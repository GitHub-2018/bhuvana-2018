$(document).ready(function(){
    console.log("Custom ready");
    console.log("next value" +$("#next").html());

    $("#testing").on("click", function(){
	console.log("on click event");
         $.ajax({  
                type: "POST",  
                url: "/bin/sling/mappingconfiguration",  
                cache: false,
                success: function(resp){
                    console.log("success");
                }
         });
    });
});