package com.jhi.aem.website.v1.core.service.admin;

import java.util.Map;

import javax.activation.DataSource;
import javax.jcr.Session;

public interface EmailService {
	
	/**
	 * Construct an email based on a template and send it to one or more
	 * recipients without attachment.
	 * 
	 * @param session
	 *            Session
	 * @param emailTemplatePath
	 *            Absolute path of the template in the repository. It should be
	 *            of type *.html
	 * @param emailProps
	 *            Map of all the dynamic properties to be passed to the template
	 * @param recipients
	 *            Array of the recipients
	 * @param recipientsInCC
	 *            Array of the CC ed Recipients
	 * @throws Exception
	 */
	public void sendEmail(Session session, final String emailTemplatePath, final Map<String, String> emailProps,
			final String[] recipients, final String[] ccList) throws Exception;
	
	/**
	 * Construct an email based on a template and send it to one or more
	 * recipients and with a from address with attachments.
	 * 
	 * @param session
	 *            Session
	 * @param emailTemplatePath
	 *            Absolute path of the template in the repository. It should be
	 *            of type *.html
	 * @param emailProps
	 *            Map of all the dynamic properties to be passed to the template
	 * @param fromAddress
	 * 			  From address to be set in the template
	 * @param recipient
	 *            Single recepient
	 * @param recipientsInCC
	 *            Array of the CC ed Recipients
	 * @param attachments
	 *            Map of attachments . Key should be attachment title and value
	 *            should be the <object>DataSource</object>
	 * @throws Exception
	 */
	public void sendEmail(Session session, final String emailTemplatePath, final Map<String, String> emailProps,String fromAddress,
			final String recipient, final String[] ccList, Map<String, DataSource> attachments) throws Exception;

	
	/**
	 * Construct an email based on a template and send it to one or more
	 * recipients and with a from address with attachments.
	 * 
	 * @param session
	 *            Session
	 * @param emailTemplatePath
	 *            Absolute path of the template in the repository. It should be
	 *            of type *.html
	 * @param emailProps
	 *            Map of all the dynamic properties to be passed to the template
	 * @param fromAddress
	 * 			  From address to be set in the template
	 * @param recipient
	 *            Multiple recepients
	 * @param recipientsInCC
	 *            Array of the CC ed Recipients
	 * @param attachments
	 *            Map of attachments . Key should be attachment title and value
	 *            should be the <object>DataSource</object>
	 * @throws Exception
	 */
	public void sendEmail(Session session, final String emailTemplatePath, final Map<String, String> emailProps,String fromAddress,
			final String[] recipients, final String[] ccList, Map<String, DataSource> attachments) throws Exception;
	
	/**
	 * Construct an email based on a template and send it to one 
	 * recipient with attachments.
	 * 
	 * @param session
	 *            Session
	 * @param emailTemplatePath
	 *            Absolute path of the template in the repository. It should be
	 *            of type *.html
	 * @param emailProps
	 *            Map of all the dynamic properties to be passed to the template
	 * @param recipients
	 *           Single Recipient
	 * @param recipientsInCC
	 *            Array of the CC ed Recipients
	 * @param attachments
	 *            Map of attachments . Key should be attachment title and value
	 *            should be the <object>DataSource</object>
	 * @throws Exception
	 */
	public void sendEmail(Session session, final String emailTemplatePath, final Map<String, String> emailProps,
			final String recipient, final String[] ccList, Map<String, DataSource> attachments) throws Exception;
	
	
	
	/**
	 * Construct an email based on a template and send it to one or more
	 * recipients with attachments.
	 * 
	 * @param session
	 *            Session
	 * @param emailTemplatePath
	 *            Absolute path of the template in the repository. It should be
	 *            of type *.html
	 * @param emailProps
	 *            Map of all the dynamic properties to be passed to the template
	 * @param recipients
	 *            Array of the recipients
	 * @param recipientsInCC
	 *            Array of the CC ed Recipients
	 * @param attachments
	 *            Map of attachments . Key should be attachment title and value
	 *            should be the <object>DataSource</object>
	 * @throws Exception
	 */
	public void sendEmail(Session session, final String emailTemplatePath, final Map<String, String> emailProps,
			final String[] recipients, final String[] ccList, Map<String, DataSource> attachments) throws Exception;
	
	
	

}
