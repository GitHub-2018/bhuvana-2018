package com.jhi.aem.website.v1.core.service.admin;

import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

import com.jhi.aem.website.v1.core.service.auth.external.IsamGroups;
import com.jhi.aem.website.v1.core.service.email.impl.MarketoApiService;
import com.jhi.aem.website.v1.core.service.isam.IsamAdminService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

public interface AdminService {
	
	static final String AUDIT_ACTIVITY_GROUP_UPDATE = "GROUP_UPDATE";
	static final String AUDIT_ACTIVITY_USER_STATUS_UPDATE = "STATUS_UPDATE";

	/**
	 * 
	 * @param isamAdminService
	 * @param marketoApiService
	 * @param userProfileService
	 * @param resolverFactory
	 * @param emailAddress
	 * @param oldGroupName
	 * @param newGroupName
	 * @return
	 */
	public boolean updateUserGroup(IsamAdminService isamAdminService, MarketoApiService marketoApiService,
			UserProfileService userProfileService, ResourceResolverFactory resolverFactory, String adminEmailAddress,
			String emailAddress, String newAemGroupName, String newIsamGroupName);
	
	/**
	 * 
	 * @param isamAdminService
	 * @param marketoApiService
	 * @param userProfileService
	 * @param resolverFactory
	 * @param adminEmailAddress
	 * @param emailAddress
	 * @param userStatus
	 * @param statusMessage
	 * @return
	 */
	public boolean updateUserActiveStatus(IsamAdminService isamAdminService, MarketoApiService marketoApiService,
			UserProfileService userProfileService, ResourceResolverFactory resolverFactory, String adminEmailAddress,
			String emailAddress, String userStatus, String statusMessage);
	
	
	/**
	 * 
	 * @param isamGroupName
	 * @return
	 */
	public String getAEMGroupName(String isamGroupName); 
	/**
	 * Verify the user has an Admin Role
	 * @param resolverFactory
	 * @param adminEmailAddress
	 * @return
	 */
	public boolean isAdminUser(ResourceResolverFactory resolverFactory, String adminEmailAddress);
	/**
	 * get the user profile from JCR
	 * @param resolverFactory
	 * @param emailAddress
	 * @return
	 */
	public Map<String, String> getUserProperty(ResourceResolverFactory resolverFactory, String emailAddress);

	/**
	 * Verify the user has an Admin Role
	 */
	boolean isAdminUser(ResourceResolver userResourceResolver);

	boolean isAdminUserGroup(Group group);
	
}
