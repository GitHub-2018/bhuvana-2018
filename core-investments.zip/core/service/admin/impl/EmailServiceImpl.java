package com.jhi.aem.website.v1.core.service.admin.impl;



import java.util.Map;

import javax.activation.DataSource;
import javax.jcr.Session;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrLookup;
import org.apache.commons.mail.HtmlEmail;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.mail.MailTemplate;
import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.jhi.aem.website.v1.core.service.admin.EmailService;


@Component(
		name="Email Service Implementations",
		immediate=true,
		service=EmailService.class)

public class EmailServiceImpl implements EmailService {

	private static final Logger LOG = LoggerFactory.getLogger(EmailServiceImpl.class);

	
	private MessageGatewayService messageGatewayService;
	@Reference
	public void bindMessageGatewayService(MessageGatewayService messageGatewayService) {
		this.messageGatewayService=messageGatewayService;
	}
	public void unbindMessageGatewayService(MessageGatewayService messageGatewayService) {
		this.messageGatewayService=messageGatewayService;
	}

	public void sendEmail(Session session, String emailTemplatePath, Map<String, String> emailProps,
			String[] recipients, String[] ccList) throws Exception {
		HtmlEmail email = new HtmlEmail();
		MailTemplate mailTemplate = MailTemplate.create(emailTemplatePath, session);
		LOG.debug("Email Template path is  {}" , emailTemplatePath);
		LOG.debug("Mail template for email service is  {}" , mailTemplate);
		if (mailTemplate != null) {
			LOG.debug(" Mail template found at {}" , emailTemplatePath);
			email = mailTemplate.getEmail(StrLookup.mapLookup(emailProps), HtmlEmail.class);
			LOG.debug(" email is {}" , email);
			// To add email addresses in TO list
			for (final String recipient : recipients) {
				if (StringUtils.isNotBlank(recipient)){
					email.addTo(recipient);
				}
			}

			// To add email addresses in CC list
			for (final String ccAddress : ccList) {
				if (StringUtils.isNotBlank(ccAddress)){
					email.addCc(ccAddress);
				}
			}

			MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
			LOG.debug(" Sending email using message Gateway {}" , messageGateway);
			messageGateway.send(email);
			LOG.debug("Email Send **** {} " , email);
		}
		
	}

	public void sendEmail(Session session, String emailTemplatePath, Map<String, String> emailProps, String recipient,
			String[] ccList, Map<String, DataSource> attachments) throws Exception {
		sendEmail(session, emailTemplatePath, emailProps, new String[]{recipient}, ccList, attachments);
		
	}

	public void sendEmail(Session session, String emailTemplatePath, Map<String, String> emailProps,
			String[] recipients, String[] ccList, Map<String, DataSource> attachments) throws Exception {
		HtmlEmail email = new HtmlEmail();
		MailTemplate mailTemplate = MailTemplate.create(emailTemplatePath, session);
		if (mailTemplate != null) {
			email = mailTemplate.getEmail(StrLookup.mapLookup(emailProps), HtmlEmail.class);

			// To add email addresses in TO list
			for (final String recipient : recipients) {
				if (StringUtils.isNotBlank(recipient)){
					email.addTo(recipient);
				}
			}

			// To add email addresses in CC list
			for (final String ccAddress : ccList) {
				if (StringUtils.isNotBlank(ccAddress)){
					email.addCc(ccAddress);
				}
			}

			if (attachments != null && attachments.size() > 0) {
				for (Map.Entry<String, DataSource> entry : attachments.entrySet()) {
					((HtmlEmail) email).attach(entry.getValue(), entry.getKey(), null);
				}
			}
			MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
			messageGateway.send(email);
		}

		else {
			LOG.info("Email Template is " + mailTemplate);
		}
		
	}

	public void sendEmail(Session session, String emailTemplatePath, Map<String, String> emailProps, String fromAddress,
			String recipient, String[] ccList, Map<String, DataSource> attachments) throws Exception {
	sendEmail(session, emailTemplatePath, emailProps, fromAddress, new String[]{recipient}, ccList, attachments);
		
	}
	
	
	public void sendEmail(Session session, String emailTemplatePath, Map<String, String> emailProps, String fromAddress,
			String[] recipients, String[] ccList, Map<String, DataSource> attachments) throws Exception {
		HtmlEmail email = new HtmlEmail();
		MailTemplate mailTemplate = MailTemplate.create(emailTemplatePath, session);
		if (mailTemplate != null) {
			email = mailTemplate.getEmail(StrLookup.mapLookup(emailProps), HtmlEmail.class);
			email.setFrom(fromAddress);
			
			// To add email addresses in TO list
			for (final String recipient : recipients) {
				if (StringUtils.isNotBlank(recipient)){
					email.addTo(recipient);
				}
			}

			// To add email addresses in CC list
			for (final String ccAddress : ccList) {
				if (StringUtils.isNotBlank(ccAddress)){
					email.addCc(ccAddress);
				}
			}

			if (attachments != null && attachments.size() > 0) {
				for (Map.Entry<String, DataSource> entry : attachments.entrySet()) {
					((HtmlEmail) email).attach(entry.getValue(), entry.getKey(), null);
				}
			}
			MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
			messageGateway.send(email);
		}

		else {
			LOG.info("Email Template is " + mailTemplate);
		}
	}
}

