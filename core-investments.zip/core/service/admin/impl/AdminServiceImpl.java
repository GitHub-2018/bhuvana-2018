package com.jhi.aem.website.v1.core.service.admin.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.constants.IsamUserProfileConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.user.AuditModel;
import com.jhi.aem.website.v1.core.service.admin.AdminService;
import com.jhi.aem.website.v1.core.service.auth.external.IsamConstants;
import com.jhi.aem.website.v1.core.service.auth.external.IsamGroups;
import com.jhi.aem.website.v1.core.service.email.impl.MarketoApiService;
import com.jhi.aem.website.v1.core.service.email.models.MarketoOAuthTokenResponse;
import com.jhi.aem.website.v1.core.service.email.models.MktCreateLeadResponse;
import com.jhi.aem.website.v1.core.service.isam.IsamAdminService;
import com.jhi.aem.website.v1.core.service.isam.models.AddUserToGroupRequest;
import com.jhi.aem.website.v1.core.service.isam.models.AddUserToGroupResponse;
import com.jhi.aem.website.v1.core.service.isam.models.RemoveUserFromGroupRequest;
import com.jhi.aem.website.v1.core.service.isam.models.RemoveUserFromGroupResponse;
import com.jhi.aem.website.v1.core.service.isam.models.UpdateUserStatusRequest;
import com.jhi.aem.website.v1.core.service.isam.models.UpdateUserStatusResponse;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.utils.AuthHelper;
import com.jhi.aem.website.v1.core.utils.UserUtil;

@Component(
		name="Admin Service Implementation",
		immediate = true,
		service=AdminService.class,
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website admin service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

public class AdminServiceImpl implements AdminService {

	private static final Logger LOG = LoggerFactory.getLogger(AdminServiceImpl.class);

	
	private UserProfileService userProfileService;
	@Reference
	public void bindUserProfileService(UserProfileService userProfileService) {
		this.userProfileService=userProfileService;
	}
	public void unbindUserProfileService(UserProfileService userProfileService) {
		this.userProfileService=userProfileService;
	}
	
	@Activate
	protected void activate() {
		LOG.info("Activate");
	}

	@Modified
	protected void update() {
		LOG.info("Update");
	}

	@Override
	public boolean updateUserGroup(IsamAdminService isamAdminService, MarketoApiService marketoApiService,
			UserProfileService userProfileService, ResourceResolverFactory resolverFactory, String adminEmailAddress,
			String emailAddress, String newAemGroupName, String newIsamGroupName) {
		// get user's first name
		Map<String, String> userProfilePropertyMap = getUserProfileProperty(resolverFactory, emailAddress);
		String firstName = userProfilePropertyMap.get(IsamUserProfileConstants.FIRSTNAME);
		
		// get user property from AEM
		Map<String, String> userPropertyMap = getUserProperty(resolverFactory, emailAddress);

		if (userPropertyMap == null)
			return false;

		// get the current ISAM Group name
		String oldIsamGroupName = userPropertyMap.get(IsamConstants.ISAM_GROUP_PROPERTY);
		LOG.info("oldIsamGroupName " + oldIsamGroupName);
		// get the AEM group name based on ISAM group name
		String oldAemGroupName = getAEMGroupName(oldIsamGroupName);
		LOG.info("oldAemGroupName " + oldAemGroupName);

		// update the group information in ISAM
		if (!isamRemoveUserFromGroup(isamAdminService, emailAddress, oldIsamGroupName))
			return false;
		if (!isamAddUserToGroup(isamAdminService, emailAddress, newIsamGroupName))
			return false;

		// update user group in AEM
		if (!updateUserPropertyInAEM(resolverFactory, emailAddress, IsamConstants.ISAM_GROUP_PROPERTY,
				newIsamGroupName))
			return false;

		// physically move user from old group to new group
		if (!removeMemberShip(resolverFactory, emailAddress, oldAemGroupName))
			return false;
		if (!applyMemberShip(resolverFactory, emailAddress, newAemGroupName))
			return false;

		// update the group information in Marketo

		if (!updateUserDetailsInMarketo(marketoApiService, emailAddress,
				userPropertyMap.get(IsamConstants.ISAM_USER_STATUS_PROPERTY), newIsamGroupName, firstName))
			return false;

		// add audit trail
		AuditModel auditModel = new AuditModel.Builder().userEmail(emailAddress).adminUserEmail(adminEmailAddress)
				.activityType(AUDIT_ACTIVITY_GROUP_UPDATE).activityMsg("User Group updated by Admin - " + adminEmailAddress)
				.build();

		if (!addAuditTrailInAEM(resolverFactory, auditModel))
			return false;

		return true;
	}

	@Override
	public boolean updateUserActiveStatus(IsamAdminService isamAdminService, MarketoApiService marketoApiService,
			UserProfileService userProfileService, ResourceResolverFactory resolverFactory, String adminEmailAddress,
			String emailAddress, String userStatus, String statusMessage) {

		Optional<String> isamStatus = Optional.empty();
		Optional<String> aemStatus = Optional.empty();

		Optional<String> userStatusFlag = Optional.of(userStatus);
		if (userStatusFlag.isPresent() && userStatusFlag.get().equals(JhiConstants.USER_ACTIVE)) {
			isamStatus = Optional.of(JhiConstants.ISAM_ACTIVE);
			aemStatus = Optional.of(JhiConstants.AEM_ACTIVE);
		} else if (userStatusFlag.isPresent() && userStatusFlag.get().equals(JhiConstants.USER_INACTIVE)) {
			isamStatus = Optional.of(JhiConstants.ISAM_INACTIVE);
			aemStatus = Optional.of(JhiConstants.AEM_INACTIVE);
		}
		// get user's first name
		Map<String, String> userProfilePropertyMap = getUserProfileProperty(resolverFactory, emailAddress);
		String firstName = userProfilePropertyMap.get(IsamUserProfileConstants.FIRSTNAME);
		LOG.info(" firstname {} ", firstName);
		
		// get user property from AEM
		Map<String, String> userPropertyMap = getUserProperty(resolverFactory, emailAddress);

		// update the status information in ISAM
		if (!isamUpdateUserStatus(isamAdminService, emailAddress, isamStatus.get()))
			return false;

		// update user status in AEM
		if (!updateUserPropertyInAEM(resolverFactory, emailAddress, IsamConstants.ISAM_USER_STATUS_PROPERTY,
				aemStatus.get()))
			return false;

		// update the group information in Marketo

		if (!updateUserDetailsInMarketo(marketoApiService, emailAddress, userStatus,
				userPropertyMap.get(IsamConstants.ISAM_GROUP_PROPERTY), firstName))
			return false;

		// add audit trail
		AuditModel auditModel = new AuditModel.Builder().userEmail(emailAddress).adminUserEmail(adminEmailAddress)
				.activityType(AUDIT_ACTIVITY_USER_STATUS_UPDATE).activityMsg(statusMessage).build();

		if (!addAuditTrailInAEM(resolverFactory, auditModel))
			return false;

		return true;
	}

    /**
     * To get the AEM group name based on ISAM Group name
     *
     * @param isamGroupName
     * @return
     */
    @Override
    public String getAEMGroupName(String isamGroupName) {

        String aemGroupName = "";
        switch (isamGroupName) {
            case IsamGroups.ISAM_ADMIN_USER_GROUP:
                aemGroupName = IsamGroups.AEM_ADMIN_USER_GROUP;
                break;
            case IsamGroups.ISAM_UNVERIFIED_PRO_GROUP:
                aemGroupName = IsamGroups.AEM_UNVERIFIED_PRO_GROUP;
                break;
            case IsamGroups.ISAM_VERIFIED_PRO_GROUP:
                aemGroupName = IsamGroups.AEM_VERIFIED_PRO_GROUP;
                break;
            case IsamGroups.ISAM_EMPLOYEE_GROUP:
                aemGroupName = IsamGroups.AEM_EMPLOYEE_GROUP;
                break;
            case IsamGroups.ISAM_INVESTOR_GROUP:
                aemGroupName = IsamGroups.AEM_INVESTOR_GROUP;
                break;
        }

		return aemGroupName;
	}

	/**
	 * Remove user from current ISAM group
	 * 
	 * @param isamAdminService
	 * @param emailAddress
	 * @param oldGroupName
	 * @return
	 */
	private boolean isamRemoveUserFromGroup(IsamAdminService isamAdminService, String emailAddress,
			String oldIsamGroupName) {
		try {
			LOG.info("Remove {} from group {}", emailAddress, oldIsamGroupName);
			RemoveUserFromGroupResponse removeUserFromGroupResponse = isamAdminService
					.removeUserFromGroup(new RemoveUserFromGroupRequest.Builder().userName(emailAddress)
							.groupName(oldIsamGroupName).build());
			if (removeUserFromGroupResponse.isSuccess()) {
				return true;
			} else {
				LOG.error("Could not remove user {} from group {} due to API Error {} ",
						new Object[] { emailAddress, oldIsamGroupName, removeUserFromGroupResponse.getMessage() });
				return false;
			}
		} catch (Exception e) {
			LOG.error("Could not remove user {} from group {}", new Object[] { emailAddress, oldIsamGroupName, e });
			return false;
		}
	}

	/**
	 * add the user to new group in ISAM
	 * 
	 * @param isamAdminService
	 * @param emailAddress
	 * @param newIsamGroupName
	 * @return
	 */
	private boolean isamAddUserToGroup(IsamAdminService isamAdminService, String emailAddress,
			String newIsamGroupName) {
		try {
			AddUserToGroupResponse addUserToGroupResponse = isamAdminService.addUserToGroup(
					new AddUserToGroupRequest.Builder().userName(emailAddress).groupName(newIsamGroupName).build());
			if (addUserToGroupResponse.isSuccess()) {
				return true;
			} else {
				LOG.error("Could not add user {} to group {} due to API Error {} ",
						new Object[] { emailAddress, newIsamGroupName, addUserToGroupResponse.getMessage() });
				return false;
			}
		} catch (Exception e) {
			LOG.error("Could not add user {} to group {}", new Object[] { emailAddress, newIsamGroupName, e });
			return false;
		}
	}

	/**
	 * Update user status in ISAM
	 * 
	 * @param isamAdminService
	 * @param emailAddress
	 * @param userStatus
	 * @return
	 */
	private boolean isamUpdateUserStatus(IsamAdminService isamAdminService, String emailAddress, String userStatus) {
		try {
			UpdateUserStatusResponse updateUserStatusResponse = isamAdminService.updateUserStatus(
					new UpdateUserStatusRequest.Builder().userName(emailAddress).status(userStatus).build());
			if (updateUserStatusResponse.isSuccess()) {
				return true;
			} else {
				LOG.error("Could not add user {} to group {} due to API Error {} ",
						new Object[] { emailAddress, userStatus, updateUserStatusResponse.getMessage() });
				return false;
			}
		} catch (Exception e) {
			LOG.error("Could not update user {} status to {}", new Object[] { emailAddress, userStatus, e });
			return false;
		}
	}

	/**
	 * Update user details in Marketo
	 * 
	 * @param marketoApiService
	 * @param emailAddress
	 * @param userStatus
	 * @param groupName
	 * @return
	 */
	private boolean updateUserDetailsInMarketo(MarketoApiService marketoApiService, String emailAddress,
			String userStatus, String groupName, String userFirstName) {
		try {
			// Update the field in Marketo
			// Get the token
			MarketoOAuthTokenResponse mktOAuthResp = marketoApiService.getMarketoAccessToken();
			String accessToken = StringUtils.EMPTY;

			if (null != mktOAuthResp) {
				accessToken = mktOAuthResp.getAccessToken();
				LOG.info("accesstoken {} groupname {}", accessToken, groupName);
			} else {
				LOG.error("Error while getting access token from Marketo");
				return false;
			}
			MktCreateLeadResponse mktCreateLeadResponse = marketoApiService.createMarketoLead(accessToken, emailAddress,
					userFirstName, null);
			if (mktCreateLeadResponse.getSuccess()) {
				// Update the user record in Marketo
				MktCreateLeadResponse marketoResponse = marketoApiService.createUpdateCustomField(accessToken,
						emailAddress, userStatus, groupName);

				if (marketoResponse.getSuccess()) {
					LOG.info("Successfully updated Marketo for user {} to group {} and status {}",
							new Object[] { emailAddress, groupName, userStatus });
					return true;
				} else {
					LOG.error("Could not update Marketo for user {} to group {} and status {} - error while updating custom fields",
							new Object[] { emailAddress, groupName, userStatus });
					return false;
				}
			} else {
				LOG.error("Could not update Marketo for user {} to group {} and status {} - error while getting lead",
						new Object[] { emailAddress, groupName, userStatus });
				return false;
			}

			

		} catch (Exception e) {
			LOG.error("Could not update user Marketo for user {} to group {} and status {}",
					new Object[] { emailAddress, groupName, userStatus, e });
			return false;
		}
	}

	/**
	 * 
	 * @param resolverFactory
	 * @param emailAddress
	 * @param newGroupName
	 * @return
	 */
	private boolean updateUserPropertyInAEM(ResourceResolverFactory resolverFactory, String emailAddress,
			String propertyName, String propertyValue) {
		ResourceResolver resolver = null;
		try {
			resolver = getResourceResolver(resolverFactory);

			Resource resource = AuthHelper.queryUserResource(resolver, JhiConstants.USER_REP_AUTHORIZABLE_ID,
					emailAddress);

			ModifiableValueMap valueMap = AuthHelper.getModifiableMapForUserResource(resource);

			if (valueMap == null) {
				LOG.error("Could not get a modifiable map for the user {}", emailAddress);
				return false;
			}

			// update the node value
			valueMap.put(propertyName, propertyValue);
			resource.getResourceResolver().commit();

			// return success flag
			return true;

		} catch (Exception e) {
			LOG.error("Could not set user property {} in AEM for {}", new Object[] { propertyName, emailAddress, e });
			return false;
		} finally {
			closeResourceResolver(resolver);
		}
	}

    /**
     * get the user profile from JCR
     *
     * @param resolverFactory
     * @param emailAddress
     * @return
     */
    @Override
    public Map<String, String> getUserProperty(ResourceResolverFactory resolverFactory, String emailAddress) {
        ResourceResolver resolver = null;
        try {
            resolver = getResourceResolver(resolverFactory);

			Resource resource = AuthHelper.queryUserResource(resolver, JhiConstants.USER_REP_AUTHORIZABLE_ID,
					emailAddress);

			ModifiableValueMap userValueMap = AuthHelper.getModifiableMapForUserResource(resource);

			if (userValueMap == null)
				return null;

			return userValueMap.entrySet().stream()
					.collect(Collectors.toMap(p -> p.getKey().toString(), p -> p.getValue().toString()));

		} catch (Exception e) {
			LOG.error("Could not get user property from AEM for {}", new Object[] { emailAddress, e });
			return null;
		} finally {
			closeResourceResolver(resolver);
		}
	}
	/**
	 * get the user profile property
	 * @param resolverFactory
	 * @param emailAddress
	 * @return
	 */
	private Map<String, String> getUserProfileProperty(ResourceResolverFactory resolverFactory, String emailAddress) {
		ResourceResolver resolver = null;
		try {
			resolver = getResourceResolver(resolverFactory);

			Resource resource = AuthHelper.queryUserResource(resolver, JhiConstants.USER_REP_AUTHORIZABLE_ID,
					emailAddress);

			ModifiableValueMap userValueMap = AuthHelper.getModifiableProfileForUserResource(resource);

			if (userValueMap == null)
				return null;

			return userValueMap.entrySet().stream()
					.collect(Collectors.toMap(p -> p.getKey().toString(), p -> p.getValue().toString()));

		} catch (Exception e) {
			LOG.error("Could not get user property from AEM for {}", new Object[] { emailAddress, e });
			return null;
		} finally {
			closeResourceResolver(resolver);
		}
	}

	/**
	 * 
	 * @param resolver
	 */
	private void closeResourceResolver(ResourceResolver resolver) {
		if (resolver != null) {
			resolver.close();
		}
	}

	/**
	 * 
	 * @param resolverFactory
	 * @return
	 * @throws LoginException
	 */
	private ResourceResolver getResourceResolver(ResourceResolverFactory resolverFactory) throws LoginException {
		ResourceResolver resolver = resolverFactory.getServiceResourceResolver(Collections
				.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER));
		if (resolver == null) {
			LOG.error("Could not retrieve resource resolver for '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER);
		}
		return resolver;
	}

	/**
	 * 
	 * @param resolver
	 * @param emailAddress
	 * @param oldGroupName
	 * @return
	 * @throws RepositoryException
	 */
	private boolean removeMemberShip(ResourceResolverFactory resolverFactory, String emailAddress,
			String oldGroupName) {
		ResourceResolver resolver = null;
		try {
			resolver = getResourceResolver(resolverFactory);
			UserManager userManager = resolver.adaptTo(UserManager.class);
			Authorizable userAuthorizable = userManager.getAuthorizable(emailAddress);
			Authorizable group = userManager.getAuthorizable(oldGroupName);
			if (group == null) {
				LOG.warn("Unable to apply remove-membership to {}. No such group: {}", emailAddress, oldGroupName);
				LOG.info("Unable to apply remove-membership to {}. No such group: {}", emailAddress, oldGroupName);
				return false;
			} else if (group instanceof Group) {
				((Group) group).removeMember(userAuthorizable);
				return true;
			} else {
				LOG.warn("Unable to apply remove-membership to {}. Authorizable '{}' is not a group.", emailAddress,
						oldGroupName);
				LOG.info("Unable to apply remove-membership to {}. Authorizable '{}' is not a group.", emailAddress,
						oldGroupName);
				return false;
			}
		} catch (Exception e) {
			LOG.error("Unable to apply remove-membership to {} from group {} due to error ",
					new Object[] { emailAddress, oldGroupName, e });
			return false;
		} finally {
			closeResourceResolver(resolver);
		}
	}

	/**
	 * 
	 * @param resolver
	 * @param emailAddress
	 * @param oldGroupName
	 * @return
	 * @throws RepositoryException
	 */
	private boolean applyMemberShip(ResourceResolverFactory resolverFactory, String emailAddress, String newGroupName) {
		ResourceResolver resolver = null;
		try {
			resolver = getResourceResolver(resolverFactory);
			UserManager userManager = resolver.adaptTo(UserManager.class);
			Authorizable userAuthorizable = userManager.getAuthorizable(emailAddress);
			Authorizable group = userManager.getAuthorizable(newGroupName);
			if (group == null) {
				LOG.warn("Unable to apply add-membership to {}. No such group: {}", emailAddress, newGroupName);
				return false;
			} else if (group instanceof Group) {
				((Group) group).addMember(userAuthorizable);
				return true;
			} else {
				LOG.warn("Unable to apply add-membership to {}. Authorizable '{}' is not a group.", emailAddress,
						newGroupName);
				return false;
			}
		} catch (Exception e) {
			LOG.error("Unable to apply add-membership to {} from group {} due to error ",
					new Object[] { emailAddress, newGroupName, e });
			return false;
		} finally {
			closeResourceResolver(resolver);
		}
	}

	/**
	 * Add audit trail in AEM
	 * 
	 * @param resolverFactory
	 * @param auditModel
	 * @return
	 */
	private boolean addAuditTrailInAEM(ResourceResolverFactory resolverFactory, AuditModel auditModel) {
		ResourceResolver resolver = null;
		try {
			resolver = getResourceResolver(resolverFactory);

			Resource userResource = AuthHelper.queryUserResource(resolver, JhiConstants.USER_REP_AUTHORIZABLE_ID,
					auditModel.getUserEmail());
			if (userResource == null) {
				LOG.error("Could not get Resource object for the user {}", auditModel.getUserEmail());
				return false;
			}

			return userProfileService.addAuditTrail(userResource, auditModel);
		} catch (Exception e) {
			LOG.error("Unable to add audit trail for user {} due to error ",
					new Object[] { auditModel.getUserEmail(), e });
		} finally {
			closeResourceResolver(resolver);
		}

		return false;
	}

	/**
	 * 
	 * @param userResource
	 * @param dataName
	 * @return
	 */
	private Resource prepareUserDataResource(Resource userResource, String dataName) {
		if (userResource == null) {
			return null;
		}
		Resource dataResource = userResource.getChild(dataName);
		ResourceResolver resourceResolver = userResource.getResourceResolver();
		if (dataResource == null) {
			final Map<String, Object> dataProperties = new HashMap<>();
			dataProperties.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
			try {
				dataResource = resourceResolver.create(userResource, dataName, dataProperties);
				resourceResolver.commit();
			} catch (PersistenceException e) {
				LOG.error("Problem while creating data resource: {}", dataName, e);
				dataResource = null;
			}
		}
		return dataResource;
	}

	/**
	 * Verify the user has an Admin Role
	 * 
	 * @param resolverFactory
	 * @param adminEmailAddress
	 * @return
	 */
	@Override
	public boolean isAdminUser(ResourceResolverFactory resolverFactory, String adminEmailAddress) {

		ResourceResolver resolver = null;

		try {
			resolver = getResourceResolver(resolverFactory);
			Resource resource = AuthHelper.queryUserResource(resolver, JhiConstants.USER_REP_AUTHORIZABLE_ID,
					adminEmailAddress);
			ModifiableValueMap valueMap = AuthHelper.getModifiableMapForUserResource(resource);
			if (valueMap == null) {
				LOG.error("Could not get a modifiable map for the user {}", adminEmailAddress);
				return false;
			}
			String groupName = valueMap.get(IsamConstants.ISAM_GROUP_PROPERTY, String.class);
			LOG.debug(" User's ISAM group status {} ", groupName);
			Optional<String> groupNameOpt = Optional.ofNullable(groupName);
			return groupNameOpt.isPresent() && groupNameOpt.get().equals(IsamGroups.ISAM_ADMIN_USER_GROUP);
		} catch (LoginException loginException) {
			return false;
		} finally {
			closeResourceResolver(resolver);
		}

	}

	/**
	 * Verify the user has an Admin Role
	 * @return
	 */
	@Override
	public boolean isAdminUser(ResourceResolver userResourceResolver) {
		Authorizable authorizable = UserUtil.getCurrentAuthorizable(userResourceResolver);
		
		if (authorizable != null) {

			try {
				Iterator<Group> declaredMemberOf = authorizable.declaredMemberOf();
				while (declaredMemberOf.hasNext()) {
					Group group = declaredMemberOf.next();
					if (isAdminUserGroup(group)) {
						return true;
					}
				}

			} catch (RepositoryException e) {
				LOG.warn("Error accessing groups for {}", userResourceResolver.getUserID(), e);
			}

		} else {
			LOG.debug("No authorizable found for this request");
		}
		
		return false;
	}

	@Override
	public boolean isAdminUserGroup(Group group) {
		try {
			if (StringUtils.equals(group.getID(), IsamGroups.AEM_ADMIN_USER_GROUP)) {
				return true;
			}
		} catch (RepositoryException e) {
			LOG.warn("Error get group id", e);
		}
		
		return false;
	}

}
