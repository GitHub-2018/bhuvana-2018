package com.jhi.aem.website.v1.core.service.cart;

import java.util.List;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.CommerceService;
import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.commerce.api.CommerceSession.CartEntry;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Component(
		service=UserCartService.class,
		immediate=true,
		property= {
				Constants.SERVICE_DESCRIPTION+"=User Cart Service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR			
		})

public class UserCartServiceImpl implements UserCartService {
	private final static Logger LOG = LoggerFactory.getLogger(UserCartServiceImpl.class);
    private static final int DEFAULT_QUANTITY = 1;
    private static final String QUANTITY_PARAMETER = "quantity";

	@Override
	public CommerceSession getCommerceSession(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) {
        Resource resource = request.getResource();
        CommerceSession commerceSession = null;
        CommerceService commerceService = resource.adaptTo(CommerceService.class);

        if (commerceService == null) {
            LOG.debug("No commerce service for resource {}", resource.getPath());
        } else{
	        try {
	            commerceSession = commerceService.login(request, response);
	        } catch (CommerceException e) {
	            LOG.debug("Problem while obtaining commerce session", e);
	        }
        }
        
        return commerceSession;
	}

	@Override
	public void logout(CommerceSession commerceSession) {
		if (commerceSession != null) {
	        try {
	            commerceSession.logout();
	        } catch (CommerceException e) {
	            LOG.error("Problem while closing commerce session", e);
	        }
		}
	}
	
	@Override
	public int getTotalItems(CommerceSession commerceSession) {
		int total = 0;

		try {
			List<CartEntry> cartEntries = commerceSession.getCartEntries();
			
			if (cartEntries != null && !cartEntries.isEmpty()) {
				for (CartEntry entry : cartEntries) {
					// Total should be total distinct items, not accummulated quantity
					// total += entry.getQuantity();
					total++;
				}
			}
		} catch (CommerceException e) {
			LOG.warn("Could not get commerce service entries", e);
		}
		
		return total;
	}

    @Override
	public int getQuantity(SlingHttpServletRequest request) {
        String parameter = request.getParameter(QUANTITY_PARAMETER);
        int value = DEFAULT_QUANTITY;
        if (StringUtils.isNumeric(parameter)) {
            value = Integer.parseInt(parameter);
            if (value < 0) {
                value = DEFAULT_QUANTITY;
            }
        }

        return value;
    }

    @Override
	public void modifyCartEntry(CommerceSession commerceSession, int entryNumber, int quantity) throws CommerceException {
        commerceSession.modifyCartEntry(entryNumber, ImmutableMap.of(QUANTITY_PARAMETER, quantity));
    }
}
