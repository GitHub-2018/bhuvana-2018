package com.jhi.aem.website.v1.core.service.cart;

import javax.annotation.Nonnull;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;

import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.commerce.api.CommerceSession.CartEntry;
import com.google.common.collect.ImmutableMap;

public interface UserCartService {

	CommerceSession getCommerceSession(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response);

	void logout(CommerceSession commerceSession);

	int getQuantity(SlingHttpServletRequest request);

	void modifyCartEntry(CommerceSession commerceSession, int entryNumber, int quantity) throws CommerceException;

	int getTotalItems(CommerceSession commerceSession);


}
