package com.jhi.aem.website.v1.core.service.assetmanager;

import java.util.Collection;
import java.util.Map;

import org.apache.sling.api.resource.Resource;

import com.jhi.aem.website.v1.core.service.assetmanager.impl.AssetManagerLookupDto;

public interface AssetManagerLookupService {

    Map<String, Collection<AssetManagerLookupDto>> findAssetManagers(String sharedClasses, Resource resource, String hostBaseUrl);
}
