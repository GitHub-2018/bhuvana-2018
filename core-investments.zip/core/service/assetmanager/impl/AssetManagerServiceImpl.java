package com.jhi.aem.website.v1.core.service.assetmanager.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.search.Predicate;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.FulltextPredicateEvaluator;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.eval.TypePredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.models.search.SearchResultsItems;
import com.jhi.aem.website.v1.core.models.viewpoint_asset_manager.ViewpointsAssetManagerModel;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.service.pagetags.PageTagsQueryService;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.StreamUtils;

@Component(
		name="Asset Manager Service implementations",
		immediate = true,
		service=AssetManagerService.class,
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website asset manager service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

public class AssetManagerServiceImpl implements AssetManagerService {
    private static final Logger LOG = LoggerFactory.getLogger(AssetManagerServiceImpl.class);
    protected static final String FUND_MANAGER_FUNDS_PARSYS = "/jcr:content/fundManagerFunds/fundsParagraph";

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    
    private PageTagsQueryService pageTagsQueryService;
    @Reference
    public void bindPageTagsQueryService(PageTagsQueryService pageTagsQueryService) {
    	this.pageTagsQueryService=pageTagsQueryService;
    }
    public void unbindPageTagsQueryService(PageTagsQueryService pageTagsQueryService) {
    	this.pageTagsQueryService=pageTagsQueryService;
    }

    
    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }

    @Override
    public List<AssetManagerModel> getAllAssetManagers(String rootPath) {
        List<AssetManagerModel> result = new ArrayList<>();
        ResourceResolver resolver = null;

        try {
            resolver = resolverFactory.getServiceResourceResolver(
                    Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));
            result = getAllAssetManagers(resolver, rootPath);
        } catch (LoginException e) {
            LOG.error("Error reading asset managers", e);
        } finally {
            if (resolver != null) {
                resolver.close();
            }
        }

        return result;
    }

    @Override
    public List<AssetManagerModel> getAllAssetManagers(ResourceResolver resourceResolver, String rootPath) {
        List<Page> pages = pageTagsQueryService.getPagesOfResourceType(resourceResolver, rootPath,
                ResourcesConstants.ASSET_MANAGER_CONFIG_PAGE_RESOURCE_TYPE);
        return getAssetManagerModelListForPageList(pages);
    }

    private List<AssetManagerModel> getAssetManagerModelListForPageList(List<Page> pages) {
        List<AssetManagerModel> assetManagers = new ArrayList<>(pages.size());
        for (Page page : pages) {
            if (page != null && page.isValid()) {
                AssetManagerModel assetManager = AssetManagerModel.fromPage(page);
                if (!assetManager.isBlank()) {
                    assetManagers.add(assetManager);
                }
            }
        }
        Collections.sort(assetManagers);
        return assetManagers;
    }

    @Override
    public AssetManagerModel getAssetManagerWithTagId(ResourceResolver resourceResolver, String rootPath,
            String tagId) {
        List<Page> pages = pageTagsQueryService.getPagesOfResourceTypeWithViewpointsTag(resourceResolver, rootPath,
                ResourcesConstants.ASSET_MANAGER_CONFIG_PAGE_RESOURCE_TYPE, tagId);

        if (!pages.isEmpty()) {
            return AssetManagerModel.fromPage(pages.get(0));
        }

        return null;
    }

    @Override
    public SearchResultsItems searchAssetManagers(ResourceResolver resourceResolver, String path, String queryText, int offset,
            int maxItems) {
        if (resourceResolver == null || StringUtils.isBlank(path)) {
            return SearchResultsItems.EMPTY;
        }

        SearchResultsItems searchResultsItems = new SearchResultsItems(maxItems > 0);
        SearchResult result = getSearchResult(resourceResolver, path, queryText, offset, maxItems);
        /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        if (!result.getHits().isEmpty()) {
            searchResultsItems.setTotalMatches((int) result.getTotalMatches());
            for (Hit hit : result.getHits()) {
                try {
                	String pagePath = hit.getPath();
                    Resource pageResource = resourceResolver.getResource(pagePath);
                    if (pageResource != null) {
                        Page page = pageResource.adaptTo(Page.class);
                        if (page != null && page.isValid()) {
                            if (searchResultsItems.getResults().size() < searchResultsItems.getMaxItems()) {
                                ViewpointsAssetManagerModel viewpointsAssetManagerModel = ViewpointsAssetManagerModel
                                        .fromAssetManagerPage(page);
                                if (viewpointsAssetManagerModel != null && !viewpointsAssetManagerModel.isBlank()) {
                                    searchResultsItems.addResult(viewpointsAssetManagerModel);
                                }
                            }
                        }
                    }
                } catch (RepositoryException e) {
                    LOG.error("Problem fetching page resource", e);
                }
            }
        }
        /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        return searchResultsItems;
    }

    @Override
    public List<Page> getAssetManagersConfigPages(Page page) {
        if (page != null) {
            List<Page> pages = new ArrayList<>();
            Page assetManagersRoot = PageUtil.getSitePageByResourceType(page,
                    ResourcesConstants.ASSET_MANAGERS_CONFIG_ROOT_PAGE_RESOURCE_TYPE);
            if (assetManagersRoot != null) {
                Iterator<Page> assetManagersIterator = assetManagersRoot.listChildren();
                while (assetManagersIterator.hasNext()) {
                    Page assetManagerPage = assetManagersIterator.next();
                    if (assetManagerPage != null && assetManagerPage.isValid()) {
                        pages.add(assetManagerPage);
                    }
                }
                return pages;
            }
        }
        return Collections.emptyList();
    }

    private SearchResult getSearchResult(ResourceResolver resourceResolver, String path, String queryText, int offset,
            int maxItems) {
        final Map<String, String> searchParams = new HashMap<>();
        searchParams.put(PathPredicateEvaluator.PATH, path);
        searchParams.put(TypePredicateEvaluator.TYPE, NameConstants.NT_PAGE);
        if (StringUtils.isNotBlank(queryText)) {
            searchParams.put(FulltextPredicateEvaluator.FULLTEXT, queryText + JhiConstants.ASTERISK);
        }
        searchParams.put(JcrPropertyPredicateEvaluator.PROPERTY, JhiConstants.PAGE_RESOURCE_TYPE_PROPERTY);
        searchParams.put(JhiConstants.PROPERTY_VALUE_PARAMETER, ResourcesConstants.ASSET_MANAGER_CONFIG_PAGE_RESOURCE_TYPE);
        searchParams.put(Predicate.ORDER_BY, "@" + JhiConstants.TITLE_PROPERTY_NAME);
        searchParams.put(JhiConstants.ORDER_BY_SORT_PROPERTY, Predicate.SORT_ASCENDING);

        final Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams),
                resourceResolver.adaptTo(Session.class));
        query.setStart(offset);
        query.setHitsPerPage(maxItems);

        return query.getResult();
    }

    @Override
    public Set<AssetManagerModel> getAssetManagersForAssetClasses(Page page, Set<String> assetClasses) {
        return getAssetManagersForAssetClassesAndInvestmentTypes(page, assetClasses, null);
    }

    @Override
    public Set<AssetManagerModel> getAssetManagersForInvestmentTypes(Page page, Set<String> investmentTypes) {
        return getAssetManagersForAssetClassesAndInvestmentTypes(page, null, investmentTypes);
    }

    @Override
    @SuppressWarnings("unchecked")
    public Set<AssetManagerModel> getAssetManagersForAssetClassesAndInvestmentTypes(Page page,
            Set<String> assetClasses, Set<String> investmentTypes) {
        // For each asset class look up the asset managers associated with that asset class tag
        List<AssetManagerModel> allAssetManagers = getAllAssetManagers(page.getContentResource().getResourceResolver(),
                PageUtil.getAssetManagersConfigRootPath(page));

        if (allAssetManagers != null) {
            return allAssetManagers.stream()
                    .filter(assetManager ->
                    // Check if the asset classes for this asset manager contains a match for any which are set
                    // up in the component
                    (assetManager.getAssetsClasses() != null &&
                            assetClasses != null &&
                            assetManager.getAssetsClasses().stream().anyMatch(assetClasses::contains)) ||
                    // Check if the investment types for this asset manager contains a match for any which are set
                    // up in the component
                            (assetManager.getInvestmentTypes() != null &&
                                    investmentTypes != null &&
                                    assetManager.getInvestmentTypes().stream().anyMatch(investmentTypes::contains)))
                    .collect(Collectors.toSet());
        }

        return Collections.EMPTY_SET;
    }

    @Override
    public Set<String> getFundsForAssetManager(Page page, String assetManagerReference) {
        // Equivalent Querybuilder query:
        // http://localhost:4502/bin/querybuilder.json?
        // path=/content/jhi-website/en_US_dev/hidden/people&
        // 1_property=jcr:content/personalBiography/assetManager&
        // 1_property.value=/content/jhi-viewpoints-blog/en_US/hidden/asset-managers/john-hancock-investments&
        // 2_property=jcr:content/fundManagerFunds/fundsParagraph/fundmanagerfund/fund&
        // 2_property.operation=exists&
        // p.hits=selective&
        // p.properties=jcr:content/fundManagerFunds/fundsParagraph/fundmanagerfund/fund

        // Create a query which gets all of the funds from a person who has a reference to this asset manager
        final Map<String, String> searchParams = new HashMap<>();
        searchParams.put(PathPredicateEvaluator.PATH, PageUtil.getPeopleRootPath(page));
        searchParams.put("1_" + JcrPropertyPredicateEvaluator.PROPERTY, JhiConstants.PAGE_CONTENT_ASSET_MANAGER_PROPERTY);
        searchParams.put("1_" + JhiConstants.PROPERTY_VALUE_PARAMETER, assetManagerReference);
        searchParams.put("2_" + JcrPropertyPredicateEvaluator.PROPERTY,
                JhiConstants.PEOPLE_PAGE_PERSONAL_BIOGRAPHY_FUND_MANAGER_FUND_FUND_PROPERTY);
        searchParams.put("2_" + JhiConstants.PROPERTY_OPERATION_PARAMETER, JcrPropertyPredicateEvaluator.OP_EXISTS);
        // searchParams.put("p.hits", "selective");
        // searchParams.put("p.properties", JhiConstants.PEOPLE_PAGE_PERSONAL_BIOGRAPHY_FUND_MANAGER_FUND);

        Set<String> returnSet = new HashSet<>();
        Resource resource = page.adaptTo(Resource.class);
        if (resource != null) {
            ResourceResolver resolver = resource.getResourceResolver();
            final Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resolver.adaptTo(Session.class));
            query.setStart(0);
            query.setHitsPerPage(Integer.MAX_VALUE);
            // Run the query
            SearchResult result = query.getResult();
            /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
            if (!result.getHits().isEmpty()) {
                for (Hit hit : result.getHits()) {
                    try {
                    	String path = hit.getPath();
						Resource resultResource = resolver.getResource(path);
                        Set<String> funds = getFundTags(resolver, resultResource);
                        returnSet.addAll(funds);
                    } catch (RepositoryException e) {
                        LOG.error("Problem fetching results", e);
                    }
                }
            }
            /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        }
        return returnSet;
    }

    @Override
    public Set<Tag> getAllAssetClassesTags(ResourceResolver resolver) {
        TagManager tagManager = resolver.adaptTo(TagManager.class);
        if (tagManager != null) {
            Tag assetClassesRootTag = tagManager.resolve(JhiConstants.ASSET_CLASSES_TAG_PREFIX);
            Set<Tag> assetClassesTags = new TreeSet<>((o1, o2) -> {
                if (StringUtils.isBlank(o1.getTitle())) {
                    return -1;
                }
                if (StringUtils.isBlank(o2.getTitle())) {
                    return 1;
                }
                return o1.getTitle().compareTo(o2.getTitle());
            });
            assetClassesRootTag.listChildren().forEachRemaining(assetClassesTags::add);
            return assetClassesTags;
        }
        return Collections.emptySet();
    }

    @Override
    public Set<AssetManagerModel> getConfiguredAssetManagers(ResourceResolver resolver, List<Resource> assetManagers) {
        return assetManagers.stream()
                .map(resource -> resolver.getResource(
                        resource.getValueMap().get("assetMgr") + JhiConstants.SLASH + JcrConstants.JCR_CONTENT + JhiConstants.SLASH + AssetManagerModel.ASSET_MANAGER_PATH))
                .filter(Objects::nonNull)
                .map(resource -> resource.adaptTo(AssetManagerModel.class))
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(LinkedHashSet::new));

    }
    
    

    @Override
    public List<AssetManagerModel> getGridAssetManagers(String rootPath) {
        return getAllAssetManagers(rootPath)
                .stream()
                .filter(AssetManagerModel::showLogoInGrid)
                .collect(Collectors.toList());
    }

    private Set<String> getFundTags(ResourceResolver resolver, Resource resultResource) {
        return StreamUtils
                .getChildrenResourcesAsList(resolver, resultResource.getPath() + FUND_MANAGER_FUNDS_PARSYS)
                .stream()
                .map(Resource::getValueMap)
                .map(valueMap -> valueMap.get(JhiConstants.FUND_MANAGER_COMPONENT_FUND_TAGS_PROPERTY, String.class))
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.toSet());
    }
}