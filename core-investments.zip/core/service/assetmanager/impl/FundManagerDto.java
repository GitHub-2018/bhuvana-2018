package com.jhi.aem.website.v1.core.service.assetmanager.impl;

import com.google.gson.annotations.Expose;
import com.jhi.aem.website.v1.core.models.fundmanager.FundManagerFundModel;
import com.jhi.aem.website.v1.core.models.person.PersonalBiographyDetails;
import com.jhi.aem.website.v1.core.service.fund.FundManagerFullDetails;

public class FundManagerDto {

    @Expose
    private final String name;
    @Expose
    private final String position;
    @Expose
    private final String careerStartDate;
    @Expose
    private final int yearsOfExperience;
    @Expose
    private final Integer fundStartYear;
    @Expose
    private final Integer yearsOnFund;
    @Expose
    private String image;
    @Expose
    private final String biography;

    public FundManagerDto(FundManagerFullDetails fullDetails, String hostBaseUrl) {
        PersonalBiographyDetails personalBiographyDetails = fullDetails.getPersonalBiographyDetails();
        name = personalBiographyDetails.getName();
        position = personalBiographyDetails.getPosition();
        careerStartDate = personalBiographyDetails.getCareerStartDateFormatted();
        yearsOfExperience = personalBiographyDetails.getYearsOfExperience();
        if(!personalBiographyDetails.getImagePath().isEmpty()){
            image = hostBaseUrl + personalBiographyDetails.getImagePath();
        }
        biography = personalBiographyDetails.getBiography();
        FundManagerFundModel fundModel = fullDetails.getFundManagerFundModel();
        fundStartYear = fundModel.getStartYear();
        yearsOnFund = fundModel.getYearsOnFund();
    }
}
