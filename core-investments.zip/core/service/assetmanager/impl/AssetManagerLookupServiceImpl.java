package com.jhi.aem.website.v1.core.service.assetmanager.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.models.fund.FundTag;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerLookupService;
import com.jhi.aem.website.v1.core.service.fund.FundManagerFullDetails;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListingType;
import com.jhi.aem.website.v1.core.service.tags.TagsQueryService;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Component(
		name="Asset Manager LookUp Service implementation",
		immediate=true,
		service=AssetManagerLookupService.class,
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website asset manager lookup service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

public class AssetManagerLookupServiceImpl implements AssetManagerLookupService {

    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }

    
    private FundService fundService;
    @Reference
    public void bindFundService(FundService fundService) {
    	this.fundService=fundService;
    }
    public void unbindFundService(FundService fundService) {
    	this.fundService=fundService;
    }

    
    private TagsQueryService tagsQueryService;
    @Reference
    public void bindTagsQueryService(TagsQueryService tagsQueryService) {
    	this.tagsQueryService=tagsQueryService;
    }
    public void unbindTagsQueryService(TagsQueryService tagsQueryService) {
    	this.tagsQueryService=tagsQueryService;
    }

    private ResourceResolver resourceResolver;

    @Override
    public Map<String, Collection<AssetManagerLookupDto>> findAssetManagers(String shareClassesString, Resource resource, String hostBaseUrl) {

        Map<String, Collection<AssetManagerLookupDto>> results = new HashMap<>();

        Page page = PageUtil.getContainingPage(resource);
        boolean inUcitsSite = PageUtil.isInUcitsSite(page);
        List<String> shareClassIds = getShareClassIds(inUcitsSite ? FundListingType.UCITS_ONLY : FundListingType.NON_UCITS, shareClassesString);
        final TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
        for (String shareClassId : shareClassIds) {
            Tag shareClassTag = tagManager.resolve(shareClassId);
            Set<FundManagerFullDetails> fundManagerFullDetails = fundService.getPeopleManagingFund(shareClassTag, page);
            if (!fundManagerFullDetails.isEmpty()) {
                results.put(shareClassId, mapToAssetManagerLookupDto(fundManagerFullDetails, hostBaseUrl));
            }
        }

        return results;
    }

    private Collection<AssetManagerLookupDto> mapToAssetManagerLookupDto(Set<FundManagerFullDetails> fundManagerFullDetails, String hostBaseUrl) {
        HashMap<String, AssetManagerLookupDto> assetManagerLookupDtos = new HashMap<>();
        for (FundManagerFullDetails fundManager : fundManagerFullDetails) {
            AssetManagerModel assetManagerModel = fundManager.getPersonalBiographyDetails().getAssetManager();
            AssetManagerLookupDto dto = Optional.ofNullable(assetManagerLookupDtos.get(assetManagerModel.getName()))
                    .orElseGet(() -> new AssetManagerLookupDto(fundManager.getPersonalBiographyDetails().getAssetManager(), hostBaseUrl));
            assetManagerLookupDtos.putIfAbsent(dto.getName(), dto);
            dto.addFundManager(fundManager);
        }
        return assetManagerLookupDtos.values();
    }

    private List<String> getShareClassIds(FundListingType fundListingType, String shareClassString) {
        List<String> shareClasses = Optional.ofNullable(shareClassString)
                .map(s -> s.split(","))
                .map(Arrays::asList)
                .orElse(Collections.emptyList());
        if (shareClasses.isEmpty()) {
            shareClasses = getAllShareClassIds(fundListingType);
        }
        return shareClasses;
    }

    private List<String> getAllShareClassIds(FundListingType fundListingType) {
        ResourceResolver resolver = null;
        try {
            resolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
            return tagsQueryService.getAllShareClassTags(resolver, fundListingType)
                    .stream()
                    .map(FundTag::getTagId)
                    .collect(Collectors.toList());
        } finally {
            if (resolver != null) {
                resolver.close();
            }
        }

    }

}
