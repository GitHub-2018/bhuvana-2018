package com.jhi.aem.website.v1.core.service.assetmanager.impl;

import java.util.ArrayList;
import java.util.List;

import com.drew.lang.annotations.NotNull;
import com.google.gson.annotations.Expose;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.service.fund.FundManagerFullDetails;

public class AssetManagerLookupDto {

    @Expose
    private String description;
    @Expose
    private String logoUrl;

    @Expose
    private String name;

    @Expose
    private List<FundManagerDto> fundManagers = new ArrayList<>();
    private String hostBaseUrl;

    public AssetManagerLookupDto(@NotNull AssetManagerModel assetManager, String baseUrl) {
        hostBaseUrl = baseUrl;
        description = assetManager.getLongDescription();
        if (!assetManager.getLogoPath().isEmpty()) {
            logoUrl = hostBaseUrl + assetManager.getLogoPath();
        }
        name = assetManager.getName();
    }

    public String getName() {
        return name;
    }

    void addFundManager(FundManagerFullDetails fundManagerFullDetails) {
        fundManagers.add(new FundManagerDto(fundManagerFullDetails, hostBaseUrl));
    }
}
