package com.jhi.aem.website.v1.core.service.assetmanager;

import java.util.List;
import java.util.Set;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.models.search.SearchResultsItems;

public interface AssetManagerService {

    /**
     * Retrieves a list of all asset managers from the root path
     *
     * @param rootPath
     * @return
     */
    List<AssetManagerModel> getAllAssetManagers(String rootPath);

    /**
     * Retrieves a list of all asset managers from the root path
     *
     * @param resolver
     * @param rootPath
     * @return
     */
    List<AssetManagerModel> getAllAssetManagers(ResourceResolver resolver, String rootPath);

    /**
     * Retrieves a list of the asset managers from the root path with the
     * matching tag
     *
     * @param resolver
     * @param rootPath
     * @param tagId
     * @return
     */
    AssetManagerModel getAssetManagerWithTagId(ResourceResolver resolver, String rootPath, String tagId);

    SearchResultsItems searchAssetManagers(ResourceResolver resourceResolver, String path, String queryText, int offset, int maxItems);

    List<Page> getAssetManagersConfigPages(Page page);

    /**
     * Gets the tag id's of the funds which are related to this asset manager through the person.
     *
     * @param assetManagerReference
     * @return
     */
    Set<String> getFundsForAssetManager(Page page, String assetManagerReference);

    Set<AssetManagerModel> getAssetManagersForAssetClassesAndInvestmentTypes(Page page, Set<String> assetClasses, Set<String> investmentTypes);

    Set<AssetManagerModel> getAssetManagersForInvestmentTypes(Page page, Set<String> investmentTypes);

    Set<AssetManagerModel> getAssetManagersForAssetClasses(Page page, Set<String> assetClasses);

    Set<Tag> getAllAssetClassesTags(ResourceResolver resolver);

    Set<AssetManagerModel> getConfiguredAssetManagers(ResourceResolver resolver, List<Resource> assetManagers);

    /**
     * Get grid available asset managers.
     * @param rootPath
     * @return
     */
    List<AssetManagerModel> getGridAssetManagers(String rootPath);
}
