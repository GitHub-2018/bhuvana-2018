package com.jhi.aem.website.v1.core.service.dashboard;

import java.math.BigDecimal;
import java.util.List;

public class Fund {

    public static final Fund EMPTY = new Fund();

    private List<String> assetManagers;
    private List<KeyDocument> keyDocuments;
    private String link;
    private String tickerId;
    private String fundCode;
    private String displayName;
    private String amountInvestedFormatted;
    private String shareClass;
    private String classShareLetter;
    private BigDecimal amountInvested;
    private List<Report> reports;
    private String assetManagerName;

    public Fund() {
    }

    public List<String> getAssetManagers() {
        return assetManagers;
    }

    public List<KeyDocument> getKeyDocuments() {
        return keyDocuments;
    }

    public void setAssetManagers(List<String> assetManagers) {
        this.assetManagers = assetManagers;
    }

    public void setKeyDocuments(List<KeyDocument> keyDocuments) {
        this.keyDocuments = keyDocuments;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLink() {
        return this.link;
    }

    public String getTickerId() {
        return this.tickerId;
    }

    public void setTickerId(String tickerId) {
        this.tickerId = tickerId;
    }

    public String getFundCode() {
        return fundCode;
    }

    public void setFundCode(String fundCode) {
        this.fundCode = fundCode;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getClassShareLetter() {
        return classShareLetter;
    }

    public void setClassShareLetter(String classShareLetter) {
        this.classShareLetter = classShareLetter;
    }

    public void setAmountInvested(BigDecimal amountInvested) {
        this.amountInvested = amountInvested;
    }

    public String getAmountInvested() {
        return this.amountInvested.toPlainString();
    }

    public String getAmountInvestedFormatted() {
        return amountInvestedFormatted;
    }

    public void setAmountInvestedFormatted(String amountInvestedFormatted) {
        this.amountInvestedFormatted = amountInvestedFormatted;
    }

    public String getShareClass() {
        return shareClass;
    }

    public void setShareClass(String shareClass) {
        this.shareClass = shareClass;
    }

    public void setReports(List<Report> reports) {
        this.reports = reports;
    }

    public List<Report> getReports() {
        return reports;
    }

    public void setAssetManagerName(String assetManagerName) {
        this.assetManagerName = assetManagerName;
    }

    public String getAssetManagerName() {
        return assetManagerName;
    }
}
