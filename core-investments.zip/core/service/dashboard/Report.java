package com.jhi.aem.website.v1.core.service.dashboard;

import java.util.Calendar;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.utils.DateUtil;

public class Report {

    private static final Logger LOG = LoggerFactory.getLogger(Report.class);
    private static final String ACTIVE_CLASS = "active";

    private Boolean active;

    private String name;

    private Calendar date;

    private String actionName;

    private String actionUrl;

    public Report(Boolean active, String name, Calendar date, String actionName, String actionUrl) {
        super();
        this.active = active;
        this.name = name;
        this.date = date;
        this.actionName = "Download " +actionName;
        this.actionUrl = actionUrl;
    }

    public boolean getActive() {
        return Boolean.TRUE.equals(active);
    }

    public String getActiveClass() {
        if (getActive()) {
            return ACTIVE_CLASS;
        }

        return StringUtils.EMPTY;
    }

    public String getName() {
        return name;
    }

    public Calendar getDate() {
        return Optional.ofNullable(date)
                .orElse(Calendar.getInstance());
    }

    public String getDateFormatted() {
        return DateUtil.getFormattedUsDate(date, null);
    }

    public String getActionName() {
        return actionName;
    }

    public String getActionUrl() {
        return actionUrl;
    }


}
