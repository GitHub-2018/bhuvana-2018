package com.jhi.aem.website.v1.core.service.dashboard;

import java.util.Calendar;
import java.util.List;

import com.jhi.aem.website.v1.core.models.user.AddressModel;
import com.jhi.aem.website.v1.core.utils.DateUtil;

public class Order {

	private String code;

	private AddressModel address;

	private Calendar orderedDate;

	private Calendar shippedDate;

	private List<OrderItem> items;

	public Order(String code, AddressModel address, Calendar orderedDate, Calendar shippedDate, List<OrderItem> items) {
		super();
		this.code = code;
		this.address = address;
		this.orderedDate = orderedDate;
		this.shippedDate = shippedDate;
		this.items = items;
	}

	public String getCode() {
		return code;
	}

	public AddressModel getAddress() {
		return address;
	}

	public Calendar getOrderedDate() {
		return orderedDate;
	}

	public String getOrderedDateFormatted() {
		return DateUtil.getFormattedFullDate(orderedDate, null);
	}

	public Calendar getShippedDate() {
		return shippedDate;
	}

	public String getShippedDateFormatted() {
		return DateUtil.getFormattedFullDate(shippedDate, null);
	}

	public List<OrderItem> getItems() {
		return items;
	}

	public String getReorderUrl() {
		return "#";
	}
}
