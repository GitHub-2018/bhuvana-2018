package com.jhi.aem.website.v1.core.service.dashboard;

import java.util.List;
import java.util.Optional;

public class Dashboard {

    private List<Fund> funds;

    public Dashboard() {
    }

    public Dashboard(List<Fund> funds) {
        super();
        this.funds = funds;
    }

    public Fund getFirstFund() {
        return Optional.ofNullable(funds)
                .filter(f -> !f.isEmpty())
                .map(f -> f.get(0))
                .orElse(Fund.EMPTY);
    }

    public List<Fund> getFunds() {
        return funds;
    }
}
