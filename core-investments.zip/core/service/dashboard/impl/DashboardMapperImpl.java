package com.jhi.aem.website.v1.core.service.dashboard.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.resources.ResourceDetailModel;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.models.user.DownloadedReport;
import com.jhi.aem.website.v1.core.models.user.FundModel;
import com.jhi.aem.website.v1.core.service.auth.external.IsamGroups;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardMapper;
import com.jhi.aem.website.v1.core.service.dashboard.Fund;
import com.jhi.aem.website.v1.core.service.dashboard.KeyDocument;
import com.jhi.aem.website.v1.core.service.dashboard.Report;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListMapper;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDto;
import com.jhi.aem.website.v1.core.service.resources.DocumentsUtil;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.utils.UserUtil;

@Component(
		name="Dashboard Mapper Implementation",
		service=DashboardMapper.class,
		immediate=true)
public class DashboardMapperImpl implements DashboardMapper {

    private static final Logger LOG = LoggerFactory.getLogger(DashboardMapperImpl.class);

    
    private UserProfileService userProfileService;
    @Reference
    public void bindUserProfileService(UserProfileService userProfileService) {
    	this.userProfileService=userProfileService;
    }
    public void unbindUserProfileService(UserProfileService userProfileService) {
    	this.userProfileService=userProfileService;
    }
    
    private FundListMapper mapper;
    @Reference
    public void bindFundListMapper(FundListMapper mapper) {
    	this.mapper=mapper;
    }
    public void unbindFundListMapper(FundListMapper mapper) {
    	this.mapper=mapper;
    }

    @Override
    public Fund mapFund(FundModel fundModel, Page page) {
        ShareClassDto shareClassDto = getOptionalTag(fundModel, page)
                .map(tag -> mapper.mapShareClass(tag, page))
                .orElse(ShareClassDto.EMPTY);
        if (shareClassDto.equals(ShareClassDto.EMPTY)) {
            return Fund.EMPTY;
        }

        Fund dto = new Fund();
        dto.setAmountInvestedFormatted(fundModel.getAmountInvestedFormatted());
        dto.setAmountInvested(fundModel.getAmountInvested());
        dto.setShareClass(fundModel.getShareClass());

        List<ResourceDetailModel> fundKeyDocuments = new ArrayList<>();

        dto.setTickerId(shareClassDto.getTickerId());
        dto.setDisplayName(shareClassDto.getFundTitle());
        dto.setClassShareLetter(shareClassDto.getShareClassLetter());
        dto.setFundCode(shareClassDto.getFundCode());
        dto.setLink(shareClassDto.getLink());
        dto.setAssetManagers(shareClassDto.getAssetManagers());
        dto.setAssetManagerName(shareClassDto.getAssetManagerName());

        boolean allowAllDocuments = true;
        final ResourceResolver resolver = page.getContentResource().getResourceResolver();
        Authorizable authorizable = UserUtil.getCurrentAuthorizable(resolver);
        if (authorizable != null) {
            try {
                Iterator<Group> declaredMemberGroupsIter = authorizable.declaredMemberOf();
                while (declaredMemberGroupsIter.hasNext()) {
                    Group group = declaredMemberGroupsIter.next();
                    if (StringUtils.equals(group.getID(), IsamGroups.AEM_INVESTOR_GROUP)) {
                        allowAllDocuments = false;
                        break;
                    }
                }
            } catch (RepositoryException e) {
            	LOG.error("Problem while checking user groups", e);
            }
        }

        for (String documentType : shareClassDto.getDocuments().keySet()) {
            if (allowAllDocuments
                    || !(StringUtils.equals(documentType, DocumentsUtil.ATTRIBUTION_REPORT)
                    || StringUtils.equals(documentType, DocumentsUtil.BROKER_FACT_SHEET))) {
                fundKeyDocuments.add(shareClassDto.getDocuments().get(documentType));
            }
        }

        List<KeyDocument> keyDocumentList = getKeyDocuments(fundKeyDocuments);
        dto.setKeyDocuments(keyDocumentList);


        List<String> recentDownloadPaths = getRecentDownloadPaths(resolver);
        List<ResourceDocumentModel> documents = getResourceDocuments(fundKeyDocuments, resolver);

        dto.setReports(getReports(documents, recentDownloadPaths));

        return dto;
    }

    private List<ResourceDocumentModel> getResourceDocuments(List<ResourceDetailModel> fundKeyDocuments, ResourceResolver resolver) {
        return fundKeyDocuments.stream()
                .filter(model -> DocumentsUtil.REPORT_TYPES.contains(model.getDocumentType()))
                .map(model -> getResourceDocumentModel(resolver, model))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    private ResourceDocumentModel getResourceDocumentModel(ResourceResolver resolver, ResourceDetailModel model) {
        return Optional.ofNullable(resolver.getResource(model.getDocumentPath()))
                .map(resource -> resource.adaptTo(ResourceDocumentModel.class))
                .orElse(null);
    }

    private List<String> getRecentDownloadPaths(ResourceResolver resolver) {
        return userProfileService.getDownloadedReports(resolver)
                .stream()
                .map(DownloadedReport::getPath)
                .collect(Collectors.toList());
    }

    private Optional<Tag> getOptionalTag(FundModel fundModel, Page page) {
        return Optional.ofNullable(page.getContentResource())
                .map(Resource::getResourceResolver)
                .map(resolver -> resolver.adaptTo(TagManager.class))
                .map(tagManager -> tagManager.resolve(fundModel.getTagId()));
    }

    private List<KeyDocument> getKeyDocuments(List<ResourceDetailModel> fundKeyDocuments) {
        return fundKeyDocuments
                .stream()
                .filter(doc -> DocumentsUtil.DASHBOARD_KEY_DOCUMENTS.contains(doc.getDocumentType()))
                .map(doc -> new KeyDocument(doc.getDocumentType(), doc.getPageLink()))
                .sorted(new Comparator<KeyDocument>() {
					@Override
					public int compare(KeyDocument o1, KeyDocument o2) {			
						return Integer.compare(DocumentsUtil.DASHBOARD_KEY_DOCUMENTS.indexOf(o1.getName()), DocumentsUtil.DASHBOARD_KEY_DOCUMENTS.indexOf(o2.getName()));
					}   	
                })
                .collect(Collectors.toList());
    }

    private List<Report> getReports(List<ResourceDocumentModel> documents, List<String> recentDownloadPaths) {
        return documents
                .stream()
                .map(doc -> new Report(!recentDownloadPaths.contains(doc.getAssetPath()), doc.getTitle(),
                        Optional.ofNullable(doc.getRevisionDate()).orElse(doc.getLastUpdated()),
                        doc.getFileType().toUpperCase(), doc.getAssetPath()))
                .sorted(Comparator.comparing(Report::getDate))
                .collect(Collectors.toList());
    }
}
