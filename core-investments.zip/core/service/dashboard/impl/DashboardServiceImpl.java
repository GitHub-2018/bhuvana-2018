package com.jhi.aem.website.v1.core.service.dashboard.impl;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ArrayUtils;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.user.FundModel;
import com.jhi.aem.website.v1.core.models.user.InvestmentPortfolioModel;
import com.jhi.aem.website.v1.core.service.dashboard.Dashboard;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardMapper;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardService;
import com.jhi.aem.website.v1.core.service.dashboard.Fund;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;


@Component(
		immediate = true,
		name =" Dashboard Service Implementation",
		service =DashboardService.class,
		configurationPolicy = ConfigurationPolicy.OPTIONAL,
		configurationPid="com.jhi.aem.website.v1.core.service.dashboard.impl.DashboardServiceImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website dashboard service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

@Designate(ocd=DashboardServiceImpl.Config.class)
public class DashboardServiceImpl implements DashboardService {

    private static final Logger LOG = LoggerFactory.getLogger(DashboardServiceImpl.class);

    private static final String DEFAULT_RELATED_VIEWPOINTS_MAX_AGE = "3M";
    
    @ObjectClassDefinition(name="Dashboard Service Configuation for JHI website", description="Configuration properties for Dashboard Service implementation")
    public @interface Config{
    	@AttributeDefinition(name = "Related viewpoints max age",
                description = "Maximum age of related viewpoints to show in the dashboard. Supports the bugzilla "
                		+ "syntax 1s 2m 3h 4d 5w 6M 7y (one second, two minutes, three hours, four days, five "
                		+ "weeks, 6 months, 7 years). It does not take leap years into consideration and all months "
                		+ "are 30 days.")
        String relatedViewpointsMaxAge() default DEFAULT_RELATED_VIEWPOINTS_MAX_AGE;
    	
    	@AttributeDefinition(name = "Static related viewpoint category paths",
                description = "Paths of static categories to include in the related viewpoints for a user")
        String[] staticViewpointCategories();
    }
   
   
	private String relatedViewpointsMaxAge;

    
	private String[] staticViewpointCategories;

    
    private UserProfileService service;
    @Reference
    public void bindUserProfileService(UserProfileService service) {
    	this.service=service;
    }
    public void unbindUserProfileService(UserProfileService service) {
    	this.service=service;
    }

    
    private DashboardMapper mapper;
    @Reference
    public void bindDashboardMapper(DashboardMapper mapper) {
    	this.mapper=mapper;
    }
    public void unbindDashboardMapper(DashboardMapper mapper) {
    	this.mapper=mapper;
    }
    

	@Activate
    public void activate(final Config config) throws IllegalAccessException, LoginException, IOException {
    	doConfigure(config);
        LOG.info("Activated Service");
    }

	@Modified
    public void modified(final Config config) throws IllegalAccessException, LoginException, IOException {
		doConfigure(config);
        LOG.info("Modified Service");
    }

    private void doConfigure(final Config config) throws LoginException, IllegalAccessException, IOException {
    	relatedViewpointsMaxAge = config.relatedViewpointsMaxAge();
    	staticViewpointCategories = PropertiesUtil.toStringArray(config.staticViewpointCategories(),
    			ArrayUtils.EMPTY_STRING_ARRAY);
    }

    @Override
    public Dashboard getDashboard(Page page) {
        return new Dashboard(getDashboardFunds(page));
    }

    @Override
    public List<Fund> getDashboardFunds(Page page) {
        return service.getFunds(page.getContentResource().getResourceResolver())
                .stream()
                .map(fundModel -> mapper.mapFund(fundModel, page))
                .filter(fund -> !fund.equals(Fund.EMPTY))
                .collect(Collectors.toList());
    }

    @Override
    public boolean hasFund(final ResourceResolver resolver, final String shareClass) {
        LOG.debug("shareClass: {}", shareClass);
        return service.getInvestmentPortfolio(resolver)
                .getInvestedFunds()
                .stream()
                .anyMatch(fundModel -> fundModel.getShareClass().equalsIgnoreCase(shareClass));
    }

    @Override
    public boolean addRemoveDashboardFunds(ResourceResolver resolver, List<FundModel> list) {
        if (list.isEmpty()) {
            LOG.debug("list is empty");
            return true;
        }
        if (list.size() == 1) {
            LOG.debug("only one dashboard fund. Toggle it.");
            return toggleDashboardFund(resolver, list.get(0));
        } else if (service.getFunds(resolver).containsAll(list)) {
            LOG.debug("All funds passed are in dashboard. Removing them all.");
            return list.stream()
                    .allMatch(fund -> service.deleteFund(resolver, fund.getShareClass()));
        }
        LOG.debug("Not All funds passed are in dashboard. Adding them all.");
        return addFunds(resolver, list);
    }

    @Override
    public boolean addFunds(ResourceResolver resolver, List<FundModel> funds) {
        LOG.debug("add funds tags found: {}", funds.size());
        List<FundModel> fundModels = service.getFunds(resolver);

        return funds.stream()
                .allMatch(fund -> {
                    if (fundModels.contains(fund)) {
                        return service.updateFund(resolver, "fund-" + fund.getShareClass(), fund);
                    }
                    return service.addFund(resolver, fund);
                });
    }

    @Override
    public boolean editFunds(ResourceResolver resolver, List<FundModel> fundModels) {
        LOG.debug("edit funds tags found: {}", fundModels.size());
        return fundModels.isEmpty() || service.updateInvestmentPortfolio(resolver, new InvestmentPortfolioModel(fundModels));
    }

    private boolean toggleDashboardFund(final ResourceResolver resolver, final FundModel fund) {
        LOG.debug("One tag found : {}", fund.getTagId());
        if (hasFund(resolver, fund.getShareClass())) {
            LOG.debug("Removing fund: {}", fund.getTagId());
            return service.deleteFund(resolver, fund.getShareClass());
        }
        LOG.debug("Trying to add fund: {}", fund.getTagId());
        return service.addFund(resolver, fund);

    }

	@Override
	public String getRelatedViewpointsMaxAge() {
		return relatedViewpointsMaxAge;
	}

	@Override
	public String[] getStaticViewpointCategories() {
		return staticViewpointCategories;
	}

}
