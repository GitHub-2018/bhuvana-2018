package com.jhi.aem.website.v1.core.service.dashboard.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.jcr.query.Query;

import org.apache.commons.collections4.IteratorUtils;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardContentService;

@Component(
		name="Dashboard Content Service Implementation",
		immediate=true,
		service=DashboardContentService.class)

public class DashboardContentServiceImpl implements DashboardContentService {

    private static final Logger LOG = LoggerFactory.getLogger(DashboardContentServiceImpl.class);
    private final static String QUERY = "SELECT * FROM [nt:unstructured] AS s WHERE ISDESCENDANTNODE([%s]) and s.[sling:resourceType] = 'jhi-website-v1/components/structure/registration/registrationStart'";

    @Override
    public List<String> getUfpRoles(Page page) {

        LOG.debug("Page path: {}", page.getPath());
        final ResourceResolver resolver = page.getContentResource().getResourceResolver();

        String query = String.format(QUERY, page.getAbsoluteParent(2).getPath());
        LOG.debug("Query: {}", query);

        return IteratorUtils.toList(resolver.findResources(query, Query.JCR_SQL2))
                .stream()
                .map(Resource::getValueMap)
                .map(valueMap -> valueMap.get("ufpRoles", String[].class))
                .filter(Objects::nonNull)
                .map(Arrays::asList)
                .findFirst()
                .orElse(Collections.emptyList());
    }
}
