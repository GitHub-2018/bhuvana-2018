package com.jhi.aem.website.v1.core.service.dashboard;

public class OrderItem {

	private String name;

	private String reference;

	private int quantity;

	public OrderItem(String name, String reference, int quantity) {
		super();
		this.name = name;
		this.reference = reference;
		this.quantity = quantity;
	}

	public String getName() {
		return name;
	}

	public String getReference() {
		return reference;
	}

	public int getQuantity() {
		return quantity;
	}

	public String getThumbnailUrl() {
		return "https://placeholdit.imgix.net/~text?txtsize=12&txt=54%C3%9773&w=54&h=73";
	}
}
