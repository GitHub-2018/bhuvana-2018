package com.jhi.aem.website.v1.core.service.dashboard;

public class Document {

}
