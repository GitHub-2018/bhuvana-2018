package com.jhi.aem.website.v1.core.service.dashboard;

public class KeyDocument {

	private String name;

	private String url;

	public KeyDocument(String name, String url) {
		super();
		this.name = name;
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public String getUrl() {
		return url;
	}
}
