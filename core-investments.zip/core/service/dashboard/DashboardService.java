package com.jhi.aem.website.v1.core.service.dashboard;

import java.util.List;

import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.user.FundModel;

public interface DashboardService {

    Dashboard getDashboard(Page page);

    List<Fund> getDashboardFunds(Page page);

    boolean hasFund(ResourceResolver resolver, String shareClass);

    boolean addRemoveDashboardFunds(ResourceResolver resolver, List<FundModel> list);

    boolean editFunds(ResourceResolver resolver, List<FundModel> fundModels);

    boolean addFunds(ResourceResolver resolver, List<FundModel> funds);

	String[] getStaticViewpointCategories();

	String getRelatedViewpointsMaxAge();
}
