package com.jhi.aem.website.v1.core.service.dashboard;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.user.FundModel;

public interface DashboardMapper {
    Fund mapFund(FundModel fundModel, Page page);
}
