package com.jhi.aem.website.v1.core.service.dashboard;

import java.util.List;

import com.day.cq.wcm.api.Page;

public interface DashboardContentService {

    List<String> getUfpRoles(Page page);
}
