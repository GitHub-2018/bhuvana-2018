package com.jhi.aem.website.v1.core.service.auth;

public interface Messages {
    public static final String ISAM_2313_ERROR = "ISAM-2313";
    public static final String ISAM_USER_INACTIVE_ERROR = "ISAM_USER_INACTIVE_ERROR";
    public static final String ISAM_USER_INVALID_ERROR = "ISAM_USER_INVALID_ERROR";
    public static final String ISAM_USER_REJECTED_ERROR = "ISAM_USER_REJECTED_ERROR";
    public static final String ISAM_TECHNICAL_ERROR = "techErrorSubtitle";
}
