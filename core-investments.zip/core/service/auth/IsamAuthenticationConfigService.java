package com.jhi.aem.website.v1.core.service.auth;

import java.util.List;
import java.util.Map;

import com.jhi.aem.website.v1.core.service.email.impl.EmailRegexCollection;

public interface IsamAuthenticationConfigService {

	EmailRegexCollection getValidEmployeeEmailDomainsRegex();

	int getEmailValidationTokenValidityHours();

	String getInitialRegistrationMarketoCampaignName();

	String getForgotPasswordMarketoCampaignName();

	String getChangePasswordMarketoCampaignName();

	Map<String, List<String>> getRrdConstantToFirmIdMappings();

	int getUnverifiedProLapsesAfterHours();

	EmailRegexCollection getInvalidRegistrationEmailRegexCollection();

	String getTempUserResourceLocation();

}
