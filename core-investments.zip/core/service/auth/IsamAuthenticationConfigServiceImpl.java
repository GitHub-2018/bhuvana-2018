package com.jhi.aem.website.v1.core.service.auth;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.apache.sling.commons.scheduler.Job;
import org.apache.sling.commons.scheduler.JobContext;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.email.impl.EmailRegexCollection;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Component(
		name="Isam Authentication Config Service Implementation",
		service=IsamAuthenticationConfigService.class,
		immediate=true,
		configurationPolicy = ConfigurationPolicy.REQUIRE,
		configurationPid = "com.jhi.aem.website.v1.core.service.auth.IsamAuthenticationConfigServiceImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website ISAM Authentication Config Service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

@Designate(ocd=IsamAuthenticationConfigServiceImpl.Config.class)
public class IsamAuthenticationConfigServiceImpl implements IsamAuthenticationConfigService {
    private static final Logger LOG = LoggerFactory.getLogger(IsamAuthenticationConfigServiceImpl.class);
    private static final String EXCEL_EXTERNAL_FIRM_ID_HEADING = "FIRM_EXT_ID";
    private static final String FIRM_ID_MAPPINGS_REFRESH_JOB_NAME = "Firm ID mappings Excel Job";
    private static final int FIRM_IDS_MAPPING_JOB_REFRESH_PERIOD = 60 * 5;

    @ObjectClassDefinition(name = "IsamAuthenticationConfigService for JHI Website", description = "Configurations for IsamAuthenticationConfigServiceImpl Component")

    public @interface Config{
    	final int DEFAULT_EMAIL_VALIDATION_TOKEN_VALIDITY_HOURS = 24;
    	@AttributeDefinition(name = "Email validation link validity period (hours)",
                description = "The amount of time in hours for which an email validation token (link) is valid")
    	int emailValidationTokenValidity() default DEFAULT_EMAIL_VALIDATION_TOKEN_VALIDITY_HOURS;
    	
    	@AttributeDefinition(name = "Employee email domains",
                description = "A set of regular expressions which identify employees")
        String[] employeeEmailDomains();
    	
    	@AttributeDefinition (name = "Initial Registration Marketo campaign name",
                description = "The campaign name in Marketo for the initial registration email")
        String initialRegistrationMarketoCampaignName();
    	
    	@AttributeDefinition(name = "Forgotten password Marketo campaign name",
                description = "The campaign name in Marketo for the forgotten password email")
        String forgotPasswordMarketoCampaignName();
    	
    	@AttributeDefinition(name = "Change password Marketo campaign name",
                description = "The campaign name in Marketo for the change password email")
        String changePasswordMarketoCampaignName();
    	
    	final int DEFAULT_UNVERIFIED_PRO_LAPSES_HOURS = 72;
        @AttributeDefinition(name = "Unverified users lapse after this time",
                description = "The number or hours after which an unverified user who hasn't been confirmed "
                        + "in the backend Salesforce system lapses and can no longer login after")
        int unverifiedProLapsesAfterHours() default DEFAULT_UNVERIFIED_PRO_LAPSES_HOURS;
        
        @AttributeDefinition(name = "Restricted firms mapping Excel",
                description = "Location of the restricted firms mapping Excel spreadsheet which contains sheets labelled with RRD keys for each of the firms and firm id's from datahub as FIRM_EXT_ID as a column in the sheet")
        String restrictedFirmMappingsExcel();
   
        @AttributeDefinition(name = "Invalid registration emails",
                description = "Invalid registration email regular expressions which will be automatically excluded from registration")
        String[] invalidRegistrationEmailRegex();
        
        @AttributeDefinition(name = "Temporary User Resource Location",
                description = "A location to store temporary user data prior to a user being imported into AEM, this is used in the forgot password flow")
        String tempUserResourceLocation();
    }
    
    private int emailValidationTokenValidity;
    private String[] employeeEmailDomains;
    private EmailRegexCollection validEmployeeEmailDomainsRegex;  
    private String initialRegistrationMarketoCampaignName;
    private String forgotPasswordMarketoCampaignName;
    private String changePasswordMarketoCampaignName;
    private int unverifiedProLapsesAfterHours;
    private String restrictedFirmMappingsExcel;
    private String[] invalidRegistrationEmailRegex;
    private String tempUserResourceLocation;
    private EmailRegexCollection invalidRegistrationEmailRegexCollection;

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory = resolverFactory;
    }
    
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory = resolverFactory;
    } 
    
    
    private Scheduler scheduler;
    @Reference
    public void bindScheduler(final Scheduler scheduler) {
    	this.scheduler = scheduler;
    }
    public void unbindScheduler(final Scheduler scheduler) {
    	this.scheduler = scheduler;
    }
    
    private Map<String, List<String>> rrdConstantToFirmIdMappings;

    private class FirmIdsMappingRefreshJob implements Job {

        private Calendar restrictedFirmsLastModified;

        @Override
        public void execute(JobContext context) {
            // Read the Excel to get all of the firm id mappings
            ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resolverFactory);
            if (resourceResolver == null) {
                LOG.error("Could not get a resource resolver");
                throw new IllegalStateException("Could not get a resource resolver");
            }

            try {
                LOG.debug("Getting restricted firms mapping Excel {}", restrictedFirmMappingsExcel);
                Resource restrictedFirmMappingsExcelResource =
                        resourceResolver.getResource(restrictedFirmMappingsExcel);

                if (restrictedFirmMappingsExcelResource == null
                        || ResourceUtil.isNonExistingResource(restrictedFirmMappingsExcelResource)) {
                    LOG.error("No resource exists at: {}", restrictedFirmMappingsExcel);
                    throw new IllegalArgumentException("No resource exists at: " + restrictedFirmMappingsExcel);
                }

                // Check the last modified time
                Calendar restrictedFirmsLastModifiedLatest =
                        (Calendar) restrictedFirmMappingsExcelResource.getChild(JcrConstants.JCR_CONTENT)
                                .getValueMap().get(JcrConstants.JCR_LASTMODIFIED);
                boolean doUpdate = true;

                if (restrictedFirmsLastModifiedLatest != null) {
                    if (restrictedFirmsLastModified == null) {
                        LOG.debug("No previous last modified, updating from Excel {}",
                                restrictedFirmMappingsExcel);
                    } else if (!restrictedFirmsLastModifiedLatest.equals(restrictedFirmsLastModified)) {
                        LOG.debug("Restricted firms Excel list has been modified at {}",
                                restrictedFirmMappingsExcel);
                    } else {
                        LOG.debug("Not updating, last modified has not changed for {}",
                                restrictedFirmMappingsExcel);
                        doUpdate = false;
                    }
                } else {
                    LOG.debug("Restricted firms Excel last modified is null for {}, "
                            + "updating assuming it has changed", restrictedFirmMappingsExcel);
                }

                // No update?
                if (!doUpdate) {
                    return;
                }

                // If this is a rendition then get the asset
                Asset asset = null;
                Rendition rendition = restrictedFirmMappingsExcelResource.adaptTo(Rendition.class);
                if (rendition != null) {
                    asset = rendition.getAsset();
                } else {
                    // Lastly attempt to resolve to an asset
                    asset = restrictedFirmMappingsExcelResource.adaptTo(Asset.class);
                }

                if (asset == null) {
                    LOG.error("The resource at '{}' is not a DAM asset", restrictedFirmMappingsExcel);
                    throw new IllegalArgumentException("The resource at " + restrictedFirmMappingsExcel + " is not a DAM asset");
                }

                LOG.debug("Opening restricted firms Excel workbook at '{}'", restrictedFirmMappingsExcel);
                try (InputStream assetStream = asset.getOriginal().getStream()) {
                    XSSFWorkbook wb = new XSSFWorkbook(assetStream);
                    int rrdMappingsLength = wb.getNumberOfSheets();

                    // Read each sheet in the spreadsheet
                    for (int i = 0; i < rrdMappingsLength; i++) {
                        XSSFSheet rrdMappingSheet = wb.getSheetAt(i);
                        String rrdConstant = wb.getSheetName(i);
                        LOG.debug("Processing sheet {}", rrdConstant);
                        int externalFirmIdsColumn = -1;

                        // Process the first heading row to find the firm id's column
                        XSSFRow firstRow = rrdMappingSheet.getRow(rrdMappingSheet.getFirstRowNum());
                        boolean readCells = false;
                        for (int j = 0; !readCells; j++) {
                            XSSFCell cell = firstRow.getCell(j);
                            String cellValue = cell.getStringCellValue();

                            if (cellValue == null) {
                                readCells = true;
                            }

                            if (StringUtils.equals(EXCEL_EXTERNAL_FIRM_ID_HEADING, cellValue)) {
                                externalFirmIdsColumn = j;
                                readCells = true;
                            }
                        }

                        if (externalFirmIdsColumn == -1) {
                            LOG.warn("Could not read {} heading from Excel", EXCEL_EXTERNAL_FIRM_ID_HEADING);
                            throw new IllegalArgumentException("Could not read " + EXCEL_EXTERNAL_FIRM_ID_HEADING + " heading from Excel");
                        }

                        // Get all of the external firm id's from the spreadsheet
                        List<String> externalFirmIds = new ArrayList<>();
                        for (int k = 0; k < rrdMappingSheet.getLastRowNum(); k++) {
                            XSSFRow row = rrdMappingSheet.getRow(k);
                            XSSFCell cell = row.getCell(externalFirmIdsColumn);

                            if (cell != null) {
                                String cellValue = cell.getRawValue();

                                if (cellValue != null) {
                                    externalFirmIds.add(cellValue);
                                }
                            }
                        }

                        rrdConstantToFirmIdMappings.put(rrdConstant, externalFirmIds);
                        LOG.debug("RRD constant '{}' = firm id's [{}]", rrdConstant, externalFirmIds);
                    }
                    
                    wb.close();
                    
                }

                // Set the last modified time after update
                restrictedFirmsLastModified = restrictedFirmsLastModifiedLatest;

                LOG.debug("Finished reading restricted firms Excel, retrieved mappings: {}",
                        rrdConstantToFirmIdMappings);
            } catch (Exception e) {
                LOG.error("An error was thrown attempting to read restricted firms Excel {}",
                        restrictedFirmMappingsExcel, e);
            } finally {
                resourceResolver.close();
            }
        }
    }

    @Activate
    @Modified
    protected void activate(final Config config) throws IllegalAccessException, LoginException, IOException {
        doConfigure(config);
        LOG.info("Activated/Modified ISAM Authentication Config Service");
    }

   

    private void doConfigure(Config config) throws LoginException, IllegalAccessException, IOException {
        emailValidationTokenValidity = config.emailValidationTokenValidity();

        employeeEmailDomains = PropertiesUtil.toStringArray(config.employeeEmailDomains(),
                ArrayUtils.EMPTY_STRING_ARRAY);
        invalidRegistrationEmailRegex = PropertiesUtil.toStringArray(config.invalidRegistrationEmailRegex(),
                ArrayUtils.EMPTY_STRING_ARRAY);
        unverifiedProLapsesAfterHours = config.unverifiedProLapsesAfterHours();
        initialRegistrationMarketoCampaignName =
                getNonNullPropertyString(config.initialRegistrationMarketoCampaignName());
        forgotPasswordMarketoCampaignName =
                getNonNullPropertyString(config.forgotPasswordMarketoCampaignName());
        changePasswordMarketoCampaignName =
                getNonNullPropertyString(config.changePasswordMarketoCampaignName());
        tempUserResourceLocation =
                getNonNullPropertyString(config.tempUserResourceLocation());

        // Create employee regex's from the array of valid domains
        if (employeeEmailDomains != null) {
            validEmployeeEmailDomainsRegex = new EmailRegexCollection(
                    Arrays.asList(employeeEmailDomains));
            LOG.debug("Set valid employee email registrations to: {}", Arrays.asList(employeeEmailDomains));
        } else {
            LOG.warn("No valid employee email domains have been provided");
        }

        if (invalidRegistrationEmailRegex != null) {
            invalidRegistrationEmailRegexCollection = new EmailRegexCollection(
                    Arrays.asList(invalidRegistrationEmailRegex));
            LOG.debug("Set invalid email registrations to: {}", Arrays.asList(invalidRegistrationEmailRegex));
        } else {
            LOG.warn("No invalid registration emails set");
        }

        restrictedFirmMappingsExcel = getNonNullPropertyString(config.restrictedFirmMappingsExcel());
        rrdConstantToFirmIdMappings = new HashMap<>();

        // Set up the job to refresh the mappings
        FirmIdsMappingRefreshJob firmIdMappingsRefreshJob = new FirmIdsMappingRefreshJob();
        ScheduleOptions options = scheduler.AT(new Date(), -1, FIRM_IDS_MAPPING_JOB_REFRESH_PERIOD)
                .canRunConcurrently(false)
                .name(FIRM_ID_MAPPINGS_REFRESH_JOB_NAME);
        scheduler.schedule(firmIdMappingsRefreshJob, options);
        LOG.debug("Scheduled job '" + FIRM_ID_MAPPINGS_REFRESH_JOB_NAME + "'");

        // Run it first time
        try {
            firmIdMappingsRefreshJob.execute(null);
        } catch (Exception e) {
            LOG.warn("Firm id mappings Excel refresh job errored on first run", e);
        }
    }

    @Deactivate
    public void deactivate() {
        scheduler.unschedule(FIRM_ID_MAPPINGS_REFRESH_JOB_NAME);
        LOG.debug("Deactivated job '" + FIRM_ID_MAPPINGS_REFRESH_JOB_NAME + "'");
    }

    private String getNonNullPropertyString(String property) {
        String propValue =
                PropertiesUtil.toString(property, null);

        if (StringUtils.isBlank(propValue)) {
            throw new RuntimeException("No configuration for property " + property);
        }

        return propValue;
    }

    @Override
    public int getEmailValidationTokenValidityHours() {
        return emailValidationTokenValidity;
    }

    @Override
    public EmailRegexCollection getValidEmployeeEmailDomainsRegex() {
        return validEmployeeEmailDomainsRegex;
    }

    @Override
    public String getInitialRegistrationMarketoCampaignName() {
        return initialRegistrationMarketoCampaignName;
    }

    @Override
    public String getForgotPasswordMarketoCampaignName() {
        return forgotPasswordMarketoCampaignName;
    }

    @Override
    public String getChangePasswordMarketoCampaignName() {
        return changePasswordMarketoCampaignName;
    }

    public String getRestrictedFirmMappingsExcel() {
        return restrictedFirmMappingsExcel;
    }

    @Override
    public Map<String, List<String>> getRrdConstantToFirmIdMappings() {
        return rrdConstantToFirmIdMappings;
    }

    @Override
    public int getUnverifiedProLapsesAfterHours() {
        return unverifiedProLapsesAfterHours;
    }

    @Override
    public EmailRegexCollection getInvalidRegistrationEmailRegexCollection() {
        return invalidRegistrationEmailRegexCollection;
    }

    @Override
    public String getTempUserResourceLocation() {
        return tempUserResourceLocation;
    }


}
