package com.jhi.aem.website.v1.core.service.auth.external;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Binary;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFactory;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.jackrabbit.oak.commons.DebugTimer;
import org.apache.jackrabbit.oak.commons.PathUtils;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalGroup;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentity;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityException;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityProvider;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityRef;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalUser;
import org.apache.jackrabbit.oak.spi.security.authentication.external.SyncContext;
import org.apache.jackrabbit.oak.spi.security.authentication.external.SyncException;
import org.apache.jackrabbit.oak.spi.security.authentication.external.SyncResult;
import org.apache.jackrabbit.oak.spi.security.authentication.external.basic.DefaultSyncContext;
import org.apache.jackrabbit.oak.spi.security.authentication.external.basic.DefaultSyncResultImpl;
import org.apache.jackrabbit.oak.spi.security.authentication.external.basic.DefaultSyncedIdentity;
import org.apache.jackrabbit.oak.spi.security.principal.PrincipalImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.user.ProfileModel;

/**
 * An implementation built on top of the {@link DefaultSyncContext} for ISAM registration
 * and login.
 */
public class IsamSyncContext implements SyncContext, IsamConstants {
	private static final Logger log = LoggerFactory.getLogger(IsamSyncContext.class);

	/**
	 * Name of the {@link ExternalIdentity#getExternalId()} property of a
	 * synchronized identity.
	 */
	public static final String REP_EXTERNAL_ID = "rep:externalId";

	/**
	 * Name of the property that stores the time when an identity was synced.
	 */
	public static final String REP_LAST_SYNCED = "rep:lastSynced";

	protected final ExternalIdentityProvider idp;

	protected final UserManager userManager;

	protected final ValueFactory valueFactory;

	protected boolean keepMissing;

	protected boolean forceUserSync;

	protected boolean forceGroupSync;

	// we use the same wall clock for the entire context
	protected final long now;

	protected final Value nowValue;

	private final String userPathPrefix;

	private final String groupPathPrefix;

	private final long expirationTimeMs;

	private boolean trustUserLoginToken;

	public IsamSyncContext(ExternalIdentityProvider idp, UserManager userManager, ValueFactory valueFactory,
			String userPathPrefix, String groupPathPrefix, long expirationTimeMs, boolean trustUserLoginToken) {
		this.idp = idp;
		this.userManager = userManager;
		this.valueFactory = valueFactory;
		this.userPathPrefix = userPathPrefix;
		this.groupPathPrefix = groupPathPrefix;
		this.expirationTimeMs = expirationTimeMs;
		this.trustUserLoginToken = trustUserLoginToken;

		// initialize 'now'
		final Calendar nowCal = Calendar.getInstance();
		this.nowValue = valueFactory.createValue(nowCal);
		this.now = nowCal.getTimeInMillis();
	}

	/**
	 * Creates a synced identity from the given authorizable.
	 * 
	 * @param auth
	 *            the authorizable
	 * @return the id
	 * @throws RepositoryException
	 *             if an error occurs
	 */
	public static DefaultSyncedIdentity createSyncedIdentity(Authorizable auth) throws RepositoryException {
		if (auth == null) {
			return null;
		}
		ExternalIdentityRef ref = getIdentityRef(auth);
		Value[] lmValues = auth.getProperty(REP_LAST_SYNCED);
		long lastModified = -1;
		if (lmValues != null && lmValues.length > 0) {
			lastModified = lmValues[0].getLong();
		}
		return new DefaultSyncedIdentity(auth.getID(), ref, auth.isGroup(), lastModified);
	}

	/**
	 * Retrieves the external identity ref from the authorizable
	 * 
	 * @param auth
	 *            the authorizable
	 * @return the ref
	 * @throws RepositoryException
	 *             if an error occurs
	 */

	public static ExternalIdentityRef getIdentityRef(Authorizable auth) throws RepositoryException {
		if (auth == null) {
			return null;
		}
		Value[] v = auth.getProperty(REP_EXTERNAL_ID);
		if (v == null || v.length == 0) {
			return null;
		}
		return ExternalIdentityRef.fromString(v[0].getString());
	}

	/**
	 * Robust relative path concatenation.
	 * 
	 * @param paths
	 *            relative paths
	 * @return the concatenated path
	 * @deprecated Since Oak 1.3.10. Please use
	 *             {@link PathUtils#concatRelativePaths(String...)} instead.
	 */
	public static String joinPaths(String... paths) {
		return PathUtils.concatRelativePaths(paths);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void close() {
		// nothing to do
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isKeepMissing() {
		return keepMissing;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	public SyncContext setKeepMissing(boolean keepMissing) {
		this.keepMissing = keepMissing;
		return this;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isForceUserSync() {
		return forceUserSync;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	public SyncContext setForceUserSync(boolean forceUserSync) {
		this.forceUserSync = forceUserSync;
		return this;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isForceGroupSync() {
		return forceGroupSync;
	}

	@Override

	public SyncContext setForceGroupSync(boolean forceGroupSync) {
		this.forceGroupSync = forceGroupSync;
		return this;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	public SyncResult sync(ExternalIdentity identity) throws SyncException {
		ExternalIdentityRef ref = identity.getExternalId();
		if (!isSameIDP(ref)) {
			// create result in accordance with sync(String) where status is
			// FOREIGN
			boolean isGroup = (identity instanceof ExternalGroup);
			return new DefaultSyncResultImpl(new DefaultSyncedIdentity(identity.getId(), ref, isGroup, -1),
					SyncResult.Status.FOREIGN);
		}
		try {
			DebugTimer timer = new DebugTimer();
			DefaultSyncResultImpl ret;
			boolean created = false;
			if (identity instanceof ExternalUser) {
				// Get the existing user - i.e. already imported or previously registered through AEM
				User user = getAuthorizable(identity, User.class);
				timer.mark("find");

				if (user == null) {
					// Create the user record in AEM if it doesn't exist
					user = createUser((ExternalUser) identity);
					timer.mark("create");
					created = true;
				} else {
					// If the user record exists in AEM then check it for validity if we are in regsitration
					try {
						checkUserRegistrationPhase((ExternalUser) identity, user);
					} catch (SyncException e) {
						log.error("Error checking registration phase for {}", identity.getId(), e);
						throw e;
					}
				}

				ret = syncUser((ExternalUser) identity, user);
				timer.mark("sync");
			} else if (identity instanceof ExternalGroup) {
				log.error("Group sync is not implemented, ignoring {}", identity.getId());
				throw new IllegalArgumentException("Group sync is not implemented: " + identity);
//				Group group = getAuthorizable(identity, Group.class);
//				timer.mark("find");
//				if (group == null) {
//					group = createGroup((ExternalGroup) identity);
//					timer.mark("create");
//					created = true;
//				}
//				ret = syncGroup((ExternalGroup) identity, group);
//				timer.mark("sync");
			} else {
				throw new IllegalArgumentException("identity must be user or group but was: " + identity);
			}
			if (log.isDebugEnabled()) {
				log.debug("sync(external identity) {}:{} -> {}", new Object[] {ref.getString(), identity.getId(), timer.getString()});
			}
			if (created) {
				ret.setStatus(SyncResult.Status.ADD);
			}
			return ret;
		} catch (RepositoryException e) {
			throw new SyncException(e);
		}
	}

	/**
	 * If the user record exists in AEM then check it for validity if we are in registration
	 * @param identity
	 * @param user
	 * @throws SyncException 
	 */
	private void checkUserRegistrationPhase(ExternalUser identity, User user) throws SyncException {
		if (identity instanceof IsamRegisteringUser || identity instanceof IsamImportingUser) {
			IsamExternalUser registeringUserIdentity = (IsamExternalUser)identity;
			IsamRegistrationPhase savedRegPhase = null;

			try {
				Value[] savedRegPhaseValue = user.getProperty(ISAM_REGISTRATION_PHASE);

				if (savedRegPhaseValue != null && savedRegPhaseValue.length > 0) {
					Value savedRegPhaseVal = savedRegPhaseValue[0];
					String regPhaseString = savedRegPhaseVal.getString();
					
					if (StringUtils.isNotBlank(regPhaseString)) {
						savedRegPhase = IsamRegistrationPhase.valueOf(regPhaseString);
					}
				}
			} catch (RepositoryException e) {
				log.warn("Error retrieving {}", ISAM_REGISTRATION_PHASE, e);
			}

			// Check the phase move is legal!
			if (registeringUserIdentity instanceof IsamRegisteringUser) {
				IsamRegistrationPhase isamRegistrationPhase =
						((IsamRegisteringUser)registeringUserIdentity).getIsamRegistrationPhase();
				if (savedRegPhase != null && !isamRegistrationPhase.equals(savedRegPhase) &&
						!savedRegPhase.canProceedToState(isamRegistrationPhase) &&
						!savedRegPhase.canRegressToState(isamRegistrationPhase)) {
					log.warn("ISAM registration phase for saved user profile '{}' is {}, cannot proceed/regress to state {}",
							 new Object[] {identity.getPrincipalName(), savedRegPhase, isamRegistrationPhase});
					throw new SyncException("Illegal registration phase");
				}
			}
		} else {
			log.info("Not checking registration phase for identity type: {}", identity.getClass());
		}
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	public SyncResult sync(String id) throws SyncException {
		try {
			DebugTimer timer = new DebugTimer();
			DefaultSyncResultImpl ret;
			// find authorizable
			Authorizable auth = userManager.getAuthorizable(id);
			if (auth == null) {
				return new DefaultSyncResultImpl(new DefaultSyncedIdentity(id, null, false, -1),
						SyncResult.Status.NO_SUCH_AUTHORIZABLE);
			}
			// check if we need to deal with this authorizable
			ExternalIdentityRef ref = getIdentityRef(auth);
			if (ref == null || !isSameIDP(ref)) {
				return new DefaultSyncResultImpl(new DefaultSyncedIdentity(id, ref, auth.isGroup(), -1),
						SyncResult.Status.FOREIGN);
			}

//			if (auth.isGroup()) {
//				ExternalGroup external = idp.getGroup(id);
//				timer.mark("retrieve");
//				if (external == null) {
//					ret = handleMissingIdentity(id, auth, timer);
//				} else {
//					ret = syncGroup(external, (Group) auth);
//					timer.mark("sync");
//				}
//			} else {
				ExternalUser external = idp.getUser(id);
				timer.mark("retrieve");
				if (external == null) {
					ret = handleMissingIdentity(id, auth, timer);
					timer.mark("handleMissing");
				} else {
					ret = syncUser(external, (User) auth);
					timer.mark("sync");
				}
//			}
			if (log.isDebugEnabled()) {
				log.debug("sync(id) {}:{} -> {}", new Object[] {id, ref.getString(), timer.getString()});
			}
			return ret;
		} catch (RepositoryException e) {
			throw new SyncException(e);
		} catch (ExternalIdentityException e) {
			throw new SyncException(e);
		}
	}

	private DefaultSyncResultImpl handleMissingIdentity(String id, Authorizable authorizable, DebugTimer timer)
			throws RepositoryException {
		DefaultSyncedIdentity syncId = createSyncedIdentity(authorizable);
		SyncResult.Status status;
		if (authorizable.isGroup() && ((Group) authorizable).getDeclaredMembers().hasNext()) {
			log.info("won't remove local group with members: {}", id);
			status = SyncResult.Status.NOP;
		} else if (!keepMissing) {
			if (!authorizable.isGroup()) {
				((User) authorizable).disable("No longer exists on external identity provider '" + idp.getName() + "'");
				log.debug("disabling user '{}' that no longer exists on IDP {}", id, idp.getName());
				status = SyncResult.Status.DELETE;
			} else {
				authorizable.remove();
				log.debug("removing authorizable '{}' that no longer exists on IDP {}", id, idp.getName());
				status = SyncResult.Status.DELETE;
			}
			timer.mark("remove");
		} else {
			status = SyncResult.Status.MISSING;
			log.info("external identity missing for {}, but purge == false.", id);
		}
		return new DefaultSyncResultImpl(syncId, status);
	}

	/**
	 * Retrieves the repository authorizable that corresponds to the given
	 * external identity
	 * 
	 * @param external
	 *            the external identity
	 * @param type
	 *            the authorizable type
	 * @return the repository authorizable or {@code null} if not found.
	 * @throws RepositoryException
	 *             if an error occurs.
	 * @throws SyncException
	 *             if the repository contains a colliding authorizable with the
	 *             same name.
	 */

	protected <T extends Authorizable> T getAuthorizable(ExternalIdentity external, Class<T> type)
			throws RepositoryException, SyncException {
		Authorizable authorizable = userManager.getAuthorizable(external.getId());
		if (authorizable == null) {
			authorizable = userManager.getAuthorizable(external.getPrincipalName());
		}
		if (authorizable == null) {
			return null;
		} else if (type.isInstance(authorizable)) {
			return type.cast(authorizable);
		} else {
			log.error("Unable to process external {}: {}. Colliding authorizable exists in repository.",
					type.getSimpleName(), external.getId());
			throw new SyncException("Unexpected authorizable: " + authorizable);
		}
	}

	/**
	 * Creates a new repository user for the given external one. Note that this
	 * method only creates the authorizable but does not perform any
	 * synchronization.
	 *
	 * @param externalUser
	 *            the external user
	 * @return the repository user
	 * @throws RepositoryException
	 *             if an error occurs
	 */

	protected User createUser(ExternalUser externalUser) throws RepositoryException {
		Principal principal = new PrincipalImpl(externalUser.getPrincipalName());
//		String authId = config.user().isApplyRFC7613UsernameCaseMapped()
//				? java.text.Normalizer.normalize(externalUser.getId().toLowerCase(), java.text.Normalizer.Form.NFKC)
//				: externalUser.getId();
		String authId = externalUser.getId();
		User user = userManager.createUser(authId, null, principal,
				PathUtils.concatRelativePaths(userPathPrefix, externalUser.getIntermediatePath()));
		setExternalId(user, externalUser);
		return user;
	}

	/**
	 * Creates a new repository group for the given external one. Note that this
	 * method only creates the authorizable but does not perform any
	 * synchronization.
	 *
	 * @param externalGroup
	 *            the external group
	 * @return the repository group
	 * @throws RepositoryException
	 *             if an error occurs
	 */
	protected Group createGroup(ExternalGroup externalGroup) throws RepositoryException {
		Principal principal = new PrincipalImpl(externalGroup.getPrincipalName());
		Group group = userManager.createGroup(externalGroup.getId(), principal,
				PathUtils.concatRelativePaths(groupPathPrefix, externalGroup.getIntermediatePath()));
		setExternalId(group, externalGroup);
		return group;
	}

	/**
	 * Sets the {@link #REP_EXTERNAL_ID} as obtained from
	 * {@code externalIdentity} to the specified {@code authorizable} (user or
	 * group). The property is a single value of type
	 * {@link javax.jcr.PropertyType#STRING STRING}.
	 *
	 * @param authorizable
	 *            The user or group that needs to get the
	 *            {@link #REP_EXTERNAL_ID} property set.
	 * @param externalIdentity
	 *            The {@link ExternalIdentity} from which to retrieve the value
	 *            of the property.
	 * @throws RepositoryException
	 *             If setting the property using
	 *             {@link Authorizable#setProperty(String, Value)} fails.
	 */
	private void setExternalId(Authorizable authorizable, ExternalIdentity externalIdentity)
			throws RepositoryException {
		log.debug("Fallback: setting rep:externalId without adding the corresponding mixin type");
		authorizable.setProperty(REP_EXTERNAL_ID,
				valueFactory.createValue(externalIdentity.getExternalId().getString()));
	}

	protected DefaultSyncResultImpl syncUser(ExternalUser external, User user) throws RepositoryException {
		SyncResult.Status status;
		// first check if user is expired
		if (isUserLoggedIn(external, user) || (!forceUserSync && !isExpired(user))) {
			status = SyncResult.Status.NOP;
		} else {
			syncExternalIdentity(external, user);
			if (isExpired(user, expirationTimeMs, "Membership")) {
				// synchronize external memberships
				syncMembership(external, user, 1);
			}
			if (user.isDisabled()) {
				status = SyncResult.Status.UPDATE;
				user.disable(null);
			} else {
				status = SyncResult.Status.UPDATE;
			}
			// finally "touch" the sync property
			user.setProperty(REP_LAST_SYNCED, nowValue);
		}
		return new DefaultSyncResultImpl(createSyncedIdentity(user), status);
	}

	/**
	 * Checks against the AEM user token value to see if the user is indeed logged-in
	 * 
	 * @param external
	 * @param user
	 * @return
	 */
	private boolean isUserLoggedIn(ExternalUser external, User user) {
		DebugTimer timer = new DebugTimer();

		// Get the token from properties passed in
		String userToken = (String)external.getProperties().get(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN);
		
		// This flag determines if the flag is for a new login/registration event, and so the user is not yet
		// logged in
		Boolean newUserTokenFlag = BooleanUtils.isTrue((Boolean)external.getProperties().get(NEW_USER_TOKEN_FLAG));
		timer.mark("userToken");
		
		try {
			if (!newUserTokenFlag && StringUtils.isNotBlank(userToken)) {

				// Do we always trust the login token? If we do then don't check against the value in the CRX.
				if (trustUserLoginToken) {
					return true;
				}

				// Check against the user profile for this token
				Value[] property = null;
				try {
					property = user.getProperty(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN);
				} catch (RepositoryException e) {
					log.error("Could not get user token property " + JhiConstants.ISAM_AUTH_INFO_USER_TOKEN + " for {}", external.getId(), e);
				} finally {
					timer.mark("property");
				}
	
				// Expecting a single value, not an array, for this property
				if (property != null && property.length == 1) {
					try {
						String userLoginToken = property[0].getString();
						if (StringUtils.equals(userLoginToken, userToken)) {
							return true;
						}
						
						if (log.isWarnEnabled()) {
							log.warn("User tokens for {} are not equal: expected({}) != input({})",
									new Object[] {external.getId(), userToken, userLoginToken});
						}
					} catch (IllegalStateException | RepositoryException e) {
						log.error("Could not get user login token property " +
								JhiConstants.ISAM_AUTH_INFO_USER_TOKEN + " for {}", external.getId(), e);
					} finally {
						timer.mark("value");
					}
				}
					
			} else {
				log.debug("No " + JhiConstants.ISAM_AUTH_INFO_USER_TOKEN + " found on user info for {}", external.getId());
			}
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("sync (logged in check) {} -> {}", external.getId(), timer.getString());
			}
		}
		
		return false;
	}

	protected DefaultSyncResultImpl syncGroup(ExternalGroup external, Group group) throws RepositoryException {
		SyncResult.Status status;
		// first check if group is expired
		if (!forceGroupSync && !isExpired(group)) {
			status = SyncResult.Status.NOP;
		} else {
			syncExternalIdentity(external, group);
			// finally "touch" the sync property
			group.setProperty(REP_LAST_SYNCED, nowValue);
			status = SyncResult.Status.UPDATE;
		}
		return new DefaultSyncResultImpl(createSyncedIdentity(group), status);
	}

	/**
	 * Synchronize content common to both external users and external groups: -
	 * properties - auto-group membership
	 *
	 * @param external
	 *            The external identity
	 * @param authorizable
	 *            The corresponding repository user/group
	 * @param config
	 *            The sync configuration
	 * @throws RepositoryException
	 *             If an error occurs.
	 */
	private void syncExternalIdentity(ExternalIdentity external, Authorizable authorizable) throws RepositoryException {
		// Apply membership
        String groupApplied = applyMembershipForUserState(external, authorizable);
        
        if (groupApplied == null) {
        	authorizable.removeProperty(ISAM_GROUP_PROPERTY);
        } else {
        	authorizable.setProperty(ISAM_GROUP_PROPERTY, createValue(groupApplied));
        }

        // Set properties
        syncProperties(external, authorizable, null, ISAM_EXTERNAL_USER_PROPS, false);
		syncProperties(external, authorizable, "profile", ISAM_EXTERNAL_USER_PROFILE_PROPS, false);

		// Set up last logged in properties
		Value[] lastLoginPropertyValues = (Value[])authorizable.getProperty("profile/" + ProfileModel.LAST_LOGIN_PROPERTY);
        Value lastLogin = lastLoginPropertyValues == null || lastLoginPropertyValues.length == 0 ? null :
        		Arrays.stream(lastLoginPropertyValues)
        			.findFirst().orElse(null);
        if (lastLogin != null && lastLogin.getDate() != null) {
        	authorizable.setProperty("profile/" + ProfileModel.PREVIOUS_LOGIN_PROPERTY, createValue(lastLogin));
        }
        authorizable.setProperty("profile/" + ProfileModel.LAST_LOGIN_PROPERTY, createValue(Calendar.getInstance()));

        // Store the email (username/id) property on the profile
        authorizable.setProperty("profile/" + ProfileModel.EMAIL_PROPERTY, createValue(authorizable.getID()));
	}

	/**
	 * Recursively sync the memberships of an authorizable up-to the specified
	 * depth. If the given depth is equal or less than 0, no syncing is
	 * performed.
	 *
	 * @param external
	 *            the external identity
	 * @param auth
	 *            the authorizable
	 * @param depth
	 *            recursion depth.
	 * @throws RepositoryException
	 */
	protected void syncMembership(ExternalIdentity external, Authorizable auth, long depth) throws RepositoryException {
		if (depth <= 0) {
			return;
		}
		if (log.isDebugEnabled()) {
			log.debug("Syncing membership '{}' -> '{}'", external.getExternalId().getString(), auth.getID());
		}

		final DebugTimer timer = new DebugTimer();
		Iterable<ExternalIdentityRef> externalGroups;
		try {
			externalGroups = external.getDeclaredGroups();
		} catch (ExternalIdentityException e) {
			log.error("Error while retrieving external declared groups for '{}'", external.getId(), e);
			return;
		}
		timer.mark("fetching");

        // first get the set of the existing groups that are synced ones
        Map<String, Group> declaredExternalGroups = new HashMap<>();
        Iterator<Group> grpIter = auth.declaredMemberOf();
        while (grpIter.hasNext()) {
            Group grp = grpIter.next();
            if (isSameIDP(grp)) {
                declaredExternalGroups.put(grp.getID(), grp);
            }
        }
        timer.mark("reading");

		if (externalGroups != null) {
			for (ExternalIdentityRef ref : externalGroups) {
				log.debug("Processing group membership {}", ref.getId());
				// get group
				ExternalGroup extGroup;
				try {
					ExternalIdentity extId = idp.getIdentity(ref);
					if (extId != null && extId instanceof ExternalGroup) {
						extGroup = (ExternalGroup) extId;
					} else {
						log.warn("No external group found for ref '{}'.", ref.getString());
						continue;
					}
				} catch (ExternalIdentityException e) {
					log.warn("Unable to retrieve external group '{}' from provider.", ref.getString(), e);
					continue;
				}
				log.debug("IDP returned external group '{}'", extGroup.getId());
	
				Group grp;
				Authorizable a = userManager.getAuthorizable(extGroup.getId());
				if (a == null) {
					grp = createGroup(extGroup);
					log.debug("Created new group {}", extGroup.getId());
				} else if (a.isGroup() && isSameIDP(a)) {
					grp = (Group) a;
				} else {
					log.warn("Existing authorizable '{}' is not a group from this IDP '{}'.", extGroup.getId(),
							idp.getName());
					continue;
				}
				log.debug("User manager returned '{}'", grp);
	
				syncGroup(extGroup, grp);
	
				// ensure membership
				if (!grp.isDeclaredMember(auth)) {
					grp.addMember(auth);
					log.debug("Added '{}' as member to '{}'", auth, grp);
				} else {
					log.debug("User '{}' is already a member of group '{}'", auth, grp);
				}

				// remember the declared group
				declaredExternalGroups.remove(grp.getID());
	
				// recursively apply further membership
				if (depth > 1) {
					log.debug("Recursively sync group membership of '{}' (depth = {}).", grp.getID(), depth);
					syncMembership(extGroup, grp, depth - 1);
				} else {
					log.debug("Group nesting level for '{}' reached", grp.getID());
				}
			}
			timer.mark("adding");
		}

		// remove us from the lost membership groups
		for (Group grp : declaredExternalGroups.values()) {
			grp.removeMember(auth);
			log.debug("- removing member '{}' for group '{}'", auth.getID(), grp.getID());
		}
		if (log.isDebugEnabled()) {
			timer.mark("removing");
			log.debug("syncMembership({}) {}", external.getId(), timer.getString());
		}
	}

	private String applyMembershipForUserState(ExternalIdentity external, Authorizable authorizable)
			throws RepositoryException {
		IsamRegistrationPhase isamRegistrationPhase =
				(IsamRegistrationPhase)external.getProperties().get(IsamConstants.ISAM_REGISTRATION_PHASE);
		String isamGroup = null;
		Set<String> groupsToApply = null;

		if (isamRegistrationPhase == null) {
			// Apply ISAM memberships on new login
			removeMembership(authorizable, IsamGroups.AEM_MAPPED_ISAM_GROUPS);
			groupsToApply = getGroupsToApplyFromExternalIdentity(external, authorizable, groupsToApply);
			if (groupsToApply.size() > 0) {
				try {
					isamGroup = external.getDeclaredGroups().iterator().next().getId();
				} catch (ExternalIdentityException e) {
					log.warn("Could not get ISAM group from external entity");
				}
			}
			log.debug("No ISAM registration phase set, implies new login for user '{}', applying groups: {}",
					authorizable.getID(), groupsToApply);
		} else {
			switch (isamRegistrationPhase) {

                case EMPLOYEE_USER_EMAIL_VALIDATED:
                case EMPLOYEE_USER_EMAIL_VALIDATION:
                case UNVERIFIED_USER_EMAIL_VALIDATED:
                case UNVERIFIED_USER_EMAIL_VALIDATION:
                case INVESTOR_USER_EMAIL_VALIDATED:
                case INVESTOR_USER_EMAIL_VALIDATION:
                case VERIFIED_USER_EMAIL_VALIDATED:
                case VERIFIED_USER_EMAIL_VALIDATION:
                    groupsToApply = IsamSyncHandler.IN_REGISTRATION_ISAM_MEMBERSHIP_GROUPS;
                    break;

                case VERIFIED_USER_COMPLETE_REGISTRATION:
                case EMPLOYEE_USER_COMPLETE_REGISTRATION:
                case UNVERIFIED_USER_COMPLETE_REGISTRATION:
                case INVESTOR_USER_COMPLETE_REGISTRATION:
                    isamGroup = isamRegistrationPhase.getIsamGroups().stream().findFirst().get();
                    groupsToApply = isamRegistrationPhase.getAemGroups();
                    // TODO: Remove other membership, but only if the user is not in one of the blocked states
                    removeMembership(authorizable, IsamSyncHandler.IN_REGISTRATION_ISAM_MEMBERSHIP_GROUPS);
                    break;

				case UNVERIFIED_USER_LAPSED:
				case UNVERIFIED_USER_PURGATORY:
					groupsToApply = IsamSyncHandler.BLOCKED_ISAM_MEMBERSHIP_GROUPS;
					break;

				case IMPORT_EXISTING_ISAM_USER:
					// Apply ISAM user groups for an importing user
					removeMembership(authorizable, IsamGroups.AEM_MAPPED_ISAM_GROUPS);
					groupsToApply = getGroupsToApplyFromExternalIdentity(external, authorizable, groupsToApply);
					if (groupsToApply.size() > 0) {
						try {
							isamGroup = external.getDeclaredGroups().iterator().next().getId();
						} catch (ExternalIdentityException e) {
							log.warn("Could not get ISAM group from external entity");
						}
					}
					break;

				default:
					log.debug("Not setting any groups for ISAM registration phase {} on user '{}'",
							isamRegistrationPhase, authorizable.getID());
			}
		}
		
		applyMembership(authorizable, groupsToApply);
		return isamGroup;
	}

	private Set<String> getGroupsToApplyFromExternalIdentity(ExternalIdentity external, Authorizable authorizable,
			Set<String> groupsToApply) throws RepositoryException {
		try {
			// Go through the groups which have been extracted from ISAM and apply them
			Iterable<ExternalIdentityRef> declaredGroups = external.getDeclaredGroups();
			
			if (declaredGroups != null && declaredGroups.iterator().hasNext()) {
				removeMembership(authorizable, IsamSyncHandler.BLOCKED_ISAM_MEMBERSHIP_GROUPS);
				groupsToApply = new HashSet<>();

                for (ExternalIdentityRef groupRef : declaredGroups) {
                    switch (groupRef.getId()) {
                        case IsamGroups.ISAM_ADMIN_USER_GROUP:
                            groupsToApply.add(IsamGroups.AEM_ADMIN_USER_GROUP);
                            break;
                        case IsamGroups.ISAM_EMPLOYEE_GROUP:
                            groupsToApply.add(IsamGroups.AEM_EMPLOYEE_GROUP);
                            break;
                        case IsamGroups.ISAM_INVESTOR_GROUP:
                            groupsToApply.add(IsamGroups.AEM_INVESTOR_GROUP);
                            break;
                        case IsamGroups.ISAM_UNVERIFIED_PRO_GROUP:
                            groupsToApply.add(IsamGroups.AEM_UNVERIFIED_PRO_GROUP);
                            break;
                        case IsamGroups.ISAM_VERIFIED_PRO_GROUP:
                            groupsToApply.add(IsamGroups.AEM_VERIFIED_PRO_GROUP);
                            break;
                    }
                }
            }

		} catch (ExternalIdentityException e) {
			log.warn("An error occured extracting the user groups to apply, "
					+ "not changing groups for importing ISAM user", e);
		}
		return groupsToApply;
	}

	private void removeMembership(Authorizable member, Set<String> groups) throws RepositoryException {
		if (groups == null || groups.isEmpty()) {
			log.warn("Clearing group membership for '{}'", member.getID());
		} else {

			for (String groupName : groups) {
				Authorizable group = userManager.getAuthorizable(groupName);
				if (group == null) {
					log.warn("Unable to apply auto-membership to {}. No such group: {}", member.getID(), groupName);
				} else if (group instanceof Group) {
					((Group) group).removeMember(member);
				} else {
					log.warn("Unable to apply auto-membership to {}. Authorizable '{}' is not a group.", member.getID(),
							groupName);
				}
			}
		}
	}

	/**
	 * Ensures that the given authorizable is member of the specific groups.
	 * Note that it does not create groups if missing, nor remove memberships of
	 * groups not in the given set.
	 * 
	 * @param member
	 *            the authorizable
	 * @param groups
	 *            set of groups.
	 */
	protected void applyMembership(Authorizable member, Set<String> groups) throws RepositoryException {
		if (groups != null && !groups.isEmpty()) {
			log.debug("Setting groups for {}: {}", member.getID(), groups);

			for (String groupName : groups) {
				Authorizable group = userManager.getAuthorizable(groupName);
				if (group == null) {
					log.warn("Unable to apply auto-membership to {}. No such group: {}", member.getID(), groupName);
				} else if (group instanceof Group) {
					((Group) group).addMember(member);
				} else {
					log.warn("Unable to apply auto-membership to {}. Authorizable '{}' is not a group.", member.getID(),
							groupName);
				}
			}
		} else {
			log.warn("No groups being set for '{}'", member.getID());
		}
	}

	/**
	 * Syncs the properties specified in the {@code mapping} from the external
	 * identity to the given authorizable. Note that this method does not check
	 * for value equality and just blindly copies or deletes the properties.
	 * 
	 * TODO: Import the profile, no user properties are available in the profile yet
	 *
	 * @param ext
	 *            external identity
	 * @param auth
	 *            the authorizable
	 * @param propertiesToMap
	 *            the property names to map
	 * @throws RepositoryException
	 *             if an error occurs
	 */
	protected void syncProperties(ExternalIdentity ext, Authorizable auth,
			String basePropertyPath, List<String> propertiesToMap, boolean deleteMissing)
			throws RepositoryException {
		Map<String, ?> properties = ext.getProperties();
		for (String propName : propertiesToMap) {
			Object obj = properties.get(propName);
			String name = basePropertyPath != null ? basePropertyPath + "/" + propName : propName;

			if (obj == null) {
				if (deleteMissing) {
					int nameLen = name.length();
					if (nameLen > 1 && name.charAt(0) == '"' && name.charAt(nameLen - 1) == '"') {
						auth.setProperty(name, valueFactory.createValue(name.substring(1, nameLen - 1)));
					} else {
						auth.removeProperty(name);
					}
				}
			} else {
				if (obj instanceof Collection) {
					auth.setProperty(name, createValues((Collection) obj));
				} else if (obj instanceof byte[] || obj instanceof char[]) {
					auth.setProperty(name, createValue(obj));
				} else if (obj instanceof Object[]) {
					auth.setProperty(name, createValues(Arrays.asList((Object[]) obj)));
				} else {
					auth.setProperty(name, createValue(obj));
				}
			}
		}
		
		// Set the email on the profile, for example
		//auth.setProperty("profile/" + UserProperties.EMAIL, createValue(auth.getID()));
	}

	/**
	 * Checks if the given authorizable needs syncing based on the
	 * {@link #REP_LAST_SYNCED} property.
	 *
	 * @param authorizable
	 *            the authorizable to check
	 * @return {@code true} if the authorizable needs sync
	 */
	private boolean isExpired(Authorizable authorizable) throws RepositoryException {
		return isExpired(authorizable, expirationTimeMs, "Properties");
	}

	/**
	 * Checks if the given authorizable needs syncing based on the
	 * {@link #REP_LAST_SYNCED} property.
	 * 
	 * @param auth
	 *            the authorizable to check
	 * @param expirationTime
	 *            the expiration time to compare to.
	 * @param type
	 *            debug message type
	 * @return {@code true} if the authorizable needs sync
	 */
	protected boolean isExpired(Authorizable auth, long expirationTime, String type) throws RepositoryException {
		Value[] values = auth.getProperty(REP_LAST_SYNCED);
		if (values == null || values.length == 0) {
			if (log.isDebugEnabled()) {
				log.debug("{} of {} '{}' need sync. " + REP_LAST_SYNCED + " not set.",
						new Object[] {type, auth.isGroup() ? "group" : "user", auth.getID()});
			}
			return true;
		} else if (now - values[0].getLong() > expirationTime) {
			if (log.isDebugEnabled()) {
				log.debug("{} of {} '{}' need sync. " + REP_LAST_SYNCED + " expired ({} > {})",
						new Object[] {type, auth.isGroup() ? "group" : "user", auth.getID(), now - values[0].getLong(), expirationTime});
			}
			return true;
		} else {
			if (log.isDebugEnabled()) {
				log.debug("{} of {} '{}' do not need sync.",
						new Object[] {type, auth.isGroup() ? "group" : "user", auth.getID()});
			}
			return false;
		}
	}

	/**
	 * Creates a new JCR value of the given object, checking the internal type.
	 * 
	 * @param v
	 *            the value
	 * @return the JCR value or null
	 * @throws RepositoryException
	 *             if an error occurs
	 */

	protected Value createValue(Object v) throws RepositoryException {
		if (v == null) {
			return null;
		} else if (v instanceof Boolean) {
			return valueFactory.createValue((Boolean) v);
		} else if (v instanceof Byte || v instanceof Short || v instanceof Integer || v instanceof Long) {
			return valueFactory.createValue(((Number) v).longValue());
		} else if (v instanceof Float || v instanceof Double) {
			return valueFactory.createValue(((Number) v).doubleValue());
		} else if (v instanceof BigDecimal) {
			return valueFactory.createValue((BigDecimal) v);
		} else if (v instanceof Calendar) {
			return valueFactory.createValue((Calendar) v);
		} else if (v instanceof Date) {
			Calendar cal = Calendar.getInstance();
			cal.setTime((Date) v);
			return valueFactory.createValue(cal);
		} else if (v instanceof byte[]) {
			Binary bin = valueFactory.createBinary(new ByteArrayInputStream((byte[]) v));
			return valueFactory.createValue(bin);
		} else if (v instanceof Binary) {
			return valueFactory.createValue((Binary) v);
		} else if (v instanceof InputStream) {
			return valueFactory.createValue((InputStream) v);
		} else if (v instanceof char[]) {
			return valueFactory.createValue(new String((char[]) v));
		} else {
			return valueFactory.createValue(String.valueOf(v));
		}
	}

	/**
	 * Creates an array of JCR values based on the type.
	 * 
	 * @param propValues
	 *            the given values
	 * @return and array of JCR values
	 * @throws RepositoryException
	 *             if an error occurs
	 */

    protected Value[] createValues(Collection<?> propValues) throws RepositoryException {
        List<Value> values = new ArrayList<>();
        for (Object obj : propValues) {
            Value v = createValue(obj);
            if (v != null) {
                values.add(v);
            }
        }
        return values.toArray(new Value[values.size()]);
    }

	/**
	 * Checks if the given authorizable was synced from the same IDP by
	 * comparing the IDP name of the {@value #REP_EXTERNAL_ID} property.
	 *
	 * todo: allow multiple IDPs on 1 authorizable
	 *
	 * @param auth
	 *            the authorizable.
	 * @return {@code true} if same IDP.
	 */
	protected boolean isSameIDP(Authorizable auth) throws RepositoryException {
		ExternalIdentityRef ref = getIdentityRef(auth);
		return ref != null && idp.getName().equals(ref.getProviderName());
	}

	/**
	 * Tests if the given {@link ExternalIdentityRef} refers to the same IDP as
	 * associated with this context instance.
	 *
	 * @param ref
	 *            The {@link ExternalIdentityRef} to be tested.
	 * @return {@code true} if {@link ExternalIdentityRef#getProviderName()}
	 *         refers to the IDP associated with this context instance.
	 */
	protected boolean isSameIDP(ExternalIdentityRef ref) {
		return idp.getName().equals(ref.getProviderName());
	}
}