package com.jhi.aem.website.v1.core.service.auth.external;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.jcr.RepositoryException;
import javax.jcr.ValueFactory;

import org.apache.commons.lang3.StringUtils;

import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.jackrabbit.commons.iterator.AbstractLazyIterator;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityProvider;
import org.apache.jackrabbit.oak.spi.security.authentication.external.SyncContext;
import org.apache.jackrabbit.oak.spi.security.authentication.external.SyncException;
import org.apache.jackrabbit.oak.spi.security.authentication.external.SyncHandler;
import org.apache.jackrabbit.oak.spi.security.authentication.external.SyncedIdentity;
import org.apache.jackrabbit.oak.spi.security.authentication.external.basic.DefaultSyncContext;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Sets;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Component(
		service=SyncHandler.class,
		immediate=true,
		configurationPolicy=ConfigurationPolicy.REQUIRE,
		configurationPid="com.jhi.aem.website.v1.core.service.auth.external.IsamSyncHandler",
		property= {
				Constants.SERVICE_DESCRIPTION+"=ISAM user sync handler for Oak",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

@Designate(ocd=IsamSyncHandler.Config.class)
public class IsamSyncHandler implements SyncHandler {
	private static final Logger log = LoggerFactory.getLogger(IsamSyncHandler.class);
	
	@ObjectClassDefinition(name="IsamSyncHandlerConfigurations for JHI Website", description="Configurations for IsamSynchHandler")
	public @interface Config{
		final String DEFAULT_ISAM_SYNC_CONFIG_NAME = "isamSync";
		@AttributeDefinition(name = "Sync Handler config name",
				description = "This sync config's name")
		String sync_handlerName() default DEFAULT_ISAM_SYNC_CONFIG_NAME;
		
		final String DEFAULT_USER_PATH_PREFIX = StringUtils.EMPTY;
		@AttributeDefinition(name = "User Path Prefix",
				description = "The path prefix for sync'd users")
	    String user_pathPrefix() default DEFAULT_USER_PATH_PREFIX ;
		
		final String DEFAULT_GROUP_PATH_PREFIX = StringUtils.EMPTY;
		@AttributeDefinition(name = "Group Path Prefix",
				description = "The path prefix for sync'd groups")
	    String group_pathPrefix() default DEFAULT_GROUP_PATH_PREFIX ;
		
		long DEFAULT_EXPRATION_TIME = 15 * 60 * 1000;
		@AttributeDefinition(name = "Expiration Time",
				description = "The expiration time in milliseconds for a sync'd user/group")
	    long sync_expirationTimeMs() default DEFAULT_EXPRATION_TIME;
		
		boolean DEFAULT_TRUST_LOGIN_COOKIE = false;
		@AttributeDefinition(name = "Trust Login Cookia",
				description = "True if the presence of a login token from the auth frontend should be trusted "
								+ "or false if it should be checked against the value in stored in CRX (default)")
	    boolean sync_trustUserLoginToken() default DEFAULT_TRUST_LOGIN_COOKIE ;
	}

	
	
	private String syncConfigName;
	private String userPathPrefix;
	private String groupPathPrefix;
	private long expirationTimeMs;
	private boolean trustUserLoginToken;

	public static final Set<String> IN_REGISTRATION_ISAM_MEMBERSHIP_GROUPS = Sets.newHashSet(IsamGroups.AEM_USER_IN_REGISTRATION_GROUP);

	public static final Set<String> BLOCKED_ISAM_MEMBERSHIP_GROUPS = Sets.newHashSet(IsamGroups.AEM_USER_BLOCKED_GROUP);

	

	@Activate
	@Modified
	protected void activate(final Config config) {
		updateConfig(config);
	}
	
	
		
	private void updateConfig(final Config config) {
		userPathPrefix = config.user_pathPrefix();
		groupPathPrefix = config.group_pathPrefix(); 
		syncConfigName = config.sync_handlerName(); 
		expirationTimeMs = config.sync_expirationTimeMs();
		trustUserLoginToken = config.sync_trustUserLoginToken();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getName() {
		return syncConfigName;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	public SyncContext createContext(ExternalIdentityProvider idp, UserManager userManager, ValueFactory valueFactory)
			throws SyncException {
		return new IsamSyncContext(idp, userManager, valueFactory, userPathPrefix, groupPathPrefix,
				expirationTimeMs, trustUserLoginToken);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public SyncedIdentity findIdentity(UserManager userManager, String id) throws RepositoryException {
		return DefaultSyncContext.createSyncedIdentity(userManager.getAuthorizable(id));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean requiresSync(SyncedIdentity identity) {
		if (identity.getExternalIdRef() == null || identity.lastSynced() < 0) {
			return true;
		}
		return System.currentTimeMillis() - identity.lastSynced() > expirationTimeMs;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	public Iterator<SyncedIdentity> listIdentities(UserManager userManager) throws RepositoryException {
		final Iterator<Authorizable> iter = userManager.findAuthorizables("jcr:primaryType", null);
		return new AbstractLazyIterator<SyncedIdentity>() {

			@Override
			protected SyncedIdentity getNext() {
				while (iter.hasNext()) {
					try {
						SyncedIdentity id = DefaultSyncContext.createSyncedIdentity(iter.next());
						if (id != null && id.getExternalIdRef() != null) {
							return id;
						}
					} catch (RepositoryException e) {
						log.error("Error while fetching authorizables", e);
						break;
					}
				}
				return null;
			}
		};
	}
}