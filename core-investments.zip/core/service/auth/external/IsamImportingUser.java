package com.jhi.aem.website.v1.core.service.auth.external;

import java.util.List;

import javax.security.auth.login.LoginException;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.isam.models.LoginResponse;

public class IsamImportingUser extends IsamLoggedInUser {
	private final IsamRegistrationPhase isamRegistrationPhase;

	/**
	 * User created through a registration call
	 * @param isamRegistrationPhase 
	 * @param externalUserRefName
	 * @param userId
	 * @param loggedInToken
	 * @param loginResponse
	 * @param firstName
	 * @param lastName
	 * @param firm
	 * @param financialAdvisor
	 * @param crdNumber
	 * @param  
	 * @throws LoginException
	 */
	public IsamImportingUser(String loggedInToken, LoginResponse loginResponse,
			IsamRegistrationPhase isamRegistrationPhase, String externalUserRefName,
			String userId, List<String> userGroups,
			String firstName, String lastName, String firm,
			String firmId, String financialAdvisor, String crdNumber,
			String marsRepId, String webId,
			String topIndustryProducer, String oaeSegment) throws LoginException {
		super(externalUserRefName, userId, userGroups, loggedInToken, loginResponse,
				firstName, lastName, firm, firmId, financialAdvisor, crdNumber,
				marsRepId, webId, topIndustryProducer, oaeSegment);
		this.isamRegistrationPhase = isamRegistrationPhase;
		this.properties.put(IsamConstants.ISAM_REGISTRATION_PHASE, isamRegistrationPhase);
		this.properties.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, loggedInToken);
		this.properties.put(IsamConstants.NEW_USER_TOKEN_FLAG, Boolean.TRUE);
		this.properties.put(IsamExternalIdentityProvider.LOGIN_TOKEN, loginToken);
	}

	public IsamRegistrationPhase getIsamRegistrationPhase() {
		return isamRegistrationPhase;
	}

}
