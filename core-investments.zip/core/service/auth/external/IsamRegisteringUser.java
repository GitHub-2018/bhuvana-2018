package com.jhi.aem.website.v1.core.service.auth.external;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.security.auth.login.LoginException;

import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityException;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityRef;

import com.jhi.aem.website.v1.core.service.user.UserProfileConstants;

/**
 * A user who is registering through ISAM but who has not yet completed registration
 */
public class IsamRegisteringUser extends IsamExternalUser {
	private final String userId;
	private final ExternalIdentityRef externalId;
	private final Map<String,Object> properties;
	private final IsamRegistrationPhase isamRegistrationPhase;

	/**
	 * User created through a registration call
	 * @param isamRegistrationPhase 
	 * @param externalUserRefName
	 * @param userId
	 * @param loggedInToken
	 * @param loginResponse
	 * @param firstName
	 * @param lastName
	 * @param firm
	 * @param financialAdvisor
	 * @param crdNumber
	 * @param registrationDate 
	 * @param  
	 * @throws LoginException
	 */
	public IsamRegisteringUser(IsamRegistrationPhase isamRegistrationPhase, String externalUserRefName,
			String userId, String userToken, String firstName, String lastName, String firm,
			String firmId, String financialAdvisor, String crdNumber,
			String marsRepId, String webId,
			String topIndustryProducer, String oaeSegment, Calendar registrationDate) throws LoginException {
		this.isamRegistrationPhase = isamRegistrationPhase;
		this.userId = userId;
		this.externalId = new ExternalIdentityRef(userId, externalUserRefName);
		this.properties = new HashMap<>();
		this.properties.put(UserProfileConstants.FIRST_NAME_PROPERTY, firstName);
		this.properties.put(UserProfileConstants.LAST_NAME_PROPERTY, lastName);
		this.properties.put(UserProfileConstants.FIRM_NAME_PROPERTY, firm);
		this.properties.put(UserProfileConstants.FIRM_ID_PROPERTY, firmId);
		this.properties.put(UserProfileConstants.ROLE_PROPERTY, financialAdvisor);
		this.properties.put(UserProfileConstants.CRD_NUMBER_PROPERTY, crdNumber);
		this.properties.put(IsamConstants.ISAM_REGISTRATION_PHASE, isamRegistrationPhase);
		this.properties.put(UserProfileConstants.MARS_REP_ID_PROPERTY, marsRepId);
		this.properties.put(UserProfileConstants.WEB_ID_PROPERTY, webId);
		this.properties.put(UserProfileConstants.TOP_INDUSTRY_PRODUCER_PROPERTY, topIndustryProducer);
		this.properties.put(UserProfileConstants.OAE_SEGMENT_PROPERTY, oaeSegment);
		this.properties.put(UserProfileConstants.EXTERNAL_ID_PROPERTY, generateUniqueExternalUserIdentifier());
		this.properties.put(IsamConstants.USER_REGISTRATION_DATE, registrationDate);

		// Only need to set up the email validation token to sync as a property when we 
		// are setting up the email validation on the user
		if (isamRegistrationPhase != null && isamRegistrationPhase.isEmailValidationState()) {
			this.properties.put(IsamConstants.EMAIL_VALIDATION_TOKEN, userToken);
			this.properties.put(IsamConstants.EMAIL_VALIDATION_TOKEN_CREATED_DATE, Calendar.getInstance());
		}
	}

	@Override
	public ExternalIdentityRef getExternalId() {
		return externalId;
	}

	@Override
	public String getId() {
		return userId;
	}

	@Override
	public String getPrincipalName() {
		return "p_" + getExternalId().getString();
	}

	/**
	 * TODO: Groups from the ISAM interface
	 */
	@Override
	public Iterable<ExternalIdentityRef> getDeclaredGroups() throws ExternalIdentityException {
		return null;
	}

	@Override
	public Map<String, ?> getProperties() {
		return properties;
	}

	public IsamRegistrationPhase getIsamRegistrationPhase() {
		return isamRegistrationPhase;
	}

}
