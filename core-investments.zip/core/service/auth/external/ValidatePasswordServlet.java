package com.jhi.aem.website.v1.core.service.auth.external;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;


import org.apache.http.HttpStatus;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.jhi.aem.website.v1.core.constants.IsamUserProfileConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.service.isam.IsamAdminService;
import com.jhi.aem.website.v1.core.service.isam.IsamException;
import com.jhi.aem.website.v1.core.service.isam.models.ValidatePasswordRequest;
import com.jhi.aem.website.v1.core.service.isam.models.ValidatePasswordResponse;
import com.jhi.aem.website.v1.core.servlets.ServletHelper;

/**
 * A servlet that can be used by the frontend to validate a user's password
 */

@Component(
		service=Servlet.class,
		immediate=true,
		property= {
				"sling.servlet.resourceTypes="+ResourcesConstants.CHANGE_PASSWORD_RESOURCE_TYPE,
				"sling.servlet.resourceTypes="+ResourcesConstants.LOGIN_PAGE_RESOURCE_TYPE,
				"sling.servlet.resourceTypes="+ResourcesConstants.REGISTER_VERIFIED_RESOURCE_TYPE,
				"sling.servlet.resourceTypes="+ResourcesConstants.REGISTER_UNVERIFIED_RESOURCE_TYPE,
				"sling.servlet.selectors="+IsamUserProfileConstants.VALIDATE_PASSWORD_SELECTOR,
				"sling.servlet.extensions="+JhiConstants.JSON_EXTENSION,
				"sling.servlet.methods="+HttpConstants.METHOD_POST
		})

public class ValidatePasswordServlet extends SlingAllMethodsServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(ValidatePasswordServlet.class);

    
    private IsamAdminService isamAdminService;
    @Reference
    public void bindIsamAdminService(IsamAdminService isamAdminService ) {
    	this.isamAdminService = isamAdminService;
    }
    public void unbindIsamAdminService(IsamAdminService isamAdminService ) {
    	this.isamAdminService = isamAdminService;
    }

    @Override
    protected void doPost(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws IOException {
        List<String> errors = new ArrayList<>();

        Map<String, Object> requestJson = null;
        try {
            requestJson = ServletHelper.deserializeJsonFromRequestContent(request);
        } catch (JsonSyntaxException | JsonIOException | IOException e) {
            errors.add("Could not deserialize request JSON");
        }

        if (requestJson != null && errors.isEmpty()) {
            String password = (String) requestJson.get("j_password");
            if (StringUtils.isBlank(password)) {
                errors.add("The password is empty. Please enter a valid password.");
            } else {
                ValidatePasswordRequest vprequest = new ValidatePasswordRequest.Builder()
                        .passWord(password)
                        .build();

                try {
                    ValidatePasswordResponse validatePasswordResp = isamAdminService.validatePassword(vprequest);

                    if (!validatePasswordResp.isSuccess()) {
                        errors.add(validatePasswordResp.getMessage());
                    }

                } catch (IsamException e) {
                    LOG.error("Could not validate password", e);
                    errors.add("Could not validate the password due to a system error. Please try again later.");
                }
            }
        }

        // Return a map with success/fail
        boolean success = errors.isEmpty();
        Map<String, Object> jsonReturnMap = new HashMap<>();
        jsonReturnMap.put(ServletHelper.SUCCESS_PROPERTY, success);
        if (!success) {
            jsonReturnMap.put(ServletHelper.RETURN_MAP_ERRORS_PROPERTY, errors);
        }
        ServletHelper.returnJsonResponse(response, jsonReturnMap,
                ServletHelper.RETURN_MAP_ERRORS_PROPERTY, HttpStatus.SC_BAD_REQUEST);
    }
}
