package com.jhi.aem.website.v1.core.service.auth.external;

import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import com.google.common.collect.Sets;

public enum IsamRegistrationPhase {
    /**
     * A verified user registration with email validation, i.e. the first part of the verified user registration
     */
	VERIFIED_USER_EMAIL_VALIDATION(),

	/**
	 * Email has been validated, the user is in a semi-authenticated state
	 */
	VERIFIED_USER_EMAIL_VALIDATED(VERIFIED_USER_EMAIL_VALIDATION),

	/**
     * A verified user registration after email validation has completed
     */
	VERIFIED_USER_COMPLETE_REGISTRATION(
			Sets.newHashSet(IsamGroups.ISAM_VERIFIED_PRO_GROUP), Sets.newHashSet(IsamGroups.AEM_VERIFIED_PRO_GROUP),
			VERIFIED_USER_EMAIL_VALIDATED),
	
    /**
     * An unverified user registration with email validation, i.e. the first part of the unverified user registration
     */
	UNVERIFIED_USER_EMAIL_VALIDATION(),
	
	/**
	 * Email has been validated, the user is in a semi-authenticated state
	 */
	UNVERIFIED_USER_EMAIL_VALIDATED(UNVERIFIED_USER_EMAIL_VALIDATION),

	/**
     * An unverified user registration after email validation has completed
     */
	UNVERIFIED_USER_COMPLETE_REGISTRATION(
			Sets.newHashSet(IsamGroups.ISAM_UNVERIFIED_PRO_GROUP), Sets.newHashSet(IsamGroups.AEM_UNVERIFIED_PRO_GROUP),
			UNVERIFIED_USER_EMAIL_VALIDATED),

    /**
     * An investor user registration with email validation, i.e. the first part of the investor user registration
     */
    INVESTOR_USER_EMAIL_VALIDATION(),

    /**
     * Email has been validated, the user is in a semi-authenticated state
     */
    INVESTOR_USER_EMAIL_VALIDATED(INVESTOR_USER_EMAIL_VALIDATION),

    /**
     * An investor user registration after email validation has completed
     */
    INVESTOR_USER_COMPLETE_REGISTRATION(
            Sets.newHashSet(IsamGroups.ISAM_INVESTOR_GROUP), Sets.newHashSet(IsamGroups.AEM_INVESTOR_GROUP),
            INVESTOR_USER_EMAIL_VALIDATED),

    /**
     * An employee user registration with email validation, i.e. the first part of the unverified user registration
     */
	EMPLOYEE_USER_EMAIL_VALIDATION(),
	
	/**
	 * Email has been validated, the user is in a semi-authenticated state
	 */
	EMPLOYEE_USER_EMAIL_VALIDATED(EMPLOYEE_USER_EMAIL_VALIDATION),

	/**
     * An unverified user registration after email validation has completed
     */
	EMPLOYEE_USER_COMPLETE_REGISTRATION(
			Sets.newHashSet(IsamGroups.ISAM_EMPLOYEE_GROUP), Sets.newHashSet(IsamGroups.AEM_EMPLOYEE_GROUP),
			EMPLOYEE_USER_EMAIL_VALIDATED),

	/**
	 * Unverified user registration which has lapsed
	 */
	UNVERIFIED_USER_LAPSED(),
	
	/**
	 * Unverified user registration where the user is in purgatory
	 */
	UNVERIFIED_USER_PURGATORY(),

	/**
	 * An existing user in ISAM being imported into AEM
	 */
	IMPORT_EXISTING_ISAM_USER();

    private final static EnumSet<IsamRegistrationPhase> EMAIL_VALIDATION_STATES =
            EnumSet.of(VERIFIED_USER_EMAIL_VALIDATION, UNVERIFIED_USER_EMAIL_VALIDATION, INVESTOR_USER_EMAIL_VALIDATION,
                    EMPLOYEE_USER_EMAIL_VALIDATION);

    private final static EnumSet<IsamRegistrationPhase> EMAIL_VALIDATION_LANDING_STATES =
            EnumSet.of(VERIFIED_USER_EMAIL_VALIDATION, VERIFIED_USER_EMAIL_VALIDATED,
                    UNVERIFIED_USER_EMAIL_VALIDATION, UNVERIFIED_USER_EMAIL_VALIDATED,
                    INVESTOR_USER_EMAIL_VALIDATION, INVESTOR_USER_EMAIL_VALIDATED,
                    EMPLOYEE_USER_EMAIL_VALIDATION, EMPLOYEE_USER_EMAIL_VALIDATED);

	private List<IsamRegistrationPhase> validPreviousStates;

	private Set<String> isamGroups;
	private Set<String> aemGroups;

	@SuppressWarnings("unchecked")
	IsamRegistrationPhase() {
		validPreviousStates = Collections.EMPTY_LIST;
	}

	IsamRegistrationPhase(Set<String> isamGroups, Set<String> aemGroups) {
		this();
		this.isamGroups = isamGroups;
		this.aemGroups = aemGroups;
	}

	IsamRegistrationPhase(Set<String> isamGroups, Set<String> aemGroups, IsamRegistrationPhase... validPreviousStates) {
		this(validPreviousStates);
		this.isamGroups = isamGroups;
		this.aemGroups = aemGroups;
	}

	IsamRegistrationPhase(IsamRegistrationPhase... validPreviousStates) {
		this.validPreviousStates = Arrays.asList(validPreviousStates);
	}
	
	public boolean canProceedToState(IsamRegistrationPhase nextState) {
		return nextState.validPreviousStates.contains(this);
	}

	public boolean canRegressToState(IsamRegistrationPhase previousState) {
		return validPreviousStates.contains(previousState);
	}

	public boolean isEmailValidationState() {
		return EMAIL_VALIDATION_STATES.contains(this);
	}

	public boolean isEmailValidationLandingState() {
		return EMAIL_VALIDATION_LANDING_STATES.contains(this);
	}

	public Set<String> getIsamGroups() {
		return isamGroups;
	}

	public Set<String> getAemGroups() {
		return aemGroups;
	}

}
