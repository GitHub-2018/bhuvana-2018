package com.jhi.aem.website.v1.core.service.auth.external;

import java.util.List;

import org.apache.sling.auth.core.spi.AuthenticationInfo;

import com.google.common.collect.Lists;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.user.UserProfileConstants;

public interface IsamConstants {
    String LOGIN_TOKEN = "loginToken";
    String SESSION_START = "sessionStart";
    String SESSION_LAST_CHECKED = "sessionLastChecked";
    String EMAIL_VALIDATION_TOKEN = "emailValidationToken";
    String EMAIL_VALIDATION_TOKEN_CREATED_DATE = "emailValidationTokenCreated";
    String RESET_PASSWORD_TOKEN = "resetPasswordToken";

    // Actions for login/registration form
    String LOGIN_ACTION_PARAMETER = "action";
    String USER_TYPE_PARAMETER = "usertype";
    String REGISTRATION_ACTION_TYPE = "register";
    String REGISTRATION_UNVERIFIED_PRO_ACTION_TYPE = "register-unverified";
    String REGISTRATION_INVESTOR_ACTION_TYPE = "register-investor";
    String REGISTRATION_EMPLOYEE_ACTION_TYPE = "register-employee";
    String REGISTRATION_COMPLETE_ACTION_TYPE = "register-complete";
    String LOGIN_ACTION_TYPE = "login";
    String LOGOUT_ACTION_TYPE = "logout";
    String RESET_PASSWORD_ACTION_TYPE = "resetPassword";
    String CHANGE_PASSWORD_ACTION_TYPE = "changePassword";

    // Login/registration parameters
    String USER_EMAIL_PARAMETER = "j_username";
    String USER_PASSWORD_PARAMETER = "password";

    // Registration parameters
    String USER_CONFIRM_PASSWORD_PARAMETER = "confirm_password";
    String USER_FIRST_NAME_PARAMETER = "j_userfirstname";
    String USER_LAST_NAME_PARAMETER = "j_userlastname";
    String USER_FIRM_PARAMETER = "j_firm";
    String USER_FIRM_ID_PARAMETER = "firmId";
    String USER_FINANCIAL_ADVISOR_PARAMETER = "j_financial";
    String USER_CRD_NUMBER_PARAMETER = "j_crde";
    String USER_MARS_REP_ID_PARAMETER = "marsRepId";
    String USER_WEB_ID_PARAMETER = "webId";
    String USER_TOP_INDUSTRY_PRODUCER_PARAMETER = "topIndustryProducer";
    String USER_OAE_SEGMENT_PARAMETER = "oaeSegment";

    // Change password parameters
    String USER_OLD_PASSWORD_PARAMETER = "oldPassword";

    /**
     * Flag added to {@link AuthenticationInfo} to indicate that this is a new login/registration
     */
    String NEW_USER_TOKEN_FLAG = "newUserTokenFlag";

    /**
     * Tells us what phase registration is in at the moment
     */
    String ISAM_REGISTRATION_PHASE = "isamRegistrationPhase";

    /**
     * External auth errors from the {@link IsamExternalIdentityProvider} are added to the
     * {@link org.apache.sling.commons.auth.spi.AuthenticationInfo} object
     */
    String EXTERNAL_LOGIN_ERROR_AUTH_INFO_KEY = "loginError";

    /**
     * A key set by {@link IsamExternalIdentityProvider} to indicate that login was
     * attempted through the external IDP
     */
    String EXTERNAL_ISAM_LOGIN_CHECK = "externalIsamLoginPassed";

    // User statuses
    String ACTIVE_USER_STATUS = "Active";
    String INACTIVE_USER_STATUS = "Inactive";

    /**
     * ISAM user status property
     */
    String ISAM_USER_STATUS_PROPERTY = "userStatus";

    /**
     * ISAM group property
     */
    String ISAM_GROUP_PROPERTY = "isamGroup";

    /**
     * ISAM givenName property
     */
    String ISAM_GIVEN_NAME_PROPERTY = "givenName";

    /**
     * ISAM familyName property
     */
    String ISAM_FAMILY_NAME_PROPERTY = "familyName";

    /**
     * ISAM email property
     */
    String ISAM_EMAIL_PROPERTY = "email";

    /**
     * User finalized registration date
     */
    String USER_REGISTRATION_DATE = "registrationCompletedDate";


    String CURRENT_REQUEST_URI = "currentRequestUri";

    // Properties which are set up on the user
    List<String> ISAM_EXTERNAL_USER_PROPS =
            Lists.newArrayList(LOGIN_TOKEN, SESSION_START, SESSION_LAST_CHECKED, JhiConstants.ISAM_AUTH_INFO_USER_TOKEN,
                    ISAM_REGISTRATION_PHASE, EMAIL_VALIDATION_TOKEN, EMAIL_VALIDATION_TOKEN_CREATED_DATE,
                    RESET_PASSWORD_TOKEN, USER_REGISTRATION_DATE);

    // Properties which are set up on the user's profile
    List<String> ISAM_EXTERNAL_USER_PROFILE_PROPS =
            Lists.newArrayList(UserProfileConstants.FIRST_NAME_PROPERTY, UserProfileConstants.LAST_NAME_PROPERTY,
                    UserProfileConstants.FIRM_NAME_PROPERTY, UserProfileConstants.FIRM_ID_PROPERTY,
                    UserProfileConstants.ROLE_PROPERTY, UserProfileConstants.CRD_NUMBER_PROPERTY,
                    UserProfileConstants.MARS_REP_ID_PROPERTY, UserProfileConstants.WEB_ID_PROPERTY,
                    UserProfileConstants.TOP_INDUSTRY_PRODUCER_PROPERTY, UserProfileConstants.OAE_SEGMENT_PROPERTY,
                    UserProfileConstants.EXTERNAL_ID_PROPERTY);

}
