package com.jhi.aem.website.v1.core.service.auth.external;

import java.util.Set;

import com.google.common.collect.Sets;

public interface IsamGroups {

    // Synthetic groups
    String AEM_USER_BLOCKED_GROUP = "jhi-user-blocked";
    String AEM_USER_IN_REGISTRATION_GROUP = "jhi-user-in-registration";

    // Real ISAM groups
    String ISAM_UNVERIFIED_PRO_GROUP = "UnverifiedPro";
    String ISAM_VERIFIED_PRO_GROUP = "VerifiedPro";
    String ISAM_EMPLOYEE_GROUP = "Employee";
    String ISAM_ADMIN_USER_GROUP = "UserAdmin";
    String ISAM_INVESTOR_GROUP = "investor";

    // Real AEM groups
    String AEM_UNVERIFIED_PRO_GROUP = "jhi-unverified-pro";
    String AEM_VERIFIED_PRO_GROUP = "jhi-verified-pro";
    String AEM_EMPLOYEE_GROUP = "jhi-employee";
    String AEM_ADMIN_USER_GROUP = "jhi-useradmin";
    String AEM_INVESTOR_GROUP = "jhi-investor";

    Set<String> AEM_MAPPED_ISAM_GROUPS = Sets.newHashSet(AEM_UNVERIFIED_PRO_GROUP,
            AEM_VERIFIED_PRO_GROUP, AEM_EMPLOYEE_GROUP, AEM_INVESTOR_GROUP);

}
