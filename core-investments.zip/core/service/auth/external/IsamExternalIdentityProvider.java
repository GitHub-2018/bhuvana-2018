package com.jhi.aem.website.v1.core.service.auth.external;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import java.util.concurrent.atomic.AtomicBoolean;

import javax.jcr.Credentials;
import javax.jcr.SimpleCredentials;
import javax.security.auth.login.LoginException;

import org.apache.commons.lang3.StringUtils;

import org.apache.jackrabbit.oak.commons.DebugTimer;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalGroup;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentity;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityException;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityProvider;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityRef;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalUser;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.auth.IsamAuthenticationConfigService;
import com.jhi.aem.website.v1.core.service.auth.Messages;
import com.jhi.aem.website.v1.core.service.i18n.I18nService;
import com.jhi.aem.website.v1.core.service.isam.IsamAdminService;
import com.jhi.aem.website.v1.core.service.isam.IsamException;
import com.jhi.aem.website.v1.core.service.isam.IsamUserService;
import com.jhi.aem.website.v1.core.service.isam.models.GetUserDetailsRequest;
import com.jhi.aem.website.v1.core.service.isam.models.GetUserDetailsResponse;
import com.jhi.aem.website.v1.core.service.isam.models.LoginResponse;
import com.jhi.aem.website.v1.core.utils.AuthHelper;

@Component(
		name="ISAM - Oak External Identity Provider",
		service=ExternalIdentityProvider.class,
		immediate=true,
		configurationPolicy=ConfigurationPolicy.REQUIRE,
		configurationPid="com.jhi.aem.website.v1.core.service.auth.external.IsamExternalIdentityProvider"
		)

@Designate(ocd=IsamExternalIdentityProvider.Config.class)
public class IsamExternalIdentityProvider implements ExternalIdentityProvider, IsamConstants {
    private static final Logger log = LoggerFactory.getLogger(IsamExternalIdentityProvider.class);
    
    public static final String ISAM_EXTERNAL_IDENTITY_PROVIDER = "ISAMExternalIdentityProvider";
    
    private String idp;
    @ObjectClassDefinition(name="ISAM External identity provider Configuration", description="Configurations for ISAM External identity provider")
    public @interface Config{
    	@AttributeDefinition(name="Identity provider name", description="Identity provider name")
    	String name() default ISAM_EXTERNAL_IDENTITY_PROVIDER;
    }
    

   
    private IsamUserService userService;
    @Reference
    public void bindIsamUserService (IsamUserService userService) {
    	this.userService=userService;
    }
    public void unbindIsamUserService (IsamUserService userService) {
    	this.userService=userService;
    }

   
    private IsamAdminService adminService;
    @Reference
    public void bindIsamAdminService (IsamAdminService adminService) {
    	this.adminService=adminService;
    }
    public void unbindIsamAdminService (IsamAdminService adminService) {
    	this.adminService=adminService;
    }

   
    private IsamAuthenticationConfigService isamAuthenticationConfigService;
    @Reference
    public void bindIsamAuthenticationConfigService (IsamAuthenticationConfigService isamAuthenticationConfigService) {
    	this.isamAuthenticationConfigService=isamAuthenticationConfigService;
    }
    public void unbindIsamAuthenticationConfigService (IsamAuthenticationConfigService isamAuthenticationConfigService) {
    	this.isamAuthenticationConfigService=isamAuthenticationConfigService;
    }
   
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory (ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory (ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }

    
    private I18nService i18nService;
    @Reference
    public void bindI18nService (I18nService i18nService) {
    	this.i18nService=i18nService;
    }
    public void unbindI18nService (I18nService i18nService) {
    	this.i18nService=i18nService;
    }

    // Activate and deactivate does not perform any custom action, commenting the methods.
    @Activate
    @Modified
    public void activate(final Config config) {
        doConfigure(config);
        log.info("Activated External Identity Provider: {}", getName());
    }

    private void doConfigure(final Config config) {
    	idp = config.name();
    }

    @Deactivate
    public void deactivate(final Config config) {
    	idp = null;
    }

    @Override
    public String getName() {
        return idp;
    }

    /**
     * Always returns null as ISAM doesn't allow us to get identities without username/password
     */
    @Override
    public ExternalIdentity getIdentity(ExternalIdentityRef ref) throws ExternalIdentityException {
        return null;
    }

    /**
     * Always returns null as ISAM doesn't allow us to get identities without username/password
     */
    @Override
    public ExternalUser getUser(final String userId) throws ExternalIdentityException {
        return null;
    }

    @Override
    public ExternalUser authenticate(Credentials credentials) throws ExternalIdentityException, LoginException {
        if (credentials instanceof SimpleCredentials) {
            SimpleCredentials simpleCreds = (SimpleCredentials) credentials;

            try {

                // Get the generic user token property
                String userToken = (String) simpleCreds.getAttribute(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN);

                // Get the registration phase, if this is a registration action
                IsamRegistrationPhase isamRegistrationPhase =
                        (IsamRegistrationPhase) simpleCreds.getAttribute(ISAM_REGISTRATION_PHASE);

                if (isamRegistrationPhase != null &&
                        !IsamRegistrationPhase.IMPORT_EXISTING_ISAM_USER.equals(isamRegistrationPhase)) {
                    return new IsamRegisteringUser(isamRegistrationPhase, getName(), simpleCreds.getUserID(), userToken,
                            (String) simpleCreds.getAttribute(USER_FIRST_NAME_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_LAST_NAME_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FIRM_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FIRM_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FINANCIAL_ADVISOR_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_CRD_NUMBER_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_MARS_REP_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_WEB_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_TOP_INDUSTRY_PRODUCER_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_OAE_SEGMENT_PARAMETER),
                            (Calendar) simpleCreds.getAttribute(USER_REGISTRATION_DATE)
                    );
                }

                // Detect cookied user who doesn't pass in a password but has a user token
                if (isamRegistrationPhase == null &&
                        (simpleCreds.getPassword() == null || simpleCreds.getPassword().length == 0)
                        && StringUtils.isNotBlank(userToken)) {
                    // This is a cookied user
                    return new IsamLoggedInUser(getName(), simpleCreds.getUserID(), userToken);
                }

                // Login or register through ISAM
                DebugTimer timer = new DebugTimer();
                timer.mark("isamLogin");
                LoginResponse loginResponse = userService.login(simpleCreds);

                // Set the login check flag if required
                AtomicBoolean externalIsamLoginPassedFlag = (AtomicBoolean) simpleCreds.getAttribute(EXTERNAL_ISAM_LOGIN_CHECK);
                if (externalIsamLoginPassedFlag != null) {
                    externalIsamLoginPassedFlag.set(true);
                }

                if (log.isDebugEnabled()) {
                    log.debug("login({}) -> {} {}", new Object[]{getName(), simpleCreds.getUserID(), timer.getString()});
                }

                // Get the user details from ISAM
                List<String> isamUserGroups = getIsamUserGroups(simpleCreds);
                log.debug("Returned for user {} groups: {}", simpleCreds.getUserID(), isamUserGroups);

                // Check if the user has lapsed
                checkUserHasLapsed(simpleCreds, isamUserGroups);

                IsamLoggedInUser loggedInUser;
                if (isamRegistrationPhase == null ||
                        IsamRegistrationPhase.IMPORT_EXISTING_ISAM_USER.equals(isamRegistrationPhase)) {
                    loggedInUser = new IsamImportingUser(userToken, loginResponse,
                            isamRegistrationPhase, getName(), simpleCreds.getUserID(),
                            isamUserGroups,
                            (String) simpleCreds.getAttribute(USER_FIRST_NAME_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_LAST_NAME_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FIRM_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FIRM_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FINANCIAL_ADVISOR_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_CRD_NUMBER_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_MARS_REP_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_WEB_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_TOP_INDUSTRY_PRODUCER_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_OAE_SEGMENT_PARAMETER)
                    );
                } else {
                    loggedInUser = new IsamLoggedInUser(getName(), simpleCreds.getUserID(),
                            isamUserGroups, userToken, loginResponse,
                            (String) simpleCreds.getAttribute(USER_FIRST_NAME_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_LAST_NAME_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FIRM_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FIRM_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_FINANCIAL_ADVISOR_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_CRD_NUMBER_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_MARS_REP_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_WEB_ID_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_TOP_INDUSTRY_PRODUCER_PARAMETER),
                            (String) simpleCreds.getAttribute(USER_OAE_SEGMENT_PARAMETER)
                     );
                }

                return loggedInUser;
            } catch (IsamException e) {
                // Pass the errors back up
                @SuppressWarnings("unchecked")
                List<Object> authErrors = (List<Object>) simpleCreds.getAttribute(EXTERNAL_LOGIN_ERROR_AUTH_INFO_KEY);
                AuthHelper.addMessageWithError(authErrors,
                        e.hasAuthError() ? e.getAuthError() : AuthErrors.INVALID_PASSWORD_ERROR, e.getMessage());
                throw new ExternalIdentityException(e);
            }
        } else {
            throw new LoginException("Unsupported credentials of type " + credentials.getClass().getName());
        }
    }

    /**
     * Gets the ISAM groups this user belongs to. Also this checks the response to see if the user
     * is active in ISAM, if they are not than an {@link IsamException} is thrown.
     *
     * @param simpleCreds
     * @return
     * @throws IsamException
     */
    @SuppressWarnings("unchecked")
    private List<String> getIsamUserGroups(SimpleCredentials simpleCreds) throws IsamException {
        GetUserDetailsRequest userDetailsRequest =
                new GetUserDetailsRequest.Builder().userName(simpleCreds.getUserID()).build();

        try {
            log.debug("Getting user details for {}", simpleCreds.getUserID());
            GetUserDetailsResponse userDetails = adminService.getUserDetails(userDetailsRequest);
            if (userDetails != null && userDetails.isSuccess()) {

                if (userDetails.getDetails() == null || userDetails.getDetails().getUserDetails() == null) {
                    log.warn("Could not get user details, the details are empty: {}", userDetails);
                    return Collections.EMPTY_LIST;
                }

                log.debug("Checking user details, account valid status for {}: {}", simpleCreds.getUserID(), userDetails);
                if (!userDetails.getDetails().getUserDetails().isAccountValid()) {
                    log.error("User account is not valid for {}, setting account to inactive", simpleCreds.getUserID());
                    AuthHelper.setUserActiveStatus(resolverFactory, simpleCreds.getUserID(), false);
                    throw new IsamException(null, AuthErrors.USER_INACTIVE_ERROR,
                            i18nService.getMessageWithKey(
                                    (String) simpleCreds.getAttribute(IsamConstants.CURRENT_REQUEST_URI),
                                    Messages.ISAM_USER_INACTIVE_ERROR));
                }

                // Set the user active status in AEM
                log.debug("Setting account active status for {}", simpleCreds.getUserID());
                AuthHelper.setUserActiveStatus(resolverFactory, simpleCreds.getUserID(), true);

                // Get the user groups from ISAM
                return userDetails.getDetails().getUserGroups();
            } else {
                log.error("Could not get user details for {}", simpleCreds.getUserID());
                throw new IsamException(null, AuthErrors.USER_INVALID_ERROR,
                        i18nService.getMessageWithKey(
                                (String) simpleCreds.getAttribute(IsamConstants.CURRENT_REQUEST_URI),
                                Messages.ISAM_USER_INVALID_ERROR));
            }
        } catch (IsamException e) {
            log.error("Could not get user details for {}", simpleCreds.getUserID());
            throw new IsamException(null, AuthErrors.USER_INVALID_ERROR,
                    i18nService.getMessageWithKey(
                            (String) simpleCreds.getAttribute(IsamConstants.CURRENT_REQUEST_URI),
                            Messages.ISAM_USER_INVALID_ERROR));
        }
    }

    /**
     * If the user is unverified for >72 hours then they must have lapsed
     *
     * @param simpleCreds
     * @param isamUserGroups
     * @throws IsamException
     */
    private void checkUserHasLapsed(SimpleCredentials simpleCreds, List<String> isamUserGroups) throws IsamException {
        final String emailAddress = simpleCreds.getUserID();

        if (isamUserGroups.contains(IsamGroups.ISAM_UNVERIFIED_PRO_GROUP)) {
            log.debug("Checking if user has lapsed {}", emailAddress);

            Object hasLapsed = AuthHelper.executeUserActionInElevatedResourceResolver(resolverFactory,
                    resolver -> {
                        Resource resource = AuthHelper.queryUserResource(resolver, JhiConstants.USER_REP_AUTHORIZABLE_ID,
                                emailAddress);

                        if (resource != null && !ResourceUtil.isNonExistingResource(resource)) {
                            log.debug("Getting created date for user {}", emailAddress);
                            ModifiableValueMap valueMap = AuthHelper.getModifiableMapForUserResource(resource);

                            if (valueMap != null) {
                                Calendar createdDate = (Calendar) valueMap.get(JcrConstants.JCR_CREATED);

                                if (createdDate != null) {
                                    int unverifiedProLapsesAfterHours = isamAuthenticationConfigService.getUnverifiedProLapsesAfterHours();
                                    OffsetDateTime created = createdDate.toInstant().atOffset(ZoneOffset.UTC);
                                    log.debug("Checking date lapsed for user {} (created={}, lapses after hours={})",
                                            new Object[]{emailAddress,
                                                    DateTimeFormatter.ISO_DATE_TIME.format(created),
                                                    unverifiedProLapsesAfterHours});
                                    OffsetDateTime dateLapsed = created.plusHours(unverifiedProLapsesAfterHours);

                                    if (dateLapsed.isBefore(OffsetDateTime.now(ZoneOffset.UTC))) {
                                        log.warn("User {] created on {} has lapsed at {}",
                                                new Object[]{emailAddress,
                                                        DateTimeFormatter.ISO_DATE_TIME.format(created),
                                                        DateTimeFormatter.ISO_DATE_TIME.format(dateLapsed)});
                                        return true;
                                    }
                                } else {
                                    log.warn("User '{}' has no date created field on their record: {}", emailAddress, valueMap);
                                }
                            }
                        }

                        return false;
                    });

            if (Boolean.TRUE.equals(hasLapsed)) {
                log.warn("User {} is still unverified and has lapsed, rejecting their login attempt", emailAddress);
                throw new IsamException(null, AuthErrors.USER_REJECTED_ERROR,
                        i18nService.getMessageWithKey(
                                (String) simpleCreds.getAttribute(IsamConstants.CURRENT_REQUEST_URI),
                                Messages.ISAM_USER_REJECTED_ERROR));
            }
        } else {
            log.debug("User is not in the unverified group, not checking for lapsed time on: {}", emailAddress);
        }
    }

    @Override
    public ExternalGroup getGroup(final String name) throws ExternalIdentityException {
        throw new UnsupportedOperationException("getGroup");
    }


    @Override
    public Iterator<ExternalUser> listUsers() throws ExternalIdentityException {
        throw new UnsupportedOperationException("listUsers");
    }


    @Override
    public Iterator<ExternalGroup> listGroups() throws ExternalIdentityException {
        throw new UnsupportedOperationException("listGroups");
    }
}