package com.jhi.aem.website.v1.core.service.auth.external;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.security.auth.login.LoginException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalGroup;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityException;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalIdentityRef;

import com.google.common.collect.Sets;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.isam.models.LoginResponse;
import com.jhi.aem.website.v1.core.service.user.UserProfileConstants;

public class IsamLoggedInUser extends IsamExternalUser {
	protected final String loginToken;
	protected final String loggedInToken;
	protected final String userId;
	protected final ExternalIdentityRef externalId;
	protected final Map<String,Object> properties;
	protected final List<ExternalIdentityRef> groups;
	
	public static class IsamExternalGroup extends ExternalIdentityRef implements ExternalGroup {

		public IsamExternalGroup(String id, String providerName) {
			super(id, providerName);
		}

		@Override
		public ExternalIdentityRef getExternalId() {
			return this;
		}

		@Override
		public String getPrincipalName() {
			return getId();
		}

		@Override
		public String getIntermediatePath() {
			// TODO: Create intermediate path properly
			return StringUtils.EMPTY;
		}

		@Override
		public Iterable<ExternalIdentityRef> getDeclaredGroups() throws ExternalIdentityException {
			return Collections.EMPTY_SET;
		}

		@Override
		public Map<String, ?> getProperties() {
			return Collections.EMPTY_MAP;
		}

		@Override
		public Iterable<ExternalIdentityRef> getDeclaredMembers() throws ExternalIdentityException {
			return Sets.newHashSet(this);
		}

	}

	/**
	 * User created through a login call
	 * @param string10 
	 * @param string9 
	 * @param string8 
	 * @param string7 
	 * @param string6 
	 * @param string5 
	 * @param string4 
	 * @param string3 
	 * @param string2 
	 * @param string 
	 */
	IsamLoggedInUser(String externalUserRefName, String userId, List<String> userGroups,
			String loggedInToken, LoginResponse loginResponse,
			String firstName, String lastName, String firm,
			String firmId, String financialAdvisor, String crdNumber,
			String marsRepId, String webId,
			String topIndustryProducer, String oaeSegment)
				throws LoginException {
		if (!loginResponse.isSuccess()) {
			throw new LoginException("User " + userId + " cannot login - " +
					loginResponse.getCode() + ": " + loginResponse.getMessage());
		}

		this.userId = userId;
		this.loginToken = loginResponse.getToken();
		this.loggedInToken = loggedInToken;
		this.externalId = new ExternalIdentityRef(userId, externalUserRefName);
		this.groups = userGroups.stream()
				.map(userGroup -> new ExternalIdentityRef(userGroup, externalUserRefName))
				.collect(Collectors.toList());
		this.properties = new HashMap<>();
		this.properties.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, loggedInToken);
		this.properties.put(IsamConstants.NEW_USER_TOKEN_FLAG, Boolean.TRUE);
		this.properties.put(IsamExternalIdentityProvider.LOGIN_TOKEN, loginToken);
		this.properties.put(IsamExternalIdentityProvider.SESSION_START, System.currentTimeMillis());
		this.properties.put(IsamExternalIdentityProvider.SESSION_LAST_CHECKED, System.currentTimeMillis());
		this.properties.put(UserProfileConstants.FIRST_NAME_PROPERTY, firstName);
		this.properties.put(UserProfileConstants.LAST_NAME_PROPERTY, lastName);
		this.properties.put(UserProfileConstants.FIRM_NAME_PROPERTY, firm);
		this.properties.put(UserProfileConstants.FIRM_ID_PROPERTY, firmId);
		this.properties.put(UserProfileConstants.ROLE_PROPERTY, financialAdvisor);
		this.properties.put(UserProfileConstants.CRD_NUMBER_PROPERTY, crdNumber);
		this.properties.put(UserProfileConstants.MARS_REP_ID_PROPERTY, marsRepId);
		this.properties.put(UserProfileConstants.WEB_ID_PROPERTY, webId);
		this.properties.put(UserProfileConstants.TOP_INDUSTRY_PRODUCER_PROPERTY, topIndustryProducer);
		this.properties.put(UserProfileConstants.OAE_SEGMENT_PROPERTY, oaeSegment);
		this.properties.put(UserProfileConstants.EXTERNAL_ID_PROPERTY, generateUniqueExternalUserIdentifier());
	}

	/**
	 * User created through a cookied user
	 */
	public IsamLoggedInUser(String externalUserRefName, String userId, String loggedInToken) {
		this.userId = userId;
		this.loginToken = null;
		this.groups = null;
		this.loggedInToken = loggedInToken;
		this.externalId = new ExternalIdentityRef(userId, externalUserRefName);
		this.properties = new HashMap<>();
		this.properties.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, loggedInToken);
		this.properties.put(IsamConstants.NEW_USER_TOKEN_FLAG, Boolean.FALSE);
		this.properties.put(IsamExternalIdentityProvider.SESSION_START, System.currentTimeMillis());
		this.properties.put(IsamExternalIdentityProvider.SESSION_LAST_CHECKED, System.currentTimeMillis());
		this.properties.put(UserProfileConstants.EXTERNAL_ID_PROPERTY, generateUniqueExternalUserIdentifier());
	}

	@Override
	public ExternalIdentityRef getExternalId() {
		return externalId;
	}

	@Override
	public String getId() {
		return userId;
	}

	@Override
	public String getPrincipalName() {
		return "p_" + getExternalId().getString();
	}

	/**
	 * Groups from the ISAM interface
	 */
	@Override
	public Iterable<ExternalIdentityRef> getDeclaredGroups() throws ExternalIdentityException {
		return groups;
	}

	@Override
	public Map<String, ?> getProperties() {
		return properties;
	}

	public String getLoginToken() {
		return loginToken;
	}

	public String getLoggedInToken() {
		return loggedInToken;
	}

	public String getUserId() {
		return userId;
	}
	
}