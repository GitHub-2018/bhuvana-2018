package com.jhi.aem.website.v1.core.service.auth.external;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.oak.spi.security.authentication.external.ExternalUser;

import com.jhi.aem.website.v1.core.utils.Base58;

public abstract class IsamExternalUser implements ExternalUser {

	/**
	 * Converts the user id to MD5 and then creates a two-level directory structure from
	 * the first few bytes of the MD5
	 */
	@Override
	public final String getIntermediatePath() {
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			// Should never happen
			throw new RuntimeException(e);
		}

		md.update(getId().getBytes());
		byte[] digest = md.digest();
		String hash = DatatypeConverter.printHexBinary(digest);
		return StringUtils.substring(hash, 0, 2) + "/" + StringUtils.substring(hash, 2, 4);
	}
	
	/**
	 * Generates an external ID for this user
	 * @return
	 */
	public final String generateUniqueExternalUserIdentifier() {
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			// Should never happen
			throw new RuntimeException(e);
		}

		md.update(getId().getBytes());
		byte[] digest = md.digest();
		return Base58.encode(digest);
	}

}
