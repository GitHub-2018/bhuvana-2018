package com.jhi.aem.website.v1.core.service.auth;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.jcr.RepositoryException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.map.SingletonMap;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.apache.http.entity.ContentType;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.oak.commons.DebugTimer;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.auth.core.AuthenticationSupport;
import org.apache.sling.auth.core.spi.AuthenticationFeedbackHandler;
import org.apache.sling.auth.core.spi.AuthenticationHandler;
import org.apache.sling.auth.core.spi.AuthenticationInfo;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.JobManager;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.http.HttpContext;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.google.common.net.HttpHeaders;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.user.AuditModel;
import com.jhi.aem.website.v1.core.service.admin.AdminService;
import com.jhi.aem.website.v1.core.service.auth.external.AuthErrors;
import com.jhi.aem.website.v1.core.service.auth.external.IsamConstants;
import com.jhi.aem.website.v1.core.service.auth.external.IsamGroups;
import com.jhi.aem.website.v1.core.service.auth.external.IsamRegistrationPhase;
import com.jhi.aem.website.v1.core.service.crypto.CryptoService;
import com.jhi.aem.website.v1.core.service.datahub.DatahubService;
import com.jhi.aem.website.v1.core.service.datahub.DatahubServiceException;
import com.jhi.aem.website.v1.core.service.datahub.models.FindAdvisorResponse;
import com.jhi.aem.website.v1.core.service.datahub.models.RepLookupRepresentative;
import com.jhi.aem.website.v1.core.service.datahub.models.Representative;
import com.jhi.aem.website.v1.core.service.datahub.models.UserLookupResponse;
import com.jhi.aem.website.v1.core.service.email.impl.EmailJob;
import com.jhi.aem.website.v1.core.service.email.impl.MarketoApiService;
import com.jhi.aem.website.v1.core.service.i18n.I18nService;
import com.jhi.aem.website.v1.core.service.isam.IsamAdminService;
import com.jhi.aem.website.v1.core.service.isam.IsamException;
import com.jhi.aem.website.v1.core.service.isam.IsamUserService;
import com.jhi.aem.website.v1.core.service.isam.impl.IsamErrorCodes;
import com.jhi.aem.website.v1.core.service.isam.models.ChangePasswordResponse;
import com.jhi.aem.website.v1.core.service.isam.models.CompleteForgottenPasswordResponse;
import com.jhi.aem.website.v1.core.service.isam.models.CreateUserRequest;
import com.jhi.aem.website.v1.core.service.isam.models.CreateUserResponse;
import com.jhi.aem.website.v1.core.service.isam.models.GetUserDetailsRequest;
import com.jhi.aem.website.v1.core.service.isam.models.GetUserDetailsResponse;
import com.jhi.aem.website.v1.core.service.isam.models.ValidatePasswordRequest;
import com.jhi.aem.website.v1.core.service.isam.models.ValidatePasswordResponse;
import com.jhi.aem.website.v1.core.service.user.UserInfoService;
import com.jhi.aem.website.v1.core.service.user.UserProfileConstants;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.servlets.ServletHelper;
import com.jhi.aem.website.v1.core.servlets.auth.CUGPermissionsCheckServlet;
import com.jhi.aem.website.v1.core.servlets.redirect.LoginRedirectorServlet;
import com.jhi.aem.website.v1.core.servlets.user.GenerateForgotPassWordLinkServlet;
import com.jhi.aem.website.v1.core.utils.AuthHelper;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.LogUtils;
import com.jhi.aem.website.v1.core.utils.PageUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;

@Component(
		immediate = true,
		name = "ISAM Authentication Handler",
		service = AuthenticationHandler.class,
		configurationPid = "com.jhi.aem.website.v1.core.service.auth.IsamAuthenticationHandler",
		property = {
			Constants.SERVICE_DESCRIPTION + "=Apache Sling Form Based Authentication Handler",
			AuthenticationHandler.PATH_PROPERTY + "=" + JhiConstants.WEBSITE_LOGIN_PATH,
			AuthenticationHandler.PATH_PROPERTY + "=/content/dam",
			AuthenticationHandler.PATH_PROPERTY + "=" + JhiConstants.CSRF_SERVLET_PATH,
			AuthenticationHandler.PATH_PROPERTY + "=" + LoginRedirectorServlet.LOGIN_REDIRECT_SERVLET_PATH,
			AuthenticationHandler.PATH_PROPERTY + "=" + CUGPermissionsCheckServlet.CUG_PERMISSIONS_CHECK_SERVLET_PATH,
			AuthenticationHandler.TYPE_PROPERTY + "=" + JhiConstants.WEBSITE_AUTH_TYPE, "service.ranking:Integer=500"
		})

@Designate(ocd = IsamAuthenticationHandler.Config.class)
public class IsamAuthenticationHandler
		implements AuthenticationHandler, AuthenticationFeedbackHandler, IsamConstants, AuthErrors {
	private static final String DEFAULT_EXCLUSIVE_AUTH_REDIRECT_PATH = "/";
	private static final Logger LOG = LoggerFactory.getLogger(IsamAuthenticationHandler.class);
	private static final String CURRENT_USER_COOKIE = "current-user-cookie";
	private static final String EMAIL_VALIDATION_TOKEN_USER = "email-validation-token-user";
	private static final String UNVERIFIED_FINANCIAL_PROFESSIONAL = "UNVERIFIED_FINANCIAL_PROFESSIONAL";
	private static final String EMPLOYEE = "EMPLOYEE";
	private static final String AUTH_ERRORS_JSON_RETURN_PROPERTY = "authError";
	private static final String REGISTRATION_PHASE_SUCCESS_JSON_RETURN_PROPERTY = "registrationPhaseSuccess";
	private static final String REQUEST_ID_ATTRIBUTE = "REQUEST_ID_ATTRIBUTE";
	private static final long LONG_REQUEST_TIME = 5000;
	private static final long VERY_LONG_REQUEST_TIME = 15000;
	private static final String INVESTOR_USER_TYPE = "investor";
	private static final String OPTIONS_METHOD = "OPTIONS";

	@ObjectClassDefinition(name = "IsamAuthenticationHandlerConfig for JHI Website", description = "Configurations for IsamAuthentication Handler Component")

    public @interface Config {
        final long DEFAULT_LOGIN_COOKIE_TTL_MS = 28800000;
        final String DEFAULT_LOGIN_COOKIE_NAME = "jhi-login";
        final String DEFAULT_LOGIN_COOKIE_PATH = DEFAULT_EXCLUSIVE_AUTH_REDIRECT_PATH;
        final String DEFAULT_LOGIN_COOKIE_DOMAIN = "jhinvestments.com";
        final boolean DEFAULT_EXCLUSIVE_AUTH = false;

        @AttributeDefinition(name = "Login Cookie Expiry Time (ms)", description = "The time in milliseconds after which the login cookie is expired if not accessed")
        long loginCookieExpiryTimeMs() default DEFAULT_LOGIN_COOKIE_TTL_MS;

        @AttributeDefinition(name = "Login Cookie Name", description = "A name for the login cookie")
        String loginCookieName() default DEFAULT_LOGIN_COOKIE_NAME;

        @AttributeDefinition(name = "Login Cookie Path", description = "The cookie path to set for login cookies")
        String loginCookiePath() default DEFAULT_LOGIN_COOKIE_PATH;

        @AttributeDefinition(name = "Login Cookie Domain", description = "The cookie domain to set for login cookies")
        String loginCookieDomain() default DEFAULT_LOGIN_COOKIE_DOMAIN;

        @AttributeDefinition(name = "Exclusive auth handler", description = "When set this signifies that if this handler fires then it will be the only authority for authentication at the fired path")
        boolean exclusiveAuthHandler() default DEFAULT_EXCLUSIVE_AUTH;

        @AttributeDefinition(name = "Login Cookie Path", description = "When the exclusive handler parameter is set then this is used to set the paths for which auth will be exclusive, if empty then all paths fired by this handler will be used", cardinality = Integer.MAX_VALUE)
        String[] exclusiveAuthPaths();
    }

	private long loginCookieExpiryTimeMs;
	private String loginCookieName;
	private String loginCookiePath;
	private String loginCookieDomain;
	private boolean exclusiveAuthHandler;
	private List<String> exclusiveAuthPaths;

	private CryptoService cryptoService;

	@Reference
	public void bindCryptoService(CryptoService cryptoService) {
		this.cryptoService = cryptoService;
	}

	public void unbindCryptoService(CryptoService cryptoService) {
		this.cryptoService = cryptoService;
	}

	private IsamAdminService isamAdminService;

	@Reference
	public void bindIsamAdminService(IsamAdminService isamAdminService) {
		this.isamAdminService = isamAdminService;
	}

	public void unbindIsamAdminService(IsamAdminService isamAdminService) {
		this.isamAdminService = isamAdminService;
	}

	private IsamUserService isamUserService;

	@Reference
	public void bindIsamUserService(IsamUserService isamUserService) {
		this.isamUserService = isamUserService;
	}

	public void unbindIsamUserService(IsamUserService isamUserService) {
		this.isamUserService = isamUserService;
	}

	private IsamAuthenticationConfigService isamAuthenticationConfigService;

	@Reference
	public void bindIsamAuthenticationConfigService(IsamAuthenticationConfigService isamAuthenticationConfigService) {
		this.isamAuthenticationConfigService = isamAuthenticationConfigService;
	}

	public void unbindIsamAuthenticationConfigService(IsamAuthenticationConfigService isamAuthenticationConfigService) {
		this.isamAuthenticationConfigService = isamAuthenticationConfigService;
	}

	private DatahubService datahubService;

	@Reference
	public void bindDatahubService(DatahubService datahubService) {
		this.datahubService = datahubService;
	}

	public void unbindDatahubService(DatahubService datahubService) {
		this.datahubService = datahubService;
	}

	private ResourceResolverFactory resolverFactory;

	@Reference
	public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
		this.resolverFactory = resolverFactory;
	}

	public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
		this.resolverFactory = resolverFactory;
	}

	private UserInfoService userInfoService;

	@Reference
	public void bindUserInfoService(UserInfoService userInfoService) {
		this.userInfoService = userInfoService;
	}

	public void unbindUserInfoService(UserInfoService userInfoService) {
		this.userInfoService = userInfoService;
	}

	private UserProfileService userProfileService;

	@Reference
	public void bindUserProfileService(UserProfileService userProfileService) {
		this.userProfileService = userProfileService;
	}

	public void unbindUserProfileService(UserProfileService userProfileService) {
		this.userProfileService = userProfileService;
	}

	private JobManager jobManager;

	@Reference
	public void bindJobManager(JobManager jobManager) {
		this.jobManager = jobManager;
	}

	public void unbindJobManager(JobManager jobManager) {
		this.jobManager = jobManager;
	}

	private MarketoApiService marketoApiService;

	@Reference
	public void bindMarketoApiService(MarketoApiService marketoApiService) {
		this.marketoApiService = marketoApiService;
	}

	public void unbindMarketoApiService(MarketoApiService marketoApiService) {
		this.marketoApiService = marketoApiService;
	}

	private I18nService i18nService;

	@Reference
	public void bindI18nService(I18nService i18nService) {
		this.i18nService = i18nService;
	}

	public void unbindI18nService(I18nService i18nService) {
		this.i18nService = i18nService;
	}

	private SlingSettingsService slingSettingsService;

	@Reference
	public void bindSlingSettingsService(SlingSettingsService slingSettingsService) {
		this.slingSettingsService = slingSettingsService;
	}

	public void unbindSlingSettingsService(SlingSettingsService slingSettingsService) {
		this.slingSettingsService = slingSettingsService;
	}

	private AtomicLong requestIdentifier = new AtomicLong(0);
	private String hostId;

	private class RequestIdentifier {
		private String requestId;
		private final long requestStarted;

		RequestIdentifier() {
			requestStarted = System.currentTimeMillis();
			requestId = new StringBuilder("#").append(requestIdentifier.incrementAndGet()).toString();
		}

        public void updateRequestIdentifier(String loginActionType, String email) {
            requestId = new StringBuilder(requestId)
                    .append(" (Action=")
                    .append(loginActionType)
                    .append(", Email=")
                    .append(email)
                    .append(")")
                    .toString();
        }
    }

	@Activate
	@Modified
	protected void activate(final Config config) throws IllegalAccessException, LoginException, IOException {
		doConfigure(config);
		LOG.info("Activated/Modified ISAM Authentication Handler");
	}

	@Deactivate
	public void deactivate(final Config config) {
		LOG.info("Deactivating ISAM Authentication handler");
    }
	
    private void doConfigure(final Config config) throws LoginException, IllegalAccessException, IOException {
        loginCookieName = config.loginCookieName();
        loginCookiePath = config.loginCookiePath();
        loginCookieDomain = config.loginCookieDomain();
        exclusiveAuthHandler = config.exclusiveAuthHandler();
        exclusiveAuthPaths = Arrays
                .asList(PropertiesUtil.toStringArray(config.exclusiveAuthPaths(), ArrayUtils.EMPTY_STRING_ARRAY));
        hostId = StringUtils.substring(slingSettingsService.getSlingId(), -4);
        loginCookieExpiryTimeMs = config.loginCookieExpiryTimeMs();
    }

	@Override
	public AuthenticationInfo extractCredentials(HttpServletRequest request, HttpServletResponse response) {
		// Add the request identifier
		addRequestIdentifier(request);

		List<Object> authErrors = new ArrayList<>();
		AuthenticationInfo info = doExtractCredentials(request, response, authErrors);

        // Calculate any CUG redirects based on this request
        String requestUri = StringUtils.substringBeforeLast(request.getRequestURI(), ".");
        String redirectPath =
                AuthHelper.getCUGRedirectPath(resolverFactory, requestUri, DEFAULT_EXCLUSIVE_AUTH_REDIRECT_PATH);

        // If this is an exclusive auth handler and there is a CUG redirect path and auth failed for
        // this request then attempt to redirect
        if (exclusiveAuthHandler && StringUtils.isNotBlank(redirectPath) &&
                (info == null || AuthenticationInfo.FAIL_AUTH.equals(info))) {
            // Does the request match any of the auth paths if the auth paths is non-empty
            if (exclusiveAuthPaths == null || exclusiveAuthPaths.isEmpty() ||
                    exclusiveAuthPaths.stream().anyMatch(p -> StringUtils.startsWith(requestUri, p))) {

				// Redirect for CUG enabled paths only
				LOG.debug("Redirecting CUG enabled resource from '{}' to '{}'", requestUri, redirectPath);
				logRequest(request);
				try {
					response.sendRedirect(redirectPath);
				} catch (IOException e) {
					LOG.error("Could not send redirect to '{}'", redirectPath, e);
				}

				return AuthenticationInfo.DOING_AUTH;
			} else {
				LOG.debug("Path '{}' is not an exclusive auth path", requestUri);
			}
		}

		// Errors were passed back from the process
		if (AuthenticationInfo.FAIL_AUTH.equals(info) && !authErrors.isEmpty()) {
			LOG.debug("Returning auth errors for request, ending request in Sling: {}", authErrors);
			Map<String, Object> jsonReturnMap = new HashMap<>();
			jsonReturnMap.put(AUTH_ERRORS_JSON_RETURN_PROPERTY, authErrors.stream().findFirst().get());
			returnJsonResponse(response, jsonReturnMap);
			logRequest(request);
			// Tell Sling not to send back a response, auth failed
			return AuthenticationInfo.DOING_AUTH;
		}

		LOG.debug("Returning authentication info object to Sling");
		return info;
	}

	private void addRequestIdentifier(HttpServletRequest request) {
		request.setAttribute(REQUEST_ID_ATTRIBUTE, new RequestIdentifier());
	}

	private AuthenticationInfo doExtractCredentials(HttpServletRequest request, HttpServletResponse response,
			List<Object> authErrors) {
		final DebugTimer timer = new DebugTimer();

		try {

            // This is a JHI login/registration action if the path is to "/j_security_check"
            String contentTypeHeader = request.getHeader(HttpHeaders.CONTENT_TYPE);
            // and the content type is JSON
            AuthenticationInfo authInfo = null;
            boolean isSlingSecurityCheckPath =
                    StringUtils.endsWith(request.getRequestURI(), JhiConstants.SLING_SECURITY_CHECK_PATH);
            boolean isJsonContentType =
                    StringUtils.equals(StringUtils.substringBefore(contentTypeHeader, ";"), ContentType.APPLICATION_JSON.getMimeType());
            boolean isOptionsRequest = OPTIONS_METHOD.equals(request.getMethod());
            if (isSlingSecurityCheckPath && (isJsonContentType || isOptionsRequest)) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Checking registration or login action for request : uri='{}', "
                                    + "isSlingSecurityCheckPath={}, isJsonContentType={}",
                            new Object[]{request.getRequestURI(), isSlingSecurityCheckPath, isJsonContentType});
                }
                authInfo = checkJsonRegistrationOrLoginAction(timer, request, response, authErrors);
            } else {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Not checking registration info: uri='{}', isSlingSecurityCheckPath={}, isJsonContentType={}",
                            new Object[]{request.getRequestURI(), isSlingSecurityCheckPath, isJsonContentType});
                }
            }

			// Return on success
			if (authInfo != null && !AuthenticationInfo.FAIL_AUTH.equals(authInfo)) {
				return authInfo;
			}

			// Auth failed
			if (!authErrors.isEmpty()) {
				request.setAttribute(AUTH_ERRORS_JSON_RETURN_PROPERTY, authErrors);
				return authInfo != null ? authInfo : AuthenticationInfo.FAIL_AUTH;
			}

			// Fallback to email validation token validation, so the user can click on the
			// link more than once, as this
			// also creates a login cookie
			timer.mark("email validation token");
			authInfo = extractEmailValidationToken(request);

			if (authInfo == null) {
				// Finally, Check for a login cookie
				timer.mark("login cookie");
				authInfo = getAuthInfoForRequestCookie(request, response);
			}

			// If this is a fail then Sling authentication will continue
			return authInfo;

		} finally {
			if (LOG.isDebugEnabled()) {
				LOG.debug("auth(extract credentials) -> {}", timer.getString());
			}
		}
	}

	private void setNewUserLoginToken(HttpServletRequest request, AuthenticationInfo info) {
		setNewUserLoginToken(request, info, UUID.randomUUID().toString());
	}

	private void setNewUserLoginToken(HttpServletRequest request, AuthenticationInfo info, String token) {
		// The token is passed into the cookie later if auth succeeds
		info.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, token);
		// Tell the sync context not to use this token as the fact that this user exists
		// in AEM
		info.put(IsamConstants.NEW_USER_TOKEN_FLAG, Boolean.TRUE);
		info.put(IsamConstants.EXTERNAL_LOGIN_ERROR_AUTH_INFO_KEY, new ArrayList<>());
		info.put(IsamConstants.CURRENT_REQUEST_URI, request.getRequestURI());
	}

	private AuthenticationInfo extractEmailValidationToken(HttpServletRequest request) {
		String emailValidationToken = request.getParameter("token");

		if (StringUtils.isNotBlank(emailValidationToken)) {
			// Run a query to match the user against the token
			ResourceResolver resolver = null;

            try {
                resolver = resolverFactory.getServiceResourceResolver(
                        Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER));
                if (resolver == null) {
                    LOG.error("Could not retrieve resource resolver for '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER);
                    return null;
                }

                Resource resource = AuthHelper.queryUserResource(resolver, EMAIL_VALIDATION_TOKEN, emailValidationToken);

				if (resource != null) {
					// Get the registration phase for the user
					ValueMap valueMap = resource.getValueMap();

					// Check the validity of the token
					Calendar emailValidationTokenCreated = (Calendar) valueMap.get(EMAIL_VALIDATION_TOKEN_CREATED_DATE);
					if (emailValidationTokenCreated == null) {
						LOG.error("Email validation token is empty for user at '{}'", resource.getPath());
						return null;
					}

					emailValidationTokenCreated.add(Calendar.HOUR_OF_DAY,
							isamAuthenticationConfigService.getEmailValidationTokenValidityHours());
					if (System.currentTimeMillis() > emailValidationTokenCreated.getTimeInMillis()) {
						LOG.error("The email validation token has expired after {} hours",
								isamAuthenticationConfigService.getEmailValidationTokenValidityHours());
						return null;
					}

					// Check this is a user
					if (!StringUtils.equals((String) valueMap.get("jcr:primaryType"), "rep:User")) {
						LOG.warn("Attempting to search for email validation token returned a non-user "
								+ "result in path '{}'", resource.getPath());
						return null;
					}

					// Get the user id
					String userId = (String) valueMap.get("rep:authorizableId");
					if (StringUtils.isBlank(userId)) {
						LOG.warn("Could not get the authorizable identifier for the user at {}", resource.getPath());
						return null;
					}

					// Get the registration phase for this user
					IsamRegistrationPhase registrationPhase = getIsamRegistrationPhaseFromUserValueMap(valueMap);
					if (registrationPhase == null) {
						LOG.warn("ISAM registration phase is empty for user '{}'", userId);
						return null;
					}

                    if (registrationPhase.isEmailValidationLandingState()) {
                        IsamRegistrationPhase nextRegistrationPhase;
                        switch (registrationPhase) {
                            case UNVERIFIED_USER_EMAIL_VALIDATION:
                            case UNVERIFIED_USER_EMAIL_VALIDATED:
                                nextRegistrationPhase = IsamRegistrationPhase.UNVERIFIED_USER_EMAIL_VALIDATED;
                                break;
                            case INVESTOR_USER_EMAIL_VALIDATION:
                            case INVESTOR_USER_EMAIL_VALIDATED:
                                nextRegistrationPhase = IsamRegistrationPhase.INVESTOR_USER_EMAIL_VALIDATED;
                                break;
                            case VERIFIED_USER_EMAIL_VALIDATION:
                            case VERIFIED_USER_EMAIL_VALIDATED:
                                nextRegistrationPhase = IsamRegistrationPhase.VERIFIED_USER_EMAIL_VALIDATED;
                                break;
                            case EMPLOYEE_USER_EMAIL_VALIDATION:
                            case EMPLOYEE_USER_EMAIL_VALIDATED:
                                nextRegistrationPhase = IsamRegistrationPhase.EMPLOYEE_USER_EMAIL_VALIDATED;
                                break;
                            default:
                                LOG.error("Unknown email validation state '{}'", registrationPhase);
                                return null;
                        }

                        if (!registrationPhase.equals(nextRegistrationPhase) &&
                                !registrationPhase.canProceedToState(nextRegistrationPhase)) {
                            LOG.error("Cannot proceed to the next registration state from {} -> {}",
                                    registrationPhase, nextRegistrationPhase);
                            return null;
                        }

						AuthenticationInfo authInfo = new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, userId);
						authInfo.put(ISAM_REGISTRATION_PHASE, nextRegistrationPhase);
						authInfo.put(EMAIL_VALIDATION_TOKEN_USER, true);
						setNewUserLoginToken(request, authInfo);
						LOG.debug("Email validation detected for '{}'", userId);
						return authInfo;
					} else {
						LOG.warn("User '{}' attempted email validation but their registration phase is "
								+ "not in the email validation phase {}", userId, registrationPhase);
					}
				}

			} catch (LoginException e) {
				LOG.error("Could not extract email validation token, unable to get the user management "
						+ "service user '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER, e);
			} finally {
				if (resolver != null) {
					resolver.close();
				}
			}
		}

		return null;
	}

    private AuthenticationInfo checkJsonRegistrationOrLoginAction(DebugTimer timer,
                                                                  HttpServletRequest request, HttpServletResponse response, List<Object> authErrors) {
        Map<String, Object> requestJson;
        try {
            requestJson = ServletHelper.deserializeJsonFromRequestContent(request);
            timer.mark("parsing JSON");
        } catch (JsonSyntaxException | JsonIOException | IOException e) {
            LOG.error("Invalid JSON passed in", e);
            authErrors.add(INVALID_JSON_ERROR);
            return AuthenticationInfo.FAIL_AUTH;
        }

		if (requestJson == null) {
			// No JSON? Pass back.
			LOG.error("Invalid or no JSON passed in, cannot login/register");
			authErrors.add(INVALID_JSON_ERROR);
			return AuthenticationInfo.FAIL_AUTH;
		}

		// Getthe login type out of the JSON
		String loginActionType = (String) requestJson.get(LOGIN_ACTION_PARAMETER);

        if (StringUtils.isNotBlank(loginActionType)) {
            // The registration complete action type relies on the user having been logged in previously
            // through the email validation link
            if (StringUtils.equals(loginActionType, REGISTRATION_COMPLETE_ACTION_TYPE)) {
                LOG.debug("Attempting registration complete action for request");
                AuthenticationInfo regAuthInfo = doRegistrationCompleteAction(request, response, requestJson, authErrors);
                timer.mark("registration complete action");
                return regAuthInfo;
            } else if (StringUtils.equals(loginActionType, CHANGE_PASSWORD_ACTION_TYPE)) {
                LOG.debug("Attempting change password action for request");
                AuthenticationInfo changePasswordInfo = doChangePasswordAction(request, response, requestJson, authErrors);
                timer.mark("change password action");
                return changePasswordInfo;
            }

			// Drop any pre-existing login cookie for all other types of login/registration
			// action
			try {
				dropCredentials(request, response);
				timer.mark("drop credentials");
			} catch (IOException e) {
				LOG.warn("Could not drop previous credentials", e);
			}

            // Mandatory property for other login action types
            String email = StringUtils.lowerCase(AuthHelper.getNotNullParameter(requestJson, authErrors, USER_EMAIL_PARAMETER));

			if (authErrors.isEmpty()) {
				updateRegistrationIdentifier(request, loginActionType, email);

				if (StringUtils.equals(loginActionType, REGISTRATION_ACTION_TYPE)) {
					LOG.debug("Attempting initial registration action for request");
					// A registration action with automatic login
					AuthenticationInfo regAuthInfo = doUserRegistrationAction(request, email, requestJson, authErrors);
					timer.mark("initial register action");
					return regAuthInfo;
				} else if (StringUtils.equals(loginActionType, REGISTRATION_UNVERIFIED_PRO_ACTION_TYPE)) {
                    String userType = (String) requestJson.get(USER_TYPE_PARAMETER);
                    AuthenticationInfo regAuthInfo;
                    if (!StringUtils.equals(userType, INVESTOR_USER_TYPE)) {
                        LOG.debug("Attempting unverified professional registration action for request");
                        regAuthInfo = doUnverifiedProRegisterAction(request, email, requestJson, authErrors);
                        timer.mark("unverified pro register action");
                    } else {
                        LOG.debug("Attempting investor registration action for request");
                        regAuthInfo = doInvestorRegisterAction(request, email, requestJson, authErrors);
                        timer.mark("investor register action");
                    }
                    return regAuthInfo;
                } else if (StringUtils.equals(loginActionType, REGISTRATION_INVESTOR_ACTION_TYPE)) {
                    LOG.debug("Attempting investor registration action for request");
                    AuthenticationInfo regAuthInfo = doInvestorRegisterAction(request, email, requestJson, authErrors);
                    timer.mark("investor register action");
                    return regAuthInfo;
				} else if (StringUtils.equals(loginActionType, REGISTRATION_EMPLOYEE_ACTION_TYPE)) {
					LOG.debug("Attempting unverified professional registration action for request");
					AuthenticationInfo regAuthInfo = doEmployeeRegisterAction(request, email, requestJson, authErrors);
					timer.mark("employee register action");
					return regAuthInfo;
				} else if (StringUtils.equals(loginActionType, LOGIN_ACTION_TYPE)) {
					String password = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_PASSWORD_PARAMETER);
					if (authErrors.isEmpty()) {
						LOG.debug("Attempting login action for request");

						// If the user is an employee they don't have a record in Datahub so we can skip
						// the next step
                        boolean isEmployee =
                                isamAuthenticationConfigService.getValidEmployeeEmailDomainsRegex().matchesAnyPattern(email);

                        // User is being imported from ISAM -> AEM after logging in as it doesn't exist yet in AEM
                        Representative financialAdvisorRep =
                                isEmployee ? null : getRepresentativeInformationFromDatahub(email, authErrors, false);

                        // A plain login
                        AuthenticationInfo info =
                                new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, email, password.toCharArray());
                        addDatahubInfo(email, info, financialAdvisorRep);
                        setNewUserLoginToken(request, info);
                        info.put(EXTERNAL_ISAM_LOGIN_CHECK, new AtomicBoolean(false));
                        timer.mark("login action");
                        return info;
                    }
                } else if (StringUtils.equals(loginActionType, RESET_PASSWORD_ACTION_TYPE)) {
                    LOG.debug("Attempting reset password action for request");
                    AuthenticationInfo resetPasswordInfo = doResetPasswordAction(request, email, requestJson, authErrors);
                    timer.mark("reset password action");
                    return resetPasswordInfo;
                }

			}

			LOG.error("Did not find registration or login action parameter (value='{}') on the JSON request, "
					+ "ignoring this JSON request", loginActionType);
		}

		if (authErrors.isEmpty()) {
			LOG.error("No valid login action (" + LOGIN_ACTION_PARAMETER + ") found in the JSON: {}", requestJson);
			authErrors.add(INVALID_LOGIN_ERROR);
		}

		return AuthenticationInfo.FAIL_AUTH;
	}

	private void updateRegistrationIdentifier(HttpServletRequest request, String loginActionType, String email) {
		RequestIdentifier requestIdentifier = (RequestIdentifier) request.getAttribute(REQUEST_ID_ATTRIBUTE);
		if (requestIdentifier != null) {
			requestIdentifier.updateRequestIdentifier(loginActionType, email);
		}
	}

	private IsamRegistrationPhase getIsamRegistrationPhaseFromUserValueMap(ValueMap valueMap) {
		String isamRegPhase = (String) valueMap.get(ISAM_REGISTRATION_PHASE);
		if (StringUtils.isBlank(isamRegPhase)) {
			return null;
		}

		// Get the registration phase
		return IsamRegistrationPhase.valueOf(isamRegPhase);
	}

	private AuthenticationInfo getAuthInfoForRequestCookie(HttpServletRequest request, HttpServletResponse response) {
		LOG.debug("Attempting cookie auth for request");

		// Check previously logged in through the cookie - get the user's id and use
		// that for the AuthInfo
		Cookie cookie = ServletHelper.getCookie(request, loginCookieName);

		if (cookie != null && cookie.getValue() != null) {
			final DebugTimer timer = new DebugTimer();

			try {
				// Parse the cookie
                Jws<Claims> claimsJws = Jwts.parser()
                        .setSigningKey(cryptoService.getHmacSigningKey())
                        .parseClaimsJws(cookie.getValue());
                timer.mark("JWT parse");
                String cookieId = claimsJws.getBody().getId();
                String cookieUserId = claimsJws.getBody().getSubject();
                String cookieIssuer = claimsJws.getBody().getIssuer();

                if (!StringUtils.equals(hostId, cookieIssuer)) {
                    LOG.debug("Host id mismatch: the cookie contains an issuer '{}' different from the current '{}' for {}, continuing",
                            new Object[]{cookieIssuer, hostId, cookieUserId});
                }

                // Trust the user and pass them through
                AuthenticationInfo info = new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, cookieUserId);
                // Add the login token so that we know this user is logged in already
                info.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, cookieId);
                info.put(CURRENT_USER_COOKIE, cookie.getValue());
                info.put(IsamConstants.CURRENT_REQUEST_URI, request.getRequestURI());
                LOG.debug("User cookie {} detected for '{}'", cookieId, cookieUserId);
                return info;
            } catch (Exception e) {
				// Catch all exceptions here
				LOG.warn("Error parsing cookie and retrieving local cache values", e);
			} finally {
				if (LOG.isDebugEnabled()) {
					LOG.debug("auth(cookie auth) -> {}", timer.getString());
				}
			}

        } else {
            if (LOG.isDebugEnabled()) {
                LOG.debug("No cookie found for cookie auth, existing cookies are: {}", ServletHelper.getCookieNames(request));
            }
        }

		LOG.debug("No auth cookie found for request");

		// No cookie, or cookie auth failed - let auth continue
		return null;
	}

    private AuthenticationInfo doUserRegistrationAction(HttpServletRequest request,
                                                        String email, Map<String, Object> requestJson, List<Object> errors) {
        boolean isEmployee =
                isamAuthenticationConfigService.getValidEmployeeEmailDomainsRegex().matchesAnyPattern(email);

        if (isEmployee) {
            // Employee registration
            LOG.warn("Employee detected for '{}', not validating email address", email);
        }

        if (errors.isEmpty()) {
            // Lookup the email address in ISAM
            LOG.debug("Checking {} for existence in ISAM", email);
            try {
                GetUserDetailsResponse userDetails =
                        isamAdminService.getUserDetails(new GetUserDetailsRequest.Builder().userName(email).build());
                if (userDetails != null && userDetails.getDetails() != null) {
                    // Check if the user was rejected as an unverified financial professional
                    if (!userDetails.getDetails().getUserDetails().isAccountValid()) {
                        LOG.warn("ISAM returned account not valid for '{}'", email);
                        errors.add(USER_INACTIVE_ERROR);
                    }

					// User exists, ask them to reset their password
					LOG.warn("User exists, requesting password reset for '{}'", email);
					errors.add(USER_EXISTS_ERROR);
				}
			} catch (IsamException e) {
				LOG.error("ISAM exception attempting to get user details for '{}'", email, e);
				errors.add(TECHNICAL_ERROR);
			}
		}

		if (errors.isEmpty() && isEmployee) {
			// Employee registration
			LOG.warn("Employee detected for '{}', not validating email address", email);
			errors.add(EMPLOYEE);
		}

		Representative financialAdvisorRep = null;
		if (errors.isEmpty()) {
			financialAdvisorRep = getRepresentativeInformationFromDatahub(email, errors, true);
		}

		if (errors.isEmpty()) {
			// Return auth info. After this login should continue through the ISAM IDP.
			LOG.debug("Initial registration passed, setting up auth info");
			AuthenticationInfo info = new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, email);
			addDatahubInfo(email, info, financialAdvisorRep);
			info.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, generateSignedToken(UUID.randomUUID().toString()));
			info.put(IsamConstants.ISAM_REGISTRATION_PHASE, IsamRegistrationPhase.VERIFIED_USER_EMAIL_VALIDATION);
			info.put(IsamConstants.CURRENT_REQUEST_URI, request.getRequestURI());
			return info;
		}

		LOG.debug("Initial registration failed: {}", errors);
		return AuthenticationInfo.FAIL_AUTH;
	}

	private void addDatahubInfo(String email, AuthenticationInfo info, Representative financialAdvisorRep) {
		if (financialAdvisorRep != null) {
			info.put(USER_FIRST_NAME_PARAMETER, financialAdvisorRep.getFirstName());
			info.put(USER_LAST_NAME_PARAMETER, financialAdvisorRep.getLastName());
			info.put(USER_FIRM_PARAMETER, financialAdvisorRep.getFirmName());
			info.put(USER_FIRM_ID_PARAMETER, financialAdvisorRep.getFirmID());
			info.put(USER_MARS_REP_ID_PARAMETER, financialAdvisorRep.getRepID());
			info.put(USER_WEB_ID_PARAMETER, financialAdvisorRep.getWebID());

			if (StringUtils.isNotBlank(financialAdvisorRep.getRepID())) {
				RepLookupRepresentative rep = lookupUserInDatahub(email, financialAdvisorRep.getRepID());

				if (rep != null) {
					info.put(USER_TOP_INDUSTRY_PRODUCER_PARAMETER, rep.getTopIndustryProducer());
					info.put(USER_OAE_SEGMENT_PARAMETER, rep.getOaeSegment());
				}
			}
		}
	}

	private RepLookupRepresentative lookupUserInDatahub(String email, String repId) {
		if (StringUtils.isBlank(repId)) {
			LOG.debug("Not looking up user info from Datahub for empty repId for user: {}", email);
			return null;
		}

		try {
			UserLookupResponse response = datahubService.lookupUserByRepId(repId);

			List<RepLookupRepresentative> representatives = response.getRepresentatives();
			if (representatives == null || representatives.isEmpty()) {
				// Not a verified financial professional
				LOG.warn("No record found in Datahub for UFP '{}'", email);
			} else if (representatives.size() > 1) {
				// Assume an error as the lookup returned more than one representative
				LOG.warn("Multiple record found in Datahub, assuming UFP '{}'", email);
			} else {
				// Only a single rep exists, this is a verified financial pro
				return representatives.stream().findFirst().get();
			}

		} catch (DatahubServiceException e) {
			LOG.warn("Could not lookup user by rep id for repId={}, email={}", repId, email);
		}

		return null;
	}

    private AuthenticationInfo doUnverifiedProRegisterAction(HttpServletRequest request,
                                                             String email, Map<String, Object> requestJson, List<Object> errors) {
        if (errors.isEmpty()) {
            // AEM properties
            String firstName = AuthHelper.getNotNullParameter(requestJson, errors, USER_FIRST_NAME_PARAMETER);
            String lastName = AuthHelper.getNotNullParameter(requestJson, errors, USER_LAST_NAME_PARAMETER);
            String firm = AuthHelper.getNotNullParameter(requestJson, errors, USER_FIRM_PARAMETER);
            String financialAdvisor = AuthHelper.getNotNullParameter(requestJson, errors, USER_FINANCIAL_ADVISOR_PARAMETER);
            String crdNumber = AuthHelper.getOptionalParameter(requestJson, errors, USER_CRD_NUMBER_PARAMETER);

            if (errors.isEmpty()) {
                // Pass the user through to be created in AEM so that we can send an email
                // Return auth info. After this login should continue through the ISAM IDP.
                AuthenticationInfo info = new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, email);
                info.put(USER_FIRST_NAME_PARAMETER, firstName);
                info.put(USER_LAST_NAME_PARAMETER, lastName);
                info.put(USER_FIRM_PARAMETER, firm);
                info.put(USER_FINANCIAL_ADVISOR_PARAMETER, financialAdvisor);
                info.put(USER_CRD_NUMBER_PARAMETER, crdNumber);
                info.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, generateSignedToken(UUID.randomUUID().toString()));
                info.put(IsamConstants.ISAM_REGISTRATION_PHASE, IsamRegistrationPhase.UNVERIFIED_USER_EMAIL_VALIDATION);
                info.put(IsamConstants.CURRENT_REQUEST_URI, request.getRequestURI());
                return info;
            }
        }
        return AuthenticationInfo.FAIL_AUTH;
    }

    private AuthenticationInfo doInvestorRegisterAction(HttpServletRequest request,
                                                        String email, Map<String, Object> requestJson, List<Object> errors) {
        if (errors.isEmpty()) {
            // AEM properties
            String firstName = AuthHelper.getNotNullParameter(requestJson, errors, USER_FIRST_NAME_PARAMETER);
            String lastName = AuthHelper.getNotNullParameter(requestJson, errors, USER_LAST_NAME_PARAMETER);

            if (errors.isEmpty()) {
                // Pass the user through to be created in AEM so that we can send an email
                // Return auth info. After this login should continue through the ISAM IDP.
                AuthenticationInfo info = new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, email);
                info.put(USER_FIRST_NAME_PARAMETER, firstName);
                info.put(USER_LAST_NAME_PARAMETER, lastName);
                info.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, generateSignedToken(UUID.randomUUID().toString()));
                info.put(IsamConstants.ISAM_REGISTRATION_PHASE, IsamRegistrationPhase.INVESTOR_USER_EMAIL_VALIDATION);
                info.put(IsamConstants.CURRENT_REQUEST_URI, request.getRequestURI());
                return info;
            }
        }
        return AuthenticationInfo.FAIL_AUTH;
    }

    private AuthenticationInfo doEmployeeRegisterAction(HttpServletRequest request,
                                                        String email, Map<String, Object> requestJson, List<Object> errors) {
        if (errors.isEmpty()) {
            // AEM properties
            String firstName = AuthHelper.getNotNullParameter(requestJson, errors, USER_FIRST_NAME_PARAMETER);
            String lastName = AuthHelper.getNotNullParameter(requestJson, errors, USER_LAST_NAME_PARAMETER);

			if (errors.isEmpty()) {
				// Pass the user through to be created in AEM so that we can send an email
				// Return auth info. After this login should continue through the ISAM IDP.
				AuthenticationInfo info = new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, email);
				info.put(USER_FIRST_NAME_PARAMETER, firstName);
				info.put(USER_LAST_NAME_PARAMETER, lastName);
				info.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, generateSignedToken(UUID.randomUUID().toString()));
				info.put(IsamConstants.ISAM_REGISTRATION_PHASE, IsamRegistrationPhase.EMPLOYEE_USER_EMAIL_VALIDATION);
				info.put(IsamConstants.CURRENT_REQUEST_URI, request.getRequestURI());
				return info;
			}

		}

		return AuthenticationInfo.FAIL_AUTH;
	}

    private AuthenticationInfo doResetPasswordAction(HttpServletRequest request, String email,
                                                     Map<String, Object> requestJson, List<Object> authErrors) {
        String password = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_PASSWORD_PARAMETER);
        String confirmPassword = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_CONFIRM_PASSWORD_PARAMETER);
        String resetPasswordToken = AuthHelper.getNotNullParameter(requestJson, authErrors, RESET_PASSWORD_TOKEN);

		// Check passwords match
		if (!StringUtils.equals(password, confirmPassword)) {
			authErrors.add(new AuthHelper.FormError(USER_PASSWORD_PARAMETER, PASSWORDS_DO_NOT_MATCH_ERROR));
		}

        // Validate reset password token       
        if (!(Boolean) AuthHelper.executeUserActionInElevatedResourceResolver(
                resolverFactory, (resolver) ->
                        AuthHelper.validateResetPasswordToken(resolver,
                                isamAuthenticationConfigService, resetPasswordToken, email))) {
            AuthHelper.addMessageWithError(authErrors, INVALID_TOKEN_ERROR, "Invalid reset password token");
        }

		if (authErrors.isEmpty()) {

            // Validate the password
            ValidatePasswordResponse validatePasswordResponse;
            try {
                validatePasswordResponse = isamAdminService.validatePassword(new ValidatePasswordRequest.Builder()
                        .passWord(password).build());
                if (!validatePasswordResponse.isSuccess()) {
                    AuthHelper.addMessageWithError(authErrors,
                            INVALID_PASSWORD_ERROR, validatePasswordResponse.getMessage());
                }
            } catch (IsamException e) {
                LOG.error("Could not validate password in ISAM", e);
                addInvalidPasswordIsamError(e, request, authErrors);
            }
        }

        if (authErrors.isEmpty()) {
            // Change the password in ISAM
            try {
                CompleteForgottenPasswordResponse completeForgotPassword =
                        isamUserService.completeForgotPassword(resetPasswordToken, password);
                if (!completeForgotPassword.isSuccess()) {
                    authErrors.add(TECHNICAL_ERROR);
                } else {
                    LOG.info("Changed password successfully");
                    //invalidate reset password token
                    AuthHelper.executeUserActionInElevatedResourceResolver(
                            resolverFactory, (resolver) -> {
                                try {
                                    return AuthHelper.invalidateResetPasswordToken(
                                            resolver, isamAuthenticationConfigService, email);
                                } catch (IOException e) {
                                    LOG.error("Could not invalidate reset password token for user '{}'", email, e);
                                    return true;
                                }
                            });
                }
            } catch (IsamException e) {
                LOG.error("Could not reset password with token", e);
                addInvalidPasswordIsamError(e, request, authErrors);
            }
        }

		// Go ahead and login if everything went well
		if (authErrors.isEmpty()) {

            // Return auth info. After this login should continue through the ISAM IDP, as if for a
            // normal login
            AuthenticationInfo info =
                    new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, email, password.toCharArray());
            setNewUserLoginToken(request, info, resetPasswordToken);

            // If the user is an employee they don't have a record in Datahub so we can skip
            // the next step
            boolean isEmployee =
                    isamAuthenticationConfigService.getValidEmployeeEmailDomainsRegex().matchesAnyPattern(email);

            // User is being imported from ISAM -> AEM after logging in as it doesn't exist yet in AEM
            Representative financialAdvisorRep =
                    isEmployee ? null : getRepresentativeInformationFromDatahub(email, authErrors, false);

			if (authErrors.isEmpty()) {
				// Add data if we got it from Datahub
				addDatahubInfo(email, info, financialAdvisorRep);

				info.put(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN, generateSignedToken(UUID.randomUUID().toString()));
				info.put(IsamConstants.ISAM_REGISTRATION_PHASE, IsamRegistrationPhase.IMPORT_EXISTING_ISAM_USER);
				info.put(IsamConstants.CURRENT_REQUEST_URI, request.getRequestURI());
				return info;
			}
		}

		return AuthenticationInfo.FAIL_AUTH;
	}

	private Representative getRepresentativeInformationFromDatahub(String email, List<Object> authErrors,
			boolean errorOnDatahubRecordCheck) {
		Representative financialAdvisorRep = null;

		// Does the user exist in Datahub as a verified financial professional?
		try {
			FindAdvisorResponse findAdvisorResponse = datahubService.findAdvisorByEmailAddress(email);

			if (findAdvisorResponse == null) {
				LOG.warn("No record found in Datahub for UFP '{}'", email);
				if (errorOnDatahubRecordCheck) {
					authErrors.add(UNVERIFIED_FINANCIAL_PROFESSIONAL);
				}
			} else {
				List<Representative> representatives = findAdvisorResponse.getRepresentatives();
				if (representatives == null || representatives.isEmpty()) {
					// Not a verified financial professional
					LOG.warn("No record found in Datahub for UFP '{}'", email);
					if (errorOnDatahubRecordCheck) {
						authErrors.add(UNVERIFIED_FINANCIAL_PROFESSIONAL);
					}
				} else if (representatives.size() > 1) {
					// Assume an error as the lookup returned more than one representative
					LOG.warn("Multiple record found in Datahub, assuming UFP '{}'", email);
					if (errorOnDatahubRecordCheck) {
						authErrors.add(UNVERIFIED_FINANCIAL_PROFESSIONAL);
					}
				} else {
					// Only a single rep exists, this is a verified financial pro
					financialAdvisorRep = representatives.stream().findFirst().get();
				}
			}
		} catch (DatahubServiceException e) {
			LOG.error("Datahub exception attempting to find advisor by email address '{}'", email, e);
			authErrors.add(TECHNICAL_ERROR);
		}

		return financialAdvisorRep;
	}

    private AuthenticationInfo doChangePasswordAction(HttpServletRequest request, HttpServletResponse response,
                                                      Map<String, Object> requestJson, List<Object> authErrors) {
        String oldPassword = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_OLD_PASSWORD_PARAMETER);
        String password = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_PASSWORD_PARAMETER);
        String confirmPassword = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_CONFIRM_PASSWORD_PARAMETER);

        // Check passwords match
        if (!StringUtils.equals(password, confirmPassword)) {
            authErrors.add(new AuthHelper.FormError(USER_PASSWORD_PARAMETER, PASSWORDS_DO_NOT_MATCH_ERROR));
        }

        if (authErrors.isEmpty()) {
            // Validate the password
            ValidatePasswordResponse validatePasswordResponse;
            try {
                validatePasswordResponse = isamAdminService.validatePassword(new ValidatePasswordRequest.Builder()
                        .passWord(password).build());
                if (!validatePasswordResponse.isSuccess()) {
                    AuthHelper.addMessageWithError(authErrors,
                            INVALID_PASSWORD_ERROR, validatePasswordResponse.getMessage());
                }
            } catch (IsamException e) {
                LOG.error("Could not validate password in ISAM", e);
                addInvalidPasswordIsamError(e, request, authErrors);
            }
        }

		String email = null;
		if (authErrors.isEmpty()) {

			// Get the current user from the cookie
			AuthenticationInfo currentUserAuthInfo = getAuthInfoForRequestCookie(request, response);

			if (currentUserAuthInfo == null) {
				LOG.error("Cannot complete registration action, no user is present on the request");
				authErrors.add(INVALID_LOGIN_ERROR);
			} else {
				updateRegistrationIdentifier(request, CHANGE_PASSWORD_ACTION_TYPE, currentUserAuthInfo.getUser());

				// Get the email from the logged-in user
				email = currentUserAuthInfo.getUser();

                // Get a resource resolver
                ResourceResolver elevatedResolver = null;
                try {
                    // Get an elevated resource resolver to check the user
                    elevatedResolver = resolverFactory.getServiceResourceResolver(
                            Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER));

                    if (elevatedResolver == null) {
                        LOG.error("Could not retrieve resource resolver for '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER);
                        authErrors.add(TECHNICAL_ERROR);
                    } else {

                        Resource resource =
                                AuthHelper.queryUserResource(elevatedResolver,
                                        JhiConstants.USER_REP_AUTHORIZABLE_ID, email);

						if (resource == null || ResourceUtil.isNonExistingResource(resource)) {
							LOG.error("Cannot find AEM user '{}'", email);
							authErrors.add(INVALID_LOGIN_ERROR);
						} else {

							// Get the login token
							String loginToken = (String) resource.getValueMap().get(IsamConstants.LOGIN_TOKEN);

                            // Change the password in ISAM
                            try {
                                ChangePasswordResponse changePassword =
                                        isamUserService.changePassword(loginToken, oldPassword, password);

                                if (!changePassword.isSuccess()) {
                                    authErrors.add(TECHNICAL_ERROR);
                                } else {
                                    LOG.info("Changed password successfully");
                                }
                            } catch (IsamException e) {
                                LOG.error("Could not change password with token '{}'", loginToken, e);
                                addInvalidPasswordIsamError(e, request, authErrors);
                            }
                        }
                    }
                } catch (LoginException e) {
                    LOG.error("Unable to get the user management service user '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER, e);
                } finally {
                    if (elevatedResolver != null) {
                        elevatedResolver.close();
                    }
                }
            }

		}

        // Go ahead and login if everything went well
        if (authErrors.isEmpty()) {
            // Drop existing creds, these need to be replaced with new login info
            try {
                dropCredentials(request, response);
            } catch (IOException e) {
                LOG.warn("Drop credentials failed", e);
            }

            // Continue to login with the new password
            AuthenticationInfo info =
                    new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE, email, password.toCharArray());
            setNewUserLoginToken(request, info);
            return info;
        }

		return AuthenticationInfo.FAIL_AUTH;
	}

    private void addInvalidPasswordIsamError(IsamException e, HttpServletRequest request, List<Object> authErrors) {
        if (StringUtils.equals(IsamErrorCodes.INVALID_PASSWORD, e.getErrorCode())) {
            String i18nMessage = i18nService.getMessageWithKey(request, Messages.ISAM_2313_ERROR);
            String errorMessage =
                    StringUtils.defaultIfBlank(i18nMessage, e.getMessage());
            AuthHelper.addMessageWithError(authErrors, INVALID_PASSWORD_ERROR, errorMessage);
        } else {
            AuthHelper.addMessageWithError(authErrors, INVALID_PASSWORD_ERROR, e.getMessage());
        }
    }

    private AuthenticationInfo doRegistrationCompleteAction(HttpServletRequest request, HttpServletResponse response,
                                                            Map<String, Object> requestJson, List<Object> authErrors) {
        String password = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_PASSWORD_PARAMETER);
        String confirmPassword = AuthHelper.getNotNullParameter(requestJson, authErrors, USER_CONFIRM_PASSWORD_PARAMETER);

        // Check passwords match
        if (!StringUtils.equals(password, confirmPassword)) {
            authErrors.add(new AuthHelper.FormError(USER_PASSWORD_PARAMETER, PASSWORDS_DO_NOT_MATCH_ERROR));
        }

        if (authErrors.isEmpty()) {

            // Get the current user
            AuthenticationInfo currentUserAuthInfo = getAuthInfoForRequestCookie(request, response);

            if (currentUserAuthInfo == null) {
                LOG.error("Cannot complete registration action, no user is present on the request");
                authErrors.add(INVALID_LOGIN_ERROR);
            } else {
                updateRegistrationIdentifier(request, REGISTRATION_COMPLETE_ACTION_TYPE, currentUserAuthInfo.getUser());

                return (AuthenticationInfo) AuthHelper.executeUserActionInElevatedResourceResolver(resolverFactory, resolver -> {
                    // Get the user for this email
                    Resource userResource = AuthHelper.queryUserResource(resolver, JhiConstants.USER_REP_AUTHORIZABLE_ID,
                            currentUserAuthInfo.getUser());
                    IsamRegistrationPhase nextRegPhase = null;

                    if (userResource != null) {
                        // Get the registration phase for this user
                        IsamRegistrationPhase registrationPhase =
                                getIsamRegistrationPhaseFromUserValueMap(userResource.getValueMap());
                        if (registrationPhase == null) {
                            LOG.warn("ISAM registration phase is empty for user '{}'", currentUserAuthInfo.getUser());
                            return null;
                        }

                        // Work out the completed registration phase
                        switch (registrationPhase) {
                            case UNVERIFIED_USER_EMAIL_VALIDATED:
                                nextRegPhase = IsamRegistrationPhase.UNVERIFIED_USER_COMPLETE_REGISTRATION;
                                break;
                            case INVESTOR_USER_EMAIL_VALIDATED:
                                nextRegPhase = IsamRegistrationPhase.INVESTOR_USER_COMPLETE_REGISTRATION;
                                break;
                            case VERIFIED_USER_EMAIL_VALIDATED:
                                nextRegPhase = IsamRegistrationPhase.VERIFIED_USER_COMPLETE_REGISTRATION;
                                break;
                            case EMPLOYEE_USER_EMAIL_VALIDATED:
                                nextRegPhase = IsamRegistrationPhase.EMPLOYEE_USER_COMPLETE_REGISTRATION;
                                break;
                            default:
                                nextRegPhase = null;
                        }

                        if (nextRegPhase == null) {
                            LOG.warn("Cannot complete registration for user whose state is {}", registrationPhase);
                            return null;
                        }

                        // Get the registration groups
                        // TODO: Only one applies at the moment
                        Set<String> isamRegistrationGroups = nextRegPhase.getIsamGroups();

                        // Get the profile for this user
                        Resource profileResource = userResource.getChild("profile");

                        if (profileResource == null) {
                            LOG.error("Could not find a profile for the user '{}'", currentUserAuthInfo.getUser());
                        } else {

                            ValueMap profileValueMap =
                                    profileResource.adaptTo(ValueMap.class);
                            String firstName = (String) profileValueMap.get(UserProfileConstants.FIRST_NAME_PROPERTY);
                            String lastName = (String) profileValueMap.get(UserProfileConstants.LAST_NAME_PROPERTY);

                            // Execute ISAM create user, so that we can login and the sync handler can then create the user's profile
                            try {

                                // Validate the password
                                try {
                                    ValidatePasswordResponse validatePasswordResponse =
                                            isamAdminService.validatePassword(new ValidatePasswordRequest.Builder()
                                                    .passWord(password).build());
                                    if (!validatePasswordResponse.isSuccess()) {
                                        AuthHelper.addMessageWithError(authErrors,
                                                INVALID_PASSWORD_ERROR, validatePasswordResponse.getMessage());
                                        return AuthenticationInfo.FAIL_AUTH;
                                    }
                                } catch (IsamException e) {
                                    LOG.error("Could not validate password in ISAM", e);
                                    addInvalidPasswordIsamError(e, request, authErrors);
                                }

                                if (authErrors.isEmpty()) {
                                    LOG.info("Registering {} user '{}' in ISAM ({} {})",
                                            new Object[]{nextRegPhase, currentUserAuthInfo.getUser(), firstName, lastName});
                                    CreateUserResponse createUser =
                                            isamAdminService.createUser(
                                                    new CreateUserRequest(firstName, lastName,
                                                            currentUserAuthInfo.getUser(), password));

                                    if (!createUser.isSuccess()) {
                                        LOG.error("Could not complete ISAM registration with email address '{}': {} - {}",
                                                new Object[]{currentUserAuthInfo.getUser(), createUser.getCode(),
                                                        createUser.getMessage()});
                                        authErrors.add(TECHNICAL_ERROR);
                                    } else {
                                        LOG.info("Registered {} user '{}' in ISAM",
                                                nextRegPhase, currentUserAuthInfo.getUser());

                                        String isamGroup = isamRegistrationGroups.iterator().next();
                                        if (AuthHelper.assignUserToIsamGroup(
                                                isamAdminService, marketoApiService,
                                                currentUserAuthInfo.getUser(), userResource,
                                                isamGroup)) {

                                            try {
                                                AuditModel auditModel =
                                                        new AuditModel.Builder()
                                                                .userEmail(currentUserAuthInfo.getUser())
                                                                .activityType(AdminService.AUDIT_ACTIVITY_GROUP_UPDATE)
                                                                .activityMsg("User Group changed after user completed registration")
                                                                .build();
                                                if (!userProfileService.addAuditTrail(userResource, auditModel)) {
                                                    LOG.warn("Could not add user group change audit trail for '{}'",
                                                            currentUserAuthInfo.getUser());
                                                }
                                            } catch (Exception e) {
                                                LOG.warn("Could not add user group change audit trail for '{}'",
                                                        currentUserAuthInfo.getUser(), e);
                                            }

												} else {
													LOG.warn("Could not assign user '{}' to group {} in ISAM",
															currentUserAuthInfo.getUser(), isamGroup);
													authErrors.add(TECHNICAL_ERROR);
												}
											}
										}

                            } catch (IsamException e) {
                                LOG.error("Could not register unverified financial professional with email address '{}'",
                                        currentUserAuthInfo.getUser(), e);
                                if (StringUtils.equals(IsamErrorCodes.INVALID_PASSWORD, e.getErrorCode())) {
                                    addInvalidPasswordIsamError(e, request, authErrors);
                                } else {
                                    authErrors.add(TECHNICAL_ERROR);
                                }
                            }
                        }
                    }

                    if (authErrors.isEmpty()) {
                        // Return auth info. After this login should continue through the ISAM IDP.
                        AuthenticationInfo info =
                                new AuthenticationInfo(JhiConstants.WEBSITE_AUTH_TYPE,
                                        currentUserAuthInfo.getUser(), password.toCharArray());
                        setNewUserLoginToken(request, info);
                        info.put(IsamConstants.USER_REGISTRATION_DATE, Calendar.getInstance());
                        info.put(IsamConstants.ISAM_REGISTRATION_PHASE, nextRegPhase);
                        return info;
                    }

							return AuthenticationInfo.FAIL_AUTH;
						});
			}
		}

		return AuthenticationInfo.FAIL_AUTH;
	}

	private String generateSignedToken(String tokenMessage) {
		SecretKeySpec secretKeySpec = new SecretKeySpec(cryptoService.getHmacSigningKey(),
				cryptoService.getHmacSigningAlgorithmNameForHmacKey());

        Mac mac;
        try {
            mac = Mac.getInstance(cryptoService.getHmacSigningAlgorithmNameForHmacKey());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Could not find message digest type '" +
                    cryptoService.getHmacSigningAlgorithmNameForHmacKey() + "'");
        }

        try {
            mac.init(secretKeySpec);
        } catch (InvalidKeyException e) {
            throw new RuntimeException("Invalid HMAC signing key for digest type '" +
                    cryptoService.getHmacSigningAlgorithmNameForHmacKey() +
                    "' (key length=" + cryptoService.getHmacSigningKey() + ")", e);
        }

        return Base64.encodeBase64String(mac.doFinal(tokenMessage.getBytes()));
    }

    @Override
    public void authenticationFailed(HttpServletRequest request, HttpServletResponse response,
                                     AuthenticationInfo authInfo) {
        try {
            LOG.info("Authentication failed");

            // If the lower down levels gave us back an error then return it to the user
            @SuppressWarnings("unchecked")
            List<Object> authErrors = (List<Object>) authInfo.get(EXTERNAL_LOGIN_ERROR_AUTH_INFO_KEY);
            if (authErrors != null && !authErrors.isEmpty()) {
                // The sendValidationEmail method failed, send back an error response
                Map<String, Object> authErrorMap =
                        new SingletonMap<>(AUTH_ERRORS_JSON_RETURN_PROPERTY, authErrors.stream().findFirst().get());
                returnJsonResponse(response, authErrorMap);
            }
        } finally {
            logRequest(request);
        }
    }

	private void logRequest(HttpServletRequest request) {
		RequestIdentifier identifier = (RequestIdentifier) request.getAttribute(REQUEST_ID_ATTRIBUTE);

		if (identifier != null) {
			long elapsedTime = System.currentTimeMillis() - identifier.requestStarted;
			double elapsedSeconds = elapsedTime / 1000.0d;

			if (elapsedTime >= VERY_LONG_REQUEST_TIME) {
				LOG.warn("{} - Auth Request Time VERY SLOW At {}s", identifier.requestId, elapsedSeconds);
			} else if (elapsedTime >= LONG_REQUEST_TIME) {
				LOG.info("{} - Auth Request Time SLOW At {}s", identifier.requestId, elapsedSeconds);
			} else if (LOG.isTraceEnabled()) {
				LOG.trace("{} - Auth Request Time NORMAL At {}s", identifier.requestId, elapsedSeconds);
			}
		} else {
			LOG.debug("No request identifier found for request");
		}
	}

    private void returnJsonResponse(HttpServletResponse response, Map<String, Object> jsonReturnMap) {
        try {
            ServletHelper.returnJsonResponse(response, jsonReturnMap,
                    AUTH_ERRORS_JSON_RETURN_PROPERTY, HttpStatus.SC_UNAUTHORIZED);
        } catch (IOException e) {
            LOG.error("I/O Exception returning response", e);
        }

		// Commit the response so that the other parts higher up in the
		// SlingAuthenticator don't fire
		try {
			response.flushBuffer();
		} catch (IOException e) {
			LOG.error("Could not commit response", e);
		}
	}

	@Override
	public boolean authenticationSucceeded(HttpServletRequest request, HttpServletResponse response,
			AuthenticationInfo authInfo) {
		try {
			// Check if this was a login/registration or user passed through already with
			// cookie
			String currentUserCookie = (String) authInfo.get(CURRENT_USER_COOKIE);
			if (StringUtils.isNotBlank(currentUserCookie)) {
				printUserCookieDebug(authInfo, currentUserCookie);

				// Retouch login cookie if this is not the CSRF servlet, i.e. only for user
				// activity
				if (!StringUtils.startsWith(request.getRequestURI(), JhiConstants.CSRF_SERVLET_PATH)) {
					// Retouch the TTL on the login cookie
					addLoginCookieToResponse(response, currentUserCookie);
				}

				printAuthSuccessDebug(request, authInfo);

				// This user entered with a cookie so let the usual Sling auth flow continue,
				// the user
				// should now be logged in with the resolver and everything
				return false;
			}

			// Get the registration phase if it exists
			IsamRegistrationPhase isamRegPhase = (IsamRegistrationPhase) authInfo.get(ISAM_REGISTRATION_PHASE);

            // Before we get to here the user has been to the ISAM External IDP and the sync context
            // has sync'd over the user properties. If we asked for this check flag then it must be
            // set by the IDP to true.
            AtomicBoolean externalIsamLoginCheck = (AtomicBoolean) authInfo.get(EXTERNAL_ISAM_LOGIN_CHECK);
            if (externalIsamLoginCheck != null) {
                // If this was not a registration and external login didn't pass then this could be an AEM user
                // login - fail it!
                if (!externalIsamLoginCheck.get()) {
                    LOG.error("Auth for user {} did not pass through external ISAM IDP, failing auth", authInfo.getUser());
                    request.removeAttribute(AuthenticationSupport.REQUEST_ATTRIBUTE_RESOLVER);
                    throw new IllegalStateException("User did not pass through external ISAM IDP, failing auth");
                }
            }

            // If in the email validation registration state then send the email validation mail
            if (isamRegPhase != null && isamRegPhase.isEmailValidationState()) {
                // Send a user registration email if in the validation phase
                if (!sendValidationEmail(request, response, authInfo, isamRegPhase)) {
                    // The sendValidationEmail method failed, send back an error response
                    Map<String, Object> authErrorMap =
                            new SingletonMap<>(AUTH_ERRORS_JSON_RETURN_PROPERTY, TECHNICAL_ERROR);
                    returnJsonResponse(response, authErrorMap);
                    return true;
                }

                // Send back a response indicating that we are in a phase of registration
                Map<String, Object> registrationInfoMap =
                        new SingletonMap<>(REGISTRATION_PHASE_SUCCESS_JSON_RETURN_PROPERTY, isamRegPhase);
                returnJsonResponse(response, registrationInfoMap);

				// At this point in AEM the user is still not logged in or registered but we
				// pass back a success message
				return true;
			}

			// Get the user token (see previously) which is required for the user to be
			// cookied the next time around
			String loginId = (String) authInfo.get(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN);

			// This must have been set in order for the auth to succeed
			if (StringUtils.isBlank(loginId)) {
				LOG.error("Login token for {} is empty, auth cannot continue", authInfo.getUser());
				request.removeAttribute(AuthenticationSupport.REQUEST_ATTRIBUTE_RESOLVER);
				return false;
			}

            // Create JWT with the token and user
            String compactJws = Jwts.builder()
                    .setSubject(authInfo.getUser())
                    .setId(loginId)
                    .setIssuer(hostId)
                    .signWith(cryptoService.getSignatureAlgorithmForHmacKey(), cryptoService.getHmacSigningKey())
                    .compact();
            addLoginCookieToResponse(response, compactJws);
            LOG.debug("Created user cookie, added '{}' for '{}'", loginId, authInfo.getUser());

            // Get the resource resolver which is set up by the SlingAuthenticator after successful
            // login and before this method is invoked
            ResourceResolver resolver =
                    (ResourceResolver) request.getAttribute(AuthenticationSupport.REQUEST_ATTRIBUTE_RESOLVER);

			if (resolver == null) {
				throw new IllegalStateException("No resource resolver for the user has been set up in the "
						+ "request after a successful login");
			}

            // Sets the request attributes required by the OSGi HttpContext interface
            // specification for the handleSecurity method.
            // HttpService API required attributes
            request.setAttribute(HttpContext.REMOTE_USER, authInfo.getUser());
            request.setAttribute(HttpContext.AUTHENTICATION_TYPE, authInfo.getAuthType());
            String requestURI = request.getRequestURI();

            // Check if the user came through an email validation URL
            Object isEmailValidationTokenAuth = authInfo.get(EMAIL_VALIDATION_TOKEN_USER);
            if (Boolean.TRUE.equals(isEmailValidationTokenAuth)) {
                // This user is coming through email validation auth, redirect them to the preceeding path
                String redirectURI =
                        LinkUtil.getLink(resolver,
                                StringUtils.substringBeforeLast(requestURI, JhiConstants.SLING_SECURITY_CHECK_PATH));

				try {
					response.sendRedirect(redirectURI);
					return true;
				} catch (IOException e) {
					LOG.warn("Could not send redirect to '{}'", LogUtils.sanitizeLogInput(redirectURI), e);
				}
			}

			// Return a JSON response in all other cases
			Map<String, Object> userInfoMap = new HashMap<>();
			userInfoService.userInfoToMap(resolver, requestURI, userInfoMap);
			returnJsonResponse(response, userInfoMap);

			// Let everything else pass through, auth success
			return true;
		} finally {
			logRequest(request);
		}
	}

    private void printUserCookieDebug(AuthenticationInfo authInfo, String currentUserCookie) {
        if (LOG.isDebugEnabled()) {
            try {
                Jws<Claims> claimsJws = Jwts.parser()
                        .setSigningKey(cryptoService.getHmacSigningKey())
                        .parseClaimsJws(currentUserCookie);
                String cookieId = claimsJws.getBody().getId();
                String cookieUserId = claimsJws.getBody().getSubject();
                String cookieIssuer = claimsJws.getBody().getIssuer();
                LOG.debug("Retouched user cookie, '{}' issued by '{}' for '{}' ({})",
                        new Object[]{cookieId, cookieIssuer, authInfo.getUser(), cookieUserId});
            } catch (Exception e) {
                LOG.debug("Could not read encoded cookie for {}", authInfo.getUser(), e);
            }
        }
    }

    private void printAuthSuccessDebug(HttpServletRequest request, AuthenticationInfo authInfo) {
        // Print some debugging which helps in analysing user issues
        if (LOG.isDebugEnabled()) {
            ResourceResolver resolver =
                    (ResourceResolver) request.getAttribute(AuthenticationSupport.REQUEST_ATTRIBUTE_RESOLVER);

			if (resolver != null) {
				Authorizable authorizable = resolver.adaptTo(Authorizable.class);
				if (authorizable != null) {
					StringBuilder groups = new StringBuilder();
					try {
						authorizable.declaredMemberOf().forEachRemaining(group -> {
							if (groups.length() > 0) {
								groups.append(", ");
							}
							try {
								groups.append(group.getID());
							} catch (Exception e) {
								LOG.warn("Exception getting group id for {}", authInfo.getUser(), e);
							}
						});
						LOG.debug("User {} is in groups: {}", authInfo.getUser(), groups.toString());
					} catch (RepositoryException e) {
						LOG.warn("Could not get declared members of {}", authInfo.getUser(), e);
					}
				} else {
					LOG.warn("Could not adapt user resolver to authorizable for {}", authInfo.getUser());
				}
			} else {
				LOG.warn("Could not get resource resolver for user {}", authInfo.getUser());
			}
		}
	}

	private void addLoginCookieToResponse(HttpServletResponse response, String encodedCookieValue) {
		Cookie userCookie = new Cookie(loginCookieName, encodedCookieValue);
		userCookie.setPath(loginCookiePath);
		userCookie.setDomain(loginCookieDomain);
		userCookie.setMaxAge((int) (loginCookieExpiryTimeMs / 1000));
		response.addCookie(userCookie);
	}

    private boolean sendValidationEmail(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationInfo authInfo, IsamRegistrationPhase isamRegPhase) {
        String emailValidationToken;
        try {
            emailValidationToken = URLEncoder.encode((String) authInfo.get(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN), JhiConstants.DEFAULT_CHARSET_NAME);
        } catch (UnsupportedEncodingException e) {
            LOG.error("Could not URL encode email validation token '{}' with {}",
                    new Object[]{authInfo.get(JhiConstants.ISAM_AUTH_INFO_USER_TOKEN), JhiConstants.DEFAULT_CHARSET_NAME}, e);
            return false;
        }
        String firstName =
                StringUtils.defaultIfEmpty((String) authInfo.get(USER_FIRST_NAME_PARAMETER),
                        GenerateForgotPassWordLinkServlet.UNKNOWN);
        String lastName =
                StringUtils.defaultIfEmpty((String) authInfo.get(USER_LAST_NAME_PARAMETER),
                        GenerateForgotPassWordLinkServlet.UNKNOWN);
        String leadEmail = authInfo.getUser();

		// Get the link to the path
		String emailValidationPathForRegPhase;
		String group;

        switch (isamRegPhase) {
            case VERIFIED_USER_EMAIL_VALIDATION:
                emailValidationPathForRegPhase =
                        getEmailValidationPathWithResource(request,
                                ResourcesConstants.EMAIL_VALIDATION_VERIFIED_PROFESSIONAL_COMPONENT_REGISTRATION_RESOURCE_TYPE);
                group = IsamGroups.ISAM_VERIFIED_PRO_GROUP;
                break;
            case UNVERIFIED_USER_EMAIL_VALIDATION:
                emailValidationPathForRegPhase =
                        getEmailValidationPathWithResource(request,
                                ResourcesConstants.EMAIL_VALIDATION_UNVERIFIED_PROFESSIONAL_COMPONENT_REGISTRATION_RESOURCE_TYPE);
                group = IsamGroups.ISAM_UNVERIFIED_PRO_GROUP;
                break;
            case INVESTOR_USER_EMAIL_VALIDATION:
                emailValidationPathForRegPhase =
                        getEmailValidationPathWithResource(request,
                                ResourcesConstants.EMAIL_VALIDATION_INVESTOR_COMPONENT_REGISTRATION_RESOURCE_TYPE);
                group = IsamGroups.ISAM_INVESTOR_GROUP;
                break;
            case EMPLOYEE_USER_EMAIL_VALIDATION:
                emailValidationPathForRegPhase =
                        getEmailValidationPathWithResource(request,
                                ResourcesConstants.EMAIL_VALIDATION_EMPLOYEE_REGISTRATION_COMPONENT_RESOURCE_TYPE);
                group = IsamGroups.ISAM_EMPLOYEE_GROUP;
                break;
            default:
                LOG.error("Cannot get email validation path for ISAM registration pgase{}", isamRegPhase);
                return false;
        }

		if (emailValidationPathForRegPhase == null) {
			LOG.error("Cannot get email validation path for registration phase {}", isamRegPhase);
			return false;
		}

        // Create the location for the email confirmation URL
        String emailValidationSubPath = LinkUtil.getLinkWithDefaultResolver(resolverFactory, emailValidationPathForRegPhase);
        StringBuilder emailValidationPath = new StringBuilder();
        if (!StringUtils.startsWith(emailValidationSubPath, "http")) {
            LinkUtil.getHostBaseUrlFromRequest(emailValidationPath, request);
        }

        LOG.trace("Registration confirmation base path: '{}'", emailValidationPath);
        emailValidationPath.append(emailValidationSubPath)
                .append(JhiConstants.SLING_SECURITY_CHECK_PATH)
                .append("?")
                .append(JhiConstants.EMAIL_VALIDATION_QUERY_STRING_TOKEN_PARAMETER)
                .append("=")
                .append(emailValidationToken);

		String regiConfUrl = emailValidationPath.toString();
		LOG.trace("Registration confirmation Url: {}", regiConfUrl);

        Map<String, Object> emailJobProperties = new HashMap<>();
        Set<String> contentSet = new LinkedHashSet<>();
        contentSet.add(regiConfUrl);
        emailJobProperties.put(EmailJob.FIRST_NAME, firstName);
        emailJobProperties.put(EmailJob.LAST_NAME, lastName);
        emailJobProperties.put(EmailJob.LEAD_EMAIL, leadEmail);
        emailJobProperties.put(EmailJob.MREG_STATUS, ACTIVE_USER_STATUS);
        emailJobProperties.put(EmailJob.MREG_GROUP, group);
        emailJobProperties.put(EmailJob.EMAIL_CONTENT, contentSet);
        emailJobProperties.put(EmailJob.CAMPAIGN_TYPE, isamAuthenticationConfigService.getInitialRegistrationMarketoCampaignName());

		Job job = jobManager.addJob(EmailJob.JOB_NAME, emailJobProperties);
		LOG.debug("Added email job with id {} and properties: {}", job.getId(), emailJobProperties);

		return true;
	}

    private String getEmailValidationPathWithResource(HttpServletRequest request, String resourceType) {
        return (String) com.jhi.aem.website.v1.core.utils.ResourceUtil.executeResourceActionInElevatedResourceResolver(
                resolverFactory, (resolver) -> {
                    String requestUri = StringUtils.substringBeforeLast(
                            StringUtils.substringBeforeLast(request.getRequestURI(), "."), JhiConstants.SLING_SECURITY_CHECK_PATH);
                    Resource requestResource = resolver.getResource(requestUri);

                    if (requestResource == null || ResourceUtil.isNonExistingResource(requestResource)) {
                        LOG.error("Could not find request resource for request URI '{}'", LogUtils.sanitizeLogInput(requestUri));
                        return null;
                    }

					Page homePage = PageUtil.getHomePage(requestResource);
					if (homePage == null) {
						LOG.error("Could not get homepage for request resource {}", requestResource.getPath());
						return null;
					}

                    LOG.debug("Getting sub resources in page hierarchy for '{}' at home page='{}'", resourceType, homePage.getPath());
                    Resource resourceResult =
                            com.jhi.aem.website.v1.core.utils.ResourceUtil.getAllSubResourcesInPageHierarchy(resolver, homePage, resourceType)
                                    .stream().findFirst().orElse(null);
                    if (resourceResult == null || ResourceUtil.isNonExistingResource(resourceResult)) {
                        LOG.error("Cannot find email validation resource type '{}'", resourceType);
                        return null;
                    }

					return PageUtil.getContainingPage(resourceResult).getPath();
				});
	}

    @Override
    public boolean requestCredentials(HttpServletRequest request, HttpServletResponse response) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void dropCredentials(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Get the credentials cookie from the request
        Cookie cookie = ServletHelper.getCookie(request, loginCookieName);

        if (cookie != null) {

            try {
                // Parse the cookie
                Jws<Claims> claimsJws = Jwts.parser()
                        .setSigningKey(cryptoService.getHmacSigningKey())
                        .parseClaimsJws(cookie.getValue());
                String cookieId = claimsJws.getBody().getId();

				// Invalidate the cookie
				Cookie deleteCookie = new Cookie(loginCookieName, "");
				deleteCookie.setMaxAge(0);
				deleteCookie.setPath(loginCookiePath);
				deleteCookie.setDomain(loginCookieDomain);
				response.addCookie(deleteCookie);
				LOG.debug("Drop credentials: invalidated cookie for {}", cookieId);

				// Check the user id, if it exists then get the login token and call the logout
				// API
				String cookieUserId = claimsJws.getBody().getSubject();
				AuthHelper.logoutUserFromISAM(isamUserService, resolverFactory, cookieUserId);
			} catch (Exception e) {
				LOG.warn("Could not drop cookie", e);
			}

		} else {
			LOG.debug("Cannot logout, no {} cookie exists to drop", loginCookieName);
		}

        // Is this a logout?
        boolean logoutAction = BooleanUtils.isTrue((Boolean) request.getAttribute(LOGOUT_ACTION_TYPE));
        if (logoutAction) {
            // Commit a response so the SlingAuthenticator doesn't redirect us to home
            ServletHelper.returnJsonResponse(response, new SingletonMap<>("logout", Boolean.TRUE));
        }

	}
}