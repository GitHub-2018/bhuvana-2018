package com.jhi.aem.website.v1.core.service.email.exception;

public class MarketoServiceException extends Exception {

	private static final long serialVersionUID = 1L;

	private ErrorInfo errorInfo;

	public MarketoServiceException() {
		super();
	}

	public MarketoServiceException(String message) {
		super(message);
	}

	public MarketoServiceException(Throwable cause) {
		super(cause);
	}

	public MarketoServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public MarketoServiceException(ErrorInfo errorInfo) {
		this(errorInfo.getStatusCode() + " - " + errorInfo.getStatusMesage());
		this.errorInfo = errorInfo;

	}

	public MarketoServiceException(ErrorInfo errorInfo, Throwable cause) {
		this(errorInfo.getStatusCode() + " - " + errorInfo.getStatusMesage(), cause);
		this.errorInfo = errorInfo;
	}

	public ErrorInfo getErroInfo() {
		return errorInfo;
	}

	public ErrorInfo setErrorInfo(ErrorInfo errorInfo) {
		return this.errorInfo = errorInfo;

	}
}
