package com.jhi.aem.website.v1.core.service.email.exception;

import java.io.Serializable;

public class ErrorInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String statusCode;
    private String statusMessage;

    public ErrorInfo() {
        super();
    }

    public ErrorInfo(String statusCode, String statusMessage) {
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;
    }
    
    public String getStatusCode(){
    	return statusCode;
    }
    
    public void setStatusCode(String statusCode){
    	this.statusCode = statusCode;
    	
    }
    
    public String getStatusMesage(){
    	return statusMessage;
    }
    
    public void setStatusMessage(String statusMessage){
    	this.statusMessage = statusMessage;
    }
}
