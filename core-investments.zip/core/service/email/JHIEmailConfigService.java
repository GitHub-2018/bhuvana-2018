package com.jhi.aem.website.v1.core.service.email;

import java.util.List;

import org.json.JSONException;

import com.google.gson.annotations.SerializedName;

public interface JHIEmailConfigService {

	String EMAIL_TOKEN_SELECTOR = "/token";
	String EMAIL_SEND_SELECTOR = "/send";
	String EMAIL_SERVICE_API_URL = "emailserviceapiurl";
	String EMAIL_SERVICE_UNAME = "emailserviceuname";
	String EMAIL_SERVICE_API_PWD = "emailservicepwd";
	String EMAIL_SERVICE_API_FROM_ADDRESS = "fromaddress";
	String EMPTY_STRING = "";
	String CHANGE_PWD_PAGE_PATH_PROP_NAME = "changepwdpagepath";

	String EMAIL_SERVICE_API_URL_LABEL = "JHI Email Service URL";
	String EMAIL_SERVICE_UNAME_LABEL = "User Name";
	String EMAIL_SERVICE_API_PWD_LABEL = "Pwd";
	String EMAIL_SERVICE_API_FROM_ADDRESS_LABEL = "From Address";
	String CHANGE_PWD_PAGE_PATH_PROP_NAME_LABEL = "Change Pwd Page URL";
	String EMAIL_COMPONENT_NAME = "com.jhi.aem.website.v1.core.service.email.impl.JHIEmailConfigServiceImpl";
	String EMAIL_COMPONENT_LABEL = "JHI Email ConfigService";
	String AUTHORIZATION_HEADER_NAME = "Authorization";
	String CONTENT_TYPE_HEADER_KEY = "Content-Type";
	String APPLICATION_JSON_HEADER_KEY = "application/json";
	long DEFAULT_TIMEOUT_MS = 120000;
	String TOKEN_SUCCESS = "success";
	String TOKEN_SUCCESS_TRUE = "true";
	String TOKEN_KEY = "token";
	String CC_EMAIL = "ccemail";
	String CC_EMAIL_LABEL = "CC Email";

	// marketo variables

	String MARKETO_CLI_ID = "cliid";
	String MARKETO_CLI_SECRT = "clisecrt";
	String MARKETO_REST_IDENTITY = "marketorestidentity";
	String MARKETO_REST_ENDPOINT = "marketorestendpoint";
	String OAUTH_TOKEN_API_PATH = "oauthtokenapi";
	String LEAD_API_PATH = "leadsapi";
	String CAMPAIGN_ID = "campaignid";
	String INCLUDE_TOKEN_LIST = "includetokenslist";

	String CONSTANT_BEARER = "bearer";

	String CLI_ID_LABEL = "Enter Marketo Client Id :";
	String CLI_SECRT_LABEL = "Enter Marketo SECRT Key :";
	String REST_IDENTITY_LABEL = "Enter REST Identity URL :";
	String REST_ENDPOINT_LABEL = "Enter REST Endpoint URL:";
	String OAUTH_TOKEN_API_PATH_LABEL = "Enter Token API URL:";
	String LEAD_API_PATH_LABEL = "Enter Lead API URL:";

	String CAMPAIGN_ID_LABEL = "Add CampaignType and ID with ~ Sympbol";
	String INCLUDE_TOKEN_LIST_LABEL = "Configure tokesn to Include in Campaign :";
	String MARKETO_SUBSCRIPTION_LIST ="mktsubscriptionlist";
	String MARKETO_SUBCSCRIPTION_LIST_LABEL = "Configure Subscription List :";
	String MARKETO_SUB_INPUT_FIELD_NAMES = "mksubscpinputfieldnames";
	String MARKETO_SUB_INPUT_FIELD_NAMES_LABEL = "Configure Subscription Input fields :";
	String MARKETO_SUBSCRIPTION_MAPPING ="mktsubscriptionmapping";
	String MARKETO_SUBCSCRIPTION_MAPPING_LABEL = "Configure Subscription List :";
	String MARKETO_SUBSCR_FIELD_MAPPING ="mktfieldmapping";
	String MARKETO_SUBSCR_FIELD_MAPPING_LABEL = "Configure FieldMapping List :";
	

	String CREATED = "created";
	String SKIPPED = "skipped";
	
	

	String getEmailServiceUName();

	String getEmailServicePwd();

	String getEmailServiceApiUrl();

	String getTokenCredentials() throws JSONException;

	String getFromEmailAddress();

	String getTokenJsonBody();

	String getChangePwdPagePath();

	// marketo API methods.

	String getMktCliId();

	String getMktClientSecrt();

	String getMktRestIdentity();

	String getMktRestEndpoint();

	String getMktOAuthTokenApiUrl();

	String getMktLeadApiUrl();

	String[] getCcEmail();

	String getCampaignId(String campaignName);

	List<String> getIncludeTokens();
	List<String> getMktSubscriptions();
	List<String> getMktSubscpInputFieldNames();
	String getMktSubscription(String fieldName);
	String getMktSubscrFields(String subscriptionname);

}
