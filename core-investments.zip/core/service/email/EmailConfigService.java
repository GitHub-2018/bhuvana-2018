package com.jhi.aem.website.v1.core.service.email;

import java.util.List;
import java.util.Map;

import org.apache.sling.commons.json.JSONException;

import com.google.gson.annotations.SerializedName;

public interface EmailConfigService {

	final String COMPONENT_LABEL = "JHI Mail Configurations";
	final String COMPONENT_NAME="com.jhi.aem.website.v1.core.service.email.impl.EmailConfigServiceImpl";
	
	final String MARKETO_TOKENVALUES = "marketo.tokenValues";
	final String MARKETO_LEAD_EMAIL="marketo.leademail";
	final String MARKETO_LEAD_FIRSTNAME="marketo.lead.firstName";
	final String MARKETO_CC_EMAIL="marketo.cc.email";
	final String MARKETO_SHOW_DEFAULT_LEAD_EMAIL="marketo.isDefaultLead";
	final String MARKETO_SHOW_DEFAULT_CC_EMAIL="marketo.isDefaultCCEMail";
	final String MARKETO_LEAD_API_URL="marketo.leadApiURL";
	final String MARKETO_CAMPAIGN_TYPE="marketo.campaignType";
	final String MARKETO_CAMPAIGN_ID="marketo.campaignId";
	
	
	final String MARKETO_TOKENVALUES_LABEL="Marketo Token Values";
	final String MARKETO_LEAD_EMAIL_LABEL="Default Lead Email Address";
	final String MARKETO_CC_EMAIL_LABEL="Default CC Email Address(es)";
	final String MARKETO_LEAD_EMAIL_FIRSTNAME_LABEL="Default Lead First Name";
	final String MARKETO_SHOW_DEFAULT_LEAD_EMAIL_LABEL="Use Default Lead Email address";
	final String MARKETO_SHOW_DEFAULT_CC_EMAIL_LABEL="Use Default CC Email address(es)";
	final String MARKETO_LEAD_API_URL_LABEL="Lead API URL";
	final String MARKETO_CAMPAIGN_TYPE_LABEL="Marketo Campaign Type";
	final String MARKETO_CAMPAIGN_ID_LABEL="Marketo Campaing ID";
	
	
	
	Map<String,String> getMarketoTokenValues();
	String getDefaultLeadEmail();
	String getDefaultLeadEmailFirstName();
	List<String> getDefaultCCEMail();
	String getLeadAPIUrl();
	String getCampaignType();
	String getCampaignId();
	boolean isDefaultEmailAddress();
	boolean isDefaultCCEMailAddress();

}
