package com.jhi.aem.website.v1.core.service.email.impl;

import java.io.IOException;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.service.email.exception.MarketoServiceException;
import com.jhi.aem.website.v1.core.service.email.models.MktTriggerResponse;

@Component(
		name="Email Job for JHI Website",
		immediate=true,
		service=JobConsumer.class,
		property= {
				JobConsumer.PROPERTY_TOPICS+"="+EmailJob.JOB_NAME
		})

public class EmailJob implements JobConsumer {

	public static final Logger LOGGER = LoggerFactory.getLogger(EmailJob.class);

	public static final String JOB_NAME = "com/jhi/aem/website/emailJob";

	public static final String CC_EMAIL = "ccEmail";
	public static final String CAMPAIGN_TYPE = "campaignType";
	public static final String EMAIL_CONTENT = "emailContent";
	public static final String EMAIL_SUBJECT = "emailSubject";
	public static final String MREG_GROUP = "mregGroup";
	public static final String MREG_STATUS = "mregStatus";
	public static final String POSTAL_CODE = "postalCode";
	public static final String USER_ID = "userId";
	public static final String LEAD_EMAIL = "leadEmail";
	public static final String LAST_NAME = "lastName";
	public static final String FIRST_NAME = "firstName";


	private MarketoApiService marketoApiService;
	@Reference
	public void bindMarketoApiService(MarketoApiService marketoApiService) {
		this.marketoApiService=marketoApiService;
	}
	public void unbindMarketoApiService(MarketoApiService marketoApiService) {
		this.marketoApiService=marketoApiService;
	}

	@Override
	public JobResult process(Job job) {
		if (LOGGER.isDebugEnabled()) {
			StringBuilder jobProps = new StringBuilder("{ ");
			job.getPropertyNames().forEach(propName -> {
				jobProps.append(propName).append("='").append(job.getProperty(propName)).append(" ");
			});
			jobProps.append("}");
			LOGGER.debug("Started processing email job id={}: {}", job.getId(), jobProps);
		}

		MktTriggerResponse mktTriggerResp;
		try {
			mktTriggerResp = marketoApiService.sendCampaignToUser(job.getProperty(FIRST_NAME, String.class),
					job.getProperty(LAST_NAME, String.class), job.getProperty(LEAD_EMAIL, String.class),
					job.getProperty(USER_ID, String.class), job.getProperty(POSTAL_CODE, String.class),
					job.getProperty(MREG_STATUS, String.class), job.getProperty(MREG_GROUP, String.class),
					job.getProperty(EMAIL_SUBJECT, String.class), job.getProperty(EMAIL_CONTENT, Set.class),
					job.getProperty(CAMPAIGN_TYPE, String.class), job.getProperty(CC_EMAIL, String.class));
		} catch (MarketoServiceException | IOException e) {
			LOGGER.error("Exception processing emailJob, id={}", job.getId(), e);
			return JobResult.FAILED;
		}

		if (mktTriggerResp.getSuccess()) {
			LOGGER.debug("Successfully processed emailJob, id={}", job.getId());
			return JobResult.OK;
		} else {
			LOGGER.error("Unsuccessful processing emailJob, id={}, Marketo returned errors: ", job.getId(),
					mktTriggerResp.getErrors().stream().map(e -> e.getMessage()).collect(Collectors.joining(",")));
			return JobResult.FAILED;
		}
	}
}
