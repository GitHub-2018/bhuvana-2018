package com.jhi.aem.website.v1.core.service.email.impl;

import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.crypto.CryptoException;
import com.adobe.granite.crypto.CryptoSupport;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.jhi.aem.website.v1.core.constants.MarketoMailServiceConstatnts;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolService;
import com.jhi.aem.website.v1.core.service.email.EmailConfigService;
import com.jhi.aem.website.v1.core.service.email.JHIEmailConfigService;
import com.jhi.aem.website.v1.core.service.email.exception.ErrorInfo;
import com.jhi.aem.website.v1.core.service.email.exception.MarketoServiceException;
import com.jhi.aem.website.v1.core.service.email.models.LeadsResponse;
import com.jhi.aem.website.v1.core.service.email.models.LeadsResults;
import com.jhi.aem.website.v1.core.service.email.models.MarketoOAuthTokenResponse;
import com.jhi.aem.website.v1.core.service.email.models.MktCreateLeadResponse;
import com.jhi.aem.website.v1.core.service.email.models.MktTriggerResponse;
import com.jhi.aem.website.v1.core.utils.JsonUtil;

@Component(
		name = "JHIMarketoApiService", 
		immediate = true,
		service = MarketoApiService.class,
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Marketo Api Service"
		})

public class MarketoApiService {

	private static final Logger log = LoggerFactory.getLogger(MarketoApiService.class);
	
	private AsyncHttpClientPoolService httpClientPool;
	@Reference
	public void bindAsyncHttpClientPoolService(AsyncHttpClientPoolService httpClientPool) {
		this.httpClientPool=httpClientPool;
	}
	public void unbindAsyncHttpClientPoolService(AsyncHttpClientPoolService httpClientPool) {
		this.httpClientPool=httpClientPool;
	}

	
	private JHIEmailConfigService jhiEmailConfigService;
	@Reference
	public void bindJHIEmailConfigService(JHIEmailConfigService jhiEmailConfigService) {
		this.jhiEmailConfigService=jhiEmailConfigService;
	}
	public void unbindJHIEmailConfigService(JHIEmailConfigService jhiEmailConfigService) {
		this.jhiEmailConfigService=jhiEmailConfigService;
	}
	

	private EmailConfigService emailConfigService;
	@Reference
	public void bindEmailConfigService(EmailConfigService emailConfigService) {
		this.emailConfigService=emailConfigService;
	}
	public void unbindEmailConfigService(EmailConfigService emailConfigService) {
		this.emailConfigService=emailConfigService;
	}
	
	private CryptoSupport cryptoSupport;
	@Reference
	public void bindCryptoSupport(CryptoSupport cryptoSupport) {
		this.cryptoSupport=cryptoSupport;
	}
	public void unbindCryptoSupport(CryptoSupport cryptoSupport) {
		this.cryptoSupport=cryptoSupport;
	}

	/**
	 * This method is used to create or update custom fields on marketo lead
	 * record for given lead email address.
	 * 
	 * @param accessToken
	 * @param leadEmail
	 * @param mRegStatus
	 * @param mRegGroup
	 * @return
	 * @throws MarketoServiceException
	 */
	public MktCreateLeadResponse createUpdateCustomField(String accessToken, String leadEmail, String mRegStatus,
			String mRegGroup) throws MarketoServiceException {
		log.info("Entering createUpdateCustomFields method.");
		MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();
		if (StringUtils.isBlank(accessToken)) {
			log.error("accessToken value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(leadEmail)) {
			log.error("LeadEmail value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "LeadEmail value is blank");
			throw new MarketoServiceException(info);
		}
		log.info("Exiting createUpdateCustomFields method.");
		return mailServiceHelper.doCreateUpdateCustomFieldPost(jhiEmailConfigService, httpClientPool,
				MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS, accessToken, leadEmail, mRegStatus, mRegGroup);

	}

	/**
	 * This method is used to get the access_token by calling
	 * /identity/oauth/token marketo API.
	 * 
	 * @return
	 * @throws MarketoServiceException
	 */
	public MarketoOAuthTokenResponse getMarketoAccessToken() throws MarketoServiceException {
		log.info("Entering getMarketoToken method.");
		MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();

		MarketoOAuthTokenResponse mktOauthResp = mailServiceHelper.getMktAccessToken(jhiEmailConfigService,
				httpClientPool, MarketoOAuthTokenResponse.class);
		if (null != mktOauthResp) {
			if (null != mktOauthResp.getError()
					&& mktOauthResp.getError().equalsIgnoreCase(MarketoMailServiceConstatnts.ERROR_INVALID_CLI)) {
				log.error("Error: Marketo Token API thrown error");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_401,
						mktOauthResp.getErrorDescription());
				throw new MarketoServiceException(info);
			}
		}
		log.info("Exiting getMarketoToken method.");
		return mktOauthResp;
	}

	/**
	 * This method is used to create lead in Marketo
	 * 
	 * @param accessToken
	 * @param leadEmail
	 * @param firstName
	 * @param postalCode
	 * @return
	 * @throws MarketoServiceException
	 */
	public MktCreateLeadResponse createMarketoLead(String accessToken, String leadEmail, String firstName,
			String postalCode) throws MarketoServiceException {
		log.info("Entering createMarketoLead method.");
		if (StringUtils.isBlank(accessToken)) {
			log.error("accessToken value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(leadEmail)) {
			log.error("leadEmail value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "leadEmail value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(firstName)) {
			log.error("firstName value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "firstName value is blank");
			throw new MarketoServiceException(info);
		}
		MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();
		MktCreateLeadResponse createLeadResp = mailServiceHelper.doCreateMarketoLeadPost(jhiEmailConfigService,
				httpClientPool, MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS, accessToken, leadEmail, firstName,
				postalCode);
		log.info("Exiting createMarketoLead method.");
		return createLeadResp;
	}

	/**
	 * This method is used to get leadId from marketo based on lead email.
	 * 
	 * @param accessToken
	 * @param leadEmail
	 * @param ccEmail
	 * @return
	 * @throws MarketoServiceException
	 */
	public LeadsResponse getMareketoLeadIdS(String accessToken, String leadEmail, String ccEmail)
			throws MarketoServiceException {
		log.info("Entering createMarketoLead method.");
		if (StringUtils.isBlank(accessToken)) {
			log.error("accessToken value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(leadEmail)) {
			log.error("LeadEmail value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "LeadEmail value is blank");
			throw new MarketoServiceException(info);
		}
		MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();
		GsonBuilder gsonBuilder = new GsonBuilder();
		LeadsResponse leadsResp = mailServiceHelper.getLeadIdS(gsonBuilder, jhiEmailConfigService, httpClientPool,
				LeadsResponse.class, accessToken, leadEmail, ccEmail);
		log.info("Exiting createMarketoLead method.");
		return leadsResp;

	}

	/**
	 * This method is used to trigger campaign mail based on campaign type.
	 * 
	 * @param accessToken
	 * @param firstName
	 * @param lastName
	 * @param userId
	 * @param campaignType
	 * @param emailSubject
	 * @param leadIDCSValues
	 * @param tokenCSValues
	 * @return
	 * @throws MarketoServiceException
	 */
	public MktTriggerResponse triggerMarketoCampaign(String accessToken, String firstName, String lastName,
			String userId, String campaignType, String emailSubject, String leadIDCSValues, Set<String> tokenCSValues)
			throws MarketoServiceException {
		log.info("Entering triggerMarketoCampaign method.");
		MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();
		GsonBuilder gsonBuilder = new GsonBuilder();
		if (StringUtils.isBlank(accessToken)) {
			log.error("accessToken value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(firstName)) {
			log.error("firstName value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "firstName value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(campaignType)) {
			log.error("campaignType value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "campaignType value is blank");
			throw new MarketoServiceException(info);
		} else {
			String campaignId = jhiEmailConfigService.getCampaignId(campaignType);
			if (StringUtils.isBlank(campaignId)) {
				log.error("invlaid campaignType values sent in request");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "Invalid CampaignType");
				throw new MarketoServiceException(info);
			}
		}
		if (StringUtils.isBlank(leadIDCSValues)) {
			log.error("lead values are blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "lead values are blank");
			throw new MarketoServiceException(info);
		}
		/*if (StringUtils.isBlank(tokenCSValues)) {
			log.error("token values are blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "token values are blank");
			throw new MarketoServiceException(info);
		}*/
		log.info("tokenCSValues == " +  tokenCSValues);
		if(null == tokenCSValues ||tokenCSValues.isEmpty()) {
			log.error("token values are blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "token values are blank");
			throw new MarketoServiceException(info);
		}

		log.info("Exiting triggerMarketoCampaign method.");
		return mailServiceHelper.doCampaignTriggerPost(gsonBuilder, jhiEmailConfigService, httpClientPool, accessToken,
				campaignType, emailSubject, firstName, lastName, userId, leadIDCSValues, tokenCSValues);

	}

	public void invokeCampaign(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws MarketoServiceException, IOException {
		log.info("Entering invokeCampaign method.");
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String leadEmail = request.getParameter("leademail");
		String userId = request.getParameter("userid");
		String postalCode = request.getParameter("postalcode");
		String mregStatus = request.getParameter("mregstatus");
		String mregGroup = request.getParameter("mreggroup");
		String emailSubject = request.getParameter("emailsubject");
		String emailContent = request.getParameter("emailcontent");
		 //##Fix for ticket 1930
	    // call convertTokenstoSet will to convert token string to set object
		Set<String> emailContentSet = convertTokenstoSet(emailContent);
		String campaignType = request.getParameter("campaigntype");
		String ccEmail = request.getParameter("ccemail");
		MktTriggerResponse mktTriggerResp = sendCampaignToUser(firstName, lastName, leadEmail, userId, postalCode,
				mregStatus, mregGroup, emailSubject, emailContentSet, campaignType, ccEmail);
		response.getWriter().write(new Gson().toJson(mktTriggerResp));
		log.info("Exiting invokeCampaign method.");

	}
	
	 //##Fix for ticket 1930
    // convertTokenstoSet will convert a give token with comma separated value to a set object 
	private Set<String> convertTokenstoSet(String tokens) {
		Set<String> tokenSet = new LinkedHashSet<String>();
		if(StringUtils.isBlank(tokens)) {
			return tokenSet;
		}else if(tokens.contains(",")){
			String[] tokenArr = tokens.split(",");
			for(int count=0;count<tokenArr.length;count++) {
				tokenSet.add(tokenArr[count]);
			}
			
		}else {
			tokenSet.add(tokens);
		}
		
		return tokenSet;
	}

	/**
	 * This method is used to invoke the marketo API to send mail.
	 * 
	 * @param firstName
	 * @param lastName
	 * @param leadEmail
	 * @param userId
	 * @param postalCode
	 * @param mregStatus
	 * @param mregGroup
	 * @param emailSubject
	 * @param emailContent
	 * @param campaignType
	 * @param ccEmail
	 * @return
	 * @throws MarketoServiceException
	 * @throws IOException
	 */
	public MktTriggerResponse sendCampaignToUser(String firstName, String lastName, String leadEmail, String userId,
			String postalCode, String mregStatus, String mregGroup, String emailSubject, Set<String> emailContent,
			String campaignType, String ccEmail) throws MarketoServiceException, IOException {
		log.info("Entering sendCampaignToUser method.");
		long startTime = System.currentTimeMillis();
		String accessToken = null;
		boolean isLeadCreated = false;
		LeadsResponse leadsResp = null;
		String leadIDCSValues = "";
		GsonBuilder gsonBuilder = new GsonBuilder();
		MarketoOAuthTokenResponse mOAResp = getMarketoAccessToken();

		if (null != mOAResp) {
			accessToken = mOAResp.getAccessToken();
		} else {
			log.warn("Could not get Marketo access token");
			throw new MarketoServiceException("Could not get Marketo access token");
		}

		MktCreateLeadResponse createLeadResp = createMarketoLead(accessToken, leadEmail, firstName, postalCode);
		if (null != createLeadResp) {
			if (createLeadResp.getSuccess() == false) {
				log.error("CreateLead API is not success.Thrown errors");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_200,
						gsonBuilder.create().toJson(createLeadResp));
				throw new MarketoServiceException(info);
			} else {
				String status = createLeadResp.getResult().get(0).getStatus();
				log.info("status : {}", status);
				if (MarketoMailServiceConstatnts.SKIPPED.equalsIgnoreCase(status)
						|| MarketoMailServiceConstatnts.CREATED.equalsIgnoreCase(status)) {
					isLeadCreated = true;
				}
			}
		}
		if (isLeadCreated) {
			createUpdateCustomField(accessToken, leadEmail, mregStatus, mregGroup);
			leadsResp = getMareketoLeadIdS(accessToken, leadEmail, ccEmail);
		}

		if (null != leadsResp) {
			if (leadsResp.getSuccess() == false) {
				log.error("leadsFilter Email API is not success.Thrown errors");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_200,
						gsonBuilder.create().toJson(leadsResp));
				throw new MarketoServiceException(info);
			}

			StringBuilder leadIDCSValuesBuilder = new StringBuilder();
			List<LeadsResults> leadsResult = leadsResp.getResult();
			for (int i = 0; i < leadsResult.size(); i++) {
				String email = leadsResult.get(i).getEmail();
				int id = leadsResult.get(i).getId();
				log.info("lead email : {} ", email);
				log.info("lead id : {} ", id);
				leadIDCSValuesBuilder.append(String.valueOf(id));
				if (i < leadsResult.size() - 1) {
					leadIDCSValuesBuilder.append(",");
				}
			}

			leadIDCSValues = leadIDCSValuesBuilder.toString();
		}

		MktTriggerResponse triggerMarketoCampaign = triggerMarketoCampaign(accessToken, firstName, lastName, userId,
				campaignType, emailSubject, leadIDCSValues, emailContent);
		long endTime = System.currentTimeMillis();
		log.debug("Time taken to sendCampaignToUser : " + (endTime - startTime)/1000);
		log.info("Exiting sendCampaignToUser method.");
		return triggerMarketoCampaign;
	}

	public JsonObject getSubscritionList(String accessToken, String leadEmail,String manageSubFlag) throws MarketoServiceException {
		log.info("Entering getSubscritionList method.");
		log.info("leademail : {} ", leadEmail);
		if (StringUtils.isBlank(accessToken)) {
			log.error("accessToken value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(leadEmail)) {
			log.error("LeadEmail value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "LeadEmail value is blank");
			throw new MarketoServiceException(info);
		}
		MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();
		GsonBuilder gsonBuilder = new GsonBuilder();
		JsonObject leadsResp = mailServiceHelper.getCustomFields(gsonBuilder, jhiEmailConfigService, httpClientPool,
				accessToken, leadEmail,manageSubFlag);
		log.info("Exiting getSubscritionList method.");
		return leadsResp;

	}

	public MktCreateLeadResponse updateMktSubscriptions(String accessToken, String subscriptions)
			throws MarketoServiceException, CryptoException {
		log.info("Entering updateMktSubscriptions method.");
		String leadEmail = null;
		JsonObject subscriptionsjObj = null;
		String leadCSValues = "";
		MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();
		GsonBuilder gsonBuilder = new GsonBuilder();
		if (StringUtils.isBlank(accessToken)) {
			log.error("accessToken value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
			throw new MarketoServiceException(info);
		}

		log.info("subscriptions json object value string :::::: {} ", subscriptions);
		JsonParser jsonParser = new JsonParser();
		JsonElement subsciptionsJsonEl;
		try {
			subsciptionsJsonEl = jsonParser.parse(JsonUtil.getJsonContent(new StringReader(subscriptions)));
		} catch (JsonSyntaxException | IOException e) {
			log.error("Could not parse subscriptions JSON", e);
			throw new MarketoServiceException(e);
		}
		subscriptionsjObj = subsciptionsJsonEl.getAsJsonObject();
		leadEmail = subscriptionsjObj.get("leademail").getAsString();
		log.info("leademail : {} ", leadEmail);
		if(StringUtils.isNotBlank(leadEmail)) {
			leadEmail = cryptoSupport.unprotect(leadEmail);
		}
		log.info("leademail after crypto : {} ", leadEmail);
		if (StringUtils.isBlank(leadEmail)) {
			log.error("leadEmail value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "leadEmail value is blank");
			throw new MarketoServiceException(info);
		}
		log.info("Exiting updateMktSubscriptions method.");
		MktCreateLeadResponse leadUpdateResp = mailServiceHelper.updateMktSubscriptions(jhiEmailConfigService,
				httpClientPool, MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS, accessToken, leadEmail,
				subscriptionsjObj);
		boolean success = leadUpdateResp.getSuccess();
		if (success) {
			log.info("Marketo subscriptions updated.");
			LeadsResponse leadsResp = getMareketoLeadIdS(accessToken, leadEmail, null);
			if (null != leadsResp) {
				if (leadsResp.getSuccess() == false) {
					log.error("leadsFilter Email API is not success.Thrown errors");
					ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_200,
							gsonBuilder.create().toJson(leadsResp));
					throw new MarketoServiceException(info);
				}

				StringBuilder leadIDCSValuesBuilder = new StringBuilder();
				List<LeadsResults> leadsResult = leadsResp.getResult();
				for (int i = 0; i < leadsResult.size(); i++) {
					String email = leadsResult.get(i).getEmail();
					int id = leadsResult.get(i).getId();
					log.info("lead email : {} ", email);
					log.info("lead id : {} ", id);
					leadIDCSValuesBuilder.append(String.valueOf(id));
					if (i < leadsResult.size() - 1) {
						leadIDCSValuesBuilder.append(",");
					}
				}
				leadCSValues = leadIDCSValuesBuilder.toString();
				mailServiceHelper.doCampaignTriggerPost(gsonBuilder, jhiEmailConfigService, httpClientPool, accessToken,
						"updatesubcription", null, null, null, null, leadCSValues, null);
			}
		}
		return leadUpdateResp;
	}
	
	
	public MktTriggerResponse landingpagecontactus( Map<String,Object> detailsMap)
			throws MarketoServiceException {
		log.info("!!!!Marketo Api Service : Entering landingpagecontact us !!!!");
		long startTime = System.currentTimeMillis();
		
		MktTriggerResponse triggerMarketoCampaign = null;
		if(null != detailsMap && !detailsMap.isEmpty()) {
			
			MarketoOAuthTokenResponse mOAResp = getMarketoAccessToken();
			String accessToken="";
			
			if (null != mOAResp) {
				accessToken = mOAResp.getAccessToken();
			} else {
				log.info("!!!!Marketo Api Service : Could not get Marketo access token !!!!");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
				throw new MarketoServiceException(info);
			}
			
			
			
			
			if (StringUtils.isBlank(accessToken)) {
				log.error("Marketo API Service : AccessToken value is blank");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "accessToken value is blank");
				throw new MarketoServiceException(info);
			}

			MarketoMailServiceHelper mailServiceHelper = new MarketoMailServiceHelper();
			GsonBuilder gsonBuilder = new GsonBuilder();
			Boolean isDefaultLeadEnabled = emailConfigService.isDefaultEmailAddress();
			LeadsResponse leadResponse = null;
			
			if(!isDefaultLeadEnabled) {
				
				leadResponse = getLeadIdFromMarketo(accessToken,false);
			}
			
			//LeadsResponse leadResponse = getOrCreateLeadId(accessToken, isDefaultLeadEnabled);
			
			if(!(null != leadResponse && leadResponse.getSuccess() && !leadResponse.getResult().isEmpty()))
			{
				
				log.debug("Call the Marketo API to get Lead ID based on email ID");
				leadResponse = getLeadIdFromMarketo(accessToken,true);
				if(!(null != leadResponse && leadResponse.getSuccess()&&!leadResponse.getResult().isEmpty())) {
					log.debug("Create a new marketo Lead ID");
					leadResponse = createLeadIdInMarketo(accessToken);
				}
			}
			if (null != leadResponse) {
				if (leadResponse.getSuccess() == false) {
					log.error("Unable to retrieve leadEmail id from Marketo Service");
					ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_200,
							gsonBuilder.create().toJson(leadResponse));
					throw new MarketoServiceException(info);
				}

				StringBuilder leadsIdBuilder = new StringBuilder();
				List<LeadsResults> leadsResult = leadResponse.getResult();
				for (int i = 0; i < leadsResult.size(); i++) {
					String email = leadsResult.get(i).getEmail();
					int id = leadsResult.get(i).getId();
					log.info("lead email : {} ", email);
					log.info("lead id : {} ", id);
					leadsIdBuilder.append(String.valueOf(id));
					if (i < leadsResult.size() - 1) {
						leadsIdBuilder.append(",");
					}
				}
				String leadIds = leadsIdBuilder.toString();
				Map<String,String> tokenMap = emailConfigService.getMarketoTokenValues();
				 triggerMarketoCampaign = mailServiceHelper.doLandingPageTriggerPost(gsonBuilder, jhiEmailConfigService, httpClientPool, accessToken,
							emailConfigService.getCampaignId(), leadIds, detailsMap,tokenMap);
				long endTime = System.currentTimeMillis();
				log.debug("!!!! Marketo API Service : Time taken to sendCampaignToUser : !!!!" + (endTime - startTime)/1000);
				log.info("!!!! Marketo API Service :Exiting landingpagecontactus method.!!!!");
			}
		
		}else {
			log.error("Marketo API Service: Contact Details info missing or null");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "Contact details is blank");
			throw new MarketoServiceException(info);
		}
		
		return triggerMarketoCampaign;
	}
	
	private LeadsResponse getLeadIdFromMarketo(String accessToken,Boolean filterType) throws MarketoServiceException {
		log.debug("Entering getLeadIdFromMarketo() method in Marketo API Service");
		final String LEAD_API_URL_ID = emailConfigService.getLeadAPIUrl()+"?access_token={1}";
		final String LEAD_API_URL_FILTER_TYPE =  jhiEmailConfigService.getMktLeadApiUrl() + "?access_token={1}&filterType=email&filterValues={0}";
		
		MarketoMailServiceHelper serviceHelper = new MarketoMailServiceHelper();
		GsonBuilder gsonBuilder = new GsonBuilder();
		LeadsResponse leadResponse=null;
		if(filterType) {
			
			String defaultEmailId = emailConfigService.getDefaultLeadEmail();
			generateEmailIdList(defaultEmailId);
			log.debug("Call the Marketo API to get Lead ID based on Email :"+ defaultEmailId);
			if(StringUtils.isBlank(defaultEmailId)) {
				log.error("Default Email Id (and/or) CC Email address are blank");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "Default Email Id (and/or) CC Email address are blank");
				throw new MarketoServiceException(info);	
			}
			// call getLeadId from Marketo form filterType
			leadResponse = serviceHelper.getLeadIdFromMarketo(gsonBuilder, accessToken,defaultEmailId,LEAD_API_URL_FILTER_TYPE,jhiEmailConfigService, httpClientPool);
			
		}else {
			
			String campaignId = emailConfigService.getCampaignId();
			log.debug("Call the Marketo API to get Lead ID based on Campaign Id : "+ campaignId);
			if(StringUtils.isBlank(campaignId)){
				log.error("Campaign Id value is blank");
				ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "Campaign id value is not configured");
				throw new MarketoServiceException(info);
			}
			leadResponse = serviceHelper.getLeadIdFromMarketo(gsonBuilder, accessToken,campaignId,LEAD_API_URL_ID,jhiEmailConfigService, httpClientPool);
			
		}
		
		log.debug("Entering getLeadIdFromMarketo() method in Marketo API Service");
		return leadResponse;
	}
	
	private LeadsResponse createLeadIdInMarketo(String accessToken) throws MarketoServiceException {
		MarketoMailServiceHelper serviceHelper = new MarketoMailServiceHelper();
		GsonBuilder gsonBuilder = new GsonBuilder();
		
		String leadFirstName = emailConfigService.getDefaultLeadEmailFirstName();
		String leadEmail = emailConfigService.getDefaultLeadEmail();
		log.info("MarketoAPI Service Email:"+ leadEmail);
		log.info("MarketoAPI Service First name:"+ leadFirstName);
		if (StringUtils.isBlank(leadEmail)) {
			log.error("leadEmail value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "leadEmail value is blank");
			throw new MarketoServiceException(info);
		}
		if (StringUtils.isBlank(leadFirstName)) {
			log.error("firstName value is blank");
			ErrorInfo info = new ErrorInfo(MarketoMailServiceConstatnts.STATUS_CODE_400, "firstName value is blank");
			throw new MarketoServiceException(info);
		}
		
		log.debug("Create a new lead Id in marketo for email :"+leadEmail);
		LeadsResponse leadResponse = serviceHelper.createLeadId(gsonBuilder, accessToken,leadEmail,leadFirstName,jhiEmailConfigService, httpClientPool);
		return leadResponse;
	}
	
	private void generateEmailIdList (String defaultEmailId) {
		if (emailConfigService.isDefaultCCEMailAddress() && null != defaultEmailId) {
			List<String> ccEmails = emailConfigService.getDefaultCCEMail(); 
			String ccEmail = String.join(",", ccEmails);
			if(StringUtils.isNotBlank(ccEmail))
				defaultEmailId = defaultEmailId+","+ccEmail;
			
		}
		
	}
	
	
	

	@Activate
	protected void activate() {
		log.info("activate method called.");
	}

}
