/**
 * 
 */
package com.jhi.aem.website.v1.core.service.email.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.constants.IsamUserProfileConstants;
import com.jhi.aem.website.v1.core.service.email.JHIEmailConfigService;

/**
 * @author singave
 *
 */
@Component(
		name = JHIEmailConfigService.EMAIL_COMPONENT_NAME,
		immediate = true,
		service=JHIEmailConfigService.class,
		configurationPid="com.jhi.aem.website.v1.core.service.email.impl.JHIEmailConfigServiceImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"="+JHIEmailConfigService.EMAIL_COMPONENT_LABEL
		})


@Designate(ocd=JHIEmailConfigServiceImpl.Config.class)
public class JHIEmailConfigServiceImpl implements JHIEmailConfigService {
	private static final Logger log = LoggerFactory.getLogger(JHIEmailConfigServiceImpl.class);
	private String emailServiceApiUrl;
	private String emailServiceUName;
	private String emailServicePwd;
	private String emailServiceFromAddress;
	private String tokenCredentials;
	private String changePwdPagePath;
	private String[] ccemail;

	// marketo variables

	private String mktCliId;
	private String mktCliSecrt;
	private String mktRestIdentity;
	private String mktRestEndpoint;
	private String oauthTokenpath;
	private String leadApipath;
	private Map<String, String> campaignNameToIdsMap;
	private String[] includeTokens;
	private String[] subscriptions;
	private String[] inputFieldNames;
	private Map<String, String> fieldToSubscriptionMap;
	private Map<String, String> subscriptionToFieldToMap;
	private List<String> asListTokens;
	private List<String> listSubscriptions;
	private List<String> listInputFieldNames;
	
	@ObjectClassDefinition(name="Email Service Configuration for JHI website",description="Configurations for JHI Website email configuration service implementation")
	public @interface Config{
		@AttributeDefinition(name = JHIEmailConfigService.EMAIL_SERVICE_API_URL_LABEL)
		String emailserviceapiurl() default JHIEmailConfigService.EMPTY_STRING;
		
		@AttributeDefinition(name = JHIEmailConfigService.EMAIL_SERVICE_UNAME_LABEL)
		String emailserviceuname() default JHIEmailConfigService.EMPTY_STRING;
		
		@AttributeDefinition(name = JHIEmailConfigService.EMAIL_SERVICE_API_PWD_LABEL)
		String  emailservicepwd() default JHIEmailConfigService.EMPTY_STRING;
		@AttributeDefinition(name = JHIEmailConfigService.EMAIL_SERVICE_API_FROM_ADDRESS_LABEL)
		String  fromaddress() default JHIEmailConfigService.EMPTY_STRING;
		@AttributeDefinition(name = JHIEmailConfigService.CHANGE_PWD_PAGE_PATH_PROP_NAME_LABEL)
		String  changepwdpagepath() default JHIEmailConfigService.EMPTY_STRING;
		@AttributeDefinition(name= JHIEmailConfigService.CC_EMAIL_LABEL,cardinality=Integer.MAX_VALUE)
		String[]  ccemail() default {};
		@AttributeDefinition(name= JHIEmailConfigService.CLI_ID_LABEL)
		String  cliid() default JHIEmailConfigService.EMPTY_STRING;
		@AttributeDefinition(name= JHIEmailConfigService.CLI_SECRT_LABEL)
		String  clisecrt() default JHIEmailConfigService.EMPTY_STRING;
		
		@AttributeDefinition(name= JHIEmailConfigService.REST_IDENTITY_LABEL)
		String  marketorestidentity() default JHIEmailConfigService.EMPTY_STRING;
		
		@AttributeDefinition(name= JHIEmailConfigService.REST_ENDPOINT_LABEL)
		String  marketorestendpoint() default JHIEmailConfigService.EMPTY_STRING;
		
		@AttributeDefinition(name= JHIEmailConfigService.OAUTH_TOKEN_API_PATH_LABEL)
		String oauthtokenapi() default JHIEmailConfigService.EMPTY_STRING;
		
		@AttributeDefinition(name= JHIEmailConfigService.LEAD_API_PATH_LABEL)
		String  leadsapi() default JHIEmailConfigService.EMPTY_STRING;
		
		@AttributeDefinition(name= JHIEmailConfigService.CAMPAIGN_ID_LABEL, cardinality = Integer.MAX_VALUE)
		String[]  campaignid() default {};
		
		@AttributeDefinition(name= JHIEmailConfigService.INCLUDE_TOKEN_LIST_LABEL,  cardinality = Integer.MAX_VALUE)
		String[]  includetokenslist() default{} ;
		
		@AttributeDefinition(name= JHIEmailConfigService.MARKETO_SUBCSCRIPTION_LIST_LABEL,cardinality = Integer.MAX_VALUE)
		String[]  mktsubscriptionlist() default {};
		
		@AttributeDefinition(name= JHIEmailConfigService.MARKETO_SUB_INPUT_FIELD_NAMES_LABEL, cardinality = Integer.MAX_VALUE)
		String[]  mksubscpinputfieldnames() default {};
		
		@AttributeDefinition(name= JHIEmailConfigService.MARKETO_SUBCSCRIPTION_MAPPING_LABEL, cardinality = Integer.MAX_VALUE)
		String[]  mktsubscriptionmapping() default {};
		
		@AttributeDefinition(name= JHIEmailConfigService.MARKETO_SUBSCR_FIELD_MAPPING_LABEL, cardinality = Integer.MAX_VALUE)
		String[]  mktfieldmapping() default {};
	}

	@Override
	public String getEmailServiceUName() {
		return emailServiceUName;
	}

	@Override
	public String getEmailServicePwd() {
		return emailServicePwd;
	}

	@Override
	public String getEmailServiceApiUrl() {
		return emailServiceApiUrl;
	}

	@Override
	public String getFromEmailAddress() {
		return emailServiceFromAddress;
	}

	@Override
	public String getTokenCredentials() throws JSONException {

		return new JSONObject().put(IsamUserProfileConstants.UNAME, getEmailServiceUName())
				.put(IsamUserProfileConstants.PWD, getEmailServicePwd()).toString();

	}

	@Override
	public String getTokenJsonBody() {
		return tokenCredentials;
	}

	@Override
	public String getChangePwdPagePath() {

		return changePwdPagePath;
	}

	@Override
	public String[] getCcEmail() {
		return ccemail;
	}

	@Override
	public String getMktCliId() {
		return mktCliId;
	}

	@Override
	public String getMktClientSecrt() {
		return mktCliSecrt;
	}

	@Override
	public String getMktRestIdentity() {
		return mktRestIdentity;
	}

	@Override
	public String getMktRestEndpoint() {
		return mktRestEndpoint;
	}

	@Override
	public String getMktOAuthTokenApiUrl() {
		return oauthTokenpath;
	}

	@Override
	public String getMktLeadApiUrl() {
		return leadApipath;
	}

	@Override
	public String getCampaignId(String campaignName) {
		return campaignNameToIdsMap.get(campaignName);
	}

	public List<String> getIncludeTokens() {
		return asListTokens;
	}

	public List<String> getMktSubscriptions() {
		return listSubscriptions;
	}

	public List<String> getMktSubscpInputFieldNames() {
		return listInputFieldNames;
	}

	public String getMktSubscription(String fieldName) {
		return fieldToSubscriptionMap.get(fieldName);
	}

	@Override
	public String getMktSubscrFields(String subscriptionname) {
		return subscriptionToFieldToMap.get(subscriptionname);
	}

	@Activate
	protected void activate(final Config config) throws Exception {
		doConfigure(config);
		log.info("Activated service " + JHIEmailConfigServiceImpl.class.getName());
	}

	@Modified
	protected void modified(final Config config) throws Exception {
		doConfigure(config);
		log.info("Modified service " + JHIEmailConfigServiceImpl.class.getName());
	}

	private void doConfigure(final Config config) throws Exception {
		log.info("JHI Email ConfigService activate called.");
		emailServiceApiUrl = config.emailserviceapiurl();
		emailServiceUName = config.emailserviceuname();
		emailServicePwd = config.emailservicepwd();
		emailServiceFromAddress = config.fromaddress();
		changePwdPagePath = config.changepwdpagepath();
		ccemail = config.ccemail();
		tokenCredentials = getTokenCredentials();
		// marketo configurations
		mktCliId = config.cliid();
		mktCliSecrt =config.clisecrt();
		mktRestIdentity = config.marketorestidentity();
		mktRestEndpoint = config.marketorestendpoint();
		oauthTokenpath = config.oauthtokenapi();
		leadApipath = config.leadsapi();

		String[] campaignIdentifiers = config.campaignid();
		if (campaignIdentifiers == null || campaignIdentifiers.length == 0) {
			log.error("No campaign identifiers have been set, no emails will be sent for campaigns");
			throw new RuntimeException("No campaign identifiers have been set");
		}
		campaignNameToIdsMap = new HashMap<>(campaignIdentifiers.length);
		Arrays.stream(campaignIdentifiers).forEach(campaignIdentifier -> {
			String[] campaignIds = campaignIdentifier.split("~");
			campaignNameToIdsMap.put(campaignIds[0], campaignIds[1]);
		});
		includeTokens = config.includetokenslist();
		asListTokens = Arrays.asList(includeTokens);
		subscriptions = config.mktsubscriptionlist();
		listSubscriptions = Arrays.asList(subscriptions);
		inputFieldNames = config.mksubscpinputfieldnames();
		listInputFieldNames = Arrays.asList(inputFieldNames);
		String[] subMapping = config.mktsubscriptionmapping();
		fieldToSubscriptionMap = new HashMap<>(subMapping.length);
		subscriptionToFieldToMap = new HashMap<>(subMapping.length);
		Arrays.stream(subMapping).forEach(subMapValue -> {
			String[] fieldsubScritionValue = subMapValue.split("~");
			fieldToSubscriptionMap.put(fieldsubScritionValue[0], fieldsubScritionValue[1]);
			subscriptionToFieldToMap.put(fieldsubScritionValue[1], fieldsubScritionValue[0]);
		});
		log.info("emailServiceApiUrl : {}", emailServiceApiUrl);
		log.info("emailServiceFromAddress : {}", emailServiceFromAddress);
		log.info("changePwdPagePath : {} ", changePwdPagePath);
		log.info("ccemail length : " + ccemail.length);
		log.info("mktCliId : " + mktCliId);
		log.info("mktCliSecrt : " + mktCliSecrt);
		log.info("mktRestIdentity : " + mktRestIdentity);
		log.info("mktRestEndpoint : " + mktRestEndpoint);
		log.info("oauthTokenpath : " + oauthTokenpath);
		log.info("leadApipath : " + leadApipath);
		log.info("campaignNameToIdsMap: " + campaignNameToIdsMap);
		log.info("includeTokens length : " + includeTokens.length);
		log.info("subscriptions length : " + subscriptions.length);
		log.info("subscriptionfieldNames: " + inputFieldNames.length);
		log.info("fieldToSubscriptionMap : " + fieldToSubscriptionMap.size());
		log.info("subscriptionToFieldToMap size : " + subscriptionToFieldToMap.size());
		
	}

	@Deactivate
	protected void deactivate() {
		log.info("JHI Email ConfigService deactivate called.");
	}

}
