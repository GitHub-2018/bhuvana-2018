/**
 * 
 */
package com.jhi.aem.website.v1.core.service.email.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.email.EmailConfigService;


/**
 * @author rangayu
 *
 */

@Component(
		name = EmailConfigService.COMPONENT_LABEL,
		service=EmailConfigService.class,
		immediate=true,
		configurationPid=EmailConfigService.COMPONENT_NAME,
		configurationPolicy=ConfigurationPolicy.OPTIONAL,
		property= {
	    		Constants.SERVICE_DESCRIPTION+"=JHI Email Configuration Service implementation",
	    		Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
	    })
	
@Designate(ocd=EmailConfigServiceImpl.Config.class)
public class EmailConfigServiceImpl implements EmailConfigService {
	private static final Logger log = LoggerFactory.getLogger(EmailConfigServiceImpl.class);
	
	private String campaignType;
	private String campaignId;
	
	private Map<String,String> tokenMap;
	
	private boolean isDefaulLeadEnabled;
	private String leadEmail;
	private String leadFirstName;
	 
	private boolean isDefaultCCEnabled;
	private List<String> ccEmailList;
	
	private String leadAPIUrl;
	
	@ObjectClassDefinition(name="JHI Email Service Configurations", description="Configurations for JHI Mail Service")
	public @interface Config{
		@AttributeDefinition(name=EmailConfigService.MARKETO_CAMPAIGN_TYPE_LABEL,description="Label for Marketo Campaign Type")
		String marketo_campaignType() default "landingpagecontactus";
		
		@AttributeDefinition(name=EmailConfigService.MARKETO_CAMPAIGN_ID_LABEL,description="Label for Marketo Campaign ID")
		String marketo_campaignId() default "4321";
		
		@AttributeDefinition(name=EmailConfigService.MARKETO_TOKENVALUES_LABEL,description="Label for Marketo Token values",cardinality=Integer.MAX_VALUE)
		String[] marketo_tokenValues() default StringUtils.EMPTY;
		
		@AttributeDefinition(name=EmailConfigService.MARKETO_SHOW_DEFAULT_LEAD_EMAIL_LABEL,description="Show or Hide the default Lead email",type=AttributeType.BOOLEAN)
		boolean marketo_isDefaultLead() default false;
	
		@AttributeDefinition(name = EmailConfigService.MARKETO_LEAD_EMAIL_LABEL, description = "Default Marketo Lead Email Address" )
		String marketo_leademail() default "info@jhinvestments.com";
		
		@AttributeDefinition(name = EmailConfigService.MARKETO_LEAD_EMAIL_FIRSTNAME_LABEL, description = "Default Marketo Lead Firstname")
		String marketo_lead_firstName() default "JH Investments Info";
		
		@AttributeDefinition(name = EmailConfigService.MARKETO_SHOW_DEFAULT_CC_EMAIL_LABEL, description="Show/hide default CC Email address from configuration",type=AttributeType.BOOLEAN)
		boolean marketo_isDefaultCCEMail() default false ;
		
		@AttributeDefinition(name = EmailConfigService.MARKETO_CC_EMAIL_LABEL, description="List of default CC Email addresses, a max of 30 email addresses are allowed",cardinality = 30)
		String[] marketo_cc_email() default StringUtils.EMPTY;
		
		final String DEFAULT_LEAD_API_URL = "/v1/lead/{0}.json";
		@AttributeDefinition(name =  EmailConfigService.MARKETO_LEAD_API_URL_LABEL, description = "Default Marketo API URL to get the Lead details")
		String marketo_leadApiURL() default DEFAULT_LEAD_API_URL;
		
	}
	
	@Override
	public Map<String,String> getMarketoTokenValues() {
		return tokenMap;
	}
	
	@Activate
	protected void activate(Config config) throws Exception {
		doConfigure(config);
		log.info("Activated service " + EmailConfigServiceImpl.class.getName());
	}

	@Modified
	protected void modified(Config config) throws Exception {
		doConfigure(config);
		log.info("Modified service " + EmailConfigServiceImpl.class.getName());
	}

	private void doConfigure(Config config) throws Exception {
		log.info("JHI Email ConfigService activate called.");
		campaignType = config.marketo_campaignType();
		campaignId = config.marketo_campaignId();

		String[] tokenValues = config.marketo_tokenValues();
		setTokenMap(tokenValues);

		isDefaulLeadEnabled = config.marketo_isDefaultLead();
		leadEmail = config.marketo_leademail();
		leadFirstName = config.marketo_lead_firstName();
		isDefaultCCEnabled = config.marketo_isDefaultCCEMail();
		String[] ccEmail = config.marketo_cc_email();
		setEmailList(ccEmail);

		leadAPIUrl = config.marketo_leadApiURL();

	}

	@Deactivate
	protected void deactivate() {
		log.info("LandingPage contact us ConfigService deactivate called.");
	}


	@Override
	public String getDefaultLeadEmail() {
		return leadEmail;
	}



	@Override
	public String getDefaultLeadEmailFirstName() {
		return leadFirstName;
	}



	@Override
	public List<String> getDefaultCCEMail() {
		return ccEmailList;
	}



	@Override
	public String getLeadAPIUrl() {
		return leadAPIUrl;
	}



	@Override
	public String getCampaignType() {
		return campaignType;
	}



	@Override
	public String getCampaignId() {
		return campaignId;
	}



	@Override
	public boolean isDefaultEmailAddress() {
		return isDefaulLeadEnabled;
	}



	@Override
	public boolean isDefaultCCEMailAddress() {
		return isDefaultCCEnabled;
	}

	
	private void setEmailList(String[] ccEmail) {
		ccEmailList = new ArrayList<String>();
		if(null != ccEmail && ccEmail.length > 1) {
			ccEmailList = Arrays.asList(ccEmail);
		}
	}
	
	private void setTokenMap(String[] tokenValues) {
		tokenMap = new HashMap<>(tokenValues.length);
		Arrays.stream(tokenValues).forEach(tokenValue -> {
			String[] token = tokenValue.split("=");
			if(token.length > 1) {
				tokenMap.put(token[0],token[1]);
			}else {
				log.error("Landing Page contactus token not configured properly for "+tokenValue);
			}
		});
	}

	

}
