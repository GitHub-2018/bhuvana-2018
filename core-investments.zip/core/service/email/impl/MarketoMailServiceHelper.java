/**
 * 
 */
package com.jhi.aem.website.v1.core.service.email.impl;

import java.io.IOException;
import java.io.StringReader;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.mcm.emailprovider.EmailServiceException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jhi.aem.website.v1.core.constants.MarketoMailServiceConstatnts;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolExecutor;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolService;
import com.jhi.aem.website.v1.core.service.email.JHIEmailConfigService;
import com.jhi.aem.website.v1.core.service.email.exception.MarketoServiceException;
import com.jhi.aem.website.v1.core.service.email.models.EmailResponse;
import com.jhi.aem.website.v1.core.service.email.models.Input;
import com.jhi.aem.website.v1.core.service.email.models.LeadsResponse;
import com.jhi.aem.website.v1.core.service.email.models.MarketoEmailProgramTokenRequest;
import com.jhi.aem.website.v1.core.service.email.models.MktCreateLeadRequest;
import com.jhi.aem.website.v1.core.service.email.models.MktCreateLeadResponse;
import com.jhi.aem.website.v1.core.service.email.models.MktTriggerRequest;
import com.jhi.aem.website.v1.core.service.email.models.MktTriggerResponse;
import com.jhi.aem.website.v1.core.service.email.models.TriggerInput;
import com.jhi.aem.website.v1.core.service.email.models.TriggerLeads;
import com.jhi.aem.website.v1.core.service.email.models.TriggerTokens;
import com.jhi.aem.website.v1.core.utils.JsonUtil;

/**
 * @author singave
 *
 */

public class MarketoMailServiceHelper {

	private static final Logger log = LoggerFactory.getLogger(MarketoMailServiceHelper.class);

	/**
	 * This method used to make Marketo Get OAuth Token.
	 *
	 * @param jhiEmailConfigService
	 * @param httpClientPool
	 * @param emailResponeClass
	 * @return
	 * @throws EmailServiceException
	 */

	public <T extends EmailResponse> T getMktAccessToken(JHIEmailConfigService jhiEmailConfigService,
			AsyncHttpClientPoolService httpClientPool, Class<T> emailResponeClass) throws MarketoServiceException {
		log.info("Entering into getMktAccessToken method");
		GsonBuilder gsonBuilder = new GsonBuilder();
		// Create the request
		String tokenUrl = jhiEmailConfigService.getMktRestIdentity() + jhiEmailConfigService.getMktOAuthTokenApiUrl()
				+ "?grant_type=client_credentials&" + "client_id=" + jhiEmailConfigService.getMktCliId()
				+ "&client_secret=" + jhiEmailConfigService.getMktClientSecrt();
		log.info("Marketo API token url : " + tokenUrl);
		final HttpGet getMethod = new HttpGet(tokenUrl);
		// Execute
		try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(getMethod);
			HttpResponse httpResponse = future.get(MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS,
					TimeUnit.MILLISECONDS);
			log.info("STATUS_CODE :  {}", httpResponse.getStatusLine().getStatusCode());
			return gsonBuilder.create().fromJson(JsonUtil.getJsonContent(httpResponse.getEntity().getContent()),
					emailResponeClass);
		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Marketo getOAuthToken API URL '" + StringUtils.abbreviate(tokenUrl.toString(), 64)
					+ "'", e);
			throw new MarketoServiceException("Error calling Marketo getOAuthToken API URL '" + tokenUrl + "'", e);
		}

	}

	/**
	 * This method used to make Marketo API post call to create lead in LeadDB
	 *
	 * @param jhiEmailConfigService
	 * @param httpClientPool
	 * @param requestTimeoutMs
	 * @return
	 * @throws EmailServiceException
	 */
	public MktCreateLeadResponse doCreateMarketoLeadPost(JHIEmailConfigService jhiEmailConfigService,
			AsyncHttpClientPoolService httpClientPool, long requestTimeoutMs, String acTkn, String leadEmail,
			String firstName, String postalCode) throws MarketoServiceException {
		log.info("Entering into doMarketoEmailPost method.");
		Gson gson = new GsonBuilder().create();
		String url = jhiEmailConfigService.getMktRestEndpoint() + jhiEmailConfigService.getMktLeadApiUrl();
		log.info("Marketo post url : {} ", url);

		HttpPost empostMethod = new HttpPost(url);
		empostMethod.addHeader(MarketoMailServiceConstatnts.API_KEY_HEADER_NAME,
				MarketoMailServiceConstatnts.CONSTANT_BERR + acTkn);
		empostMethod.addHeader(MarketoMailServiceConstatnts.CONTENT_TYPE_HDR_KEY,
				MarketoMailServiceConstatnts.APPLICATION_JSON);
		// set Create Lead Request Body
		MktCreateLeadRequest mktCrtLeadReq = new MktCreateLeadRequest(MarketoMailServiceConstatnts.ACTION_CREATE_ONLY);
		Input leadInput = new Input();
		leadInput.setEmail(leadEmail);
		leadInput.setFirstName(firstName);
		if (StringUtils.isNotBlank(postalCode)) {
			leadInput.setPostalCode(postalCode);
		}
		Input[] inputArray = new Input[] { leadInput };
		mktCrtLeadReq.setInput(inputArray);
		String mktCrtLeadReqjson = gson.toJson(mktCrtLeadReq);
		empostMethod.setEntity(new StringEntity(mktCrtLeadReqjson, ContentType.APPLICATION_JSON));

		try (AsyncHttpClientPoolExecutor emhttpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> emfuture = emhttpClientBuilder.withStandardRequestConfig().execute(empostMethod);
			HttpResponse emhttpResponse = emfuture.get(requestTimeoutMs, TimeUnit.MILLISECONDS);
			MktCreateLeadResponse mktCrtLeadResp = gson.fromJson(
					JsonUtil.getJsonContent(emhttpResponse.getEntity().getContent()), MktCreateLeadResponse.class);
			String json = gson.toJson(mktCrtLeadResp);
			log.info("CreateLead API response : " + json);
			return mktCrtLeadResp;

		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Email Post API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
			throw new MarketoServiceException("Error calling SEND  EmailPost API URL '" + url + "'", e);
		}

	}

	/**
	 * This method is used to trigger Campaign Email based on Campaign ID.
	 *
	 * @param gsonBuilder
	 * @param jhiEmailConfigService
	 * @param httpClientPool
	 * @param aTkn
	 * @param campaignType
	 * @param emailSub
	 * @param firstName
	 * @param lastName
	 * @param userId
	 * @param leadCSValues
	 * @param tokenCSValues
	 * @return
	 * @throws EmailServiceException
	 */
	public MktTriggerResponse doCampaignTriggerPost(GsonBuilder gsonBuilder,
			JHIEmailConfigService jhiEmailConfigService, AsyncHttpClientPoolService httpClientPool, String aTkn,
			String campaignType, String emailSub, String firstName, String lastName, String userId, String leadCSValues,
			Set<String> tokenCSValues) throws MarketoServiceException {
		log.info("Entering into doCampaignTriggerPost method");
		Gson gson = gsonBuilder.create();
		String campaignId = null;
		LinkedHashMap<String, String> lHashMap = new LinkedHashMap<String, String>();
		ArrayList<Integer> leadsAl = new ArrayList<Integer>();
		// get leadIDs from leadCSValues
		String[] leadIds = leadCSValues.split(",");

		for (int i = 0; i < leadIds.length; i++) {
			leadsAl.add(Integer.valueOf(leadIds[i]));
		}
		// get tokens from tokenCSValues
		/*if (StringUtils.isNotBlank(tokenCSValues)) {
			String[] contentTokens = tokenCSValues.split(",");
			for (int i = 0; i < contentTokens.length; i++) {
				lHashMap.put("{{my.emailcontent" + i + "}}", contentTokens[i]);
			}
		}*/
		
		//##Fix for ticket 1930
	    // read the token set object to convert each set element to a email content message
		if( null != tokenCSValues && !tokenCSValues.isEmpty()) {
			int count=0;
			Iterator<String> iter = tokenCSValues.iterator();
			while(iter.hasNext()) {
				lHashMap.put("{{my.emailcontent" + count  + "}}", iter.next());
				count++;
			}
		}
		// set tokens
		log.debug("firstName : " + firstName);
		if (StringUtils.isNotBlank(firstName)) {
			lHashMap.put("{{my.firstname}}", firstName);
		}
		if (StringUtils.isNotBlank(lastName)) {
			lHashMap.put("{{my.lastname}}", lastName);
		}
		if (StringUtils.isNotBlank(userId)) {
			lHashMap.put("{{my.userid}}", userId);
		}
		if (StringUtils.isNotBlank(emailSub)) {
			lHashMap.put("{{my.emailsubject}}", emailSub);
		}
		// set input param values in MarketoEmailProgramTokenRequest
		MarketoEmailProgramTokenRequest mktEPgmTknReq = new MarketoEmailProgramTokenRequest();
		mktEPgmTknReq.setTokenLHashMap(lHashMap);
		if (StringUtils.isNotBlank(campaignType)) {
			campaignId = jhiEmailConfigService.getCampaignId(campaignType);
			log.info("Found campaign id '{}' for campaign key '{}'", campaignId, campaignType);
		}

		// create leads array
		log.info("leads List size : {} ", leadsAl.size());
		TriggerLeads leads = null;
		TriggerLeads[] tLeadsArr = new TriggerLeads[leadsAl.size()];
		for (int i = 0; i < leadsAl.size(); i++) {
			leads = new TriggerLeads();
			log.info("************************** : Retrieving lead id :  {} ", leadsAl.get(i));
			leads.setId(leadsAl.get(i));
			tLeadsArr[i] = leads;
		}
		log.info("TriggerLeads[] length : {} ", tLeadsArr.length);

		// create tokens array
		TriggerTokens tokens = null;
		LinkedHashMap<String, String> tokenLHashMap = mktEPgmTknReq.getTokenLHashMap();
		log.info("*********************** tokenLHashMap size() : " + tokenLHashMap.size());
		List<String> includeTokens = jhiEmailConfigService.getIncludeTokens();
		List<TriggerTokens> finalTokensList = new ArrayList<TriggerTokens>();
		for (String tokenKey : includeTokens) {
			tokens = new TriggerTokens();
			log.debug("tokenKey : " + tokenKey);
			log.debug("tokenValue: " + tokenLHashMap.get(tokenKey));
			if(null != tokenLHashMap.get(tokenKey)){
				tokens.setName(tokenKey);
				tokens.setValue(tokenLHashMap.get(tokenKey));
				finalTokensList.add(tokens);
			}

		}
		log.info("final tokenlist size : " + finalTokensList.size());
		TriggerTokens[] tTokensArr = new TriggerTokens[finalTokensList.size()];
		tTokensArr = finalTokensList.toArray(tTokensArr);
		log.info("final tokenArray length : " + finalTokensList.size());

		TriggerInput input = new TriggerInput();
		input.setLeads(tLeadsArr);
		input.setTokens(tTokensArr);
		MktTriggerRequest mktTriggerRequest = new MktTriggerRequest();
		mktTriggerRequest.setInput(input);
		String mktTriggerRequestJson = gson.toJson(mktTriggerRequest);
		log.debug("mktTriggerRequestJson : {} ", mktTriggerRequestJson);
		// call trigger.json API

		String url = jhiEmailConfigService.getMktRestEndpoint() + "/v1/campaigns/" + campaignId + "/trigger.json";
		HttpPost trgPostMethod = new HttpPost(url);
		trgPostMethod.addHeader(MarketoMailServiceConstatnts.API_KEY_HEADER_NAME,
				MarketoMailServiceConstatnts.CONSTANT_BERR + aTkn);
		trgPostMethod.addHeader(MarketoMailServiceConstatnts.CONTENT_TYPE_HDR_KEY,
				MarketoMailServiceConstatnts.APPLICATION_JSON);
		trgPostMethod.setEntity(new StringEntity(mktTriggerRequestJson, ContentType.APPLICATION_JSON));
		try (AsyncHttpClientPoolExecutor emhttpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> emfuture = emhttpClientBuilder.withStandardRequestConfig().execute(trgPostMethod);
			HttpResponse emhttpResponse = emfuture.get(MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS,
					TimeUnit.MILLISECONDS);
			MktTriggerResponse mktTriggerResponse = gson.fromJson(
					JsonUtil.getJsonContent(emhttpResponse.getEntity().getContent()), MktTriggerResponse.class);
			String json = gson.toJson(mktTriggerResponse);
			log.info("Trigger API response : " + json);
			return mktTriggerResponse;

		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Email Post API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
			throw new MarketoServiceException("Error calling SEND  /v1/trigger.json API URL '" + url + "'", e);
		}

	}

	public MktTriggerResponse doLandingPageTriggerPost(GsonBuilder gsonBuilder,
			JHIEmailConfigService jhiEmailConfigService, AsyncHttpClientPoolService httpClientPool, String aTkn,
			String campaignId,  String leadCSValues,
			Map<String,Object> detailsMap,Map<String,String> tokenMap) throws MarketoServiceException {
		log.info("#### Marketo Mail Helper Entering into doCampaignTriggerPost method ####");
		Gson gson = gsonBuilder.create();
		
		LinkedHashMap<String, String> lHashMap = new LinkedHashMap<String, String>();
		ArrayList<Integer> leadsAl = new ArrayList<Integer>();
		// get leadIDs from leadCSValues
		String[] leadIds = leadCSValues.split(",");

		for (int i = 0; i < leadIds.length; i++) {
			leadsAl.add(Integer.valueOf(leadIds[i]));
		}
		
		
		if( null != detailsMap && !detailsMap.isEmpty() && null != tokenMap && !tokenMap.isEmpty()) {
			
			Iterator<String> tokenIterator = tokenMap.keySet().iterator();
			
			while(tokenIterator.hasNext()) {
				String key= tokenIterator.next();
				if(detailsMap.containsKey(key)) {
					lHashMap.put(tokenMap.get(key),detailsMap.get(key).toString());
				}
			}
			
		}
		
		// set input param values in MarketoEmailProgramTokenRequest
		MarketoEmailProgramTokenRequest mktEPgmTknReq = new MarketoEmailProgramTokenRequest();
		mktEPgmTknReq.setTokenLHashMap(lHashMap);
		if (StringUtils.isNotBlank(campaignId)) {
			
			log.info("!!!! Marketo Mail helper: Found campaign id '{}' for campaign key '{}' !!!!", campaignId);
		}

		// create leads array
		log.info("leads List size : {} ", leadsAl.size());
		TriggerLeads leads = null;
		TriggerLeads[] tLeadsArr = new TriggerLeads[leadsAl.size()];
		for (int i = 0; i < leadsAl.size(); i++) {
			leads = new TriggerLeads();
			log.info("************************** : Retrieving lead id :  {} ", leadsAl.get(i));
			leads.setId(leadsAl.get(i));
			tLeadsArr[i] = leads;
		}
		log.info("TriggerLeads[] length : {} ", tLeadsArr.length);

		// create tokens array
		TriggerTokens tokens = null;
	//	LinkedHashMap<String, String> tokenLHashMap = mktEPgmTknReq.getTokenLHashMap();
		log.info("*********************** tokenLHashMap size() : " + lHashMap.size());
		//List<String> includeTokens = jhiEmailConfigService.getIncludeTokens();
		Set<String>tokenKeys = lHashMap.keySet();
		List<TriggerTokens> finalTokensList = new ArrayList<TriggerTokens>();
		for (String tokenKey : tokenKeys) {
			tokens = new TriggerTokens();
			log.debug("tokenKey : " + tokenKey);
			log.debug("tokenValue: " + lHashMap.get(tokenKey));
			if(null != lHashMap.get(tokenKey)){
				tokens.setName(tokenKey);
				tokens.setValue(lHashMap.get(tokenKey));
				finalTokensList.add(tokens);
			}

		}
		log.info("final tokenlist size : " + finalTokensList.size());
		TriggerTokens[] tTokensArr = new TriggerTokens[finalTokensList.size()];
		tTokensArr = finalTokensList.toArray(tTokensArr);
		log.info("final tokenArray length : " + finalTokensList.size());

		TriggerInput input = new TriggerInput();
		input.setLeads(tLeadsArr);
		input.setTokens(tTokensArr);
		MktTriggerRequest mktTriggerRequest = new MktTriggerRequest();
		mktTriggerRequest.setInput(input);
		String mktTriggerRequestJson = gson.toJson(mktTriggerRequest);
		log.debug("mktTriggerRequestJson : {} ", mktTriggerRequestJson);
		// call trigger.json API

		String url = jhiEmailConfigService.getMktRestEndpoint() + "/v1/campaigns/" + campaignId + "/trigger.json";
		HttpPost trgPostMethod = new HttpPost(url);
		trgPostMethod.addHeader(MarketoMailServiceConstatnts.API_KEY_HEADER_NAME,
				MarketoMailServiceConstatnts.CONSTANT_BERR + aTkn);
		trgPostMethod.addHeader(MarketoMailServiceConstatnts.CONTENT_TYPE_HDR_KEY,
				MarketoMailServiceConstatnts.APPLICATION_JSON);
		trgPostMethod.setEntity(new StringEntity(mktTriggerRequestJson, ContentType.APPLICATION_JSON));
		try (AsyncHttpClientPoolExecutor emhttpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> emfuture = emhttpClientBuilder.withStandardRequestConfig().execute(trgPostMethod);
			HttpResponse emhttpResponse = emfuture.get(MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS,
					TimeUnit.MILLISECONDS);
			MktTriggerResponse mktTriggerResponse = gson.fromJson(
					JsonUtil.getJsonContent(emhttpResponse.getEntity().getContent()), MktTriggerResponse.class);
			String json = gson.toJson(mktTriggerResponse);
			log.info("Trigger API response : " + json);
			
			log.info("#### Maketo Mail Helper Exiting into doCampaignTriggerPost method ####");
			return mktTriggerResponse;

		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Email Post API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
			throw new MarketoServiceException("Error calling SEND  /v1/trigger.json API URL '" + url + "'", e);
		}

	}
	
	
	/**
	 * This method is used to get Lead ID from Marketo Lead Database
	 *
	 * @param gsonBuilder
	 * @param jhiEmailConfigService
	 * @param httpClientPool
	 * @param emailResponeClass
	 * @param accessToken
	 * @param leadEmail
	 * @param ccEmail
	 * @return
	 * @throws EmailServiceException
	 */
	public <T extends EmailResponse> T getLeadIdS(GsonBuilder gsonBuilder, JHIEmailConfigService jhiEmailConfigService,
			AsyncHttpClientPoolService httpClientPool, Class<T> emailResponeClass, String accessToken, String leadEmail,
			String ccEmail) throws MarketoServiceException {
		log.info("Entering into getLeadId method");
		List<String> emailList = new ArrayList<String>();
		emailList.add(leadEmail);
		/**
		 * ccemail -This code is added for testing ccemail during UAT- start
		 *
		 */
		if (null == ccEmail) {
			String[] ccEmailVal = jhiEmailConfigService.getCcEmail();
			if (null !=ccEmailVal && ccEmailVal.length > 0) {
				log.info("Number of CCEmails configured : {}", ccEmailVal.length);
				for (int c = 0; c < ccEmailVal.length; c++) {
					emailList.add(ccEmailVal[c]);
				}
			}
		}
		/**
		 * ccemail -This code is added for testing ccemail during UAT -end
		 *
		 */
		if (StringUtils.isNotBlank(ccEmail)) {
			String[] ccemails = ccEmail.split(",");
			for (int i = 0; i < ccemails.length; i++) {
				emailList.add(ccemails[i]);
			}
		}
		log.info("filerValues for leads.json request : " + emailList.size());
		String tknendPoint = jhiEmailConfigService.getMktRestEndpoint() + jhiEmailConfigService.getMktLeadApiUrl()
				+ "?access_token=" + accessToken + "&filterType=email" + "&filterValues="
				+ arrayListTocsVString(emailList);
		final HttpGet getMethod = new HttpGet(tknendPoint);
		// Execute
		try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(getMethod);
			HttpResponse httpResponse = future.get(MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS,
					TimeUnit.MILLISECONDS);
			return gsonBuilder.create().fromJson(JsonUtil.getJsonContent(httpResponse.getEntity().getContent()),
					emailResponeClass);
		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Marketo getLeadId API URL '" + StringUtils.abbreviate(tknendPoint, 64) + "'", e);
			throw new MarketoServiceException("Error calling Marketo getLeadId API URL '" + tknendPoint + "'", e);
		}

	}

	/**
	 * This methid is used to create or update the custom fields on lead record
	 * in Lead Database.
	 *
	 * @param jhiEmailConfigService
	 * @param httpClientPool
	 * @param requestTimeoutMs
	 * @param leadEmail
	 * @param mRegGroup
	 * @param mRegStatus
	 * @return
	 * @throws EmailServiceException
	 */

	public MktCreateLeadResponse doCreateUpdateCustomFieldPost(JHIEmailConfigService jhiEmailConfigService,
			AsyncHttpClientPoolService httpClientPool, long requestTimeoutMs, String aTkn, String leadEmail,
			String mRegStatus, String mRegGroup) throws MarketoServiceException {

		log.info("Entering into doCreateUpdateCustomFieldPost method.");
		Gson gson = new GsonBuilder().create();
		String url = jhiEmailConfigService.getMktRestEndpoint() + jhiEmailConfigService.getMktLeadApiUrl();
		log.info("Marketo post url : {} ", url);

		HttpPost empostMethod = new HttpPost(url);
		empostMethod.addHeader(MarketoMailServiceConstatnts.API_KEY_HEADER_NAME,
				MarketoMailServiceConstatnts.CONSTANT_BERR + aTkn);
		empostMethod.addHeader(MarketoMailServiceConstatnts.CONTENT_TYPE_HDR_KEY,
				MarketoMailServiceConstatnts.APPLICATION_JSON);
		// set Create Lead Request Body
		MktCreateLeadRequest mktCrtLeadReq = new MktCreateLeadRequest(
				MarketoMailServiceConstatnts.ACTION_CREATE_OR_UPDATAE);
		Input leadInput = new Input();
		leadInput.setEmail(leadEmail);
		if (StringUtils.isNotBlank(mRegStatus)) {
			leadInput.setMRegistrationStatus(mRegStatus);
		}
		if (StringUtils.isNotBlank(mRegGroup)) {
			leadInput.setMRegistrationGroup(mRegGroup);
		}
		Input[] inputArray = new Input[] { leadInput };
		mktCrtLeadReq.setInput(inputArray);
		String mktCrtLeadReqjson = gson.toJson(mktCrtLeadReq);
		empostMethod.setEntity(new StringEntity(mktCrtLeadReqjson, ContentType.APPLICATION_JSON));

		try (AsyncHttpClientPoolExecutor emhttpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> emfuture = emhttpClientBuilder.withStandardRequestConfig().execute(empostMethod);
			HttpResponse emhttpResponse = emfuture.get(requestTimeoutMs, TimeUnit.MILLISECONDS);
			MktCreateLeadResponse mktCrtLeadResp = gson.fromJson(
					JsonUtil.getJsonContent(emhttpResponse.getEntity().getContent()), MktCreateLeadResponse.class);
			String json = gson.toJson(mktCrtLeadResp);
			return mktCrtLeadResp;

		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Email Post API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
			throw new MarketoServiceException("Error calling SEND  EmailPost API URL '" + url + "'", e);
		}

	}

	/**
	 * This method is used to get custom fields for given lead email ID.
	 *
	 * @param gsonBuilder
	 * @param jhiEmailConfigService
	 * @param httpClientPool
	 * @param accessToken
	 * @param leadEmail
	 * @return
	 * @throws EmailServiceException
	 */
	public JsonObject getCustomFields(GsonBuilder gsonBuilder, JHIEmailConfigService jhiEmailConfigService,
			AsyncHttpClientPoolService httpClientPool, String accessToken, String leadEmail,String manageSubFlag)
			throws MarketoServiceException {
		log.info("Entering getCustomFields method.");
		// lead.json end point url construction.
		String leadApiEndPoint = jhiEmailConfigService.getMktRestEndpoint() + jhiEmailConfigService.getMktLeadApiUrl()
				+ "?access_token=" + accessToken + "&filterType=email" + "&filterValues=" + leadEmail + "&fields="
				+ arrayListTocsVString(jhiEmailConfigService.getMktSubscriptions());
		log.info("leadApiEndPoint : {}", leadApiEndPoint);
		final HttpGet getMethod = new HttpGet(leadApiEndPoint);

		// Execute
		try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(getMethod);
			HttpResponse httpResponse = future.get(MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS,
					TimeUnit.MILLISECONDS);
			log.info("Exiting getCustomFields method.");
			String response = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
			JsonParser jsonParser = new JsonParser();
			return getSubscritionDetails(
					jsonParser.parse(JsonUtil.getJsonContent(new StringReader(response))).getAsJsonObject(),
					jhiEmailConfigService,manageSubFlag);
		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Marketo leads API URL '" + StringUtils.abbreviate(leadApiEndPoint, 64) + "'", e);
			throw new MarketoServiceException("Error calling Marketo leads API URL '" + leadApiEndPoint + "'", e);
		}
	}

	/**
	 * This method is used to get Marketo Subscriptions based on lead email.
	 *
	 * @param jhiEmailConfigService
	 * @param httpClientPool
	 * @param requestTimeoutMs
	 * @param aTkn
	 * @param leadEmail
	 * @param subscriptionsjObj
	 * @return
	 * @throws MarketoServiceException
	 */
	public MktCreateLeadResponse updateMktSubscriptions(JHIEmailConfigService jhiEmailConfigService,
			AsyncHttpClientPoolService httpClientPool, long requestTimeoutMs, String aTkn, String leadEmail,
			JsonObject subscriptionsjObj) throws MarketoServiceException {
		log.info("Entering into updateMktSubscriptions method.");
		Gson gson = new GsonBuilder().create();
		JsonArray leadInput = new JsonArray();
		JsonObject inputJobj = new JsonObject();
		JsonObject mktCrtLeadReq = new JsonObject();
		String url = jhiEmailConfigService.getMktRestEndpoint() + jhiEmailConfigService.getMktLeadApiUrl();
		log.info("Marketo post url : {} ", url);
		HttpPost empostMethod = new HttpPost(url);
		empostMethod.addHeader(MarketoMailServiceConstatnts.API_KEY_HEADER_NAME,
				MarketoMailServiceConstatnts.CONSTANT_BERR + aTkn);
		empostMethod.addHeader(MarketoMailServiceConstatnts.CONTENT_TYPE_HDR_KEY,
				MarketoMailServiceConstatnts.APPLICATION_JSON);
		List<String> mktSubscpInputFieldNames = jhiEmailConfigService.getMktSubscpInputFieldNames();

		JsonArray subscrDetailsArr = subscriptionsjObj.getAsJsonArray("subscriptiondetails");
		JsonObject subJobj = subscrDetailsArr.get(0).getAsJsonObject();
		// set lead email.
		inputJobj.addProperty("email", leadEmail);
		for (int j = 0; j < mktSubscpInputFieldNames.size(); j++) {
			String fieldName = mktSubscpInputFieldNames.get(j);
			log.info("inputfield name : " + fieldName);
			boolean fieldValue;
			if(subJobj.has(fieldName)){
				fieldValue = subJobj.get(fieldName).getAsBoolean();
				inputJobj.addProperty(jhiEmailConfigService.getMktSubscription(fieldName), fieldValue);
			} 	//#1684 fix
			else {
				String formMktSubName = jhiEmailConfigService.getMktSubscription(fieldName);
				if(subJobj.has(formMktSubName)){
					log.info(formMktSubName);
					fieldValue = subJobj.get(formMktSubName).getAsBoolean();
					inputJobj.addProperty(formMktSubName,fieldValue);
				}
			}
		}
		mktCrtLeadReq.addProperty("action", MarketoMailServiceConstatnts.ACTION_CREATE_OR_UPDATAE);
		mktCrtLeadReq.addProperty("lookupField", "email");
		leadInput.add(inputJobj);
		mktCrtLeadReq.add("input", leadInput);

		String mktCrtLeadReqjson = gson.toJson(mktCrtLeadReq);
		log.info("leadrequest json : {} ", mktCrtLeadReqjson);
		empostMethod.setEntity(new StringEntity(mktCrtLeadReqjson, ContentType.APPLICATION_JSON));

		try (AsyncHttpClientPoolExecutor emhttpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> emfuture = emhttpClientBuilder.withStandardRequestConfig().execute(empostMethod);
			HttpResponse emhttpResponse = emfuture.get(requestTimeoutMs, TimeUnit.MILLISECONDS);
			MktCreateLeadResponse mktCrtLeadResp = gson.fromJson(
					JsonUtil.getJsonContent(emhttpResponse.getEntity().getContent()), MktCreateLeadResponse.class);
			String json = gson.toJson(mktCrtLeadResp);
			log.info("respone json : {}", json);
			return mktCrtLeadResp;

		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Email Post API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
			throw new MarketoServiceException("Error calling SEND  EmailPost API URL '" + url + "'", e);
		}

	}
	
	public MktCreateLeadResponse createLandingPageLeadPost(JHIEmailConfigService jhiEmailConfigService,
			AsyncHttpClientPoolService httpClientPool, long requestTimeoutMs, String acTkn, String leadEmail,String leadFirstName,Map<String,Object> detailsMap) throws MarketoServiceException {
		log.info("Entering into createLandingPageLeadPost method.");
		
		
		
		
		Gson gson = new GsonBuilder().create();
		String url = jhiEmailConfigService.getMktRestEndpoint() + jhiEmailConfigService.getMktLeadApiUrl();
		log.info("Marketo post url : {} ", url);

		HttpPost empostMethod = new HttpPost(url);
		empostMethod.addHeader(MarketoMailServiceConstatnts.API_KEY_HEADER_NAME,
				MarketoMailServiceConstatnts.CONSTANT_BERR + acTkn);
		empostMethod.addHeader(MarketoMailServiceConstatnts.CONTENT_TYPE_HDR_KEY,
				MarketoMailServiceConstatnts.APPLICATION_JSON);
		// set Create Lead Request Body
		MktCreateLeadRequest mktCrtLeadReq = new MktCreateLeadRequest(MarketoMailServiceConstatnts.ACTION_CREATE_ONLY);
		Input leadInput = new Input();
		leadInput.setEmail(leadEmail);
		
		leadInput.setFirstName(leadFirstName);
		
		Input[] inputArray = new Input[] { leadInput };
		mktCrtLeadReq.setInput(inputArray);
		String mktCrtLeadReqjson = gson.toJson(mktCrtLeadReq);
		empostMethod.setEntity(new StringEntity(mktCrtLeadReqjson, ContentType.APPLICATION_JSON));

		try (AsyncHttpClientPoolExecutor emhttpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> emfuture = emhttpClientBuilder.withStandardRequestConfig().execute(empostMethod);
			HttpResponse emhttpResponse = emfuture.get(requestTimeoutMs, TimeUnit.MILLISECONDS);
			MktCreateLeadResponse mktCrtLeadResp = gson.fromJson(
					JsonUtil.getJsonContent(emhttpResponse.getEntity().getContent()), MktCreateLeadResponse.class);
			String json = gson.toJson(mktCrtLeadResp);
			log.info("CreateLead API response : " + json);
			return mktCrtLeadResp;

		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Email Post API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
			throw new MarketoServiceException("Error calling SEND  EmailPost API URL '" + url + "'", e);
		}

	}


	/**
	 * This method constructs and returns the subscription details json object.
	 *
	 * @param jsonObject
	 * @param jhiEmailConfigService
	 * @return
	 */
	private JsonObject getSubscritionDetails(JsonObject jsonObject, JHIEmailConfigService jhiEmailConfigService,String manageSubFlag) {
		log.info("Entering getSubscritionDetails method.");
		JsonObject subscpResp = new JsonObject();
		List<String> mktSubscriptions = jhiEmailConfigService.getMktSubscriptions();
		Optional.ofNullable(jsonObject)
				.filter(json -> json.has("result"))
				.map(json -> json.get("result").getAsJsonArray())
				.filter(jsonArray -> jsonArray.size() > 0)
				.map(json -> json.get(0).getAsJsonObject())
				.ifPresent(subscripObj -> {
					JsonObject subscpDetails = new JsonObject();
					for (String mktSubfield : mktSubscriptions) {
						if (subscripObj.has(mktSubfield)) {
							boolean subscpValue = subscripObj.get(mktSubfield).getAsBoolean();
							if(null != manageSubFlag && manageSubFlag.equalsIgnoreCase("mgsub")){
								subscpDetails.addProperty(mktSubfield, subscpValue);
							} else {
								subscpDetails.addProperty(jhiEmailConfigService.getMktSubscrFields(mktSubfield), subscpValue);
							}
							
						}
					}
					JsonArray subscrDetailArray = new JsonArray();
					subscrDetailArray.add(subscpDetails);
					subscpResp.add("subscriptiondetails", subscrDetailArray);
					subscpResp.addProperty("success", true);
				});
		log.info("Exiting getSubscritionDetails method.");
		return subscpResp;
	}
	
	
	public LeadsResponse  getLeadIdFromMarketo(GsonBuilder gsonBuilder,String accessToken,String param,String leadAPIUrl,JHIEmailConfigService jhiEmailConfigService,AsyncHttpClientPoolService httpClientPool) throws MarketoServiceException {

		log.debug("Entering getLeadIdFromMarketo() method in mailservice helper");
		
		log.info("Execute marketo Lead API details  " + param);
		
		
		leadAPIUrl = new MessageFormat(leadAPIUrl).format(new Object[] {param,accessToken});
		
		String leadEndPointURL = jhiEmailConfigService.getMktRestEndpoint() + leadAPIUrl;
		
		log.debug("Lead API URL for Marketo with campaignId :"+leadEndPointURL);
		final HttpGet getMethod = new HttpGet(leadEndPointURL);
	
		try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			
			Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(getMethod);
			HttpResponse httpResponse = future.get(MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS,
					TimeUnit.MILLISECONDS);
			log.debug("Exiting getLeadIdFromMarketo() method in Mail Service helper");
			return gsonBuilder.create().fromJson(JsonUtil.getJsonContent(httpResponse.getEntity().getContent()),
					LeadsResponse.class);
		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling getLeadIdfromMarketo API URL '" + StringUtils.abbreviate(leadEndPointURL, 64) + "'", e);
			throw new MarketoServiceException("Error calling Marketo getLeadId API URL '" + leadEndPointURL + "'", e);
		}

	
	}
	
	public LeadsResponse createLeadId(GsonBuilder gsonBuilder,String accessToken,String leadEmail,String leadFirstname,JHIEmailConfigService jhiEmailConfigService,AsyncHttpClientPoolService httpClientPool) throws MarketoServiceException{
		
		String url = jhiEmailConfigService.getMktRestEndpoint() + jhiEmailConfigService.getMktLeadApiUrl();
		log.debug("Marketo create Lead url : {} ", url);
		Gson gson = gsonBuilder.create();
		HttpPost postMethod = new HttpPost(url);
		postMethod.addHeader(MarketoMailServiceConstatnts.API_KEY_HEADER_NAME,
				MarketoMailServiceConstatnts.CONSTANT_BERR + accessToken);
		postMethod.addHeader(MarketoMailServiceConstatnts.CONTENT_TYPE_HDR_KEY,
				MarketoMailServiceConstatnts.APPLICATION_JSON);
		// set Create Lead Request Body
		MktCreateLeadRequest mktCrtLeadReq = new MktCreateLeadRequest(MarketoMailServiceConstatnts.ACTION_CREATE_ONLY);
		
		Input leadInput = new Input();
		log.info("Lead Email :"+leadEmail);
		log.info("First Name :"+leadFirstname);
		leadInput.setEmail(leadEmail);
		leadInput.setFirstName(leadFirstname);
		
		Input[] inputArray = new Input[] { leadInput };
		mktCrtLeadReq.setInput(inputArray);
		
		String mktCrtLeadReqjson = gsonBuilder.create().toJson(mktCrtLeadReq);
		log.info("Marketo Request :"+mktCrtLeadReqjson );
		postMethod.setEntity(new StringEntity(mktCrtLeadReqjson, ContentType.APPLICATION_JSON));

		try (AsyncHttpClientPoolExecutor emhttpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
			Future<HttpResponse> emfuture = emhttpClientBuilder.withStandardRequestConfig().execute(postMethod);
			HttpResponse emhttpResponse = emfuture.get(MarketoMailServiceConstatnts.DEFAULT_TIMEOUT_MS, TimeUnit.MILLISECONDS);
			LeadsResponse mktCrtLeadResp = gson.fromJson(
					JsonUtil.getJsonContent(emhttpResponse.getEntity().getContent()), LeadsResponse.class);	
			String json = gson.toJson(mktCrtLeadResp);
			gson=null;
			log.info("Create Lead Response :"+ json);
			return mktCrtLeadResp;

		} catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
			log.error("Error calling Email Post API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
			throw new MarketoServiceException("Error calling SEND  EmailPost API URL '" + url + "'", e);
		}
	}
	
	
	
	/**
	 * This method used to convert list of strings to comma separated values.
	 *
	 * @param fields
	 * @return
	 */
	private String arrayListTocsVString(List<String> fields) {
		StringBuilder fieldCsv = new StringBuilder();
		for (int i = 0; i < fields.size(); i++) {
			fieldCsv.append(fields.get(i));
			if (i + 1 != fields.size()) {
				fieldCsv.append(",");
			}
		}
		return fieldCsv.toString();
	}

}
