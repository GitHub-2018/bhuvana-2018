package com.jhi.aem.website.v1.core.service.email.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class EmailRegexCollection implements List<ThreadLocal<Matcher>> {
	private static final Logger LOG = LoggerFactory.getLogger(EmailRegexCollection.class);
	private List<ThreadLocal<Matcher>> collection = new ArrayList<>();

	public EmailRegexCollection(Collection<String> regularExpressionStrings) {
		for (String regexString : regularExpressionStrings) {
			if (!StringUtils.startsWith(regexString, "^")) {
				regexString = "^" + regexString;
			}
			if (!StringUtils.endsWith(regexString, "$")) {
				regexString = regexString + "$";
			}
			
			try {
				final String rs = regexString;
				add(new ThreadLocal<Matcher>() {
					@Override
					protected Matcher initialValue() {
						return Pattern.compile(rs).matcher(StringUtils.EMPTY);
					}
				});
			} catch (PatternSyntaxException e) {
				LOG.warn("Email pattern for '{}' is invalid, skipping definition", regexString, e);
			}
		}
	}
	
	public boolean matchesAnyPattern(String emailAddress) {
		for (ThreadLocal<Matcher> localMatcher : this) {
			if (LOG.isTraceEnabled()) {
				LOG.trace("Checking email regex pattern for '{}' against '{}'", emailAddress, localMatcher.get().toString());
			}

			if (localMatcher.get().reset(emailAddress).matches()) {
				if (LOG.isTraceEnabled()) {
					LOG.trace("Email regex pattern matched '{}' against '{}'", emailAddress, localMatcher.get().toString());
				}

				return true;
			}
		}

		return false;
	}

	public void add(int index, ThreadLocal<Matcher> element) {
		collection.add(index, element);
	}

	public boolean add(ThreadLocal<Matcher> e) {
		return collection.add(e);
	}

	public boolean addAll(Collection<? extends ThreadLocal<Matcher>> c) {
		return collection.addAll(c);
	}

	public boolean addAll(int index, Collection<? extends ThreadLocal<Matcher>> c) {
		return collection.addAll(index, c);
	}

	public void clear() {
		collection.clear();
	}

	public boolean contains(Object o) {
		return collection.contains(o);
	}

	public boolean containsAll(Collection<?> c) {
		return collection.containsAll(c);
	}

	public boolean equals(Object o) {
		return collection.equals(o);
	}

	public ThreadLocal<Matcher> get(int index) {
		return collection.get(index);
	}

	public int hashCode() {
		return collection.hashCode();
	}

	public int indexOf(Object o) {
		return collection.indexOf(o);
	}

	public boolean isEmpty() {
		return collection.isEmpty();
	}

	public Iterator<ThreadLocal<Matcher>> iterator() {
		return collection.iterator();
	}

	public int lastIndexOf(Object o) {
		return collection.lastIndexOf(o);
	}

	public ListIterator<ThreadLocal<Matcher>> listIterator() {
		return collection.listIterator();
	}

	public ListIterator<ThreadLocal<Matcher>> listIterator(int index) {
		return collection.listIterator(index);
	}

	public ThreadLocal<Matcher> remove(int index) {
		return collection.remove(index);
	}

	public boolean remove(Object o) {
		return collection.remove(o);
	}

	public boolean removeAll(Collection<?> c) {
		return collection.removeAll(c);
	}

	public boolean retainAll(Collection<?> c) {
		return collection.retainAll(c);
	}

	public ThreadLocal<Matcher> set(int index, ThreadLocal<Matcher> element) {
		return collection.set(index, element);
	}

	public int size() {
		return collection.size();
	}

	public List<ThreadLocal<Matcher>> subList(int fromIndex, int toIndex) {
		return collection.subList(fromIndex, toIndex);
	}

	public Object[] toArray() {
		return collection.toArray();
	}

	public <T> T[] toArray(T[] a) {
		return collection.toArray(a);
	}
	
	@Override
	public String toString() {
		return collection.toString();
	}

}
