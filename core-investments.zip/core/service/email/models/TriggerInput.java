package com.jhi.aem.website.v1.core.service.email.models;

public class TriggerInput {

	private TriggerLeads[] leads;
	private TriggerTokens[] tokens;


	public void setLeads(TriggerLeads[] leads) {
		this.leads = leads;
	}

	public TriggerLeads[] getLeads() {
		return leads;
	}
	public TriggerTokens[] getTokens() {
		return tokens;
	}

	public void setTokens(TriggerTokens[] tokens) {
		this.tokens = tokens;
	}

}
