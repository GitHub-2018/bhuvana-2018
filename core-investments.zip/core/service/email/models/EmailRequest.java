package com.jhi.aem.website.v1.core.service.email.models;

import java.util.Collections;
import java.util.List;

import org.apache.http.NameValuePair;

public interface EmailRequest {

	String getDescription();

	/**
	 * Gets the URL parameters (if any) for this request.
	 * @return
	 */
	@SuppressWarnings("unchecked")
	default List<NameValuePair> getRequestParameters() {
		return Collections.EMPTY_LIST;
	}


}
