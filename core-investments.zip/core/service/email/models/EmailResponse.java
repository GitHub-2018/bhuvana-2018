package com.jhi.aem.website.v1.core.service.email.models;

import org.apache.commons.lang3.StringUtils;

/**
 * A serializable JSON response object
 */
public interface EmailResponse {
    static final String SUCCESS_CODE = "0000";

    /**
     * @return	The response code
     */
    String getCode();

    /**
     * Tests that the response successfully returned, the default implementation checks that
     * {@link #getCode()} and {@link #SUCCESS_CODE} are equal.
     */
    default boolean isSuccess() {
		return StringUtils.equals(SUCCESS_CODE, getCode());
	}

}
