package com.jhi.aem.website.v1.core.service.email.models;

import java.util.List;

public class MktTriggerResponse {

	private String requestId;
	private boolean success;
	private List<MktTriggerResult> result;
	private List<Errors> errors;

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public boolean getSuccess() {
		return success;
	}

	public void setResult(List<MktTriggerResult> result) {
		this.result = result;
	}

	public List<MktTriggerResult> getResult() {
		return result;
	}

	public void setErrors(List<Errors> errors) {
		this.errors = errors;
	}

	public List<Errors> getErrors() {
		return errors;
	}
}
