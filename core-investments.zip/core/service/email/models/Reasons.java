package com.jhi.aem.website.v1.core.service.email.models;

public class Reasons {

    String code;
    String message;

    public void setCode( String code){
	   this.code =code;
   }
    public String getCode() {
        return code;
    }
    
    public void setMessage(String message){
    	this.message = message;
    }
    
    public String getMessage(){
    	return message;
    }
}
