package com.jhi.aem.website.v1.core.service.email.models;

/**
 * A serializable JSON request object
 */
public interface EmailPostRequest extends EmailRequest {

}
