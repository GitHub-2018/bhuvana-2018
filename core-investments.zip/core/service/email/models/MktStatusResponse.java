package com.jhi.aem.website.v1.core.service.email.models;

import com.google.gson.annotations.SerializedName;

public class MktStatusResponse {
	@SerializedName("statusCode")
	private String statusCode;
	@SerializedName("statusmessage")
	private String statusMessage;

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusMessage() {
		return statusMessage;
	}
}
