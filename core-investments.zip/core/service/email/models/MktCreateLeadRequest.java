package com.jhi.aem.website.v1.core.service.email.models;

public class MktCreateLeadRequest implements EmailPostRequest {

	private String action;
	private String lookupField;
	private Input[] input;

	public MktCreateLeadRequest(String action) {
		this.action = action;
		this.lookupField = "email";
	}

	public String getAction() {
		return action;
	}

	public String getLookupField() {
		return lookupField;
	}

	public void setInput(Input[] input) {
		this.input = input;
	}

	public Input[] getInput() {
		return input;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "EmailID CreateOnly Request";
	}

}
