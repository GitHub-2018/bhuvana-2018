package com.jhi.aem.website.v1.core.service.email.models;

public class MktTriggerResult {

	private int id;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}
}
