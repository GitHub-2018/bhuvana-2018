package com.jhi.aem.website.v1.core.service.email.models;

public class Input {

	private String email;
	private String firstName;
	private String postalCode;
	private String mRegistrationGroup;
	private String mRegistrationStatus;

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setMRegistrationGroup(String mRegistrationGroup) {
		this.mRegistrationGroup = mRegistrationGroup;
	}

	public String getMRegistrationGroup() {
		return mRegistrationGroup;
	}

	public void setMRegistrationStatus(String mRegistrationStatus) {
		this.mRegistrationStatus = mRegistrationStatus;
	}

	public String getMRegistrationStatus() {
		return mRegistrationStatus;
	}

}
