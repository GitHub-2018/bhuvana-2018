package com.jhi.aem.website.v1.core.service.email.models;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class MarketoEmailProgramTokenRequest {

	private String userId;
	private String emailAddress;
	private String firstName;
	private String lastName;
	private String subject;
	private String emailContent;
	private String campaignId;
	private ArrayList<String> emailList;
	private ArrayList<Integer> leads;
	private LinkedHashMap<String, String> lHashMap;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public ArrayList<String> getEmailList() {
		return emailList;
	}

	public void setEmailList(ArrayList<String> emailList) {
		this.emailList = emailList;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String geLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEmailContent() {
		return emailContent;
	}

	public void setEmailContent(String emailContent) {
		this.emailContent = emailContent;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getCampaignId() {
		return campaignId;
	}
	
	public ArrayList<Integer> getLeads() {
		return leads;
	}

	public void setLeads(ArrayList<Integer> leads) {
		this.leads = leads;
	}
	
	public void setTokenLHashMap(LinkedHashMap<String, String>lHashMap){
		this.lHashMap = lHashMap;
	}
	public LinkedHashMap<String, String> getTokenLHashMap(){
		return  lHashMap;
	}
}
