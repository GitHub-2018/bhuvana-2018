package com.jhi.aem.website.v1.core.service.email.models;

import java.util.List;

public class MktCreateLeadResponse implements EmailResponse {

	String requestId;
	List<Result> result;
	List<Errors> errors;
	boolean success;
	@Override
	public String getCode() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public boolean getSuccess() {
		return success;
	}

	public void setResult(List<Result> result) {
		this.result = result;
	}

	public List<Result> getResult() {
		return result;
	}
	
	public void setErrors(List<Errors> errors) {
		this.errors = errors;
	}

	public List<Errors> getErrors() {
		return errors;
	}


}
