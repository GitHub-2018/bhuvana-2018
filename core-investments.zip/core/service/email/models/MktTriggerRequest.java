package com.jhi.aem.website.v1.core.service.email.models;

public class MktTriggerRequest {

	private TriggerInput input;

	
	public void setInput(TriggerInput input) {
		this.input = input;
	}

	public TriggerInput getInput() {
		return input;
	}

}
