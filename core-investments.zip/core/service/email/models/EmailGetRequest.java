package com.jhi.aem.website.v1.core.service.email.models;

public interface EmailGetRequest extends EmailRequest {

}
