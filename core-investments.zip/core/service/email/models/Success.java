package com.jhi.aem.website.v1.core.service.email.models;

public class Success {

    	private boolean success;
    	
    	public void setSucess(boolean success){
    		this.success = success;
    	}
    	public boolean getSucess(){
    		return success;
    	} 	
    
}
