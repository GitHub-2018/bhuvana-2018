package com.jhi.aem.website.v1.core.service.email.models;

import java.util.List;

public class Result {

	String status;
	long id;
	List<Reasons> reasons;

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}
	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public void setReasons(List<Reasons> reasons) {

		this.reasons = reasons;
	}

	public List<Reasons> getReasons(List<Reasons> reasons) {
		return reasons;
	}

}
