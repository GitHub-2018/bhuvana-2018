package com.jhi.aem.website.v1.core.service.email.models;

import java.util.List;

public class Errors {

	String message;
	String code;

	public void setStatus(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setId(String code) {
		this.code = code;
	}

	public String getId() {
		return code;
	}

}
