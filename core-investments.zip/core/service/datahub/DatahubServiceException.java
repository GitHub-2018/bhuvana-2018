package com.jhi.aem.website.v1.core.service.datahub;

public class DatahubServiceException extends Exception {
	public static final int NO_STATUS_CODE = -1;
	private int statusCode = NO_STATUS_CODE;

	public DatahubServiceException() {
		super();
	}

	public DatahubServiceException(String arg0) {
		super(arg0);
	}

	public DatahubServiceException(int statusCode, String arg0) {
		super(arg0);
		this.statusCode = statusCode;
	}

	public DatahubServiceException(Throwable arg0) {
		super(arg0);
	}

	public DatahubServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public DatahubServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public int getStatusCode() {
		return statusCode;
	}

}
