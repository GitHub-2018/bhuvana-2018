package com.jhi.aem.website.v1.core.service.datahub;

import com.jhi.aem.website.v1.core.service.datahub.models.FindAdvisorResponse;
import com.jhi.aem.website.v1.core.service.datahub.models.UserLookupResponse;

public interface DatahubService {

	/**
	 * Gets the latest token for the service
	 * @return
	 */
	String getToken() throws DatahubServiceException;

	/**
	 * Finds an advisor by their email address
	 * @param emailAddress
	 * @return
	 */
	FindAdvisorResponse findAdvisorByEmailAddress(String emailAddress) throws DatahubServiceException;

	/**
	 * Lookup a user by their representative id
	 * @param repId
	 * @return
	 */
	UserLookupResponse lookupUserByRepId(String repId) throws DatahubServiceException;

}
