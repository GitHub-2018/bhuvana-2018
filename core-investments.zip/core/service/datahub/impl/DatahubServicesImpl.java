package com.jhi.aem.website.v1.core.service.datahub.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.collections4.map.SingletonMap;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicNameValuePair;
import org.apache.jackrabbit.oak.commons.DebugTimer;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolExecutor;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolService;
import com.jhi.aem.website.v1.core.service.datahub.DatahubService;
import com.jhi.aem.website.v1.core.service.datahub.DatahubServiceException;
import com.jhi.aem.website.v1.core.service.datahub.models.DatahubResponse;
import com.jhi.aem.website.v1.core.service.datahub.models.FindAdvisorResponse;
import com.jhi.aem.website.v1.core.service.datahub.models.TokenResponse;
import com.jhi.aem.website.v1.core.service.datahub.models.UserLookupResponse;
import com.jhi.aem.website.v1.core.utils.JsonUtil;
import com.jhi.aem.website.v1.core.utils.LogUtils;

@Component(
		name="Datahub Services Implementation",
		immediate = true,
		service = DatahubService.class,
		configurationPid="com.jhi.aem.website.v1.core.service.datahub.impl.DatahubServicesImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website Datahub Service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

@Designate(ocd=DatahubServicesImpl.Config.class )
public class DatahubServicesImpl implements DatahubService {
	private static final String DEFAULT_UPDATED_SINCE_LOOKUP_USER_DATE = "01/01/1990";

	private static final Logger LOG = LoggerFactory.getLogger(DatahubServicesImpl.class);

	private static final int DEFAULT_REQUEST_TIMEOUT_MS = 30000;
	private static final String DEFAULT_DATAHUB_SERVICE_URL = "api-sys1.jhinvestments.com";
	private static final String DEFAULT_DATAHUB_TOKEN_USERNAME = "TestRepSYS123";
	private static final String DEFAULT_DATAHUB_TOKEN_PASSWORD = "AdminSys321";
	private static final String DEFAULT_DATAHUB_TOKEN_GRANT_TYPE = "password";
	
	@ObjectClassDefinition(name="Datahub Service Configuration for JHI Website",description="Configurations for Datahub Service configurations")
	public @interface Config{
		
	@AttributeDefinition(name = "Datahub Service HTTP Request Timeout", type = AttributeType.INTEGER ,
			description = "The Datahub service HTTP Request Timeout in milliseconds")
    int requestTimeoutMs() default DEFAULT_REQUEST_TIMEOUT_MS ;
	
	@AttributeDefinition(name = "Datahub Service URL",description = "The Datahub service URL")
	String serviceUrl() default DEFAULT_DATAHUB_SERVICE_URL;
	
	@AttributeDefinition(name = "Datahub Token Service Username",
			description = "The username for the Datahub token service")
    String tokenUsername() default DEFAULT_DATAHUB_TOKEN_USERNAME;
	
	@AttributeDefinition(name = "Datahub Token Service Password",
			description = "The password for the Datahub token service")
    String tokenPassword() default DEFAULT_DATAHUB_TOKEN_PASSWORD;
	
	@AttributeDefinition(name = "Datahub Token Service Grant Type",
			description = "The grant type for the Datahub token service")
    String grantType() default DEFAULT_DATAHUB_TOKEN_GRANT_TYPE;
	}

	private static final int DEFAULT_RETRIES = 1;
	private int requestTimeoutMs;
    private String serviceUrl;
	private String tokenUsername;
    private String tokenPassword;
    private String grantType;
    
    private AsyncHttpClientPoolService httpClientPool;
    @Reference
    public void bindAsyncHttpClientPoolService(AsyncHttpClientPoolService httpClientPool) {
    	this.httpClientPool=httpClientPool;
    }
    public void unbindAsyncHttpClientPoolService(AsyncHttpClientPoolService httpClientPool) {
    	this.httpClientPool=httpClientPool;
    }
    
    
    private GsonBuilder gsonBuilder;
    
    private ReentrantReadWriteLock tokenReadWriteLock;
    
    private TokenResponse tokenResponse;

	private String tokenServiceUrl;

	private String findAdvisorServiceUrl;

	private String lookupUserServiceUrl;

	@Activate
    public void activate(final Config config) {
    	tokenReadWriteLock = new ReentrantReadWriteLock();
    	gsonBuilder = new GsonBuilder();
    	gsonBuilder.enableComplexMapKeySerialization();
    	configure(config);
    }

    @Modified
    protected void modified(final Config config) {
        configure(config);
    }
    
    public void configure(final Config config) {
    	serviceUrl = config.serviceUrl();
    	tokenUsername = config.tokenUsername();
    	tokenPassword = config.tokenPassword();
    	grantType = config.grantType();
    	requestTimeoutMs = config.requestTimeoutMs();
    	
    	if (StringUtils.isBlank(serviceUrl)) {
    		throw new RuntimeException("Service URL must be configured");
    	}
    	if (StringUtils.isBlank(tokenUsername)) {
    		throw new RuntimeException("Token Username must be configured");
    	}
    	if (StringUtils.isBlank(tokenPassword)) {
    		throw new RuntimeException("Token Password must be configured");
    	}
    	if (StringUtils.isBlank(grantType)) {
    		throw new RuntimeException("Token Grant Type must be configured");
    	}
    	
    	tokenServiceUrl = "https://" + serviceUrl + "/advisor/token";
    	findAdvisorServiceUrl = "https://" + serviceUrl + "/advisor/findadvisor";
    	lookupUserServiceUrl = "https://" + serviceUrl + "/Advisor/LookupUser";
    }

    @Override
	public String getToken() throws DatahubServiceException {
		return getToken(false);
	}

    protected String getToken(boolean forceNewToken) throws DatahubServiceException {
        final DebugTimer timer = new DebugTimer();
        tokenReadWriteLock.readLock().lock();

        try {
            if (forceNewToken || isTokenInvalid()) {
                // Upgrade to a write lock
                tokenReadWriteLock.readLock().unlock();
                tokenReadWriteLock.writeLock().lock();

                try {
                    timer.mark("token write lock acquisition");

                    // Check again to make sure another thread didn't just create a valid token
                    if (forceNewToken || isTokenInvalid()) {
                        // Empty the current response if it exists
                        tokenResponse = null;
                        LOG.info("Issuing a new token request...");

	    	    		// Request a new token
	    	    		List<NameValuePair> requestBodyParams =
	    	    			Lists.newArrayList(
	    	    				new BasicNameValuePair("username", tokenUsername),
	    	    				new BasicNameValuePair("password", tokenPassword),
	    	    				new BasicNameValuePair("grant_type", grantType)
	    	    			);

	    	    		UrlEncodedFormEntity requestBodyParamsEntity;
						try {
	    	    			requestBodyParamsEntity =
	    	    					new UrlEncodedFormEntity(requestBodyParams, JhiConstants.DEFAULT_CHARSET_NAME);
	    	    		} catch (UnsupportedEncodingException e) {
	    	    			throw new DatahubServiceException("Cannot support default encoding '" +
	    	    					JhiConstants.DEFAULT_CHARSET_NAME + "'", e);
	    	    		}

	    	    		@SuppressWarnings("unchecked")
						TokenResponse tokenResponse =
	    	    				doDatahubPost(gsonBuilder.create(), tokenServiceUrl, false,
	    	    						requestBodyParamsEntity, TokenResponse.class);
	    	    		timer.mark("token API");

	    	    		// Is it a valid response? If not don't save the value
	    	    		if (!tokenResponse.isErrorResponse()) {
	    	    			this.tokenResponse = tokenResponse;
		    	    		LOG.info("A new token was received");
	    	    		} else {
	    	    			LOG.warn("Request for a new token received an error response: {}", tokenResponse);
	    	    		}
	    	    	}
	    		} finally {
	    			// Acquire the read lock again
	    	    	tokenReadWriteLock.readLock().lock();
	    			// Release the write lock
		    		tokenReadWriteLock.writeLock().unlock();
	    		}
	    	}

            if (isTokenInvalid()) {
                LOG.error("Did not receive a valid token from the Datahub token service: {}", tokenResponse);
                throw new DatahubServiceException("Did not receive a valid token from the Datahub token service");
            }

            return tokenResponse.getAccessToken();
        } finally {
            tokenReadWriteLock.readLock().unlock();
            timer.mark("token locks release");
            if (LOG.isDebugEnabled()) {
                LOG.debug("token -> {}", timer.getString());
            }
        }
    }

    private boolean isTokenInvalid() {
        return tokenResponse == null || !StringUtils.isNotBlank(tokenResponse.getAccessToken()) || tokenResponse.hasExpired();
    }

    @Override
    public FindAdvisorResponse findAdvisorByEmailAddress(String emailAddress) throws DatahubServiceException {
        final DebugTimer timer = new DebugTimer();
        //Map<String, String> requestHeaders = new SingletonMap<>("Authorization", "bearer " + getToken());
        timer.mark("token acquisition");

        Map<String, Object> requestParamsMap = new HashMap<>();
        requestParamsMap.put("EmailId", emailAddress);
        Gson gson = gsonBuilder.create();
        StringEntity requestBodyParamsEntity =
                new StringEntity(gson.toJson(requestParamsMap), ContentType.APPLICATION_JSON);

		FindAdvisorResponse response = doDatahubPost(gson, findAdvisorServiceUrl, true,
				requestBodyParamsEntity, FindAdvisorResponse.class);
		timer.mark("findAdvisor API");
		if (LOG.isDebugEnabled()) {
			LOG.debug("findAdvisor -> {}", timer.getString());
		}

		return response;
	}

	@Override
	public UserLookupResponse lookupUserByRepId(String repId) throws DatahubServiceException {
		final DebugTimer timer = new DebugTimer();

		Map<String,Object> requestParamsMap = new HashMap<>();
		requestParamsMap.put("Id", repId);
		requestParamsMap.put("UpdatedSince", DEFAULT_UPDATED_SINCE_LOOKUP_USER_DATE);
		Gson gson = gsonBuilder.create();
		StringEntity requestBodyParamsEntity =
				new StringEntity(gson.toJson(requestParamsMap), ContentType.APPLICATION_JSON);

		UserLookupResponse response =
				doDatahubPost(gson, lookupUserServiceUrl, true, requestBodyParamsEntity, UserLookupResponse.class);
		timer.mark("lookupUser API");
		if (LOG.isDebugEnabled()) {
			LOG.debug("lookupUser -> {}", timer.getString());
		}
		return response;
	}

    private <T extends DatahubResponse> T doDatahubPost(Gson gson, String url, boolean useTokenHeader,
                                                        HttpEntity requestBodyParametersEntity,
                                                        Class<T> datahubResponseClass) throws DatahubServiceException {
        final DebugTimer timer = new DebugTimer();
        LOG.debug("Datahub POST to '{}'", url);
        final HttpPost postMethod = new HttpPost(url);

        // Add all the headers
        postMethod.addHeader("Content-Type", JhiConstants.APPLICATION_JSON_RESPONSE);
        postMethod.setEntity(requestBodyParametersEntity);

        try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
        	int retryCounter = 0;
        	DatahubServiceException lastException = null;

        	// Retry on token errors
        	while (retryCounter < DEFAULT_RETRIES) {
                // Use token authorization for this call
                if (useTokenHeader) {
                	postMethod.setHeader("Authorization", "bearer " + getToken(retryCounter > 0));
        			timer.mark("token acquisition");
                }

	        	timer.mark("preparing request");
	            Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(postMethod);
	            HttpResponse httpResponse = future.get(requestTimeoutMs, TimeUnit.MILLISECONDS);
	            timer.mark("http response");
	            
	            try {
	            	checkStatusCode(url, postMethod, httpResponse);
	            } catch (DatahubServiceException dhe) {
            		lastException = dhe;

            		// Throw all other errors
            		if (HttpStatus.SC_UNAUTHORIZED != dhe.getStatusCode()) {
	            		throw dhe;
	            	}
	            	
	            	// Retry when unauthorized by refreshing the token
            		retryCounter++;
            		LOG.debug("Unauthorized response, retry #{}", retryCounter);
	            }

	            return gson.fromJson(JsonUtil.getJsonContent(httpResponse.getEntity().getContent()), datahubResponseClass);
        	}

        	throw lastException == null ? new DatahubServiceException() : lastException;
        } catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
            LOG.error("Error calling Datahub API URL '" + StringUtils.abbreviate(url, 64) + "'", e);
            throw new DatahubServiceException("Error calling Datahub API URL '" + url + "'", e);
        } finally {
			LOG.debug("Datahub POST({}) -> {}", url, timer.getString());
        }
	}

	private static void checkStatusCode(String execType, HttpRequest request, HttpResponse httpResponse) throws DatahubServiceException {
		if (httpResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {	
			String responseContent = "";
			InputStream is = null;
			try {
				is = httpResponse.getEntity().getContent();
				responseContent = IOUtils.toString(is, StandardCharsets.UTF_8);
			} catch (UnsupportedOperationException | IOException e) {
				LOG.warn("Could not get response content", e);
			} finally {
				IOUtils.closeQuietly(is);
			}

			throw new DatahubServiceException(httpResponse.getStatusLine().getStatusCode(),
					"Error executing " + execType + " (" + request.getRequestLine().getMethod() +
					" - " + request.getRequestLine().getUri() + "): " +
					httpResponse.getStatusLine().getStatusCode() + " - " +
					LogUtils.sanitizeLogInput(httpResponse.getStatusLine().getReasonPhrase()) + " - " +
					LogUtils.sanitizeLogInput(responseContent));
		}
	}

}