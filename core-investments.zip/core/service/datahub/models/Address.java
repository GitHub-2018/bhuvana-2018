package com.jhi.aem.website.v1.core.service.datahub.models;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.google.gson.annotations.SerializedName;

public class Address {
	@SerializedName("line1")
	private String line1;

	@SerializedName("line2")
	private String line2;

	@SerializedName("city")
	private String city;

	@SerializedName("stateCode")
	private String stateCode;

	@SerializedName("zip")
	private String zip;

	@SerializedName("primaryPhone")
	private String primaryPhone;

	@SerializedName("emailID")
	private String emailID;

	public String getLine1() {
		return line1;
	}

	public String getLine2() {
		return line2;
	}

	public String getCity() {
		return city;
	}

	public String getStateCode() {
		return stateCode;
	}

	public String getZip() {
		return zip;
	}

	public String getPrimaryPhone() {
		return primaryPhone;
	}

	public String getEmailID() {
		return emailID;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}


}
