package com.jhi.aem.website.v1.core.service.datahub.models;

import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.google.gson.annotations.SerializedName;

public class UserLookupResponse extends DatahubResponse {
	@SerializedName("statusCode")
	private int statusCode;
	
	@SerializedName("rep")
	private List<RepLookupRepresentative> representatives;

	public int getStatusCode() {
		return statusCode;
	}

	public List<RepLookupRepresentative> getRepresentatives() {
		return representatives;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
