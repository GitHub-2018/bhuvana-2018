package com.jhi.aem.website.v1.core.service.datahub.models;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.annotations.SerializedName;

/**
 * Base Datahub response
 */
public abstract class DatahubResponse {
	@SerializedName("message")
	private String message;

	public String getMessage() {
		return message;
	}
	
	public boolean isErrorResponse() {
		return StringUtils.isNotBlank(message);
	}

}
