package com.jhi.aem.website.v1.core.service.datahub.models;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.google.gson.annotations.SerializedName;

public class Representative {
	@SerializedName("repID")
	private String repID;

	@SerializedName("webID")
	private String webID;

	@SerializedName("firstName")
	private String firstName;

	@SerializedName("lastName")
	private String lastName;

	@SerializedName("firmID")
	private String firmID;

	@SerializedName("firmName")
	private String firmName;

	@SerializedName("retailID")
	private String retailID;

	@SerializedName("separateAccountID")
	private String separateAccountID;

	@SerializedName("address")
	private Address address;

	public String getRepID() {
		return repID;
	}

	public String getWebID() {
		return webID;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirmID() {
		return firmID;
	}

	public String getRetailID() {
		return retailID;
	}

	public String getSeparateAccountID() {
		return separateAccountID;
	}

	public Address getAddress() {
		return address;
	}

	public String getFirmName() {
		return firmName;
	}

	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}


}
