package com.jhi.aem.website.v1.core.service.datahub.models;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.google.gson.annotations.SerializedName;

public class TokenResponse extends DatahubResponse {
	private static final long RESPONSE_VALIDITY_GRACE_PERIOD = 20000;

	@SerializedName("access_token")
	private String accessToken;

	@SerializedName("token_type")
	private String tokenType;

	@SerializedName("expires_in")
	private long expiresInSeconds;
	
	private long createdDate = System.currentTimeMillis();

	public String getAccessToken() {
		return accessToken;
	}

	public String getTokenType() {
		return tokenType;
	}

	public long getExpiresInSeconds() {
		return expiresInSeconds;
	}

	public long getCreatedDate() {
		return createdDate;
	}

	public boolean hasExpired() {
		return (createdDate + (expiresInSeconds * 1000)) < (System.currentTimeMillis() + RESPONSE_VALIDITY_GRACE_PERIOD);
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
