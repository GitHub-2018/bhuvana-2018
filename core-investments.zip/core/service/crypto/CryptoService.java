package com.jhi.aem.website.v1.core.service.crypto;

import io.jsonwebtoken.SignatureAlgorithm;

public interface CryptoService {

	byte[] getHmacSigningKey();

	SignatureAlgorithm getSignatureAlgorithmForHmacKey();

	String getHmacSigningAlgorithmNameForHmacKey();

}
