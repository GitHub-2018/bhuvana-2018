package com.jhi.aem.website.v1.core.service.crypto;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

import io.jsonwebtoken.SignatureAlgorithm;

@Component(
		name="Crypto Service implementation",
		immediate = true,
		service=CryptoService.class,
		property= {
				Constants.SERVICE_DESCRIPTION+"=Crypto Service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

public class CryptoServiceImpl implements CryptoService {
	private static final String AEM_ETC_KEY_HMAC_PROPERTY = "hmac";

	private static final String AEM_ETC_KEY_NODE = "/etc/key";

	private final static Logger LOG = LoggerFactory.getLogger(CryptoServiceImpl.class);

    private byte[] hmacSigningKey;

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }

    @Activate
    public void activate() throws IllegalAccessException, LoginException, IOException {
    	doConfigure();
        LOG.info("Activated ISAM Authentication Handler");
    }

	@Modified
    public void modified(Map<String, Object> properties) throws IllegalAccessException, LoginException, IOException {
		doConfigure();
        LOG.info("Modified ISAM Authentication Handler");
    }

    private void doConfigure() throws LoginException, IllegalAccessException, IOException {

    	// Get the HMAC crypto key from AEM
    	ResourceResolver resolver = null;
		try {
            resolver = resolverFactory.getServiceResourceResolver(
                    Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_CRYPTO_SERVICE_USER));
            if (resolver == null) {
            	LOG.error("Could not retrieve resource resolver for '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER);
            	throw new RuntimeException("Cannot retrieve crypto key, admin user '" + 
            	JhiConstants.JHI_CRYPTO_SERVICE_USER + "' is not available");
            }

            Resource cryptoKey = resolver.resolve(AEM_ETC_KEY_NODE);
            
            if (ResourceUtil.isNonExistingResource(cryptoKey)) {
            	throw new IllegalAccessException("Cannot find HMAC crypto key");
            }

            ValueMap cryptoKeyMap = cryptoKey.adaptTo(ValueMap.class);
            hmacSigningKey = IOUtils.toByteArray(cryptoKeyMap.get(AEM_ETC_KEY_HMAC_PROPERTY, InputStream.class));
        } finally {
            if (resolver != null) {
                resolver.close();
            }
        }
	}

    @Override
	public byte[] getHmacSigningKey() {
    	return hmacSigningKey;
    }

    @Override
	public SignatureAlgorithm getSignatureAlgorithmForHmacKey() {
    	return SignatureAlgorithm.HS384;
    }
    
    @Override
	public String getHmacSigningAlgorithmNameForHmacKey() {
    	return getSignatureAlgorithmForHmacKey().getJcaName();
    }

}
