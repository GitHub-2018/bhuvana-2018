package com.jhi.aem.website.v1.core.commerce.rrd;

public enum RrdItemStatus {

    ACTIVE, //
    DISCONTINUED, //
    TO_BE_DISCONTINUED, //
    INACTIVE, //
    NOT_FOUND
}
