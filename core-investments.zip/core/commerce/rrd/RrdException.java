package com.jhi.aem.website.v1.core.commerce.rrd;

public class RrdException extends Exception {

    private static final long serialVersionUID = -3607468711347144226L;

    public RrdException(String message) {
        super(message);
    }

    public RrdException(String message, Throwable cause) {
        super(message, cause);
    }
}
