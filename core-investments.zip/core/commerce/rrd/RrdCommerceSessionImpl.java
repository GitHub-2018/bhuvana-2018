package com.jhi.aem.website.v1.core.commerce.rrd;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.PlacedOrder;
import com.adobe.cq.commerce.api.Product;
import com.adobe.cq.commerce.common.AbstractJcrCommerceSession;
import com.adobe.granite.security.user.UserProperties;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.personalization.UserPropertiesUtil;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.commerce.rrd.models.OrderHeader;
import com.jhi.aem.website.v1.core.commerce.rrd.models.OrderLine;
import com.jhi.aem.website.v1.core.commerce.rrd.models.ShiptoFields;
import com.jhi.aem.website.v1.core.commerce.rrd.models.SubmitOrderRequest;
import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.RrdService;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.user.AddressModel;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.utils.DateUtil;


public class RrdCommerceSessionImpl extends AbstractJcrCommerceSession {

    private static final Logger LOGGER = LoggerFactory.getLogger(RrdCommerceSessionImpl.class);

    private static final String ORDERS_PATH = "orders";
    public static final String COMMERCE_ORDERS_PATH = "/commerce/" + ORDERS_PATH + "/";
    public static final String ORDER_ID_PROPERTY = "orderId";
    public static final String ORDER_DETAILS_PATH = "order-details";
    public static final char ITEM_ENTRY_SEPARATOR = ':';
    public static final String ORDER_STATUS_SEPARATOR = "|";
    public static final String CART_ITEMS_PROPERTY = "cartItems";
    public static final String ORDER_DATE = "orderDate";

    public static final String ORDER_STATUS_PROPERTY = "status";
    public static final String ORDER_CLOSED = "Closed";
    public static final String ORDER_OPEN = "Open";

    private static final String COMMERCE_PROFILE_PATH = "commerce";
    private static final String CART_PATH = "cart";
    private static final String ORDER_NAME_PATTERN = "order-%d";
    private static final String ITEMS_PROPERTY = "items";

    private static final String ADDRESS_OPTION_PROPERTY = "addressOption";
    private static final String SAVE_ADDRESS_PROPERTY = "saveAddress";
    private static final String NEW_ADDRESS_OPTION = "new";

    private static final Map<String, Object> COMMERCE_PARAMETERS_MAP = Collections.singletonMap(JcrConstants.JCR_PRIMARYTYPE,
            JcrResourceConstants.NT_SLING_FOLDER);
    private static final String SHIPPING_SERVICE_LEVEL_UPS_GROUND = "UPS GROUND";

    private String orderId;

    public RrdCommerceSessionImpl(RrdCommerceServiceImpl commerceService, SlingHttpServletRequest request,
                                  SlingHttpServletResponse response, Resource resource) throws CommerceException {
    	super(commerceService, request, response, resource);
    }

    @Override
    public void saveCart() throws CommerceException {
        String[] cartItems = new String[cart.size()];
        int i = 0;
        for (CartEntry entry : cart) {
            cartItems[i++] = entry.getProduct().getSKU() + ITEM_ENTRY_SEPARATOR + entry.getQuantity();
        }
        if (!UserPropertiesUtil.isAnonymous(request)) {
            Resource cartResource = prepareUserCartResource();
            if (cartResource != null) {
                ModifiableValueMap cartProperties = cartResource.adaptTo(ModifiableValueMap.class);
                if (cartProperties != null) {
                    cartProperties.put(ITEMS_PROPERTY, cartItems);
                    if (StringUtils.isBlank(orderId)) {
                        // TODO: Check for clashes in this identifier with saved orders?
                        orderId = Long.toString(RrdOrderUtils.generateOrderId());
                    }
                    cartProperties.put(ORDER_ID_PROPERTY, orderId);
                    try {
                        resolver.commit();
                    } catch (PersistenceException e) {
                        LOGGER.error("Problem while saving cart", e);
                    }
                }
            }
        }
    }

    private Resource prepareUserCartResource() {
        Resource commerceResource = getUserCommerceResource();
        if (commerceResource == null) {
            return null;
        }
        Resource cartResource = commerceResource.getChild(CART_PATH);
        if (cartResource == null) {
            final Map<String, Object> cartProperties = new HashMap<>();
            cartProperties.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
            cartProperties.put(JcrConstants.JCR_CREATED, Calendar.getInstance(this.locale));
            try {
                cartResource = resolver.create(commerceResource, CART_PATH, cartProperties);
                resolver.commit();
            } catch (PersistenceException e) {
                LOGGER.error("Problem while creating cart node", e);
                cartResource = null;
            }
        }
        return cartResource;
    }

    @Override
    public void loadCart() {
        if (!UserPropertiesUtil.isAnonymous(request)) {
            Resource commerceResource = getUserCommerceResource();
            if (commerceResource != null) {
                Resource cartResource = commerceResource.getChild(CART_PATH);
                if (cartResource != null) {
                    ValueMap cartProperties = cartResource.getValueMap();
                    String[] items = cartProperties.get(ITEMS_PROPERTY, ArrayUtils.EMPTY_STRING_ARRAY);
                    for (String item : items) {
                        loadItemEntry(item);
                    }
                    String orderIdValue = cartProperties.get(ORDER_ID_PROPERTY, StringUtils.EMPTY);
                    if (StringUtils.isNotBlank(orderIdValue)) {
                        orderId = orderIdValue;
                    }
                }
            }
        }
    }

    private Resource getUserCommerceResource() {
        if (UserPropertiesUtil.isAnonymous(request)) {
            return null;
        }
        UserProperties userProperties = request.adaptTo(UserProperties.class);
        if (userProperties != null) {
            Resource profileResource = resolver.getResource(userProperties.getAuthorizablePath());
            if (profileResource != null) {
                Resource commerceResource = profileResource.getChild(COMMERCE_PROFILE_PATH);
                if (commerceResource == null) {
                    final Map<String, Object> commerceProperties = new HashMap<>();
                    commerceProperties.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
                    try {
                        commerceResource = resolver.create(profileResource, COMMERCE_PROFILE_PATH, commerceProperties);
                        resolver.commit();
                    } catch (PersistenceException e) {
                        LOGGER.error("Problem while creating commerce node", e);
                        commerceResource = null;
                    }
                }
                return commerceResource;
            }
        }
        return null;
    }

    private void loadItemEntry(String productEntry) {
        if (StringUtils.isNotBlank(productEntry)) {
            String[] entryParts = StringUtils.split(productEntry, ITEM_ENTRY_SEPARATOR);
            if (entryParts.length == 2) {
                final String productId = entryParts[0];
                final String quantityString = entryParts[1];
                int quantity = 1;
                if (StringUtils.isNumeric(quantityString)) {
                    quantity = Integer.parseInt(quantityString);
                }
                Product product = getProduct(productId);
                if (product != null && quantity > 0) {
                    try {
                        doAddCartEntry(product, quantity, null);
                    } catch (CommerceException e) {
                        LOGGER.error("Problem while adding item to cart", e);
                    }
                }
            } else {
                LOGGER.error("Incorrect product cart entry : " + productEntry);
            }
        }
    }

    public int getEntryNumber(String entryCode) {
        int result = -1;
        for (int i = 0; i < cart.size(); i++) {
            try {
                if (cart.get(i).getProduct().getSKU().equals(entryCode)) {
                    return i;
                }
            } catch (CommerceException e) {
                LOGGER.error("Problem while taking product", e);
            }
        }
        return result;
    }

    @Override
    public void deleteCartEntry(int entryNumber) throws CommerceException {
        if (entryNumber >= 0 && entryNumber < cart.size()) {
            cart.remove(entryNumber);
        }
        this.saveCart();
    }

    @Override
    protected void doPlaceOrder(Map<String, String> orderDetailsDelta) throws CommerceException {
        orderDetails.putAll(orderDetailsDelta);
        savePlacedOrderShopperRecord();

        this.orderId = StringUtils.EMPTY;
        this.cart.clear();
        this.vouchers.clear();
        this.orderDetails.clear();
        saveCart();
    }

    @Override
    protected void savePlacedOrderShopperRecord() throws CommerceException {
        UserProperties userProperties = this.request.adaptTo(UserProperties.class);
        if ((userProperties != null) && (!UserPropertiesUtil.isAnonymous(userProperties))) {
            Calendar now = Calendar.getInstance(this.locale);
            Resource userCommerceResource = getUserCommerceResource();
            if (userCommerceResource == null) {
                throw new CommerceException("User commerce resource doesn't exist");
            }
            Resource ordersResource = getOrdersResource(userCommerceResource);
            if (ordersResource == null) {
                throw new CommerceException("User commerce orders resource doesn't exist");
            }
            try {
                saveAndSubmitOrderDetails(ordersResource, now);
                resolver.commit();
            } catch (PersistenceException e) {
                LOGGER.error("Problem while saving order", e);
                throw new CommerceException("Saving order details failed");
            }
        }
    }

    private Resource getOrdersResource(Resource userCommerceResource) {
        Resource ordersResource = userCommerceResource.getChild(ORDERS_PATH);
        if (ordersResource == null) {
            try {
                ordersResource = resolver.create(userCommerceResource, ORDERS_PATH, COMMERCE_PARAMETERS_MAP);
                resolver.commit();
            } catch (PersistenceException e) {
                LOGGER.error("Problem while creating orders folder", e);
                ordersResource = null;
            }
        }
        return ordersResource;
    }

    private void saveAndSubmitOrderDetails(Resource ordersResource, Calendar orderDate) throws PersistenceException {
        final Map<String, Object> orderParameters = new HashMap<>(6);
        final String[] entries = new String[cart.size()];

        try {
            int i = 0;
            for (CartEntry cartEntry : cart) {
                entries[i++] = cartEntry.getProduct().getSKU() + ITEM_ENTRY_SEPARATOR + cartEntry.getQuantity();
            }
        } catch (CommerceException e) {
            LOGGER.error("Problem while serializing cart entries", e);
        }

        orderParameters.put(CART_ITEMS_PROPERTY, entries);
        orderParameters.put(JcrConstants.JCR_LANGUAGE, getLocale().toString());
        orderParameters.put(ORDER_DATE, orderDate);
        orderParameters.put(ORDER_ID_PROPERTY, this.orderId);
        orderParameters.put(ORDER_STATUS_PROPERTY, ORDER_OPEN);
        orderParameters.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);

        Resource orderResource = resolver.create(ordersResource, String.format(ORDER_NAME_PATTERN, orderDate.getTime().getTime()), orderParameters);
        final Map<String, Object> orderDetailsParameters = processOrderDetails();
        resolver.create(orderResource, ORDER_DETAILS_PATH, orderDetailsParameters);
        resolver.commit();

        submitOrderDetails(orderDetailsParameters, orderDate);
    }

    private void submitOrderDetails(Map<String, Object> orderDetailsParameters, Calendar orderDate) {
        final ShiptoFields shipToFields = new ShiptoFields(new AddressModel(orderDetailsParameters));
        final OrderHeader orderHeader = new OrderHeader(this.orderId, DateUtil.getFormattedUsDate(orderDate, null),
                SHIPPING_SERVICE_LEVEL_UPS_GROUND, StringUtils.EMPTY, "1", shipToFields);

        final List<OrderLine> orders = new ArrayList<>(cart.size());

        try {
            for (CartEntry cartEntry : cart) {
                RrdProductImpl rrdProduct = (RrdProductImpl) cartEntry.getProduct();
                final OrderLine order = new OrderLine(rrdProduct.getCode(), cartEntry.getQuantity(), rrdProduct.getUomCode());
                orders.add(order);
            }
        } catch (CommerceException e) {
            LOGGER.error("Problem while serializing cart entries", e);
        }

        try {
            final SubmitOrderRequest submitOrderRequest = new SubmitOrderRequest(orderHeader, orders);
            getRrdService().submitOrder(submitOrderRequest);
        } catch (RrdException e) {
            LOGGER.error("Problem while submitting order", e);
        }
    }

    private Map<String, Object> processOrderDetails() {
        boolean saveAddress = false;
        boolean newAddress = false;

        final Map<String, Object> result = new HashMap<>();
        result.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);

        for (Map.Entry<String, String> entry : this.orderDetails.entrySet()) {
            String key = entry.getKey();
            if (!StringUtils.equals(key, ADDRESS_OPTION_PROPERTY)) {
                result.put(key, entry.getValue());
            } else {
                if (StringUtils.equals(entry.getValue(), NEW_ADDRESS_OPTION)) {
                    newAddress = true;
                    if (result.containsKey(SAVE_ADDRESS_PROPERTY)) {
                        saveAddress = true;
                    }
                } else {
                    UserProfileService userProfileService = getUserProfileService();
                    AddressModel addressModel = userProfileService.getAddress(resolver, entry.getValue());
                    if (addressModel != null) {
                        result.putAll(addressModel.getValueMap(false));
                    }
                }
            }
        }
        if (newAddress && saveAddress) {
            UserProfileService userProfileService = getUserProfileService();
            userProfileService.updateAddress(resolver, StringUtils.EMPTY, new AddressModel(result));
        }
        return result;
    }

    private UserProfileService getUserProfileService() {
        return ((RrdServiceContext) commerceService.serviceContext()).userProfileService;
    }

    private RrdService getRrdService() {
        return ((RrdServiceContext) commerceService.serviceContext()).rrdService;
    }

    @Override
    public String getOrderId() {
        return this.orderId;
    }

    @Override
    public PlacedOrder getPlacedOrder(String orderId) {
        ResourceResolver resourceResolver = getResourceResolver();
        try {
            Session userSession = resourceResolver.adaptTo(Session.class);
            if (userSession == null) {
                LOGGER.error("Cannot obtain user session");
                return null;
            }
            UserProperties userProperties = getRequest().adaptTo(UserProperties.class);
            if ((userProperties != null) && (!UserPropertiesUtil.isAnonymous(userProperties))) {
                UserManager um = ((JackrabbitSession) userSession).getUserManager();
                Authorizable user = um.getAuthorizable(userProperties.getAuthorizableID());

                if (user != null) {
                    Map<String, String> searchParams = new HashMap<>(3);
                    searchParams.put(PathPredicateEvaluator.PATH, user.getPath() + RrdCommerceSessionImpl.COMMERCE_ORDERS_PATH);
                    searchParams.put(JcrPropertyPredicateEvaluator.PROPERTY, RrdCommerceSessionImpl.ORDER_ID_PROPERTY);
                    searchParams.put(JhiConstants.PROPERTY_VALUE_PARAMETER, orderId);
                    QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
                    if (queryBuilder == null) {
                        LOGGER.error("Cannot obtain query builder");
                        return null;
                    }
                    Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
                    query.setHitsPerPage(1);
                    SearchResult queryResult = query.getResult();
                    List<Hit> hits = queryResult.getHits();
                    /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
                    if (!hits.isEmpty()) {
                        try {
                        	String orderPath = hits.get(0).getPath();
                            Resource orderResource = resourceResolver.getResource(orderPath);
                            return new RrdPlacedOrder(this, orderResource);
                        } catch (RepositoryException e) {
                            LOGGER.error("Problem while taking order resource for {}", hits.get(0), e);
                        }
                    }
                    /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
                }
            }
        } catch (RepositoryException e) {
            String cleanOrderId = StringUtils.EMPTY;
            if (StringUtils.isNotBlank(orderId)) {
                cleanOrderId = orderId.replaceAll("[^A-Za-z0-9-]", StringUtils.SPACE);
            }
            LOGGER.error("Error while searching for orderResource history with orderId '" + cleanOrderId + "'", e);
        }
        return null;
    }

    public ResourceResolver getResourceResolver() {
        return resolver;
    }

    public SlingHttpServletRequest getRequest() {
        return request;
    }

    public Product getProduct(String productId) {
        Product product = null;
        try {
            product = ((RrdCommerceServiceImpl) this.commerceService).getProductByCode(productId);
            if (product == null) {
                LOGGER.error("Product cannot be found", productId);
            }
        } catch (CommerceException e) {
            LOGGER.error("Problem while loading product", e);
        }
        return product;
    }
}