package com.jhi.aem.website.v1.core.commerce.rrd;

import java.util.List;

import com.adobe.cq.commerce.api.Product;
import com.adobe.cq.commerce.common.DefaultJcrCartEntry;

public class RrdCartEntry extends DefaultJcrCartEntry {

    private String status;
    private List<OrderItemShipmentDetails> shipmentDetails;

    public RrdCartEntry(int index, Product product, int quantity, List<OrderItemShipmentDetails> shipmentDetails) {
        super(index, product, quantity);
        this.shipmentDetails = shipmentDetails;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<OrderItemShipmentDetails> getShipmentDetails() {
        return shipmentDetails;
    }

    public void setShipmentDetails(List<OrderItemShipmentDetails> shipmentDetails) {
        this.shipmentDetails = shipmentDetails;
    }
}
