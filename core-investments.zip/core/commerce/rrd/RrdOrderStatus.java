package com.jhi.aem.website.v1.core.commerce.rrd;

public enum RrdOrderStatus {

    BACKORDERED("Backordered", "Backordered"),
    IN_PROCESS("IN PROCESS", "In process"),
    SHIPPED("SHIPPED", "Shipped"),
    INVOICED("INVOICED", "Invoiced"),
    ON_HOLD("ON-HOLD", "On hold"),
    MIXED("MIXED", "Mixed"),
    CANCELED("CANCELLED", "Canceled");

    private final String value;
    private final String label;

    RrdOrderStatus(String value, String label) {
        this.value = value;
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }
}
