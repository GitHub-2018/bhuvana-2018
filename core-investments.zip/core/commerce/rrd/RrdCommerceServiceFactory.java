package com.jhi.aem.website.v1.core.commerce.rrd;


import org.apache.sling.api.resource.Resource;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.adobe.cq.commerce.api.CommerceService;
import com.adobe.cq.commerce.api.CommerceServiceFactory;
import com.adobe.cq.commerce.common.AbstractJcrCommerceServiceFactory;
import com.adobe.cq.commerce.common.ServiceContext;
import com.day.cq.wcm.api.LanguageManager;
import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.RrdService;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

@Component(
		name="RRD Commerce Service Factory Implementation",
		service=CommerceServiceFactory.class,
		property= {
				Constants.SERVICE_DESCRIPTION+"=RRD commerce service factory",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR,
				CommerceServiceFactory.PROPERTY_COMMERCE_PROVIDER+"="+JhiConstants.RRD_COMMERCE_PROVIDER
		})

public class RrdCommerceServiceFactory extends AbstractJcrCommerceServiceFactory implements CommerceServiceFactory {

    
    protected UserProfileService userProfileService;
    @Reference
    public void bindUserProfileService(UserProfileService userProfileService) {
    	this.userProfileService = userProfileService;
    }
    public void unbindUserProfileService(UserProfileService userProfileService) {
    	this.userProfileService = userProfileService;
    }
    protected RrdService rrdService;
    @Reference
    public void bindRrdService(RrdService rrdService) {
    	this.rrdService = rrdService;
    }
    public void unbindRrdService(RrdService rrdService) {
    	this.rrdService = rrdService;
    }
    
    protected LanguageManager languageManager;
    @Reference
    public void bindLanguageManager(LanguageManager languageManager) {
    	this.languageManager = languageManager;
    }
    public void unbindLanguageManager(LanguageManager languageManager) {
    	this.languageManager = languageManager;
    }
    
    
  
    
    @Override
    public CommerceService getCommerceService(Resource resource) {
    	super.languageManager=languageManager;
        return new RrdCommerceServiceImpl(getServiceContext(), resource);
    }

    @Override
    protected ServiceContext getServiceContext() {
        return new RrdServiceContext(this);
    }
}
