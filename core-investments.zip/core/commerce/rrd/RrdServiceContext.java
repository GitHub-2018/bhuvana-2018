package com.jhi.aem.website.v1.core.commerce.rrd;

import com.adobe.cq.commerce.common.ServiceContext;
import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.RrdService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

public class RrdServiceContext extends ServiceContext {

    public final UserProfileService userProfileService;
    public final RrdService rrdService;
    public RrdServiceContext(RrdCommerceServiceFactory serviceFactory) {
        super(serviceFactory);
        userProfileService = serviceFactory.userProfileService;
        rrdService = serviceFactory.rrdService;       
    }
}
