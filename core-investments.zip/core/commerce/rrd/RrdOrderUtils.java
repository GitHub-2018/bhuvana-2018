package com.jhi.aem.website.v1.core.commerce.rrd;

import java.security.SecureRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class RrdOrderUtils {
	private static final Logger LOG = LoggerFactory.getLogger(RrdOrderUtils.class);
    private static final SecureRandom random = new SecureRandom();

	private RrdOrderUtils() {}

	public static long generateOrderId() {
		return Math.abs(random.nextLong());
	}
	
	public static long parseOrderId(String orderIdString) {
		try {
			return Long.parseLong(orderIdString);
		} catch (NumberFormatException nfe) {
			LOG.error("Could not parse order id string as a number", nfe);
			throw nfe;
		}
	}

}
