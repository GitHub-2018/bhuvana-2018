package com.jhi.aem.website.v1.core.commerce.rrd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.commerce.api.PlacedOrder;
import com.adobe.cq.commerce.api.PriceInfo;
import com.adobe.cq.commerce.api.Product;
import com.adobe.cq.commerce.api.promotion.PromotionInfo;
import com.adobe.cq.commerce.api.promotion.VoucherInfo;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.user.AddressModel;

public class RrdPlacedOrder implements PlacedOrder {

    private Resource orderResource;
    private String orderId;
    private List<CommerceSession.CartEntry> cartEntries;
    private Map<String, Object> orderDetails;
    private String status;

    public RrdPlacedOrder(RrdCommerceSessionImpl rrdCommerceSession, Resource orderResource) {
        if (orderResource != null) {
            ValueMap values = orderResource.getValueMap();
            this.orderId = values.get(RrdCommerceSessionImpl.ORDER_ID_PROPERTY, String.class);
            status = StringUtils.defaultIfBlank(values.get(RrdCommerceSessionImpl.ORDER_STATUS_PROPERTY, String.class),
                    RrdCommerceSessionImpl.ORDER_OPEN);
        }
        this.orderResource = orderResource;
        cartEntries = initCartEntries(rrdCommerceSession);
        orderDetails = getOrderDetails();
    }

    @Override
    public List<CommerceSession.CartEntry> getCartEntries() {
        return cartEntries;
    }

    @Override
    public String getOrderId() {
        return orderId;
    }

    private List<CommerceSession.CartEntry> initCartEntries(RrdCommerceSessionImpl rrdCommerceSession) {
        if (orderResource == null) {
            return Collections.emptyList();
        }
        ValueMap orderValues = orderResource.getValueMap();
        String[] cartItems = orderValues.get(RrdCommerceSessionImpl.CART_ITEMS_PROPERTY, ArrayUtils.EMPTY_STRING_ARRAY);
        List<CommerceSession.CartEntry> entries = new ArrayList<>(cartItems.length);
        int i = 0;
        for (String itemEntry : cartItems) {
            String[] entryParts = StringUtils.split(itemEntry, RrdCommerceSessionImpl.ORDER_STATUS_SEPARATOR);
            if (entryParts.length > 0) {
                String[] itemInfoParts = StringUtils.split(entryParts[0], RrdCommerceSessionImpl.ITEM_ENTRY_SEPARATOR);
                if (itemInfoParts.length > 0) {
                    Product product = rrdCommerceSession.getProduct(itemInfoParts[0]);
                    if (product != null) {
                        int quantity = 1;
                        if (itemInfoParts.length > 1) {
                            quantity = Integer.parseInt(itemInfoParts[1]);
                        }
                        List<OrderItemShipmentDetails> shipmentDetails = null;
                        if (entryParts.length > 1) {
                            shipmentDetails = getItemStatusesList(entryParts[1], itemInfoParts[1]);
                        }
                        entries.add(new RrdCartEntry(i++, product, quantity, shipmentDetails));
                    }
                }
            }
        }
        return entries;
    }

    private List<OrderItemShipmentDetails> getItemStatusesList(String statusPart, String quantityString) {
        List<OrderItemShipmentDetails> status = null;
        String[] statuses = StringUtils.split(statusPart, JhiConstants.VALUES_SEPARATOR);
        if (statuses.length > 0) {
            status = new ArrayList<>(statuses.length);
            for (String statusEntry : statuses) {
                String[] statusEntryParts = StringUtils.splitPreserveAllTokens(statusEntry, RrdCommerceSessionImpl.ITEM_ENTRY_SEPARATOR);
                String shippedQuantity = StringUtils.EMPTY;
                String date = StringUtils.EMPTY;
                String trackingId = StringUtils.EMPTY;
                if (statusEntryParts.length > 0 && !StringUtils.equals(quantityString, statusEntryParts[0])) {
                    shippedQuantity = statusEntryParts[0];
                }
                if (statusEntryParts.length > 1) {
                    date = statusEntryParts[1];
                }
                if (statusEntryParts.length > 2) {
                    trackingId = statusEntryParts[2];
                }
                status.add(new OrderItemShipmentDetails(shippedQuantity, date, trackingId));
            }
        }
        return status;
    }

    @Override
    public Map<String, Object> getOrder() {
        return orderDetails;
    }

    public Resource getOrderResource() {
        return orderResource;
    }

    public String getShippedToAddress() {
        return getOrderProperty(AddressModel.ADDRESS_PROPERTY);
    }

    public String getShippedToBuildingDetail() {
        return getOrderProperty(AddressModel.BUILDING_DETAIL_PROPERTY);
    }

    public String getShippedToCity() {
        return getOrderProperty(AddressModel.CITY_PROPERTY);
    }

    public String getShippedToState() {
        return getOrderProperty(AddressModel.STATE_PROPERTY);
    }

    public String getShippedToZip() {
        return getOrderProperty(AddressModel.ZIP_PROPERTY);
    }

    public String getShippedToName() {
        return getOrderProperty(AddressModel.NAME_PROPERTY);
    }


    public boolean isClosed() {
        return RrdCommerceSessionImpl.ORDER_CLOSED.equals(status);
    }

    private String getOrderProperty(String propertyName) {
        if (orderDetails != null) {
            return (String) orderDetails.getOrDefault(propertyName, StringUtils.EMPTY);
        }
        return StringUtils.EMPTY;
    }

    private Map<String, Object> getOrderDetails() {
        if (orderResource != null) {
            Resource detailsResource = orderResource.getChild(RrdCommerceSessionImpl.ORDER_DETAILS_PATH);
            if (detailsResource != null) {
                return detailsResource.getValueMap();
            }
        }
        return Collections.emptyMap();
    }

    //Methods below are not required

    @Override
    public String getCartPrice(Predicate predicate) {
        return null;
    }

    @Override
    public List<PriceInfo> getCartPriceInfo(Predicate predicate) {
        return null;
    }

    @Override
    public List<PromotionInfo> getPromotions() {
        return null;
    }

    @Override
    public List<VoucherInfo> getVoucherInfos() {
        return null;
    }
}
