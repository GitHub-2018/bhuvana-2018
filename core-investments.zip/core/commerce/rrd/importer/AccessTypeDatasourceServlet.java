package com.jhi.aem.website.v1.core.commerce.rrd.importer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.osgi.service.component.annotations.Component;

import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.servlets.generic.DatasourceServlet;

@Component(
		name="Accesstype Data Source Servlet",
		service=Servlet.class,
		property= {
				"sling.servlet.resourceTypes="+AccessTypeDatasourceServlet.ACCESS_DATASOURCE_TYPE
		})

public class AccessTypeDatasourceServlet extends DatasourceServlet {

    static final String ACCESS_DATASOURCE_TYPE = "jhi-website-v1/touch/components/productsAccessDatasource";

    @Override
    protected List<Resource> getResources(ResourceResolver resourceResolver) {
        List<Resource> resources = new ArrayList<>(AccessType.values().length);
        for (AccessType item : AccessType.values()) {
            ValueMap valueMap = new ValueMapDecorator(new HashMap<>());
            valueMap.put(JhiConstants.VALUE_PROPERTY, item.name());
            valueMap.put(JhiConstants.TEXT_PROPERTY, item.getDisplayName());
            resources.add(new ValueMapResource(resourceResolver, new ResourceMetadata(), JcrConstants.NT_UNSTRUCTURED, valueMap));
        }
        return resources;
    }
}
