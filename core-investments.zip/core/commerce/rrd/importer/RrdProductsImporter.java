package com.jhi.aem.website.v1.core.commerce.rrd.importer;

import static com.adobe.cq.commerce.api.CommerceConstants.PN_COMMERCE_TYPE;
import static com.day.cq.commons.jcr.JcrConstants.JCR_LASTMODIFIED;
import static com.jhi.aem.website.v1.core.constants.JhiConstants.SLASH;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PropertyIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.apache.sling.xss.XSSAPI;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.Product;
import com.adobe.cq.commerce.pim.api.ProductImporter;
import com.adobe.cq.commerce.pim.common.AbstractImporter;
import com.adobe.granite.activitystreams.ObjectTypes;
import com.adobe.granite.workflow.launcher.ConfigEntry;
import com.day.cq.commons.DownloadResource;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.TagConstants;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;

@Component(
		name="RRD Product Importer",
		service=ProductImporter.class,
		property= {
				Constants.SERVICE_DESCRIPTION+"=CSV-based product importer for JHI RRD",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR,
				ProductImporter.PROPERTY_COMMERCE_PROVIDER+"="+JhiConstants.RRD_COMMERCE_PROVIDER
		})


public class RrdProductsImporter extends AbstractImporter implements ProductImporter {
    private static final Logger LOGGER = LoggerFactory.getLogger(RrdProductsImporter.class);

    private static final String CSV_PATH_PARAMETER = "csvPath";
    private static final String PROVIDER_PARAMETER = "provider";
    private static final String STORE_PATH_PARAMETER = "storePath";
    private static final String STORE_NAME_PARAMETER = "storeName";

    private static final String FILE_DATA_PATH = JcrConstants.JCR_CONTENT + SLASH + JcrConstants.JCR_DATA;

    private static final String JCR_PREFIX = "jcr:";
    private static final String SLING_PREFIX = "sling:";
    private static final String CQ_PREFIX = "cq:";

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

    private static final String IS_JIT_COLUMN = "Is_JIT";
    private static final String IS_CSS_COLUMN = "Is_CSS";
    private static final String CUSTOMER_ITEM_NUMBER_COLUMN = "Customer_Item_Number";
    //    private static final String WCSS_ITEM_NUMBER_COLUMN = "WCSS_Item_Number";
    private static final String WCSS_ITEM_DESCRIPTION_COLUMN = "WCSS_Item_Description";
    private static final String CUSTOMPOINT_ITEM_DESCRIPTION_COLUMN = "CustomPoint_Item_Description";
    //    private static final String SKIP_CUSTOMPOINT_COLUMN = "Skip_CustomPoint";
    private static final String MAX_ORDER_QTY_WCSS_COLUMN = "Max_Order_Qty_WCSS";
    private static final String MINIMUM_ORDER_QUANTITY_COLUMN = "Minimum_Order_Quantity";
    private static final String MULTIPLE_ORDER_QUANTITY_COLUMN = "Multiple_Order_Quantity";
    private static final String REVISION_COLUMN = "Revision";
    private static final String PACKAGING_ORDERING_UOM_COLUMN = "Packaging_Ordering_UOM";
    private static final String PACKAGING_QUANTITY_COLUMN = "Packaging_Quantity";
    //    private static final String BILL_TO_COLUMN = "Bill_To";
    private static final String ITEM_SUBTYPE_COLUMN = "Item_SubType";
    private static final String PAPER_STOCK_TYPE_COLUMN = "Paper_Stock_Type";
    private static final String PAPER_STOCK_COLOR_COLUMN = "Paper_Stock_Color";
    private static final String PAPER_STOCK_WEIGHT_COLUMN = "Paper_Stock_Weight";
    private static final String TRIM_SIZE_WIDTH_COLUMN = "Trim_Size_Width";
    private static final String TRIM_SIZE_LENGTH_COLUMN = "Trim_Size_Length";
    private static final String PAGE_WIDTH_COLUMN = "Page_Width";
    private static final String PAGE_LENGTH_COLUMN = "Page_Length";
    private static final String INK_COLORS_COLUMN = "Ink_Colors";
    private static final String BLEEDS_COLUMN = "Bleeds";
    private static final String SIDES_PRINTED_COLUMN = "Sides_Printed";
    private static final String ORIENTATION_COLUMN = "Orientation";
    //    private static final String STITCHING_LOCATION_COLUMN = "Stitching_Location";
    //    private static final String DRILLING_SIZE_COLUMN = "Drilling_Size";
    //    private static final String DRILLING_LOCATION_COLUMN = "Drilling_Location";
    //    private static final String GLUE_LOCATION_COLUMN = "Glue_Location";
    //    private static final String FOLD_TYPE_COLUMN = "Fold_Type";
    //    private static final String FOLDED_SIZE_COLUMN = "Folded_Size";
    //    private static final String THERMAL_TAPE_COLOR_COLUMN = "Thermal_Tape_Color";
    //    private static final String NUMBER_PER_PAD_COLUMN = "Number_Per_Pad";
    //    private static final String NUMBER_PER_POLY_COLUMN = "Number_Per_Poly";
    //    private static final String PAD_LOCATION_COLUMN = "Pad_Location";
    //    private static final String PERF_LOCATION_COLUMN = "Perf_Location";
    //    private static final String SCORING_LOCATION_COLUMN = "Scoring_Location";
    //    private static final String BLANK_LOCATION_COLUMN = "Blank_Location";
    //    private static final String BLANK_TYPE_COLUMN = "Blank_Type";
    //    private static final String UPGRADE_ITEM_TEXT_COLUMN = "Upgrade_Item_Text";
    //    private static final String CONTRACT_NR_COLUMN = "Contract_Nr";
    //    private static final String PRE_IMPOSED_COLUMN = "Pre_Imposed";
    //    private static final String IMPOSE_SADDLE_STITCHED_COLUMN = "Impose_Saddle_Stitched";
    //    private static final String COMP_MANAGED_COLUMN = "Comp_Managed";
    //    private static final String COMP_NUMBER_COLUMN = "Comp_Number";
    private static final String ITEM_REF_1_COLUMN = "Item_Ref_1";
    private static final String ITEM_REF_2_COLUMN = "Item_Ref_2";
    private static final String ITEM_REF_3_COLUMN = "Item_Ref_3";
    private static final String ITEM_REF_4_COLUMN = "Item_Ref_4";
    //    private static final String REORDER_POINT_COLUMN = "Reorder_Point";
    //    private static final String REORDER_QUANTITY_COLUMN = "Reorder_Quantity";
    //    private static final String NUMBERED_ITEM_COLUMN = "Numbered_Item";
    //    private static final String CSS_THUMBNAIL_COLUMN = "CSS_Thumbnail";
    private static final String PRINT_COMMENTS_COLUMN = "Print_Comments";
    private static final String BUSINESS_UNIT_COLUMN = "Business_Unit";
    private static final String CATALOG_NAME_COLUMN = "Catalog_Name";
    private static final String CATEGORY_NAME_COLUMN = "Category_Name";
    private static final String SUBCATEGORY_NAME1_COLUMN = "SubCategory_Name1";
    private static final String SUBCATEGORY_NAME2_COLUMN = "SubCategory_Name2";
    //    private static final String SUBCATEGORY_NAME3_COLUMN = "SubCategory_Name3";
    //    private static final String SUBCATEGORY_NAME4_COLUMN = "SubCategory_Name4";
    //    private static final String SUBCATEGORY_NAME5_COLUMN = "SubCategory_Name5";
    //    private static final String SUBCATEGORY_NAME6_COLUMN = "SubCategory_Name6";
    //    private static final String SUBCATEGORY_NAME7_COLUMN = "SubCategory_Name7";
    //    private static final String SUBCATEGORY_NAME8_COLUMN = "SubCategory_Name8";
    //    private static final String SUBCATEGORY_NAME9_COLUMN = "SubCategory_Name9";
    //    private static final String SUBCATEGORY_NAME10_COLUMN = "SubCategory_Name10";
    private static final String APPROVAL_QUANTITY_LIMIT_COLUMN = "Approval_Quantity_Limit";
    //    private static final String ALTERNATE_DESCRIPTION_COLUMN = "Alternate_Description";
    //    private static final String ALTERNATE_DESCRIPTION_FLAG_COLUMN = "Alternate_Description_Flag";
    private static final String FIRM_COLUMN = "Firm";
    private static final String PRINT_ASSET_COLUMN = "Print_Asset";

    private static final String DUMMY_FIRM = "Dummy_Firm";

    private static final Map<String, String> PROPERTIES_MAP = ImmutableMap.<String, String>builder()

            .put(IS_JIT_COLUMN, RrdProductImpl.RRD_JIT)
            .put(IS_CSS_COLUMN, RrdProductImpl.RRD_CSS)
            .put(CUSTOMER_ITEM_NUMBER_COLUMN, RrdProductImpl.CODE)
//            .put(WCSS_ITEM_NUMBER_COLUMN, RrdProductImpl.)
            .put(WCSS_ITEM_DESCRIPTION_COLUMN, RrdProductImpl.RRD_WCSS_ITEM_DESCRIPTION)
            .put(CUSTOMPOINT_ITEM_DESCRIPTION_COLUMN, RrdProductImpl.RRD_ITEM_DESCRIPTION)
//            .put(SKIP_CUSTOMPOINT_COLUMN, RrdProductImpl.)
            .put(MAX_ORDER_QTY_WCSS_COLUMN, RrdProductImpl.RRD_MAXIMUM_ORDER_QUANTITY)
            .put(MINIMUM_ORDER_QUANTITY_COLUMN, RrdProductImpl.RRD_MINIMUM_ORDER_QUANTITY)
            .put(MULTIPLE_ORDER_QUANTITY_COLUMN, RrdProductImpl.RRD_MULTIPLE_ORDER_QUANTITY)
            .put(REVISION_COLUMN, RrdProductImpl.RRD_REVISION)
            .put(PACKAGING_ORDERING_UOM_COLUMN, RrdProductImpl.RRD_UOM_CODE)
            .put(PACKAGING_QUANTITY_COLUMN, RrdProductImpl.RRD_PACKAGING_QUANTITY)
//            .put(BILL_TO_COLUMN, RrdProductImpl.RRD_BILL_TO)
            .put(ITEM_SUBTYPE_COLUMN, RrdProductImpl.RRD_ITEM_SUBTYPE)
            .put(PAPER_STOCK_TYPE_COLUMN, RrdProductImpl.RRD_PAPER_STOCK_TYPE)
            .put(PAPER_STOCK_COLOR_COLUMN, RrdProductImpl.RRD_PAPER_STOCK_COLOR)
            .put(PAPER_STOCK_WEIGHT_COLUMN, RrdProductImpl.RRD_PAPER_STOCK_WEIGHT)
            .put(TRIM_SIZE_WIDTH_COLUMN, RrdProductImpl.RRD_TRIM_SIZE_WIDTH)
            .put(TRIM_SIZE_LENGTH_COLUMN, RrdProductImpl.RRD_TRIM_SIZE_LENGTH)
            .put(PAGE_WIDTH_COLUMN, RrdProductImpl.RRD_PDF_PAGE_WIDTH)
            .put(PAGE_LENGTH_COLUMN, RrdProductImpl.RRD_PDF_PAGE_LENGTH)
            .put(INK_COLORS_COLUMN, RrdProductImpl.RRD_INK_COLORS)
            .put(BLEEDS_COLUMN, RrdProductImpl.RRD_BLEEDS)
            .put(SIDES_PRINTED_COLUMN, RrdProductImpl.RRD_SIDES_PRINTED)
            .put(ORIENTATION_COLUMN, RrdProductImpl.RRD_ORIENTATION)
//            .put(STITCHING_LOCATION_COLUMN, RrdProductImpl.RRD_STITCHING_LOCATION)
//            .put(DRILLING_SIZE_COLUMN, RrdProductImpl.RRD_DRILLING_SIZE)
//            .put(DRILLING_LOCATION_COLUMN, RrdProductImpl.RRD_DRILLING_LOCATION)
//            .put(GLUE_LOCATION_COLUMN, RrdProductImpl.RRD_GLUE_LOCATION)
//            .put(FOLD_TYPE_COLUMN, RrdProductImpl.RRD_FOLD_TYPE)
//            .put(FOLDED_SIZE_COLUMN, RrdProductImpl.RRD_FOLD_SIZE)
//            .put(THERMAL_TAPE_COLOR_COLUMN, RrdProductImpl.RRD_THERMAL_TAPE_COLOR)
//            .put(NUMBER_PER_PAD_COLUMN, RrdProductImpl.RRD_PAD_NUMBER)
//            .put(NUMBER_PER_POLY_COLUMN, RrdProductImpl.RRD_POLY_NUMBER)
//            .put(PAD_LOCATION_COLUMN, RrdProductImpl.)
//            .put(PERF_LOCATION_COLUMN, RrdProductImpl.)
//            .put(SCORING_LOCATION_COLUMN, RrdProductImpl.)
//            .put(BLANK_LOCATION_COLUMN, RrdProductImpl.)
//            .put(BLANK_TYPE_COLUMN, RrdProductImpl.)
//            .put(UPGRADE_ITEM_TEXT_COLUMN, RrdProductImpl.)
//            .put(CONTRACT_NR_COLUMN, RrdProductImpl.)
//            .put(PRE_IMPOSED_COLUMN, RrdProductImpl.RRD_PRE_IMPOSED)
//            .put(IMPOSE_SADDLE_STITCHED_COLUMN, RrdProductImpl.)
//            .put(COMP_MANAGED_COLUMN, RrdProductImpl.)
//            .put(COMP_NUMBER_COLUMN, RrdProductImpl.)
            .put(ITEM_REF_1_COLUMN, RrdProductImpl.RRD_FULFILLMENT_BUDGET_CODE)
            .put(ITEM_REF_2_COLUMN, RrdProductImpl.RRD_FULFILLMENT_MANAGER)
            .put(ITEM_REF_3_COLUMN, RrdProductImpl.RRD_MARKETING_MANAGER)
            .put(ITEM_REF_4_COLUMN, RrdProductImpl.RRD_PRINT_STATUS)
//            .put(REORDER_POINT_COLUMN, RrdProductImpl.RRD_REORDER_POINT)
//            .put(REORDER_QUANTITY_COLUMN, RrdProductImpl.RRD_REORDER_QUANTITY)
//            .put(NUMBERED_ITEM_COLUMN, RrdProductImpl.)
//            .put(CSS_THUMBNAIL_COLUMN, RrdProductImpl.)
            .put(PRINT_COMMENTS_COLUMN, RrdProductImpl.RRD_PRINTING_COMMENTS)
            .put(BUSINESS_UNIT_COLUMN, RrdProductImpl.RRD_BUSINESS_UNIT)
            .put(CATALOG_NAME_COLUMN, RrdProductImpl.RRD_CATALOG)
            .put(CATEGORY_NAME_COLUMN, RrdProductImpl.RRD_CATEGORY)
            .put(SUBCATEGORY_NAME1_COLUMN, RrdProductImpl.RRD_SUBCATEGORY1)
            .put(SUBCATEGORY_NAME2_COLUMN, RrdProductImpl.RRD_SUBCATEGORY2)
//            .put(SUBCATEGORY_NAME3_COLUMN, RrdProductImpl.)
//            .put(SUBCATEGORY_NAME4_COLUMN, RrdProductImpl.)
//            .put(SUBCATEGORY_NAME5_COLUMN, RrdProductImpl.)
//            .put(SUBCATEGORY_NAME6_COLUMN, RrdProductImpl.)
//            .put(SUBCATEGORY_NAME7_COLUMN, RrdProductImpl.)
//            .put(SUBCATEGORY_NAME8_COLUMN, RrdProductImpl.)
//            .put(SUBCATEGORY_NAME9_COLUMN, RrdProductImpl.)
//            .put(SUBCATEGORY_NAME10_COLUMN, RrdProductImpl.)
            .put(APPROVAL_QUANTITY_LIMIT_COLUMN, RrdProductImpl.RRD_APPROVAL_QUANTITY_LIMIT)
//            .put(ALTERNATE_DESCRIPTION_COLUMN, RrdProductImpl.RRD_ALTERNATE_DESCRIPTION)
//            .put(ALTERNATE_DESCRIPTION_FLAG_COLUMN, RrdProductImpl.)
            .put(PRINT_ASSET_COLUMN, RrdProductImpl.PRINT_ASSET)
            .put(FIRM_COLUMN, DUMMY_FIRM)
            .build();


    public static final String FIRM_RESTRICTION_AMERFIN = "AmerFin";
    public static final String FIRM_RESTRICTION_EDJONES = "EdJones";
    public static final String FIRM_RESTRICTION_JHI_EXT = "JHIExt";
    public static final String FIRM_RESTRICTION_MLYNCH = "MLynch";
    public static final String FIRM_RESTRICTION_MSTANLEY = "MStanley";
    public static final String FIRM_RESTRICTION_UBSFIN = "UBSFin";

    public static final String FIRM_RESTRICTION_JHI_INT = "JHIInt";

    private static final Map<String, String> FIRM_RESTRICTIONS_MAP = ImmutableMap.<String, String>builder()
            .put(FIRM_RESTRICTION_EDJONES, RrdProductImpl.ACCESS_EDWARD_JONES)
            .put(FIRM_RESTRICTION_MLYNCH, RrdProductImpl.ACCESS_MERRILL_LYNCH)
            .put(FIRM_RESTRICTION_MSTANLEY, RrdProductImpl.ACCESS_MORGAN_STANLEY)
            .put(FIRM_RESTRICTION_UBSFIN, RrdProductImpl.ACCESS_UBS)
            .put(FIRM_RESTRICTION_AMERFIN, RrdProductImpl.ACCESS_AMERIPRISE_FINANCIAL)
            .put(FIRM_RESTRICTION_JHI_EXT, RrdProductImpl.ACCESS_JHI)
            .build();

    
    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }

    private List<CSVRecord> records;
    private String[] propertiesArray;
    private List<String> warnings;
    private int codeColumn = -1;
    private int cpDescriptionColumn = -1;
    private int wcssDescriptionColumn = -1;

    private int productCount;

    private boolean validateInput(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        ResourceResolver resourceResolver = request.getResourceResolver();

        String provider = request.getParameter(PROVIDER_PARAMETER);
        if (StringUtils.isEmpty(provider)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "No commerce provider specified.");
            return false;
        }
        String csvPath = request.getParameter(CSV_PATH_PARAMETER);

        if (StringUtils.isBlank(csvPath)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "No CSV path parameter specified '" + CSV_PATH_PARAMETER + "'");
            return false;
        }

        try (InputStream inputStream = getCsvInputStream(response, resourceResolver, csvPath)) {
            if (inputStream != null) {
                CSVParser parser = CSVParser.parse(inputStream, Charset.forName(JhiConstants.DEFAULT_CHARSET_NAME), CSVFormat.EXCEL);
                records = parser.getRecords();
            }
        }

        if (records == null || records.isEmpty()) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Product CSV empty.");
            return false;
        }

        if (records.size() < 2) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Product CSV contains header but no products.");
            return false;
        }

        CSVRecord headerRecord = records.get(0);
        if (headerRecord.size() < 1) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "File header is blank.");
            return false;
        }

        String[] headerColumns = new String[headerRecord.size()];
        propertiesArray = new String[headerRecord.size()];
        warnings = new ArrayList<>();
        for (int i = 0; i < headerRecord.size(); i++) {
            headerColumns[i] = headerRecord.get(i);
            if (PROPERTIES_MAP.containsKey(headerColumns[i])) {
                propertiesArray[i] = PROPERTIES_MAP.get(headerColumns[i]);
                if (StringUtils.equals(headerColumns[i], CUSTOMER_ITEM_NUMBER_COLUMN)) {
                    codeColumn = i;
                } else if (StringUtils.equals(headerColumns[i], CUSTOMPOINT_ITEM_DESCRIPTION_COLUMN)) {
                    cpDescriptionColumn = i;
                } else if (StringUtils.equals(headerColumns[i], WCSS_ITEM_DESCRIPTION_COLUMN)) {
                    wcssDescriptionColumn = i;
                }
            } else {
                warnings.add("Unknown column: '" + headerRecord.get(i) + "'");
            }
        }

        if (codeColumn < 0) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "'Customer Item Number' property not present.");
            return false;
        }

        String storePath = request.getParameter(STORE_PATH_PARAMETER);
        String storeName = request.getParameter(STORE_NAME_PARAMETER);
        if ((StringUtils.isEmpty(storePath)) && (StringUtils.isEmpty(storeName))) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Destination not specified.");
            return false;
        }
        return true;
    }


    private InputStream getCsvInputStream(SlingHttpServletResponse response, ResourceResolver resourceResolver,
                                          String csvPath) throws IOException {
        try {
            Resource csvResource = resourceResolver.getResource(csvPath);
            Node source;
            if (csvResource != null) {
                source = csvResource.adaptTo(Node.class);
                if (source != null) {
                    return source.getProperty(FILE_DATA_PATH).getBinary().getStream();
                }
            }
        } catch (RepositoryException e) {
            XSSAPI xssapi = resourceResolver.adaptTo(XSSAPI.class);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Product CSV [" +
                    (xssapi != null ? xssapi.encodeForHTML(csvPath) : null) + "] not found.");
        }
        return null;
    }

    @Override
    protected void doImport(ResourceResolver resourceResolver, Node storeRoot, boolean incrementalImport) throws RepositoryException {
        for (String warning : warnings) {
            logMessage(warning, false);
            LOGGER.warn(warning);
        }
        String storePath = storeRoot.getPath();
        boolean isData = false;
        for (CSVRecord record : records) {
            if (isData) {
                importProduct(resourceResolver, storeRoot, storePath, getColumnValue(record, codeColumn), record);
            } else {
                isData = true;
            }
        }
    }

    @Override
    public void importProducts(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        long startTime = System.currentTimeMillis();
        codeColumn = -1;
        cpDescriptionColumn = -1;
        wcssDescriptionColumn = -1;

        if (!validateInput(request, response)) {
            return;
        }

        ResourceResolver resourceResolver = request.getResourceResolver();
        Session session = resourceResolver.adaptTo(Session.class);
        String storeName = request.getParameter("storeName");
        String storePath = request.getParameter("storePath");
        String provider = request.getParameter("provider");
        initTicker(request.getParameter("tickertoken"), session);

        Boolean incrementalImport = false;
        if (request.getParameter("incrementalImport") != null) {
            incrementalImport = true;
        }

        productCount = 0;
        run(resourceResolver, storePath != null ? storePath : JhiConstants.PRODUCTS_ROOT, storeName, incrementalImport, provider);

        long millis = System.currentTimeMillis() - startTime;
        long seconds = millis / 1000;
        if (seconds > 120) {
            LOGGER.info("Imported " + productCount + " products in " + seconds / 60 + " minutes.");
        } else {
            LOGGER.info("Imported " + productCount + " products in " + seconds + " seconds.");
        }

        String summary = productCount + " products created/updated.";
        if (getErrorCount() > 0) {
            summary += " " + getErrorCount() + " errors encountered.";
        }
        respondWithMessages(response, summary);
    }

    private void importProduct(ResourceResolver resourceResolver, Node storeRoot, String storePath, String code, CSVRecord record) {
        String description = StringUtils.EMPTY;
        if (cpDescriptionColumn > -1) {
            description = getColumnValue(record, cpDescriptionColumn);
            if (StringUtils.isBlank(description) && wcssDescriptionColumn > -1) {
                description = getColumnValue(record, wcssDescriptionColumn);
            }
        }
        String productPath = getProductRelativePath(resourceResolver, storePath, code, description);
        if (StringUtils.isNotBlank(productPath)) {
            try {
                Resource product = resourceResolver.getResource(storePath + JhiConstants.SLASH + productPath);
                Node productNode = null;
                String productCode = StringUtils.EMPTY;
                if (product != null) {
                    productNode = product.adaptTo(Node.class);
                    if (productNode != null) {
                        javax.jcr.Property codeProperty = productNode.getProperty(RrdProductImpl.CODE);
                        if (codeProperty != null) {
                            productCode = codeProperty.getString();
                        }
                    }
                }
                if (productNode == null || !StringUtils.equals(productCode, code)) {
                    try {
                        Session session = resourceResolver.adaptTo(Session.class);
                        if (session != null) {
                            productNode = createProduct(storeRoot, productPath, session);
                            productNode.setProperty(RrdProductImpl.ACCESS, JhiConstants.ACCESS_INTERNAL);
                            setProperties(productNode, record, false);
                        }
                    } catch (RepositoryException e) {
                        logMessage("ERROR creating " + productPath, true);
                        LOGGER.error("Failed to create product " + productPath, e);
                    }
                } else {
                    productNode = product.adaptTo(Node.class);
                    if (productNode != null) {
                        setProperties(productNode, record, false);
                        productUpdated(productNode);
                    }
                }
            } catch (RepositoryException e) {
                logMessage("ERROR updating " + code, true);
                LOGGER.error("Failed to update product " + code, e);
            }
        } else {
            logMessage("ERROR product path cannot be created for row " + record, true);
            LOGGER.error("Product path cannot be created for row " + record);
        }
    }

    private Node createProduct(Node storeRoot, String relativePath, Session session) throws RepositoryException {
        Node product = JcrUtil.createUniqueNode(storeRoot, relativePath, JcrConstants.NT_UNSTRUCTURED, session);
        product.setProperty(PN_COMMERCE_TYPE, ObjectTypes.PRODUCT);
        product.setProperty(ResourceResolver.PROPERTY_RESOURCE_TYPE, Product.RESOURCE_TYPE_PRODUCT);
        product.setProperty(JCR_LASTMODIFIED, Calendar.getInstance());

        productCount++;
        logEvent("com/adobe/cq/commerce/pim/PRODUCT_ADDED", product.getPath());
        logMessage("Created product   " + product.getPath(), false);
        updateTicker(makeTickerMessage());

        checkpoint(session, false);
        return product;
    }

    private void productUpdated(Node product) throws RepositoryException {
        productCount++;
        logEvent("com/adobe/cq/commerce/pim/PRODUCT_MODIFIED", product.getPath());
        logMessage("Updated product   " + product.getPath(), false);
        updateTicker(makeTickerMessage());
        checkpoint(product.getSession(), false);
    }

    private String makeTickerMessage() {
        return productCount + " products imported/updated";
    }

    private void setProperties(Node node, CSVRecord record, boolean clear) throws RepositoryException {
        if (clear) {
            for (PropertyIterator existingProps = node.getProperties(); existingProps.hasNext(); ) {
                javax.jcr.Property prop = (javax.jcr.Property) existingProps.next();
                String propName = prop.getName();
                if ((propName.startsWith(JcrConstants.JCR_TITLE)) || (propName.startsWith(JcrConstants.JCR_DESCRIPTION)) ||
                        (propName.equals(TagConstants.PN_TAGS))) {
                    prop.remove();
                } else if ((!propName.startsWith(JCR_PREFIX)) && (!propName.startsWith(SLING_PREFIX))
                        && (!propName.startsWith(CQ_PREFIX)) && (!prop.getDefinition().isAutoCreated())
                        && (!prop.getDefinition().isProtected())) {
                    prop.remove();
                }
            }
            if (node.hasNode(RrdProductImpl.WEB_ASSET)) {
                node.getNode(RrdProductImpl.WEB_ASSET).remove();
            }
            if (node.hasNode(RrdProductImpl.PRINT_ASSET)) {
                node.getNode(RrdProductImpl.PRINT_ASSET).remove();
            }
        }

        for (int i = 0; i < propertiesArray.length; i++) {
            Class type = String.class;
            if (RrdProductImpl.TYPES_MAP.containsKey(propertiesArray[i])) {
                type = RrdProductImpl.TYPES_MAP.get(propertiesArray[i]);
            }
            setProperty(node, propertiesArray[i], getColumnValue(record, i), type);
        }
    }

    private void setProperty(Node node, String propertyName, String propertyValue, Class type) throws RepositoryException {
        if (StringUtils.isNotBlank(propertyName)) {
            if (RrdProductImpl.CODE.equals(propertyName)) {
                node.setProperty(propertyName, StringUtils.upperCase(propertyValue));
            } else if (DUMMY_FIRM.equals(propertyName)) {
                setFirmRestrictions(node, propertyValue);
            } else if (RrdProductImpl.PRINT_ASSET.equals(propertyName)) {
                createAsset(node, propertyValue, RrdProductImpl.PRINT_ASSET);
                createAsset(node, propertyValue, RrdProductImpl.WEB_ASSET);
            } else if (type == Calendar.class) {
                setDateProperty(node, propertyValue, propertyName);
            } else if (type == Boolean.class) {
                setBooleanProperty(node, propertyValue, propertyName);
            } else if (type == String[].class) {
                setMultiValueTextProperty(node, propertyValue, propertyName);
            } else if (StringUtils.isNotEmpty(propertyValue)) {
                node.setProperty(propertyName, propertyValue);
                if (RrdProductImpl.RRD_ITEM_DESCRIPTION.equals(propertyName)) {
                    node.setProperty(RrdProductImpl.META_TITLE, propertyValue);
                }
            }
        }
    }

    private void setFirmRestrictions(Node node, String propertyValue) throws RepositoryException {
        if (FIRM_RESTRICTIONS_MAP.containsKey(propertyValue)) {
            node.setProperty(FIRM_RESTRICTIONS_MAP.get(propertyValue), Boolean.TRUE);
            node.setProperty(RrdProductImpl.ACCESS, JhiConstants.ACCESS_RESTRICTED);
        }
    }

    private void setMultiValueTextProperty(Node node, String propertyName, String propertyValue) throws RepositoryException {
        if (StringUtils.isNotEmpty(propertyValue)) {
            node.setProperty(propertyName, StringUtils.split(propertyValue, JhiConstants.MULTIPLE_VALUES_SEPARATOR));
        }
    }

    private synchronized void setDateProperty(Node node, String propertyName, String propertyValue) throws RepositoryException {
        if (StringUtils.isNotEmpty(propertyValue)) {
            try {
                DATE_FORMAT.parse(propertyValue);
                node.setProperty(propertyName, DATE_FORMAT.getCalendar());
            } catch (ParseException e) {
                String code = StringUtils.EMPTY;
                if (node.hasProperty(RrdProductImpl.CODE)) {
                    code = node.getProperty(RrdProductImpl.CODE).getString();
                }
                logMessage("Problem while parsing date for " + code + ", " + propertyName + "='" + propertyValue + "'", true);
                LOGGER.error("Problem while parsing date", e);
            }
        }
    }

    private void setBooleanProperty(Node node, String propertyValue, String propertyName) throws RepositoryException {
        if (StringUtils.equalsIgnoreCase(propertyValue, RrdProductImpl.BOOLEAN_TRUE_Y)
                || StringUtils.equalsIgnoreCase(propertyValue, RrdProductImpl.BOOLEAN_TRUE_1)) {
            node.setProperty(propertyName, Boolean.TRUE);
        } else {
            node.setProperty(propertyName, Boolean.FALSE);
        }
    }

    private void createAsset(Node productNode, String assetPath, String assetNodePath) throws RepositoryException {
        if (StringUtils.isBlank(assetPath)) {
            return;
        }
        Node assetNode;
        if (productNode.hasNode(assetNodePath)) {
            assetNode = productNode.getNode(assetNodePath);
        } else {
            assetNode = productNode.addNode(assetNodePath, JcrConstants.NT_UNSTRUCTURED);
        }
        assetNode.setProperty(DownloadResource.PN_REFERENCE, assetPath);
        assetNode.setProperty(ResourceResolver.PROPERTY_RESOURCE_TYPE, ResourcesConstants.PRODUCT_IMAGE_RESOURCE_TYPE);
        checkpoint(productNode.getSession(), false);
    }

    private String getColumnValue(CSVRecord record, int i) {
        if (i >= 0 && i < record.size()) {
            return record.get(i);
        }
        return null;
    }

    private String getProductRelativePath(ResourceResolver resourceResolver, String storePath, String code, String description) {
        if (StringUtils.isBlank(code)) {
            return StringUtils.EMPTY;
        }
        String currentProductPath = searchProductByCode(resourceResolver, storePath, code);
        if (StringUtils.isNotBlank(currentProductPath)) {
            return currentProductPath;
        }
        if (StringUtils.isNotBlank(description)) {
            String name = StringUtils.replacePattern(description, "[^a-zA-Z0-9 _]", StringUtils.EMPTY);
            name = StringUtils.replace(name, StringUtils.SPACE, JhiConstants.DASH).toLowerCase();
            if (StringUtils.isNotBlank(name)) {
                return name;
            }
        }
        return StringUtils.EMPTY;
    }

    private String searchProductByCode(ResourceResolver resourceResolver, String storePath, String code) {
        final Map<String, String> searchParams = new HashMap<>(5);
        searchParams.put(PathPredicateEvaluator.PATH, storePath);
        searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY);
        searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER, Product.RESOURCE_TYPE_PRODUCT);
        searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY, RrdProductImpl.CODE);
        searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER, code);

        final Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
        query.setStart(0);
        query.setHitsPerPage(1);
        /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        SearchResult result = query.getResult();
        if (!result.getHits().isEmpty()) {
            for (Hit hit : result.getHits()) {
                try {
                	String productPath = hit.getPath();
                    Resource productResource = resourceResolver.getResource(productPath);
                    if (productResource != null) {
                        return productResource.getName();
                    }
                } catch (RepositoryException e) {
                    logMessage("Problem fetching product resource with code: " + code, true);
                    LOGGER.error("Problem fetching product resource", e);
                }
            }
        }
        /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        return StringUtils.EMPTY;
    }

    @Override
    protected boolean disableWorkflowPredicate(ConfigEntry workflowConfigEntry) {
        return workflowConfigEntry.getGlob().startsWith(JhiConstants.PRODUCTS_ROOT);
    }
}