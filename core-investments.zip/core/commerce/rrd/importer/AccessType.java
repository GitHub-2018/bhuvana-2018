package com.jhi.aem.website.v1.core.commerce.rrd.importer;

public enum AccessType {
    ADMIN("Admin"), BROKER_ONLY("Broker only"), INTERNAL("Internal"), INVESTOR("Investor");

    private String displayName;

    AccessType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
