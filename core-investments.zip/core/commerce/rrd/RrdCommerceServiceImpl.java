package com.jhi.aem.website.v1.core.commerce.rrd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.CommerceConstants;
import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.commerce.api.Product;
import com.adobe.cq.commerce.common.AbstractJcrCommerceService;
import com.adobe.cq.commerce.common.ServiceContext;
import com.day.cq.commons.Language;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

public class RrdCommerceServiceImpl extends AbstractJcrCommerceService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RrdCommerceServiceImpl.class);

    private Resource resource;
    
    private ServiceContext serviceContext;

    protected RrdCommerceServiceImpl(ServiceContext serviceContext, Resource resource) {
        super(serviceContext, resource);
    	this.resource = resource;
    }
    
    @Override
    public CommerceSession login(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws CommerceException {
    	return new RrdCommerceSessionImpl(this, request, response, resource);
    }

    @Override
    public boolean isAvailable(String serviceType) {
        return CommerceConstants.SERVICE_COMMERCE.equals(serviceType);
    }

    @Override
    public Product getProduct(final String path) throws CommerceException {
        if (StringUtils.isNoneBlank(path)) {
            Resource resource = resolver.getResource(path);
            if (resource != null && RrdProductImpl.isAProductOrVariant(resource)) {
                return new RrdProductImpl(resource);
            }
        }
        return null;
    }

    public Product getProductByCode(final String productId) throws CommerceException {
        if (StringUtils.isNotBlank(productId)) {
            Resource resource = getProductResource(productId);
            if (resource != null) {
                return new RrdProductImpl(resource);
            }
        }
        return null;
    }

    @Override
    public List<String> getOrderPredicates() throws CommerceException {
        List<String> predicates = new ArrayList<>();
        predicates.add(CommerceConstants.OPEN_ORDERS_PREDICATE);
        return predicates;
    }

    @Override
    public List<String> getCountries() throws CommerceException {
        return null;
    }

    @Override
    public List<String> getCreditCardTypes() throws CommerceException {
        return null;
    }

    private Resource getProductResource(String id) {
        ResourceResolver resourceResolver = resource.getResourceResolver();
        QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
        if (queryBuilder != null) {
            Map<String, String> searchParams = new HashMap<>(3);
            searchParams.put(PathPredicateEvaluator.PATH, JhiConstants.RRD_PRODUCTS_ROOT);
            searchParams.put(JcrPropertyPredicateEvaluator.PROPERTY, RrdProductImpl.CODE);
            searchParams.put(JhiConstants.PROPERTY_VALUE_PARAMETER, id);
            Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
            query.setHitsPerPage(1);
            SearchResult queryResult = query.getResult();
            if (queryResult.getTotalMatches() > 1) {
                LOGGER.error("There are multiple items with same product code: {}", id);
            }
            List<Hit> hits = queryResult.getHits();
            /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
            if (!hits.isEmpty()) {
                try {
                	String hitPath = hits.get(0).getPath();
                	return resourceResolver.getResource(hitPath);
                } catch (RepositoryException e) {
                    LOGGER.error("Problem while taking product resource", e);
                }
            }
            /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        }
        return null;
    }
}