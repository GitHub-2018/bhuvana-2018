package com.jhi.aem.website.v1.core.commerce.rrd;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.common.AbstractJcrProduct;
import com.day.cq.commons.DownloadResource;
import com.day.cq.commons.ImageResource;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.dam.api.Rendition;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.resources.ApprovedForType;
import com.jhi.aem.website.v1.core.utils.AssetUtil;

public class RrdProductImpl extends AbstractJcrProduct {

    private static final Logger LOGGER = LoggerFactory.getLogger(RrdProductImpl.class);

    public static final String BOOLEAN_TRUE_Y = "Y";
    public static final String BOOLEAN_TRUE_1 = "1";

    public static final String RRD_TXN_ID = "rrdTxnId";
    public static final String RRD_STATUS = "rrdStatus";
    public static final String RRD_STATUS_SUBMITTED = "submitted";
    public static final String RRD_STATUS_PROCESSED = "processed";
    public static final String RRD_STATUS_COMPLETE = "complete";
    public static final String RRD_STATUS_FAILED = "failed";
    public static final String RRD_STATUS_MESSAGE = "rrdStatusMessage";

    public static final String LAST_PUBLISH_ON_RRD = "lastRrdPublish";
    public static final String LAST_PUBLISH_ON_WEB = "lastWebPublish";
    public static final String PAGE_STATUS = "pageStatus";
    public static final String RESOURCE_PAGE_PATH = "resourcePagePath";

    public static final String PUBLISH_DATE = "publishDate";
    public static final String EXPIRATION_DATE = "expirationDate";
    public static final String ITEM_STATUS = "itemStatus";

    public static final String WEB_ASSET = "webAsset";
    public static final String PRINT_ASSET = "printAsset";

    public static final String LAST_UPDATED = "lastUpdated";
    public static final String PUBLISHING_FREQUENCY = "publishingFrequency";
    public static final String DISPLAY_TITLE = "displayTitle";
    public static final String DISPLAY_DESCRIPTION = "displayDescription";
    public static final String META_TITLE = JcrConstants.JCR_TITLE;
    public static final String META_DESCRIPTION = JcrConstants.JCR_DESCRIPTION;
    public static final String APPROVED_FOR = "approvedFor";
    public static final String DOCUMENT_TYPE = "documentType";
    public static final String TOPICS = "topics";
    public static final String CATEGORY = "category";
    public static final String E_FORM_LINK = "eFormLink";
    public static final String AUDIENCES = "audiences";
    public static final String FUNDS = "funds";

    public static final String ACCESS = "access";

    public static final String ACCESS_AMERIPRISE_FINANCIAL = "access-ameriprise-financial";
    public static final String ACCESS_EDWARD_JONES = "access-edward-jones";
    public static final String ACCESS_JHI = "access-jhi";
    public static final String ACCESS_MERRILL_LYNCH = "access-merrill-lynch";
    public static final String ACCESS_MORGAN_STANLEY = "access-morgan-stanley";
    public static final String ACCESS_UBS = "access-ubs";

    public static final String ACCESS_WELLS_FARGO = "access-wells-fargo";
    public static final String ACCESS_AXA = "access-axa";
    public static final String ACCESS_COMMONWEALTH = "access-commonwealth";
    public static final String ACCESS_LPL = "access-lpl";
    public static final String ACCESS_RAYMOND_JAMES = "access-raymond-james";
    public static final String ACCESS_NORTHWEST_MUTUAL = "access-northwest-mutual";

    public static final String CODE = "code";
    public static final String RRD_JIT = "rrd-jit";
    public static final String RRD_CSS = "rrd-css";
    public static final String RRD_ITEM_DESCRIPTION = "rrd-itemDescription";
    public static final String RRD_WCSS_ITEM_DESCRIPTION = "rrd-wcssItemDescription";
    public static final String RRD_UOM_CODE = "rrd-uomCode";
    public static final String RRD_PACKAGING_QUANTITY = "rrd-packagingQuantity";
    public static final String RRD_REVISION = "rrd-revision";
    public static final String RRD_MAXIMUM_ORDER_QUANTITY = "rrd-maximumOrderQuantity";
    public static final String RRD_ITEM_SUBTYPE = "rrd-itemSubType";
    public static final String RRD_ORIENTATION = "rrd-orientation";
    public static final String RRD_SIDES_PRINTED = "rrd-sidesPrinted";
    public static final String RRD_PAPER_STOCK_TYPE = "rrd-paperStockType";
    public static final String RRD_PAPER_STOCK_WEIGHT = "rrd-paperStockWeight";
    public static final String RRD_PAPER_STOCK_COLOR = "rrd-paperStockColor";
    public static final String RRD_TRIM_SIZE_WIDTH = "rrd-trimSizeWidth";
    public static final String RRD_TRIM_SIZE_LENGTH = "rrd-trimSizeLength";
    public static final String RRD_PDF_PAGE_WIDTH = "rrd-pdfPageWidth";
    public static final String RRD_PDF_PAGE_LENGTH = "rrd-pdfPageLength";
    public static final String RRD_INK_COLORS = "rrd-inkColors";
    public static final String RRD_BLEEDS = "rrd-bleeds";
    public static final String RRD_PRINTING_COMMENTS = "rrd-printingComments";
    public static final String RRD_MINIMUM_ORDER_QUANTITY = "rrd-minimumOrderQuantity";
    public static final String RRD_MULTIPLE_ORDER_QUANTITY = "rrd-multipleOrderQuantity";
    public static final String RRD_FULFILLMENT_BUDGET_CODE = "rrd-fulfillmentBudgetCode";
    public static final String RRD_FULFILLMENT_MANAGER = "rrd-fulfillmentManager";
    public static final String RRD_MARKETING_MANAGER = "rrd-marketingManager";
    public static final String RRD_PRINT_STATUS = "rrd-printStatus";
    public static final String RRD_CATALOG = "rrd-catalog";
    public static final String RRD_CATEGORY = "rrd-category";
    public static final String RRD_SUBCATEGORY1 = "rrd-subcategory1";
    public static final String RRD_SUBCATEGORY2 = "rrd-subcategory2";
    public static final String RRD_APPROVAL_QUANTITY_LIMIT = "rrd-approvalQuantityLimit";
    public static final String RRD_BUSINESS_UNIT = "rrd-businessUnit";

    public static final Map<String, Class> TYPES_MAP = ImmutableMap.<String, Class>builder()
            .put(PUBLISH_DATE, Calendar.class)
            .put(EXPIRATION_DATE, Calendar.class)
            .put(WEB_ASSET, String.class)
            .put(PRINT_ASSET, String.class)
            .put(LAST_UPDATED, Calendar.class)
            .put(PUBLISHING_FREQUENCY, String.class)
            .put(DISPLAY_TITLE, String.class)
            .put(DISPLAY_DESCRIPTION, String.class)
            .put(META_TITLE, String.class)
            .put(META_DESCRIPTION, String.class)
            .put(APPROVED_FOR, String.class)
            .put(DOCUMENT_TYPE, String.class)
            .put(TOPICS, String[].class)
            .put(CATEGORY, String.class)
            .put(E_FORM_LINK, String.class)
            .put(AUDIENCES, String[].class)
            .put(FUNDS, String[].class)
            .put(ACCESS, String.class)
            .put(ACCESS_AMERIPRISE_FINANCIAL, Boolean.class)
            .put(ACCESS_EDWARD_JONES, Boolean.class)
            .put(ACCESS_JHI, Boolean.class)
            .put(ACCESS_MERRILL_LYNCH, Boolean.class)
            .put(ACCESS_MORGAN_STANLEY, Boolean.class)
            .put(ACCESS_UBS, Boolean.class)
            .put(CODE, String.class)
            .put(RRD_JIT, String.class)
            .put(RRD_CSS, String.class)
            .put(RRD_ITEM_DESCRIPTION, String.class)
            .put(RRD_WCSS_ITEM_DESCRIPTION, String.class)
            .put(RRD_PACKAGING_QUANTITY, Integer.class)
            .put(RRD_UOM_CODE, String.class)
            .put(RRD_REVISION, String.class)
            .put(RRD_MAXIMUM_ORDER_QUANTITY, Integer.class)
            .put(RRD_ITEM_SUBTYPE, String.class)
            .put(RRD_ORIENTATION, String.class)
            .put(RRD_SIDES_PRINTED, String.class)
            .put(RRD_PAPER_STOCK_TYPE, String.class)
            .put(RRD_PAPER_STOCK_WEIGHT, String.class)
            .put(RRD_PAPER_STOCK_COLOR, String.class)
            .put(RRD_TRIM_SIZE_WIDTH, Float.class)
            .put(RRD_TRIM_SIZE_LENGTH, Float.class)
            .put(RRD_PDF_PAGE_WIDTH, Float.class)
            .put(RRD_PDF_PAGE_LENGTH, Float.class)
            .put(RRD_INK_COLORS, String.class)
            .put(RRD_BLEEDS, String.class)
            .put(RRD_PRINTING_COMMENTS, String.class)
            .put(RRD_MINIMUM_ORDER_QUANTITY, Integer.class)
            .put(RRD_MULTIPLE_ORDER_QUANTITY, Integer.class)
            .put(RRD_FULFILLMENT_BUDGET_CODE, String.class)
            .put(RRD_FULFILLMENT_MANAGER, String.class)
            .put(RRD_MARKETING_MANAGER, String.class)
            .put(RRD_PRINT_STATUS, String.class)
            .put(RRD_CATALOG, String.class)
            .put(RRD_CATEGORY, String.class)
            .put(RRD_SUBCATEGORY1, String.class)
            .put(RRD_SUBCATEGORY2, String.class)
            .put(RRD_APPROVAL_QUANTITY_LIMIT, Integer.class)
            .put(RRD_BUSINESS_UNIT, String.class)
            .build();

    private static final String THUMBNAIL_WIDTH = "100";
    private static final String THUMBNAIL_SELECTOR = "thumbnail";

    protected ValueMap valueMap = null;
    private String webAssetFileName = null;
    private Asset webAsset = null;
    private String printAssetName = null;

    public RrdProductImpl(Resource resource) {
        super(resource);
    }

    @Override
    public String getSKU() {
        return getCode();
    }

    @Override
    public String getThumbnailUrl() {
        return getThumbnailUrl(THUMBNAIL_WIDTH);
    }

    @Override
    public String getThumbnailUrl(String selectorString) {
        String selectors[] = StringUtils.split(selectorString, JhiConstants.DOT);
        Resource assetResource = getAsset();
        if (isAssetValid(assetResource)) {
            ImageResource thumbnail = new ImageResource(assetResource);
            StringBuilder thumbnailSelector = new StringBuilder(THUMBNAIL_SELECTOR);
            for (String part : selectors) {
                if (StringUtils.isNotBlank(part)) {
                    thumbnailSelector.append(JhiConstants.DOT).append(part);
                }
            }
            thumbnail.setSelector(thumbnailSelector.toString());
            return thumbnail.getHref();
        }
        return null;
    }

    @Override
    public String getPagePath() {
        if (resource != null) {
            return resource.getPath();
        }
        return StringUtils.EMPTY;
    }

    @Override
    public Resource getAsset() {
        if (resource != null) {
            Resource assetResource = resource.getChild(WEB_ASSET);
            if (isAssetValid(assetResource)) {
                return assetResource;
            }
            assetResource = resource.getChild(PRINT_ASSET);
            if (isAssetValid(assetResource)) {
                return assetResource;
            }
        }
        return null;
    }

    public Resource getPrintAssetResource() {
        if (resource != null) {
            return resource.getChild(PRINT_ASSET);
        }
        return null;
    }

    public Resource getWebAssetResource() {
        if (resource != null) {
            return resource.getChild(WEB_ASSET);
        }
        return null;
    }

    public String getPrintAssetName() {
        if (printAssetName == null) {
            printAssetName = StringUtils.EMPTY;
            Resource printAssetResource = getPrintAssetResource();
            if (printAssetResource != null && printAssetResource.isResourceType(ResourcesConstants.PRODUCT_IMAGE_RESOURCE_TYPE)) {
                ValueMap assetProperties = printAssetResource.getValueMap();
                String assetDamPath = assetProperties.get(DownloadResource.PN_REFERENCE, String.class);
                if (StringUtils.isNotBlank(assetDamPath)) {
                    Resource assetResource = printAssetResource.getResourceResolver().getResource(assetDamPath);
                    if (assetResource != null) {
                        printAssetName = assetResource.getName();
                    }
                }
            }
        }
        return printAssetName;
    }

    public String getRrdTxnId() {
        return getProperty(RRD_TXN_ID, String.class);
    }

    public boolean setRrdTxnId(String txnId) {
        return setProperty(RRD_TXN_ID, txnId);
    }

    //status
    public Calendar getPublishDate() {
        return getProperty(PUBLISH_DATE, Calendar.class);
    }

    public Calendar getExpirationDate() {
        return getProperty(EXPIRATION_DATE, Calendar.class);
    }

    public String getRrdStatus() {
        return getProperty(RRD_STATUS, String.class);
    }

    public boolean setRrdStatus(String status) {
        return setProperty(RRD_STATUS, status);
    }

    public boolean setRrdStatusMessage(String statusMessage) {
        return setProperty(RRD_STATUS_MESSAGE, statusMessage);
    }

    public String getItemStatus() {
        return getProperty(ITEM_STATUS, String.class);
    }

    public boolean isActive() {
        return RrdItemStatus.ACTIVE.name().equals(getItemStatus());
    }

    public boolean isToBeDiscontinued() {
        return RrdItemStatus.TO_BE_DISCONTINUED.name().equals(getItemStatus());
    }

    public boolean isOrderable() {
        return isActive() || isToBeDiscontinued();
    }

    public void setLastPublishOnRrd(Calendar date) {
        setProperty(LAST_PUBLISH_ON_RRD, date);
    }

    public void setPageStatusCreated() {
        setProperty(PAGE_STATUS, "Created");
    }

    public String getResourcePagePath() {
        return getProperty(RESOURCE_PAGE_PATH, String.class);
    }


    public String getFileType() {
        return StringUtils.upperCase(StringUtils.substringAfterLast(getWebAssetFileName(), JhiConstants.DOT));
    }

    public long getFileSize() {
        Asset webAsset = getWebAsset();
        if (webAsset != null) {
            Rendition originalRendition = webAsset.getOriginal();
            if (originalRendition != null) {
                return originalRendition.getSize();
            }
        }
        return 0;
    }

    public String getWebAssetFileName() {
        if (webAssetFileName == null) {
            webAssetFileName = getAssetFileName(WEB_ASSET);
        }
        return webAssetFileName;
    }

    public Asset getWebAsset() {
        if (webAsset == null) {
            webAsset = getAsset(WEB_ASSET);
        }
        return webAsset;
    }

    public Asset getPrintAsset() {
        if (webAsset == null) {
            webAsset = getAsset(PRINT_ASSET);
        }
        return webAsset;
    }

    public String getThumbnailPath() {
        Asset asset = getWebAsset();
        if (asset == null) {
            asset = getPrintAsset();
        }
        return AssetUtil.getThumbnailPath(asset);
    }

    //asset
    public String getWebAssetPath() {
        return getAssetPath(WEB_ASSET);
    }

    public String getPrintAssetPath() {
        return getAssetPath(PRINT_ASSET);
    }

    //general
    public Calendar getLastUpdated() {
        return getProperty(LAST_UPDATED, Calendar.class);
    }

    public Calendar getLastPublishOnWeb() {
        return getProperty(LAST_PUBLISH_ON_WEB, Calendar.class);
    }

    public String getPublishingFrequency() {
        return getProperty(PUBLISHING_FREQUENCY, String.class);
    }

    public String getDisplayTitle() {
        return StringUtils.defaultString(getProperty(DISPLAY_TITLE, String.class));
    }

    public String getDisplayDescription() {
        return StringUtils.defaultString(getProperty(DISPLAY_DESCRIPTION, String.class));
    }

    public String getMetaTitle() {
        return StringUtils.defaultString(getProperty(META_TITLE, String.class));
    }

    public String getMetaDescription() {
        return StringUtils.defaultString(getProperty(META_DESCRIPTION, String.class));
    }

    public String getApprovedFor() {
        return StringUtils.defaultString(getProperty(APPROVED_FOR, String.class));
    }

    public String getApprovedForText() {
        if (StringUtils.isNotBlank(getApprovedFor())) {
            ApprovedForType approvedForType = ApprovedForType.getByName(getApprovedFor());
            if (approvedForType != null) {
                return approvedForType.getText();
            }
        }
        return StringUtils.EMPTY;
    }

    public String getDocumentType() {
        return getProperty(DOCUMENT_TYPE, String.class);
    }

    public String getElectronicFormLink() {
        return getProperty(E_FORM_LINK, String.class);
    }

    public String[] getTopics() {
        return getProperty(TOPICS, String[].class);
    }

    public String getCategory() {
        return getProperty(CATEGORY, String.class);
    }

    public String[] getAudiences() {
        return getProperty(AUDIENCES, String[].class);
    }

    public String[] getFunds() {
        return getProperty(FUNDS, String[].class);
    }

    //permissions
    public String getAccess() {
        return StringUtils.defaultString(getProperty(ACCESS, String.class));
    }

    public boolean isAccessPublic() {
        return StringUtils.equals(getAccess(), JhiConstants.ACCESS_PUBLIC);
    }

    public boolean isAccessAdvisor() {
        return StringUtils.equals(getAccess(), JhiConstants.ACCESS_ADVISOR);
    }

    public boolean isAccessExclusive() {
        return StringUtils.equals(getAccess(), JhiConstants.ACCESS_EXCLUSIVE);
    }

    public boolean isAccessRestricted() {
        return StringUtils.equals(getAccess(), JhiConstants.ACCESS_RESTRICTED);
    }

    public boolean isAccessInternal() {
        return StringUtils.equals(getAccess(), JhiConstants.ACCESS_INTERNAL);
    }

    public boolean isAllowedEdwardJones() {
        return getAccessProperty(ACCESS_EDWARD_JONES);
    }

    public boolean isAllowedMerrillLynch() {
        return getAccessProperty(ACCESS_MERRILL_LYNCH);
    }

    public boolean isAllowedMorganStanley() {
        return getAccessProperty(ACCESS_MORGAN_STANLEY);
    }

    public boolean isAllowedUbs() {
        return getAccessProperty(ACCESS_UBS);
    }

    public boolean isAllowedAmeripriseFinancial() {
        return getAccessProperty(ACCESS_AMERIPRISE_FINANCIAL);
    }

    public boolean isAllowedJhi() {
        return getAccessProperty(ACCESS_JHI);
    }

    public String[] getAllowedArray() {
        List<String> restrictions = new ArrayList<>(12);
        if (isAllowedAmeripriseFinancial()) {
            restrictions.add(JhiConstants.ALLOWED_AMERIPRISE_FINANCIAL_VALUE);
        }
        if (isAllowedEdwardJones()) {
            restrictions.add(JhiConstants.ALLOWED_EDWARD_JONES_VALUE);
        }
        if (isAllowedJhi()) {
            restrictions.add(JhiConstants.ALLOWED_JHI);
        }
        if (isAllowedMerrillLynch()) {
            restrictions.add(JhiConstants.ALLOWED_MERRILL_LYNCH_VALUE);
        }
        if (isAllowedMorganStanley()) {
            restrictions.add(JhiConstants.ALLOWED_MORGAN_STANLEY_VALUE);
        }
        if (isAllowedUbs()) {
            restrictions.add(JhiConstants.ALLOWED_UBS_VALUE);
        }
        if (getAccessProperty(ACCESS_WELLS_FARGO)) {
            restrictions.add(JhiConstants.ALLOWED_WELLS_FARGO_VALUE);
        }
        if (getAccessProperty(ACCESS_AXA)) {
            restrictions.add(JhiConstants.ALLOWED_AXA_VALUE);
        }
        if (getAccessProperty(ACCESS_COMMONWEALTH)) {
            restrictions.add(JhiConstants.ALLOWED_COMMONWEALTH_VALUE);
        }
        if (getAccessProperty(ACCESS_LPL)) {
            restrictions.add(JhiConstants.ALLOWED_LPL_VALUE);
        }
        if (getAccessProperty(ACCESS_RAYMOND_JAMES)) {
            restrictions.add(JhiConstants.ALLOWED_RAYMOND_JAMES_VALUE);
        }
        if (getAccessProperty(ACCESS_NORTHWEST_MUTUAL)) {
            restrictions.add(JhiConstants.ALLOWED_NORTHWEST_MUTUAL_VALUE);
        }
        return restrictions.toArray(new String[0]);
    }

    //lit only
    public String getCode() {
        return getProperty(CODE, String.class);
    }

    public boolean setCode(String code) {
        return setProperty(CODE, StringUtils.upperCase(code));
    }

    public boolean isJit() {
        if (valueMap == null) {
            if (resource != null) {
                valueMap = resource.getValueMap();
            }
        }
        return valueMap != null && BOOLEAN_TRUE_Y.equals(valueMap.get(RRD_JIT, String.class));
    }

    public String getJit() {
        return getProperty(RRD_JIT, String.class);
    }

    public boolean isCSS() {
        if (valueMap == null) {
            if (resource != null) {
                valueMap = resource.getValueMap();
            }
        }
        return valueMap != null && BOOLEAN_TRUE_Y.equals(valueMap.get(RRD_CSS, String.class));
    }

    public String getCss() {
        return getProperty(RRD_CSS, String.class);
    }

    public String getCpItemDescription() {
        return getProperty(RRD_ITEM_DESCRIPTION, String.class);
    }

    public String getWcssItemDescription() {
        return getProperty(RRD_WCSS_ITEM_DESCRIPTION, String.class);
    }

    public String getUomCode() {
        return getProperty(RRD_UOM_CODE, String.class);
    }

    public Integer getPackagingQuantity() {
        return getProperty(RRD_PACKAGING_QUANTITY, Integer.class);
    }

    public String getRevision() {
        return getProperty(RRD_REVISION, String.class);
    }

    public Integer getMaximumOrderQuantity() {
        return getProperty(RRD_MAXIMUM_ORDER_QUANTITY, Integer.class);
    }

    public String getItemSubtype() {
        return getProperty(RRD_ITEM_SUBTYPE, String.class);
    }

    public String getOrientation() {
        return getProperty(RRD_ORIENTATION, String.class);
    }

    public String getSidesPrinted() {
        return getProperty(RRD_SIDES_PRINTED, String.class);
    }

    public String getPaperStockType() {
        return getProperty(RRD_PAPER_STOCK_TYPE, String.class);
    }

    public String getPaperStockWeight() {
        return getProperty(RRD_PAPER_STOCK_WEIGHT, String.class);
    }

    public String getPaperStockColor() {
        return getProperty(RRD_PAPER_STOCK_COLOR, String.class);
    }

    public Float getTrimSizeWidth() {
        return getProperty(RRD_TRIM_SIZE_WIDTH, Float.class);
    }

    public Float getTrimSizeLength() {
        return getProperty(RRD_TRIM_SIZE_LENGTH, Float.class);
    }

    public Float getPdfPageWidth() {
        return getProperty(RRD_PDF_PAGE_WIDTH, Float.class);
    }

    public Float getPdfPageLength() {
        return getProperty(RRD_PDF_PAGE_LENGTH, Float.class);
    }

    public String getInkColors() {
        return getProperty(RRD_INK_COLORS, String.class);
    }

    public String getBleeds() {
        return getProperty(RRD_BLEEDS, String.class);
    }

    public String getPrintingComments() {
        return getProperty(RRD_PRINTING_COMMENTS, String.class);
    }

    public Integer getMinimumOrderQuantity() {
        return getProperty(RRD_MINIMUM_ORDER_QUANTITY, Integer.class);
    }

    public Integer getMultipleOrderQuantity() {
        return getProperty(RRD_MULTIPLE_ORDER_QUANTITY, Integer.class);
    }

    public String getFulfillmentBudgetCode() {
        return getProperty(RRD_FULFILLMENT_BUDGET_CODE, String.class);
    }

    public String getFulfillmentManager() {
        return getProperty(RRD_FULFILLMENT_MANAGER, String.class);
    }

    public String getMarketingManager() {
        return getProperty(RRD_MARKETING_MANAGER, String.class);
    }

    public String getPrintStatus() {
        return getProperty(RRD_PRINT_STATUS, String.class);
    }

    public String getCatalog() {
        return getProperty(RRD_CATALOG, String.class);
    }

    public String getRrdCategory() {
        return getProperty(RRD_CATEGORY, String.class);
    }

    public String getSubcategory1() {
        return getProperty(RRD_SUBCATEGORY1, String.class);
    }

    public String getSubcategory2() {
        return getProperty(RRD_SUBCATEGORY2, String.class);
    }

    public Integer getCpApprovalQuantityLimit() {
        return getProperty(RRD_APPROVAL_QUANTITY_LIMIT, Integer.class);
    }

    public String getCpBusinessUnits() {
        return getProperty(RRD_BUSINESS_UNIT, String.class);
    }

    private boolean setProperty(String propertyName, Object propertyValue) {
        if (resource != null) {
            ModifiableValueMap productValues = resource.adaptTo(ModifiableValueMap.class);
            if (productValues != null) {
                productValues.put(propertyName, propertyValue);
                try {
                    resource.getResourceResolver().commit();
                    return true;
                } catch (PersistenceException e) {
                    LOGGER.error("Problem while saving " + propertyName, e);
                }
            } else {
                LOGGER.error("Can't create ModifiableValueMap for " + resource.getPath());
            }
        }
        return false;
    }

    private boolean getAccessProperty(String propertyName) {
        if (valueMap == null) {
            if (resource != null) {
                valueMap = resource.getValueMap();
            }
        }
        return valueMap != null && valueMap.containsKey(propertyName) && Boolean.TRUE.equals(valueMap.get(propertyName, Boolean.class));
    }

    @Override
    public <T> T getProperty(String name, Class<T> type) {
        if (valueMap == null) {
            if (resource != null) {
                valueMap = resource.getValueMap();
            }
        }
        if (valueMap != null && valueMap.containsKey(name)) {
            return valueMap.get(name, type);
        }
        return null;
    }

    private String getAssetPath(String assetType) {
        if (resource != null) {
            Resource assetResource = resource.getChild(assetType);
            if (assetResource != null) {
                ValueMap assetValues = assetResource.getValueMap();
                return assetValues.get(DownloadResource.PN_REFERENCE, StringUtils.EMPTY);
            }
        }
        return StringUtils.EMPTY;
    }

    private Asset getAsset(String assetType) {
        String assetPath = getAssetPath(assetType);
        if (StringUtils.isNotBlank(assetPath)) {
            Resource assetResource = resource.getResourceResolver().getResource(assetPath);
            if (assetResource != null) {
                return assetResource.adaptTo(Asset.class);
            }
        }
        return null;
    }

    private String getAssetFileName(String assetType) {
        Asset asset = getAsset(assetType);
        if (asset != null) {
            return asset.getName();
        }
        return StringUtils.EMPTY;
    }

    private boolean isAssetValid(Resource assetResource) {
        if (assetResource != null) {
            ValueMap assetValues = assetResource.getValueMap();
            if (assetValues.containsKey(DownloadResource.PN_REFERENCE)) {
                String assetPath = assetValues.get(DownloadResource.PN_REFERENCE, StringUtils.EMPTY);
                return StringUtils.startsWith(assetPath, DamConstants.MOUNTPOINT_ASSETS);
            }
        }
        return false;
    }
}
