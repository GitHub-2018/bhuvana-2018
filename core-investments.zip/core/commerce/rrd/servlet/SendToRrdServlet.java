package com.jhi.aem.website.v1.core.commerce.rrd.servlet;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Calendar;

import javax.annotation.Nonnull;
import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.Product;
import com.google.common.net.MediaType;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.AisService;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.ResponseSAR;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.impl.FtpSentStatus;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.HtmlUtil;
import com.jhi.aem.website.v1.core.utils.LogUtils;

@Component(
		name="Send to RRD Servlet",
		immediate=true,
		service=Servlet.class,
		property= {
				"sling.servlet.resourceTypes="+Product.RESOURCE_TYPE_PRODUCT,
				"sling.servlet.selectors="+ SendToRrdServlet.SEND_TO_RRD_SELECTOR,	
				"sling.servlet.extensions="+JhiConstants.HTML_EXTENSION,
				"sling.servlet.methods="+HttpConstants.METHOD_POST
		})

public class SendToRrdServlet extends SlingAllMethodsServlet {
    static final String SEND_TO_RRD_SELECTOR = "rrd_send";

    public static final Logger LOGGER = LoggerFactory.getLogger(SendToRrdServlet.class);

    
    private RunModeService runModeService;
    @Reference
    public void bindRunModeService(RunModeService runModeService) {
    	this.runModeService=runModeService;
    }
    public void unbindRunModeService(RunModeService runModeService) {
    	this.runModeService=runModeService;
    }

    
    private AisService aisService;
    @Reference
    public void bindAisService(AisService aisService) {
    	this.aisService=aisService;
    }
    public void unbindAisService(AisService aisService) {
    	this.aisService=aisService;
    }

    private boolean onAuthor;

    @Override
    protected void doPost(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws IOException {

        response.setContentType(MediaType.HTML_UTF_8.type());
        response.setCharacterEncoding(JhiConstants.DEFAULT_CHARSET_NAME);

        if (onAuthor) {
            Resource productResource = request.getResource();
            RrdProductImpl product = new RrdProductImpl(productResource);
            ResponseSAR responseSAR = null;

            try {
                responseSAR = aisService.submitAssetRequest(product);
            } catch (Exception e) {
                LOGGER.error("Problem while executing asset request", e);
            }
            if (responseSAR != null) {
                product.setLastPublishOnRrd(Calendar.getInstance());
                if (BigInteger.ZERO.equals(responseSAR.getResult().getReturnCode())) {
                    product.setRrdTxnId(responseSAR.getTxnID().toString());
                    product.setRrdStatus(RrdProductImpl.RRD_STATUS_SUBMITTED);
                    product.setRrdStatusMessage(StringUtils.SPACE);
                    response.setStatus(HttpServletResponse.SC_OK);
                    response.getWriter().write("<div>Product submitted ");
                    response.getWriter().write(HtmlUtil.sanitizeTextToIncludeInHtml(responseSAR.getResult().getReturnMsg()));
                    response.getWriter().write("</div>");
                    FtpSentStatus ftpSentStatus = aisService.sendFileToFtp(productResource);
                    if (ftpSentStatus.isSuccess()) {
                        response.getWriter().write("<div class=\"success\">");
                    } else {
                        response.getWriter().write("<div class=\"error\">");
                    }
                    response.getWriter().write(ftpSentStatus.getMessage() + "</div>");
                } else {
                    LOGGER.error("AIS request error: {} - {} - {}",
                            new Object[]{
                                    LogUtils.sanitizeLogInput(responseSAR.getResult().getReturnCode()),
                                    LogUtils.sanitizeLogInput(responseSAR.getResult().getReturnMsg()),
                                    LogUtils.sanitizeLogInput(responseSAR.getValidationDetail())});
                    if (!BigInteger.TEN.equals(responseSAR.getResult().getReturnCode())) {
                        product.setRrdStatus(RrdProductImpl.RRD_STATUS_FAILED);
                        String message = responseSAR.getResult().getReturnMsg()
                                + StringUtils.SPACE + responseSAR.getValidationDetail();
                        product.setRrdStatusMessage(message);
                        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                        response.getWriter().write(HtmlUtil.sanitizeTextToIncludeInHtml(message, 256));
                    }
                }
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("AIS Service not available");
            }
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Activate
    protected void activate() {
        onAuthor = runModeService.isAuthor();
    }
}
