package com.jhi.aem.website.v1.core.commerce.rrd.servlet;

import java.io.IOException;

import javax.annotation.Nonnull;
import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.adobe.cq.commerce.api.Product;
import com.google.common.net.MediaType;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPageResult;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPagesService;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.osgi.OsgiConfigurationService;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.DispatcherFlushUtil;
import com.jhi.aem.website.v1.core.servlets.assetmanager.AssetManagerServlet;



/**
 * Servlet will be called when "Publish to Web" button is triggered from Proucts UI
 * 
 * @version 1.0.0
 * @version 1.0.1 - #1749 
 *
 */
@Component(
		name="Product Page Servlet",
		immediate=true,
		service=Servlet.class,
		property= {
				"sling.servlet.resourceTypes="+Product.RESOURCE_TYPE_PRODUCT ,
				"sling.servlet.selectors="+ ProductPageServlet.CREATE_PAGE_SELECTOR,	
				"sling.servlet.extensions="+JhiConstants.HTML_EXTENSION,
				"sling.servlet.methods="+HttpConstants.METHOD_POST
		})

public class ProductPageServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = -9055588013452800726L;
    static final String CREATE_PAGE_SELECTOR = "create_page";
	private static final Logger LOG = LoggerFactory.getLogger(ProductPageServlet.class);

    
    private RunModeService runModeService;
    @Reference
    public void bindRunModeService(RunModeService runModeService) {
    	this.runModeService=runModeService;
    }
    public void unbindRunModeService(RunModeService runModeService) {
    	this.runModeService=runModeService;
    }
 
    private ProductPagesService productPagesService;
    @Reference
    public void bindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService=productPagesService;
    }
    public void unbindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService=productPagesService;
    }
    
	 
    private OsgiConfigurationService configService;
	@Reference
	public void bindOsgiConfigurationService(OsgiConfigurationService configService) {
    	this.configService=configService;
    }
    public void unbindOsgiConfigurationService(OsgiConfigurationService configService) {
    	this.configService=configService;
    }

    private boolean onAuthor;

    @Override
    protected void doPost(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws IOException {

        response.setContentType(MediaType.PLAIN_TEXT_UTF_8.type());
        response.setCharacterEncoding(JhiConstants.DEFAULT_CHARSET_NAME);
        Resource productResoure = request.getResource();
        if (onAuthor && null != productResoure) {
            ProductPageResult result = productPagesService.createPage(productResoure);
            /*DEBUG Logs */
            LOG.debug("Product Page request is " + request.getResource().getPath());
            if (result != null && result.isSuccess()) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("<div id=\"create-result-message\">" + result.getMessage() + "</div>");
                
                //GIT # 1749 : add cache flush here 
                //Since the page creation is successful , we will flush the fund paths if it is tagged
                
                RrdProductImpl product = new RrdProductImpl(request.getResource());
				if (product != null) {
					LOG.debug("Product Funds are " + product.getFunds());

					// to flush the key documents, we will flush the root path
					// Since if the business removes a tag or removes the entire
					// tag
					// It would be additional effort to listen to the changes to
					// track the funds removed
					// So to simplify , we will flush everything under
					// JhiConstants.FUNDS_PAGE_PATH 
					//String pathToClear = JhiConstants.FUNDS_PAGE_PATH ;
					
					//GIT #1749 Dated - Nov 16 2018 - Changed to add more than one path to flush when a product is updated
					//Paths moved to config for flexibility in later stage if the resource paths are chnaged 
					String[] pathsToClear = configService.getProperty(JhiConstants.DISPATCHER_CONFIG_PID,
							JhiConstants.CONFIG_INVALIDATE_PATHS, new String[0]);
					DispatcherFlushUtil.clearDispatcherCache(pathsToClear);

				}
                
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                if (result != null) {
                    response.getWriter().write(result.getMessage());
                }
            }
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Activate
    protected void activate() {
        onAuthor = runModeService.isAuthor();
    }
}
