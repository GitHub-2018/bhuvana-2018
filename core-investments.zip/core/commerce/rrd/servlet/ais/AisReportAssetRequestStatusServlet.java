package com.jhi.aem.website.v1.core.commerce.rrd.servlet.ais;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.distribution.DistributionRequest;
import org.apache.sling.distribution.DistributionRequestType;
import org.apache.sling.distribution.Distributor;
import org.apache.sling.distribution.SimpleDistributionRequest;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.AisService;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.AssetStatuses;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.DAOResponseRARS;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeAssetStatus;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeGeneralResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeResponseHeader;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.servlets.assetmanager.AssetManagerServlet;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Component(
		name="AIS Report Asset Request Status Servlet",
		service=Servlet.class,
		immediate=true,
		property= {
				"sling.servlet.paths=/bin/jhi-website/ais/reportAssetRequestStatus" ,
				"sling.servlet.extensions="+JhiConstants.XML_EXTENSION,
				"sling.servlet.methods="+HttpConstants.METHOD_POST			
		})

public class AisReportAssetRequestStatusServlet extends SlingAllMethodsServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = LoggerFactory.getLogger(AisReportAssetRequestStatusServlet.class);

    private static final String RESPONSE_SERVICE_ID = "Test_RARS";
    private static final String RESPONSE_TYPE_INFO = "Info";
    private static final String RESPONSE_TYPE_ERROR = "Error";
    private static final String RESPONSE_MESSAGE_SUCCESS = "Success";

    private static final BigInteger REQUEST_PARSING_ERROR_CODE = BigInteger.valueOf(1000);
    private static final String REQUEST_PARSING_ERROR_MESSAGE = "Error while parsing request";
    private static final BigInteger INVALID_IDS_ERROR_CODE = BigInteger.valueOf(2000);
    private static final String INVALID_IDS_ERROR_MESSAGE = "Invalid IDs passed";
    private static final BigInteger EMPTY_REQUEST_ERROR_CODE = BigInteger.valueOf(3000);
    private static final String EMPTY_REQUEST_ERROR_MESSAGE = "Empty request passed";

    
    private RunModeService runModeService;
    @Reference
    public void bindRunModeService (RunModeService runModeService) {
    	this.runModeService=runModeService;
    }
    public void unbindRunModeService (RunModeService runModeService) {
    	this.runModeService=runModeService;
    }

    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory (ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory (ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }

    
    private AisService aisService;
    @Reference
    public void bindAisService (AisService aisService) {
    	this.aisService=aisService;
    }
    public void unbindAisService (AisService aisService) {
    	this.aisService=aisService;
    }

    
    private SlingSettingsService slingSettingsService;
    @Reference
    public void bindSlingSettingsService(SlingSettingsService slingSettingsService) {
    	this.slingSettingsService=slingSettingsService;
    }
    public void unbindSlingSettingsService(SlingSettingsService slingSettingsService) {
    	this.slingSettingsService=slingSettingsService;
    }

    
    private Distributor distributor;
    @Reference
    public void bindDistributor(Distributor distributor) {
    	this.distributor=distributor;
    }

    private boolean onPublish;
    private String id;

    private JAXBContext jaxbRarsContext;
    private JAXBContext jaxbStdResponseContext;

    private DocumentBuilderFactory dbf;

    @Override
    protected void doGet(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws ServletException, IOException {
        response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
    }

    @Override
    protected void doPost(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws IOException {
        if (!onPublish) {
            response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return;
        }
        Unmarshaller requestUnmarshaller = null;
        Marshaller responseMarshaller = null;
        PrintWriter writer = response.getWriter();

        try {
            requestUnmarshaller = jaxbRarsContext.createUnmarshaller();
            responseMarshaller = jaxbStdResponseContext.createMarshaller();
        } catch (JAXBException e) {
            LOGGER.error("Jaxb initialization problem", e);
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }

        if (requestUnmarshaller != null && responseMarshaller != null) {
            response.setStatus(HttpServletResponse.SC_OK);
            response.setContentType(JhiConstants.TEXT_XML);

            try {
                DocumentBuilder db = dbf.newDocumentBuilder();
                dbf.setExpandEntityReferences(false);
                Document document = db.parse(request.getInputStream());
                AssetStatuses assetStatuses = (AssetStatuses) requestUnmarshaller.unmarshal(document);
                if (assetStatuses != null && assetStatuses.getAssets() != null) {
                    for (TypeAssetStatus assetStatus : assetStatuses.getAssets().getAssetStatus()) {
                        if (aisService.getCustomerId() == assetStatus.getCustomerID()) {
                            if (saveAssetRequestReportData(assetStatus)) {
                                sendResponse(writer, responseMarshaller, prepareResponse());
                            }
                        } else {
                            sendResponse(writer, responseMarshaller, prepareErrorResponse(INVALID_IDS_ERROR_CODE, INVALID_IDS_ERROR_MESSAGE));
                        }
                    }
                } else {
                    sendResponse(writer, responseMarshaller, prepareErrorResponse(EMPTY_REQUEST_ERROR_CODE, EMPTY_REQUEST_ERROR_MESSAGE));
                }
            } catch (JAXBException e) {
                LOGGER.error("Problem while parsing request", e);
                sendResponse(writer, responseMarshaller, prepareErrorResponse(REQUEST_PARSING_ERROR_CODE, REQUEST_PARSING_ERROR_MESSAGE));
            } catch (SAXException | ParserConfigurationException e) {
                LOGGER.error("Problem while creating xml parser", e);
                sendResponse(writer, responseMarshaller, prepareErrorResponse(REQUEST_PARSING_ERROR_CODE, REQUEST_PARSING_ERROR_MESSAGE));
            }
        }
    }

    private void sendResponse(PrintWriter writer, Marshaller responseMarshaller, DAOResponseRARS jaxbElement) {
        try {
            responseMarshaller.marshal(jaxbElement, writer);
        } catch (JAXBException e) {
            LOGGER.error("Problem while building response", e);
        }
    }

    private DAOResponseRARS prepareResponse() {
        DAOResponseRARS responseRARS = new DAOResponseRARS();
        TypeResponseHeader responseHeader = getResponseHeader();
        responseRARS.setHeader(responseHeader);
        TypeGeneralResponse results = new TypeGeneralResponse();
        responseRARS.setResult(results);
        results.setResponseType(RESPONSE_TYPE_INFO);
        results.setReturnCode(BigInteger.ZERO);
        results.setReturnMsg(RESPONSE_MESSAGE_SUCCESS);
        return responseRARS;
    }

    private DAOResponseRARS prepareErrorResponse(BigInteger errorCode, String message) {
        DAOResponseRARS responseRARS = new DAOResponseRARS();
        responseRARS.setHeader(getResponseHeader());
        TypeGeneralResponse results = new TypeGeneralResponse();
        responseRARS.setResult(results);
        results.setResponseType(RESPONSE_TYPE_ERROR);
        results.setReturnCode(errorCode);
        results.setReturnMsg(message);
        return responseRARS;
    }

    private TypeResponseHeader getResponseHeader() {
        TypeResponseHeader responseHeader = new TypeResponseHeader();
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(Calendar.getInstance().getTime());
        try {
            responseHeader.setInvokedDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar));
        } catch (DatatypeConfigurationException e) {
            LOGGER.warn("Problem while preparing invoked date", e);
        }
        responseHeader.setServiceInvoked(RESPONSE_SERVICE_ID);
        responseHeader.setSYSID(aisService.getSystemId());
        return responseHeader;
    }

    private boolean saveAssetRequestReportData(TypeAssetStatus assetStatus) {
        boolean result = true;
        ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
        if (resourceResolver == null) {
            LOGGER.error("Resource resolver not available");
            result = false;
        } else {
            Resource varAssetRequestsResource = null;
            Resource savedAssetStatusResource = null;
            try {
                varAssetRequestsResource = ResourceUtil.getOrCreateResource(resourceResolver, JhiConstants.VAR_ASSET_REQUEST_STATUS_PATH,
                        JcrResourceConstants.NT_SLING_FOLDER, JcrResourceConstants.NT_SLING_FOLDER, true);
            } catch (PersistenceException e) {
                LOGGER.error("Problem while creating resource for asset request status", e);
                result = false;
            }
            if (varAssetRequestsResource != null) {
                Calendar date = Calendar.getInstance(Locale.US);
                try {
                    savedAssetStatusResource = resourceResolver.create(varAssetRequestsResource,
                            date.getTimeInMillis() + "_" + id, getAssetStatusProperties(assetStatus));
                } catch (PersistenceException e) {
                    LOGGER.error("Problem while saving page views data", e);
                    result = false;
                }
                try {
                    resourceResolver.commit();
                } catch (PersistenceException e) {
                    LOGGER.error("Problem while persisting views", e);
                    result = false;
                }

                if (aisService != null && StringUtils.isNotBlank(aisService.getDistributionAgentName())
                        && savedAssetStatusResource != null) {
                    DistributionRequest distributionRequest = new SimpleDistributionRequest(DistributionRequestType.ADD, true,
                            savedAssetStatusResource.getPath());
                    distributor.distribute(aisService.getDistributionAgentName(), resourceResolver, distributionRequest);
                } else {
                    result = false;
                }
            }

            resourceResolver.close();
        }
        return result;
    }

    private Map<String, Object> getAssetStatusProperties(TypeAssetStatus assetStatus) {
        Map<String, Object> properties = new HashMap<>(3);
        properties.put(RrdProductImpl.CODE, assetStatus.getCustItemNum());
        properties.put(RrdProductImpl.RRD_STATUS, assetStatus.getStatusCode());
        properties.put(RrdProductImpl.RRD_STATUS_MESSAGE, assetStatus.getStatusMsg());
        return properties;
    }

    @Activate
    protected void activate() {
        onPublish = runModeService.isPublish();
        id = slingSettingsService.getSlingId();
        try {
            jaxbRarsContext = JAXBContext.newInstance(AssetStatuses.class);
            jaxbStdResponseContext = JAXBContext.newInstance(DAOResponseRARS.class);
        } catch (JAXBException e) {
            LOGGER.error("Problem while creating jaxb context", e);
        }

        // Fortify scan highlighted issues with expanded entity references, parse all the
        // streams as XML documents first using this factory
        dbf = DocumentBuilderFactory.newInstance();
        dbf.setExpandEntityReferences(false);
    }
}
