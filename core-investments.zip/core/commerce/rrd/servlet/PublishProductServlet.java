package com.jhi.aem.website.v1.core.commerce.rrd.servlet;


import javax.servlet.Servlet;

import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;

import com.adobe.cq.commerce.api.Product;
import com.jhi.aem.website.v1.core.constants.JhiConstants;


@Component(
		name="Publish Product Servlet",
		service=Servlet.class,
		immediate=true,
		property= {
				"sling.servlet.resourceTypes="+Product.RESOURCE_TYPE_PRODUCT,
				"sling.servlet.selectors="+ PublishProductServlet.PUBLISH_SELECTOR,	
				"sling.servlet.extensions="+JhiConstants.HTML_EXTENSION,
				"sling.servlet.methods="+HttpConstants.METHOD_POST
		})
public class PublishProductServlet extends SlingAllMethodsServlet {
    public static final String PUBLISH_SELECTOR = "publish";
}
