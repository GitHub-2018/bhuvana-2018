package com.jhi.aem.website.v1.core.commerce.rrd;

public class OrderItemShipmentDetails {
    private String quantity;
    private String date;
    private String trackingId;

    public OrderItemShipmentDetails(String quantity, String date, String trackingId) {
        this.quantity = quantity;
        this.date = date;
        this.trackingId = trackingId;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getDate() {
        return date;
    }

    public String getTrackingId() {
        return trackingId;
    }
}
