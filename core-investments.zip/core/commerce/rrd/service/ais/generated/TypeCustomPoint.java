
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TypeCustomPoint complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeCustomPoint">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CustomPointAttributeNameValue" type="{}TypeCustomPointAttributeValue" maxOccurs="100" minOccurs="0"/>
 *         &lt;element name="CustomPointCatalog" type="{}TypeCustomPointCatalog" maxOccurs="100" minOccurs="0"/>
 *         &lt;element name="CustomPointManagedItem" type="{}TypeCustomPointManagedItem" minOccurs="0"/>
 *         &lt;element name="CustomPointItemAssociation" type="{}TypeCustomPointItemAssociation" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeCustomPoint", propOrder = {
    "customPointAttributeNameValue",
    "customPointCatalog",
    "customPointManagedItem",
    "customPointItemAssociation"
})
public class TypeCustomPoint {

    @XmlElement(name = "CustomPointAttributeNameValue")
    protected List<TypeCustomPointAttributeValue> customPointAttributeNameValue;
    @XmlElement(name = "CustomPointCatalog")
    protected List<TypeCustomPointCatalog> customPointCatalog;
    @XmlElement(name = "CustomPointManagedItem")
    protected TypeCustomPointManagedItem customPointManagedItem;
    @XmlElement(name = "CustomPointItemAssociation")
    protected TypeCustomPointItemAssociation customPointItemAssociation;

    /**
     * Gets the value of the customPointAttributeNameValue property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customPointAttributeNameValue property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomPointAttributeNameValue().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypeCustomPointAttributeValue }
     * 
     * 
     */
    public List<TypeCustomPointAttributeValue> getCustomPointAttributeNameValue() {
        if (customPointAttributeNameValue == null) {
            customPointAttributeNameValue = new ArrayList<TypeCustomPointAttributeValue>();
        }
        return this.customPointAttributeNameValue;
    }

    /**
     * Gets the value of the customPointCatalog property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customPointCatalog property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomPointCatalog().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypeCustomPointCatalog }
     * 
     * 
     */
    public List<TypeCustomPointCatalog> getCustomPointCatalog() {
        if (customPointCatalog == null) {
            customPointCatalog = new ArrayList<TypeCustomPointCatalog>();
        }
        return this.customPointCatalog;
    }

    /**
     * Gets the value of the customPointManagedItem property.
     * 
     * @return
     *     possible object is
     *     {@link TypeCustomPointManagedItem }
     *     
     */
    public TypeCustomPointManagedItem getCustomPointManagedItem() {
        return customPointManagedItem;
    }

    /**
     * Sets the value of the customPointManagedItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeCustomPointManagedItem }
     *     
     */
    public void setCustomPointManagedItem(TypeCustomPointManagedItem value) {
        this.customPointManagedItem = value;
    }

    /**
     * Gets the value of the customPointItemAssociation property.
     * 
     * @return
     *     possible object is
     *     {@link TypeCustomPointItemAssociation }
     *     
     */
    public TypeCustomPointItemAssociation getCustomPointItemAssociation() {
        return customPointItemAssociation;
    }

    /**
     * Sets the value of the customPointItemAssociation property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeCustomPointItemAssociation }
     *     
     */
    public void setCustomPointItemAssociation(TypeCustomPointItemAssociation value) {
        this.customPointItemAssociation = value;
    }

}
