
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypeItemRef complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeItemRef">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Item_Ref_Name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Item_Ref_Value">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeItemRef", propOrder = {
    "itemRefName",
    "itemRefValue"
})
public class TypeItemRef {

    @XmlElement(name = "Item_Ref_Name", required = true)
    protected String itemRefName;
    @XmlElement(name = "Item_Ref_Value", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String itemRefValue;

    /**
     * Gets the value of the itemRefName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemRefName() {
        return itemRefName;
    }

    /**
     * Sets the value of the itemRefName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemRefName(String value) {
        this.itemRefName = value;
    }

    /**
     * Gets the value of the itemRefValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemRefValue() {
        return itemRefValue;
    }

    /**
     * Sets the value of the itemRefValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemRefValue(String value) {
        this.itemRefValue = value;
    }

}
