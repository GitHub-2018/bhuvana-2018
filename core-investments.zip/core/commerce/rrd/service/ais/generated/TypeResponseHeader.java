
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TypeResponseHeader complex type.
 * <p>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="TypeResponseHeader">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SYSID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ServiceInvoked">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="WS_SAR"/>
 *               &lt;enumeration value="WS_QARS"/>
 *               &lt;enumeration value="WS_QT"/>
 *               &lt;enumeration value="Test_RARS"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="InvokedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeResponseHeader", propOrder = {
        "sysid",
        "serviceInvoked",
        "invokedDate"
})
public class TypeResponseHeader {

    @XmlElement(name = "SYSID")
    protected int sysid;
    @XmlElement(name = "ServiceInvoked", required = true)
    protected String serviceInvoked;
    @XmlElement(name = "InvokedDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar invokedDate;

    /**
     * Gets the value of the sysid property.
     */
    public int getSYSID() {
        return sysid;
    }

    /**
     * Sets the value of the sysid property.
     */
    public void setSYSID(int value) {
        this.sysid = value;
    }

    /**
     * Gets the value of the serviceInvoked property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getServiceInvoked() {
        return serviceInvoked;
    }

    /**
     * Sets the value of the serviceInvoked property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setServiceInvoked(String value) {
        this.serviceInvoked = value;
    }

    /**
     * Gets the value of the invokedDate property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getInvokedDate() {
        return invokedDate;
    }

    /**
     * Sets the value of the invokedDate property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setInvokedDate(XMLGregorianCalendar value) {
        this.invokedDate = value;
    }

}
