
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypeCustomPointCatalog complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeCustomPointCatalog">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Catalog_Name">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Category_Name">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name1" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name2" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name3" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name4" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name5" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name6" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name7" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name8" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name9" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SubCategory_Name10" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="View_Only" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="EDoc_Indicator" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Always_Route_Indicator" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Always_Keep_Indicator" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Display_Order" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="EDoc_URL" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="255"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="UNSPSC_Code" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="12"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Approval_Quantity_Limit" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}long">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Invalid_Item_Indicator" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CP_BUID" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Item_Description" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="120"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Assigned_Approval_Queue" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Routing_Qty_For_Item_Approval" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="0"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Always_Route_For_Item_Approval" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Alternate_Description" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Alternate_Description_Flag" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Delivery_Option" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="EFD_Source" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="EFD_Settings" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="EFD_Use_Default_Service_Charge" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="EFD_Service_Fee" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="EFD_Transfer_Cost" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeCustomPointCatalog", propOrder = {
    "catalogName",
    "categoryName",
    "subCategoryName1",
    "subCategoryName2",
    "subCategoryName3",
    "subCategoryName4",
    "subCategoryName5",
    "subCategoryName6",
    "subCategoryName7",
    "subCategoryName8",
    "subCategoryName9",
    "subCategoryName10",
    "viewOnly",
    "eDocIndicator",
    "alwaysRouteIndicator",
    "alwaysKeepIndicator",
    "displayOrder",
    "eDocURL",
    "unspscCode",
    "approvalQuantityLimit",
    "invalidItemIndicator",
    "cpbuid",
    "itemDescription",
    "assignedApprovalQueue",
    "routingQtyForItemApproval",
    "alwaysRouteForItemApproval",
    "alternateDescription",
    "alternateDescriptionFlag",
    "deliveryOption",
    "efdSource",
    "efdSettings",
    "efdUseDefaultServiceCharge",
    "efdServiceFee",
    "efdTransferCost"
})
public class TypeCustomPointCatalog {

    @XmlElement(name = "Catalog_Name", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String catalogName;
    @XmlElement(name = "Category_Name", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String categoryName;
    @XmlElement(name = "SubCategory_Name1")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName1;
    @XmlElement(name = "SubCategory_Name2")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName2;
    @XmlElement(name = "SubCategory_Name3")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName3;
    @XmlElement(name = "SubCategory_Name4")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName4;
    @XmlElement(name = "SubCategory_Name5")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName5;
    @XmlElement(name = "SubCategory_Name6")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName6;
    @XmlElement(name = "SubCategory_Name7")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName7;
    @XmlElement(name = "SubCategory_Name8")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName8;
    @XmlElement(name = "SubCategory_Name9")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName9;
    @XmlElement(name = "SubCategory_Name10")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String subCategoryName10;
    @XmlElement(name = "View_Only")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String viewOnly;
    @XmlElement(name = "EDoc_Indicator")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String eDocIndicator;
    @XmlElement(name = "Always_Route_Indicator")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String alwaysRouteIndicator;
    @XmlElement(name = "Always_Keep_Indicator")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String alwaysKeepIndicator;
    @XmlElement(name = "Display_Order")
    protected Integer displayOrder;
    @XmlElement(name = "EDoc_URL")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String eDocURL;
    @XmlElement(name = "UNSPSC_Code")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String unspscCode;
    @XmlElement(name = "Approval_Quantity_Limit")
    protected Long approvalQuantityLimit;
    @XmlElement(name = "Invalid_Item_Indicator")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String invalidItemIndicator;
    @XmlElement(name = "CP_BUID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpbuid;
    @XmlElement(name = "Item_Description")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String itemDescription;
    @XmlElement(name = "Assigned_Approval_Queue")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String assignedApprovalQueue;
    @XmlElement(name = "Routing_Qty_For_Item_Approval")
    protected Integer routingQtyForItemApproval;
    @XmlElement(name = "Always_Route_For_Item_Approval")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String alwaysRouteForItemApproval;
    @XmlElement(name = "Alternate_Description")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String alternateDescription;
    @XmlElement(name = "Alternate_Description_Flag")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String alternateDescriptionFlag;
    @XmlElement(name = "Delivery_Option")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String deliveryOption;
    @XmlElement(name = "EFD_Source")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String efdSource;
    @XmlElement(name = "EFD_Settings")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String efdSettings;
    @XmlElement(name = "EFD_Use_Default_Service_Charge")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String efdUseDefaultServiceCharge;
    @XmlElement(name = "EFD_Service_Fee")
    protected Integer efdServiceFee;
    @XmlElement(name = "EFD_Transfer_Cost")
    protected Integer efdTransferCost;

    /**
     * Gets the value of the catalogName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCatalogName() {
        return catalogName;
    }

    /**
     * Sets the value of the catalogName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCatalogName(String value) {
        this.catalogName = value;
    }

    /**
     * Gets the value of the categoryName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * Sets the value of the categoryName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategoryName(String value) {
        this.categoryName = value;
    }

    /**
     * Gets the value of the subCategoryName1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName1() {
        return subCategoryName1;
    }

    /**
     * Sets the value of the subCategoryName1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName1(String value) {
        this.subCategoryName1 = value;
    }

    /**
     * Gets the value of the subCategoryName2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName2() {
        return subCategoryName2;
    }

    /**
     * Sets the value of the subCategoryName2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName2(String value) {
        this.subCategoryName2 = value;
    }

    /**
     * Gets the value of the subCategoryName3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName3() {
        return subCategoryName3;
    }

    /**
     * Sets the value of the subCategoryName3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName3(String value) {
        this.subCategoryName3 = value;
    }

    /**
     * Gets the value of the subCategoryName4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName4() {
        return subCategoryName4;
    }

    /**
     * Sets the value of the subCategoryName4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName4(String value) {
        this.subCategoryName4 = value;
    }

    /**
     * Gets the value of the subCategoryName5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName5() {
        return subCategoryName5;
    }

    /**
     * Sets the value of the subCategoryName5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName5(String value) {
        this.subCategoryName5 = value;
    }

    /**
     * Gets the value of the subCategoryName6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName6() {
        return subCategoryName6;
    }

    /**
     * Sets the value of the subCategoryName6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName6(String value) {
        this.subCategoryName6 = value;
    }

    /**
     * Gets the value of the subCategoryName7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName7() {
        return subCategoryName7;
    }

    /**
     * Sets the value of the subCategoryName7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName7(String value) {
        this.subCategoryName7 = value;
    }

    /**
     * Gets the value of the subCategoryName8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName8() {
        return subCategoryName8;
    }

    /**
     * Sets the value of the subCategoryName8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName8(String value) {
        this.subCategoryName8 = value;
    }

    /**
     * Gets the value of the subCategoryName9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName9() {
        return subCategoryName9;
    }

    /**
     * Sets the value of the subCategoryName9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName9(String value) {
        this.subCategoryName9 = value;
    }

    /**
     * Gets the value of the subCategoryName10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCategoryName10() {
        return subCategoryName10;
    }

    /**
     * Sets the value of the subCategoryName10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCategoryName10(String value) {
        this.subCategoryName10 = value;
    }

    /**
     * Gets the value of the viewOnly property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getViewOnly() {
        return viewOnly;
    }

    /**
     * Sets the value of the viewOnly property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setViewOnly(String value) {
        this.viewOnly = value;
    }

    /**
     * Gets the value of the eDocIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEDocIndicator() {
        return eDocIndicator;
    }

    /**
     * Sets the value of the eDocIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEDocIndicator(String value) {
        this.eDocIndicator = value;
    }

    /**
     * Gets the value of the alwaysRouteIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlwaysRouteIndicator() {
        return alwaysRouteIndicator;
    }

    /**
     * Sets the value of the alwaysRouteIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlwaysRouteIndicator(String value) {
        this.alwaysRouteIndicator = value;
    }

    /**
     * Gets the value of the alwaysKeepIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlwaysKeepIndicator() {
        return alwaysKeepIndicator;
    }

    /**
     * Sets the value of the alwaysKeepIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlwaysKeepIndicator(String value) {
        this.alwaysKeepIndicator = value;
    }

    /**
     * Gets the value of the displayOrder property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDisplayOrder() {
        return displayOrder;
    }

    /**
     * Sets the value of the displayOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDisplayOrder(Integer value) {
        this.displayOrder = value;
    }

    /**
     * Gets the value of the eDocURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEDocURL() {
        return eDocURL;
    }

    /**
     * Sets the value of the eDocURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEDocURL(String value) {
        this.eDocURL = value;
    }

    /**
     * Gets the value of the unspscCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUNSPSCCode() {
        return unspscCode;
    }

    /**
     * Sets the value of the unspscCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUNSPSCCode(String value) {
        this.unspscCode = value;
    }

    /**
     * Gets the value of the approvalQuantityLimit property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getApprovalQuantityLimit() {
        return approvalQuantityLimit;
    }

    /**
     * Sets the value of the approvalQuantityLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setApprovalQuantityLimit(Long value) {
        this.approvalQuantityLimit = value;
    }

    /**
     * Gets the value of the invalidItemIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvalidItemIndicator() {
        return invalidItemIndicator;
    }

    /**
     * Sets the value of the invalidItemIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvalidItemIndicator(String value) {
        this.invalidItemIndicator = value;
    }

    /**
     * Gets the value of the cpbuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPBUID() {
        return cpbuid;
    }

    /**
     * Sets the value of the cpbuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPBUID(String value) {
        this.cpbuid = value;
    }

    /**
     * Gets the value of the itemDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemDescription() {
        return itemDescription;
    }

    /**
     * Sets the value of the itemDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemDescription(String value) {
        this.itemDescription = value;
    }

    /**
     * Gets the value of the assignedApprovalQueue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedApprovalQueue() {
        return assignedApprovalQueue;
    }

    /**
     * Sets the value of the assignedApprovalQueue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedApprovalQueue(String value) {
        this.assignedApprovalQueue = value;
    }

    /**
     * Gets the value of the routingQtyForItemApproval property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRoutingQtyForItemApproval() {
        return routingQtyForItemApproval;
    }

    /**
     * Sets the value of the routingQtyForItemApproval property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRoutingQtyForItemApproval(Integer value) {
        this.routingQtyForItemApproval = value;
    }

    /**
     * Gets the value of the alwaysRouteForItemApproval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlwaysRouteForItemApproval() {
        return alwaysRouteForItemApproval;
    }

    /**
     * Sets the value of the alwaysRouteForItemApproval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlwaysRouteForItemApproval(String value) {
        this.alwaysRouteForItemApproval = value;
    }

    /**
     * Gets the value of the alternateDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternateDescription() {
        return alternateDescription;
    }

    /**
     * Sets the value of the alternateDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternateDescription(String value) {
        this.alternateDescription = value;
    }

    /**
     * Gets the value of the alternateDescriptionFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternateDescriptionFlag() {
        return alternateDescriptionFlag;
    }

    /**
     * Sets the value of the alternateDescriptionFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternateDescriptionFlag(String value) {
        this.alternateDescriptionFlag = value;
    }

    /**
     * Gets the value of the deliveryOption property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryOption() {
        return deliveryOption;
    }

    /**
     * Sets the value of the deliveryOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryOption(String value) {
        this.deliveryOption = value;
    }

    /**
     * Gets the value of the efdSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEFDSource() {
        return efdSource;
    }

    /**
     * Sets the value of the efdSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEFDSource(String value) {
        this.efdSource = value;
    }

    /**
     * Gets the value of the efdSettings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEFDSettings() {
        return efdSettings;
    }

    /**
     * Sets the value of the efdSettings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEFDSettings(String value) {
        this.efdSettings = value;
    }

    /**
     * Gets the value of the efdUseDefaultServiceCharge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEFDUseDefaultServiceCharge() {
        return efdUseDefaultServiceCharge;
    }

    /**
     * Sets the value of the efdUseDefaultServiceCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEFDUseDefaultServiceCharge(String value) {
        this.efdUseDefaultServiceCharge = value;
    }

    /**
     * Gets the value of the efdServiceFee property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEFDServiceFee() {
        return efdServiceFee;
    }

    /**
     * Sets the value of the efdServiceFee property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEFDServiceFee(Integer value) {
        this.efdServiceFee = value;
    }

    /**
     * Gets the value of the efdTransferCost property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEFDTransferCost() {
        return efdTransferCost;
    }

    /**
     * Sets the value of the efdTransferCost property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEFDTransferCost(Integer value) {
        this.efdTransferCost = value;
    }

}
