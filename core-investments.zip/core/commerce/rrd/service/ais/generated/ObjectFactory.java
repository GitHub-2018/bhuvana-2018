
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TypeAssetStatus }
     * 
     */
    public TypeAssetStatus createTypeAssetStatus() {
        return new TypeAssetStatus();
    }

    /**
     * Create an instance of {@link TypeCustomPointItemAssociation }
     * 
     */
    public TypeCustomPointItemAssociation createTypeCustomPointItemAssociation() {
        return new TypeCustomPointItemAssociation();
    }

    /**
     * Create an instance of {@link TypeCustomPointCatalog }
     * 
     */
    public TypeCustomPointCatalog createTypeCustomPointCatalog() {
        return new TypeCustomPointCatalog();
    }

    /**
     * Create an instance of {@link TypeJobRef }
     * 
     */
    public TypeJobRef createTypeJobRef() {
        return new TypeJobRef();
    }

    /**
     * Create an instance of {@link TypeCustomPointManagedItem }
     * 
     */
    public TypeCustomPointManagedItem createTypeCustomPointManagedItem() {
        return new TypeCustomPointManagedItem();
    }

    /**
     * Create an instance of {@link TypeGeneralResponse }
     * 
     */
    public TypeGeneralResponse createTypeGeneralResponse() {
        return new TypeGeneralResponse();
    }

    /**
     * Create an instance of {@link TypeDataNameValuePair }
     * 
     */
    public TypeDataNameValuePair createTypeDataNameValuePair() {
        return new TypeDataNameValuePair();
    }

    /**
     * Create an instance of {@link TypeItemRef }
     * 
     */
    public TypeItemRef createTypeItemRef() {
        return new TypeItemRef();
    }

    /**
     * Create an instance of {@link TypeECreate }
     * 
     */
    public TypeECreate createTypeECreate() {
        return new TypeECreate();
    }

    /**
     * Create an instance of {@link TypePageException }
     * 
     */
    public TypePageException createTypePageException() {
        return new TypePageException();
    }

    /**
     * Create an instance of {@link TypeECreateAttributes }
     * 
     */
    public TypeECreateAttributes createTypeECreateAttributes() {
        return new TypeECreateAttributes();
    }

    /**
     * Create an instance of {@link TypeKitComponent }
     * 
     */
    public TypeKitComponent createTypeKitComponent() {
        return new TypeKitComponent();
    }

    /**
     * Create an instance of {@link TypeCustomPointAttributeValue }
     * 
     */
    public TypeCustomPointAttributeValue createTypeCustomPointAttributeValue() {
        return new TypeCustomPointAttributeValue();
    }

    /**
     * Create an instance of {@link TypeCDI }
     * 
     */
    public TypeCDI createTypeCDI() {
        return new TypeCDI();
    }

    /**
     * Create an instance of {@link TypeCustomPoint }
     * 
     */
    public TypeCustomPoint createTypeCustomPoint() {
        return new TypeCustomPoint();
    }

    /**
     * Create an instance of {@link TypeAssetSummary }
     * 
     */
    public TypeAssetSummary createTypeAssetSummary() {
        return new TypeAssetSummary();
    }

    /**
     * Create an instance of {@link TypeAssetStatus.OtherData }
     * 
     */
    public TypeAssetStatus.OtherData createTypeAssetStatusOtherData() {
        return new TypeAssetStatus.OtherData();
    }

}
