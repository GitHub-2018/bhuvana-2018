
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TypeAssetSummary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeAssetSummary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EnclosedAssetType" type="{}TypeAssetType"/>
 *         &lt;element name="EnclosedAssets">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}short">
 *               &lt;maxInclusive value="1000"/>
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Customer_ID">
 *           &lt;simpleType>
 *             &lt;restriction base="{}TypeProfileID">
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeAssetSummary", propOrder = {
    "enclosedAssetType",
    "enclosedAssets",
    "customerID"
})
public class TypeAssetSummary {

    @XmlElement(name = "EnclosedAssetType", required = true)
    @XmlSchemaType(name = "token")
    protected TypeAssetType enclosedAssetType;
    @XmlElement(name = "EnclosedAssets")
    protected short enclosedAssets;
    @XmlElement(name = "Customer_ID")
    protected int customerID;

    /**
     * Gets the value of the enclosedAssetType property.
     * 
     * @return
     *     possible object is
     *     {@link TypeAssetType }
     *     
     */
    public TypeAssetType getEnclosedAssetType() {
        return enclosedAssetType;
    }

    /**
     * Sets the value of the enclosedAssetType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeAssetType }
     *     
     */
    public void setEnclosedAssetType(TypeAssetType value) {
        this.enclosedAssetType = value;
    }

    /**
     * Gets the value of the enclosedAssets property.
     * 
     */
    public short getEnclosedAssets() {
        return enclosedAssets;
    }

    /**
     * Sets the value of the enclosedAssets property.
     * 
     */
    public void setEnclosedAssets(short value) {
        this.enclosedAssets = value;
    }

    /**
     * Gets the value of the customerID property.
     * 
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * Sets the value of the customerID property.
     * 
     */
    public void setCustomerID(int value) {
        this.customerID = value;
    }

}
