
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypeKitComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeKitComponent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;sequence>
 *           &lt;element name="CUST_ITEM_NUM" type="{}TypeCustItemNum" minOccurs="0"/>
 *           &lt;element name="WCSS_ITEM_NUM" type="{}TypeWcssItemNum" minOccurs="0"/>
 *         &lt;/sequence>
 *         &lt;element name="Item_Message" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="255"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CMPNT_ITEM_CT" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="CMP_CRIT_IN" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;enumeration value="Critical"/>
 *               &lt;enumeration value="Non-Critical / Cancel Line"/>
 *               &lt;enumeration value="Ship Later / Backorder"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CMP_PLACE_TX" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CMP_SEQ_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="DROP_SHIP_NOT_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="TOUCH_FCT_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;fractionDigits value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="TOUCH_CHG_AM" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;fractionDigits value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="TOUCH_TRANSFER_COST_AM" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;fractionDigits value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SHELL_STOCK_IN" type="{}TypeYesNo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeKitComponent", propOrder = {
    "custitemnum",
    "wcssitemnum",
    "itemMessage",
    "cmpntitemct",
    "cmpcritin",
    "cmpplacetx",
    "cmpseqnr",
    "dropshipnotin",
    "touchfctnr",
    "touchchgam",
    "touchtransfercostam",
    "shellstockin"
})
public class TypeKitComponent {

    @XmlElement(name = "CUST_ITEM_NUM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String custitemnum;
    @XmlElement(name = "WCSS_ITEM_NUM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssitemnum;
    @XmlElement(name = "Item_Message")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String itemMessage;
    @XmlElement(name = "CMPNT_ITEM_CT")
    protected BigInteger cmpntitemct;
    @XmlElement(name = "CMP_CRIT_IN")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cmpcritin;
    @XmlElement(name = "CMP_PLACE_TX")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cmpplacetx;
    @XmlElement(name = "CMP_SEQ_NR")
    protected Integer cmpseqnr;
    @XmlElement(name = "DROP_SHIP_NOT_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo dropshipnotin;
    @XmlElement(name = "TOUCH_FCT_NR")
    protected BigDecimal touchfctnr;
    @XmlElement(name = "TOUCH_CHG_AM")
    protected BigDecimal touchchgam;
    @XmlElement(name = "TOUCH_TRANSFER_COST_AM")
    protected BigDecimal touchtransfercostam;
    @XmlElement(name = "SHELL_STOCK_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo shellstockin;

    /**
     * Gets the value of the custitemnum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTITEMNUM() {
        return custitemnum;
    }

    /**
     * Sets the value of the custitemnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTITEMNUM(String value) {
        this.custitemnum = value;
    }

    /**
     * Gets the value of the wcssitemnum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSITEMNUM() {
        return wcssitemnum;
    }

    /**
     * Sets the value of the wcssitemnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSITEMNUM(String value) {
        this.wcssitemnum = value;
    }

    /**
     * Gets the value of the itemMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemMessage() {
        return itemMessage;
    }

    /**
     * Sets the value of the itemMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemMessage(String value) {
        this.itemMessage = value;
    }

    /**
     * Gets the value of the cmpntitemct property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCMPNTITEMCT() {
        return cmpntitemct;
    }

    /**
     * Sets the value of the cmpntitemct property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCMPNTITEMCT(BigInteger value) {
        this.cmpntitemct = value;
    }

    /**
     * Gets the value of the cmpcritin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCMPCRITIN() {
        return cmpcritin;
    }

    /**
     * Sets the value of the cmpcritin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCMPCRITIN(String value) {
        this.cmpcritin = value;
    }

    /**
     * Gets the value of the cmpplacetx property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCMPPLACETX() {
        return cmpplacetx;
    }

    /**
     * Sets the value of the cmpplacetx property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCMPPLACETX(String value) {
        this.cmpplacetx = value;
    }

    /**
     * Gets the value of the cmpseqnr property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCMPSEQNR() {
        return cmpseqnr;
    }

    /**
     * Sets the value of the cmpseqnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCMPSEQNR(Integer value) {
        this.cmpseqnr = value;
    }

    /**
     * Gets the value of the dropshipnotin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getDROPSHIPNOTIN() {
        return dropshipnotin;
    }

    /**
     * Sets the value of the dropshipnotin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setDROPSHIPNOTIN(TypeYesNo value) {
        this.dropshipnotin = value;
    }

    /**
     * Gets the value of the touchfctnr property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTOUCHFCTNR() {
        return touchfctnr;
    }

    /**
     * Sets the value of the touchfctnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTOUCHFCTNR(BigDecimal value) {
        this.touchfctnr = value;
    }

    /**
     * Gets the value of the touchchgam property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTOUCHCHGAM() {
        return touchchgam;
    }

    /**
     * Sets the value of the touchchgam property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTOUCHCHGAM(BigDecimal value) {
        this.touchchgam = value;
    }

    /**
     * Gets the value of the touchtransfercostam property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTOUCHTRANSFERCOSTAM() {
        return touchtransfercostam;
    }

    /**
     * Sets the value of the touchtransfercostam property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTOUCHTRANSFERCOSTAM(BigDecimal value) {
        this.touchtransfercostam = value;
    }

    /**
     * Gets the value of the shellstockin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getSHELLSTOCKIN() {
        return shellstockin;
    }

    /**
     * Sets the value of the shellstockin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setSHELLSTOCKIN(TypeYesNo value) {
        this.shellstockin = value;
    }

}
