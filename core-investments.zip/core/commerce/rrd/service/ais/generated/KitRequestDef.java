
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for KitRequestDef complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="KitRequestDef">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Cust_Item_Num" type="{}TypeCustItemNum"/>
 *         &lt;element name="RequestType" type="{}TypeRequestType"/>
 *         &lt;element name="CreatedBy">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Submission_Name">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Customer_UID" type="{}TypeCustomerUID" minOccurs="0"/>
 *         &lt;element name="WCSS_Item_Num" type="{}TypeWcssItemNum" minOccurs="0"/>
 *         &lt;element name="WCSS_Item_Descr" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="40"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_WORK_TYPE_CD" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_WORK_TYPE_CD_DM" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_KIT_ASMBLY_REQD_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_CONTRACT_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="7"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_JI_TYPE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="5"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ORD_DFLT_DT" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Split_Shipment" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="CIN_For_Thumbnail" type="{}TypeCustItemNum" minOccurs="0"/>
 *         &lt;element name="Allow_CustomPoint_Skip" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="VERSION_DS" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="VERSION_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="5"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="VERSION_EFF_DT" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="VERSION_EXP_DT" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="STATUS_CD" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;enumeration value="Active"/>
 *               &lt;enumeration value="Pending"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="STATUS_CD_Previous" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;enumeration value="Inactive"/>
 *               &lt;enumeration value="Active"/>
 *               &lt;enumeration value="No change"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="OMS_Descr" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="120"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="TOUCH_SVC_REF_ITEM_NR" type="{}TypeWcssItemNum" minOccurs="0"/>
 *         &lt;element name="TOUCH_PLANT_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="TOUCH_JOB_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="5"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="TOUCH_JOB_COMBO_NR" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="Replenishing_Plant" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ItemRef" type="{}TypeItemRef" maxOccurs="30" minOccurs="0"/>
 *         &lt;element name="CustomPoint" type="{}TypeCustomPoint" minOccurs="0"/>
 *         &lt;element name="Kit_Component" type="{}TypeKitComponent" maxOccurs="100"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "KitRequestDef", propOrder = {
    "custItemNum",
    "requestType",
    "createdBy",
    "submissionName",
    "customerUID",
    "wcssItemNum",
    "wcssItemDescr",
    "wcssworktypecd",
    "wcssworktypecddm",
    "wcsskitasmblyreqdin",
    "wcsscontractnr",
    "wcssjitype",
    "orddfltdt",
    "splitShipment",
    "cinForThumbnail",
    "allowCustomPointSkip",
    "versionds",
    "versionnr",
    "versioneffdt",
    "versionexpdt",
    "statuscd",
    "statuscdPrevious",
    "omsDescr",
    "touchsvcrefitemnr",
    "touchplantnr",
    "touchjobnr",
    "touchjobcombonr",
    "replenishingPlant",
    "itemRef",
    "customPoint",
    "kitComponent"
})
public class KitRequestDef {

    @XmlElement(name = "Cust_Item_Num", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String custItemNum;
    @XmlElement(name = "RequestType", required = true)
    @XmlSchemaType(name = "token")
    protected TypeRequestType requestType;
    @XmlElement(name = "CreatedBy", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String createdBy;
    @XmlElement(name = "Submission_Name", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String submissionName;
    @XmlElement(name = "Customer_UID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String customerUID;
    @XmlElement(name = "WCSS_Item_Num")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssItemNum;
    @XmlElement(name = "WCSS_Item_Descr")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssItemDescr;
    @XmlElement(name = "WCSS_WORK_TYPE_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssworktypecd;
    @XmlElement(name = "WCSS_WORK_TYPE_CD_DM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssworktypecddm;
    @XmlElement(name = "WCSS_KIT_ASMBLY_REQD_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcsskitasmblyreqdin;
    @XmlElement(name = "WCSS_CONTRACT_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcsscontractnr;
    @XmlElement(name = "WCSS_JI_TYPE")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssjitype;
    @XmlElement(name = "ORD_DFLT_DT")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar orddfltdt;
    @XmlElement(name = "Split_Shipment")
    @XmlSchemaType(name = "token")
    protected TypeYesNo splitShipment;
    @XmlElement(name = "CIN_For_Thumbnail")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String cinForThumbnail;
    @XmlElement(name = "Allow_CustomPoint_Skip")
    protected Boolean allowCustomPointSkip;
    @XmlElement(name = "VERSION_DS")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String versionds;
    @XmlElement(name = "VERSION_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String versionnr;
    @XmlElement(name = "VERSION_EFF_DT")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar versioneffdt;
    @XmlElement(name = "VERSION_EXP_DT")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar versionexpdt;
    @XmlElement(name = "STATUS_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String statuscd;
    @XmlElement(name = "STATUS_CD_Previous")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String statuscdPrevious;
    @XmlElement(name = "OMS_Descr")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String omsDescr;
    @XmlElement(name = "TOUCH_SVC_REF_ITEM_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String touchsvcrefitemnr;
    @XmlElement(name = "TOUCH_PLANT_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String touchplantnr;
    @XmlElement(name = "TOUCH_JOB_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String touchjobnr;
    @XmlElement(name = "TOUCH_JOB_COMBO_NR")
    protected BigInteger touchjobcombonr;
    @XmlElement(name = "Replenishing_Plant")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String replenishingPlant;
    @XmlElement(name = "ItemRef")
    protected List<TypeItemRef> itemRef;
    @XmlElement(name = "CustomPoint")
    protected TypeCustomPoint customPoint;
    @XmlElement(name = "Kit_Component", required = true)
    protected List<TypeKitComponent> kitComponent;

    /**
     * Gets the value of the custItemNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustItemNum() {
        return custItemNum;
    }

    /**
     * Sets the value of the custItemNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustItemNum(String value) {
        this.custItemNum = value;
    }

    /**
     * Gets the value of the requestType property.
     * 
     * @return
     *     possible object is
     *     {@link TypeRequestType }
     *     
     */
    public TypeRequestType getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeRequestType }
     *     
     */
    public void setRequestType(TypeRequestType value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the submissionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubmissionName() {
        return submissionName;
    }

    /**
     * Sets the value of the submissionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubmissionName(String value) {
        this.submissionName = value;
    }

    /**
     * Gets the value of the customerUID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerUID() {
        return customerUID;
    }

    /**
     * Sets the value of the customerUID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerUID(String value) {
        this.customerUID = value;
    }

    /**
     * Gets the value of the wcssItemNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSItemNum() {
        return wcssItemNum;
    }

    /**
     * Sets the value of the wcssItemNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSItemNum(String value) {
        this.wcssItemNum = value;
    }

    /**
     * Gets the value of the wcssItemDescr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSItemDescr() {
        return wcssItemDescr;
    }

    /**
     * Sets the value of the wcssItemDescr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSItemDescr(String value) {
        this.wcssItemDescr = value;
    }

    /**
     * Gets the value of the wcssworktypecd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSWORKTYPECD() {
        return wcssworktypecd;
    }

    /**
     * Sets the value of the wcssworktypecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSWORKTYPECD(String value) {
        this.wcssworktypecd = value;
    }

    /**
     * Gets the value of the wcssworktypecddm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSWORKTYPECDDM() {
        return wcssworktypecddm;
    }

    /**
     * Sets the value of the wcssworktypecddm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSWORKTYPECDDM(String value) {
        this.wcssworktypecddm = value;
    }

    /**
     * Gets the value of the wcsskitasmblyreqdin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSKITASMBLYREQDIN() {
        return wcsskitasmblyreqdin;
    }

    /**
     * Sets the value of the wcsskitasmblyreqdin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSKITASMBLYREQDIN(TypeYesNo value) {
        this.wcsskitasmblyreqdin = value;
    }

    /**
     * Gets the value of the wcsscontractnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSCONTRACTNR() {
        return wcsscontractnr;
    }

    /**
     * Sets the value of the wcsscontractnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSCONTRACTNR(String value) {
        this.wcsscontractnr = value;
    }

    /**
     * Gets the value of the wcssjitype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSJITYPE() {
        return wcssjitype;
    }

    /**
     * Sets the value of the wcssjitype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSJITYPE(String value) {
        this.wcssjitype = value;
    }

    /**
     * Gets the value of the orddfltdt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getORDDFLTDT() {
        return orddfltdt;
    }

    /**
     * Sets the value of the orddfltdt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setORDDFLTDT(XMLGregorianCalendar value) {
        this.orddfltdt = value;
    }

    /**
     * Gets the value of the splitShipment property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getSplitShipment() {
        return splitShipment;
    }

    /**
     * Sets the value of the splitShipment property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setSplitShipment(TypeYesNo value) {
        this.splitShipment = value;
    }

    /**
     * Gets the value of the cinForThumbnail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCINForThumbnail() {
        return cinForThumbnail;
    }

    /**
     * Sets the value of the cinForThumbnail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCINForThumbnail(String value) {
        this.cinForThumbnail = value;
    }

    /**
     * Gets the value of the allowCustomPointSkip property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAllowCustomPointSkip() {
        return allowCustomPointSkip;
    }

    /**
     * Sets the value of the allowCustomPointSkip property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAllowCustomPointSkip(Boolean value) {
        this.allowCustomPointSkip = value;
    }

    /**
     * Gets the value of the versionds property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVERSIONDS() {
        return versionds;
    }

    /**
     * Sets the value of the versionds property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVERSIONDS(String value) {
        this.versionds = value;
    }

    /**
     * Gets the value of the versionnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVERSIONNR() {
        return versionnr;
    }

    /**
     * Sets the value of the versionnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVERSIONNR(String value) {
        this.versionnr = value;
    }

    /**
     * Gets the value of the versioneffdt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getVERSIONEFFDT() {
        return versioneffdt;
    }

    /**
     * Sets the value of the versioneffdt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setVERSIONEFFDT(XMLGregorianCalendar value) {
        this.versioneffdt = value;
    }

    /**
     * Gets the value of the versionexpdt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getVERSIONEXPDT() {
        return versionexpdt;
    }

    /**
     * Sets the value of the versionexpdt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setVERSIONEXPDT(XMLGregorianCalendar value) {
        this.versionexpdt = value;
    }

    /**
     * Gets the value of the statuscd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATUSCD() {
        return statuscd;
    }

    /**
     * Sets the value of the statuscd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATUSCD(String value) {
        this.statuscd = value;
    }

    /**
     * Gets the value of the statuscdPrevious property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATUSCDPrevious() {
        return statuscdPrevious;
    }

    /**
     * Sets the value of the statuscdPrevious property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATUSCDPrevious(String value) {
        this.statuscdPrevious = value;
    }

    /**
     * Gets the value of the omsDescr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOMSDescr() {
        return omsDescr;
    }

    /**
     * Sets the value of the omsDescr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOMSDescr(String value) {
        this.omsDescr = value;
    }

    /**
     * Gets the value of the touchsvcrefitemnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOUCHSVCREFITEMNR() {
        return touchsvcrefitemnr;
    }

    /**
     * Sets the value of the touchsvcrefitemnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOUCHSVCREFITEMNR(String value) {
        this.touchsvcrefitemnr = value;
    }

    /**
     * Gets the value of the touchplantnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOUCHPLANTNR() {
        return touchplantnr;
    }

    /**
     * Sets the value of the touchplantnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOUCHPLANTNR(String value) {
        this.touchplantnr = value;
    }

    /**
     * Gets the value of the touchjobnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOUCHJOBNR() {
        return touchjobnr;
    }

    /**
     * Sets the value of the touchjobnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOUCHJOBNR(String value) {
        this.touchjobnr = value;
    }

    /**
     * Gets the value of the touchjobcombonr property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTOUCHJOBCOMBONR() {
        return touchjobcombonr;
    }

    /**
     * Sets the value of the touchjobcombonr property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTOUCHJOBCOMBONR(BigInteger value) {
        this.touchjobcombonr = value;
    }

    /**
     * Gets the value of the replenishingPlant property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReplenishingPlant() {
        return replenishingPlant;
    }

    /**
     * Sets the value of the replenishingPlant property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReplenishingPlant(String value) {
        this.replenishingPlant = value;
    }

    /**
     * Gets the value of the itemRef property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the itemRef property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getItemRef().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypeItemRef }
     * 
     * 
     */
    public List<TypeItemRef> getItemRef() {
        if (itemRef == null) {
            itemRef = new ArrayList<TypeItemRef>();
        }
        return this.itemRef;
    }

    /**
     * Gets the value of the customPoint property.
     * 
     * @return
     *     possible object is
     *     {@link TypeCustomPoint }
     *     
     */
    public TypeCustomPoint getCustomPoint() {
        return customPoint;
    }

    /**
     * Sets the value of the customPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeCustomPoint }
     *     
     */
    public void setCustomPoint(TypeCustomPoint value) {
        this.customPoint = value;
    }

    /**
     * Gets the value of the kitComponent property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the kitComponent property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKitComponent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypeKitComponent }
     * 
     * 
     */
    public List<TypeKitComponent> getKitComponent() {
        if (kitComponent == null) {
            kitComponent = new ArrayList<TypeKitComponent>();
        }
        return this.kitComponent;
    }

}
