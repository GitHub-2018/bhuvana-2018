
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypeJobRef complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeJobRef">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Job_Ref_Name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Job_Ref_Value">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeJobRef", propOrder = {
    "jobRefName",
    "jobRefValue"
})
public class TypeJobRef {

    @XmlElement(name = "Job_Ref_Name", required = true)
    protected String jobRefName;
    @XmlElement(name = "Job_Ref_Value", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String jobRefValue;

    /**
     * Gets the value of the jobRefName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobRefName() {
        return jobRefName;
    }

    /**
     * Sets the value of the jobRefName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobRefName(String value) {
        this.jobRefName = value;
    }

    /**
     * Gets the value of the jobRefValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobRefValue() {
        return jobRefValue;
    }

    /**
     * Sets the value of the jobRefValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobRefValue(String value) {
        this.jobRefValue = value;
    }

}
