
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TypeLoadType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TypeLoadType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *     &lt;enumeration value="Production"/>
 *     &lt;enumeration value="PreAnalysis"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TypeLoadType")
@XmlEnum
public enum TypeLoadType {

    @XmlEnumValue("Production")
    PRODUCTION("Production"),
    @XmlEnumValue("PreAnalysis")
    PRE_ANALYSIS("PreAnalysis");
    private final String value;

    TypeLoadType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TypeLoadType fromValue(String v) {
        for (TypeLoadType c: TypeLoadType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
