
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypeCustomPointItemAssociation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeCustomPointItemAssociation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Custom_Document_Project_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Template_User_Interface_UI_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeCustomPointItemAssociation", propOrder = {
    "customDocumentProjectName",
    "templateUserInterfaceUIName"
})
public class TypeCustomPointItemAssociation {

    @XmlElement(name = "Custom_Document_Project_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String customDocumentProjectName;
    @XmlElement(name = "Template_User_Interface_UI_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String templateUserInterfaceUIName;

    /**
     * Gets the value of the customDocumentProjectName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomDocumentProjectName() {
        return customDocumentProjectName;
    }

    /**
     * Sets the value of the customDocumentProjectName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomDocumentProjectName(String value) {
        this.customDocumentProjectName = value;
    }

    /**
     * Gets the value of the templateUserInterfaceUIName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateUserInterfaceUIName() {
        return templateUserInterfaceUIName;
    }

    /**
     * Sets the value of the templateUserInterfaceUIName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateUserInterfaceUIName(String value) {
        this.templateUserInterfaceUIName = value;
    }

}
