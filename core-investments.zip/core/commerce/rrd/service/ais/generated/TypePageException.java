
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypePageException complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypePageException">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Component_Name">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Orientation">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;enumeration value="LANDSCAPE"/>
 *               &lt;enumeration value="PORTRAIT"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Sides_Printed">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;enumeration value="HEAD2HEAD"/>
 *               &lt;enumeration value="HEAD2TOE"/>
 *               &lt;enumeration value="SIMPLEX"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Ink_Colors">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;enumeration value="DIGB&amp;W"/>
 *               &lt;enumeration value="DIGCOLOR"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Paper_Stock_Type">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Paper_Stock_Weight">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Paper_Stock_Color">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Locations" type="{http://www.w3.org/2001/XMLSchema}token"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypePageException", propOrder = {
    "componentName",
    "orientation",
    "sidesPrinted",
    "inkColors",
    "paperStockType",
    "paperStockWeight",
    "paperStockColor",
    "locations"
})
public class TypePageException {

    @XmlElement(name = "Component_Name", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String componentName;
    @XmlElement(name = "Orientation", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String orientation;
    @XmlElement(name = "Sides_Printed", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String sidesPrinted;
    @XmlElement(name = "Ink_Colors", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String inkColors;
    @XmlElement(name = "Paper_Stock_Type", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String paperStockType;
    @XmlElement(name = "Paper_Stock_Weight", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String paperStockWeight;
    @XmlElement(name = "Paper_Stock_Color", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String paperStockColor;
    @XmlElement(name = "Locations", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String locations;

    /**
     * Gets the value of the componentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComponentName() {
        return componentName;
    }

    /**
     * Sets the value of the componentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComponentName(String value) {
        this.componentName = value;
    }

    /**
     * Gets the value of the orientation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrientation() {
        return orientation;
    }

    /**
     * Sets the value of the orientation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrientation(String value) {
        this.orientation = value;
    }

    /**
     * Gets the value of the sidesPrinted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSidesPrinted() {
        return sidesPrinted;
    }

    /**
     * Sets the value of the sidesPrinted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSidesPrinted(String value) {
        this.sidesPrinted = value;
    }

    /**
     * Gets the value of the inkColors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInkColors() {
        return inkColors;
    }

    /**
     * Sets the value of the inkColors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInkColors(String value) {
        this.inkColors = value;
    }

    /**
     * Gets the value of the paperStockType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperStockType() {
        return paperStockType;
    }

    /**
     * Sets the value of the paperStockType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperStockType(String value) {
        this.paperStockType = value;
    }

    /**
     * Gets the value of the paperStockWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperStockWeight() {
        return paperStockWeight;
    }

    /**
     * Sets the value of the paperStockWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperStockWeight(String value) {
        this.paperStockWeight = value;
    }

    /**
     * Gets the value of the paperStockColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperStockColor() {
        return paperStockColor;
    }

    /**
     * Sets the value of the paperStockColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperStockColor(String value) {
        this.paperStockColor = value;
    }

    /**
     * Gets the value of the locations property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocations() {
        return locations;
    }

    /**
     * Sets the value of the locations property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocations(String value) {
        this.locations = value;
    }

}
