
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TypeCustomPointManagedItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeCustomPointManagedItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Item_Description">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="255"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Item_Classification" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Item_Type" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Item_Sub_Type" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Include_In_Reports" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Department" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Division" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Primary_Vendor" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Secondary_Vendor" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Job_Type" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="25"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Revision_Number" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Revision_Date" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Product_Code" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="7"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Contract_Number" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="7"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_FOB_Point" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="11"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Logo_ID" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="25"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Cancellation_Date" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Cancellation_Reason" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Replacement_Item_Number" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Disposition_Of_Stock" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Quantity_UOM" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Quantity_UOM_Factor" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Reorder_Point" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Reorder_Quantity" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Estimated_Annual_Usage_Quantity" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Multiple_Above_Minimum" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Price" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="5"/>
 *               &lt;fractionDigits value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Pricing_UOM" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Pricing_UOM_Factor" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Default_Chargeback_Department" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Number_Of_Locations" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Manufacturing_Lead_Time" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Release_From_Stock_Lead_Time" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Number_Of_Printings" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Months_Per_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Shipments_Per_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Packaging_Method_Description" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="25"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Special_Packing_Instructions" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Primary_Per_Package_Quantity" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Primary_Per_Carton_Or_Roll_Quantity" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Primary_Package_Labeling_Description" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Designer_Source_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Designer_Media" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Photographer_Source_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Photographer_Method" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Photographer_Media" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Typeset_Source_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Typeset_Method" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Typeset_Media" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_EDoc_Location_URL" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="255"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Cost_Center" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Previous_Price" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="5"/>
 *               &lt;fractionDigits value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Previous_Pricing_UOM" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Previous_Pricing_UOM_Factor" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Orderable" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Reason_Not_Orderable" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="60"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Container" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Container_Type" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="3"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Activation_Date" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Expiration_Date" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Ship_Date" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Secondary_Per_Package_Quantity" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Secondary_Per_Carton_Or_Roll_Quantity" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Secondary_Package_Labeling_Description" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Disaster_Recovery" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Critical_Item" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Legal_Review_Required" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Foreign_Language" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Imprinting" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Camera_Ready_Copy" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Form_Design_Complete" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Intelligent_Item" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Provide_Remote_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Negotiable_Item" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Process_Color_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Remoist_Glue" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Computer_Aided_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Optical_Scanned_Item" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Tipped_On_ID_Card" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Trimmed_Stub" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Sheet_Fed_Pricing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Sense_Timing_Repeat_Mark" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Not_A_Printed_Item" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_External_Publication" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Internal_Publication" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Digital_Color_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Digital_BW_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_International_Sizes" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Contains_Pricing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Web_Printing" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Customer_Confidential" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Sheeted_Single" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Variable_Imaging" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Customer_Contact_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Customer_Contact_Email" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Customer_Contact_Phone" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="80"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Vendor_Contact_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Vendor_Contact_Email" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Vendor_Contact_Phone" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="80"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Designer_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Designer_Email" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Designer_Phone" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="80"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Photographer_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Photographer_Email" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Photographer_Phone" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="80"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Typesetter_Contact_Name" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Typesetter_Contact_Email" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Typesetter_Contact_Phone" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="80"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Item_Width" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="5"/>
 *               &lt;fractionDigits value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Item_Height" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}decimal">
 *               &lt;totalDigits value="5"/>
 *               &lt;fractionDigits value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Item_Coordinator_Login" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="16"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Non_Stock_Item_Orders" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Can_Be_A_Kit_Component" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Default_Touch_Factor" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Default_Sequence" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="2147483647"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Date_Not_Orderable" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="CPMI_Keyword1" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Keyword2" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Keyword3" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Keyword4" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Keyword5" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Keyword6" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Keyword7" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_Keyword8" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF1" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF2" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF3" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF4" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF5" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF6" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF7" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF8" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF9" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF10" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF11" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF12" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF13" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF14" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CPMI_UDF15" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeCustomPointManagedItem", propOrder = {
    "itemDescription",
    "cpmiItemClassification",
    "cpmiItemType",
    "cpmiItemSubType",
    "cpmiIncludeInReports",
    "cpmiDepartment",
    "cpmiDivision",
    "cpmiPrimaryVendor",
    "cpmiSecondaryVendor",
    "cpmiJobType",
    "cpmiRevisionNumber",
    "cpmiRevisionDate",
    "cpmiProductCode",
    "cpmiContractNumber",
    "cpmifobPoint",
    "cpmiLogoID",
    "cpmiCancellationDate",
    "cpmiCancellationReason",
    "cpmiReplacementItemNumber",
    "cpmiDispositionOfStock",
    "cpmiQuantityUOM",
    "cpmiQuantityUOMFactor",
    "cpmiReorderPoint",
    "cpmiReorderQuantity",
    "cpmiEstimatedAnnualUsageQuantity",
    "cpmiMultipleAboveMinimum",
    "cpmiPrice",
    "cpmiPricingUOM",
    "cpmiPricingUOMFactor",
    "cpmiDefaultChargebackDepartment",
    "cpmiNumberOfLocations",
    "cpmiManufacturingLeadTime",
    "cpmiReleaseFromStockLeadTime",
    "cpmiNumberOfPrintings",
    "cpmiMonthsPerPrinting",
    "cpmiShipmentsPerPrinting",
    "cpmiPackagingMethodDescription",
    "cpmiSpecialPackingInstructions",
    "cpmiPrimaryPerPackageQuantity",
    "cpmiPrimaryPerCartonOrRollQuantity",
    "cpmiPrimaryPackageLabelingDescription",
    "cpmiDesignerSourceName",
    "cpmiDesignerMedia",
    "cpmiPhotographerSourceName",
    "cpmiPhotographerMethod",
    "cpmiPhotographerMedia",
    "cpmiTypesetSourceName",
    "cpmiTypesetMethod",
    "cpmiTypesetMedia",
    "cpmieDocLocationURL",
    "cpmiCostCenter",
    "cpmiPreviousPrice",
    "cpmiPreviousPricingUOM",
    "cpmiPreviousPricingUOMFactor",
    "cpmiOrderable",
    "cpmiReasonNotOrderable",
    "cpmiContainer",
    "cpmiContainerType",
    "cpmiActivationDate",
    "cpmiExpirationDate",
    "cpmiShipDate",
    "cpmiSecondaryPerPackageQuantity",
    "cpmiSecondaryPerCartonOrRollQuantity",
    "cpmiSecondaryPackageLabelingDescription",
    "cpmiDisasterRecovery",
    "cpmiCriticalItem",
    "cpmiLegalReviewRequired",
    "cpmiForeignLanguage",
    "cpmiImprinting",
    "cpmiCameraReadyCopy",
    "cpmiFormDesignComplete",
    "cpmiIntelligentItem",
    "cpmiProvideRemotePrinting",
    "cpmiNegotiableItem",
    "cpmiProcessColorPrinting",
    "cpmiRemoistGlue",
    "cpmiComputerAidedPrinting",
    "cpmiOpticalScannedItem",
    "cpmiTippedOnIDCard",
    "cpmiTrimmedStub",
    "cpmiSheetFedPricing",
    "cpmiSenseTimingRepeatMark",
    "cpmiNotAPrintedItem",
    "cpmiExternalPublication",
    "cpmiInternalPublication",
    "cpmiDigitalColorPrinting",
    "cpmiDigitalBWPrinting",
    "cpmiInternationalSizes",
    "cpmiContainsPricing",
    "cpmiWebPrinting",
    "cpmiCustomerConfidential",
    "cpmiSheetedSingle",
    "cpmiVariableImaging",
    "cpmiCustomerContactName",
    "cpmiCustomerContactEmail",
    "cpmiCustomerContactPhone",
    "cpmiVendorContactName",
    "cpmiVendorContactEmail",
    "cpmiVendorContactPhone",
    "cpmiDesignerName",
    "cpmiDesignerEmail",
    "cpmiDesignerPhone",
    "cpmiPhotographerName",
    "cpmiPhotographerEmail",
    "cpmiPhotographerPhone",
    "cpmiTypesetterContactName",
    "cpmiTypesetterContactEmail",
    "cpmiTypesetterContactPhone",
    "cpmiItemWidth",
    "cpmiItemHeight",
    "cpmiItemCoordinatorLogin",
    "cpmiNonStockItemOrders",
    "cpmiCanBeAKitComponent",
    "cpmiDefaultTouchFactor",
    "cpmiDefaultSequence",
    "cpmiDateNotOrderable",
    "cpmiKeyword1",
    "cpmiKeyword2",
    "cpmiKeyword3",
    "cpmiKeyword4",
    "cpmiKeyword5",
    "cpmiKeyword6",
    "cpmiKeyword7",
    "cpmiKeyword8",
    "cpmiudf1",
    "cpmiudf2",
    "cpmiudf3",
    "cpmiudf4",
    "cpmiudf5",
    "cpmiudf6",
    "cpmiudf7",
    "cpmiudf8",
    "cpmiudf9",
    "cpmiudf10",
    "cpmiudf11",
    "cpmiudf12",
    "cpmiudf13",
    "cpmiudf14",
    "cpmiudf15"
})
public class TypeCustomPointManagedItem {

    @XmlElement(name = "Item_Description", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String itemDescription;
    @XmlElement(name = "CPMI_Item_Classification")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiItemClassification;
    @XmlElement(name = "CPMI_Item_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiItemType;
    @XmlElement(name = "CPMI_Item_Sub_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiItemSubType;
    @XmlElement(name = "CPMI_Include_In_Reports")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiIncludeInReports;
    @XmlElement(name = "CPMI_Department")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDepartment;
    @XmlElement(name = "CPMI_Division")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDivision;
    @XmlElement(name = "CPMI_Primary_Vendor")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPrimaryVendor;
    @XmlElement(name = "CPMI_Secondary_Vendor")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiSecondaryVendor;
    @XmlElement(name = "CPMI_Job_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiJobType;
    @XmlElement(name = "CPMI_Revision_Number")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiRevisionNumber;
    @XmlElement(name = "CPMI_Revision_Date")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiRevisionDate;
    @XmlElement(name = "CPMI_Product_Code")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiProductCode;
    @XmlElement(name = "CPMI_Contract_Number")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiContractNumber;
    @XmlElement(name = "CPMI_FOB_Point")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmifobPoint;
    @XmlElement(name = "CPMI_Logo_ID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiLogoID;
    @XmlElement(name = "CPMI_Cancellation_Date")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCancellationDate;
    @XmlElement(name = "CPMI_Cancellation_Reason")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCancellationReason;
    @XmlElement(name = "CPMI_Replacement_Item_Number")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiReplacementItemNumber;
    @XmlElement(name = "CPMI_Disposition_Of_Stock")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDispositionOfStock;
    @XmlElement(name = "CPMI_Quantity_UOM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiQuantityUOM;
    @XmlElement(name = "CPMI_Quantity_UOM_Factor")
    protected Integer cpmiQuantityUOMFactor;
    @XmlElement(name = "CPMI_Reorder_Point")
    protected Integer cpmiReorderPoint;
    @XmlElement(name = "CPMI_Reorder_Quantity")
    protected Integer cpmiReorderQuantity;
    @XmlElement(name = "CPMI_Estimated_Annual_Usage_Quantity")
    protected Integer cpmiEstimatedAnnualUsageQuantity;
    @XmlElement(name = "CPMI_Multiple_Above_Minimum")
    protected Integer cpmiMultipleAboveMinimum;
    @XmlElement(name = "CPMI_Price")
    protected BigDecimal cpmiPrice;
    @XmlElement(name = "CPMI_Pricing_UOM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPricingUOM;
    @XmlElement(name = "CPMI_Pricing_UOM_Factor")
    protected Integer cpmiPricingUOMFactor;
    @XmlElement(name = "CPMI_Default_Chargeback_Department")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDefaultChargebackDepartment;
    @XmlElement(name = "CPMI_Number_Of_Locations")
    protected Integer cpmiNumberOfLocations;
    @XmlElement(name = "CPMI_Manufacturing_Lead_Time")
    protected Integer cpmiManufacturingLeadTime;
    @XmlElement(name = "CPMI_Release_From_Stock_Lead_Time")
    protected Integer cpmiReleaseFromStockLeadTime;
    @XmlElement(name = "CPMI_Number_Of_Printings")
    protected Integer cpmiNumberOfPrintings;
    @XmlElement(name = "CPMI_Months_Per_Printing")
    protected Integer cpmiMonthsPerPrinting;
    @XmlElement(name = "CPMI_Shipments_Per_Printing")
    protected Integer cpmiShipmentsPerPrinting;
    @XmlElement(name = "CPMI_Packaging_Method_Description")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPackagingMethodDescription;
    @XmlElement(name = "CPMI_Special_Packing_Instructions")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiSpecialPackingInstructions;
    @XmlElement(name = "CPMI_Primary_Per_Package_Quantity")
    protected Integer cpmiPrimaryPerPackageQuantity;
    @XmlElement(name = "CPMI_Primary_Per_Carton_Or_Roll_Quantity")
    protected Integer cpmiPrimaryPerCartonOrRollQuantity;
    @XmlElement(name = "CPMI_Primary_Package_Labeling_Description")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPrimaryPackageLabelingDescription;
    @XmlElement(name = "CPMI_Designer_Source_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDesignerSourceName;
    @XmlElement(name = "CPMI_Designer_Media")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDesignerMedia;
    @XmlElement(name = "CPMI_Photographer_Source_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPhotographerSourceName;
    @XmlElement(name = "CPMI_Photographer_Method")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPhotographerMethod;
    @XmlElement(name = "CPMI_Photographer_Media")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPhotographerMedia;
    @XmlElement(name = "CPMI_Typeset_Source_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTypesetSourceName;
    @XmlElement(name = "CPMI_Typeset_Method")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTypesetMethod;
    @XmlElement(name = "CPMI_Typeset_Media")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTypesetMedia;
    @XmlElement(name = "CPMI_EDoc_Location_URL")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmieDocLocationURL;
    @XmlElement(name = "CPMI_Cost_Center")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCostCenter;
    @XmlElement(name = "CPMI_Previous_Price")
    protected BigDecimal cpmiPreviousPrice;
    @XmlElement(name = "CPMI_Previous_Pricing_UOM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPreviousPricingUOM;
    @XmlElement(name = "CPMI_Previous_Pricing_UOM_Factor")
    protected Integer cpmiPreviousPricingUOMFactor;
    @XmlElement(name = "CPMI_Orderable")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiOrderable;
    @XmlElement(name = "CPMI_Reason_Not_Orderable")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiReasonNotOrderable;
    @XmlElement(name = "CPMI_Container")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiContainer;
    @XmlElement(name = "CPMI_Container_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiContainerType;
    @XmlElement(name = "CPMI_Activation_Date")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiActivationDate;
    @XmlElement(name = "CPMI_Expiration_Date")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiExpirationDate;
    @XmlElement(name = "CPMI_Ship_Date")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiShipDate;
    @XmlElement(name = "CPMI_Secondary_Per_Package_Quantity")
    protected Integer cpmiSecondaryPerPackageQuantity;
    @XmlElement(name = "CPMI_Secondary_Per_Carton_Or_Roll_Quantity")
    protected Integer cpmiSecondaryPerCartonOrRollQuantity;
    @XmlElement(name = "CPMI_Secondary_Package_Labeling_Description")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiSecondaryPackageLabelingDescription;
    @XmlElement(name = "CPMI_Disaster_Recovery")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDisasterRecovery;
    @XmlElement(name = "CPMI_Critical_Item")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCriticalItem;
    @XmlElement(name = "CPMI_Legal_Review_Required")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiLegalReviewRequired;
    @XmlElement(name = "CPMI_Foreign_Language")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiForeignLanguage;
    @XmlElement(name = "CPMI_Imprinting")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiImprinting;
    @XmlElement(name = "CPMI_Camera_Ready_Copy")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCameraReadyCopy;
    @XmlElement(name = "CPMI_Form_Design_Complete")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiFormDesignComplete;
    @XmlElement(name = "CPMI_Intelligent_Item")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiIntelligentItem;
    @XmlElement(name = "CPMI_Provide_Remote_Printing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiProvideRemotePrinting;
    @XmlElement(name = "CPMI_Negotiable_Item")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiNegotiableItem;
    @XmlElement(name = "CPMI_Process_Color_Printing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiProcessColorPrinting;
    @XmlElement(name = "CPMI_Remoist_Glue")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiRemoistGlue;
    @XmlElement(name = "CPMI_Computer_Aided_Printing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiComputerAidedPrinting;
    @XmlElement(name = "CPMI_Optical_Scanned_Item")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiOpticalScannedItem;
    @XmlElement(name = "CPMI_Tipped_On_ID_Card")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTippedOnIDCard;
    @XmlElement(name = "CPMI_Trimmed_Stub")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTrimmedStub;
    @XmlElement(name = "CPMI_Sheet_Fed_Pricing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiSheetFedPricing;
    @XmlElement(name = "CPMI_Sense_Timing_Repeat_Mark")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiSenseTimingRepeatMark;
    @XmlElement(name = "CPMI_Not_A_Printed_Item")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiNotAPrintedItem;
    @XmlElement(name = "CPMI_External_Publication")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiExternalPublication;
    @XmlElement(name = "CPMI_Internal_Publication")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiInternalPublication;
    @XmlElement(name = "CPMI_Digital_Color_Printing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDigitalColorPrinting;
    @XmlElement(name = "CPMI_Digital_BW_Printing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDigitalBWPrinting;
    @XmlElement(name = "CPMI_International_Sizes")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiInternationalSizes;
    @XmlElement(name = "CPMI_Contains_Pricing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiContainsPricing;
    @XmlElement(name = "CPMI_Web_Printing")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiWebPrinting;
    @XmlElement(name = "CPMI_Customer_Confidential")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCustomerConfidential;
    @XmlElement(name = "CPMI_Sheeted_Single")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiSheetedSingle;
    @XmlElement(name = "CPMI_Variable_Imaging")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiVariableImaging;
    @XmlElement(name = "CPMI_Customer_Contact_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCustomerContactName;
    @XmlElement(name = "CPMI_Customer_Contact_Email")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCustomerContactEmail;
    @XmlElement(name = "CPMI_Customer_Contact_Phone")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCustomerContactPhone;
    @XmlElement(name = "CPMI_Vendor_Contact_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiVendorContactName;
    @XmlElement(name = "CPMI_Vendor_Contact_Email")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiVendorContactEmail;
    @XmlElement(name = "CPMI_Vendor_Contact_Phone")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiVendorContactPhone;
    @XmlElement(name = "CPMI_Designer_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDesignerName;
    @XmlElement(name = "CPMI_Designer_Email")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDesignerEmail;
    @XmlElement(name = "CPMI_Designer_Phone")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiDesignerPhone;
    @XmlElement(name = "CPMI_Photographer_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPhotographerName;
    @XmlElement(name = "CPMI_Photographer_Email")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPhotographerEmail;
    @XmlElement(name = "CPMI_Photographer_Phone")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiPhotographerPhone;
    @XmlElement(name = "CPMI_Typesetter_Contact_Name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTypesetterContactName;
    @XmlElement(name = "CPMI_Typesetter_Contact_Email")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTypesetterContactEmail;
    @XmlElement(name = "CPMI_Typesetter_Contact_Phone")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiTypesetterContactPhone;
    @XmlElement(name = "CPMI_Item_Width")
    protected BigDecimal cpmiItemWidth;
    @XmlElement(name = "CPMI_Item_Height")
    protected BigDecimal cpmiItemHeight;
    @XmlElement(name = "CPMI_Item_Coordinator_Login")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiItemCoordinatorLogin;
    @XmlElement(name = "CPMI_Non_Stock_Item_Orders")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiNonStockItemOrders;
    @XmlElement(name = "CPMI_Can_Be_A_Kit_Component")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiCanBeAKitComponent;
    @XmlElement(name = "CPMI_Default_Touch_Factor")
    protected Integer cpmiDefaultTouchFactor;
    @XmlElement(name = "CPMI_Default_Sequence")
    protected Integer cpmiDefaultSequence;
    @XmlElement(name = "CPMI_Date_Not_Orderable")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar cpmiDateNotOrderable;
    @XmlElement(name = "CPMI_Keyword1")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword1;
    @XmlElement(name = "CPMI_Keyword2")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword2;
    @XmlElement(name = "CPMI_Keyword3")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword3;
    @XmlElement(name = "CPMI_Keyword4")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword4;
    @XmlElement(name = "CPMI_Keyword5")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword5;
    @XmlElement(name = "CPMI_Keyword6")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword6;
    @XmlElement(name = "CPMI_Keyword7")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword7;
    @XmlElement(name = "CPMI_Keyword8")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiKeyword8;
    @XmlElement(name = "CPMI_UDF1")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf1;
    @XmlElement(name = "CPMI_UDF2")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf2;
    @XmlElement(name = "CPMI_UDF3")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf3;
    @XmlElement(name = "CPMI_UDF4")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf4;
    @XmlElement(name = "CPMI_UDF5")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf5;
    @XmlElement(name = "CPMI_UDF6")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf6;
    @XmlElement(name = "CPMI_UDF7")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf7;
    @XmlElement(name = "CPMI_UDF8")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf8;
    @XmlElement(name = "CPMI_UDF9")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf9;
    @XmlElement(name = "CPMI_UDF10")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf10;
    @XmlElement(name = "CPMI_UDF11")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf11;
    @XmlElement(name = "CPMI_UDF12")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf12;
    @XmlElement(name = "CPMI_UDF13")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf13;
    @XmlElement(name = "CPMI_UDF14")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf14;
    @XmlElement(name = "CPMI_UDF15")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cpmiudf15;

    /**
     * Gets the value of the itemDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemDescription() {
        return itemDescription;
    }

    /**
     * Sets the value of the itemDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemDescription(String value) {
        this.itemDescription = value;
    }

    /**
     * Gets the value of the cpmiItemClassification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIItemClassification() {
        return cpmiItemClassification;
    }

    /**
     * Sets the value of the cpmiItemClassification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIItemClassification(String value) {
        this.cpmiItemClassification = value;
    }

    /**
     * Gets the value of the cpmiItemType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIItemType() {
        return cpmiItemType;
    }

    /**
     * Sets the value of the cpmiItemType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIItemType(String value) {
        this.cpmiItemType = value;
    }

    /**
     * Gets the value of the cpmiItemSubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIItemSubType() {
        return cpmiItemSubType;
    }

    /**
     * Sets the value of the cpmiItemSubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIItemSubType(String value) {
        this.cpmiItemSubType = value;
    }

    /**
     * Gets the value of the cpmiIncludeInReports property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIIncludeInReports() {
        return cpmiIncludeInReports;
    }

    /**
     * Sets the value of the cpmiIncludeInReports property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIIncludeInReports(String value) {
        this.cpmiIncludeInReports = value;
    }

    /**
     * Gets the value of the cpmiDepartment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDepartment() {
        return cpmiDepartment;
    }

    /**
     * Sets the value of the cpmiDepartment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDepartment(String value) {
        this.cpmiDepartment = value;
    }

    /**
     * Gets the value of the cpmiDivision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDivision() {
        return cpmiDivision;
    }

    /**
     * Sets the value of the cpmiDivision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDivision(String value) {
        this.cpmiDivision = value;
    }

    /**
     * Gets the value of the cpmiPrimaryVendor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPrimaryVendor() {
        return cpmiPrimaryVendor;
    }

    /**
     * Sets the value of the cpmiPrimaryVendor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPrimaryVendor(String value) {
        this.cpmiPrimaryVendor = value;
    }

    /**
     * Gets the value of the cpmiSecondaryVendor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMISecondaryVendor() {
        return cpmiSecondaryVendor;
    }

    /**
     * Sets the value of the cpmiSecondaryVendor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMISecondaryVendor(String value) {
        this.cpmiSecondaryVendor = value;
    }

    /**
     * Gets the value of the cpmiJobType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIJobType() {
        return cpmiJobType;
    }

    /**
     * Sets the value of the cpmiJobType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIJobType(String value) {
        this.cpmiJobType = value;
    }

    /**
     * Gets the value of the cpmiRevisionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIRevisionNumber() {
        return cpmiRevisionNumber;
    }

    /**
     * Sets the value of the cpmiRevisionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIRevisionNumber(String value) {
        this.cpmiRevisionNumber = value;
    }

    /**
     * Gets the value of the cpmiRevisionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIRevisionDate() {
        return cpmiRevisionDate;
    }

    /**
     * Sets the value of the cpmiRevisionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIRevisionDate(String value) {
        this.cpmiRevisionDate = value;
    }

    /**
     * Gets the value of the cpmiProductCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIProductCode() {
        return cpmiProductCode;
    }

    /**
     * Sets the value of the cpmiProductCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIProductCode(String value) {
        this.cpmiProductCode = value;
    }

    /**
     * Gets the value of the cpmiContractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIContractNumber() {
        return cpmiContractNumber;
    }

    /**
     * Sets the value of the cpmiContractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIContractNumber(String value) {
        this.cpmiContractNumber = value;
    }

    /**
     * Gets the value of the cpmifobPoint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIFOBPoint() {
        return cpmifobPoint;
    }

    /**
     * Sets the value of the cpmifobPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIFOBPoint(String value) {
        this.cpmifobPoint = value;
    }

    /**
     * Gets the value of the cpmiLogoID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMILogoID() {
        return cpmiLogoID;
    }

    /**
     * Sets the value of the cpmiLogoID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMILogoID(String value) {
        this.cpmiLogoID = value;
    }

    /**
     * Gets the value of the cpmiCancellationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICancellationDate() {
        return cpmiCancellationDate;
    }

    /**
     * Sets the value of the cpmiCancellationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICancellationDate(String value) {
        this.cpmiCancellationDate = value;
    }

    /**
     * Gets the value of the cpmiCancellationReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICancellationReason() {
        return cpmiCancellationReason;
    }

    /**
     * Sets the value of the cpmiCancellationReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICancellationReason(String value) {
        this.cpmiCancellationReason = value;
    }

    /**
     * Gets the value of the cpmiReplacementItemNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIReplacementItemNumber() {
        return cpmiReplacementItemNumber;
    }

    /**
     * Sets the value of the cpmiReplacementItemNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIReplacementItemNumber(String value) {
        this.cpmiReplacementItemNumber = value;
    }

    /**
     * Gets the value of the cpmiDispositionOfStock property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDispositionOfStock() {
        return cpmiDispositionOfStock;
    }

    /**
     * Sets the value of the cpmiDispositionOfStock property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDispositionOfStock(String value) {
        this.cpmiDispositionOfStock = value;
    }

    /**
     * Gets the value of the cpmiQuantityUOM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIQuantityUOM() {
        return cpmiQuantityUOM;
    }

    /**
     * Sets the value of the cpmiQuantityUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIQuantityUOM(String value) {
        this.cpmiQuantityUOM = value;
    }

    /**
     * Gets the value of the cpmiQuantityUOMFactor property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIQuantityUOMFactor() {
        return cpmiQuantityUOMFactor;
    }

    /**
     * Sets the value of the cpmiQuantityUOMFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIQuantityUOMFactor(Integer value) {
        this.cpmiQuantityUOMFactor = value;
    }

    /**
     * Gets the value of the cpmiReorderPoint property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIReorderPoint() {
        return cpmiReorderPoint;
    }

    /**
     * Sets the value of the cpmiReorderPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIReorderPoint(Integer value) {
        this.cpmiReorderPoint = value;
    }

    /**
     * Gets the value of the cpmiReorderQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIReorderQuantity() {
        return cpmiReorderQuantity;
    }

    /**
     * Sets the value of the cpmiReorderQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIReorderQuantity(Integer value) {
        this.cpmiReorderQuantity = value;
    }

    /**
     * Gets the value of the cpmiEstimatedAnnualUsageQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIEstimatedAnnualUsageQuantity() {
        return cpmiEstimatedAnnualUsageQuantity;
    }

    /**
     * Sets the value of the cpmiEstimatedAnnualUsageQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIEstimatedAnnualUsageQuantity(Integer value) {
        this.cpmiEstimatedAnnualUsageQuantity = value;
    }

    /**
     * Gets the value of the cpmiMultipleAboveMinimum property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIMultipleAboveMinimum() {
        return cpmiMultipleAboveMinimum;
    }

    /**
     * Sets the value of the cpmiMultipleAboveMinimum property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIMultipleAboveMinimum(Integer value) {
        this.cpmiMultipleAboveMinimum = value;
    }

    /**
     * Gets the value of the cpmiPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCPMIPrice() {
        return cpmiPrice;
    }

    /**
     * Sets the value of the cpmiPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCPMIPrice(BigDecimal value) {
        this.cpmiPrice = value;
    }

    /**
     * Gets the value of the cpmiPricingUOM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPricingUOM() {
        return cpmiPricingUOM;
    }

    /**
     * Sets the value of the cpmiPricingUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPricingUOM(String value) {
        this.cpmiPricingUOM = value;
    }

    /**
     * Gets the value of the cpmiPricingUOMFactor property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIPricingUOMFactor() {
        return cpmiPricingUOMFactor;
    }

    /**
     * Sets the value of the cpmiPricingUOMFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIPricingUOMFactor(Integer value) {
        this.cpmiPricingUOMFactor = value;
    }

    /**
     * Gets the value of the cpmiDefaultChargebackDepartment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDefaultChargebackDepartment() {
        return cpmiDefaultChargebackDepartment;
    }

    /**
     * Sets the value of the cpmiDefaultChargebackDepartment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDefaultChargebackDepartment(String value) {
        this.cpmiDefaultChargebackDepartment = value;
    }

    /**
     * Gets the value of the cpmiNumberOfLocations property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMINumberOfLocations() {
        return cpmiNumberOfLocations;
    }

    /**
     * Sets the value of the cpmiNumberOfLocations property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMINumberOfLocations(Integer value) {
        this.cpmiNumberOfLocations = value;
    }

    /**
     * Gets the value of the cpmiManufacturingLeadTime property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIManufacturingLeadTime() {
        return cpmiManufacturingLeadTime;
    }

    /**
     * Sets the value of the cpmiManufacturingLeadTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIManufacturingLeadTime(Integer value) {
        this.cpmiManufacturingLeadTime = value;
    }

    /**
     * Gets the value of the cpmiReleaseFromStockLeadTime property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIReleaseFromStockLeadTime() {
        return cpmiReleaseFromStockLeadTime;
    }

    /**
     * Sets the value of the cpmiReleaseFromStockLeadTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIReleaseFromStockLeadTime(Integer value) {
        this.cpmiReleaseFromStockLeadTime = value;
    }

    /**
     * Gets the value of the cpmiNumberOfPrintings property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMINumberOfPrintings() {
        return cpmiNumberOfPrintings;
    }

    /**
     * Sets the value of the cpmiNumberOfPrintings property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMINumberOfPrintings(Integer value) {
        this.cpmiNumberOfPrintings = value;
    }

    /**
     * Gets the value of the cpmiMonthsPerPrinting property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIMonthsPerPrinting() {
        return cpmiMonthsPerPrinting;
    }

    /**
     * Sets the value of the cpmiMonthsPerPrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIMonthsPerPrinting(Integer value) {
        this.cpmiMonthsPerPrinting = value;
    }

    /**
     * Gets the value of the cpmiShipmentsPerPrinting property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIShipmentsPerPrinting() {
        return cpmiShipmentsPerPrinting;
    }

    /**
     * Sets the value of the cpmiShipmentsPerPrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIShipmentsPerPrinting(Integer value) {
        this.cpmiShipmentsPerPrinting = value;
    }

    /**
     * Gets the value of the cpmiPackagingMethodDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPackagingMethodDescription() {
        return cpmiPackagingMethodDescription;
    }

    /**
     * Sets the value of the cpmiPackagingMethodDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPackagingMethodDescription(String value) {
        this.cpmiPackagingMethodDescription = value;
    }

    /**
     * Gets the value of the cpmiSpecialPackingInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMISpecialPackingInstructions() {
        return cpmiSpecialPackingInstructions;
    }

    /**
     * Sets the value of the cpmiSpecialPackingInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMISpecialPackingInstructions(String value) {
        this.cpmiSpecialPackingInstructions = value;
    }

    /**
     * Gets the value of the cpmiPrimaryPerPackageQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIPrimaryPerPackageQuantity() {
        return cpmiPrimaryPerPackageQuantity;
    }

    /**
     * Sets the value of the cpmiPrimaryPerPackageQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIPrimaryPerPackageQuantity(Integer value) {
        this.cpmiPrimaryPerPackageQuantity = value;
    }

    /**
     * Gets the value of the cpmiPrimaryPerCartonOrRollQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIPrimaryPerCartonOrRollQuantity() {
        return cpmiPrimaryPerCartonOrRollQuantity;
    }

    /**
     * Sets the value of the cpmiPrimaryPerCartonOrRollQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIPrimaryPerCartonOrRollQuantity(Integer value) {
        this.cpmiPrimaryPerCartonOrRollQuantity = value;
    }

    /**
     * Gets the value of the cpmiPrimaryPackageLabelingDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPrimaryPackageLabelingDescription() {
        return cpmiPrimaryPackageLabelingDescription;
    }

    /**
     * Sets the value of the cpmiPrimaryPackageLabelingDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPrimaryPackageLabelingDescription(String value) {
        this.cpmiPrimaryPackageLabelingDescription = value;
    }

    /**
     * Gets the value of the cpmiDesignerSourceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDesignerSourceName() {
        return cpmiDesignerSourceName;
    }

    /**
     * Sets the value of the cpmiDesignerSourceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDesignerSourceName(String value) {
        this.cpmiDesignerSourceName = value;
    }

    /**
     * Gets the value of the cpmiDesignerMedia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDesignerMedia() {
        return cpmiDesignerMedia;
    }

    /**
     * Sets the value of the cpmiDesignerMedia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDesignerMedia(String value) {
        this.cpmiDesignerMedia = value;
    }

    /**
     * Gets the value of the cpmiPhotographerSourceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPhotographerSourceName() {
        return cpmiPhotographerSourceName;
    }

    /**
     * Sets the value of the cpmiPhotographerSourceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPhotographerSourceName(String value) {
        this.cpmiPhotographerSourceName = value;
    }

    /**
     * Gets the value of the cpmiPhotographerMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPhotographerMethod() {
        return cpmiPhotographerMethod;
    }

    /**
     * Sets the value of the cpmiPhotographerMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPhotographerMethod(String value) {
        this.cpmiPhotographerMethod = value;
    }

    /**
     * Gets the value of the cpmiPhotographerMedia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPhotographerMedia() {
        return cpmiPhotographerMedia;
    }

    /**
     * Sets the value of the cpmiPhotographerMedia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPhotographerMedia(String value) {
        this.cpmiPhotographerMedia = value;
    }

    /**
     * Gets the value of the cpmiTypesetSourceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITypesetSourceName() {
        return cpmiTypesetSourceName;
    }

    /**
     * Sets the value of the cpmiTypesetSourceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITypesetSourceName(String value) {
        this.cpmiTypesetSourceName = value;
    }

    /**
     * Gets the value of the cpmiTypesetMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITypesetMethod() {
        return cpmiTypesetMethod;
    }

    /**
     * Sets the value of the cpmiTypesetMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITypesetMethod(String value) {
        this.cpmiTypesetMethod = value;
    }

    /**
     * Gets the value of the cpmiTypesetMedia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITypesetMedia() {
        return cpmiTypesetMedia;
    }

    /**
     * Sets the value of the cpmiTypesetMedia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITypesetMedia(String value) {
        this.cpmiTypesetMedia = value;
    }

    /**
     * Gets the value of the cpmieDocLocationURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIEDocLocationURL() {
        return cpmieDocLocationURL;
    }

    /**
     * Sets the value of the cpmieDocLocationURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIEDocLocationURL(String value) {
        this.cpmieDocLocationURL = value;
    }

    /**
     * Gets the value of the cpmiCostCenter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICostCenter() {
        return cpmiCostCenter;
    }

    /**
     * Sets the value of the cpmiCostCenter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICostCenter(String value) {
        this.cpmiCostCenter = value;
    }

    /**
     * Gets the value of the cpmiPreviousPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCPMIPreviousPrice() {
        return cpmiPreviousPrice;
    }

    /**
     * Sets the value of the cpmiPreviousPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCPMIPreviousPrice(BigDecimal value) {
        this.cpmiPreviousPrice = value;
    }

    /**
     * Gets the value of the cpmiPreviousPricingUOM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPreviousPricingUOM() {
        return cpmiPreviousPricingUOM;
    }

    /**
     * Sets the value of the cpmiPreviousPricingUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPreviousPricingUOM(String value) {
        this.cpmiPreviousPricingUOM = value;
    }

    /**
     * Gets the value of the cpmiPreviousPricingUOMFactor property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIPreviousPricingUOMFactor() {
        return cpmiPreviousPricingUOMFactor;
    }

    /**
     * Sets the value of the cpmiPreviousPricingUOMFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIPreviousPricingUOMFactor(Integer value) {
        this.cpmiPreviousPricingUOMFactor = value;
    }

    /**
     * Gets the value of the cpmiOrderable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIOrderable() {
        return cpmiOrderable;
    }

    /**
     * Sets the value of the cpmiOrderable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIOrderable(String value) {
        this.cpmiOrderable = value;
    }

    /**
     * Gets the value of the cpmiReasonNotOrderable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIReasonNotOrderable() {
        return cpmiReasonNotOrderable;
    }

    /**
     * Sets the value of the cpmiReasonNotOrderable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIReasonNotOrderable(String value) {
        this.cpmiReasonNotOrderable = value;
    }

    /**
     * Gets the value of the cpmiContainer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIContainer() {
        return cpmiContainer;
    }

    /**
     * Sets the value of the cpmiContainer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIContainer(String value) {
        this.cpmiContainer = value;
    }

    /**
     * Gets the value of the cpmiContainerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIContainerType() {
        return cpmiContainerType;
    }

    /**
     * Sets the value of the cpmiContainerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIContainerType(String value) {
        this.cpmiContainerType = value;
    }

    /**
     * Gets the value of the cpmiActivationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIActivationDate() {
        return cpmiActivationDate;
    }

    /**
     * Sets the value of the cpmiActivationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIActivationDate(String value) {
        this.cpmiActivationDate = value;
    }

    /**
     * Gets the value of the cpmiExpirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIExpirationDate() {
        return cpmiExpirationDate;
    }

    /**
     * Sets the value of the cpmiExpirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIExpirationDate(String value) {
        this.cpmiExpirationDate = value;
    }

    /**
     * Gets the value of the cpmiShipDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIShipDate() {
        return cpmiShipDate;
    }

    /**
     * Sets the value of the cpmiShipDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIShipDate(String value) {
        this.cpmiShipDate = value;
    }

    /**
     * Gets the value of the cpmiSecondaryPerPackageQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMISecondaryPerPackageQuantity() {
        return cpmiSecondaryPerPackageQuantity;
    }

    /**
     * Sets the value of the cpmiSecondaryPerPackageQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMISecondaryPerPackageQuantity(Integer value) {
        this.cpmiSecondaryPerPackageQuantity = value;
    }

    /**
     * Gets the value of the cpmiSecondaryPerCartonOrRollQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMISecondaryPerCartonOrRollQuantity() {
        return cpmiSecondaryPerCartonOrRollQuantity;
    }

    /**
     * Sets the value of the cpmiSecondaryPerCartonOrRollQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMISecondaryPerCartonOrRollQuantity(Integer value) {
        this.cpmiSecondaryPerCartonOrRollQuantity = value;
    }

    /**
     * Gets the value of the cpmiSecondaryPackageLabelingDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMISecondaryPackageLabelingDescription() {
        return cpmiSecondaryPackageLabelingDescription;
    }

    /**
     * Sets the value of the cpmiSecondaryPackageLabelingDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMISecondaryPackageLabelingDescription(String value) {
        this.cpmiSecondaryPackageLabelingDescription = value;
    }

    /**
     * Gets the value of the cpmiDisasterRecovery property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDisasterRecovery() {
        return cpmiDisasterRecovery;
    }

    /**
     * Sets the value of the cpmiDisasterRecovery property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDisasterRecovery(String value) {
        this.cpmiDisasterRecovery = value;
    }

    /**
     * Gets the value of the cpmiCriticalItem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICriticalItem() {
        return cpmiCriticalItem;
    }

    /**
     * Sets the value of the cpmiCriticalItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICriticalItem(String value) {
        this.cpmiCriticalItem = value;
    }

    /**
     * Gets the value of the cpmiLegalReviewRequired property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMILegalReviewRequired() {
        return cpmiLegalReviewRequired;
    }

    /**
     * Sets the value of the cpmiLegalReviewRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMILegalReviewRequired(String value) {
        this.cpmiLegalReviewRequired = value;
    }

    /**
     * Gets the value of the cpmiForeignLanguage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIForeignLanguage() {
        return cpmiForeignLanguage;
    }

    /**
     * Sets the value of the cpmiForeignLanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIForeignLanguage(String value) {
        this.cpmiForeignLanguage = value;
    }

    /**
     * Gets the value of the cpmiImprinting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIImprinting() {
        return cpmiImprinting;
    }

    /**
     * Sets the value of the cpmiImprinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIImprinting(String value) {
        this.cpmiImprinting = value;
    }

    /**
     * Gets the value of the cpmiCameraReadyCopy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICameraReadyCopy() {
        return cpmiCameraReadyCopy;
    }

    /**
     * Sets the value of the cpmiCameraReadyCopy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICameraReadyCopy(String value) {
        this.cpmiCameraReadyCopy = value;
    }

    /**
     * Gets the value of the cpmiFormDesignComplete property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIFormDesignComplete() {
        return cpmiFormDesignComplete;
    }

    /**
     * Sets the value of the cpmiFormDesignComplete property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIFormDesignComplete(String value) {
        this.cpmiFormDesignComplete = value;
    }

    /**
     * Gets the value of the cpmiIntelligentItem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIIntelligentItem() {
        return cpmiIntelligentItem;
    }

    /**
     * Sets the value of the cpmiIntelligentItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIIntelligentItem(String value) {
        this.cpmiIntelligentItem = value;
    }

    /**
     * Gets the value of the cpmiProvideRemotePrinting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIProvideRemotePrinting() {
        return cpmiProvideRemotePrinting;
    }

    /**
     * Sets the value of the cpmiProvideRemotePrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIProvideRemotePrinting(String value) {
        this.cpmiProvideRemotePrinting = value;
    }

    /**
     * Gets the value of the cpmiNegotiableItem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMINegotiableItem() {
        return cpmiNegotiableItem;
    }

    /**
     * Sets the value of the cpmiNegotiableItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMINegotiableItem(String value) {
        this.cpmiNegotiableItem = value;
    }

    /**
     * Gets the value of the cpmiProcessColorPrinting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIProcessColorPrinting() {
        return cpmiProcessColorPrinting;
    }

    /**
     * Sets the value of the cpmiProcessColorPrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIProcessColorPrinting(String value) {
        this.cpmiProcessColorPrinting = value;
    }

    /**
     * Gets the value of the cpmiRemoistGlue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIRemoistGlue() {
        return cpmiRemoistGlue;
    }

    /**
     * Sets the value of the cpmiRemoistGlue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIRemoistGlue(String value) {
        this.cpmiRemoistGlue = value;
    }

    /**
     * Gets the value of the cpmiComputerAidedPrinting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIComputerAidedPrinting() {
        return cpmiComputerAidedPrinting;
    }

    /**
     * Sets the value of the cpmiComputerAidedPrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIComputerAidedPrinting(String value) {
        this.cpmiComputerAidedPrinting = value;
    }

    /**
     * Gets the value of the cpmiOpticalScannedItem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIOpticalScannedItem() {
        return cpmiOpticalScannedItem;
    }

    /**
     * Sets the value of the cpmiOpticalScannedItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIOpticalScannedItem(String value) {
        this.cpmiOpticalScannedItem = value;
    }

    /**
     * Gets the value of the cpmiTippedOnIDCard property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITippedOnIDCard() {
        return cpmiTippedOnIDCard;
    }

    /**
     * Sets the value of the cpmiTippedOnIDCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITippedOnIDCard(String value) {
        this.cpmiTippedOnIDCard = value;
    }

    /**
     * Gets the value of the cpmiTrimmedStub property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITrimmedStub() {
        return cpmiTrimmedStub;
    }

    /**
     * Sets the value of the cpmiTrimmedStub property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITrimmedStub(String value) {
        this.cpmiTrimmedStub = value;
    }

    /**
     * Gets the value of the cpmiSheetFedPricing property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMISheetFedPricing() {
        return cpmiSheetFedPricing;
    }

    /**
     * Sets the value of the cpmiSheetFedPricing property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMISheetFedPricing(String value) {
        this.cpmiSheetFedPricing = value;
    }

    /**
     * Gets the value of the cpmiSenseTimingRepeatMark property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMISenseTimingRepeatMark() {
        return cpmiSenseTimingRepeatMark;
    }

    /**
     * Sets the value of the cpmiSenseTimingRepeatMark property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMISenseTimingRepeatMark(String value) {
        this.cpmiSenseTimingRepeatMark = value;
    }

    /**
     * Gets the value of the cpmiNotAPrintedItem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMINotAPrintedItem() {
        return cpmiNotAPrintedItem;
    }

    /**
     * Sets the value of the cpmiNotAPrintedItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMINotAPrintedItem(String value) {
        this.cpmiNotAPrintedItem = value;
    }

    /**
     * Gets the value of the cpmiExternalPublication property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIExternalPublication() {
        return cpmiExternalPublication;
    }

    /**
     * Sets the value of the cpmiExternalPublication property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIExternalPublication(String value) {
        this.cpmiExternalPublication = value;
    }

    /**
     * Gets the value of the cpmiInternalPublication property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIInternalPublication() {
        return cpmiInternalPublication;
    }

    /**
     * Sets the value of the cpmiInternalPublication property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIInternalPublication(String value) {
        this.cpmiInternalPublication = value;
    }

    /**
     * Gets the value of the cpmiDigitalColorPrinting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDigitalColorPrinting() {
        return cpmiDigitalColorPrinting;
    }

    /**
     * Sets the value of the cpmiDigitalColorPrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDigitalColorPrinting(String value) {
        this.cpmiDigitalColorPrinting = value;
    }

    /**
     * Gets the value of the cpmiDigitalBWPrinting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDigitalBWPrinting() {
        return cpmiDigitalBWPrinting;
    }

    /**
     * Sets the value of the cpmiDigitalBWPrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDigitalBWPrinting(String value) {
        this.cpmiDigitalBWPrinting = value;
    }

    /**
     * Gets the value of the cpmiInternationalSizes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIInternationalSizes() {
        return cpmiInternationalSizes;
    }

    /**
     * Sets the value of the cpmiInternationalSizes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIInternationalSizes(String value) {
        this.cpmiInternationalSizes = value;
    }

    /**
     * Gets the value of the cpmiContainsPricing property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIContainsPricing() {
        return cpmiContainsPricing;
    }

    /**
     * Sets the value of the cpmiContainsPricing property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIContainsPricing(String value) {
        this.cpmiContainsPricing = value;
    }

    /**
     * Gets the value of the cpmiWebPrinting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIWebPrinting() {
        return cpmiWebPrinting;
    }

    /**
     * Sets the value of the cpmiWebPrinting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIWebPrinting(String value) {
        this.cpmiWebPrinting = value;
    }

    /**
     * Gets the value of the cpmiCustomerConfidential property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICustomerConfidential() {
        return cpmiCustomerConfidential;
    }

    /**
     * Sets the value of the cpmiCustomerConfidential property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICustomerConfidential(String value) {
        this.cpmiCustomerConfidential = value;
    }

    /**
     * Gets the value of the cpmiSheetedSingle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMISheetedSingle() {
        return cpmiSheetedSingle;
    }

    /**
     * Sets the value of the cpmiSheetedSingle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMISheetedSingle(String value) {
        this.cpmiSheetedSingle = value;
    }

    /**
     * Gets the value of the cpmiVariableImaging property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIVariableImaging() {
        return cpmiVariableImaging;
    }

    /**
     * Sets the value of the cpmiVariableImaging property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIVariableImaging(String value) {
        this.cpmiVariableImaging = value;
    }

    /**
     * Gets the value of the cpmiCustomerContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICustomerContactName() {
        return cpmiCustomerContactName;
    }

    /**
     * Sets the value of the cpmiCustomerContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICustomerContactName(String value) {
        this.cpmiCustomerContactName = value;
    }

    /**
     * Gets the value of the cpmiCustomerContactEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICustomerContactEmail() {
        return cpmiCustomerContactEmail;
    }

    /**
     * Sets the value of the cpmiCustomerContactEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICustomerContactEmail(String value) {
        this.cpmiCustomerContactEmail = value;
    }

    /**
     * Gets the value of the cpmiCustomerContactPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICustomerContactPhone() {
        return cpmiCustomerContactPhone;
    }

    /**
     * Sets the value of the cpmiCustomerContactPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICustomerContactPhone(String value) {
        this.cpmiCustomerContactPhone = value;
    }

    /**
     * Gets the value of the cpmiVendorContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIVendorContactName() {
        return cpmiVendorContactName;
    }

    /**
     * Sets the value of the cpmiVendorContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIVendorContactName(String value) {
        this.cpmiVendorContactName = value;
    }

    /**
     * Gets the value of the cpmiVendorContactEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIVendorContactEmail() {
        return cpmiVendorContactEmail;
    }

    /**
     * Sets the value of the cpmiVendorContactEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIVendorContactEmail(String value) {
        this.cpmiVendorContactEmail = value;
    }

    /**
     * Gets the value of the cpmiVendorContactPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIVendorContactPhone() {
        return cpmiVendorContactPhone;
    }

    /**
     * Sets the value of the cpmiVendorContactPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIVendorContactPhone(String value) {
        this.cpmiVendorContactPhone = value;
    }

    /**
     * Gets the value of the cpmiDesignerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDesignerName() {
        return cpmiDesignerName;
    }

    /**
     * Sets the value of the cpmiDesignerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDesignerName(String value) {
        this.cpmiDesignerName = value;
    }

    /**
     * Gets the value of the cpmiDesignerEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDesignerEmail() {
        return cpmiDesignerEmail;
    }

    /**
     * Sets the value of the cpmiDesignerEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDesignerEmail(String value) {
        this.cpmiDesignerEmail = value;
    }

    /**
     * Gets the value of the cpmiDesignerPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIDesignerPhone() {
        return cpmiDesignerPhone;
    }

    /**
     * Sets the value of the cpmiDesignerPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIDesignerPhone(String value) {
        this.cpmiDesignerPhone = value;
    }

    /**
     * Gets the value of the cpmiPhotographerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPhotographerName() {
        return cpmiPhotographerName;
    }

    /**
     * Sets the value of the cpmiPhotographerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPhotographerName(String value) {
        this.cpmiPhotographerName = value;
    }

    /**
     * Gets the value of the cpmiPhotographerEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPhotographerEmail() {
        return cpmiPhotographerEmail;
    }

    /**
     * Sets the value of the cpmiPhotographerEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPhotographerEmail(String value) {
        this.cpmiPhotographerEmail = value;
    }

    /**
     * Gets the value of the cpmiPhotographerPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIPhotographerPhone() {
        return cpmiPhotographerPhone;
    }

    /**
     * Sets the value of the cpmiPhotographerPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIPhotographerPhone(String value) {
        this.cpmiPhotographerPhone = value;
    }

    /**
     * Gets the value of the cpmiTypesetterContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITypesetterContactName() {
        return cpmiTypesetterContactName;
    }

    /**
     * Sets the value of the cpmiTypesetterContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITypesetterContactName(String value) {
        this.cpmiTypesetterContactName = value;
    }

    /**
     * Gets the value of the cpmiTypesetterContactEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITypesetterContactEmail() {
        return cpmiTypesetterContactEmail;
    }

    /**
     * Sets the value of the cpmiTypesetterContactEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITypesetterContactEmail(String value) {
        this.cpmiTypesetterContactEmail = value;
    }

    /**
     * Gets the value of the cpmiTypesetterContactPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMITypesetterContactPhone() {
        return cpmiTypesetterContactPhone;
    }

    /**
     * Sets the value of the cpmiTypesetterContactPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMITypesetterContactPhone(String value) {
        this.cpmiTypesetterContactPhone = value;
    }

    /**
     * Gets the value of the cpmiItemWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCPMIItemWidth() {
        return cpmiItemWidth;
    }

    /**
     * Sets the value of the cpmiItemWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCPMIItemWidth(BigDecimal value) {
        this.cpmiItemWidth = value;
    }

    /**
     * Gets the value of the cpmiItemHeight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCPMIItemHeight() {
        return cpmiItemHeight;
    }

    /**
     * Sets the value of the cpmiItemHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCPMIItemHeight(BigDecimal value) {
        this.cpmiItemHeight = value;
    }

    /**
     * Gets the value of the cpmiItemCoordinatorLogin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIItemCoordinatorLogin() {
        return cpmiItemCoordinatorLogin;
    }

    /**
     * Sets the value of the cpmiItemCoordinatorLogin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIItemCoordinatorLogin(String value) {
        this.cpmiItemCoordinatorLogin = value;
    }

    /**
     * Gets the value of the cpmiNonStockItemOrders property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMINonStockItemOrders() {
        return cpmiNonStockItemOrders;
    }

    /**
     * Sets the value of the cpmiNonStockItemOrders property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMINonStockItemOrders(String value) {
        this.cpmiNonStockItemOrders = value;
    }

    /**
     * Gets the value of the cpmiCanBeAKitComponent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMICanBeAKitComponent() {
        return cpmiCanBeAKitComponent;
    }

    /**
     * Sets the value of the cpmiCanBeAKitComponent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMICanBeAKitComponent(String value) {
        this.cpmiCanBeAKitComponent = value;
    }

    /**
     * Gets the value of the cpmiDefaultTouchFactor property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIDefaultTouchFactor() {
        return cpmiDefaultTouchFactor;
    }

    /**
     * Sets the value of the cpmiDefaultTouchFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIDefaultTouchFactor(Integer value) {
        this.cpmiDefaultTouchFactor = value;
    }

    /**
     * Gets the value of the cpmiDefaultSequence property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCPMIDefaultSequence() {
        return cpmiDefaultSequence;
    }

    /**
     * Sets the value of the cpmiDefaultSequence property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCPMIDefaultSequence(Integer value) {
        this.cpmiDefaultSequence = value;
    }

    /**
     * Gets the value of the cpmiDateNotOrderable property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCPMIDateNotOrderable() {
        return cpmiDateNotOrderable;
    }

    /**
     * Sets the value of the cpmiDateNotOrderable property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCPMIDateNotOrderable(XMLGregorianCalendar value) {
        this.cpmiDateNotOrderable = value;
    }

    /**
     * Gets the value of the cpmiKeyword1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword1() {
        return cpmiKeyword1;
    }

    /**
     * Sets the value of the cpmiKeyword1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword1(String value) {
        this.cpmiKeyword1 = value;
    }

    /**
     * Gets the value of the cpmiKeyword2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword2() {
        return cpmiKeyword2;
    }

    /**
     * Sets the value of the cpmiKeyword2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword2(String value) {
        this.cpmiKeyword2 = value;
    }

    /**
     * Gets the value of the cpmiKeyword3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword3() {
        return cpmiKeyword3;
    }

    /**
     * Sets the value of the cpmiKeyword3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword3(String value) {
        this.cpmiKeyword3 = value;
    }

    /**
     * Gets the value of the cpmiKeyword4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword4() {
        return cpmiKeyword4;
    }

    /**
     * Sets the value of the cpmiKeyword4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword4(String value) {
        this.cpmiKeyword4 = value;
    }

    /**
     * Gets the value of the cpmiKeyword5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword5() {
        return cpmiKeyword5;
    }

    /**
     * Sets the value of the cpmiKeyword5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword5(String value) {
        this.cpmiKeyword5 = value;
    }

    /**
     * Gets the value of the cpmiKeyword6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword6() {
        return cpmiKeyword6;
    }

    /**
     * Sets the value of the cpmiKeyword6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword6(String value) {
        this.cpmiKeyword6 = value;
    }

    /**
     * Gets the value of the cpmiKeyword7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword7() {
        return cpmiKeyword7;
    }

    /**
     * Sets the value of the cpmiKeyword7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword7(String value) {
        this.cpmiKeyword7 = value;
    }

    /**
     * Gets the value of the cpmiKeyword8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIKeyword8() {
        return cpmiKeyword8;
    }

    /**
     * Sets the value of the cpmiKeyword8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIKeyword8(String value) {
        this.cpmiKeyword8 = value;
    }

    /**
     * Gets the value of the cpmiudf1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF1() {
        return cpmiudf1;
    }

    /**
     * Sets the value of the cpmiudf1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF1(String value) {
        this.cpmiudf1 = value;
    }

    /**
     * Gets the value of the cpmiudf2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF2() {
        return cpmiudf2;
    }

    /**
     * Sets the value of the cpmiudf2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF2(String value) {
        this.cpmiudf2 = value;
    }

    /**
     * Gets the value of the cpmiudf3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF3() {
        return cpmiudf3;
    }

    /**
     * Sets the value of the cpmiudf3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF3(String value) {
        this.cpmiudf3 = value;
    }

    /**
     * Gets the value of the cpmiudf4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF4() {
        return cpmiudf4;
    }

    /**
     * Sets the value of the cpmiudf4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF4(String value) {
        this.cpmiudf4 = value;
    }

    /**
     * Gets the value of the cpmiudf5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF5() {
        return cpmiudf5;
    }

    /**
     * Sets the value of the cpmiudf5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF5(String value) {
        this.cpmiudf5 = value;
    }

    /**
     * Gets the value of the cpmiudf6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF6() {
        return cpmiudf6;
    }

    /**
     * Sets the value of the cpmiudf6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF6(String value) {
        this.cpmiudf6 = value;
    }

    /**
     * Gets the value of the cpmiudf7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF7() {
        return cpmiudf7;
    }

    /**
     * Sets the value of the cpmiudf7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF7(String value) {
        this.cpmiudf7 = value;
    }

    /**
     * Gets the value of the cpmiudf8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF8() {
        return cpmiudf8;
    }

    /**
     * Sets the value of the cpmiudf8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF8(String value) {
        this.cpmiudf8 = value;
    }

    /**
     * Gets the value of the cpmiudf9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF9() {
        return cpmiudf9;
    }

    /**
     * Sets the value of the cpmiudf9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF9(String value) {
        this.cpmiudf9 = value;
    }

    /**
     * Gets the value of the cpmiudf10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF10() {
        return cpmiudf10;
    }

    /**
     * Sets the value of the cpmiudf10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF10(String value) {
        this.cpmiudf10 = value;
    }

    /**
     * Gets the value of the cpmiudf11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF11() {
        return cpmiudf11;
    }

    /**
     * Sets the value of the cpmiudf11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF11(String value) {
        this.cpmiudf11 = value;
    }

    /**
     * Gets the value of the cpmiudf12 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF12() {
        return cpmiudf12;
    }

    /**
     * Sets the value of the cpmiudf12 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF12(String value) {
        this.cpmiudf12 = value;
    }

    /**
     * Gets the value of the cpmiudf13 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF13() {
        return cpmiudf13;
    }

    /**
     * Sets the value of the cpmiudf13 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF13(String value) {
        this.cpmiudf13 = value;
    }

    /**
     * Gets the value of the cpmiudf14 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF14() {
        return cpmiudf14;
    }

    /**
     * Sets the value of the cpmiudf14 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF14(String value) {
        this.cpmiudf14 = value;
    }

    /**
     * Gets the value of the cpmiudf15 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPMIUDF15() {
        return cpmiudf15;
    }

    /**
     * Sets the value of the cpmiudf15 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPMIUDF15(String value) {
        this.cpmiudf15 = value;
    }

}
