
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TypeQTData complex type.
 * <p>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="TypeQTData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TxnID" type="{}TypeTxnID"/>
 *         &lt;element name="TxnStatusCode" type="{}TypeTxnStatus"/>
 *         &lt;element name="TxnStatusMsg" type="{http://www.w3.org/2001/XMLSchema}token"/>
 *         &lt;element name="SubmittedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="BatchID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}long">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="OtherInfo" type="{http://www.w3.org/2001/XMLSchema}token"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeQTData", propOrder = {
        "txnID",
        "txnStatusCode",
        "txnStatusMsg",
        "submittedDate",
        "batchID",
        "otherInfo"
})
public class TypeQTData {

    @XmlElement(name = "TxnID")
    protected int txnID;
    @XmlElement(name = "TxnStatusCode")
    protected short txnStatusCode;
    @XmlElement(name = "TxnStatusMsg", required = true, nillable = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String txnStatusMsg;
    @XmlElement(name = "SubmittedDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar submittedDate;
    @XmlElement(name = "BatchID", required = true, type = Long.class, nillable = true)
    protected Long batchID;
    @XmlElement(name = "OtherInfo", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String otherInfo;

    /**
     * Gets the value of the txnID property.
     */
    public int getTxnID() {
        return txnID;
    }

    /**
     * Sets the value of the txnID property.
     */
    public void setTxnID(int value) {
        this.txnID = value;
    }

    /**
     * Gets the value of the txnStatusCode property.
     */
    public short getTxnStatusCode() {
        return txnStatusCode;
    }

    /**
     * Sets the value of the txnStatusCode property.
     */
    public void setTxnStatusCode(short value) {
        this.txnStatusCode = value;
    }

    /**
     * Gets the value of the txnStatusMsg property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getTxnStatusMsg() {
        return txnStatusMsg;
    }

    /**
     * Sets the value of the txnStatusMsg property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setTxnStatusMsg(String value) {
        this.txnStatusMsg = value;
    }

    /**
     * Gets the value of the submittedDate property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getSubmittedDate() {
        return submittedDate;
    }

    /**
     * Sets the value of the submittedDate property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setSubmittedDate(XMLGregorianCalendar value) {
        this.submittedDate = value;
    }

    /**
     * Gets the value of the batchID property.
     *
     * @return possible object is
     * {@link Long }
     */
    public Long getBatchID() {
        return batchID;
    }

    /**
     * Sets the value of the batchID property.
     *
     * @param value allowed object is
     *              {@link Long }
     */
    public void setBatchID(Long value) {
        this.batchID = value;
    }

    /**
     * Gets the value of the otherInfo property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getOtherInfo() {
        return otherInfo;
    }

    /**
     * Sets the value of the otherInfo property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setOtherInfo(String value) {
        this.otherInfo = value;
    }

}
