
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for ItemRequestDef complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemRequestDef">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Cust_Item_Num" type="{}TypeCustItemNum"/>
 *         &lt;element name="Cust_Item_Num_Replaced" type="{}TypeCustItemNum" minOccurs="0"/>
 *         &lt;element name="RequestType" type="{}TypeRequestType"/>
 *         &lt;element name="Bulk_ID_Cust" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Is_Stand_Alone_Item" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="Is_ECreate_Item" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="Is_CSS_Item" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="Is_JIT" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Is_ECreate" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Is_CSS" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ChangeType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Customer_UID" type="{}TypeCustomerUID" minOccurs="0"/>
 *         &lt;element name="ContactName">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ContactEmail">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *               &lt;pattern value=".*@.*\..*"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="OMS_Descr" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="120"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_Item_Num" type="{}TypeWcssItemNum" minOccurs="0"/>
 *         &lt;element name="WCSS_Item_Num_Master" type="{}TypeWcssItemNum" minOccurs="0"/>
 *         &lt;element name="WCSS_Item_Descr" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="40"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Cover_Type" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Packaging_UOM" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Packaging_Qty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Revision" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Max_Order_Qty_WCSS" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Item_Cat" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Item_SubType" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Orientation" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;enumeration value="LANDSCAPE"/>
 *               &lt;enumeration value="PORTRAIT"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Sides_Printed" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Page_Qty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Page_Qty_Imposed" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Paper_Stock_Type" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Paper_Stock_Weight" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Paper_Stock_Color" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Stack_Offset" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Thermal_Tape_Color" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="5"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Trim_Size_Width" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Trim_Size_Length" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Stitching_Loc" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Drilling_Size" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Drilling_Loc" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Glue_Loc" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Pad_Num" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Fold_Type" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Poly_Num" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Page_Width" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Page_Length" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Ink_Colors" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Bleeds" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="3"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="PDF_Filename" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="200"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Comments" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="InitSpec_CSR_Appr_Needed" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Author" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Book_Title" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_SpineRounding" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_HeadBandRequired" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_FoilStampPosition_Cd" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_Foil_Color_Cd" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_Cloth_Cd" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_Laminate_Cd" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_Cardboard_Cd" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_End_Paper_Cd" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Pre_Imposed" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_ISBN_10_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_ISBN_13_NR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="13"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_BOOK_PUBLISHER" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="40"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="WCSS_BOOK_US_CVR_PRC" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="WCSS_BOOK_CN_CVR_PRC" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="WCSS_Upgrade_Item_Text" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_Head_Margin" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Gutter_Margin" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Num_of_Wires" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="CR_SAP_Paper_Number" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="CR_Backing_Loose_Tight" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_Headband_Color" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="11"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CR_JKT_Flap_Wd_Front" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_JKT_Flap_Wd_Back" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Pad_Location" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Sheets_Qty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="WCSS_BOOK_WORK_TYPE_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_BlankLocation" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_BlankType" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Seq_Numbered_Item_Details" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Tab_Size" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Min_Order_Qty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Multiple_Order_Qty" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Paper_Width" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Paper_Length" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Tab_Num" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Box_Num" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="Spine_Size" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Cloth_Size_Width" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Cloth_Size_Length" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Board_Size_Width" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Board_Size_Length" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Strip_Width" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Strip_Length" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Split_Shipment" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="Seq_Numbered_Item" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="Product_Code" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Binder_Size" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Binder_Color" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Binder_Ring_Type" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Binder_Transparency" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Fold_At" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Extract_Spine" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_PROD_CLS_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_SKU_DS" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_WORK_TYPE_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Page_Width" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Page_Height" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Top_Margin" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Left_Margin" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Horizontal_Gutter" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Vertical_Gutter" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Has_Crop_Marks" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="CR_Imposition_Images_Per_Sheet" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_LSN_LVL_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_FORM_TYPE_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_DFLT_TAX_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_HARM_TARIF_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_LSN_OWNER_NM" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_COPYRIGHT_YR" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_MASTER_DIVISION_NR" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_PRODUCT_SUFFIX_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_FG_KIT_ITEM_NR" type="{}TypeWcssItemNum" minOccurs="0"/>
 *         &lt;element name="WCSS_BOM_KIT_ITEM_NR" type="{}TypeWcssItemNum" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_RORDR_PT" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_RORDR_QT" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_THRSHLD_QT" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_NUM_PLIES_NR" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="CR_Size_UOM" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_SECURE_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_POD_TYPE_CD" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ALLOW_TAX_CD_MAINT" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ALLOW_TAX_USER_FLAG" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_COMMIT_FUT_ORD_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_CMPNTS_INV_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_CMPNTS_WITH_SPLIT_ORD" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_OVRSIZ_ITM_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_UNUSUAL_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_HZRDS_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_CANCEL_BO_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_STATUS_CD" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_TYPE_CD" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_CMPNT_ONLY_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_LASERMAX_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ADTNL_MFG_DATA_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_KIT_ASMBLY_REQD_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_VIRTUAL_MASTER_IN" type="{}TypeYesNo" minOccurs="0"/>
 *         &lt;element name="WCSS_ITEM_NMBRNG_CD" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_IsCPSIA" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CR_ImagesPerRow" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="CR_UseSaddleImpose" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CR_ScoringLocation" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_PerfLocation" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_Overage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Sample_Quantity" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="CR_uvCoating" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_Laminate_Location" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_Laminate_Coating" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_Laminate_Coverage" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_Laminate_Finish_Type" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="CR_Laminate_Thickness" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Bleed_Size" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Carbonless_Imposition" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CR_Print_Spec_Comments" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="DAO_LU_Variable_Text_Configuration_ID" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="Comp_Mgd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Comp_Num" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="10"/>
 *               &lt;minLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Bill_To_Job_Default" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="ECP_Job_Default" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="RARS_Workflow" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CR_Crop_Left" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Crop_Right" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Crop_Top" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Crop_Bottom" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CR_Crop_Swap_On_Even_Pages" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CR_Crop_File" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Start_As_Draft" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Allow_CustomPoint_Skip" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ItemOnlyWorkflow" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="MD5_Cover" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="[0-9a-f]{32}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="MD5_Book" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="[0-9a-f]{32}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="eDeliveryWorkflow" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="HWSProgramID" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;pattern value="^[A-Z]{6}$"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="No_PDF_JIT" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ItemRef" type="{}TypeItemRef" maxOccurs="30" minOccurs="0"/>
 *         &lt;element name="CDI" type="{}TypeCDI" maxOccurs="25" minOccurs="0"/>
 *         &lt;element name="ECreate" type="{}TypeECreate" minOccurs="0"/>
 *         &lt;element name="CustomPoint" type="{}TypeCustomPoint" minOccurs="0"/>
 *         &lt;element name="PageExceptions" type="{}TypePageException" maxOccurs="100" minOccurs="0"/>
 *         &lt;element name="JobRef" type="{}TypeJobRef" maxOccurs="30" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemRequestDef", propOrder = {
    "custItemNum",
    "custItemNumReplaced",
    "requestType",
    "bulkIDCust",
    "isStandAloneItem",
    "isECreateItem",
    "isCSSItem",
    "isJIT",
    "isECreate",
    "isCSS",
    "changeType",
    "customerUID",
    "contactName",
    "contactEmail",
    "omsDescr",
    "wcssItemNum",
    "wcssItemNumMaster",
    "wcssItemDescr",
    "coverType",
    "packagingUOM",
    "packagingQty",
    "revision",
    "maxOrderQtyWCSS",
    "itemCat",
    "itemSubType",
    "orientation",
    "sidesPrinted",
    "pageQty",
    "pageQtyImposed",
    "paperStockType",
    "paperStockWeight",
    "paperStockColor",
    "stackOffset",
    "thermalTapeColor",
    "trimSizeWidth",
    "trimSizeLength",
    "stitchingLoc",
    "drillingSize",
    "drillingLoc",
    "glueLoc",
    "padNum",
    "foldType",
    "polyNum",
    "pageWidth",
    "pageLength",
    "inkColors",
    "bleeds",
    "pdfFilename",
    "comments",
    "initSpecCSRApprNeeded",
    "author",
    "bookTitle",
    "crSpineRounding",
    "crHeadBandRequired",
    "crFoilStampPositionCd",
    "crFoilColorCd",
    "crClothCd",
    "crLaminateCd",
    "crCardboardCd",
    "crEndPaperCd",
    "preImposed",
    "wcssisbn10NR",
    "wcssisbn13NR",
    "wcssbookpublisher",
    "wcssbookuscvrprc",
    "wcssbookcncvrprc",
    "wcssUpgradeItemText",
    "crHeadMargin",
    "crGutterMargin",
    "crNumOfWires",
    "crsapPaperNumber",
    "crBackingLooseTight",
    "crHeadbandColor",
    "crjktFlapWdFront",
    "crjktFlapWdBack",
    "crPadLocation",
    "sheetsQty",
    "wcssbookworktypecd",
    "crBlankLocation",
    "crBlankType",
    "seqNumberedItemDetails",
    "tabSize",
    "minOrderQty",
    "multipleOrderQty",
    "paperWidth",
    "paperLength",
    "tabNum",
    "boxNum",
    "spineSize",
    "clothSizeWidth",
    "clothSizeLength",
    "boardSizeWidth",
    "boardSizeLength",
    "stripWidth",
    "stripLength",
    "splitShipment",
    "seqNumberedItem",
    "productCode",
    "binderSize",
    "binderColor",
    "binderRingType",
    "binderTransparency",
    "foldAt",
    "extractSpine",
    "wcssitemprodclscd",
    "wcssitemskuds",
    "wcssworktypecd",
    "crImpositionPageWidth",
    "crImpositionPageHeight",
    "crImpositionTopMargin",
    "crImpositionLeftMargin",
    "crImpositionHorizontalGutter",
    "crImpositionVerticalGutter",
    "crImpositionHasCropMarks",
    "crImpositionImagesPerSheet",
    "wcssitemlsnlvlcd",
    "wcssitemformtypecd",
    "wcssitemdflttaxcd",
    "wcssharmtarifcd",
    "wcsslsnownernm",
    "wcsscopyrightyr",
    "wcssmasterdivisionnr",
    "wcssproductsuffixcd",
    "wcssfgkititemnr",
    "wcssbomkititemnr",
    "wcssitemrordrpt",
    "wcssitemrordrqt",
    "wcssitemthrshldqt",
    "wcssitemnumpliesnr",
    "crSizeUOM",
    "wcssitemsecurein",
    "wcssitempodtypecd",
    "wcssallowtaxcdmaint",
    "wcssallowtaxuserflag",
    "wcsscommitfutordin",
    "wcsscmpntsinvin",
    "wcsscmpntswithsplitord",
    "wcssovrsizitmin",
    "wcssitemunusualin",
    "wcssitemhzrdsin",
    "wcsscancelboin",
    "wcssitemstatuscd",
    "wcssitemtypecd",
    "wcssitemcmpntonlyin",
    "wcssitemlasermaxin",
    "wcssadtnlmfgdatain",
    "wcsskitasmblyreqdin",
    "wcssvirtualmasterin",
    "wcssitemnmbrngcd",
    "crIsCPSIA",
    "crImagesPerRow",
    "crUseSaddleImpose",
    "crScoringLocation",
    "crPerfLocation",
    "crOverage",
    "crSampleQuantity",
    "crUvCoating",
    "crLaminateLocation",
    "crLaminateCoating",
    "crLaminateCoverage",
    "crLaminateFinishType",
    "crLaminateThickness",
    "crBleedSize",
    "crCarbonlessImposition",
    "crPrintSpecComments",
    "daoluVariableTextConfigurationID",
    "compMgd",
    "compNum",
    "billToJobDefault",
    "ecpJobDefault",
    "rarsWorkflow",
    "crCropLeft",
    "crCropRight",
    "crCropTop",
    "crCropBottom",
    "crCropSwapOnEvenPages",
    "crCropFile",
    "startAsDraft",
    "allowCustomPointSkip",
    "itemOnlyWorkflow",
    "md5Cover",
    "md5Book",
    "eDeliveryWorkflow",
    "hwsProgramID",
    "noPDFJIT",
    "itemRef",
    "cdi",
    "eCreate",
    "customPoint",
    "pageExceptions",
    "jobRef"
})
public class ItemRequestDef {

    @XmlElement(name = "Cust_Item_Num", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String custItemNum;
    @XmlElement(name = "Cust_Item_Num_Replaced")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String custItemNumReplaced;
    @XmlElement(name = "RequestType", required = true)
    @XmlSchemaType(name = "token")
    protected TypeRequestType requestType;
    @XmlElement(name = "Bulk_ID_Cust")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String bulkIDCust;
    @XmlElement(name = "Is_Stand_Alone_Item", defaultValue = "N")
    @XmlSchemaType(name = "token")
    protected TypeYesNo isStandAloneItem;
    @XmlElement(name = "Is_ECreate_Item", defaultValue = "N")
    @XmlSchemaType(name = "token")
    protected TypeYesNo isECreateItem;
    @XmlElement(name = "Is_CSS_Item", defaultValue = "N")
    @XmlSchemaType(name = "token")
    protected TypeYesNo isCSSItem;
    @XmlElement(name = "Is_JIT")
    protected Boolean isJIT;
    @XmlElement(name = "Is_ECreate")
    protected Boolean isECreate;
    @XmlElement(name = "Is_CSS")
    protected Boolean isCSS;
    @XmlElement(name = "ChangeType")
    protected String changeType;
    @XmlElement(name = "Customer_UID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String customerUID;
    @XmlElement(name = "ContactName", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String contactName;
    @XmlElement(name = "ContactEmail", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String contactEmail;
    @XmlElement(name = "OMS_Descr")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String omsDescr;
    @XmlElement(name = "WCSS_Item_Num")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssItemNum;
    @XmlElement(name = "WCSS_Item_Num_Master")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssItemNumMaster;
    @XmlElement(name = "WCSS_Item_Descr")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssItemDescr;
    @XmlElement(name = "Cover_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String coverType;
    @XmlElement(name = "Packaging_UOM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String packagingUOM;
    @XmlElement(name = "Packaging_Qty")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger packagingQty;
    @XmlElement(name = "Revision")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String revision;
    @XmlElement(name = "Max_Order_Qty_WCSS")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger maxOrderQtyWCSS;
    @XmlElement(name = "Item_Cat")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String itemCat;
    @XmlElement(name = "Item_SubType")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String itemSubType;
    @XmlElement(name = "Orientation")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String orientation;
    @XmlElement(name = "Sides_Printed")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String sidesPrinted;
    @XmlElement(name = "Page_Qty")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger pageQty;
    @XmlElement(name = "Page_Qty_Imposed")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger pageQtyImposed;
    @XmlElement(name = "Paper_Stock_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String paperStockType;
    @XmlElement(name = "Paper_Stock_Weight")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String paperStockWeight;
    @XmlElement(name = "Paper_Stock_Color")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String paperStockColor;
    @XmlElement(name = "Stack_Offset")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String stackOffset;
    @XmlElement(name = "Thermal_Tape_Color")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String thermalTapeColor;
    @XmlElement(name = "Trim_Size_Width")
    protected BigDecimal trimSizeWidth;
    @XmlElement(name = "Trim_Size_Length")
    protected BigDecimal trimSizeLength;
    @XmlElement(name = "Stitching_Loc")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String stitchingLoc;
    @XmlElement(name = "Drilling_Size")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String drillingSize;
    @XmlElement(name = "Drilling_Loc")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String drillingLoc;
    @XmlElement(name = "Glue_Loc")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String glueLoc;
    @XmlElement(name = "Pad_Num")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger padNum;
    @XmlElement(name = "Fold_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String foldType;
    @XmlElement(name = "Poly_Num")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String polyNum;
    @XmlElement(name = "Page_Width")
    protected BigDecimal pageWidth;
    @XmlElement(name = "Page_Length")
    protected BigDecimal pageLength;
    @XmlElement(name = "Ink_Colors")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String inkColors;
    @XmlElement(name = "Bleeds")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String bleeds;
    @XmlElement(name = "PDF_Filename")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String pdfFilename;
    @XmlElement(name = "Comments")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String comments;
    @XmlElement(name = "InitSpec_CSR_Appr_Needed")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String initSpecCSRApprNeeded;
    @XmlElement(name = "Author")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String author;
    @XmlElement(name = "Book_Title")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String bookTitle;
    @XmlElement(name = "CR_SpineRounding")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crSpineRounding;
    @XmlElement(name = "CR_HeadBandRequired")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crHeadBandRequired;
    @XmlElement(name = "CR_FoilStampPosition_Cd")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crFoilStampPositionCd;
    @XmlElement(name = "CR_Foil_Color_Cd")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crFoilColorCd;
    @XmlElement(name = "CR_Cloth_Cd")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crClothCd;
    @XmlElement(name = "CR_Laminate_Cd")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crLaminateCd;
    @XmlElement(name = "CR_Cardboard_Cd")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crCardboardCd;
    @XmlElement(name = "CR_End_Paper_Cd")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crEndPaperCd;
    @XmlElement(name = "Pre_Imposed")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String preImposed;
    @XmlElement(name = "WCSS_ISBN_10_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssisbn10NR;
    @XmlElement(name = "WCSS_ISBN_13_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssisbn13NR;
    @XmlElement(name = "WCSS_BOOK_PUBLISHER")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssbookpublisher;
    @XmlElement(name = "WCSS_BOOK_US_CVR_PRC")
    protected BigDecimal wcssbookuscvrprc;
    @XmlElement(name = "WCSS_BOOK_CN_CVR_PRC")
    protected BigDecimal wcssbookcncvrprc;
    @XmlElement(name = "WCSS_Upgrade_Item_Text")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String wcssUpgradeItemText;
    @XmlElement(name = "CR_Head_Margin")
    protected BigDecimal crHeadMargin;
    @XmlElement(name = "CR_Gutter_Margin")
    protected BigDecimal crGutterMargin;
    @XmlElement(name = "CR_Num_of_Wires")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger crNumOfWires;
    @XmlElement(name = "CR_SAP_Paper_Number")
    protected Long crsapPaperNumber;
    @XmlElement(name = "CR_Backing_Loose_Tight")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crBackingLooseTight;
    @XmlElement(name = "CR_Headband_Color")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crHeadbandColor;
    @XmlElement(name = "CR_JKT_Flap_Wd_Front")
    protected BigDecimal crjktFlapWdFront;
    @XmlElement(name = "CR_JKT_Flap_Wd_Back")
    protected BigDecimal crjktFlapWdBack;
    @XmlElement(name = "CR_Pad_Location")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String crPadLocation;
    @XmlElement(name = "Sheets_Qty")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger sheetsQty;
    @XmlElement(name = "WCSS_BOOK_WORK_TYPE_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssbookworktypecd;
    @XmlElement(name = "CR_BlankLocation")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crBlankLocation;
    @XmlElement(name = "CR_BlankType")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crBlankType;
    @XmlElement(name = "Seq_Numbered_Item_Details")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String seqNumberedItemDetails;
    @XmlElement(name = "Tab_Size")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String tabSize;
    @XmlElement(name = "Min_Order_Qty")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger minOrderQty;
    @XmlElement(name = "Multiple_Order_Qty")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger multipleOrderQty;
    @XmlElement(name = "Paper_Width")
    protected BigDecimal paperWidth;
    @XmlElement(name = "Paper_Length")
    protected BigDecimal paperLength;
    @XmlElement(name = "Tab_Num")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger tabNum;
    @XmlElement(name = "Box_Num")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger boxNum;
    @XmlElement(name = "Spine_Size")
    protected BigDecimal spineSize;
    @XmlElement(name = "Cloth_Size_Width")
    protected BigDecimal clothSizeWidth;
    @XmlElement(name = "Cloth_Size_Length")
    protected BigDecimal clothSizeLength;
    @XmlElement(name = "Board_Size_Width")
    protected BigDecimal boardSizeWidth;
    @XmlElement(name = "Board_Size_Length")
    protected BigDecimal boardSizeLength;
    @XmlElement(name = "Strip_Width")
    protected BigDecimal stripWidth;
    @XmlElement(name = "Strip_Length")
    protected BigDecimal stripLength;
    @XmlElement(name = "Split_Shipment")
    @XmlSchemaType(name = "token")
    protected TypeYesNo splitShipment;
    @XmlElement(name = "Seq_Numbered_Item")
    @XmlSchemaType(name = "token")
    protected TypeYesNo seqNumberedItem;
    @XmlElement(name = "Product_Code")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String productCode;
    @XmlElement(name = "Binder_Size")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String binderSize;
    @XmlElement(name = "Binder_Color")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String binderColor;
    @XmlElement(name = "Binder_Ring_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String binderRingType;
    @XmlElement(name = "Binder_Transparency")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String binderTransparency;
    @XmlElement(name = "Fold_At")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String foldAt;
    @XmlElement(name = "Extract_Spine")
    @XmlSchemaType(name = "token")
    protected TypeYesNo extractSpine;
    @XmlElement(name = "WCSS_ITEM_PROD_CLS_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssitemprodclscd;
    @XmlElement(name = "WCSS_ITEM_SKU_DS")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssitemskuds;
    @XmlElement(name = "WCSS_WORK_TYPE_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssworktypecd;
    @XmlElement(name = "CR_Imposition_Page_Width")
    protected BigDecimal crImpositionPageWidth;
    @XmlElement(name = "CR_Imposition_Page_Height")
    protected BigDecimal crImpositionPageHeight;
    @XmlElement(name = "CR_Imposition_Top_Margin")
    protected BigDecimal crImpositionTopMargin;
    @XmlElement(name = "CR_Imposition_Left_Margin")
    protected BigDecimal crImpositionLeftMargin;
    @XmlElement(name = "CR_Imposition_Horizontal_Gutter")
    protected BigDecimal crImpositionHorizontalGutter;
    @XmlElement(name = "CR_Imposition_Vertical_Gutter")
    protected BigDecimal crImpositionVerticalGutter;
    @XmlElement(name = "CR_Imposition_Has_Crop_Marks")
    @XmlSchemaType(name = "token")
    protected TypeYesNo crImpositionHasCropMarks;
    @XmlElement(name = "CR_Imposition_Images_Per_Sheet")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger crImpositionImagesPerSheet;
    @XmlElement(name = "WCSS_ITEM_LSN_LVL_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssitemlsnlvlcd;
    @XmlElement(name = "WCSS_ITEM_FORM_TYPE_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssitemformtypecd;
    @XmlElement(name = "WCSS_ITEM_DFLT_TAX_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssitemdflttaxcd;
    @XmlElement(name = "WCSS_HARM_TARIF_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssharmtarifcd;
    @XmlElement(name = "WCSS_LSN_OWNER_NM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcsslsnownernm;
    @XmlElement(name = "WCSS_COPYRIGHT_YR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcsscopyrightyr;
    @XmlElement(name = "WCSS_MASTER_DIVISION_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssmasterdivisionnr;
    @XmlElement(name = "WCSS_PRODUCT_SUFFIX_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssproductsuffixcd;
    @XmlElement(name = "WCSS_FG_KIT_ITEM_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssfgkititemnr;
    @XmlElement(name = "WCSS_BOM_KIT_ITEM_NR")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssbomkititemnr;
    @XmlElement(name = "WCSS_ITEM_RORDR_PT")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger wcssitemrordrpt;
    @XmlElement(name = "WCSS_ITEM_RORDR_QT")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger wcssitemrordrqt;
    @XmlElement(name = "WCSS_ITEM_THRSHLD_QT")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger wcssitemthrshldqt;
    @XmlElement(name = "WCSS_ITEM_NUM_PLIES_NR")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger wcssitemnumpliesnr;
    @XmlElement(name = "CR_Size_UOM")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crSizeUOM;
    @XmlElement(name = "WCSS_ITEM_SECURE_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitemsecurein;
    @XmlElement(name = "WCSS_ITEM_POD_TYPE_CD")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitempodtypecd;
    @XmlElement(name = "WCSS_ALLOW_TAX_CD_MAINT")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssallowtaxcdmaint;
    @XmlElement(name = "WCSS_ALLOW_TAX_USER_FLAG")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssallowtaxuserflag;
    @XmlElement(name = "WCSS_COMMIT_FUT_ORD_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcsscommitfutordin;
    @XmlElement(name = "WCSS_CMPNTS_INV_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcsscmpntsinvin;
    @XmlElement(name = "WCSS_CMPNTS_WITH_SPLIT_ORD")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcsscmpntswithsplitord;
    @XmlElement(name = "WCSS_OVRSIZ_ITM_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssovrsizitmin;
    @XmlElement(name = "WCSS_ITEM_UNUSUAL_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitemunusualin;
    @XmlElement(name = "WCSS_ITEM_HZRDS_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitemhzrdsin;
    @XmlElement(name = "WCSS_CANCEL_BO_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcsscancelboin;
    @XmlElement(name = "WCSS_ITEM_STATUS_CD")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitemstatuscd;
    @XmlElement(name = "WCSS_ITEM_TYPE_CD")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitemtypecd;
    @XmlElement(name = "WCSS_ITEM_CMPNT_ONLY_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitemcmpntonlyin;
    @XmlElement(name = "WCSS_ITEM_LASERMAX_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssitemlasermaxin;
    @XmlElement(name = "WCSS_ADTNL_MFG_DATA_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssadtnlmfgdatain;
    @XmlElement(name = "WCSS_KIT_ASMBLY_REQD_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcsskitasmblyreqdin;
    @XmlElement(name = "WCSS_VIRTUAL_MASTER_IN")
    @XmlSchemaType(name = "token")
    protected TypeYesNo wcssvirtualmasterin;
    @XmlElement(name = "WCSS_ITEM_NMBRNG_CD")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String wcssitemnmbrngcd;
    @XmlElement(name = "CR_IsCPSIA")
    protected Boolean crIsCPSIA;
    @XmlElement(name = "CR_ImagesPerRow")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger crImagesPerRow;
    @XmlElement(name = "CR_UseSaddleImpose")
    protected Boolean crUseSaddleImpose;
    @XmlElement(name = "CR_ScoringLocation")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crScoringLocation;
    @XmlElement(name = "CR_PerfLocation")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crPerfLocation;
    @XmlElement(name = "CR_Overage")
    protected BigDecimal crOverage;
    @XmlElement(name = "CR_Sample_Quantity")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger crSampleQuantity;
    @XmlElement(name = "CR_uvCoating")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crUvCoating;
    @XmlElement(name = "CR_Laminate_Location")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crLaminateLocation;
    @XmlElement(name = "CR_Laminate_Coating")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crLaminateCoating;
    @XmlElement(name = "CR_Laminate_Coverage")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crLaminateCoverage;
    @XmlElement(name = "CR_Laminate_Finish_Type")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crLaminateFinishType;
    @XmlElement(name = "CR_Laminate_Thickness")
    protected BigDecimal crLaminateThickness;
    @XmlElement(name = "CR_Bleed_Size")
    protected BigDecimal crBleedSize;
    @XmlElement(name = "CR_Carbonless_Imposition")
    protected Boolean crCarbonlessImposition;
    @XmlElement(name = "CR_Print_Spec_Comments")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String crPrintSpecComments;
    @XmlElement(name = "DAO_LU_Variable_Text_Configuration_ID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String daoluVariableTextConfigurationID;
    @XmlElement(name = "Comp_Mgd")
    protected Boolean compMgd;
    @XmlElement(name = "Comp_Num")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String compNum;
    @XmlElement(name = "Bill_To_Job_Default")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String billToJobDefault;
    @XmlElement(name = "ECP_Job_Default")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String ecpJobDefault;
    @XmlElement(name = "RARS_Workflow")
    protected Boolean rarsWorkflow;
    @XmlElement(name = "CR_Crop_Left")
    protected BigDecimal crCropLeft;
    @XmlElement(name = "CR_Crop_Right")
    protected BigDecimal crCropRight;
    @XmlElement(name = "CR_Crop_Top")
    protected BigDecimal crCropTop;
    @XmlElement(name = "CR_Crop_Bottom")
    protected BigDecimal crCropBottom;
    @XmlElement(name = "CR_Crop_Swap_On_Even_Pages")
    protected Boolean crCropSwapOnEvenPages;
    @XmlElement(name = "CR_Crop_File")
    protected Boolean crCropFile;
    @XmlElement(name = "Start_As_Draft")
    protected Boolean startAsDraft;
    @XmlElement(name = "Allow_CustomPoint_Skip")
    protected Boolean allowCustomPointSkip;
    @XmlElement(name = "ItemOnlyWorkflow")
    protected Boolean itemOnlyWorkflow;
    @XmlElement(name = "MD5_Cover")
    protected String md5Cover;
    @XmlElement(name = "MD5_Book")
    protected String md5Book;
    protected Boolean eDeliveryWorkflow;
    @XmlElement(name = "HWSProgramID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String hwsProgramID;
    @XmlElement(name = "No_PDF_JIT")
    protected Boolean noPDFJIT;
    @XmlElement(name = "ItemRef")
    protected List<TypeItemRef> itemRef;
    @XmlElement(name = "CDI")
    protected List<TypeCDI> cdi;
    @XmlElement(name = "ECreate")
    protected TypeECreate eCreate;
    @XmlElement(name = "CustomPoint")
    protected TypeCustomPoint customPoint;
    @XmlElement(name = "PageExceptions")
    protected List<TypePageException> pageExceptions;
    @XmlElement(name = "JobRef")
    protected List<TypeJobRef> jobRef;

    /**
     * Gets the value of the custItemNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustItemNum() {
        return custItemNum;
    }

    /**
     * Sets the value of the custItemNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustItemNum(String value) {
        this.custItemNum = value;
    }

    /**
     * Gets the value of the custItemNumReplaced property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustItemNumReplaced() {
        return custItemNumReplaced;
    }

    /**
     * Sets the value of the custItemNumReplaced property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustItemNumReplaced(String value) {
        this.custItemNumReplaced = value;
    }

    /**
     * Gets the value of the requestType property.
     * 
     * @return
     *     possible object is
     *     {@link TypeRequestType }
     *     
     */
    public TypeRequestType getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeRequestType }
     *     
     */
    public void setRequestType(TypeRequestType value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the bulkIDCust property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBulkIDCust() {
        return bulkIDCust;
    }

    /**
     * Sets the value of the bulkIDCust property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBulkIDCust(String value) {
        this.bulkIDCust = value;
    }

    /**
     * Gets the value of the isStandAloneItem property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getIsStandAloneItem() {
        return isStandAloneItem;
    }

    /**
     * Sets the value of the isStandAloneItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setIsStandAloneItem(TypeYesNo value) {
        this.isStandAloneItem = value;
    }

    /**
     * Gets the value of the isECreateItem property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getIsECreateItem() {
        return isECreateItem;
    }

    /**
     * Sets the value of the isECreateItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setIsECreateItem(TypeYesNo value) {
        this.isECreateItem = value;
    }

    /**
     * Gets the value of the isCSSItem property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getIsCSSItem() {
        return isCSSItem;
    }

    /**
     * Sets the value of the isCSSItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setIsCSSItem(TypeYesNo value) {
        this.isCSSItem = value;
    }

    /**
     * Gets the value of the isJIT property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsJIT() {
        return isJIT;
    }

    /**
     * Sets the value of the isJIT property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsJIT(Boolean value) {
        this.isJIT = value;
    }

    /**
     * Gets the value of the isECreate property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsECreate() {
        return isECreate;
    }

    /**
     * Sets the value of the isECreate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsECreate(Boolean value) {
        this.isECreate = value;
    }

    /**
     * Gets the value of the isCSS property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsCSS() {
        return isCSS;
    }

    /**
     * Sets the value of the isCSS property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsCSS(Boolean value) {
        this.isCSS = value;
    }

    /**
     * Gets the value of the changeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangeType() {
        return changeType;
    }

    /**
     * Sets the value of the changeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangeType(String value) {
        this.changeType = value;
    }

    /**
     * Gets the value of the customerUID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerUID() {
        return customerUID;
    }

    /**
     * Sets the value of the customerUID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerUID(String value) {
        this.customerUID = value;
    }

    /**
     * Gets the value of the contactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets the value of the contactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactName(String value) {
        this.contactName = value;
    }

    /**
     * Gets the value of the contactEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactEmail() {
        return contactEmail;
    }

    /**
     * Sets the value of the contactEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactEmail(String value) {
        this.contactEmail = value;
    }

    /**
     * Gets the value of the omsDescr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOMSDescr() {
        return omsDescr;
    }

    /**
     * Sets the value of the omsDescr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOMSDescr(String value) {
        this.omsDescr = value;
    }

    /**
     * Gets the value of the wcssItemNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSItemNum() {
        return wcssItemNum;
    }

    /**
     * Sets the value of the wcssItemNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSItemNum(String value) {
        this.wcssItemNum = value;
    }

    /**
     * Gets the value of the wcssItemNumMaster property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSItemNumMaster() {
        return wcssItemNumMaster;
    }

    /**
     * Sets the value of the wcssItemNumMaster property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSItemNumMaster(String value) {
        this.wcssItemNumMaster = value;
    }

    /**
     * Gets the value of the wcssItemDescr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSItemDescr() {
        return wcssItemDescr;
    }

    /**
     * Sets the value of the wcssItemDescr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSItemDescr(String value) {
        this.wcssItemDescr = value;
    }

    /**
     * Gets the value of the coverType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoverType() {
        return coverType;
    }

    /**
     * Sets the value of the coverType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoverType(String value) {
        this.coverType = value;
    }

    /**
     * Gets the value of the packagingUOM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPackagingUOM() {
        return packagingUOM;
    }

    /**
     * Sets the value of the packagingUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPackagingUOM(String value) {
        this.packagingUOM = value;
    }

    /**
     * Gets the value of the packagingQty property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPackagingQty() {
        return packagingQty;
    }

    /**
     * Sets the value of the packagingQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPackagingQty(BigInteger value) {
        this.packagingQty = value;
    }

    /**
     * Gets the value of the revision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevision() {
        return revision;
    }

    /**
     * Sets the value of the revision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevision(String value) {
        this.revision = value;
    }

    /**
     * Gets the value of the maxOrderQtyWCSS property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMaxOrderQtyWCSS() {
        return maxOrderQtyWCSS;
    }

    /**
     * Sets the value of the maxOrderQtyWCSS property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMaxOrderQtyWCSS(BigInteger value) {
        this.maxOrderQtyWCSS = value;
    }

    /**
     * Gets the value of the itemCat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemCat() {
        return itemCat;
    }

    /**
     * Sets the value of the itemCat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemCat(String value) {
        this.itemCat = value;
    }

    /**
     * Gets the value of the itemSubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemSubType() {
        return itemSubType;
    }

    /**
     * Sets the value of the itemSubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemSubType(String value) {
        this.itemSubType = value;
    }

    /**
     * Gets the value of the orientation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrientation() {
        return orientation;
    }

    /**
     * Sets the value of the orientation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrientation(String value) {
        this.orientation = value;
    }

    /**
     * Gets the value of the sidesPrinted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSidesPrinted() {
        return sidesPrinted;
    }

    /**
     * Sets the value of the sidesPrinted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSidesPrinted(String value) {
        this.sidesPrinted = value;
    }

    /**
     * Gets the value of the pageQty property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPageQty() {
        return pageQty;
    }

    /**
     * Sets the value of the pageQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPageQty(BigInteger value) {
        this.pageQty = value;
    }

    /**
     * Gets the value of the pageQtyImposed property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPageQtyImposed() {
        return pageQtyImposed;
    }

    /**
     * Sets the value of the pageQtyImposed property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPageQtyImposed(BigInteger value) {
        this.pageQtyImposed = value;
    }

    /**
     * Gets the value of the paperStockType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperStockType() {
        return paperStockType;
    }

    /**
     * Sets the value of the paperStockType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperStockType(String value) {
        this.paperStockType = value;
    }

    /**
     * Gets the value of the paperStockWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperStockWeight() {
        return paperStockWeight;
    }

    /**
     * Sets the value of the paperStockWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperStockWeight(String value) {
        this.paperStockWeight = value;
    }

    /**
     * Gets the value of the paperStockColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaperStockColor() {
        return paperStockColor;
    }

    /**
     * Sets the value of the paperStockColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaperStockColor(String value) {
        this.paperStockColor = value;
    }

    /**
     * Gets the value of the stackOffset property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStackOffset() {
        return stackOffset;
    }

    /**
     * Sets the value of the stackOffset property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStackOffset(String value) {
        this.stackOffset = value;
    }

    /**
     * Gets the value of the thermalTapeColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThermalTapeColor() {
        return thermalTapeColor;
    }

    /**
     * Sets the value of the thermalTapeColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThermalTapeColor(String value) {
        this.thermalTapeColor = value;
    }

    /**
     * Gets the value of the trimSizeWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTrimSizeWidth() {
        return trimSizeWidth;
    }

    /**
     * Sets the value of the trimSizeWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTrimSizeWidth(BigDecimal value) {
        this.trimSizeWidth = value;
    }

    /**
     * Gets the value of the trimSizeLength property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTrimSizeLength() {
        return trimSizeLength;
    }

    /**
     * Sets the value of the trimSizeLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTrimSizeLength(BigDecimal value) {
        this.trimSizeLength = value;
    }

    /**
     * Gets the value of the stitchingLoc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStitchingLoc() {
        return stitchingLoc;
    }

    /**
     * Sets the value of the stitchingLoc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStitchingLoc(String value) {
        this.stitchingLoc = value;
    }

    /**
     * Gets the value of the drillingSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrillingSize() {
        return drillingSize;
    }

    /**
     * Sets the value of the drillingSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrillingSize(String value) {
        this.drillingSize = value;
    }

    /**
     * Gets the value of the drillingLoc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrillingLoc() {
        return drillingLoc;
    }

    /**
     * Sets the value of the drillingLoc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrillingLoc(String value) {
        this.drillingLoc = value;
    }

    /**
     * Gets the value of the glueLoc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGlueLoc() {
        return glueLoc;
    }

    /**
     * Sets the value of the glueLoc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGlueLoc(String value) {
        this.glueLoc = value;
    }

    /**
     * Gets the value of the padNum property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPadNum() {
        return padNum;
    }

    /**
     * Sets the value of the padNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPadNum(BigInteger value) {
        this.padNum = value;
    }

    /**
     * Gets the value of the foldType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFoldType() {
        return foldType;
    }

    /**
     * Sets the value of the foldType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFoldType(String value) {
        this.foldType = value;
    }

    /**
     * Gets the value of the polyNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolyNum() {
        return polyNum;
    }

    /**
     * Sets the value of the polyNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolyNum(String value) {
        this.polyNum = value;
    }

    /**
     * Gets the value of the pageWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPageWidth() {
        return pageWidth;
    }

    /**
     * Sets the value of the pageWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPageWidth(BigDecimal value) {
        this.pageWidth = value;
    }

    /**
     * Gets the value of the pageLength property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPageLength() {
        return pageLength;
    }

    /**
     * Sets the value of the pageLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPageLength(BigDecimal value) {
        this.pageLength = value;
    }

    /**
     * Gets the value of the inkColors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInkColors() {
        return inkColors;
    }

    /**
     * Sets the value of the inkColors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInkColors(String value) {
        this.inkColors = value;
    }

    /**
     * Gets the value of the bleeds property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBleeds() {
        return bleeds;
    }

    /**
     * Sets the value of the bleeds property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBleeds(String value) {
        this.bleeds = value;
    }

    /**
     * Gets the value of the pdfFilename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDFFilename() {
        return pdfFilename;
    }

    /**
     * Sets the value of the pdfFilename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDFFilename(String value) {
        this.pdfFilename = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Gets the value of the initSpecCSRApprNeeded property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitSpecCSRApprNeeded() {
        return initSpecCSRApprNeeded;
    }

    /**
     * Sets the value of the initSpecCSRApprNeeded property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitSpecCSRApprNeeded(String value) {
        this.initSpecCSRApprNeeded = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Sets the value of the author property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthor(String value) {
        this.author = value;
    }

    /**
     * Gets the value of the bookTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBookTitle() {
        return bookTitle;
    }

    /**
     * Sets the value of the bookTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBookTitle(String value) {
        this.bookTitle = value;
    }

    /**
     * Gets the value of the crSpineRounding property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRSpineRounding() {
        return crSpineRounding;
    }

    /**
     * Sets the value of the crSpineRounding property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRSpineRounding(String value) {
        this.crSpineRounding = value;
    }

    /**
     * Gets the value of the crHeadBandRequired property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRHeadBandRequired() {
        return crHeadBandRequired;
    }

    /**
     * Sets the value of the crHeadBandRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRHeadBandRequired(String value) {
        this.crHeadBandRequired = value;
    }

    /**
     * Gets the value of the crFoilStampPositionCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRFoilStampPositionCd() {
        return crFoilStampPositionCd;
    }

    /**
     * Sets the value of the crFoilStampPositionCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRFoilStampPositionCd(String value) {
        this.crFoilStampPositionCd = value;
    }

    /**
     * Gets the value of the crFoilColorCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRFoilColorCd() {
        return crFoilColorCd;
    }

    /**
     * Sets the value of the crFoilColorCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRFoilColorCd(String value) {
        this.crFoilColorCd = value;
    }

    /**
     * Gets the value of the crClothCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRClothCd() {
        return crClothCd;
    }

    /**
     * Sets the value of the crClothCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRClothCd(String value) {
        this.crClothCd = value;
    }

    /**
     * Gets the value of the crLaminateCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRLaminateCd() {
        return crLaminateCd;
    }

    /**
     * Sets the value of the crLaminateCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRLaminateCd(String value) {
        this.crLaminateCd = value;
    }

    /**
     * Gets the value of the crCardboardCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRCardboardCd() {
        return crCardboardCd;
    }

    /**
     * Sets the value of the crCardboardCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRCardboardCd(String value) {
        this.crCardboardCd = value;
    }

    /**
     * Gets the value of the crEndPaperCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREndPaperCd() {
        return crEndPaperCd;
    }

    /**
     * Sets the value of the crEndPaperCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREndPaperCd(String value) {
        this.crEndPaperCd = value;
    }

    /**
     * Gets the value of the preImposed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreImposed() {
        return preImposed;
    }

    /**
     * Sets the value of the preImposed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreImposed(String value) {
        this.preImposed = value;
    }

    /**
     * Gets the value of the wcssisbn10NR property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSISBN10NR() {
        return wcssisbn10NR;
    }

    /**
     * Sets the value of the wcssisbn10NR property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSISBN10NR(String value) {
        this.wcssisbn10NR = value;
    }

    /**
     * Gets the value of the wcssisbn13NR property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSISBN13NR() {
        return wcssisbn13NR;
    }

    /**
     * Sets the value of the wcssisbn13NR property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSISBN13NR(String value) {
        this.wcssisbn13NR = value;
    }

    /**
     * Gets the value of the wcssbookpublisher property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSBOOKPUBLISHER() {
        return wcssbookpublisher;
    }

    /**
     * Sets the value of the wcssbookpublisher property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSBOOKPUBLISHER(String value) {
        this.wcssbookpublisher = value;
    }

    /**
     * Gets the value of the wcssbookuscvrprc property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWCSSBOOKUSCVRPRC() {
        return wcssbookuscvrprc;
    }

    /**
     * Sets the value of the wcssbookuscvrprc property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWCSSBOOKUSCVRPRC(BigDecimal value) {
        this.wcssbookuscvrprc = value;
    }

    /**
     * Gets the value of the wcssbookcncvrprc property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWCSSBOOKCNCVRPRC() {
        return wcssbookcncvrprc;
    }

    /**
     * Sets the value of the wcssbookcncvrprc property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWCSSBOOKCNCVRPRC(BigDecimal value) {
        this.wcssbookcncvrprc = value;
    }

    /**
     * Gets the value of the wcssUpgradeItemText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSUpgradeItemText() {
        return wcssUpgradeItemText;
    }

    /**
     * Sets the value of the wcssUpgradeItemText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSUpgradeItemText(String value) {
        this.wcssUpgradeItemText = value;
    }

    /**
     * Gets the value of the crHeadMargin property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRHeadMargin() {
        return crHeadMargin;
    }

    /**
     * Sets the value of the crHeadMargin property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRHeadMargin(BigDecimal value) {
        this.crHeadMargin = value;
    }

    /**
     * Gets the value of the crGutterMargin property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRGutterMargin() {
        return crGutterMargin;
    }

    /**
     * Sets the value of the crGutterMargin property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRGutterMargin(BigDecimal value) {
        this.crGutterMargin = value;
    }

    /**
     * Gets the value of the crNumOfWires property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCRNumOfWires() {
        return crNumOfWires;
    }

    /**
     * Sets the value of the crNumOfWires property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCRNumOfWires(BigInteger value) {
        this.crNumOfWires = value;
    }

    /**
     * Gets the value of the crsapPaperNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCRSAPPaperNumber() {
        return crsapPaperNumber;
    }

    /**
     * Sets the value of the crsapPaperNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCRSAPPaperNumber(Long value) {
        this.crsapPaperNumber = value;
    }

    /**
     * Gets the value of the crBackingLooseTight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRBackingLooseTight() {
        return crBackingLooseTight;
    }

    /**
     * Sets the value of the crBackingLooseTight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRBackingLooseTight(String value) {
        this.crBackingLooseTight = value;
    }

    /**
     * Gets the value of the crHeadbandColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRHeadbandColor() {
        return crHeadbandColor;
    }

    /**
     * Sets the value of the crHeadbandColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRHeadbandColor(String value) {
        this.crHeadbandColor = value;
    }

    /**
     * Gets the value of the crjktFlapWdFront property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRJKTFlapWdFront() {
        return crjktFlapWdFront;
    }

    /**
     * Sets the value of the crjktFlapWdFront property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRJKTFlapWdFront(BigDecimal value) {
        this.crjktFlapWdFront = value;
    }

    /**
     * Gets the value of the crjktFlapWdBack property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRJKTFlapWdBack() {
        return crjktFlapWdBack;
    }

    /**
     * Sets the value of the crjktFlapWdBack property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRJKTFlapWdBack(BigDecimal value) {
        this.crjktFlapWdBack = value;
    }

    /**
     * Gets the value of the crPadLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRPadLocation() {
        return crPadLocation;
    }

    /**
     * Sets the value of the crPadLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRPadLocation(String value) {
        this.crPadLocation = value;
    }

    /**
     * Gets the value of the sheetsQty property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getSheetsQty() {
        return sheetsQty;
    }

    /**
     * Sets the value of the sheetsQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setSheetsQty(BigInteger value) {
        this.sheetsQty = value;
    }

    /**
     * Gets the value of the wcssbookworktypecd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSBOOKWORKTYPECD() {
        return wcssbookworktypecd;
    }

    /**
     * Sets the value of the wcssbookworktypecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSBOOKWORKTYPECD(String value) {
        this.wcssbookworktypecd = value;
    }

    /**
     * Gets the value of the crBlankLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRBlankLocation() {
        return crBlankLocation;
    }

    /**
     * Sets the value of the crBlankLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRBlankLocation(String value) {
        this.crBlankLocation = value;
    }

    /**
     * Gets the value of the crBlankType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRBlankType() {
        return crBlankType;
    }

    /**
     * Sets the value of the crBlankType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRBlankType(String value) {
        this.crBlankType = value;
    }

    /**
     * Gets the value of the seqNumberedItemDetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNumberedItemDetails() {
        return seqNumberedItemDetails;
    }

    /**
     * Sets the value of the seqNumberedItemDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNumberedItemDetails(String value) {
        this.seqNumberedItemDetails = value;
    }

    /**
     * Gets the value of the tabSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTabSize() {
        return tabSize;
    }

    /**
     * Sets the value of the tabSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTabSize(String value) {
        this.tabSize = value;
    }

    /**
     * Gets the value of the minOrderQty property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMinOrderQty() {
        return minOrderQty;
    }

    /**
     * Sets the value of the minOrderQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMinOrderQty(BigInteger value) {
        this.minOrderQty = value;
    }

    /**
     * Gets the value of the multipleOrderQty property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMultipleOrderQty() {
        return multipleOrderQty;
    }

    /**
     * Sets the value of the multipleOrderQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMultipleOrderQty(BigInteger value) {
        this.multipleOrderQty = value;
    }

    /**
     * Gets the value of the paperWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPaperWidth() {
        return paperWidth;
    }

    /**
     * Sets the value of the paperWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPaperWidth(BigDecimal value) {
        this.paperWidth = value;
    }

    /**
     * Gets the value of the paperLength property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPaperLength() {
        return paperLength;
    }

    /**
     * Sets the value of the paperLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPaperLength(BigDecimal value) {
        this.paperLength = value;
    }

    /**
     * Gets the value of the tabNum property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTabNum() {
        return tabNum;
    }

    /**
     * Sets the value of the tabNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTabNum(BigInteger value) {
        this.tabNum = value;
    }

    /**
     * Gets the value of the boxNum property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBoxNum() {
        return boxNum;
    }

    /**
     * Sets the value of the boxNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBoxNum(BigInteger value) {
        this.boxNum = value;
    }

    /**
     * Gets the value of the spineSize property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSpineSize() {
        return spineSize;
    }

    /**
     * Sets the value of the spineSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSpineSize(BigDecimal value) {
        this.spineSize = value;
    }

    /**
     * Gets the value of the clothSizeWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getClothSizeWidth() {
        return clothSizeWidth;
    }

    /**
     * Sets the value of the clothSizeWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setClothSizeWidth(BigDecimal value) {
        this.clothSizeWidth = value;
    }

    /**
     * Gets the value of the clothSizeLength property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getClothSizeLength() {
        return clothSizeLength;
    }

    /**
     * Sets the value of the clothSizeLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setClothSizeLength(BigDecimal value) {
        this.clothSizeLength = value;
    }

    /**
     * Gets the value of the boardSizeWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBoardSizeWidth() {
        return boardSizeWidth;
    }

    /**
     * Sets the value of the boardSizeWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBoardSizeWidth(BigDecimal value) {
        this.boardSizeWidth = value;
    }

    /**
     * Gets the value of the boardSizeLength property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBoardSizeLength() {
        return boardSizeLength;
    }

    /**
     * Sets the value of the boardSizeLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBoardSizeLength(BigDecimal value) {
        this.boardSizeLength = value;
    }

    /**
     * Gets the value of the stripWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getStripWidth() {
        return stripWidth;
    }

    /**
     * Sets the value of the stripWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setStripWidth(BigDecimal value) {
        this.stripWidth = value;
    }

    /**
     * Gets the value of the stripLength property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getStripLength() {
        return stripLength;
    }

    /**
     * Sets the value of the stripLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setStripLength(BigDecimal value) {
        this.stripLength = value;
    }

    /**
     * Gets the value of the splitShipment property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getSplitShipment() {
        return splitShipment;
    }

    /**
     * Sets the value of the splitShipment property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setSplitShipment(TypeYesNo value) {
        this.splitShipment = value;
    }

    /**
     * Gets the value of the seqNumberedItem property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getSeqNumberedItem() {
        return seqNumberedItem;
    }

    /**
     * Sets the value of the seqNumberedItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setSeqNumberedItem(TypeYesNo value) {
        this.seqNumberedItem = value;
    }

    /**
     * Gets the value of the productCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Sets the value of the productCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCode(String value) {
        this.productCode = value;
    }

    /**
     * Gets the value of the binderSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBinderSize() {
        return binderSize;
    }

    /**
     * Sets the value of the binderSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBinderSize(String value) {
        this.binderSize = value;
    }

    /**
     * Gets the value of the binderColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBinderColor() {
        return binderColor;
    }

    /**
     * Sets the value of the binderColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBinderColor(String value) {
        this.binderColor = value;
    }

    /**
     * Gets the value of the binderRingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBinderRingType() {
        return binderRingType;
    }

    /**
     * Sets the value of the binderRingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBinderRingType(String value) {
        this.binderRingType = value;
    }

    /**
     * Gets the value of the binderTransparency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBinderTransparency() {
        return binderTransparency;
    }

    /**
     * Sets the value of the binderTransparency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBinderTransparency(String value) {
        this.binderTransparency = value;
    }

    /**
     * Gets the value of the foldAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFoldAt() {
        return foldAt;
    }

    /**
     * Sets the value of the foldAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFoldAt(String value) {
        this.foldAt = value;
    }

    /**
     * Gets the value of the extractSpine property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getExtractSpine() {
        return extractSpine;
    }

    /**
     * Sets the value of the extractSpine property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setExtractSpine(TypeYesNo value) {
        this.extractSpine = value;
    }

    /**
     * Gets the value of the wcssitemprodclscd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSITEMPRODCLSCD() {
        return wcssitemprodclscd;
    }

    /**
     * Sets the value of the wcssitemprodclscd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSITEMPRODCLSCD(String value) {
        this.wcssitemprodclscd = value;
    }

    /**
     * Gets the value of the wcssitemskuds property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSITEMSKUDS() {
        return wcssitemskuds;
    }

    /**
     * Sets the value of the wcssitemskuds property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSITEMSKUDS(String value) {
        this.wcssitemskuds = value;
    }

    /**
     * Gets the value of the wcssworktypecd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSWORKTYPECD() {
        return wcssworktypecd;
    }

    /**
     * Sets the value of the wcssworktypecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSWORKTYPECD(String value) {
        this.wcssworktypecd = value;
    }

    /**
     * Gets the value of the crImpositionPageWidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRImpositionPageWidth() {
        return crImpositionPageWidth;
    }

    /**
     * Sets the value of the crImpositionPageWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRImpositionPageWidth(BigDecimal value) {
        this.crImpositionPageWidth = value;
    }

    /**
     * Gets the value of the crImpositionPageHeight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRImpositionPageHeight() {
        return crImpositionPageHeight;
    }

    /**
     * Sets the value of the crImpositionPageHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRImpositionPageHeight(BigDecimal value) {
        this.crImpositionPageHeight = value;
    }

    /**
     * Gets the value of the crImpositionTopMargin property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRImpositionTopMargin() {
        return crImpositionTopMargin;
    }

    /**
     * Sets the value of the crImpositionTopMargin property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRImpositionTopMargin(BigDecimal value) {
        this.crImpositionTopMargin = value;
    }

    /**
     * Gets the value of the crImpositionLeftMargin property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRImpositionLeftMargin() {
        return crImpositionLeftMargin;
    }

    /**
     * Sets the value of the crImpositionLeftMargin property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRImpositionLeftMargin(BigDecimal value) {
        this.crImpositionLeftMargin = value;
    }

    /**
     * Gets the value of the crImpositionHorizontalGutter property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRImpositionHorizontalGutter() {
        return crImpositionHorizontalGutter;
    }

    /**
     * Sets the value of the crImpositionHorizontalGutter property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRImpositionHorizontalGutter(BigDecimal value) {
        this.crImpositionHorizontalGutter = value;
    }

    /**
     * Gets the value of the crImpositionVerticalGutter property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRImpositionVerticalGutter() {
        return crImpositionVerticalGutter;
    }

    /**
     * Sets the value of the crImpositionVerticalGutter property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRImpositionVerticalGutter(BigDecimal value) {
        this.crImpositionVerticalGutter = value;
    }

    /**
     * Gets the value of the crImpositionHasCropMarks property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getCRImpositionHasCropMarks() {
        return crImpositionHasCropMarks;
    }

    /**
     * Sets the value of the crImpositionHasCropMarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setCRImpositionHasCropMarks(TypeYesNo value) {
        this.crImpositionHasCropMarks = value;
    }

    /**
     * Gets the value of the crImpositionImagesPerSheet property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCRImpositionImagesPerSheet() {
        return crImpositionImagesPerSheet;
    }

    /**
     * Sets the value of the crImpositionImagesPerSheet property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCRImpositionImagesPerSheet(BigInteger value) {
        this.crImpositionImagesPerSheet = value;
    }

    /**
     * Gets the value of the wcssitemlsnlvlcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSITEMLSNLVLCD() {
        return wcssitemlsnlvlcd;
    }

    /**
     * Sets the value of the wcssitemlsnlvlcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSITEMLSNLVLCD(String value) {
        this.wcssitemlsnlvlcd = value;
    }

    /**
     * Gets the value of the wcssitemformtypecd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSITEMFORMTYPECD() {
        return wcssitemformtypecd;
    }

    /**
     * Sets the value of the wcssitemformtypecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSITEMFORMTYPECD(String value) {
        this.wcssitemformtypecd = value;
    }

    /**
     * Gets the value of the wcssitemdflttaxcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSITEMDFLTTAXCD() {
        return wcssitemdflttaxcd;
    }

    /**
     * Sets the value of the wcssitemdflttaxcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSITEMDFLTTAXCD(String value) {
        this.wcssitemdflttaxcd = value;
    }

    /**
     * Gets the value of the wcssharmtarifcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSHARMTARIFCD() {
        return wcssharmtarifcd;
    }

    /**
     * Sets the value of the wcssharmtarifcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSHARMTARIFCD(String value) {
        this.wcssharmtarifcd = value;
    }

    /**
     * Gets the value of the wcsslsnownernm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSLSNOWNERNM() {
        return wcsslsnownernm;
    }

    /**
     * Sets the value of the wcsslsnownernm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSLSNOWNERNM(String value) {
        this.wcsslsnownernm = value;
    }

    /**
     * Gets the value of the wcsscopyrightyr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSCOPYRIGHTYR() {
        return wcsscopyrightyr;
    }

    /**
     * Sets the value of the wcsscopyrightyr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSCOPYRIGHTYR(String value) {
        this.wcsscopyrightyr = value;
    }

    /**
     * Gets the value of the wcssmasterdivisionnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSMASTERDIVISIONNR() {
        return wcssmasterdivisionnr;
    }

    /**
     * Sets the value of the wcssmasterdivisionnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSMASTERDIVISIONNR(String value) {
        this.wcssmasterdivisionnr = value;
    }

    /**
     * Gets the value of the wcssproductsuffixcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSPRODUCTSUFFIXCD() {
        return wcssproductsuffixcd;
    }

    /**
     * Sets the value of the wcssproductsuffixcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSPRODUCTSUFFIXCD(String value) {
        this.wcssproductsuffixcd = value;
    }

    /**
     * Gets the value of the wcssfgkititemnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSFGKITITEMNR() {
        return wcssfgkititemnr;
    }

    /**
     * Sets the value of the wcssfgkititemnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSFGKITITEMNR(String value) {
        this.wcssfgkititemnr = value;
    }

    /**
     * Gets the value of the wcssbomkititemnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSBOMKITITEMNR() {
        return wcssbomkititemnr;
    }

    /**
     * Sets the value of the wcssbomkititemnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSBOMKITITEMNR(String value) {
        this.wcssbomkititemnr = value;
    }

    /**
     * Gets the value of the wcssitemrordrpt property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getWCSSITEMRORDRPT() {
        return wcssitemrordrpt;
    }

    /**
     * Sets the value of the wcssitemrordrpt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setWCSSITEMRORDRPT(BigInteger value) {
        this.wcssitemrordrpt = value;
    }

    /**
     * Gets the value of the wcssitemrordrqt property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getWCSSITEMRORDRQT() {
        return wcssitemrordrqt;
    }

    /**
     * Sets the value of the wcssitemrordrqt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setWCSSITEMRORDRQT(BigInteger value) {
        this.wcssitemrordrqt = value;
    }

    /**
     * Gets the value of the wcssitemthrshldqt property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getWCSSITEMTHRSHLDQT() {
        return wcssitemthrshldqt;
    }

    /**
     * Sets the value of the wcssitemthrshldqt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setWCSSITEMTHRSHLDQT(BigInteger value) {
        this.wcssitemthrshldqt = value;
    }

    /**
     * Gets the value of the wcssitemnumpliesnr property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getWCSSITEMNUMPLIESNR() {
        return wcssitemnumpliesnr;
    }

    /**
     * Sets the value of the wcssitemnumpliesnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setWCSSITEMNUMPLIESNR(BigInteger value) {
        this.wcssitemnumpliesnr = value;
    }

    /**
     * Gets the value of the crSizeUOM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRSizeUOM() {
        return crSizeUOM;
    }

    /**
     * Sets the value of the crSizeUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRSizeUOM(String value) {
        this.crSizeUOM = value;
    }

    /**
     * Gets the value of the wcssitemsecurein property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMSECUREIN() {
        return wcssitemsecurein;
    }

    /**
     * Sets the value of the wcssitemsecurein property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMSECUREIN(TypeYesNo value) {
        this.wcssitemsecurein = value;
    }

    /**
     * Gets the value of the wcssitempodtypecd property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMPODTYPECD() {
        return wcssitempodtypecd;
    }

    /**
     * Sets the value of the wcssitempodtypecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMPODTYPECD(TypeYesNo value) {
        this.wcssitempodtypecd = value;
    }

    /**
     * Gets the value of the wcssallowtaxcdmaint property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSALLOWTAXCDMAINT() {
        return wcssallowtaxcdmaint;
    }

    /**
     * Sets the value of the wcssallowtaxcdmaint property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSALLOWTAXCDMAINT(TypeYesNo value) {
        this.wcssallowtaxcdmaint = value;
    }

    /**
     * Gets the value of the wcssallowtaxuserflag property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSALLOWTAXUSERFLAG() {
        return wcssallowtaxuserflag;
    }

    /**
     * Sets the value of the wcssallowtaxuserflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSALLOWTAXUSERFLAG(TypeYesNo value) {
        this.wcssallowtaxuserflag = value;
    }

    /**
     * Gets the value of the wcsscommitfutordin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSCOMMITFUTORDIN() {
        return wcsscommitfutordin;
    }

    /**
     * Sets the value of the wcsscommitfutordin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSCOMMITFUTORDIN(TypeYesNo value) {
        this.wcsscommitfutordin = value;
    }

    /**
     * Gets the value of the wcsscmpntsinvin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSCMPNTSINVIN() {
        return wcsscmpntsinvin;
    }

    /**
     * Sets the value of the wcsscmpntsinvin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSCMPNTSINVIN(TypeYesNo value) {
        this.wcsscmpntsinvin = value;
    }

    /**
     * Gets the value of the wcsscmpntswithsplitord property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSCMPNTSWITHSPLITORD() {
        return wcsscmpntswithsplitord;
    }

    /**
     * Sets the value of the wcsscmpntswithsplitord property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSCMPNTSWITHSPLITORD(TypeYesNo value) {
        this.wcsscmpntswithsplitord = value;
    }

    /**
     * Gets the value of the wcssovrsizitmin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSOVRSIZITMIN() {
        return wcssovrsizitmin;
    }

    /**
     * Sets the value of the wcssovrsizitmin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSOVRSIZITMIN(TypeYesNo value) {
        this.wcssovrsizitmin = value;
    }

    /**
     * Gets the value of the wcssitemunusualin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMUNUSUALIN() {
        return wcssitemunusualin;
    }

    /**
     * Sets the value of the wcssitemunusualin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMUNUSUALIN(TypeYesNo value) {
        this.wcssitemunusualin = value;
    }

    /**
     * Gets the value of the wcssitemhzrdsin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMHZRDSIN() {
        return wcssitemhzrdsin;
    }

    /**
     * Sets the value of the wcssitemhzrdsin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMHZRDSIN(TypeYesNo value) {
        this.wcssitemhzrdsin = value;
    }

    /**
     * Gets the value of the wcsscancelboin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSCANCELBOIN() {
        return wcsscancelboin;
    }

    /**
     * Sets the value of the wcsscancelboin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSCANCELBOIN(TypeYesNo value) {
        this.wcsscancelboin = value;
    }

    /**
     * Gets the value of the wcssitemstatuscd property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMSTATUSCD() {
        return wcssitemstatuscd;
    }

    /**
     * Sets the value of the wcssitemstatuscd property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMSTATUSCD(TypeYesNo value) {
        this.wcssitemstatuscd = value;
    }

    /**
     * Gets the value of the wcssitemtypecd property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMTYPECD() {
        return wcssitemtypecd;
    }

    /**
     * Sets the value of the wcssitemtypecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMTYPECD(TypeYesNo value) {
        this.wcssitemtypecd = value;
    }

    /**
     * Gets the value of the wcssitemcmpntonlyin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMCMPNTONLYIN() {
        return wcssitemcmpntonlyin;
    }

    /**
     * Sets the value of the wcssitemcmpntonlyin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMCMPNTONLYIN(TypeYesNo value) {
        this.wcssitemcmpntonlyin = value;
    }

    /**
     * Gets the value of the wcssitemlasermaxin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSITEMLASERMAXIN() {
        return wcssitemlasermaxin;
    }

    /**
     * Sets the value of the wcssitemlasermaxin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSITEMLASERMAXIN(TypeYesNo value) {
        this.wcssitemlasermaxin = value;
    }

    /**
     * Gets the value of the wcssadtnlmfgdatain property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSADTNLMFGDATAIN() {
        return wcssadtnlmfgdatain;
    }

    /**
     * Sets the value of the wcssadtnlmfgdatain property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSADTNLMFGDATAIN(TypeYesNo value) {
        this.wcssadtnlmfgdatain = value;
    }

    /**
     * Gets the value of the wcsskitasmblyreqdin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSKITASMBLYREQDIN() {
        return wcsskitasmblyreqdin;
    }

    /**
     * Sets the value of the wcsskitasmblyreqdin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSKITASMBLYREQDIN(TypeYesNo value) {
        this.wcsskitasmblyreqdin = value;
    }

    /**
     * Gets the value of the wcssvirtualmasterin property.
     * 
     * @return
     *     possible object is
     *     {@link TypeYesNo }
     *     
     */
    public TypeYesNo getWCSSVIRTUALMASTERIN() {
        return wcssvirtualmasterin;
    }

    /**
     * Sets the value of the wcssvirtualmasterin property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeYesNo }
     *     
     */
    public void setWCSSVIRTUALMASTERIN(TypeYesNo value) {
        this.wcssvirtualmasterin = value;
    }

    /**
     * Gets the value of the wcssitemnmbrngcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWCSSITEMNMBRNGCD() {
        return wcssitemnmbrngcd;
    }

    /**
     * Sets the value of the wcssitemnmbrngcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWCSSITEMNMBRNGCD(String value) {
        this.wcssitemnmbrngcd = value;
    }

    /**
     * Gets the value of the crIsCPSIA property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCRIsCPSIA() {
        return crIsCPSIA;
    }

    /**
     * Sets the value of the crIsCPSIA property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCRIsCPSIA(Boolean value) {
        this.crIsCPSIA = value;
    }

    /**
     * Gets the value of the crImagesPerRow property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCRImagesPerRow() {
        return crImagesPerRow;
    }

    /**
     * Sets the value of the crImagesPerRow property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCRImagesPerRow(BigInteger value) {
        this.crImagesPerRow = value;
    }

    /**
     * Gets the value of the crUseSaddleImpose property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCRUseSaddleImpose() {
        return crUseSaddleImpose;
    }

    /**
     * Sets the value of the crUseSaddleImpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCRUseSaddleImpose(Boolean value) {
        this.crUseSaddleImpose = value;
    }

    /**
     * Gets the value of the crScoringLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRScoringLocation() {
        return crScoringLocation;
    }

    /**
     * Sets the value of the crScoringLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRScoringLocation(String value) {
        this.crScoringLocation = value;
    }

    /**
     * Gets the value of the crPerfLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRPerfLocation() {
        return crPerfLocation;
    }

    /**
     * Sets the value of the crPerfLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRPerfLocation(String value) {
        this.crPerfLocation = value;
    }

    /**
     * Gets the value of the crOverage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCROverage() {
        return crOverage;
    }

    /**
     * Sets the value of the crOverage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCROverage(BigDecimal value) {
        this.crOverage = value;
    }

    /**
     * Gets the value of the crSampleQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCRSampleQuantity() {
        return crSampleQuantity;
    }

    /**
     * Sets the value of the crSampleQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCRSampleQuantity(BigInteger value) {
        this.crSampleQuantity = value;
    }

    /**
     * Gets the value of the crUvCoating property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRUvCoating() {
        return crUvCoating;
    }

    /**
     * Sets the value of the crUvCoating property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRUvCoating(String value) {
        this.crUvCoating = value;
    }

    /**
     * Gets the value of the crLaminateLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRLaminateLocation() {
        return crLaminateLocation;
    }

    /**
     * Sets the value of the crLaminateLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRLaminateLocation(String value) {
        this.crLaminateLocation = value;
    }

    /**
     * Gets the value of the crLaminateCoating property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRLaminateCoating() {
        return crLaminateCoating;
    }

    /**
     * Sets the value of the crLaminateCoating property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRLaminateCoating(String value) {
        this.crLaminateCoating = value;
    }

    /**
     * Gets the value of the crLaminateCoverage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRLaminateCoverage() {
        return crLaminateCoverage;
    }

    /**
     * Sets the value of the crLaminateCoverage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRLaminateCoverage(String value) {
        this.crLaminateCoverage = value;
    }

    /**
     * Gets the value of the crLaminateFinishType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRLaminateFinishType() {
        return crLaminateFinishType;
    }

    /**
     * Sets the value of the crLaminateFinishType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRLaminateFinishType(String value) {
        this.crLaminateFinishType = value;
    }

    /**
     * Gets the value of the crLaminateThickness property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRLaminateThickness() {
        return crLaminateThickness;
    }

    /**
     * Sets the value of the crLaminateThickness property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRLaminateThickness(BigDecimal value) {
        this.crLaminateThickness = value;
    }

    /**
     * Gets the value of the crBleedSize property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRBleedSize() {
        return crBleedSize;
    }

    /**
     * Sets the value of the crBleedSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRBleedSize(BigDecimal value) {
        this.crBleedSize = value;
    }

    /**
     * Gets the value of the crCarbonlessImposition property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCRCarbonlessImposition() {
        return crCarbonlessImposition;
    }

    /**
     * Sets the value of the crCarbonlessImposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCRCarbonlessImposition(Boolean value) {
        this.crCarbonlessImposition = value;
    }

    /**
     * Gets the value of the crPrintSpecComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRPrintSpecComments() {
        return crPrintSpecComments;
    }

    /**
     * Sets the value of the crPrintSpecComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRPrintSpecComments(String value) {
        this.crPrintSpecComments = value;
    }

    /**
     * Gets the value of the daoluVariableTextConfigurationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDAOLUVariableTextConfigurationID() {
        return daoluVariableTextConfigurationID;
    }

    /**
     * Sets the value of the daoluVariableTextConfigurationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDAOLUVariableTextConfigurationID(String value) {
        this.daoluVariableTextConfigurationID = value;
    }

    /**
     * Gets the value of the compMgd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCompMgd() {
        return compMgd;
    }

    /**
     * Sets the value of the compMgd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCompMgd(Boolean value) {
        this.compMgd = value;
    }

    /**
     * Gets the value of the compNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompNum() {
        return compNum;
    }

    /**
     * Sets the value of the compNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompNum(String value) {
        this.compNum = value;
    }

    /**
     * Gets the value of the billToJobDefault property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillToJobDefault() {
        return billToJobDefault;
    }

    /**
     * Sets the value of the billToJobDefault property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillToJobDefault(String value) {
        this.billToJobDefault = value;
    }

    /**
     * Gets the value of the ecpJobDefault property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECPJobDefault() {
        return ecpJobDefault;
    }

    /**
     * Sets the value of the ecpJobDefault property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECPJobDefault(String value) {
        this.ecpJobDefault = value;
    }

    /**
     * Gets the value of the rarsWorkflow property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRARSWorkflow() {
        return rarsWorkflow;
    }

    /**
     * Sets the value of the rarsWorkflow property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRARSWorkflow(Boolean value) {
        this.rarsWorkflow = value;
    }

    /**
     * Gets the value of the crCropLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRCropLeft() {
        return crCropLeft;
    }

    /**
     * Sets the value of the crCropLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRCropLeft(BigDecimal value) {
        this.crCropLeft = value;
    }

    /**
     * Gets the value of the crCropRight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRCropRight() {
        return crCropRight;
    }

    /**
     * Sets the value of the crCropRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRCropRight(BigDecimal value) {
        this.crCropRight = value;
    }

    /**
     * Gets the value of the crCropTop property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRCropTop() {
        return crCropTop;
    }

    /**
     * Sets the value of the crCropTop property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRCropTop(BigDecimal value) {
        this.crCropTop = value;
    }

    /**
     * Gets the value of the crCropBottom property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCRCropBottom() {
        return crCropBottom;
    }

    /**
     * Sets the value of the crCropBottom property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCRCropBottom(BigDecimal value) {
        this.crCropBottom = value;
    }

    /**
     * Gets the value of the crCropSwapOnEvenPages property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCRCropSwapOnEvenPages() {
        return crCropSwapOnEvenPages;
    }

    /**
     * Sets the value of the crCropSwapOnEvenPages property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCRCropSwapOnEvenPages(Boolean value) {
        this.crCropSwapOnEvenPages = value;
    }

    /**
     * Gets the value of the crCropFile property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCRCropFile() {
        return crCropFile;
    }

    /**
     * Sets the value of the crCropFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCRCropFile(Boolean value) {
        this.crCropFile = value;
    }

    /**
     * Gets the value of the startAsDraft property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isStartAsDraft() {
        return startAsDraft;
    }

    /**
     * Sets the value of the startAsDraft property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setStartAsDraft(Boolean value) {
        this.startAsDraft = value;
    }

    /**
     * Gets the value of the allowCustomPointSkip property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAllowCustomPointSkip() {
        return allowCustomPointSkip;
    }

    /**
     * Sets the value of the allowCustomPointSkip property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAllowCustomPointSkip(Boolean value) {
        this.allowCustomPointSkip = value;
    }

    /**
     * Gets the value of the itemOnlyWorkflow property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isItemOnlyWorkflow() {
        return itemOnlyWorkflow;
    }

    /**
     * Sets the value of the itemOnlyWorkflow property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setItemOnlyWorkflow(Boolean value) {
        this.itemOnlyWorkflow = value;
    }

    /**
     * Gets the value of the md5Cover property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMD5Cover() {
        return md5Cover;
    }

    /**
     * Sets the value of the md5Cover property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMD5Cover(String value) {
        this.md5Cover = value;
    }

    /**
     * Gets the value of the md5Book property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMD5Book() {
        return md5Book;
    }

    /**
     * Sets the value of the md5Book property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMD5Book(String value) {
        this.md5Book = value;
    }

    /**
     * Gets the value of the eDeliveryWorkflow property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEDeliveryWorkflow() {
        return eDeliveryWorkflow;
    }

    /**
     * Sets the value of the eDeliveryWorkflow property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEDeliveryWorkflow(Boolean value) {
        this.eDeliveryWorkflow = value;
    }

    /**
     * Gets the value of the hwsProgramID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHWSProgramID() {
        return hwsProgramID;
    }

    /**
     * Sets the value of the hwsProgramID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHWSProgramID(String value) {
        this.hwsProgramID = value;
    }

    /**
     * Gets the value of the noPDFJIT property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNoPDFJIT() {
        return noPDFJIT;
    }

    /**
     * Sets the value of the noPDFJIT property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNoPDFJIT(Boolean value) {
        this.noPDFJIT = value;
    }

    /**
     * Gets the value of the itemRef property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the itemRef property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getItemRef().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypeItemRef }
     * 
     * 
     */
    public List<TypeItemRef> getItemRef() {
        if (itemRef == null) {
            itemRef = new ArrayList<TypeItemRef>();
        }
        return this.itemRef;
    }

    /**
     * Gets the value of the cdi property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cdi property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCDI().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypeCDI }
     * 
     * 
     */
    public List<TypeCDI> getCDI() {
        if (cdi == null) {
            cdi = new ArrayList<TypeCDI>();
        }
        return this.cdi;
    }

    /**
     * Gets the value of the eCreate property.
     * 
     * @return
     *     possible object is
     *     {@link TypeECreate }
     *     
     */
    public TypeECreate getECreate() {
        return eCreate;
    }

    /**
     * Sets the value of the eCreate property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeECreate }
     *     
     */
    public void setECreate(TypeECreate value) {
        this.eCreate = value;
    }

    /**
     * Gets the value of the customPoint property.
     * 
     * @return
     *     possible object is
     *     {@link TypeCustomPoint }
     *     
     */
    public TypeCustomPoint getCustomPoint() {
        return customPoint;
    }

    /**
     * Sets the value of the customPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeCustomPoint }
     *     
     */
    public void setCustomPoint(TypeCustomPoint value) {
        this.customPoint = value;
    }

    /**
     * Gets the value of the pageExceptions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pageExceptions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPageExceptions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypePageException }
     * 
     * 
     */
    public List<TypePageException> getPageExceptions() {
        if (pageExceptions == null) {
            pageExceptions = new ArrayList<TypePageException>();
        }
        return this.pageExceptions;
    }

    /**
     * Gets the value of the jobRef property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the jobRef property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getJobRef().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TypeJobRef }
     * 
     * 
     */
    public List<TypeJobRef> getJobRef() {
        if (jobRef == null) {
            jobRef = new ArrayList<TypeJobRef>();
        }
        return this.jobRef;
    }

}
