
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * <p>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Header" type="{}TypeResponseHeader"/>
 *         &lt;element name="Result" type="{}TypeGeneralResponse"/>
 *         &lt;element name="TxnID" type="{}TypeTxnID" minOccurs="0"/>
 *         &lt;element name="ValidationDetail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "header",
        "result",
        "txnID",
        "validationDetail"
})
@XmlRootElement(name = "ResponseSAR")
public class ResponseSAR {

    @XmlElement(name = "Header", required = true)
    protected TypeResponseHeader header;
    @XmlElement(name = "Result", required = true)
    protected TypeGeneralResponse result;
    @XmlElement(name = "TxnID")
    protected Integer txnID;
    @XmlElement(name = "ValidationDetail")
    protected String validationDetail;

    /**
     * Gets the value of the header property.
     *
     * @return possible object is
     * {@link TypeResponseHeader }
     */
    public TypeResponseHeader getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     *
     * @param value allowed object is
     *              {@link TypeResponseHeader }
     */
    public void setHeader(TypeResponseHeader value) {
        this.header = value;
    }

    /**
     * Gets the value of the result property.
     *
     * @return possible object is
     * {@link TypeGeneralResponse }
     */
    public TypeGeneralResponse getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     *
     * @param value allowed object is
     *              {@link TypeGeneralResponse }
     */
    public void setResult(TypeGeneralResponse value) {
        this.result = value;
    }

    /**
     * Gets the value of the txnID property.
     *
     * @return possible object is
     * {@link Integer }
     */
    public Integer getTxnID() {
        return txnID;
    }

    /**
     * Sets the value of the txnID property.
     *
     * @param value allowed object is
     *              {@link Integer }
     */
    public void setTxnID(Integer value) {
        this.txnID = value;
    }

    /**
     * Gets the value of the validationDetail property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getValidationDetail() {
        return validationDetail;
    }

    /**
     * Sets the value of the validationDetail property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setValidationDetail(String value) {
        this.validationDetail = value;
    }

}
