
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypeAssetStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeAssetStatus">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="WebServiceType" type="{}TypeWebServiceType" minOccurs="0"/>
 *         &lt;element name="TxnID" type="{}TypeTxnID"/>
 *         &lt;element name="Customer_ID" type="{}TypeProfileID"/>
 *         &lt;element name="CustNum" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BillTo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Customer_UID" type="{}TypeCustomerUID" minOccurs="0"/>
 *         &lt;element name="DAORequestID" type="{}TypeRequestID"/>
 *         &lt;element name="Cust_Item_Num" type="{}TypeCustItemNum"/>
 *         &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="StatusMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OtherData" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence maxOccurs="100">
 *                   &lt;element name="DataNVP" type="{}TypeDataNameValuePair"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeAssetStatus", propOrder = {
    "webServiceType",
    "txnID",
    "customerID",
    "custNum",
    "billTo",
    "customerUID",
    "daoRequestID",
    "custItemNum",
    "statusCode",
    "statusMsg",
    "otherData"
})
public class TypeAssetStatus {

    @XmlElement(name = "WebServiceType")
    @XmlSchemaType(name = "token")
    protected TypeWebServiceType webServiceType;
    @XmlElement(name = "TxnID")
    protected int txnID;
    @XmlElement(name = "Customer_ID")
    protected int customerID;
    @XmlElement(name = "CustNum")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String custNum;
    @XmlElement(name = "BillTo")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String billTo;
    @XmlElement(name = "Customer_UID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String customerUID;
    @XmlElement(name = "DAORequestID")
    protected int daoRequestID;
    @XmlElement(name = "Cust_Item_Num", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String custItemNum;
    @XmlElement(name = "StatusCode")
    protected int statusCode;
    @XmlElement(name = "StatusMsg", required = true)
    protected String statusMsg;
    @XmlElement(name = "OtherData")
    protected TypeAssetStatus.OtherData otherData;

    /**
     * Gets the value of the webServiceType property.
     * 
     * @return
     *     possible object is
     *     {@link TypeWebServiceType }
     *     
     */
    public TypeWebServiceType getWebServiceType() {
        return webServiceType;
    }

    /**
     * Sets the value of the webServiceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeWebServiceType }
     *     
     */
    public void setWebServiceType(TypeWebServiceType value) {
        this.webServiceType = value;
    }

    /**
     * Gets the value of the txnID property.
     * 
     */
    public int getTxnID() {
        return txnID;
    }

    /**
     * Sets the value of the txnID property.
     * 
     */
    public void setTxnID(int value) {
        this.txnID = value;
    }

    /**
     * Gets the value of the customerID property.
     * 
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * Sets the value of the customerID property.
     * 
     */
    public void setCustomerID(int value) {
        this.customerID = value;
    }

    /**
     * Gets the value of the custNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNum() {
        return custNum;
    }

    /**
     * Sets the value of the custNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNum(String value) {
        this.custNum = value;
    }

    /**
     * Gets the value of the billTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillTo() {
        return billTo;
    }

    /**
     * Sets the value of the billTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillTo(String value) {
        this.billTo = value;
    }

    /**
     * Gets the value of the customerUID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerUID() {
        return customerUID;
    }

    /**
     * Sets the value of the customerUID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerUID(String value) {
        this.customerUID = value;
    }

    /**
     * Gets the value of the daoRequestID property.
     * 
     */
    public int getDAORequestID() {
        return daoRequestID;
    }

    /**
     * Sets the value of the daoRequestID property.
     * 
     */
    public void setDAORequestID(int value) {
        this.daoRequestID = value;
    }

    /**
     * Gets the value of the custItemNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustItemNum() {
        return custItemNum;
    }

    /**
     * Sets the value of the custItemNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustItemNum(String value) {
        this.custItemNum = value;
    }

    /**
     * Gets the value of the statusCode property.
     * 
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     */
    public void setStatusCode(int value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the statusMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusMsg() {
        return statusMsg;
    }

    /**
     * Sets the value of the statusMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusMsg(String value) {
        this.statusMsg = value;
    }

    /**
     * Gets the value of the otherData property.
     * 
     * @return
     *     possible object is
     *     {@link TypeAssetStatus.OtherData }
     *     
     */
    public TypeAssetStatus.OtherData getOtherData() {
        return otherData;
    }

    /**
     * Sets the value of the otherData property.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeAssetStatus.OtherData }
     *     
     */
    public void setOtherData(TypeAssetStatus.OtherData value) {
        this.otherData = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence maxOccurs="100">
     *         &lt;element name="DataNVP" type="{}TypeDataNameValuePair"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "dataNVP"
    })
    public static class OtherData {

        @XmlElement(name = "DataNVP", required = true)
        protected List<TypeDataNameValuePair> dataNVP;

        /**
         * Gets the value of the dataNVP property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the dataNVP property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDataNVP().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TypeDataNameValuePair }
         * 
         * 
         */
        public List<TypeDataNameValuePair> getDataNVP() {
            if (dataNVP == null) {
                dataNVP = new ArrayList<TypeDataNameValuePair>();
            }
            return this.dataNVP;
        }

    }

}
