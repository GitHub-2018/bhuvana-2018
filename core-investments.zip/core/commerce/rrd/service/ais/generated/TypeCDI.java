
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for TypeCDI complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TypeCDI">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CDI_Name">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="^CDI1?[0-9]$|^CDI[1-2]5$"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CDI_Value">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *               &lt;maxLength value="255"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TypeCDI", propOrder = {
    "cdiName",
    "cdiValue"
})
public class TypeCDI {

    @XmlElement(name = "CDI_Name", required = true)
    protected String cdiName;
    @XmlElement(name = "CDI_Value", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String cdiValue;

    /**
     * Gets the value of the cdiName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCDIName() {
        return cdiName;
    }

    /**
     * Sets the value of the cdiName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCDIName(String value) {
        this.cdiName = value;
    }

    /**
     * Gets the value of the cdiValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCDIValue() {
        return cdiValue;
    }

    /**
     * Sets the value of the cdiValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCDIValue(String value) {
        this.cdiValue = value;
    }

}
