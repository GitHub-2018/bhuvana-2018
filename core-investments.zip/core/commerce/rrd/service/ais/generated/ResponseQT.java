
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for anonymous complex type.
 * <p>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Header" type="{}TypeResponseHeader"/>
 *         &lt;element name="Result" type="{}TypeGeneralResponse"/>
 *         &lt;element name="QTDetails" type="{}TypeQTData" minOccurs="0"/>
 *         &lt;element name="QTOtherInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="QueuedCIN">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence maxOccurs="1000">
 *                             &lt;element name="Cust_Item_Num" type="{}TypeCustItemNum"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "header",
        "result",
        "qtDetails",
        "qtOtherInfo"
})
@XmlRootElement(name = "ResponseQT")
public class ResponseQT {

    @XmlElement(name = "Header", required = true)
    protected TypeResponseHeader header;
    @XmlElement(name = "Result", required = true)
    protected TypeGeneralResponse result;
    @XmlElement(name = "QTDetails")
    protected TypeQTData qtDetails;
    @XmlElement(name = "QTOtherInfo")
    protected ResponseQT.QTOtherInfo qtOtherInfo;

    /**
     * Gets the value of the header property.
     *
     * @return possible object is
     * {@link TypeResponseHeader }
     */
    public TypeResponseHeader getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     *
     * @param value allowed object is
     *              {@link TypeResponseHeader }
     */
    public void setHeader(TypeResponseHeader value) {
        this.header = value;
    }

    /**
     * Gets the value of the result property.
     *
     * @return possible object is
     * {@link TypeGeneralResponse }
     */
    public TypeGeneralResponse getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     *
     * @param value allowed object is
     *              {@link TypeGeneralResponse }
     */
    public void setResult(TypeGeneralResponse value) {
        this.result = value;
    }

    /**
     * Gets the value of the qtDetails property.
     *
     * @return possible object is
     * {@link TypeQTData }
     */
    public TypeQTData getQTDetails() {
        return qtDetails;
    }

    /**
     * Sets the value of the qtDetails property.
     *
     * @param value allowed object is
     *              {@link TypeQTData }
     */
    public void setQTDetails(TypeQTData value) {
        this.qtDetails = value;
    }

    /**
     * Gets the value of the qtOtherInfo property.
     *
     * @return possible object is
     * {@link ResponseQT.QTOtherInfo }
     */
    public ResponseQT.QTOtherInfo getQTOtherInfo() {
        return qtOtherInfo;
    }

    /**
     * Sets the value of the qtOtherInfo property.
     *
     * @param value allowed object is
     *              {@link ResponseQT.QTOtherInfo }
     */
    public void setQTOtherInfo(ResponseQT.QTOtherInfo value) {
        this.qtOtherInfo = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * <p>
     * <p>The following schema fragment specifies the expected content contained within this class.
     * <p>
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="QueuedCIN">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence maxOccurs="1000">
     *                   &lt;element name="Cust_Item_Num" type="{}TypeCustItemNum"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "queuedCIN"
    })
    public static class QTOtherInfo {

        @XmlElement(name = "QueuedCIN", required = true)
        protected ResponseQT.QTOtherInfo.QueuedCIN queuedCIN;

        /**
         * Gets the value of the queuedCIN property.
         *
         * @return possible object is
         * {@link ResponseQT.QTOtherInfo.QueuedCIN }
         */
        public ResponseQT.QTOtherInfo.QueuedCIN getQueuedCIN() {
            return queuedCIN;
        }

        /**
         * Sets the value of the queuedCIN property.
         *
         * @param value allowed object is
         *              {@link ResponseQT.QTOtherInfo.QueuedCIN }
         */
        public void setQueuedCIN(ResponseQT.QTOtherInfo.QueuedCIN value) {
            this.queuedCIN = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * <p>
         * <p>The following schema fragment specifies the expected content contained within this class.
         * <p>
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence maxOccurs="1000">
         *         &lt;element name="Cust_Item_Num" type="{}TypeCustItemNum"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
                "custItemNum"
        })
        public static class QueuedCIN {

            @XmlElement(name = "Cust_Item_Num", required = true)
            @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
            @XmlSchemaType(name = "token")
            protected List<String> custItemNum;

            /**
             * Gets the value of the custItemNum property.
             * <p>
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the custItemNum property.
             * <p>
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getCustItemNum().add(newItem);
             * </pre>
             * <p>
             * <p>
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             */
            public List<String> getCustItemNum() {
                if (custItemNum == null) {
                    custItemNum = new ArrayList<String>();
                }
                return this.custItemNum;
            }

        }

    }

}
