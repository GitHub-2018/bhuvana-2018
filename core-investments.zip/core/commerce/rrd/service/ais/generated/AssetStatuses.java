
package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * <p>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Assets">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="AssetStatus" type="{}TypeAssetStatus" maxOccurs="1000"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "assets"
})
@XmlRootElement(name = "AssetStatuses")
public class AssetStatuses {

    @XmlElement(name = "Assets", required = true)
    protected AssetStatuses.Assets assets;

    /**
     * Gets the value of the assets property.
     *
     * @return possible object is
     * {@link AssetStatuses.Assets }
     */
    public AssetStatuses.Assets getAssets() {
        return assets;
    }

    /**
     * Sets the value of the assets property.
     *
     * @param value allowed object is
     *              {@link AssetStatuses.Assets }
     */
    public void setAssets(AssetStatuses.Assets value) {
        this.assets = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * <p>
     * <p>The following schema fragment specifies the expected content contained within this class.
     * <p>
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="AssetStatus" type="{}TypeAssetStatus" maxOccurs="1000"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "assetStatus"
    })
    public static class Assets {

        @XmlElement(name = "AssetStatus", required = true)
        protected List<TypeAssetStatus> assetStatus;

        /**
         * Gets the value of the assetStatus property.
         * <p>
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the assetStatus property.
         * <p>
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAssetStatus().add(newItem);
         * </pre>
         * <p>
         * <p>
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TypeAssetStatus }
         */
        public List<TypeAssetStatus> getAssetStatus() {
            if (assetStatus == null) {
                assetStatus = new ArrayList<>();
            }
            return this.assetStatus;
        }

    }

}
