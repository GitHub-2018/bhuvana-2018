package com.jhi.aem.website.v1.core.commerce.rrd.service.ais;

import org.apache.sling.api.resource.Resource;

import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.ResponseQT;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.ResponseSAR;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.impl.FtpSentStatus;

public interface AisService {

    String ENABLED_PROPERTY = "enabled";
    String SERVICE_ENDPOINT_PROPERTY = "ais.service.endpoint";
    String DEFAULT_SERVICE_ENDPOINT = "https://aissp-stage.rrd.com/AssetMgmt/";
    String USERNAME_PROPERTY = "ais.username";
    String PASSWORD_PROPERTY = "ais.password";
    String SYS_ID_PROPERTY = "ais.sysId";
    String CUSTOMER_ID_PROPERTY = "ais.customerId";

    String CONTACT_NAME_PROPERTY = "ais.contactName";
    String DEFAULT_CONTACT_NAME = "JHIOrders";
    String CONTACT_EMAIL_PROPERTY = "ais.contactEmail";
    String DEFAULT_CONTACT_EMAIL = "JHIOrders@jhancock.com";

    String QUERY_DELAY_PROPERTY = "ais.query.delay";
    int DEFAULT_QUERY_DELAY = 1800;
    String DISTRIBUTION_AGENT_NAME_PROPERTY = "distribution.agent.name";
    String DEFAULT_DISTRIBUTION_AGENT_NAME = "aisRars-reverse";

    String FTP_ADDRESS_PROPERTY = "ftp.address";
    String FTP_USERNAME_PROPERTY = "ftp.username";
    String FTP_PASSWORD_PROPERTY = "ftp.password";
    String FTP_DIRECTORY_PROPERTY = "ftp.directory";

    short QT_STATUS_SUCCESS = 600;
    short QT_STATUS_IN_PROCESS = 400;

    int EMPTY_ID_VALUE = -1;

    ResponseSAR submitAssetRequest(RrdProductImpl product);

    ResponseQT queryTransaction(String trxId);

    FtpSentStatus sendFileToFtp(Resource productResource);

    boolean isAvailable();

    boolean isFtpConfigured();

    int getCustomerId();

    int getSystemId();

    String getSystemIdValue();

    String getDistributionAgentName();

    String getFtpAddress();

    String getFtpUsername();

    String getFtpPassword();

    String getFtpDirectory();
}
