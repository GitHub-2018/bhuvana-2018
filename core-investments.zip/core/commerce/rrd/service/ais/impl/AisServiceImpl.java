package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import org.apache.http.Header;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.day.cq.commons.DownloadResource;
import com.day.cq.dam.api.Asset;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.importer.RrdProductsImporter;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.AisService;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.AssetRequest;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.ItemRequestDef;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.ResponseQT;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.ResponseSAR;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeAssetSummary;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeAssetType;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeCustomPoint;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeCustomPointAttributeValue;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeCustomPointCatalog;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeItemRef;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.TypeRequestType;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolExecutor;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolService;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;

@Component(
		name="JHI Website AIS Service",
		service=AisService.class,
		immediate=true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.ais.impl.AisServiceImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website AIS Service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR,
		})
@Designate(ocd=AisServiceImpl.Config.class)
public class AisServiceImpl implements AisService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AisServiceImpl.class);
    
    @ObjectClassDefinition(name="AIS Service configurations for JHI Website", description="Configurations for JHI Website AIS Service")
    public @interface Config{
    	@AttributeDefinition(name="Enable AIS Service", description="Status of AIS Service,by default the status will be false")
    	boolean enabled() default false;
    	@AttributeDefinition(name="Service EndPoint property",description="AIS Service endpoint name")
    	String ais_service_endpoint() default DEFAULT_SERVICE_ENDPOINT;
    	@AttributeDefinition(name="Customer Id",description="AIS Service customer id")
    	int ais_customerId() default AisService.EMPTY_ID_VALUE;
    	@AttributeDefinition(name = "Username",description = "AIS Service Username")
    	String ais_username() default StringUtils.EMPTY; 
    	@AttributeDefinition(name = "Password", description = "AIS Service Password")
    	String ais_password() default StringUtils.EMPTY;
    	@AttributeDefinition(name ="Sys Id", description="AIS Service System ID")
    	int ais_sysId() default AisService.EMPTY_ID_VALUE;
    	@AttributeDefinition(name = "Contact name", description="AIS Contact name")
    	String ais_contactName() default AisService.DEFAULT_CONTACT_NAME;
    	@AttributeDefinition(name = "Contact email", description="AIS Contact email")
    	String ais_contactEmail() default AisService.DEFAULT_CONTACT_EMAIL;
    	@AttributeDefinition(name = "Query delay", description="Service query delay time")
    	int ais_query_delay() default AisService.DEFAULT_QUERY_DELAY;
    	@AttributeDefinition(name = "Distribution agent name", description="AIS Service distribution agent name")
    	String distribution_agent_name() default AisService.DEFAULT_DISTRIBUTION_AGENT_NAME;
    	@AttributeDefinition(name = "FTP Address", description ="AIS Service FTP Address")
    	String ftp_address() default StringUtils.EMPTY;
    	@AttributeDefinition(name = "FTP Username", description ="AIS Service FTP Username")
    	String ftp_username() default StringUtils.EMPTY;
    	@AttributeDefinition(name = "FTP Password", description ="AIS Service FTP password")
    	String ftp_password() default StringUtils.EMPTY;
    	@AttributeDefinition(name = "FTP Directory", description ="AIS Service FTP directory")
    	String ftp_directory() default StringUtils.EMPTY;
    }

    private static final String SYS_ID_HEADER = "SYS-ID";

    private static final short ENCLOSED_ASSETS_COUNT = 1;
    private static final String SUBMIT_ASSET_REQUEST_WEBSERVICE = "SubmitAssetRequest.asmx/AcceptItem";
    private static final String QUERY_TRANSACTION_WEBSERVICE = "QueryTrans.asmx/AcceptItem";

    private static final String QUERY_TRANSACTION_BODY_PATTERN = "<TxnID>%s</TxnID>";

    private static final long DEFAULT_AIS_TIMEOUT_SECS = 60;

    private static final String ITEM_REF_1 = "Item_Ref_1";
    private static final String ITEM_REF_2 = "Item_Ref_2";
    private static final String ITEM_REF_3 = "Item_Ref_3";
    private static final String ITEM_REF_4 = "Item_Ref_4";

    private static final String FIRM_ATTRIBUTE = "Firm";

    private static final int SFTP_PORT = 22;

    
    private RunModeService runModeService;
    @Reference
    public void bindRunModeService (RunModeService runModeService) {
    	this.runModeService = runModeService;
    }
    public void unbindRunModeService (RunModeService runModeService) {
    	this.runModeService = runModeService;
    }

    //@Reference
    //private ResourceResolverFactory resourceResolverFactory;

    private boolean onAuthor;
    private boolean enabled;
    private boolean configured;
    private boolean ftpConfigured;
    private String serviceEndpoint;
    private int sysId;
    private String sysIdValue;
    private int customerId;
    private String contactName;
    private String contactEmail;
    private String distributionAgentName;
    private String ftpAddress;
    private String ftpUsername;
    private String ftpPassword;
    private String ftpDirectory;
    private Header authHeader = null;

//    private ScheduledFuture<?> transactionQueryTask;

    private JAXBContext jaxbAssetRequestContext;
    private JAXBContext jaxbResponseSarContext;
    private JAXBContext jaxbResponseQtContext;

    
    private AsyncHttpClientPoolService httpClientPool;
    @Reference
    public void bindAsyncHttpClientPoolService(AsyncHttpClientPoolService httpClientPool) {
    	this.httpClientPool=httpClientPool;
    }
    public void unbindAsyncHttpClientPoolService(AsyncHttpClientPoolService httpClientPool) {
    	this.httpClientPool=httpClientPool;
    }
    private DocumentBuilderFactory dbf;

    @Override
    public ResponseSAR submitAssetRequest(RrdProductImpl product) {
        if (!isAvailable()) {
            return null;
        }
        if (jaxbAssetRequestContext == null) {
            LOGGER.error("Asset request context not available");
            return null;
        }
        if (jaxbResponseSarContext == null) {
            LOGGER.error("SAR response context not available");
            return null;
        }
        if (StringUtils.isNotBlank(product.getCode()) && !StringUtils.isAllUpperCase(product.getCode())) {
            if (!product.setCode(product.getCode())) {
                LOGGER.error("Problem while converting code to uppercase: " + product.getCode());
                return null;
            }
        }
        HttpPost httpPost = createPostRequest(SUBMIT_ASSET_REQUEST_WEBSERVICE);

        AssetRequest assetRequest = new AssetRequest();
        setAssetSummary(assetRequest);
        ItemRequestDef itemRequestDef = new ItemRequestDef();

        setAssetRequestProperties(itemRequestDef);
        setAssetCustomPointCatalogProperties(product, itemRequestDef);
        setAssetRrdProperties(product, itemRequestDef);
        setAssetItemRefProperties(product, itemRequestDef);
        assetRequest.getItemRequest().add(itemRequestDef);

        try {
            Marshaller jaxbMarshaller = jaxbAssetRequestContext.createMarshaller();
            StringWriter stringWriter = new StringWriter();
            jaxbMarshaller.marshal(assetRequest, stringWriter);
            String xmlString = stringWriter.toString();
            httpPost.setEntity(new ByteArrayEntity(xmlString.getBytes()));
        } catch (JAXBException e) {
            LOGGER.error("Problem while creating xml request", e);
        }

        ResponseSAR responseSar = null;
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpResponse response = httpClient.execute(httpPost);
            Unmarshaller unmarshaller = jaxbResponseSarContext.createUnmarshaller();
            DocumentBuilder db = dbf.newDocumentBuilder();
            dbf.setExpandEntityReferences(false);
            Document document;
            try (InputStream responseStream = response.getEntity().getContent()) {
                document = db.parse(responseStream);
                responseSar = (ResponseSAR) unmarshaller.unmarshal(document);
            } catch (SAXException e) {
                LOGGER.error("Error parsing XML document", e);
            }
            return responseSar;
        } catch (IOException e) {
            LOGGER.error("Problem while executing xml request", e);
        } catch (JAXBException e) {
            LOGGER.error("Problem while parsing xml response", e);
        } catch (ParserConfigurationException e) {
            LOGGER.error("Problem while getting a new document builder", e);
        }
        return null;
    }


    private HttpPost createPostRequest(String path) {
        HttpPost httpPost = new HttpPost(serviceEndpoint + path);
        if (authHeader != null) {
            httpPost.addHeader(authHeader);
        }
        httpPost.addHeader(HttpHeaders.CONTENT_TYPE, JhiConstants.TEXT_XML);
        httpPost.addHeader(SYS_ID_HEADER, sysIdValue);
        return httpPost;
    }

    private void setAssetSummary(AssetRequest assetRequest) {
        TypeAssetSummary typeAssetSummary = new TypeAssetSummary();
        typeAssetSummary.setEnclosedAssetType(TypeAssetType.ITEM);
        typeAssetSummary.setEnclosedAssets(ENCLOSED_ASSETS_COUNT);
        typeAssetSummary.setCustomerID(customerId);
        assetRequest.setAssetSummary(typeAssetSummary);
    }

    private void setAssetRequestProperties(ItemRequestDef itemRequestDef) {
        itemRequestDef.setRequestType(TypeRequestType.SYS_DETERMINE);
    }

    private void setAssetRrdProperties(RrdProductImpl product, ItemRequestDef itemRequestDef) {
        itemRequestDef.setCustItemNum(product.getCode());
        itemRequestDef.setIsJIT(product.isJit());
        itemRequestDef.setIsCSS(product.isCSS());
        itemRequestDef.setContactName(contactName);
        itemRequestDef.setContactEmail(contactEmail);
        itemRequestDef.setOMSDescr(product.getCpItemDescription());
        itemRequestDef.setWCSSItemDescr(product.getWcssItemDescription());
        itemRequestDef.setPackagingUOM(product.getUomCode());
        if (product.getPackagingQuantity() != null && product.getPackagingQuantity() > 0) {
            itemRequestDef.setPackagingQty(BigInteger.valueOf(product.getPackagingQuantity()));
        }
        itemRequestDef.setRevision(product.getRevision());
        if (product.getMaximumOrderQuantity() != null && product.getMaximumOrderQuantity() > 0) {
            itemRequestDef.setMaxOrderQtyWCSS(BigInteger.valueOf(product.getMaximumOrderQuantity()));
        }
        itemRequestDef.setItemSubType(product.getItemSubtype());
        itemRequestDef.setOrientation(product.getOrientation());
        itemRequestDef.setSidesPrinted(product.getSidesPrinted());
        itemRequestDef.setPaperStockType(product.getPaperStockType());
        itemRequestDef.setPaperStockWeight(product.getPaperStockWeight());
        itemRequestDef.setPaperStockColor(product.getPaperStockColor());
        if (product.getTrimSizeWidth() != null && product.getTrimSizeWidth() > 0) {
            itemRequestDef.setTrimSizeWidth(BigDecimal.valueOf(product.getTrimSizeWidth()));
        }
        if (product.getTrimSizeLength() != null && product.getTrimSizeLength() > 0) {
            itemRequestDef.setTrimSizeLength(BigDecimal.valueOf(product.getTrimSizeLength()));
        }
        if (product.getPdfPageWidth() != null && product.getPdfPageWidth() > 0) {
            itemRequestDef.setPageWidth(BigDecimal.valueOf(product.getPdfPageWidth()));
        }
        if (product.getPdfPageLength() != null && product.getPdfPageLength() > 0) {
            itemRequestDef.setPageLength(BigDecimal.valueOf(product.getPdfPageLength()));
        }
        itemRequestDef.setInkColors(product.getInkColors());
        itemRequestDef.setBleeds(product.getBleeds());
        itemRequestDef.setCRPrintSpecComments(product.getPrintingComments());
        if (product.getMinimumOrderQuantity() != null && product.getMinimumOrderQuantity() > 0) {
            itemRequestDef.setMinOrderQty(BigInteger.valueOf(product.getMinimumOrderQuantity()));
        }
        if (product.getMultipleOrderQuantity() != null && product.getMultipleOrderQuantity() > 0) {
            itemRequestDef.setMultipleOrderQty(BigInteger.valueOf(product.getMultipleOrderQuantity()));
        }
        itemRequestDef.setPDFFilename(product.getPrintAssetName());
    }

    private void setAssetItemRefProperties(RrdProductImpl product, ItemRequestDef itemRequestDef) {
        List<TypeItemRef> itemRefs = itemRequestDef.getItemRef();
        addItemRef(itemRefs, ITEM_REF_1, product.getFulfillmentBudgetCode());
        addItemRef(itemRefs, ITEM_REF_2, product.getFulfillmentManager());
        addItemRef(itemRefs, ITEM_REF_3, product.getMarketingManager());
        addItemRef(itemRefs, ITEM_REF_4, product.getPrintStatus());
    }

    private void addItemRef(List<TypeItemRef> itemRefs, String name, String value) {
        if (StringUtils.isNotBlank(value)) {
            TypeItemRef itemRef = new TypeItemRef();
            itemRef.setItemRefName(name);
            itemRef.setItemRefValue(value);
            itemRefs.add(itemRef);
        }
    }

    private void setAssetCustomPointCatalogProperties(RrdProductImpl product, ItemRequestDef itemRequestDef) {
        TypeCustomPoint customPoint = new TypeCustomPoint();
        List<TypeCustomPointAttributeValue> restrictionAttributes = customPoint.getCustomPointAttributeNameValue();

        if (product.isAllowedAmeripriseFinancial()) {
            restrictionAttributes.add(createCpFirmAttribute(RrdProductsImporter.FIRM_RESTRICTION_AMERFIN));
        }
        if (product.isAllowedEdwardJones()) {
            restrictionAttributes.add(createCpFirmAttribute(RrdProductsImporter.FIRM_RESTRICTION_EDJONES));
        }
        if (product.isAllowedJhi()) {
            restrictionAttributes.add(createCpFirmAttribute(RrdProductsImporter.FIRM_RESTRICTION_JHI_EXT));
        }
        if (product.isAllowedMerrillLynch()) {
            restrictionAttributes.add(createCpFirmAttribute(RrdProductsImporter.FIRM_RESTRICTION_MLYNCH));
        }
        if (product.isAllowedMorganStanley()) {
            restrictionAttributes.add(createCpFirmAttribute(RrdProductsImporter.FIRM_RESTRICTION_MSTANLEY));
        }
        if (product.isAllowedUbs()) {
            restrictionAttributes.add(createCpFirmAttribute(RrdProductsImporter.FIRM_RESTRICTION_UBSFIN));
        }
        if (StringUtils.equals(product.getAccess(), JhiConstants.ACCESS_INTERNAL)) {
            restrictionAttributes.add(createCpFirmAttribute(RrdProductsImporter.FIRM_RESTRICTION_JHI_INT));
        }

        boolean hasCatalog = false;
        if (StringUtils.isNotBlank(product.getCatalog())) {
            List<TypeCustomPointCatalog> catalogs = customPoint.getCustomPointCatalog();
            TypeCustomPointCatalog catalog = new TypeCustomPointCatalog();
            catalog.setCatalogName(product.getCatalog());
            catalog.setCategoryName(product.getRrdCategory());
            catalog.setSubCategoryName1(product.getSubcategory1());
            catalog.setSubCategoryName2(product.getSubcategory2());
            if (product.getCpApprovalQuantityLimit() != null && product.getCpApprovalQuantityLimit() > 0) {
                catalog.setApprovalQuantityLimit(Long.valueOf(product.getCpApprovalQuantityLimit()));
            }
            catalog.setCPBUID(product.getCpBusinessUnits());
            catalogs.add(catalog);
            hasCatalog = true;
        }
        if (!restrictionAttributes.isEmpty() || hasCatalog) {
            itemRequestDef.setCustomPoint(customPoint);
        }
    }

    private TypeCustomPointAttributeValue createCpFirmAttribute(String firm) {
        TypeCustomPointAttributeValue value = new TypeCustomPointAttributeValue();
        value.setAttributeName(FIRM_ATTRIBUTE);
        value.setAttributeValue(firm);
        return value;
    }

    @Override
    public ResponseQT queryTransaction(String trxId) {
        if (!isAvailable()) {
            return null;
        }
        if (jaxbResponseQtContext == null) {
            LOGGER.error("Response QT context not available");
            return null;
        }

        HttpPost httpPost = createPostRequest(QUERY_TRANSACTION_WEBSERVICE);
        httpPost.setEntity(new ByteArrayEntity(String.format(QUERY_TRANSACTION_BODY_PATTERN, trxId).getBytes()));
        try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
            Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(httpPost);
            HttpResponse httpResponse = future.get(DEFAULT_AIS_TIMEOUT_SECS, TimeUnit.SECONDS);

            String result = EntityUtils.toString(httpResponse.getEntity());
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document document = db.parse(result);

            Unmarshaller unmarshaller = jaxbResponseQtContext.createUnmarshaller();
            return (ResponseQT) unmarshaller.unmarshal(document);
        } catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
            LOGGER.error("Problem while executing xml request", e);
        } catch (JAXBException e) {
            LOGGER.error("Problem while parsing xml response", e);
        } catch (SAXException | ParserConfigurationException e) {
            LOGGER.error("Problem while creating xml parser", e);
        }
        return null;
    }

    @Override
    public FtpSentStatus sendFileToFtp(Resource productResource) {
        if (productResource == null) {
            return FtpSentStatus.ERROR_NO_PRODUCT;
        }
        ResourceResolver resourceResolver = productResource.getResourceResolver();
        RrdProductImpl product = new RrdProductImpl(productResource);
        Resource productAssetResource = product.getPrintAssetResource();
        if (product.isCSS() && productAssetResource == null) {
            return FtpSentStatus.CSS_ITEM_NO_FILE;
        }
        boolean sentSuccessful = false;
        boolean assetPresent = false;
        if (productAssetResource != null && productAssetResource.isResourceType(ResourcesConstants.PRODUCT_IMAGE_RESOURCE_TYPE)) {
            ValueMap productAssetProperties = productAssetResource.getValueMap();
            if (productAssetProperties.containsKey(DownloadResource.PN_REFERENCE)) {
                String assetDamPath = productAssetProperties.get(DownloadResource.PN_REFERENCE, String.class);
                if (assetDamPath != null) {
                    Resource assetResource = resourceResolver.getResource(assetDamPath);
                    if (assetResource != null) {
                        Asset asset = assetResource.adaptTo(Asset.class);
                        if (asset != null) {
                            assetPresent = true;
                            InputStream inputStream = asset.getOriginal().getStream();
                            if (inputStream != null) {
                                sentSuccessful = sendFile(inputStream, product.getPrintAssetName());
                                try {
                                    inputStream.close();
                                } catch (IOException e) {
                                    LOGGER.error("Problem while closing asset stream", e);
                                }
                            }
                        }
                    }
                }
            }
        }
        if (sentSuccessful) {
            return FtpSentStatus.SUCCESS;
        }
        if (!assetPresent) {
            return FtpSentStatus.ERROR_NO_FILE;
        }
        return FtpSentStatus.ERROR;
    }

    private boolean sendFile(InputStream inputStream, String fileName) {
        if (inputStream == null || StringUtils.isBlank(fileName)) {
            return false;
        }
        Session session = null;
        Channel channel = null;
        ChannelSftp channelSftp = null;

        try {
            JSch jsch = new JSch();
            session = jsch.getSession(getFtpUsername(), getFtpAddress(), SFTP_PORT);
            session.setPassword(getFtpPassword());
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            channelSftp = (ChannelSftp) channel;
            channelSftp.cd(getFtpDirectory());
            channelSftp.put(inputStream, fileName);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (channelSftp != null) {
                channelSftp.exit();
            }
            if (channel != null) {
                channel.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }
        }
        return false;
    }

    @Override
    public boolean isAvailable() {
        return onAuthor && enabled && configured;
    }

    @Override
    public boolean isFtpConfigured() {
        return ftpConfigured;
    }

    @Override
    public int getCustomerId() {
        return customerId;
    }

    @Override
    public int getSystemId() {
        return sysId;
    }

    @Override
    public String getSystemIdValue() {
        return sysIdValue;
    }

    @Override
    public String getDistributionAgentName() {
        return distributionAgentName;
    }

    @Override
    public String getFtpAddress() {
        return ftpAddress;
    }

    @Override
    public String getFtpUsername() {
        return ftpUsername;
    }

    @Override
    public String getFtpPassword() {
        return ftpPassword;
    }

    @Override
    public String getFtpDirectory() {
        return ftpDirectory;
    }


    @Activate
    protected void activate(final Config config) {
        onAuthor = runModeService.isAuthor();
        update(config);
        try {
            jaxbAssetRequestContext = JAXBContext.newInstance(AssetRequest.class);
            jaxbResponseSarContext = JAXBContext.newInstance(ResponseSAR.class);
            jaxbResponseQtContext = JAXBContext.newInstance(ResponseQT.class);
        } catch (JAXBException e) {
            LOGGER.error("Problem while creating jaxb context", e);
        }

        // Fortify scan highlighted issues with expanded entity references, parse all the
        // streams as XML documents first using this factory
        dbf = DocumentBuilderFactory.newInstance();
        dbf.setExpandEntityReferences(false);
    }

    @Modified
    protected void update(final Config config) {
        authHeader = null;
        enabled = config.enabled();
        //enabled = PropertiesUtil.toBoolean(properties.get(ENABLED_PROPERTY), false);
        serviceEndpoint = config.ais_service_endpoint();
        //serviceEndpoint = PropertiesUtil.toString(properties.get(SERVICE_ENDPOINT_PROPERTY), DEFAULT_SERVICE_ENDPOINT);
        final String username = config.ais_username();
        //final String username = PropertiesUtil.toString(properties.get(USERNAME_PROPERTY), StringUtils.EMPTY);
        final String password = config.ais_password();
        //final String password = PropertiesUtil.toString(properties.get(PASSWORD_PROPERTY), StringUtils.EMPTY);
        sysId =config.ais_sysId();
        //sysId = PropertiesUtil.toInteger(properties.get(SYS_ID_PROPERTY), AisService.EMPTY_ID_VALUE);
        if (sysId > 0) {
            sysIdValue = String.valueOf(sysId);
        }
        customerId=config.ais_customerId();
        //customerId = PropertiesUtil.toInteger(properties.get(CUSTOMER_ID_PROPERTY), AisService.EMPTY_ID_VALUE);
        configured = StringUtils.isNoneBlank(username, password, sysIdValue) && customerId > 0;
        if (configured) {
            byte[] authEncoded = Base64.encodeBase64((username + JhiConstants.COLON + password).getBytes());
            try {
				authHeader = new BasicHeader(HttpHeaders.AUTHORIZATION,
						AuthSchemes.BASIC + StringUtils.SPACE + new String(authEncoded, "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException(e);
			}
        }
        contactName=config.ais_contactName();
        //contactName = PropertiesUtil.toString(properties.get(CONTACT_NAME_PROPERTY), DEFAULT_CONTACT_NAME);
        contactEmail = config.ais_contactEmail();
        //contactEmail = PropertiesUtil.toString(properties.get(CONTACT_EMAIL_PROPERTY), DEFAULT_CONTACT_EMAIL);

        distributionAgentName = config.distribution_agent_name();
        //distributionAgentName = PropertiesUtil.toString(properties.get(DISTRIBUTION_AGENT_NAME_PROPERTY),
        //        DEFAULT_DISTRIBUTION_AGENT_NAME);

        ftpAddress = config.ftp_address();
        //ftpAddress = PropertiesUtil.toString(properties.get(FTP_ADDRESS_PROPERTY), StringUtils.EMPTY);
        ftpUsername = config.ftp_username();
        //ftpUsername = PropertiesUtil.toString(properties.get(FTP_USERNAME_PROPERTY), StringUtils.EMPTY);
        ftpPassword = config.ftp_password();
        //ftpPassword = PropertiesUtil.toString(properties.get(FTP_PASSWORD_PROPERTY), StringUtils.EMPTY);
        ftpDirectory = config.ftp_directory();
        //ftpDirectory = PropertiesUtil.toString(properties.get(FTP_DIRECTORY_PROPERTY), StringUtils.EMPTY);

        ftpConfigured = StringUtils.isNoneBlank(ftpAddress, ftpUsername, ftpPassword, ftpDirectory);

        //TODO: is query transaction required?
        //final int queryDelay = PropertiesUtil.toInteger(properties.get(QUERY_DELAY_PROPERTY), DEFAULT_QUERY_DELAY);
        //final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
        //if (transactionQueryTask != null && !transactionQueryTask.isDone()) {
        //    transactionQueryTask.cancel(false);
        //}
        //transactionQueryTask = executor.scheduleWithFixedDelay(new TransactionQueryTask(this, resourceResolverFactory), queryDelay, queryDelay, TimeUnit.SECONDS);
    }
}
