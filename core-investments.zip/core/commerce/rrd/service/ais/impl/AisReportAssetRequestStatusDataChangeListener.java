package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.impl;

import java.util.List;
import java.util.Map;


import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.observation.ResourceChange;
import org.apache.sling.api.resource.observation.ResourceChangeListener;
import org.apache.sling.event.jobs.JobManager;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;


import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Component(
		name="AIS ReportAsset Request Status Datachange Listener Implementation",
		service=ResourceChangeListener.class,
		immediate = true,
		property= {
				ResourceChangeListener.PATHS+"="+JhiConstants.VAR_ASSET_REQUEST_STATUS_PATH,
				ResourceChangeListener.CHANGES+"=ADDED"
		})

public class AisReportAssetRequestStatusDataChangeListener implements ResourceChangeListener {

    
    private SlingSettingsService slingSettingsService;
    @Reference
    public void bindSlingSettingsService(SlingSettingsService slingSettingsService) {
    	this.slingSettingsService=slingSettingsService;
    }
    public void unbindSlingSettingsService(SlingSettingsService slingSettingsService) {
    	this.slingSettingsService=slingSettingsService;
    }
    
    private JobManager jobManager;
    @Reference
    public void bindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }
    public void unbindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }
    

    private boolean onAuthor;

    @Override
    public void onChange(List<ResourceChange> changes) {
        if (onAuthor) {
            for (ResourceChange change : changes) {
                String path = change.getPath();
                Map<String, Object> eventProperties = ImmutableMap.<String, Object>builder().put(SlingConstants.PROPERTY_PATH, path).build();
                jobManager.addJob(AisReportAssetRequestStatusUpdateJob.JOB_NAME, eventProperties);
            }
        }
    }

    @Activate
    protected void activate() {
        onAuthor = slingSettingsService.getRunModes().contains(JhiConstants.RUN_MODE_AUTHOR);
    }
}
