package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.impl;

public class FtpSentStatus {
    public static final FtpSentStatus SUCCESS = new FtpSentStatus(true, "File sent to FTP");
    public static final FtpSentStatus CSS_ITEM_NO_FILE = new FtpSentStatus(true, "No file defined");

    public static final FtpSentStatus ERROR_NO_PRODUCT = new FtpSentStatus(false, "No product");
    public static final FtpSentStatus ERROR_NO_FILE = new FtpSentStatus(false, "Product has no file defined");
    public static final FtpSentStatus ERROR = new FtpSentStatus(false, "FTP sending failed");

    private boolean success;
    private String message;

    private FtpSentStatus(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
