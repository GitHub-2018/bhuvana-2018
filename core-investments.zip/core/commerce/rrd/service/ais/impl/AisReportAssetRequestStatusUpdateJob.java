package com.jhi.aem.website.v1.core.commerce.rrd.service.ais.impl;

import java.util.HashMap;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.Product;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Component(
		service=JobConsumer.class,
		name="AIS ReportAsset Request Status Job",
		immediate=true,
		property= {
				JobConsumer.PROPERTY_TOPICS+"="+AisReportAssetRequestStatusUpdateJob.JOB_NAME
				
		})

public class AisReportAssetRequestStatusUpdateJob implements JobConsumer {
    public static final String JOB_NAME = "com/jhi/aem/website/aisReportAssetRequestStatusUpdate";

    public static final Logger LOGGER = LoggerFactory.getLogger(AisReportAssetRequestStatusUpdateJob.class);
    private static final String COMPLETE_STATUS_CODE = "100";


    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder = queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder = queryBuilder;
    }

    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory = resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory = resourceResolverFactory;
    }
    
    private Replicator replicator;
    @Reference
    public void bindReplicator(Replicator replicator) {
    	this.replicator = replicator;
    }
    public void unbindReplicator(Replicator replicator) {
    	this.replicator = replicator;
    }

	@Override
	public synchronized JobResult process(Job job) {
		final String updatedDataPath = job.getProperty(SlingConstants.PROPERTY_PATH).toString();
		JobResult result = JobResult.FAILED;
		if (StringUtils.isNotBlank(updatedDataPath)
				&& !StringUtils.equals(updatedDataPath, JhiConstants.VAR_ASSET_REQUEST_STATUS_PATH)) {
			ResourceResolver resourceResolver = null;
			try {
				resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
				if (resourceResolver != null) {
					Resource updatedDataResource = resourceResolver.getResource(updatedDataPath);
					if (updatedDataResource != null) {
						ValueMap statusValueMap = updatedDataResource.getValueMap();
						String code = statusValueMap.get(RrdProductImpl.CODE, String.class);
						String status = statusValueMap.get(RrdProductImpl.RRD_STATUS, String.class);
						String statusMessage = statusValueMap.get(RrdProductImpl.RRD_STATUS_MESSAGE, String.class);
						if (StringUtils.isNotBlank(code) && StringUtils.isNotBlank(status)) {
							Resource productResource = searchProductByCode(resourceResolver, code);
							if (productResource != null) {
								ModifiableValueMap productValueMap = productResource.adaptTo(ModifiableValueMap.class);
								if (productValueMap != null) {
									if (COMPLETE_STATUS_CODE.equals(status)) {
										productValueMap.put(RrdProductImpl.RRD_STATUS,
												RrdProductImpl.RRD_STATUS_COMPLETE);
										productValueMap.put(RrdProductImpl.RRD_STATUS_MESSAGE, StringUtils.EMPTY);
									} else {
										productValueMap.put(RrdProductImpl.RRD_STATUS,
												RrdProductImpl.RRD_STATUS_FAILED);
										productValueMap.put(RrdProductImpl.RRD_STATUS_MESSAGE,
												StringUtils.defaultString(statusMessage));
									}
									try {
										resourceResolver.commit();
										cleanStatusEntry(updatedDataResource);
										try {
											Session session = resourceResolver.adaptTo(Session.class);
											replicator.replicate(session, ReplicationActionType.ACTIVATE,
													productResource.getPath());
										} catch (ReplicationException e) {
											LOGGER.error(
													"Problem while activating product: " + productResource.getPath(),
													e);
										}
										result = JobResult.OK;
									} catch (PersistenceException e) {
										LOGGER.error("Problem while saving rrd status for: " + productResource.getPath()
												+ " [" + updatedDataPath + "]");
									}
								}
							}
						} else {
							result = JobResult.CANCEL;
							cleanStatusEntry(updatedDataResource);
						}
					}

					// GIT issue #1712 - Closing all open ResourceResolver objects
					// This can leave sessions open internally if not closed
					// You open it , you close it
				}
			} finally {
				if (resourceResolver != null && resourceResolver.isLive()) {
					resourceResolver.close();
				}
			}

		}
		if (result == JobResult.FAILED) {
			LOGGER.error("Problem while processing RARS update:" + updatedDataPath);
		}
		return result;
	}

    private void cleanStatusEntry(Resource updatedDataResource) {
        if (updatedDataResource != null) {
            ResourceResolver resourceResolver = updatedDataResource.getResourceResolver();
            Session session = resourceResolver.adaptTo(Session.class);
            String dataResourcePath = updatedDataResource.getPath();
            try {
                replicator.replicate(session, ReplicationActionType.DELETE, dataResourcePath);
            } catch (ReplicationException e) {
                LOGGER.error("Problem while deactivating RARS status data: " + dataResourcePath, e);
            }
            try {
                resourceResolver.delete(updatedDataResource);
                resourceResolver.commit();
            } catch (PersistenceException e) {
                LOGGER.error("Problem while deleting RARS status data: " + dataResourcePath, e);
            }
        }
    }

    private Resource searchProductByCode(ResourceResolver resourceResolver, String code) {
        final Map<String, String> searchParams = new HashMap<>(5);
        searchParams.put(PathPredicateEvaluator.PATH, JhiConstants.RRD_PRODUCTS_ROOT);
        searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY);
        searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER, Product.RESOURCE_TYPE_PRODUCT);
        searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY, RrdProductImpl.CODE);
        searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER, code);

        final Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
        query.setStart(0);
        query.setHitsPerPage(1);
        /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        SearchResult result = query.getResult();
        if (!result.getHits().isEmpty()) {
            for (Hit hit : result.getHits()) {
                try {
                	String productPath = hit.getPath();
                    Resource productResource = resourceResolver.getResource(productPath);
                    if (productResource != null) {
                        return productResource;
                    }
                } catch (RepositoryException e) {
                    LOGGER.error("Problem fetching product resource", e);
                }
            }
        }
        /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        return null;
    }
}