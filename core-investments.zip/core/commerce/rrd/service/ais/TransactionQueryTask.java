package com.jhi.aem.website.v1.core.commerce.rrd.service.ais;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.ais.generated.ResponseQT;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

public class TransactionQueryTask implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionQueryTask.class);

    private ResourceResolverFactory resourceResolverFactory;
    private AisService aisService;

    public TransactionQueryTask(AisService aisService, ResourceResolverFactory resourceResolverFactory) {
        this.aisService = aisService;
        this.resourceResolverFactory = resourceResolverFactory;
    }

    @Override
    public void run() {
        ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
        if (resourceResolver != null) {
        	
        	try {
	            List<Resource> productsToUpdate = getProductsToUpdate(resourceResolver);
	            for (Resource productResource : productsToUpdate) {
	                ModifiableValueMap valueMap = productResource.adaptTo(ModifiableValueMap.class);
	                String txnId = valueMap.get(RrdProductImpl.RRD_TXN_ID, StringUtils.EMPTY);
	                if (StringUtils.isNotBlank(txnId)) {
	                    ResponseQT responseQT = aisService.queryTransaction(txnId);
	                    if (responseQT != null && responseQT.getQTDetails() != null
	                            && responseQT.getQTDetails().getTxnStatusCode() == AisService.QT_STATUS_SUCCESS) {
	                        valueMap.put(RrdProductImpl.RRD_STATUS, RrdProductImpl.RRD_STATUS_PROCESSED);
	                    }
	                }
	            }

	            try {
	                resourceResolver.commit();
	            } catch (PersistenceException e) {
	                LOGGER.error("Problem while committing changes", e);
	            }

        	} finally {
        		resourceResolver.close();
        	}
        }
    }

    private List<Resource> getProductsToUpdate(ResourceResolver resourceResolver) {
        QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
        Query query = queryBuilder.createQuery(PredicateGroup.create(getSearchParams()), resourceResolver.adaptTo(Session.class));
        SearchResult queryResult = query.getResult();
        List<Hit> hits = queryResult.getHits();
        /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        if (!hits.isEmpty()) {
            List<Resource> results = new ArrayList<>((int) queryResult.getTotalMatches());
            for (Hit hit : queryResult.getHits()) {
                try {
                	String productPath = hit.getPath();
                    Resource productResource = resourceResolver.getResource(productPath);
                    if (productResource != null) {
                        results.add(productResource);
                    }
                } catch (RepositoryException e) {
                    LOGGER.error("Problem while taking product resource", e);
                }
            }
            return results;
        }
        /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        return Collections.emptyList();
    }

    private Map<String, String> getSearchParams() {
        Map<String, String> searchParams = new HashMap<>(3);
        searchParams.put(PathPredicateEvaluator.PATH, JhiConstants.RRD_PRODUCTS_ROOT);
        searchParams.put(JcrPropertyPredicateEvaluator.PROPERTY, RrdProductImpl.RRD_STATUS);
        searchParams.put(JhiConstants.PROPERTY_VALUE_PARAMETER, RrdProductImpl.RRD_STATUS_SUBMITTED);
        return searchParams;
    }
}