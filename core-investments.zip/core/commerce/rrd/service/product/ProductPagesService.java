package com.jhi.aem.website.v1.core.commerce.rrd.service.product;

import org.apache.sling.api.resource.Resource;

public interface ProductPagesService {
    String PAGES_MAP_PROPERTY = "pagesMap";
    String[] DEFAULT_PAGES_MAP = {"/var/commerce/products/jhi-rrd/ucits:/content/jhi-website/en/resources/all-resources",
    		"/var/commerce/products/jhi-rrd:/content/jhi-website/en_US/resources/all-resources"};

    ProductPageResult createPage(Resource productResource);

    String getPagesRoot(String productPath);
}
