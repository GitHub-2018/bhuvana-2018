package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;

import java.util.Collections;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import javax.jcr.observation.ObservationManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.event.jobs.JobManager;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Component(name = "Product Moved Listener", immediate = true)
//@Component(
//		name="Product Moved Listener",
//		service=ResourceChangeListener.class,
//		immediate = true,
//		property={
//				ResourceChangeListener.PATHS+"="+ JhiConstants.PRODUCTS_ROOT,
//				ResourceChangeListener.CHANGES+"=ADDED"
//		})
public class ProductMovedListener implements EventListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductMovedListener.class);

    
	private JobManager jobManager;

	@Reference
	public void bindJobManager(JobManager jobManager) {
		this.jobManager = jobManager;
	}

	public void unbindJobManager(JobManager jobManager) {
		this.jobManager = jobManager;
	}

	private ResourceResolverFactory resourceResolverFactory;

	@Reference
	public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory = resourceResolverFactory;
	}

	public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory = resourceResolverFactory;
	}

	private ObservationManager observationManager;
	private ResourceResolver resolver;

	@Activate
	protected void activate(ComponentContext ctx) {
		resolver = null;

		try {
			resolver = resourceResolverFactory.getServiceResourceResolver(
					Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));

			final Session session = resolver.adaptTo(Session.class);
			observationManager = session.getWorkspace().getObservationManager();
			final String[] types = { "nt:unstructured" };
			observationManager
					.addEventListener(
							this, Event.NODE_MOVED | Event.NODE_ADDED,
							JhiConstants.PRODUCTS_ROOT, true, null, types, false);
		} catch (LoginException | RepositoryException e1) {
			LOGGER.error("Could not initialise ", e1);
			throw new RuntimeException(e1);
		}
	}

	@Deactivate
	public void deactivate() {
		if (resolver != null) {
			resolver.close();
		}
	}

	@Override
	public void onEvent(EventIterator events) {
		while (events.hasNext()) {
			Event event = events.nextEvent();

            String path = null;
			try {
				path = event.getPath();
			} catch (RepositoryException e) {
				LOGGER.warn("Could not get path for event", e);
			}

			if (StringUtils.isNotEmpty(path)) {
				Resource resource = resolver.resolve(path);
	
				if (resource.getValueMap().containsKey(RrdProductImpl.RESOURCE_PAGE_PATH)) {
	                Map<String, Object> eventProperties =
	                		ImmutableMap.<String, Object>builder().put(SlingConstants.PROPERTY_PATH, path).build();
	                jobManager.addJob(ProductMovedUpdateJob.JOB_NAME, eventProperties);				
				}
			}
        }
    }
}
