package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;




import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.DispatcherFlushUtil;

import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component(
		name="JHI Product Page Cache Flush Workflow",
		service=WorkflowProcess.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductPageCacheFlushWorkflow",
		property= {
				Constants.SERVICE_DESCRIPTION+"=JH Product Page Cache Flush Workflow process",
				Constants.SERVICE_VENDOR+"="+ JhiConstants.SERVICE_VENDOR,        
		})

public class ProductPageCacheFlushWorkflow implements WorkflowProcess {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductPageCacheFlushWorkflow.class);

    @Override
    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
        LOGGER.debug("ProductPageCacheFlushWorkflow execute method start.");
        String pathToClear = JhiConstants.FUNDS_PAGE_PATH;
        DispatcherFlushUtil.clearDispatcherCache(pathToClear);
        LOGGER.debug("ProductPageCacheFlushWorkflow execute method end.");
    }

}
