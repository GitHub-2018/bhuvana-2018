package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;

import static java.util.stream.Collectors.joining;

import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import javax.jcr.Node;

import javax.jcr.RepositoryException;
import javax.jcr.Session;


import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;

import com.day.cq.replication.Replicator;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.workflow.PayloadMap;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPageResult;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPagesService;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.resources.ResourceCategoryType;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.service.resources.DocumentsUtil;
import com.jhi.aem.website.v1.core.service.resources.ResourceTypeModel;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Component(name = "Product Pages Service Implementation", service = ProductPagesService.class, immediate = true, configurationPid = "com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductPagesServiceImpl", property = {
		Constants.SERVICE_DESCRIPTION + "=Product pages service Implementations",
		Constants.SERVICE_VENDOR + "=" + JhiConstants.SERVICE_VENDOR })

@Designate(ocd = ProductPagesServiceImpl.Config.class)
public class ProductPagesServiceImpl implements ProductPagesService {

	public final static String DOCUMENT_PATH = "document";
	private String scheduled_deactivation_model = null;
	private String jh_scheduled_deactivation_model = null;
	private String jh_scheduled_activation_model = null;
	private boolean onAuthor;
	private Map<String, String> pagesMap;
	private List<String> productsRoots;
	private String statusMessage ;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductPagesServiceImpl.class);

	@ObjectClassDefinition(name = "Product Page Service configuration for JHI Website", description = "Configuration properties for Product Page Implementation service")
	public @interface Config {
		String DEFAULT_SCHEDULED_DEACTIVATION_MODEL = "/etc/workflow/models/scheduled_deactivation/jcr:content/model";
		String DEFAULT_JH_SCHEDULED_DEACTIVATION_MODEL = "/etc/workflow/models/jh_scheduled_deactivation/jcr:content/model";
		String DEFAULT_JH_SCHEDULED_ACTIVATION_MODEL = "/etc/workflow/models/jh_scheduled_activation/jcr:content/model";

		@AttributeDefinition(name = "Product Pages Map", description = "A map of product pages")
		String[] pagesMap();

		@AttributeDefinition(name = "Scheduled deactivation model Path", description = "Name of scheduled deactivation model path")
		String scheduled_deactivation_model() default DEFAULT_SCHEDULED_DEACTIVATION_MODEL;

		@AttributeDefinition(name = "JH scheduled deactivation model path", description = "Name of JH scheduled deactivation model path")
		String jh_scheduled_deactivation_model() default DEFAULT_JH_SCHEDULED_DEACTIVATION_MODEL;

		@AttributeDefinition(name = "JH scheduled activation model path", description = "Name of JH scheduled activation model path")
		String jh_scheduled_activation_model() default DEFAULT_JH_SCHEDULED_ACTIVATION_MODEL;

	}

	@Reference
	private RunModeService runModeService;

	@Reference
	private Replicator replicator;

	@Reference
	private QueryBuilder queryBuilder;

	@Reference
	private WorkflowService workflowService;

	@Reference
	private PayloadMap payloadMap;

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Activate
	@Modified
	protected void activate(final Config config) {
		onAuthor = runModeService.isAuthor();
		update(config);
	}

	protected void update(final Config config) {
		String[] pagesMapProperty = PropertiesUtil.toStringArray(config.pagesMap(), DEFAULT_PAGES_MAP);
		Map<String, String> newPagesMap = new LinkedHashMap<>(pagesMapProperty.length);
		List<String> newProductsRoots = new LinkedList<>();
		if (!ArrayUtils.isEmpty(pagesMapProperty)) {
			for (String line : pagesMapProperty) {
				String lineParts[] = StringUtils.split(line, JhiConstants.COLON);
				if (lineParts.length == 2) {
					LOGGER.info("Added pages map config: {} = {}", lineParts[0], lineParts[1]);
					newPagesMap.put(lineParts[0], lineParts[1]);
					newProductsRoots.add(lineParts[0]);
				}
			}
		}
		pagesMap = newPagesMap;
		productsRoots = newProductsRoots;

		scheduled_deactivation_model = config.scheduled_deactivation_model();
		jh_scheduled_activation_model = config.jh_scheduled_activation_model();
		jh_scheduled_deactivation_model = config.jh_scheduled_deactivation_model();
	}

	@Override
	public ProductPageResult createPage(Resource productResource) {
		statusMessage=null;
		if (!onAuthor) {
			return new ProductPageResult(false, statusMessage);
		}

		ValueMap productValueMap = productResource.getValueMap();
		String displayTitle = productValueMap.get(RrdProductImpl.DISPLAY_TITLE, StringUtils.EMPTY);
		

		if (StringUtils.isBlank(displayTitle)) {
			return new ProductPageResult(false, "Product display title is blank");
		}

		String pagesRoot = getPagesRoot(productResource.getPath());
		
		if (StringUtils.isBlank(pagesRoot)) {
			return new ProductPageResult(false, "No resources pages root found. Please check configuration.");
		}

		Resource rootPageResource = productResource.getResourceResolver().getResource(pagesRoot);
		if (rootPageResource == null) {
			return new ProductPageResult(false,
					"Resources pages root '" + pagesRoot + "' cannot be used. Please check configuration.");
		}

		Resource resourcePageResource;
		try {

			resourcePageResource = createResourcePage(productResource, rootPageResource);

			if (resourcePageResource == null) {
				return new ProductPageResult(false, statusMessage);
			}
			ModifiableValueMap productProperties = productResource.adaptTo(ModifiableValueMap.class);
			if (productProperties != null) {
				productProperties.put(RrdProductImpl.LAST_PUBLISH_ON_WEB, Calendar.getInstance());
				productProperties.put(RrdProductImpl.RESOURCE_PAGE_PATH, resourcePageResource.getPath());
				try {
					productResource.getResourceResolver().commit();
				} catch (PersistenceException e) {
					LOGGER.error("Problem while saving last created time");
					statusMessage = "last created time stamp was not set";
				}
			} else {
				LOGGER.error("Can't update properties for product" + productResource.getPath());
				statusMessage = "product properties were not updated";
			}

		} catch (RepositoryException re) {
			LOGGER.error("RepositoryException thrown " + productResource.getPath());
			statusMessage = "product was not saved";
		}
		statusMessage = (null == statusMessage) ? "Page Created" : "Page Created but " + statusMessage;
		return new ProductPageResult(true, statusMessage);
	}

	private Resource createResourcePage(Resource productResource, Resource rootPageResource)
			throws RepositoryException {
		LOGGER.debug("Creating the resource pages under {} for {}", rootPageResource.getPath(),
				productResource.getPath());

		Resource resourcePageResource = null;

		ResourceResolver serviceResolver;
		try {
			serviceResolver = resolverFactory.getServiceResourceResolver(
					Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));
		} catch (LoginException e) {
			statusMessage = "Admin User does not exist";
			throw new RepositoryException("Could not get admin resource resolver", e);
		}

		try {
			String categoryName = "other";

			RrdProductImpl product = new RrdProductImpl(productResource);

			if (DocumentsUtil.isResource(product.getDocumentType())) {
				String productCategory = product.getCategory();
				if (StringUtils.isNotEmpty(productCategory)) {
					ResourceCategoryType categoryType = ResourceCategoryType.getByName(productCategory);
					if (categoryType != null) {
						categoryName = categoryType.getCategoryLocation();
					}
				}
			}

			Resource categoryPageResource = createOrGetCategoryResource(serviceResolver, rootPageResource,
					categoryName);

			if (categoryPageResource == null) {
				statusMessage = "Failed to create category Page";
				LOGGER.error("Problem while creating resource category page: {}", product.getPath());
				return null;
			}

			if (StringUtils.isBlank(product.getDisplayTitle())) {
				statusMessage = "Product Display title is empty or blank";
				LOGGER.error("Product display title is empty for product: {}", product.getPath());
				return null;
			}

			String resourcePageName = createPageName(product.getDisplayTitle());
			

			if (StringUtils.isNotBlank(resourcePageName)) {
				resourcePageResource = serviceResolver.getResource(categoryPageResource, resourcePageName);

				// New resource page to be created for a new product or existing product
				if (resourcePageResource == null || ResourceUtil.isNonExistingResource(resourcePageResource)) {
					String oldPage = cleanOldResourcePages(productResource);
					resourcePageResource = createOrUpdateResourcePage(serviceResolver, resourcePageName,
							categoryPageResource.getPath(), product);

				} else {
					resourcePageResource = createOrUpdateResourcePage(serviceResolver, resourcePageName,
							categoryPageResource.getPath(), product);

				}
				if (null != resourcePageResource) {
					replicatePages(serviceResolver, resourcePageResource.getPath(), product);
					replicatePages(serviceResolver, productResource.getPath(), product);
					if (StringUtils.isNoneBlank(product.getPrintAssetPath())) {
						if (serviceResolver.getResource(product.getPrintAssetPath()) != null) {
							replicatePages(serviceResolver, product.getPrintAssetPath(), product);
						}
					}
					if (StringUtils.isNoneBlank(product.getWebAssetPath())) {
						if (serviceResolver.getResource(product.getWebAssetPath()) != null) {
							replicatePages(serviceResolver, product.getWebAssetPath(), product);
						}
					}
					String fundDetailsPagePath = getFundDetailsPagePath(rootPageResource);
					if (StringUtils.isNotBlank(fundDetailsPagePath)) {
						replicatePages(serviceResolver, fundDetailsPagePath, null);
					}
					product.setPageStatusCreated();
				} else {
					return null;
				}

			} else {
				LOGGER.error("Page name is blank");
				statusMessage = "Page name is blank";
				return null;
			}

		} finally {
			serviceResolver.close();
		}

		return resourcePageResource;
	}

	private void replicatePages(ResourceResolver serviceResolver, String path, RrdProductImpl product) {
		LOGGER.debug("Replicating path: {}", path);

		Session session = serviceResolver.adaptTo(Session.class);
		boolean pubDateExist = null != product ? isPubDateExist(product) : false;
		boolean expDateExist = null != product ? isExpDateExist(product) : false;

		try {
			if (expDateExist) {
				deactivateContent(session, path, product.getExpirationDate());
			}

			if (pubDateExist) {
				activateContent(session, path, product.getPublishDate(), null);
			} else {
				terminateAllworkflows(session, path);
				replicator.replicate(session, ReplicationActionType.ACTIVATE, path);
				
			}
		} catch (RepositoryException | ReplicationException e) {
			statusMessage = "Page activation failed";
			LOGGER.error("Replication failed" + e.getMessage());
		}
	}

	private Resource createOrUpdateResourcePage(ResourceResolver serviceResolver, String resourcePageName,
			String categoryPagePath, RrdProductImpl product) {

		String resourcePagePath = categoryPagePath + "/" + resourcePageName;
		Resource resourcePage = null;

		try {
			Map<String, Object> pageProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE, NameConstants.NT_PAGE);
			resourcePage = ResourceUtil.getOrCreateResource(serviceResolver, resourcePagePath, pageProperties, null,
					true);
			boolean existingResourcePage = checkExistingResourcePage(resourcePage, product.getPath());

			if (existingResourcePage) {
				statusMessage = product.getDisplayTitle() + " is already being used by another product";
				return null;
			} else {
				try {
					String resourcePageContentPath = resourcePage.getPath() + "/" + JcrConstants.JCR_CONTENT;
					Map<String, Object> pageContentProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE,
							JhiConstants.PAGE_CONTENT_TYPE);
					Resource resourcePageContent = ResourceUtil.getOrCreateResource(serviceResolver,
							resourcePageContentPath, pageContentProperties, null, true);

					ModifiableValueMap pageContentMap = resourcePageContent.adaptTo(ModifiableValueMap.class);
					pageContentMap.put(ResourceResolver.PROPERTY_RESOURCE_TYPE,
							ResourcesConstants.RESOURCE_DOCUMENT_PAGE_RESOURCE_TYPE);
					pageContentMap.put(JhiConstants.ALLOWED_FIRMS_PROPERTY, product.getAllowedArray());
					pageContentMap.put(JhiConstants.ACCESS_PROPERTY, product.getAccess());
					pageContentMap.put(JcrConstants.JCR_TITLE, product.getDisplayTitle());
					pageContentMap.put(NameConstants.PN_PAGE_TITLE, product.getMetaTitle());
					pageContentMap.put(JcrConstants.JCR_DESCRIPTION, product.getMetaDescription());
					pageContentMap.put(ResourceDocumentModel.ORDERABLE_PROPERTY, product.isOrderable());
					pageContentMap.put(NameConstants.PN_PAGE_LAST_MOD, Calendar.getInstance());

					if (product.getPublishDate() != null) {
						pageContentMap.put(RrdProductImpl.PUBLISH_DATE, product.getPublishDate());
					}
					if (StringUtils.isNotBlank(product.getDocumentType())) {
						pageContentMap.put(RrdProductImpl.DOCUMENT_TYPE, product.getDocumentType());
					}
					if (product.getExpirationDate() != null) {
						pageContentMap.put(NameConstants.PN_OFF_TIME, product.getExpirationDate());
					}
					if (StringUtils.isNotBlank(product.getCategory())) {
						pageContentMap.put(ResourceTypeModel.CATEGORY_PARAMETER, product.getCategory());
					}
					if (!ArrayUtils.isEmpty(product.getTopics())) {
						pageContentMap.put(ResourceTypeModel.TOPICS_PARAMETER, product.getTopics());
					}
					if (!ArrayUtils.isEmpty(product.getAudiences())) {
						pageContentMap.put(ResourceTypeModel.AUDIENCES_PARAMETER, product.getAudiences());
					}
					if (!ArrayUtils.isEmpty(product.getFunds())) {
						pageContentMap.put(JhiConstants.INVESTMENT_TAGS_PROPERTY, product.getFunds());
					}

					Resource documentResource = createOrUpdateDocumentResource(product, serviceResolver,
							resourcePageContent);
					if (null == documentResource) {
						serviceResolver.delete(resourcePage);
						serviceResolver.commit();
						return null;
					}
				} catch (PersistenceException e) {
					LOGGER.error("Unable to create resouce content Page :" + e.getMessage());
					statusMessage = "Unable to create resouce content";
					serviceResolver.delete(resourcePage);
					serviceResolver.commit();
					return null;
				}

			}
		} catch (PersistenceException e) {
			LOGGER.error("Unable to create resource Page :" + e.getMessage());
			statusMessage = "Unable to create resource Page";
			return null;
		}

		return resourcePage;

	}

	private boolean checkExistingResourcePage(Resource resourcePage, String productPath) {
		boolean sameProdPage = true;
		try {
			Node resourcePageNode = resourcePage.adaptTo(Node.class);
			if (resourcePageNode.hasNode(JcrConstants.JCR_CONTENT + "/" + DOCUMENT_PATH)) {
				Node documentNode = resourcePageNode.getNode(JcrConstants.JCR_CONTENT + "/" + DOCUMENT_PATH);
				String prodPath = documentNode.hasProperty("productPath")
						? documentNode.getProperty("productPath").getString()
						: null;
				sameProdPage = prodPath.equals(productPath);
			}
		} catch (RepositoryException e) {
			LOGGER.error("Unable to verify resourcePage :" + e.getMessage());
			sameProdPage = true;
		}
		return !sameProdPage;
	}

	private String getFundDetailsPagePath(Resource rootPageResource) {
		Page homePage = PageUtil.getHomePage(rootPageResource);
		if (homePage != null) {
			Page investmentsPage = PageUtil.getChildByResourceType(homePage,
					ResourcesConstants.INVESTMENTS_PAGE_RESOURCE_TYPE);
			if (investmentsPage != null) {
				Page fundDetailsPage = PageUtil.getChildByResourceType(homePage,
						ResourcesConstants.FUND_DETAILS_PAGE_RESOURCE_TYPE);
				if (fundDetailsPage != null) {
					LOGGER.debug("Fund Details page " + fundDetailsPage.getPath());
					return fundDetailsPage.getPath();
				}
			}
		}
		return StringUtils.EMPTY;
	}

	private String cleanOldResourcePages(Resource productResource) {
		
		ResourceResolver resourceResolver = productResource.getResourceResolver();
		SearchResult result = getProductUsages(resourceResolver, productResource.getPath());

		/*
		 * START - Change the method call getResource from search results hits as this
		 * is creating a unclosed internal resolver session
		 */
		String oldPagePath = null;
		if (!result.getHits().isEmpty()) {
			PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
			if (pageManager != null) {
				for (Hit hit : result.getHits()) {
					try {
						String productPath = hit.getPath();
						Resource productDocumentResource = resourceResolver.getResource(productPath);

						if (productDocumentResource != null) {
							Page resourcePage = pageManager.getContainingPage(productDocumentResource);
							oldPagePath = resourcePage.getPath();
							removeResourcePage(oldPagePath, resourceResolver, productResource);

						}

					} catch (RepositoryException e) {
						statusMessage = "failed to delete old resource pages";
						LOGGER.error("Problem while obtaining product document resource", e);
					}
				}
			} else {
				LOGGER.error("Page manager is null");
			}
		}
		/*
		 * END - Change the method call getResource from search results hits as this is
		 * creating a unclosed internal resolver session
		 */

		return oldPagePath;
	}

	private void removeResourcePage(String resourcePagePath, ResourceResolver serviceResolver,
			Resource productResource) {

		Session session = serviceResolver.adaptTo(Session.class);

		RrdProductImpl product = new RrdProductImpl(productResource);
		terminateAndDeactivatePage(session, resourcePagePath, product);
		Resource oldResourcePage = serviceResolver.getResource(resourcePagePath);
		if (oldResourcePage != null) {
			try {
				LOGGER.debug(" resourcePageResource is not null {} ", oldResourcePage.getPath());
				Node oldResourceNode = oldResourcePage.adaptTo(Node.class);
				oldResourceNode.remove();
				session.save();
				serviceResolver.refresh();
			} catch (RepositoryException e) {
				LOGGER.error("Problem while deleting old resource page: " + serviceResolver, e);

			}
		}

	}

	private void terminateAndDeactivatePage(Session session, String path, RrdProductImpl product) {
		try {

			terminateAllworkflows(session, path);
			replicator.replicate(session, ReplicationActionType.DELETE, path);
			if (StringUtils.isNotBlank(product.getWebAssetPath())) {
				terminateAllworkflows(session, product.getWebAssetPath());
				replicator.replicate(session, ReplicationActionType.DELETE, product.getWebAssetPath());
			}
			if (StringUtils.isNotBlank(product.getPrintAssetPath())) {
				terminateAllworkflows(session, product.getPrintAssetPath());
				replicator.replicate(session, ReplicationActionType.DELETE, product.getPrintAssetPath());
			}

		} catch (ReplicationException e) {
			statusMessage = "failed to terminate and deactivate old workflows";
			LOGGER.error("Deactivation of old resource pages failed :" + e);
		}
	}

	private SearchResult getProductUsages(ResourceResolver resourceResolver, String productPath) {
		String pagesRoot = getPagesRoot(productPath);
		final Map<String, String> searchParams = new HashMap<>(5);
		if (StringUtils.isNotBlank(pagesRoot)) {
			searchParams.put(PathPredicateEvaluator.PATH, pagesRoot);
		} else {
			searchParams.put(PathPredicateEvaluator.PATH, JhiConstants.CONTENT_ROOT);
		}
		searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY,
				ResourceDocumentModel.PRODUCT_PATH_PROPERTY);
		searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER, productPath);
		searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY,
				ResourceResolver.PROPERTY_RESOURCE_TYPE);
		searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER,
				ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE);
		Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams),
				resourceResolver.adaptTo(Session.class));
		return query.getResult();
	}

	private Resource createOrGetCategoryResource(ResourceResolver serviceResolver, Resource rootPageResource,
			String categoryName) {

		Resource categoryPageResource = rootPageResource.getChild(categoryName);
		if (categoryPageResource != null) {
			return categoryPageResource;
		}
		try {
			String categoryPagePath = rootPageResource.getPath() + "/" + categoryName;
			Resource categoryResource = ResourceUtil.getOrCreateResource(serviceResolver, categoryPagePath,
					NameConstants.NT_PAGE, null, true);
			if (null != categoryResource) {
				Map<String, Object> pageContentProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE,
						JhiConstants.PAGE_CONTENT_TYPE, NameConstants.PN_TEMPLATE,
						ResourcesConstants.REDIRECT_PAGE_TEMPLATE, ResourceResolver.PROPERTY_RESOURCE_TYPE,
						ResourcesConstants.REDIRECT_PAGE_RESOURCE_TYPE, JcrConstants.JCR_TITLE,
						DocumentsUtil.RESOURCES_CATEGORIES_NAMES.get(categoryName));
				String categoryResourceContentPath = categoryResource.getPath() + "/" + JcrConstants.JCR_CONTENT;
				try {
				ResourceUtil.getOrCreateResource(serviceResolver,
						categoryResourceContentPath, pageContentProperties, null, true);
				}catch (PersistenceException e) {
					serviceResolver.delete(categoryResource);
					serviceResolver.commit();
					
					LOGGER.error("Problem while creating category resource content page", e);
				}
				serviceResolver.refresh();
				return categoryPageResource;
			}

		} catch (PersistenceException e) {
			LOGGER.error("Problem while creating category page", e);
		}
		return null;
	}

	private Resource createOrUpdateDocumentResource(RrdProductImpl product, ResourceResolver serviceResolver,
			Resource resourcePageContent) {
		String documentPath = resourcePageContent.getPath() + "/" + DOCUMENT_PATH;
		try {
			Map<String, Object> pageProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE,
					JcrConstants.NT_UNSTRUCTURED);
			Resource documentResource = ResourceUtil.getOrCreateResource(serviceResolver, documentPath, pageProperties,
					null, true);
			ModifiableValueMap documentPropertiesMap = documentResource.adaptTo(ModifiableValueMap.class);

			documentPropertiesMap.put(ResourceResolver.PROPERTY_RESOURCE_TYPE,
					ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE);
			documentPropertiesMap.put(ResourceDocumentModel.TITLE_PROPERTY, product.getDisplayTitle());
			documentPropertiesMap.put(ResourceDocumentModel.DESCRIPTION_PROPERTY, product.getDisplayDescription());
			documentPropertiesMap.put(ResourceDocumentModel.PRODUCT_PATH_PROPERTY, product.getPath());
			documentPropertiesMap.put(ResourceDocumentModel.ASSET_PATH_PROPERTY, product.getWebAssetPath());
			documentPropertiesMap.put(ResourceDocumentModel.THUMBNAIL_PATH_PROPERTY, product.getThumbnailPath());
			documentPropertiesMap.put(ResourceDocumentModel.FILE_TYPE_PROPERTY, product.getFileType());
			documentPropertiesMap.put(ResourceDocumentModel.FILE_SIZE_PROPERTY, product.getFileSize());
			documentPropertiesMap.put(ResourceDocumentModel.ORDERABLE_PROPERTY, product.isOrderable());
			documentPropertiesMap.put(ResourceDocumentModel.APPROVED_FOR_PROPERTY, product.getApprovedFor());
			if (StringUtils.isNotBlank(product.getCode())) {
				documentPropertiesMap.put(ResourceDocumentModel.PRODUCT_CODE_PROPERTY, product.getCode());
			}
			if (product.getLastUpdated() != null) {
				documentPropertiesMap.put(ResourceDocumentModel.REVISION_DATE_PROPERTY, product.getLastUpdated());
			}
			if (StringUtils.isNotBlank(product.getElectronicFormLink())) {
				documentPropertiesMap.put(ResourceDocumentModel.ELECTRONIC_FORM_LINK_PROPERTY,
						product.getElectronicFormLink());
			}
			serviceResolver.commit();
			return documentResource;

		} catch (PersistenceException e) {
			LOGGER.error("Unabe to create a document resource" + e.getMessage());
			statusMessage = "Unable to create resource document";
			return null;
		}

	}

	private String createPageName(String title) {
		if (StringUtils.isNotBlank(title)) {
			String sanitizedTitle = StringUtils.replacePattern(title, "'", StringUtils.EMPTY);
			String[] nameParts = sanitizedTitle.split("[^a-zA-Z0-9]");
			String name = Stream.of(nameParts).filter(StringUtils::isNotBlank).collect(joining(JhiConstants.DASH));
			if (StringUtils.isNotBlank(name)) {
				return name.toLowerCase();
			}
		}
		return StringUtils.EMPTY;
	}

	@Override
	public String getPagesRoot(String productPath) {
		if (StringUtils.isNotBlank(productPath)) {
			for (String root : productsRoots) {
				if (productPath.startsWith(root)) {
					return pagesMap.get(root);
				}
			}
		}
		return StringUtils.EMPTY;
	}

	// #1724 -fix
	private void activateContent(Session session, String resourcePath, Calendar date, String oldPage)
			throws ReplicationException, RepositoryException {

		LOGGER.debug("Activating content at path {}", resourcePath);
		WorkflowSession wfSession = workflowService.getWorkflowSession(session);
		if (null != date) {
			LOGGER.debug("before starting scheduled_activation_model.");
			terminateWorkflow(wfSession, jh_scheduled_activation_model, resourcePath);
			if (null != oldPage) {
				LOGGER.debug("old page path for deactivation - " + oldPage);
				startWorkflow(wfSession, jh_scheduled_deactivation_model, oldPage, date.getTimeInMillis());
			}
			startWorkflow(wfSession, jh_scheduled_activation_model, resourcePath, date.getTimeInMillis());
		}
	}

	private void deactivateContent(Session session, String resourcePath, Calendar date)
			throws ReplicationException, RepositoryException {
		LOGGER.debug("Deactivating content at path {}", resourcePath);
		WorkflowSession wfSession = workflowService.getWorkflowSession(session);
		if (null != date) {
			LOGGER.debug("before starting scheduled_deactivation_model.");
			terminateWorkflow(wfSession, scheduled_deactivation_model, resourcePath);
			startWorkflow(wfSession, scheduled_deactivation_model, resourcePath, date.getTimeInMillis());
		}
	}

	private void terminateAllworkflows(Session session, String resourcePath) {
		LOGGER.debug("Terminating all workflows at path {}", resourcePath);
		WorkflowSession wfSession = workflowService.getWorkflowSession(session);
		terminateWorkflow(wfSession, jh_scheduled_activation_model, resourcePath);
		terminateWorkflow(wfSession, scheduled_deactivation_model, resourcePath);
		terminateWorkflow(wfSession, jh_scheduled_deactivation_model, resourcePath);

	}
	// #1724 -fix - startworkflow method start the workfow based on scheduld
	// activation or deactivation.

	private void startWorkflow(WorkflowSession wfSession, String model, String resourcePath, long absTime)
			throws RepositoryException {
		LOGGER.debug("Entering startWorkflow method with model={}, path={}", model, resourcePath);
		try {
			// start workflow
			WorkflowModel wfModel = wfSession.getModel(model);
			WorkflowData wfDataProduct = wfSession.newWorkflowData("JCR_PATH", resourcePath);
			HashMap<String, Object> timeMap = new HashMap<String, Object>();
			timeMap.put("absoluteTime", absTime);
			LOGGER.debug("Model={}, Workflow Model={}, Data={}, Map={}",
					new Object[] { model, wfModel, wfDataProduct, timeMap });
			wfSession.startWorkflow(wfModel, wfDataProduct, timeMap);
			LOGGER.debug("workflow started on path : " + resourcePath);
		} catch (WorkflowException e) {
			LOGGER.error("WorkflowException thrown in doPost method", e);
		} catch (Exception e) {
			LOGGER.error("Exception thrown in doPost method", e);
		}

		LOGGER.debug("Exiting startWorkflow method.");
	}

	private void terminateWorkflow(WorkflowSession wfSession, String model, String resourcePath) {

		try {
			List<Workflow> wfList = payloadMap.getWorkflowInstances(resourcePath, true);
			for (Workflow wf : wfList) {
				if (null != wf && model.contentEquals(wf.getWorkflowModel().getId())) {
					wfSession.terminateWorkflow(wf);
					break;
				}
			}
		} catch (WorkflowException e) {
			statusMessage = "Unable to terminate existing workflows";
			LOGGER.error("Unable to terminate the existing workflow on payload path :" + resourcePath);
		}

	}

	// #1724 fix
	private boolean isPubDateExist(RrdProductImpl product) {

		boolean isPubDtExOnPrd = false;
		Calendar publishDate = product.getPublishDate();
		if (null != publishDate) {
			isPubDtExOnPrd = true;
		}
		return isPubDtExOnPrd;
	}

	// #1724 fix
	private boolean isExpDateExist(RrdProductImpl product) {

		boolean isExpDtExOnPrd = false;
		Calendar expDate = product.getExpirationDate();
		if (null != expDate) {
			isExpDtExOnPrd = true;
		}
		return isExpDtExOnPrd;
	}
}