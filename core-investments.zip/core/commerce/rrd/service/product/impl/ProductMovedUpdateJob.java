package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;


import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPagesService;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;


@Component(
		name="Product Moved Update Job",
		service=JobConsumer.class,
		immediate = true,
		property = {
				JobConsumer.PROPERTY_TOPICS+"="+ ProductMovedUpdateJob.JOB_NAME
		})
public class ProductMovedUpdateJob implements JobConsumer {
    public static final String JOB_NAME = "com/jhi/aem/website/productMoved";

    public static final Logger LOGGER = LoggerFactory.getLogger(ProductMovedUpdateJob.class);

   
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    
    private ProductPagesService productPagesService;
    @Reference
    public void bindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService=productPagesService;
    }
    public void unbindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService=productPagesService;
    }
    
    @Override
    public JobResult process(Job job) {
        JobResult jobResult = JobResult.FAILED;
        final String updatedProductPath = job.getProperty(SlingConstants.PROPERTY_PATH).toString();
        if (StringUtils.isNotBlank(updatedProductPath)) {
			ResourceResolver resourceResolver = null;
			try {
				resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
				if (resourceResolver != null) {
					Resource productResource = resourceResolver.getResource(updatedProductPath);
					jobResult = updateProductReference(resourceResolver, productResource);

					// GIT issue #1712 - Closing all open ResourceResolver objects
					// This can leave sessions open internally if not closed
					// You open it , you close it
				}
			} finally {
				if (resourceResolver != null && resourceResolver.isLive()) {
					resourceResolver.close();
				}
			}
            
        }
        return jobResult;
    }

    private JobResult updateProductReference(ResourceResolver resourceResolver, Resource productResource) {
        if (productResource != null) {
            RrdProductImpl product = new RrdProductImpl(productResource);
            String resourcePagePath = product.getResourcePagePath();
            if (StringUtils.isNotBlank(resourcePagePath)) {
                Resource productResourcePageResource = resourceResolver.getResource(resourcePagePath);
                if (productResourcePageResource != null) {
                    Resource pageContentResource = productResourcePageResource.getChild(JcrConstants.JCR_CONTENT);
                    if (pageContentResource != null) {
                        Resource documentResource = pageContentResource.getChild(ProductPagesServiceImpl.DOCUMENT_PATH);
                        if (documentResource != null) {
                            ModifiableValueMap documentValues = documentResource.adaptTo(ModifiableValueMap.class);
                            if (documentValues != null) {
                                documentValues.put(ResourceDocumentModel.PRODUCT_PATH_PROPERTY, productResource.getPath());
                                try {
                                    resourceResolver.commit();
                                    return JobResult.OK;
                                } catch (PersistenceException e) {
                                    LOGGER.error("Problem while persisting product path", e);
                                    return JobResult.FAILED;
                                }
                            } else {
                                return JobResult.FAILED;
                            }
                        }
                    }
                }
            }
        }
        return JobResult.CANCEL;
    }
}
