package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;


import java.util.HashMap;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPagesService;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;



@Component(
		name="Product Code Change Update Job",
		service=JobConsumer.class,
		immediate = true,
		property= {
				JobConsumer.PROPERTY_TOPICS+"="+ProductCodeChangeUpdateJob.JOB_NAME
		})

public class ProductCodeChangeUpdateJob implements JobConsumer {
    public static final String JOB_NAME = "com/jhi/aem/website/productCodeUpdate";

    public static final Logger LOGGER = LoggerFactory.getLogger(ProductCodeChangeUpdateJob.class);

    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }

    
    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }
    
    private ProductPagesService productPagesService;
    @Reference
    public void bindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService=productPagesService;
    }
    public void unbindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService=productPagesService;
    }
    
    @Override
    public JobResult process(Job job) {
        JobResult jobResult = JobResult.FAILED;
        final String updatedProductPath = job.getProperty(SlingConstants.PROPERTY_PATH).toString();
        if (StringUtils.isNotBlank(updatedProductPath)) {
			ResourceResolver resourceResolver = null;
			try {
				resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
				if (resourceResolver != null) {
					Resource productResource = resourceResolver.getResource(updatedProductPath);
					jobResult = updateResourcesPages(resourceResolver, productResource);

					// GIT issue #1712 - Closing all open ResourceResolver objects
					// This can leave sessions open internally if not closed
					// You open it , you close it
				}
			} finally {
				if (resourceResolver != null && resourceResolver.isLive()) {
					resourceResolver.close();
				}
			}
           
        }
        return jobResult;
    }

    private JobResult updateResourcesPages(ResourceResolver resourceResolver, Resource productResource) {
        if (productResource != null) {
            RrdProductImpl product = new RrdProductImpl(productResource);
            SearchResult result = getSearchResult(resourceResolver, productResource.getPath());
            /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
            if (!result.getHits().isEmpty()) {
                for (Hit hit : result.getHits()) {
                    try {
                    	String productPath = hit.getPath();
                        Resource productDocumentResource = resourceResolver.getResource(productPath);
                        if (productDocumentResource != null) {
                            ModifiableValueMap documentValues = productDocumentResource.adaptTo(ModifiableValueMap.class);
                            if (documentValues != null) {
                                documentValues.put(ResourceDocumentModel.PRODUCT_CODE_PROPERTY, product.getCode());
                                try {
                                    resourceResolver.commit();
                                    return JobResult.OK;
                                } catch (PersistenceException e) {
                                    LOGGER.error("Problem while persisting product code", e);
                                    return JobResult.FAILED;
                                }
                            }
                        }
                    } catch (RepositoryException e) {
                        LOGGER.error("Problem while updating product code", e);
                    }
                }
            }
            /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        }
        return JobResult.CANCEL;
    }

    private SearchResult getSearchResult(ResourceResolver resourceResolver, String productPath) {
        String pagesRoot = productPagesService.getPagesRoot(productPath);
        final Map<String, String> searchParams = new HashMap<>(3);
        if (StringUtils.isNotBlank(pagesRoot)) {
            searchParams.put(PathPredicateEvaluator.PATH, pagesRoot);
        } else {
            searchParams.put(PathPredicateEvaluator.PATH, JhiConstants.CONTENT_ROOT);
        }
        searchParams.put(JcrPropertyPredicateEvaluator.PROPERTY, ResourceDocumentModel.PRODUCT_PATH_PROPERTY);
        searchParams.put(JhiConstants.PROPERTY_VALUE_PARAMETER, productPath);
        final Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
        return query.getResult();
    }
}