package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;

import org.apache.commons.lang.StringUtils;

import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.event.jobs.JobManager;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.Product;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductOrderabilitySyncService;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.page.PageOrderabilityUpdateJob;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;


@Component(
		name="Product Orderability Sync Service Implementation",
		service=ProductOrderabilitySyncService.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductOrderabilitySyncServiceImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"=Product orderability sync service",
				Constants.SERVICE_VENDOR+"="+ JhiConstants.SERVICE_VENDOR,        
		})
@Designate(ocd=ProductOrderabilitySyncServiceImpl.Config.class)
public class ProductOrderabilitySyncServiceImpl implements ProductOrderabilitySyncService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductOrderabilitySyncServiceImpl.class);
    
    @ObjectClassDefinition(name="Product Orderability Sync Service Configuration for JHI Website", description="Configurations for Product orderability sync service implementations")
    public @interface Config{
    	@AttributeDefinition(name = "Enabled", description = "Configuration property to enable/disable the service, by default will be set to true")
    	boolean enabled() default true;
    	@AttributeDefinition(name = "Products root path", description = "Configuration property to specify the products root path")
    	String productsRootPath() default ProductOrderabilitySyncService.DEFAULT_PRODUCTS_ROOT_PATH;
    }
    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }

    
    private JobManager jobManager;
    @Reference
    public void bindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }
    public void unbindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }

    private boolean enabled;
    private String productsRootPath;

    @Override
    public void performSync() {
        if (enabled) {
            if (StringUtils.isNotBlank(productsRootPath)) {
                ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
                if (resourceResolver != null) {
                    Resource rootResource = resourceResolver.getResource(productsRootPath);
                    if (rootResource != null) {
                        processProducts(rootResource);
                    }
                    resourceResolver.close();
                }
            } else {
                if (StringUtils.isBlank(productsRootPath)) {
                    LOGGER.error("Products root page is blank");
                }
            }
        }
    }

    private void processProducts(Resource rootResource) {
        if (rootResource != null) {
            for (Resource resource : rootResource.getChildren()) {
                if (resource != null) {
                    if (resource.isResourceType(Product.RESOURCE_TYPE_PRODUCT)) {
                        jobManager.addJob(PageOrderabilityUpdateJob.JOB_NAME,
                                ImmutableMap.of(SlingConstants.PROPERTY_PATH, resource.getPath()));
                    } else if (resource.isResourceType(JcrResourceConstants.NT_SLING_FOLDER)
                            || resource.isResourceType(JcrResourceConstants.NT_SLING_ORDERED_FOLDER)) {
                        processProducts(resource);
                    }
                }
            }
        }
    }

    @Activate
    protected void activate(final Config config) {
        update(config);
    }

    @Modified
    protected void update(final Config config) {
        enabled = config.enabled();
        productsRootPath = config.productsRootPath(); 
        performSync();
    }
}
