package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;


import javax.jcr.RepositoryException;
import javax.jcr.Session;


import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.Product;
import com.day.cq.search.Predicate;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.eval.RangePropertyPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPagesService;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.schedulers.DAMFilesUploader.Config;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Component(
		name="Product Scheduled Activation Service implementation - JHI Website",
		service=Runnable.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductScheduledActivationServiceImpl",
        configurationPolicy= ConfigurationPolicy.REQUIRE
        )
@Designate(ocd=ProductScheduledActivationServiceImpl.Config.class)
public class ProductScheduledActivationServiceImpl implements Runnable {

    

    @ObjectClassDefinition(name="Product Activation Scheduler Configuration for JHI Website",description="Configrations for Scheduled Production Activation")
    public @interface Config{
    	   	
    	static final String SCHEDULER_EXPERSSION = "10 0/10 * * * ?";
		@AttributeDefinition(name = "Enabled", description = "Enable Scheduler", type = AttributeType.BOOLEAN)
		 boolean serviceEnabled() default true;
		
		@AttributeDefinition(name = "Concurrent", description = "Schedule task concurrently", type = AttributeType.BOOLEAN)
		 boolean schedulerConcurrent() default false;
		
		@AttributeDefinition(name = "Scheduler name", description = "Scheduler name", type = AttributeType.STRING)
		 public String schedulerName() default "JHI Website Product Activation Scheduler";
		
		@AttributeDefinition(name="Scheduler Expression", description ="Specify the scheduler expression as a quartz regex pattern")
		public String schedulerExpression() default SCHEDULER_EXPERSSION;
    }
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductScheduledActivationServiceImpl.class);
    private static final String RELATIVEDATERANGE = "relativedaterange";
    private static final String RELATIVE_NOW = String.valueOf(0);
    private static final String PREVIOUS_20_MINUTEs = "-1200000";

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory = resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory = resolverFactory;
    }

    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder ) {
    	this.queryBuilder=queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder ) {
    	this.queryBuilder=queryBuilder;
    }

    
    private ProductPagesService productPagesService;
    @Reference
    public void bindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService = productPagesService;
    }
    public void unbindProductPagesService(ProductPagesService productPagesService) {
    	this.productPagesService = productPagesService;
    }

    private RunModeService runModeService;
    @Reference
    public void bindRunModeService(RunModeService runModeService) {
    	this.runModeService = runModeService;
    }
    public void unbindRunModeService(RunModeService runModeService) {
    	this.runModeService = runModeService;
    }

    private boolean notFirstRun = false;
    
    private Scheduler scheduler;
	
	@Reference
	public void bindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	public void unbindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	
    private int schedulerID;
	@Activate
	protected void activate(Config config) {
		schedulerID = config.schedulerName().hashCode();
	}
	
	@Modified
	protected void modified(Config config) {
		removeScheduler();
		schedulerID = config.schedulerName().hashCode();
		addScheduler(config);
	}
	
	@Deactivate
	protected void deactivate(Config config) {
		removeScheduler();
	}
	
	private void removeScheduler() {
		LOGGER.debug("Removing Scheduler Job '{}'", schedulerID);
		  scheduler.unschedule(String.valueOf(schedulerID));
		 }
	
	private void addScheduler(Config config) {
		  if (config.serviceEnabled()) {
		   ScheduleOptions sopts = scheduler.EXPR(config.schedulerExpression());
		   sopts.name(String.valueOf(schedulerID));
		   sopts.canRunConcurrently(config.schedulerConcurrent());
		   scheduler.schedule(this, sopts);
		   LOGGER.debug("JHI Product Activation Scheduler added succesfully");
		  } else {
			  LOGGER.debug("JHI Product Activation Scheduler, no scheduler job created");
		  }
		 }
	
	
    @Override
    public void run() {
        if (runModeService.isAuthor()) {
            ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resolverFactory);
            if (resourceResolver == null) {
                LOGGER.error("Could not access service resource resolver");
                return;
            }
            Query query = prepareQuery(resourceResolver);
            SearchResult searchResult = query.getResult();
            /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
            for (Hit hit : searchResult.getHits()) {
                Resource resource = null;
                try {
                	String path = hit.getPath();
                    resource = resourceResolver.getResource(path);
                } catch (RepositoryException e) {
                    LOGGER.error("Problem while fetching product resource", e);
                }
                if (resource != null) {
                    processItem(resource);
                }
            }
            /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */

            resourceResolver.close();
        }
    }

    private void processItem(Resource productResource) {
		if (null != productResource) {
			RrdProductImpl product = new RrdProductImpl(productResource);
			if (product.getLastPublishOnWeb() == null || (product.getPublishDate() != null
					&& product.getPublishDate().after(product.getLastPublishOnWeb()))) {
				productPagesService.createPage(productResource);
				LOGGER.debug("Publishing product {}", productResource.getPath());
			}
		}
    }

    private Query prepareQuery(ResourceResolver resourceResolver) {
        Predicate pathPredicate = new Predicate(PathPredicateEvaluator.PATH);
        pathPredicate.set(PathPredicateEvaluator.PATH, JhiConstants.RRD_PRODUCTS_ROOT);

        Predicate typePredicate = new Predicate(JcrPropertyPredicateEvaluator.PROPERTY);
        typePredicate.set(JcrPropertyPredicateEvaluator.PROPERTY, ResourceResolver.PROPERTY_RESOURCE_TYPE);
        typePredicate.set(JcrPropertyPredicateEvaluator.VALUE, Product.RESOURCE_TYPE_PRODUCT);

        Predicate publishDatePredicate = new Predicate(RELATIVEDATERANGE);
        publishDatePredicate.set(RangePropertyPredicateEvaluator.PROPERTY, RrdProductImpl.PUBLISH_DATE);
        publishDatePredicate.set(RangePropertyPredicateEvaluator.UPPER_BOUND, RELATIVE_NOW);

        PredicateGroup rootPredicate = new PredicateGroup();
        rootPredicate.setAllRequired(true);
        rootPredicate.add(pathPredicate);
        rootPredicate.add(typePredicate);
        rootPredicate.add(publishDatePredicate);

        if (notFirstRun) {
            publishDatePredicate.set(RangePropertyPredicateEvaluator.LOWER_BOUND, PREVIOUS_20_MINUTEs);
        } else {
            notFirstRun = true;
        }

        return queryBuilder.createQuery(rootPredicate, resourceResolver.adaptTo(Session.class));
    }
}