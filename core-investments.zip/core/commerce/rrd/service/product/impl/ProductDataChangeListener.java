package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;

import java.util.Collections;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import javax.jcr.observation.ObservationManager;

import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.event.jobs.JobManager;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset.DamAssetMetadataUpdateJob;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset.DamAssetPermissionsUpdateJob;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.page.PageOrderabilityUpdateJob;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Component(name = "Product Data Change Listener", immediate = true)
public class ProductDataChangeListener implements EventListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductDataChangeListener.class);


	private JobManager jobManager;

	@Reference
	public void bindJobManager(JobManager jobManager) {
		this.jobManager = jobManager;
	}

	public void unbindJobManager(JobManager jobManager) {
		this.jobManager = jobManager;
	}

	private ResourceResolverFactory resourceResolverFactory;

	@Reference
	public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory = resourceResolverFactory;
	}

	public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory = resourceResolverFactory;
	}

	private ObservationManager observationManager;
	private ResourceResolver resolver;

	@Activate
	protected void activate(ComponentContext ctx) {
		resolver = null;

		try {
			resolver = resourceResolverFactory.getServiceResourceResolver(
					Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));

			final Session session = resolver.adaptTo(Session.class);
			observationManager = session.getWorkspace().getObservationManager();
			final String[] types = { "nt:unstructured" };
			observationManager
					.addEventListener(
							this, Event.PROPERTY_ADDED | Event.PROPERTY_CHANGED | Event.PROPERTY_REMOVED
									| Event.NODE_ADDED | Event.NODE_REMOVED,
							JhiConstants.RRD_PRODUCTS_ROOT, true, null, types, false);
		} catch (LoginException | RepositoryException e1) {
			LOGGER.error("Could not initialise ", e1);
			throw new RuntimeException(e1);
		}
	}

	@Deactivate
	public void deactivate() {
		if (resolver != null) {
			resolver.close();
		}
	}

	@Override
	public void onEvent(EventIterator events) {
		while (events.hasNext()) {
			Event event = events.nextEvent();
			LOGGER.debug("Checking for permission inside loop of product change listner");

			try {
				if (isAssetChange(event)) {
					LOGGER.debug("Asset changed");
					addUpdateJob(DamAssetMetadataUpdateJob.JOB_NAME, event.getPath());
					addUpdateJob(DamAssetPermissionsUpdateJob.JOB_NAME, event.getPath());
				} else {
					if (isMetadataChange(event)) {
						LOGGER.debug("Metadata changed");
						addUpdateJob(DamAssetMetadataUpdateJob.JOB_NAME,
								event.getPath() + JhiConstants.SLASH + RrdProductImpl.WEB_ASSET);
						addUpdateJob(DamAssetMetadataUpdateJob.JOB_NAME,
								event.getPath() + JhiConstants.SLASH + RrdProductImpl.PRINT_ASSET);
					}

					if (isPropertyChangedRemovedOrAdded(event)) {
						LOGGER.debug("Metadata changed");
						addUpdateJob(ProductCodeChangeUpdateJob.JOB_NAME, event.getPath());
					}

					if (isAccessChange(event)) {
						LOGGER.debug("Access changed");
						addUpdateJob(DamAssetPermissionsUpdateJob.JOB_NAME,
								event.getPath() + JhiConstants.SLASH + RrdProductImpl.WEB_ASSET);
						addUpdateJob(DamAssetPermissionsUpdateJob.JOB_NAME,
								event.getPath() + JhiConstants.SLASH + RrdProductImpl.PRINT_ASSET);
					}

					if (isItemStatusChange(event)) {
						LOGGER.debug("Item status changed");
						addUpdateJob(PageOrderabilityUpdateJob.JOB_NAME, event.getPath());
					}
				}
			} catch (RepositoryException e) {
				LOGGER.warn("Encountered a repository exception for event", e);
			}
		}
	}

	private void addUpdateJob(String jobName, String path) {
		jobManager.addJob(jobName, ImmutableMap.of(SlingConstants.PROPERTY_PATH, path));
	}

	private boolean isAssetChange(Event event) throws RepositoryException {
		return (event.getType() == Event.PROPERTY_ADDED || event.getType() == Event.PROPERTY_CHANGED)
				&& isAssetPath(event);
	}

	private boolean isAssetPath(Event event) throws RepositoryException {
		return event.getPath().endsWith(RrdProductImpl.WEB_ASSET)
				|| event.getPath().endsWith(RrdProductImpl.PRINT_ASSET);
	}

	private boolean isMetadataChange(Event event) throws RepositoryException {
		return !isAssetPath(event) && isPropertyChangedRemovedOrAdded(event);
	}

	private boolean isAccessChange(Event event) throws RepositoryException {
		return !isAssetPath(event) && isPropertyChangedRemovedOrAdded(event);
	}

	private boolean isItemStatusChange(Event event) throws RepositoryException {
		return !isAssetPath(event)
				&& (event.getType() == Event.PROPERTY_ADDED || event.getType() == Event.PROPERTY_CHANGED);
	}

	private boolean isPropertyChangedRemovedOrAdded(Event event) {
		return event.getType() == Event.PROPERTY_ADDED || event.getType() == Event.PROPERTY_CHANGED
				|| event.getType() == Event.PROPERTY_REMOVED;
	}

}
