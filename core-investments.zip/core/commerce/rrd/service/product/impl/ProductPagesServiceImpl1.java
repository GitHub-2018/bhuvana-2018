package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;

import static java.util.stream.Collectors.joining;

import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.InvalidQueryException;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPageResult;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPagesService;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPagesService1;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.resources.ResourceCategoryType;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.service.resources.DocumentsUtil;
import com.jhi.aem.website.v1.core.service.resources.ResourceTypeModel;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Component(
		name="Old Product Pages Service Implementation",
		service=ProductPagesService1.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductPagesServiceImpl1",
		property= {
				Constants.SERVICE_DESCRIPTION+"=Product pages service Implementations",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

@Designate(ocd=ProductPagesServiceImpl1.Config.class)
public class ProductPagesServiceImpl1 implements ProductPagesService1 {

	public static final String DOCUMENT_PATH = "document";
	public static final String scheduled_deactivation_model = "/etc/workflow/models/scheduled_deactivation/jcr:content/model";
	public static final String jh_scheduled_deactivation_model = "/etc/workflow/models/jh_scheduled_deactivation/jcr:content/model";
	public static final String jh_scheduled_activation_model = "/etc/workflow/models/jh_scheduled_activation/jcr:content/model";

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductPagesServiceImpl.class);

    @ObjectClassDefinition(name="Product Page Service configuration for JHI Website", description="Configuration properties for Product Page Implementation service")
    public @interface Config{
    	@AttributeDefinition(name="Product Pages Map",description="A map of product pages")
    	String[] pagesMap(); 
    }
    
    
    private RunModeService runModeService;
    @Reference
    public void bindRunModeService(RunModeService runModeService) {
    	this.runModeService = runModeService;
    }
    public void unbindRunModeService(RunModeService runModeService) {
    	this.runModeService = runModeService;
    }
    
    
    private Replicator replicator;
    @Reference
    public void bindReplicator(Replicator replicator) {
    	this.replicator = replicator;
    }
    public void unbindReplicator(Replicator replicator) {
    	this.replicator = replicator;
    }
    
    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder = queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder = queryBuilder;
    }

	private boolean onAuthor;
	private Map<String, String> pagesMap;
	private List<String> productsRoots;

	private WorkflowService workflowService;
	@Reference
	public void bindWorkflowService(WorkflowService workflowService) {
		this.workflowService = workflowService;
	}
	
	public void unbindWorkflowService(WorkflowService workflowService) {
		this.workflowService = workflowService;
	}
	
	private ResourceResolverFactory resolverFactory;
	@Reference
	public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
		this.resolverFactory = resolverFactory;
	}
	
	public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
		this.resolverFactory = resolverFactory;
	}

	@Override
	public ProductPageResult createPage(Resource productResource) {
		if (!onAuthor) {
			return new ProductPageResult(false, "Not available");
		}
		if (productResource == null) {
			return new ProductPageResult(false, "No product resource");
		}
		ValueMap productValueMap = productResource.getValueMap();
		String displayTitle = productValueMap.get(RrdProductImpl.DISPLAY_TITLE, StringUtils.EMPTY);
		// Debug logs //
		LOGGER.debug("Product Creation displayTitle is " + displayTitle);

		if (StringUtils.isBlank(displayTitle)) {
			return new ProductPageResult(false, "Product display title is blank");
		}
		String pagesRoot = getPagesRoot(productResource.getPath());
		// Debug logs //
		LOGGER.debug("ProductPageResult -> createPage -> Pages root is " + pagesRoot);
		if (StringUtils.isBlank(pagesRoot)) {
			return new ProductPageResult(false, "No resources pages root found. Please check configuration.");
		}
		Resource rootPageResource = productResource.getResourceResolver().getResource(pagesRoot);
		if (rootPageResource == null) {
			return new ProductPageResult(false, "Resources pages root '" + pagesRoot + "' cannot be used. Please check configuration.");
		}
		Resource resourcePageResource;
		try {
			resourcePageResource = createResourcePage(productResource, rootPageResource);

			if (resourcePageResource == null) {
				return new ProductPageResult(false, "Problem while creating resource page");
			}
			ModifiableValueMap productProperties = productResource.adaptTo(ModifiableValueMap.class);
			if (productProperties != null) {
				productProperties.put(RrdProductImpl.LAST_PUBLISH_ON_WEB, Calendar.getInstance());
				productProperties.put(RrdProductImpl.RESOURCE_PAGE_PATH, resourcePageResource.getPath());
				try {
					productResource.getResourceResolver().commit();
				} catch (PersistenceException e) {
					LOGGER.error("Problem while saving last created time");
				}
			} else {
				LOGGER.error("Can't update properties for product" + productResource.getPath());
			}

		} catch (RepositoryException re) {
			LOGGER.error("RepositoryException thrown " + productResource.getPath());
		}
		return new ProductPageResult(true, "Page created");
	}

	private Resource createResourcePage(Resource productResource, Resource rootPageResource) throws RepositoryException {
		LOGGER.debug("Creating the resource pages under {} for {}", rootPageResource.getPath(), productResource.getPath());

		Resource resourcePageResource = null;
		String categoryName = "other";
		Resource resourcePageContent = null;
		RrdProductImpl product = new RrdProductImpl(productResource);
		boolean pubDateExist = isPubDateExist(product);
		boolean expDateExist = isExpDateExist(product);

		LOGGER.debug("Publication date exists for '{}' : {}", productResource.getPath(), pubDateExist);
		LOGGER.debug("Expiry date exists for '{}' : {}", productResource.getPath(), expDateExist);

        ResourceResolver resourceResolver;
		try {
			resourceResolver = resolverFactory.getServiceResourceResolver(
			        Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));
		} catch (LoginException e) {
			throw new RepositoryException("Could not get admin resource resolver", e);
		}

		try {
			if (DocumentsUtil.isResource(product.getDocumentType())) {
				String productCategory = product.getCategory();
				if (StringUtils.isNotEmpty(productCategory)) {
					ResourceCategoryType categoryType = ResourceCategoryType.getByName(productCategory);
					if (categoryType != null) {
						categoryName = categoryType.getCategoryLocation();
					}
				}
			}

			Resource categoryPageResource = prepareCategoryPageResource(resourceResolver, rootPageResource, categoryName);
	        if (categoryPageResource == null) {
	            LOGGER.error("Problem while creating resource category page: {}", product.getPath());
	            return null;
	        }
	
			if (StringUtils.isBlank(product.getDisplayTitle())) {
				LOGGER.error("Product display title is empty for product: {}", product.getPath());
				return null;
			}

			String name = createPageName(product.getDisplayTitle());
	
			// Debug logs
			LOGGER.debug("Product Page Name: {}", name);
			String oldPage = null;

			if (StringUtils.isNotBlank(name)) {
				resourcePageResource = resourceResolver.getResource(categoryPageResource, name);

				if (resourcePageResource == null || ResourceUtil.isNonExistingResource(resourcePageResource)) {
					LOGGER.debug("Resource page does not exist for: {} - {}", categoryPageResource, name);
					oldPage = cleanOldResourcePages(productResource, pubDateExist);
					LOGGER.debug("No/Rename page == {}", oldPage);

					try {
						Map<String, Object> pageProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE, NameConstants.NT_PAGE);
						resourcePageResource = resourceResolver.create(categoryPageResource, name, pageProperties);
						resourceResolver.commit();
						resourceResolver.refresh();
						// Debug logs
						LOGGER.debug("Resource page created successfully at  " + resourcePageResource.getPath());
					} catch (PersistenceException e) {
						LOGGER.error("Problem while generating resource page", e);
						return null;
					}

					resourcePageContent = resourcePageResource.getChild(JcrConstants.JCR_CONTENT);

					if (resourcePageContent == null) {
						try {
							Map<String, Object> pageContentProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE,
									JhiConstants.PAGE_CONTENT_TYPE);
							resourcePageContent = resourceResolver.create(resourcePageResource, JcrConstants.JCR_CONTENT,
									pageContentProperties);
							resourceResolver.commit();
							resourceResolver.refresh();
						} catch (PersistenceException e) {
							LOGGER.error("Problem while generating resource page content", e);
							return null;
						}
					} else {
						LOGGER.debug("Resource resourcePageContent exist at {} ", resourcePageResource.getPath());
					}

				} else {
					LOGGER.debug("Resource page exist at {} ", resourcePageResource.getPath());

					if (pubDateExist || expDateExist) {
						LOGGER.debug("PublishDate is set on product - Get JCR_CONTENT Resource for: {}", resourcePageResource.getPath());
						resourcePageContent = resourcePageResource.getChild(JcrConstants.JCR_CONTENT);
					} else {
						LOGGER.debug("PublishDate does not exist on page: {}", resourcePageResource.getPath());
						oldPage = cleanOldResourcePages(productResource, pubDateExist);
						LOGGER.debug("Old Page Exist == {}", oldPage);

						resourcePageContent = resourcePageResource.getChild(JcrConstants.JCR_CONTENT);
						if (resourcePageContent == null || ResourceUtil.isNonExistingResource(resourcePageContent)) {
							try {
								Map<String, Object> pageContentProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE,
										JhiConstants.PAGE_CONTENT_TYPE);
								resourcePageContent = resourceResolver.create(resourcePageResource, JcrConstants.JCR_CONTENT,
										pageContentProperties);
								resourceResolver.commit();
								resourceResolver.refresh();
							} catch (PersistenceException e) {
								LOGGER.error("Problem while generating resource page content", e);
								return null;
							}
						} else {
							LOGGER.debug("Resource page content exists at: {} ", resourcePageContent.getPath());
						}
					}
				}
			} else {
				LOGGER.error("Page name is blank");
				return null;
			}

			ModifiableValueMap resourcePageContentValues = resourcePageContent.adaptTo(ModifiableValueMap.class);

			if (resourcePageContentValues != null) {
				resourcePageContentValues.put(ResourceResolver.PROPERTY_RESOURCE_TYPE,
						ResourcesConstants.RESOURCE_DOCUMENT_PAGE_RESOURCE_TYPE);
				resourcePageContentValues.put(JhiConstants.ALLOWED_FIRMS_PROPERTY, product.getAllowedArray());
				resourcePageContentValues.put(JhiConstants.ACCESS_PROPERTY, product.getAccess());
				resourcePageContentValues.put(JcrConstants.JCR_TITLE, product.getDisplayTitle());
				resourcePageContentValues.put(NameConstants.PN_PAGE_TITLE, product.getMetaTitle());
				resourcePageContentValues.put(JcrConstants.JCR_DESCRIPTION, product.getMetaDescription());
				resourcePageContentValues.put(ResourceDocumentModel.ORDERABLE_PROPERTY, product.isOrderable());
				resourcePageContentValues.put(NameConstants.PN_PAGE_LAST_MOD, Calendar.getInstance());
	
				if (product.getPublishDate() != null) {
					resourcePageContentValues.put(RrdProductImpl.PUBLISH_DATE, product.getPublishDate());
				}
				if (StringUtils.isNotBlank(product.getDocumentType())) {
					resourcePageContentValues.put(RrdProductImpl.DOCUMENT_TYPE, product.getDocumentType());
				}
				if (product.getExpirationDate() != null) {
					resourcePageContentValues.put(NameConstants.PN_OFF_TIME, product.getExpirationDate());
				}
				if (StringUtils.isNotBlank(product.getCategory())) {
					resourcePageContentValues.put(ResourceTypeModel.CATEGORY_PARAMETER, product.getCategory());
				}
				if (!ArrayUtils.isEmpty(product.getTopics())) {
					resourcePageContentValues.put(ResourceTypeModel.TOPICS_PARAMETER, product.getTopics());
				}
				if (!ArrayUtils.isEmpty(product.getAudiences())) {
					resourcePageContentValues.put(ResourceTypeModel.AUDIENCES_PARAMETER, product.getAudiences());
				}
				if (!ArrayUtils.isEmpty(product.getFunds())) {
					resourcePageContentValues.put(JhiConstants.INVESTMENT_TAGS_PROPERTY, product.getFunds());
				}
			}

			try {
				createDocumentResource(product, resourceResolver, resourcePageContent, pubDateExist, expDateExist);
				resourceResolver.commit();
				resourceResolver.refresh();
			} catch (PersistenceException | RepositoryException e) {
				LOGGER.error("Problem while creating/modifying/saving resource page: {}", resourcePageContent.getPath(), e);
				return null;
			}

			try {
	
				Session session = resourceResolver.adaptTo(Session.class);
	
				// #1724 fix - call activatecontent if the product contains publishdate value
				if (expDateExist) {
					deactivateContent(session, resourcePageResource.getPath(), product.getExpirationDate());
				}

				if (pubDateExist) {
					activateContent(session, resourcePageResource.getPath(), product.getPublishDate(), oldPage);
				} else {
					terminateAllworkflows(session, resourcePageResource.getPath());
					replicator.replicate(session, ReplicationActionType.ACTIVATE, resourcePageResource.getPath());
					LOGGER.debug("Replicated '{}' path successfully  ", resourcePageResource.getPath());
				}
	
				// #1724 fix - call activatecontent if the product contains publishdate value
				if (expDateExist) {
					deactivateContent(session, productResource.getPath(), product.getExpirationDate());
				}
				if (pubDateExist) {
					activateContent(session, productResource.getPath(), product.getPublishDate(), null);
				} else {
					terminateAllworkflows(session, productResource.getPath());
					replicator.replicate(session, ReplicationActionType.ACTIVATE, productResource.getPath());
					LOGGER.debug("Replicated '{}' path successfully  ", productResource.getPath());
				}
	
				if (StringUtils.isNoneBlank(product.getPrintAssetPath())) {
					if (resourceResolver.getResource(product.getPrintAssetPath()) != null) {
						// #1724 fix - call activatecontent if the product contains publishdate value
						if (expDateExist) {
							deactivateContent(session, product.getPrintAssetPath(), product.getExpirationDate());
						}
						if (pubDateExist) {
							activateContent(session, product.getPrintAssetPath(), product.getPublishDate(), null);
						} else {
							terminateAllworkflows(session, product.getPrintAssetPath());
							replicator.replicate(session, ReplicationActionType.ACTIVATE, product.getPrintAssetPath());
							LOGGER.debug("Replicated '{}' path successfully  ", product.getPrintAssetPath());
						}
					} else {
						LOGGER.error("Print asset does not exist {}", product.getPrintAssetPath());
					}
				}
				if (StringUtils.isNoneBlank(product.getWebAssetPath())) {
					if (resourceResolver.getResource(product.getWebAssetPath()) != null) {
	
						// #1724 fix - call activatecontent if the product contains publishdate value
						if (expDateExist) {
							deactivateContent(session, product.getWebAssetPath(), product.getExpirationDate());
						}
						if (pubDateExist) {
							activateContent(session, product.getWebAssetPath(), product.getPublishDate(), null);
						} else {
							terminateAllworkflows(session, product.getWebAssetPath());
							replicator.replicate(session, ReplicationActionType.ACTIVATE, product.getWebAssetPath());
							LOGGER.debug("Replicated '{}' path successfully  ", product.getWebAssetPath());
						}
					} else {
						LOGGER.error("Web asset does not exist {}", product.getWebAssetPath());
					}
				}
				String fundDetailsPagePath = getFundDetailsPagePath(rootPageResource);
	
				// Debug logs
				LOGGER.debug("Fund Details path is " + fundDetailsPagePath);
				if (StringUtils.isNotBlank(fundDetailsPagePath)) {
					replicator.replicate(session, ReplicationActionType.ACTIVATE, fundDetailsPagePath);
					// Debug logs
					LOGGER.debug("Replicated '{}' path successfully  ", fundDetailsPagePath);
				}
			} catch (ReplicationException e) {
				LOGGER.error("Problem while replicating resource page", e);
			}
		} finally {
		    resourceResolver.close();
		}

		product.setPageStatusCreated();
		return resourcePageResource;
	}

	private String getFundDetailsPagePath(Resource rootPageResource) {
		Page homePage = PageUtil.getHomePage(rootPageResource);
		if (homePage != null) {
			Page investmentsPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants.INVESTMENTS_PAGE_RESOURCE_TYPE);
			if (investmentsPage != null) {
				Page fundDetailsPage = PageUtil.getChildByResourceType(homePage,
						ResourcesConstants.FUND_DETAILS_PAGE_RESOURCE_TYPE);
				if (fundDetailsPage != null) {
					LOGGER.debug("Fund Details page " + fundDetailsPage.getPath());
					return fundDetailsPage.getPath();
				}
			}
		}
		return StringUtils.EMPTY;
	}

	private String cleanOldResourcePages(Resource productResource, boolean pubDateExist) {
		LOGGER.debug("Cleaning old resource pages for {} ({})", productResource, pubDateExist);
		ResourceResolver resourceResolver = productResource.getResourceResolver();
		SearchResult result = getProductUsages(resourceResolver, productResource.getPath());

		/* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
		if (!result.getHits().isEmpty()) {
			PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
			if (pageManager != null) {
				for (Hit hit : result.getHits()) {
					try {
						String productPath = hit.getPath();
						Resource productDocumentResource = resourceResolver.getResource(productPath);
						String oldPagePath = null;
						if (productDocumentResource != null) {
							Page resourcePage = pageManager.getContainingPage(productDocumentResource);
							oldPagePath = resourcePage.getPath();
							if (!pubDateExist) {
								removeResourcePage(resourcePage, resourceResolver);
							}
						}
						return oldPagePath;
					} catch (RepositoryException e) {
						LOGGER.error("Problem while obtaining product document resource", e);
					}
				}
			} else {
				LOGGER.error("Page manages is null");
			}
		}
		/* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */

		return null;
	}

	private void removeResourcePage(Page resourcePage, ResourceResolver resourceResolver) {
		if (resourcePage != null) {
			Session session = resourceResolver.adaptTo(Session.class);
			try {
				replicator.replicate(session, ReplicationActionType.DELETE, resourcePage.getPath());
				Resource resourcePageResource = resourceResolver.getResource(resourcePage.getPath());
				if (resourcePageResource != null) {
					try {
						LOGGER.debug(" resourcePageResource is not null {} ", resourcePageResource.getPath());
						resourceResolver.delete(resourcePageResource);
						resourceResolver.commit();
						resourceResolver.refresh();
					} catch (PersistenceException e) {
						LOGGER.error("Problem while deleting old resource page: " + resourcePage.getPath(), e);
					}
				}
			} catch (ReplicationException e) {
				LOGGER.error("Problem while deactivating old resource page: " + resourcePage.getPath(), e);
			}
		} else {
			LOGGER.error("Resource page was null");
		}
	}

	private SearchResult getProductUsages(ResourceResolver resourceResolver, String productPath) {
		String pagesRoot = getPagesRoot(productPath);
		final Map<String, String> searchParams = new HashMap<>(5);
		if (StringUtils.isNotBlank(pagesRoot)) {
			searchParams.put(PathPredicateEvaluator.PATH, pagesRoot);
		} else {
			searchParams.put(PathPredicateEvaluator.PATH, JhiConstants.CONTENT_ROOT);
		}
		searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY,
				ResourceDocumentModel.PRODUCT_PATH_PROPERTY);
		searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER, productPath);
		searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY,
				ResourceResolver.PROPERTY_RESOURCE_TYPE);
		searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER,
				ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE);
		Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
		return query.getResult();
	}

	private Resource prepareCategoryPageResource(ResourceResolver resourceResolver, Resource rootPageResource, 
			String categoryName) {
		Resource categoryPageResource = rootPageResource.getChild(categoryName);
		if (categoryPageResource != null) {
			LOGGER.debug("Category page resource exists for {}", categoryPageResource.getPath());
			return categoryPageResource;
		}
		try {
			LOGGER.debug("Creating category page resource {} -> {}", rootPageResource.getPath(), categoryName);
			categoryPageResource = resourceResolver.create(rootPageResource, categoryName,
					Collections.singletonMap(JcrConstants.JCR_PRIMARYTYPE, NameConstants.NT_PAGE));
			Map<String, Object> pageContentProperties = ImmutableMap.of(JcrConstants.JCR_PRIMARYTYPE,
					JhiConstants.PAGE_CONTENT_TYPE, NameConstants.PN_TEMPLATE, ResourcesConstants.REDIRECT_PAGE_TEMPLATE,
					ResourceResolver.PROPERTY_RESOURCE_TYPE, ResourcesConstants.REDIRECT_PAGE_RESOURCE_TYPE,
					JcrConstants.JCR_TITLE, DocumentsUtil.RESOURCES_CATEGORIES_NAMES.get(categoryName));
			resourceResolver.create(categoryPageResource, JcrConstants.JCR_CONTENT, pageContentProperties);
			resourceResolver.commit();
			LOGGER.debug("Created category page resource {} -> {}", rootPageResource.getPath(), categoryName);
			return categoryPageResource;
		} catch (PersistenceException e) {
			LOGGER.error("Problem while creating category page", e);
		}
		return null;
	}

	private void createDocumentResource(RrdProductImpl product, ResourceResolver resourceResolver, Resource resourcePageContent,
			boolean pubDateExist, boolean expDateExist) throws PersistenceException, RepositoryException {
		resourceResolver.commit();
		resourceResolver.refresh();
		Resource documentResource = resourcePageContent.getChild(DOCUMENT_PATH);

		if (documentResource != null && !ResourceUtil.isNonExistingResource(documentResource)) {
			LOGGER.debug("Document resource exists at path {} ", documentResource.getPath());

			// resource Exist
			if (pubDateExist || expDateExist) {

				LOGGER.debug("Publication/expiry date exists for path '{}', processing document '{}'",
						resourcePageContent.getPath(), documentResource.getPath());

				Node documentNode = documentResource.adaptTo(Node.class);

				LOGGER.debug("Setting properties for existing document node at path {} ", documentNode.getPath());
				documentNode.setProperty(ResourceDocumentModel.TITLE_PROPERTY, product.getDisplayTitle());
				documentNode.setProperty(ResourceDocumentModel.DESCRIPTION_PROPERTY, product.getDisplayDescription());
				documentNode.setProperty(ResourceDocumentModel.PRODUCT_PATH_PROPERTY, product.getPath());
				documentNode.setProperty(ResourceDocumentModel.ASSET_PATH_PROPERTY, product.getWebAssetPath());
				documentNode.setProperty(ResourceDocumentModel.THUMBNAIL_PATH_PROPERTY, product.getThumbnailPath());
				documentNode.setProperty(ResourceDocumentModel.FILE_TYPE_PROPERTY, product.getFileType());
				documentNode.setProperty(ResourceDocumentModel.FILE_SIZE_PROPERTY, product.getFileSize());
				documentNode.setProperty(ResourceDocumentModel.ORDERABLE_PROPERTY, product.isOrderable());
				documentNode.setProperty(ResourceDocumentModel.APPROVED_FOR_PROPERTY, product.getApprovedFor());

				if (StringUtils.isNotBlank(product.getCode())) {
					documentNode.setProperty(ResourceDocumentModel.PRODUCT_CODE_PROPERTY, product.getCode());
				}
				if (product.getLastUpdated() != null) {
					documentNode.setProperty(ResourceDocumentModel.REVISION_DATE_PROPERTY, product.getLastUpdated());
				}
				if (StringUtils.isNotBlank(product.getElectronicFormLink())) {
					documentNode.setProperty(ResourceDocumentModel.ELECTRONIC_FORM_LINK_PROPERTY,
							product.getElectronicFormLink());
				}

			} else {
				LOGGER.debug("Publication/expiry date does not exist for path '{}', processing document '{}'",
						resourcePageContent.getPath(), documentResource.getPath());

				// Delete the old resource
				LOGGER.debug("Deleting old document resource '{}'", documentResource.getPath());
				resourceResolver.delete(documentResource);
				resourceResolver.commit();
				resourceResolver.refresh();

				Map<String, Object> documentProperties = new HashMap<>();
				documentProperties.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
				documentProperties.put(ResourceResolver.PROPERTY_RESOURCE_TYPE,
						ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE);
				documentProperties.put(ResourceDocumentModel.TITLE_PROPERTY, product.getDisplayTitle());
				documentProperties.put(ResourceDocumentModel.DESCRIPTION_PROPERTY, product.getDisplayDescription());
				documentProperties.put(ResourceDocumentModel.PRODUCT_PATH_PROPERTY, product.getPath());
				documentProperties.put(ResourceDocumentModel.ASSET_PATH_PROPERTY, product.getWebAssetPath());
				documentProperties.put(ResourceDocumentModel.THUMBNAIL_PATH_PROPERTY, product.getThumbnailPath());
				documentProperties.put(ResourceDocumentModel.FILE_TYPE_PROPERTY, product.getFileType());
				documentProperties.put(ResourceDocumentModel.FILE_SIZE_PROPERTY, product.getFileSize());
				documentProperties.put(ResourceDocumentModel.ORDERABLE_PROPERTY, product.isOrderable());
				documentProperties.put(ResourceDocumentModel.APPROVED_FOR_PROPERTY, product.getApprovedFor());
				if (StringUtils.isNotBlank(product.getCode())) {
					documentProperties.put(ResourceDocumentModel.PRODUCT_CODE_PROPERTY, product.getCode());
				}
				if (product.getLastUpdated() != null) {
					documentProperties.put(ResourceDocumentModel.REVISION_DATE_PROPERTY, product.getLastUpdated());
				}
				if (StringUtils.isNotBlank(product.getElectronicFormLink())) {
					documentProperties.put(ResourceDocumentModel.ELECTRONIC_FORM_LINK_PROPERTY,
							product.getElectronicFormLink());
				}

				LOGGER.debug("Recreating document resource content at path '{}'", resourcePageContent.getPath());
				resourceResolver.create(resourcePageContent, DOCUMENT_PATH, documentProperties);
				resourceResolver.commit();
				resourceResolver.refresh();
				LOGGER.debug("Recreated document resource content at path '{}'", resourcePageContent.getPath());
			}

		} else {
			
			LOGGER.debug("Document resource does not yet exist for path '{}', creating...", resourcePageContent.getPath());
			Map<String, Object> documentProperties = new HashMap<>();
			documentProperties.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
			documentProperties.put(ResourceResolver.PROPERTY_RESOURCE_TYPE,
					ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE);
			documentProperties.put(ResourceDocumentModel.TITLE_PROPERTY, product.getDisplayTitle());
			documentProperties.put(ResourceDocumentModel.DESCRIPTION_PROPERTY, product.getDisplayDescription());
			documentProperties.put(ResourceDocumentModel.PRODUCT_PATH_PROPERTY, product.getPath());
			documentProperties.put(ResourceDocumentModel.ASSET_PATH_PROPERTY, product.getWebAssetPath());
			documentProperties.put(ResourceDocumentModel.THUMBNAIL_PATH_PROPERTY, product.getThumbnailPath());
			documentProperties.put(ResourceDocumentModel.FILE_TYPE_PROPERTY, product.getFileType());
			documentProperties.put(ResourceDocumentModel.FILE_SIZE_PROPERTY, product.getFileSize());
			documentProperties.put(ResourceDocumentModel.ORDERABLE_PROPERTY, product.isOrderable());
			documentProperties.put(ResourceDocumentModel.APPROVED_FOR_PROPERTY, product.getApprovedFor());
			if (StringUtils.isNotBlank(product.getCode())) {
				documentProperties.put(ResourceDocumentModel.PRODUCT_CODE_PROPERTY, product.getCode());
			}
			if (product.getLastUpdated() != null) {
				documentProperties.put(ResourceDocumentModel.REVISION_DATE_PROPERTY, product.getLastUpdated());
			}
			if (StringUtils.isNotBlank(product.getElectronicFormLink())) {
				documentProperties.put(ResourceDocumentModel.ELECTRONIC_FORM_LINK_PROPERTY, product.getElectronicFormLink());
			}

			LOGGER.debug("Creating document resource for path '{}'", resourcePageContent.getPath());
			resourceResolver.create(resourcePageContent, DOCUMENT_PATH, documentProperties);
			resourceResolver.commit();
			resourceResolver.refresh();
			LOGGER.debug("Created document resource for path '{}'", resourcePageContent.getPath());
		}
	}

    private String createPageName(String title) {
        if (StringUtils.isNotBlank(title)) {
            String sanitizedTitle = StringUtils.replacePattern(title, "'", StringUtils.EMPTY);
            String[] nameParts = sanitizedTitle.split("[^a-zA-Z0-9]");
            String name = Stream.of(nameParts).filter(StringUtils::isNotBlank).collect(joining(JhiConstants.DASH));
            if (StringUtils.isNotBlank(name)) {
                return name.toLowerCase();
            }
        }
        return StringUtils.EMPTY;
    }

    @Override
    public String getPagesRoot(String productPath) {
        if (StringUtils.isNotBlank(productPath)) {
            for (String root : productsRoots) {
                if (productPath.startsWith(root)) {
                    return pagesMap.get(root);
                }
            }
        }
        return StringUtils.EMPTY;
    }

    @Activate
    protected void activate(final Config config) {
        onAuthor = runModeService.isAuthor();
        update(config);
    }

    @Modified
    protected void update(final Config config) {
        String[] pagesMapProperty = PropertiesUtil.toStringArray(config.pagesMap(), DEFAULT_PAGES_MAP);
        Map<String, String> newPagesMap = new LinkedHashMap<>(pagesMapProperty.length);
        List<String> newProductsRoots = new LinkedList<>();
        if (!ArrayUtils.isEmpty(pagesMapProperty)) {
            for (String line : pagesMapProperty) {
                String lineParts[] = StringUtils.split(line, JhiConstants.COLON);
                if (lineParts.length == 2) {
                	LOGGER.info("Added pages map config: {} = {}", lineParts[0], lineParts[1]);
                    newPagesMap.put(lineParts[0], lineParts[1]);
                    newProductsRoots.add(lineParts[0]);
                }
            }
        }
        pagesMap = newPagesMap;
        productsRoots = newProductsRoots;
    }
	// #1724 -fix
	private void activateContent(Session session, String resourcePath, Calendar date, String oldPage)
			throws ReplicationException, RepositoryException {

		LOGGER.debug("Activating content at path {}", resourcePath);
		WorkflowSession wfSession = workflowService.getWorkflowSession(session);
		if (null != date) {
			LOGGER.debug("before starting scheduled_activation_model.");
			terminateWorkflow(wfSession, jh_scheduled_activation_model, resourcePath);
			if (null != oldPage) {
				LOGGER.debug("old page path for deactivation - " + oldPage);
				startWorkflow(wfSession, jh_scheduled_deactivation_model, oldPage, date.getTimeInMillis());
			}
			startWorkflow(wfSession, jh_scheduled_activation_model, resourcePath, date.getTimeInMillis());
		}
	}
	private void deactivateContent(Session session, String resourcePath, Calendar date) throws ReplicationException,
			RepositoryException {
		LOGGER.debug("Deactivating content at path {}", resourcePath);
		WorkflowSession wfSession = workflowService.getWorkflowSession(session);
		if (null != date) {
			LOGGER.debug("before starting scheduled_deactivation_model.");
			terminateWorkflow(wfSession, scheduled_deactivation_model, resourcePath);
			startWorkflow(wfSession, scheduled_deactivation_model, resourcePath, date.getTimeInMillis());
		}
	}

	private void terminateAllworkflows(Session session, String resourcePath) {
		LOGGER.debug("Terminating all workflows at path {}", resourcePath);
		WorkflowSession wfSession = workflowService.getWorkflowSession(session);
		terminateWorkflow(wfSession, jh_scheduled_activation_model, resourcePath);
		terminateWorkflow(wfSession, scheduled_deactivation_model, resourcePath);
		terminateWorkflow(wfSession, jh_scheduled_deactivation_model, resourcePath);

	}
	// #1724 -fix - startworkflow method start the workfow based on scheduld
	// activation or deactivation.

	private void startWorkflow(WorkflowSession wfSession, String model, String resourcePath, long absTime)
			throws RepositoryException {
		LOGGER.debug("Entering startWorkflow method with model={}, path={}", model, resourcePath);
		try {
			// start workflow
			WorkflowModel wfModel = wfSession.getModel(model);
			WorkflowData wfDataProduct = wfSession.newWorkflowData("JCR_PATH", resourcePath);
			HashMap<String, Object> timeMap = new HashMap<String, Object>();
			timeMap.put("absoluteTime", absTime);
			LOGGER.debug("Model={}, Workflow Model={}, Data={}, Map={}",
					new Object[] {model, wfModel, wfDataProduct, timeMap});
			wfSession.startWorkflow(wfModel, wfDataProduct, timeMap);
			LOGGER.debug("workflow started on path : " + resourcePath);
		} catch (WorkflowException e) {
			LOGGER.error("WorkflowException thrown in doPost method", e);
		} catch (Exception e) {
			LOGGER.error("Exception thrown in doPost method", e);
		}

		LOGGER.debug("Exiting startWorkflow method.");
	}

	// #1724-fix -added terminateworkflow method.
	private void terminateWorkflow(WorkflowSession wfSession, String model, String resourcePath) {
		LOGGER.debug("Terminating workflow for model={}, path={}", model, resourcePath);

		try {
			// check if the workflow is runnning and terminate.
			String queryStr = "SELECT * FROM [cq:Workflow] as node WHERE ISDESCENDANTNODE(node, '/etc/workflow/instances') AND node.[data/payload/path] =CAST('"
					+ resourcePath + "' AS PATH) and node.modelId='" + model + "' and node.status='RUNNING'";
			LOGGER.debug("query : " + queryStr);
			QueryManager queryManager = wfSession.getSession().getWorkspace().getQueryManager();
			QueryResult results = queryManager.createQuery(queryStr, javax.jcr.query.Query.JCR_SQL2).execute();
			long size = results.getRows().getSize();
			LOGGER.debug(size + " workflows running on path  : " + resourcePath);
			if (size > 0) {
				NodeIterator wfNodes = results.getNodes();
				while (wfNodes.hasNext()) {
					Node nextNode = wfNodes.nextNode();
					String workflowId = nextNode.getPath();
					Workflow wfData = wfSession.getWorkflow(workflowId);
					wfSession.terminateWorkflow(wfData);
					LOGGER.debug(workflowId + "- workflow terminated");
				}
			}
		} catch (InvalidQueryException e) {
			LOGGER.error("InvalidQueryException thrown in terminateWorkflow method.", e);
		} catch (RepositoryException e) {
			LOGGER.error("RepositoryException thrown in terminateWorkflow method.", e);
		} catch (WorkflowException e) {
			LOGGER.error("WorkflowException thrown in terminateWorkflow method.", e);
		}
	}

	// #1724 fix
	private boolean isPubDateExist(RrdProductImpl product) {

		boolean isPubDtExOnPrd = false;
		Calendar publishDate = product.getPublishDate();
		if (null != publishDate) {
			isPubDtExOnPrd = true;
		}
		return isPubDtExOnPrd;
	}

	// #1724 fix
	private boolean isExpDateExist(RrdProductImpl product) {

		boolean isExpDtExOnPrd = false;
		Calendar expDate = product.getExpirationDate();
		if (null != expDate) {
			isExpDtExOnPrd = true;
		}
		return isExpDtExOnPrd;
	}
}