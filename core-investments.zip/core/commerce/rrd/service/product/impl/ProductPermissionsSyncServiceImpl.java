package com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

import org.apache.sling.event.jobs.JobManager;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.Product;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.ProductPermissionsSyncService;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset.DamAssetPermissionsUpdateJob;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;


@Component(
		name="Product Permissions Sync Service Implementation",
		service=ProductPermissionsSyncService.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductPermissionsSyncServiceImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"=Product permissions sync service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

@Designate(ocd=ProductPermissionsSyncServiceImpl.Config.class)
public class ProductPermissionsSyncServiceImpl implements ProductPermissionsSyncService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductPermissionsSyncServiceImpl.class);

    @ObjectClassDefinition(name="Product Permissions Sync Service Configuration for JHI Website",description="Configurations for Product permission sync service impl")
    public @interface Config{
    	@AttributeDefinition(name="Enabled",description="Status of product permissions sync service, by default the status is set to true")
    	boolean enabled() default true;
    	
    	@AttributeDefinition(name="Products root path",description="root path of the products")
    	String productsRootPath() default ProductPermissionsSyncService.DEFAULT_PRODUCTS_ROOT_PATH;
    }
    
    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resourceResolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resourceResolverFactory=resolverFactory;
    }

    private JobManager jobManager;
    @Reference
    public void bindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }
    public void unbindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }

    private boolean enabled;
    private String rootPath;

    @Override
    public void performSync() {
        if (enabled) {
            if (StringUtils.isNotBlank(rootPath)) {
                ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
                if (resourceResolver != null) {
                    Resource rootResource = resourceResolver.getResource(rootPath);
                    if (rootResource != null) {
                        addProductsTasks(rootResource);
                    }
                    resourceResolver.close();
                }
            } else {
                LOGGER.error("Root page is blank");
            }
        }
    }

    private void addProductsTasks(Resource rootResource) {
        if (rootResource != null) {
            for (Resource resource : rootResource.getChildren()) {
                if (resource.isResourceType(Product.RESOURCE_TYPE_PRODUCT)) {
                    addUpdateJob(resource, RrdProductImpl.WEB_ASSET);
                    addUpdateJob(resource, RrdProductImpl.PRINT_ASSET);
                } else if (resource.isResourceType(JcrResourceConstants.NT_SLING_FOLDER)
                        || resource.isResourceType(JcrResourceConstants.NT_SLING_ORDERED_FOLDER)) {
                    addProductsTasks(resource);
                }
            }
        }
    }

    private void addUpdateJob(Resource resource, String assetRelativePath) {
        if (resource.getChild(assetRelativePath) != null) {
            jobManager.addJob(DamAssetPermissionsUpdateJob.JOB_NAME,
                    ImmutableMap.of(SlingConstants.PROPERTY_PATH, resource.getPath() + JhiConstants.SLASH + assetRelativePath));
        }
    }

    @Activate
    protected void activate(final Config config) {
        update(config);
    }

    @Modified
    protected void update(final Config config) {
        enabled =config.enabled(); 
        rootPath =config.productsRootPath();
        performSync();
    }
}
