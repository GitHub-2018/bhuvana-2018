package com.jhi.aem.website.v1.core.commerce.rrd.service.product;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

public interface ProductOrderabilitySyncService {
    String ENABLED_PROPERTY = "enabled";
    String PRODUCTS_ROOT_PATH = "productsRootPath";
    String DEFAULT_PRODUCTS_ROOT_PATH = JhiConstants.RRD_PRODUCTS_ROOT;

    void performSync();
}
