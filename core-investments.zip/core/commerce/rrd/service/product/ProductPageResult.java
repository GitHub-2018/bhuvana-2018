package com.jhi.aem.website.v1.core.commerce.rrd.service.product;

public class ProductPageResult {

    private boolean success;
    private String message;

    public ProductPageResult(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
