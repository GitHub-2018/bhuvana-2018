package com.jhi.aem.website.v1.core.commerce.rrd.service.product.page;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.Agent;
import com.day.cq.replication.AgentIdFilter;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.ReplicationOptions;
import com.day.cq.replication.Replicator;
import com.day.cq.search.Predicate;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;


@Component(
		name="PageOrderability Update Job",
		service=JobConsumer.class,
		immediate = true,
		property= {
				JobConsumer.PROPERTY_TOPICS+"="+PageOrderabilityUpdateJob.JOB_NAME	
		})

public class PageOrderabilityUpdateJob implements JobConsumer {
    public static final String JOB_NAME = "com/jhi/aem/website/pageOrderabilityUpdate";

    private static final Logger LOGGER = LoggerFactory.getLogger(PageOrderabilityUpdateJob.class);

    private static final String PATH_PREDICATE_NAME = "Path";
    private static final String RESOURCE_TYPE_PREDICATE_NAME = "Resource Type";
    private static final String PRODUCT_PATH_PREDICATE_NAME = "Product Path";

    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory (ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory (ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }

    private RunModeService runModeService;
    @Reference
    public void bindRunModeService(RunModeService runModeService) {
    	this.runModeService=runModeService;
    }
    public void unbindRunModeService(RunModeService runModeService) {
    	this.runModeService=runModeService;
    }
    
    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder) {
    	this.queryBuilder=queryBuilder;
    }

    private Replicator replicator;
    @Reference
    public void bindReplicator(Replicator replicator) {
    	this.replicator=replicator;
    }
    public void unbindReplicator(Replicator replicator) {
    	this.replicator=replicator;
    }

    @Override
    public JobResult process(Job job) {
        JobResult jobResult = JobResult.FAILED;
        final String productPath = job.getProperty(SlingConstants.PROPERTY_PATH).toString();
        if (StringUtils.isNotBlank(productPath)) {
            ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
            if (resourceResolver != null) {
                Resource productResource = resourceResolver.getResource(productPath);
                if (productResource != null) {
                    jobResult = updatePageOrderability(resourceResolver, productResource);
                } else {
                    return JobResult.CANCEL;
                }
                resourceResolver.close();
            }
        }
        return jobResult;
    }

    private JobResult updatePageOrderability(ResourceResolver resourceResolver, Resource productResource) {
        if (productResource != null) {
            String productPath = productResource.getPath();
            Query query = queryBuilder.createQuery(preparePredicate(productPath), resourceResolver.adaptTo(Session.class));
            query.setHitsPerPage(0);
            SearchResult queryResult = query.getResult();
            /* START - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
            if (queryResult.getTotalMatches() > 0) {
                RrdProductImpl product = new RrdProductImpl(productResource);
                boolean orderable = product.isOrderable();
                for (Hit hit : queryResult.getHits()) {
                    try {
                    	String hitPath = hit.getPath();
                        Resource productDocumentResource = resourceResolver.getResource(hitPath);
                        if (processSingleItem(resourceResolver, productDocumentResource, orderable)) {
                            return JobResult.OK;
                        }
                    } catch (RepositoryException e) {
                        LOGGER.error("Problem while taking page resource for {}", hit, e);
                    }
                }
            }
            /* END - Change the method call getResource from search results hits as this is creating a unclosed internal resolver session */
        }
        return JobResult.CANCEL;
    }

    private PredicateGroup preparePredicate(String productPath) {
        PredicateGroup rootPredicate = new PredicateGroup();
        rootPredicate.setAllRequired(true);
        Predicate pathPredicate = new Predicate(PATH_PREDICATE_NAME, PathPredicateEvaluator.PATH);
        pathPredicate.set(PathPredicateEvaluator.PATH, JhiConstants.JHI_WEBSITE_ROOT);
        rootPredicate.add(pathPredicate);
        Predicate resourceTypePredicate = new Predicate(RESOURCE_TYPE_PREDICATE_NAME, JcrPropertyPredicateEvaluator.PROPERTY);
        resourceTypePredicate.set(JcrPropertyPredicateEvaluator.PROPERTY, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY);
        resourceTypePredicate.set(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JcrPropertyPredicateEvaluator.VALUE, ResourcesConstants.SUITE_DOCUMENT_RESOURCE_TYPE);
        resourceTypePredicate.set(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JcrPropertyPredicateEvaluator.VALUE, ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE);
        rootPredicate.add(resourceTypePredicate);
        Predicate productPathPredicate = new Predicate(PRODUCT_PATH_PREDICATE_NAME, JcrPropertyPredicateEvaluator.PROPERTY);
        productPathPredicate.set(JcrPropertyPredicateEvaluator.PROPERTY, ResourceDocumentModel.PRODUCT_PATH_PROPERTY);
        productPathPredicate.set(JcrPropertyPredicateEvaluator.VALUE, productPath);
        rootPredicate.add(productPathPredicate);
        return rootPredicate;
    }

    private boolean processSingleItem(ResourceResolver resourceResolver, Resource productDocumentResource, boolean orderable) {
        String resourcePagePath = StringUtils.EMPTY;
        if (productDocumentResource != null) {
            boolean commitRequired = updateOrderability(productDocumentResource, orderable);
            if (productDocumentResource.isResourceType(ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE)) {
                Resource pageContentResource = productDocumentResource.getParent();
                if (pageContentResource != null
                        && pageContentResource.isResourceType(ResourcesConstants.RESOURCE_DOCUMENT_PAGE_RESOURCE_TYPE)) {
                    commitRequired = updateOrderability(pageContentResource, orderable);
                    if (commitRequired) {
                        Resource pageResource = pageContentResource.getParent();
                        if (pageResource != null) {
                            resourcePagePath = pageResource.getPath();
                        }
                    }
                }
            }
            if (commitRequired) {
                try {
                    resourceResolver.commit();
                    if (StringUtils.isNotBlank(resourcePagePath)) {
                        flushProductPage(resourceResolver, resourcePagePath);
                    }
                } catch (PersistenceException e) {
                    LOGGER.error("Problem while updating orderability for product {}", productDocumentResource.getPath());
                    return false;
                }
            }
        }
        return true;
    }

    private boolean updateOrderability(Resource orderableResource, boolean orderable) {
        ValueMap documentResourceValues = orderableResource.getValueMap();
        if (!documentResourceValues.containsKey(ResourceDocumentModel.ORDERABLE_PROPERTY)
                || BooleanUtils.toBoolean(documentResourceValues.get(ResourceDocumentModel.ORDERABLE_PROPERTY, Boolean.class)) != orderable) {
            ModifiableValueMap values = orderableResource.adaptTo(ModifiableValueMap.class);
            if (values != null) {
                values.put(ResourceDocumentModel.ORDERABLE_PROPERTY, orderable);
                return true;
            } else {
                LOGGER.error("Cannot modify resource orderability {}", orderableResource.getPath());
            }
        }
        return false;
    }

    private void flushProductPage(ResourceResolver resourceResolver, String resourcePagePath) {
        if (runModeService.isPublish()) {
            ReplicationOptions replicationOptions = new ReplicationOptions();
            replicationOptions.setFilter(new AgentIdFilter() {
                @Override
                public boolean isIncluded(Agent agent) {
                    return agent.isCacheInvalidator();
                }
            });
            Session session = resourceResolver.adaptTo(Session.class);
            try {
                replicator.replicate(session, ReplicationActionType.DELETE, resourcePagePath, replicationOptions);
            } catch (ReplicationException e) {
                LOGGER.error("Problem while flushing dispatcher", e);
            }
        }
    }
}