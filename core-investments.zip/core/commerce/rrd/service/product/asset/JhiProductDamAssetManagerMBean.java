package com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset;

public interface JhiProductDamAssetManagerMBean {

	void reprocessDamPermissions();

}
