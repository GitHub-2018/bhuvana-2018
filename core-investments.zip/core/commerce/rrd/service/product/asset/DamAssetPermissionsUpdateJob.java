package com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset;


import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.security.AccessControlEntry;
import javax.jcr.security.AccessControlManager;
import javax.jcr.security.Privilege;

import org.apache.commons.lang3.StringUtils;

import org.apache.jackrabbit.JcrConstants;
import org.apache.jackrabbit.api.security.JackrabbitAccessControlList;
import org.apache.jackrabbit.commons.jackrabbit.authorization.AccessControlUtils;
import org.apache.jackrabbit.oak.spi.security.authorization.accesscontrol.ACE;
import org.apache.jackrabbit.oak.spi.security.privilege.PrivilegeConstants;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.DownloadResource;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.tagging.InvalidTagFormatException;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.NameConstants;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.auth.external.IsamGroups;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;

@Component(
		name="DAM Asset Permissions Update Job",
		service=JobConsumer.class,
		immediate=true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset.DamAssetPermissionsUpdateJob",
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website DAM permissions update job.",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR,
				JobConsumer.PROPERTY_TOPICS+"="+DamAssetPermissionsUpdateJob.JOB_NAME
		})

@Designate(ocd=DamAssetPermissionsUpdateJob.Config.class)

public class DamAssetPermissionsUpdateJob implements JobConsumer {
    public static final String JOB_NAME = "com/jhi/aem/website/assetPermissionsUpdate";

    static final String JHI_ADMIN_NAME_PROPERTY = "user.jhi-admin";
    static final String JHI_ADMIN_NAME_DEFAULT = "jhi-admin";
    static final String JHI_DATA_DISTRIBUTION_ADMIN_NAME_PROPERTY = "user.jhi-data-distribution-admin";
    static final String JHI_DATA_DISTRIBUTION_ADMIN_NAME_DEFAULT = "jhi-data-distribution-admin";
    static final String JHI_AUTHOR_GROUP_NAME_PROPERTY = "group.jhi-author";
    static final String JHI_AUTHOR_GROUP_NAME_DEFAULT = "jhi-author";
    static final String JHI_ADVISOR_GROUP_NAME_PROPERTY = "group.advisor";
    static final String JHI_ADVISOR_GROUP_NAME_DEFAULT = IsamGroups.AEM_UNVERIFIED_PRO_GROUP;
    static final String JHI_EXCLUSIVE_GROUP_NAME_PROPERTY = "group.exclusive";
    static final String JHI_EXCLUSIVE_GROUP_DEFAULT = IsamGroups.AEM_VERIFIED_PRO_GROUP;
    static final String JHI_INTERNAL_GROUP_NAME_PROPERTY = "group.internal";
    static final String JHI_INTERNAL_GROUP_NAME_DEFAULT = IsamGroups.AEM_EMPLOYEE_GROUP;
    static final String JHI_ADMIN_USER_GROUP_NAME_PROPERTY = "group.adminUser";
    static final String JHI_ADMIN_USER_GROUP_NAME_DEFAULT = IsamGroups.AEM_ADMIN_USER_GROUP;

    static final String ADVISOR_TAG_PROPERTY = "tag.advisor";
    static final String ADVISOR_TAG_DEFAULT = "/content/cq:tags/jhi-website/access-restriction/advisor";
    static final String EXCLUSIVE_TAG_PROPERTY = "tag.exclusive";
    static final String EXCLUSIVE_TAG_DEFAULT = "/content/cq:tags/jhi-website/access-restriction/exclusive";
    static final String RESTRICTED_TAG_PROPERTY = "tag.restricted";
    static final String RESTRICTED_TAG_DEFAULT = "/content/cq:tags/jhi-website/access-restriction/restricted";
    static final String INTERNAL_TAG_PROPERTY = "tag.internal";
    static final String INTERNAL_TAG_DEFAULT = "/content/cq:tags/jhi-website/access-restriction/internal";


    private static final Logger LOGGER = LoggerFactory.getLogger(DamAssetPermissionsUpdateJob.class);
    private static final String RENDITIONS_PATH = JcrConstants.JCR_CONTENT + JhiConstants.SLASH + DamConstants.RENDITIONS_FOLDER;

    @ObjectClassDefinition(name="DAM Asset Permission Udpate Job Configurations for JHI Website", description="Configurations for the DAM Asset Permission Update Job")
    public @interface Config{

        @AttributeDefinition(name = "Jhi Admin user", description = "Admin User name by defaul the value will be admin")
        String user_jhi_admin() default JHI_ADMIN_NAME_DEFAULT;   
        @AttributeDefinition(name = "Jhi data distribution user", description= "JHI data distribution name" )
        String user_jhi_data_distribution_admin() default JHI_DATA_DISTRIBUTION_ADMIN_NAME_DEFAULT;
        @AttributeDefinition(name = "Jhi Author group")
        String group_jhi_author() default DamAssetPermissionsUpdateJob.JHI_AUTHOR_GROUP_NAME_DEFAULT;
        @AttributeDefinition(name = "Jhi Advisor group")
        String group_advisor() default DamAssetPermissionsUpdateJob.JHI_ADVISOR_GROUP_NAME_DEFAULT;
        @AttributeDefinition(name = "Jhi Exclusive group")
        String group_exclusive() default DamAssetPermissionsUpdateJob.JHI_EXCLUSIVE_GROUP_DEFAULT;
        @AttributeDefinition(name = "Jhi Internal group")
        String group_internal() default DamAssetPermissionsUpdateJob.JHI_INTERNAL_GROUP_NAME_DEFAULT; 
        @AttributeDefinition(name = "Jhi Admin User group")
        String group_adminUser() default DamAssetPermissionsUpdateJob.JHI_ADMIN_USER_GROUP_NAME_DEFAULT;
        @AttributeDefinition(name = "Advisor tag")
        String tag_advisor() default DamAssetPermissionsUpdateJob.ADVISOR_TAG_DEFAULT;
        @AttributeDefinition(name = "Exclusive tag")
        String tag_exclusive() default DamAssetPermissionsUpdateJob.EXCLUSIVE_TAG_DEFAULT;
        @AttributeDefinition(name = "Restricted tag")
        String tag_restricted() default DamAssetPermissionsUpdateJob.RESTRICTED_TAG_DEFAULT;
        @AttributeDefinition(name = "Internal tag")
        String tag_internal() default DamAssetPermissionsUpdateJob.INTERNAL_TAG_DEFAULT;

    }
    private String jhiAdminGroupName;
    private String jhiDataDistributionAdminName;
    private String jhiAuthorGroupName;
    private String advisorGroupName;
    private String exclusiveGroupName;
    private String internalGroupName;
    private String adminUserGroupName;

    private Map<String, String> tagsIdsMap = Collections.emptyMap();

    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory ) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory ) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }

    
    private RunModeService runmodeService;
    @Reference
    public void bindRunModeService(RunModeService runmodeService ) {
    	this.runmodeService=runmodeService;
    }
    public void unbindRunModeService(RunModeService runmodeService ) {
    	this.runmodeService=runmodeService;
    }

    @Override
    public JobResult process(Job job) {
        final String productAssetPath = job.getProperty(SlingConstants.PROPERTY_PATH).toString();
        return processProduct(productAssetPath);
    }

    private JobResult processProduct(final String productAssetPath) {
        JobResult jobResult = JobResult.FAILED;

        if (StringUtils.isNotBlank(productAssetPath)) {
            ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
            if (resourceResolver != null) {
                try {
                    Resource productAssetResource = resourceResolver.getResource(productAssetPath);
                    if (productAssetResource != null) {
                        jobResult = updateAssetPermissions(resourceResolver, productAssetResource);
                    } else {
                        return JobResult.CANCEL;
                    }
                } finally {
                    resourceResolver.close();
                }
            }
        }

        return jobResult;
    }

    private JobResult updateAssetPermissions(ResourceResolver resourceResolver, Resource productAssetResource) {
        Resource productResource = productAssetResource.getParent();

        if (productResource != null) {
            RrdProductImpl product = new RrdProductImpl(productResource);
            ValueMap productAssetValues = productAssetResource.getValueMap();

            if (productAssetValues.containsKey(DownloadResource.PN_REFERENCE)) {
                String damAssetPath = productAssetValues.get(DownloadResource.PN_REFERENCE, String.class);
                String renditionsResourcePath = damAssetPath + JhiConstants.SLASH + RENDITIONS_PATH;

                if (StringUtils.isNotBlank(damAssetPath)) {
                    Resource damAssetResource = resourceResolver.getResource(damAssetPath + JhiConstants.SLASH
                            + JcrConstants.JCR_CONTENT + JhiConstants.SLASH + DamConstants.METADATA_FOLDER);
                    if (damAssetResource != null) {
                        LOGGER.debug("Updating DAM asset permissions on {} for {}", damAssetPath, productAssetResource.getPath());

                        return (JobResult) ResourceUtil.executeResourceActionInElevatedResourceResolver(resourceResolverFactory, resolver -> {
                            Session session = resolver.adaptTo(Session.class);
                            if (session != null) {
                                try {
                                    LOGGER.debug("Processing ACL for {}", damAssetPath);
                                    AccessControlManager accessControlManager = session.getAccessControlManager();
                                    JackrabbitAccessControlList accessControlList = AccessControlUtils.getAccessControlList(accessControlManager, damAssetPath);
                                    Privilege[] allPrivilege = AccessControlUtils.privilegesFromNames(accessControlManager, PrivilegeConstants.JCR_ALL);
                                    Privilege[] readPrivilege = AccessControlUtils.privilegesFromNames(accessControlManager, PrivilegeConstants.JCR_READ);
                                    Principal everyoneGroup = AccessControlUtils.getEveryonePrincipal(session);
                                    if (!product.isAccessPublic()) {

                                        // Remove allow for everyone
                                        removeAllGroupPermissions(accessControlList, everyoneGroup, damAssetPath);

                                        // Apply deny for everyone
                                        LOGGER.debug("Applying ACL: everyone/deny {}", damAssetPath);
                                        accessControlList.addEntry(everyoneGroup, allPrivilege, false);
                                        if (!accessControlList.isEmpty()) {
                                            // Find the everyone deny privilege - it may have already been applied and
                                            // be in the incorrect position. We need to make this the first ACL.
                                            AccessControlEntry[] accessControlEntries = accessControlList.getAccessControlEntries();
                                            Stream<AccessControlEntry> everyoneDeny =
                                                    Arrays.stream(accessControlEntries).filter(entry -> {
                                                        if (entry.getPrincipal().getName().equals(everyoneGroup.getName())) {
                                                            return !((ACE) entry).isAllow();
                                                        }
                                                        return false;
                                                    });
                                            Optional<AccessControlEntry> firstEveryoneDeny = everyoneDeny.findFirst();
                                            if (firstEveryoneDeny.isPresent()) {
                                                // Make this the first rule
                                                accessControlList.orderBefore(firstEveryoneDeny.get(),
                                                        accessControlEntries[0]);
                                            } else {
                                                LOGGER.warn("Cannot find everyone deny rule for {}", damAssetPath);
                                            }
                                        }

                                        // Allow authoring and processing
                                        LOGGER.debug("Applying ACL: {}/all {}", jhiAdminGroupName, damAssetPath);
                                        grantAclForPrincipal(session, accessControlList, allPrivilege, jhiAdminGroupName);
                                        LOGGER.debug("Applying ACL: {}/all {}", jhiDataDistributionAdminName, damAssetPath);
                                        grantAclForPrincipal(session, accessControlList, allPrivilege, jhiDataDistributionAdminName);
                                        LOGGER.debug("Applying ACL: {}/all {}", jhiAuthorGroupName, damAssetPath);
                                        grantAclForPrincipal(session, accessControlList, allPrivilege, jhiAuthorGroupName);
                                        LOGGER.debug("Applying ACL: {}/all {}", adminUserGroupName, damAssetPath);
                                        grantAclForPrincipal(session, accessControlList, allPrivilege, adminUserGroupName);

                                        if (product.isAccessAdvisor() || product.isAccessRestricted()) {
                                            // Remove any deny permissions for advisor and exclusive
                                            Principal advisorGroup = AccessControlUtils.getPrincipal(session, advisorGroupName);
                                            removeGroupPermissions(accessControlList, advisorGroup, damAssetPath, false);
                                            Principal exclusiveGroup = AccessControlUtils.getPrincipal(session, exclusiveGroupName);
                                            removeGroupPermissions(accessControlList, exclusiveGroup, damAssetPath, false);

                                            LOGGER.debug("Applying ACL: {}/read {}", advisorGroupName, damAssetPath);
                                            grantAclForPrincipal(session, accessControlList, readPrivilege, advisorGroupName);
                                            LOGGER.debug("Applying ACL: {}/read {}", exclusiveGroupName, damAssetPath);
                                            grantAclForPrincipal(session, accessControlList, readPrivilege, exclusiveGroupName);
                                            LOGGER.debug("Applying ACL: {}/read {}", internalGroupName, damAssetPath);
                                            grantAclForPrincipal(session, accessControlList, readPrivilege, internalGroupName);
                                        }

                                        if (product.isAccessInternal() || product.isAccessExclusive()) {
                                            // Remove allow permissions for advisor/exclusive groups
                                            Principal advisorGroup = AccessControlUtils.getPrincipal(session, advisorGroupName);
                                            removeGroupPermissions(accessControlList, advisorGroup, damAssetPath, true);
                                            Principal exclusiveGroup = AccessControlUtils.getPrincipal(session, exclusiveGroupName);
                                            removeGroupPermissions(accessControlList, exclusiveGroup, damAssetPath, true);
                                           

                                            if (product.isAccessExclusive()) {
                                                Principal internalGroup = AccessControlUtils.getPrincipal(session, internalGroupName);
                                                removeGroupPermissions(accessControlList, internalGroup, damAssetPath, true);
                                            } else {
                                                LOGGER.debug("Applying ACL: {}/read {}", internalGroupName, damAssetPath);
                                                grantAclForPrincipal(session, accessControlList, readPrivilege, internalGroupName);
                                            }
                                        }

                                        Resource renditionsResource = resolver.getResource(renditionsResourcePath);
                                        if (renditionsResource != null) {

                                            // Set the thumbnails to be visible to everyone - in the publisher only
                                        	LOGGER.info("Checking is author for Updating renditions resource", !runmodeService.isAuthor());
                                            if (!runmodeService.isAuthor()) {
                                                LOGGER.info("Updating renditions resource {}", renditionsResourcePath);
                                                JackrabbitAccessControlList renditionsAccessControlList =
                                                        AccessControlUtils.getAccessControlList(
                                                                accessControlManager, renditionsResourcePath);
                                                removeAllGroupPermissions(renditionsAccessControlList, everyoneGroup, damAssetPath);

                                                if (renditionsAccessControlList != null) {
                                                    LOGGER.debug("Applying ACL: {}/read {}", everyoneGroup.getName(), renditionsResourcePath);
                                                    renditionsAccessControlList.addEntry(everyoneGroup, readPrivilege, true);
                                                    accessControlManager.setPolicy(renditionsResourcePath, renditionsAccessControlList);
                                                } else {
                                                    LOGGER.warn("Empty ACL list for {}", renditionsResourcePath);
                                                }
                                            } else {
                                                // Clear out this permission on the author as it causes issues in the author
                                                // where DAM admin is unable to view assets
                                                AccessControlUtils.clear(session, renditionsResourcePath);
                                            }

                                        } else {
                                            LOGGER.warn("Could not get renditions resource at {} for DAM asset {}",
                                                    renditionsResourcePath, damAssetPath);
                                        }

                                    } else {
                                        if (!accessControlList.isEmpty()) {
                                            removeAllGroupPermissions(accessControlList, everyoneGroup, damAssetPath);
                                        }

                                        LOGGER.debug("Applying ACL: {}/read {}", everyoneGroup.getName(), damAssetPath);
                                        accessControlList.addEntry(everyoneGroup, readPrivilege, true);

                                        // Clear the renditions permissions
                                        AccessControlUtils.clear(session, renditionsResourcePath);
                                    }

                                    LOGGER.debug("Applying all permissions for {}", damAssetPath);
                                    accessControlManager.setPolicy(damAssetPath, accessControlList);
                                    session.save();

                                } catch (Exception e) {
                                    LOGGER.error("Could not update ACL's for {}", damAssetPath, e);
                                    return JobResult.FAILED;
                                }
                            } else {
                                LOGGER.error("Problem while obtaining session while updating {}", damAssetPath);
                            }

                            updateTags(damAssetResource, product);
                            return JobResult.OK;
                        });

                    } else {
                        LOGGER.warn("Could not find DAM asset path {} for product {}", damAssetPath, productAssetResource.getPath());
                    }
                } else {
                    LOGGER.warn("No DAM asset path found for product {}", productAssetResource.getPath());
                }
            } else {
                LOGGER.warn("No file reference found on product {}", productAssetResource.getPath());
            }
        }

        return JobResult.CANCEL;
    }

    private void removeAllGroupPermissions(JackrabbitAccessControlList accessControlList, Principal group,
                                           String path) throws RepositoryException {
        if (accessControlList != null && !accessControlList.isEmpty()) {
            Stream<AccessControlEntry> groupPerms =
                    Arrays.stream(accessControlList.getAccessControlEntries()).filter(accessControlEntry ->
                            accessControlEntry.getPrincipal().getName().equals(group.getName()));

            removePermissions(accessControlList, groupPerms, group, path);
        }
    }

    private void removePermissions(JackrabbitAccessControlList accessControlList,
                                   Stream<AccessControlEntry> permissionEntries, Principal group, String path) {
        if (permissionEntries != null) {
            permissionEntries.forEach(accessControlEntry -> {
                if (accessControlEntry != null) {
                    try {
                        LOGGER.debug("Removing ACL: {}/{} {}",
                                new Object[]{group.getName(), ((ACE) accessControlEntry).isAllow() ? "allow" : "deny", path});
                        accessControlList.removeAccessControlEntry(accessControlEntry);
                    } catch (Exception e) {
                        LOGGER.warn("Could not remove ACL entry: {}/{} {}",
                                new Object[]{group.getName(), ((ACE) accessControlEntry).isAllow() ? "allow" : "deny", path, e});
                    }
                }
            });
        }
    }

    private void removeGroupPermissions(JackrabbitAccessControlList accessControlList, Principal group,
                                        String path, boolean allow) throws RepositoryException {
        if (accessControlList != null && !accessControlList.isEmpty()) {
            Stream<AccessControlEntry> groupPerms =
                    Arrays.stream(accessControlList.getAccessControlEntries()).filter(accessControlEntry ->
                            accessControlEntry.getPrincipal().getName().equals(group.getName()) &&
                                    ((ACE) accessControlEntry).isAllow() == allow);

            removePermissions(accessControlList, groupPerms, group, path);
        }
    }

    private void updateTags(Resource damAssetResource, RrdProductImpl product) {
        if (damAssetResource != null && product != null) {
            ModifiableValueMap values = damAssetResource.adaptTo(ModifiableValueMap.class);
            if (values != null) {
                String[] tags = null;
                if (values.containsKey(NameConstants.PN_TAGS)) {
                    tags = values.get(NameConstants.PN_TAGS, String[].class);
                }
                if (tags == null) {
                    if (tagsIdsMap.containsKey(product.getAccess())) {
                        tags = new String[]{tagsIdsMap.get(product.getAccess())};
                        values.put(NameConstants.PN_TAGS, tags);
                    }
                } else {
                    List<String> tagsList = new ArrayList<>(tags.length + 1);
                    for (String tag : tags) {
                        if (!tagsIdsMap.values().contains(tag)) {
                            tagsList.add(tag);
                        }
                    }
                    if (tagsIdsMap.containsKey(product.getAccess())) {
                        tagsList.add(tagsIdsMap.get(product.getAccess()));
                    }
                    values.put(NameConstants.PN_TAGS, tagsList.toArray());
                }
                if (tags != null) {
                    try {
                        damAssetResource.getResourceResolver().commit();
                    } catch (PersistenceException e) {
                        LOGGER.error("Cannot save asset tags", e);
                    }
                }
            } else {
                LOGGER.error("Unable to update asset tags " + damAssetResource.getPath());
            }
        }
    }

    private void grantAclForPrincipal(Session session, JackrabbitAccessControlList acl, Privilege[] privileges, String principalId) {
        try {
            Principal principal = AccessControlUtils.getPrincipal(session, principalId);
            if (principal != null) {
                acl.addEntry(principal, privileges, true);
            } else {
                LOGGER.error("Principal not found {}", principalId);
            }
        } catch (RepositoryException e) {
            LOGGER.error("Problem while adding acl for principal {}", principalId);
        }
    }

    @Activate
    protected void activate(final Config config) {
        update(config);
    }

    @Modified
    protected void update(final Config config) {
        jhiAdminGroupName = config.user_jhi_admin();
        jhiDataDistributionAdminName =config.user_jhi_data_distribution_admin();
        jhiAuthorGroupName = config.group_jhi_author();
        advisorGroupName = config.group_advisor(); 
        exclusiveGroupName = config.group_exclusive(); 
        internalGroupName = config.group_internal();
        adminUserGroupName = config.group_adminUser(); 

        ResourceUtil.consumeResourceInElevatedResourceResolver(resourceResolverFactory, resolver -> {
            // Get the principals/groups from AEM
            Session session = resolver.adaptTo(Session.class);
            if (session != null) {
                checkPrincipalId(session, jhiAdminGroupName);
                checkPrincipalId(session, jhiDataDistributionAdminName);
                checkPrincipalId(session, jhiAuthorGroupName);
                checkPrincipalId(session, advisorGroupName);
                checkPrincipalId(session, exclusiveGroupName);
                checkPrincipalId(session, internalGroupName);
                checkPrincipalId(session, adminUserGroupName);
            } else {
                LOGGER.warn("Could not resolve a session, not checking principals");
            }

            String advisorTagPath = config.tag_advisor(); 
            String exclusiveTagPath = config.tag_exclusive();
            String restrictedTagPath = config.tag_restricted();
            String internalTagPath = config.tag_internal(); 

            // Get the tags from AEM
            TagManager tagManager = resolver.adaptTo(TagManager.class);
            if (tagManager != null) {
                Map<String, String> newTagIdsMap = new HashMap<>(4);
                prepareTagId(tagManager, advisorTagPath, newTagIdsMap, JhiConstants.ACCESS_ADVISOR);
                prepareTagId(tagManager, exclusiveTagPath, newTagIdsMap, JhiConstants.ACCESS_EXCLUSIVE);
                prepareTagId(tagManager, restrictedTagPath, newTagIdsMap, JhiConstants.ACCESS_RESTRICTED);
                prepareTagId(tagManager, internalTagPath, newTagIdsMap, JhiConstants.ACCESS_INTERNAL);
                tagsIdsMap = newTagIdsMap;
            } else {
                LOGGER.warn("Could not get tags manager, tags will be empty");
            }
        });
    }

    private void checkPrincipalId(Session session, String principalId) {
        try {
            Principal principal = AccessControlUtils.getPrincipal(session, principalId);
            if (principal == null) {
                LOGGER.error("Principal not found " + principalId);
            }
        } catch (RepositoryException e) {
            LOGGER.error("Problem while checking principal " + principalId, e);
        }
    }

    private void prepareTagId(TagManager tagManager, String tagPath, Map<String, String> tagsIdsMap, String tagKey) {
        Tag tag = null;
        if (StringUtils.isNotBlank(tagPath)) {
            tag = tagManager.resolve(tagPath);
            if (tag == null) {
                try {
                    tag = tagManager.createTag(tagPath, StringUtils.substringAfterLast(tagPath, JhiConstants.SLASH), StringUtils.EMPTY);
                } catch (InvalidTagFormatException e) {
                    LOGGER.error("Problem while creating tag", e);
                }
            }
        }
        if (tag != null) {
            tagsIdsMap.put(tagKey, tag.getTagID());
        }
    }
}
