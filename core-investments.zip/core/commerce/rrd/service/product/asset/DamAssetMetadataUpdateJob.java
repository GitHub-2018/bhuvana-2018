package com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset;

import org.apache.commons.lang3.StringUtils;

import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.DownloadResource;
import com.day.cq.dam.api.DamConstants;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Component(
		name="DAM Asset Metadata Update Job",
		service=JobConsumer.class,
		immediate=true,
		property= {
				JobConsumer.PROPERTY_TOPICS+"="+DamAssetMetadataUpdateJob.JOB_NAME	
		})

public class DamAssetMetadataUpdateJob implements JobConsumer {
    public static final String JOB_NAME = "com/jhi/aem/website/assetMetadataUpdate";

    private static final Logger LOGGER = LoggerFactory.getLogger(DamAssetMetadataUpdateJob.class);

  
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory ) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory ) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }

    @Override
    public JobResult process(Job job) {
        JobResult jobResult = JobResult.FAILED;
        final String productAssetPath = job.getProperty(SlingConstants.PROPERTY_PATH).toString();
        if (StringUtils.isNotBlank(productAssetPath)) {
            ResourceResolver resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
            if (resourceResolver != null) {
                Resource productAssetResource = resourceResolver.getResource(productAssetPath);
                if (productAssetResource != null) {
                    jobResult = updateAssetsMetadata(resourceResolver, productAssetResource);
                } else {
                    return JobResult.CANCEL;
                }
                resourceResolver.close();
            }
        } else {
            LOGGER.error("Empty path for DamAssetMetadataUpdateJob");
            return JobResult.CANCEL;
        }
        return jobResult;
    }

    private JobResult updateAssetsMetadata(ResourceResolver resourceResolver, Resource productAssetResource) {

        Resource productResource = productAssetResource.getParent();
        if (productResource != null) {
            RrdProductImpl product = new RrdProductImpl(productResource);
            ValueMap productAssetValues = productAssetResource.getValueMap();
            if (productAssetValues.containsKey(DownloadResource.PN_REFERENCE)) {
                String damAssetPath = productAssetValues.get(DownloadResource.PN_REFERENCE, String.class);
                if (StringUtils.isNotBlank(damAssetPath)) {
                    Resource metadataResource = resourceResolver.getResource(damAssetPath + JhiConstants.SLASH
                            + JcrConstants.JCR_CONTENT + JhiConstants.SLASH + DamConstants.METADATA_FOLDER);
                    if (metadataResource != null) {
                        ModifiableValueMap metadataValues = metadataResource.adaptTo(ModifiableValueMap.class);
                        if (metadataValues != null) {
                            boolean needUpdate = false;
                            if (!StringUtils.equals(metadataValues.get(DamConstants.DC_TITLE, StringUtils.EMPTY), product.getMetaTitle())) {
                                metadataValues.put(DamConstants.DC_TITLE, product.getMetaTitle());
                                needUpdate = true;
                            }
                            if (!StringUtils.equals(metadataValues.get(DamConstants.DC_DESCRIPTION, StringUtils.EMPTY), product.getMetaDescription())) {
                                metadataValues.put(DamConstants.DC_DESCRIPTION, product.getMetaDescription());
                                needUpdate = true;
                            }
                            if (needUpdate) {
                                try {
                                    resourceResolver.commit();
                                    return JobResult.OK;
                                } catch (PersistenceException e) {
                                    LOGGER.error("Problem while saving asset metadata", e);
                                    return JobResult.FAILED;
                                }
                            } else {
                                return JobResult.OK;
                            }
                        } else {
                            LOGGER.warn("Cannot get metadata values for " + metadataResource.getPath());
                            return JobResult.FAILED;
                        }
                    } else {
                        return JobResult.FAILED;
                    }
                }
            }
        }
        return JobResult.CANCEL;
    }
}
