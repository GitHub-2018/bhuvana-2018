package com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset;

import javax.management.DynamicMBean;
import javax.management.NotCompliantMBeanException;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.event.jobs.JobManager;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.CommerceConstants;
import com.adobe.granite.jmx.annotation.AnnotatedStandardMBean;
import com.google.common.collect.ImmutableMap;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;


@Component(
		name="JHI Product DAM Asset Manager MBean Impl",
		service=DynamicMBean.class,
		immediate = true,
		property= {
				"jmx.objectname=com.jhi.aem.website.v1.core.commerce.rrd.service.product.asset:type=JHI Product DAM Asset Manager"				
		})

public class JhiProductDamAssetManagerMBeanImpl extends AnnotatedStandardMBean implements JhiProductDamAssetManagerMBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(JhiProductDamAssetManagerMBeanImpl.class);
    private static final String PRODUCT_COMMERCE_TYPE = "product";

    
    private Scheduler scheduler;
    @Reference
    public void bindScheduler(Scheduler scheduler) {
    	this.scheduler=scheduler;
    }
    public void unbindScheduler(Scheduler scheduler) {
    	this.scheduler=scheduler;
    }

    
    private ResourceResolverFactory resourceResolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
    	this.resourceResolverFactory=resourceResolverFactory;
    }
    
    private JobManager jobManager;
    @Reference
    public void bindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }
    public void unbindJobManager(JobManager jobManager) {
    	this.jobManager=jobManager;
    }

    public JhiProductDamAssetManagerMBeanImpl() throws NotCompliantMBeanException {
        super(JhiProductDamAssetManagerMBean.class);
    }

    @Override
    public void reprocessDamPermissions() {
        final ScheduleOptions options = scheduler.NOW()
                .canRunConcurrently(false)
                .name("JhiProductDamAssetManagerMBeanImpl.reprocessJob");

        final org.apache.sling.commons.scheduler.Job reprocessingJob = context ->
                com.jhi.aem.website.v1.core.utils.ResourceUtil
                        .consumeResourceInElevatedResourceResolver(resourceResolverFactory, resolver -> {
                            // Reprocess all products
                            LOGGER.debug("Reprocessing all products...");
                            Resource productsRoot = resolver.getResource(JhiConstants.RRD_PRODUCTS_ROOT);
                            if (productsRoot != null) {
                                reprocessProductResources(productsRoot);
                                LOGGER.debug("Finished reprocessing all products");
                            }
                        });

        scheduler.schedule(reprocessingJob, options);
        LOGGER.debug("Scheduled reprocessing job");

    }

    private void reprocessProductResources(Resource productsFolder) {
        for (Resource resource : productsFolder.getChildren()) {
            if (StringUtils.equals(PRODUCT_COMMERCE_TYPE,
                    resource.getValueMap().get(CommerceConstants.PN_COMMERCE_TYPE, String.class))) {
                //updateChildAsset(resource, null);
                updateChildAsset(resource, RrdProductImpl.WEB_ASSET);
                updateChildAsset(resource, RrdProductImpl.PRINT_ASSET);
            } else if (resource.isResourceType(JcrResourceConstants.NT_SLING_FOLDER)
                    || resource.isResourceType(JcrResourceConstants.NT_SLING_ORDERED_FOLDER)) {
                reprocessProductResources(resource);
            }
        }
    }

    private void updateChildAsset(Resource resource, String childPath) {
        Resource asset = StringUtils.isNotBlank(childPath) ? resource.getChild(childPath) : resource;

        if (asset != null && !ResourceUtil.isNonExistingResource(asset)) {
            jobManager.addJob(DamAssetPermissionsUpdateJob.JOB_NAME, ImmutableMap.of(SlingConstants.PROPERTY_PATH, asset.getPath()));
        }
    }
}
