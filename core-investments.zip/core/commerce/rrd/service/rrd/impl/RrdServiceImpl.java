package com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.http.Header;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdException;
import com.jhi.aem.website.v1.core.commerce.rrd.models.CheckItemStatusResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.models.CheckOrderStatusResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.models.SubmitOrderRequest;
import com.jhi.aem.website.v1.core.commerce.rrd.models.SubmitOrderResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.RrdService;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolExecutor;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolService;
import com.jhi.aem.website.v1.core.utils.HttpUtil;
import com.jhi.aem.website.v1.core.utils.JsonUtil;
import com.jhi.aem.website.v1.core.utils.LogUtils;

@Component(
		name="RRD Service Implementation-JHI Website",
		service=RrdService.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.impl.RrdServiceImpl",
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website RRD Service",
				Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
		})

@Designate(ocd=RrdServiceImpl.Config.class)
public class RrdServiceImpl implements RrdService {

    private static final Logger LOG = LoggerFactory.getLogger(RrdServiceImpl.class);
    
    @ObjectClassDefinition(name="RRD Service Implementation Configurations for JHI Website", description="Configurations for JHI Website RRD Service Implementation")
    public @interface Config {
    	@AttributeDefinition(name="RRD url", description="URL to connect RRD Service")
    	String instancecUrl() default RrdService.DEFAULT_INSTANCE_URL;
    	
    	@AttributeDefinition(name="Username", description="RRD Service username")
    	String rrd_username() default StringUtils.EMPTY;
    	
    	@AttributeDefinition(name="Password", description="RRD Service password")
    	String rrd_password() default StringUtils.EMPTY;
    }
    private static final long DEFAULT_TIMEOUT_MS = 120000;

    private static final String SUBMIT_ORDER_URL = "%s/JHISO/V1/SubmitOrder";
    private static final String CHECK_ORDER_STATUS_URL = "%s/JHIO/V1/Order/%s";
    private static final String CHECK_ITEM_STATUS_URL = "%s/JHI/V1/Item/%s";

    private static final String FAILURE_INDICATOR = "Failure";

    public static final String ITEM_NOT_FOUND_RESPONSE = "Item Not Found";

    private AsyncHttpClientPoolService httpClientPool;
    @Reference
    public void bindAsyncHttpClientPoolService (AsyncHttpClientPoolService httpClientPool) {
    	this.httpClientPool=httpClientPool;
    }
    public void unbindAsyncHttpClientPoolService (AsyncHttpClientPoolService httpClientPool) {
    	this.httpClientPool=httpClientPool;
    }

    private String instanceUrl;
    private final GsonBuilder gsonBuilder = new GsonBuilder();
    private Header authHeader = null;


    @Override
    public SubmitOrderResponse submitOrder(SubmitOrderRequest request) throws RrdException {
        final Gson gson = gsonBuilder.create();
        final String json = gson.toJson(request);

        final String url = String.format(SUBMIT_ORDER_URL, instanceUrl);
        final HttpPost postMethod = new HttpPost(url);
        postMethod.addHeader("Content-Type", JhiConstants.APPLICATION_JSON_RESPONSE);
        if (authHeader != null) {
            postMethod.addHeader(authHeader);
        }
        postMethod.setEntity(new StringEntity(json, ContentType.APPLICATION_JSON));

        try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
            Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(postMethod);
            HttpResponse httpResponse = future.get(DEFAULT_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            handleMethodStatus(httpResponse);

            // Handle the response
            SubmitOrderResponse response =
                    gson.fromJson(JsonUtil.getJsonContent(httpResponse.getEntity().getContent()), SubmitOrderResponse.class);
            handleResponseStatus(response);
            return response;
        } catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
            LOG.error("Error calling RRD submit order API", e);
            throw new RrdException("Error calling RRD submit order API", e);
        }
    }

    @Override
    public CheckOrderStatusResponse checkOrderStatus(String id) throws RrdException {
        final Gson gson = gsonBuilder.create();
        final String url = String.format(CHECK_ORDER_STATUS_URL, instanceUrl, id);
        final HttpGet getMethod = new HttpGet(url);
        if (authHeader != null) {
            getMethod.addHeader(authHeader);
        }

        try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
            Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(getMethod);
            HttpResponse httpResponse = future.get(DEFAULT_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            handleMethodStatus(httpResponse);

            return gson.fromJson(JsonUtil.getJsonContent(httpResponse.getEntity().getContent()), CheckOrderStatusResponse.class);
        } catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
            LOG.error("Error calling RRD check order status API with URL {}", url, e);
            throw new RrdException("Error calling RRD check order status API", e);
        }
    }

    @Override
    public CheckItemStatusResponse checkItemStatus(String code) throws RrdException {
        if (StringUtils.isBlank(code)) {
            LOG.error("Product code is blank");
            return null;
        }
        final Gson gson = gsonBuilder.create();
        String encodedItemCode;
        try {
            encodedItemCode = URLEncoder.encode(code, JhiConstants.DEFAULT_CHARSET_NAME);
        } catch (UnsupportedEncodingException e) {
            LOG.error("Problem while encoding product code " + code, e);
            return null;
        }
        final String url = String.format(CHECK_ITEM_STATUS_URL, instanceUrl, encodedItemCode);
        final HttpGet getMethod = new HttpGet(url);
        if (authHeader != null) {
            getMethod.addHeader(authHeader);
        }

        try (AsyncHttpClientPoolExecutor httpClientBuilder = new AsyncHttpClientPoolExecutor(httpClientPool)) {
            Future<HttpResponse> future = httpClientBuilder.withStandardRequestConfig().execute(getMethod);
            HttpResponse httpResponse = future.get(DEFAULT_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            handleMethodStatus(httpResponse);
            return gson.fromJson(JsonUtil.getJsonContent(httpResponse.getEntity().getContent()), CheckItemStatusResponse.class);
        } catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
            LOG.error("Error calling RRD check item status API with URL {}", url, e);
            throw new RrdException("Error calling RRD check item status API", e);
        }
    }

    private void handleMethodStatus(HttpResponse response) throws RrdException {
        StatusLine statusLine = response.getStatusLine();
        if (statusLine.getStatusCode() != HttpServletResponse.SC_OK) {
            final String errorMessage = "Error calling RRD API: " +
                    LogUtils.sanitizeLogInput(statusLine.getStatusCode()) + " - " +
                    LogUtils.sanitizeLogInput(statusLine.getReasonPhrase()) + " - " +
                    LogUtils.sanitizeLogInput(HttpUtil.getResponseContent(response));
            LOG.error(errorMessage);
            throw new RrdException(errorMessage);
        }
    }

    private void handleResponseStatus(SubmitOrderResponse response) throws RrdException {
        final String statusFlag = response != null ? response.getStatusFlag() : StringUtils.EMPTY;
        if (StringUtils.isBlank(statusFlag) || StringUtils.contains(statusFlag, FAILURE_INDICATOR)) {
            final String errorMessage = "RRD Submit order response indicated a failure in the status flag '" +
                    statusFlag + "': " + ReflectionToStringBuilder.toString(response);
            LOG.error(errorMessage);
            throw new RrdException(errorMessage);
        }
    }

    @Activate
    protected void activate(final Config config) {
        update(config);
    }

    @Modified
    protected void update(final Config config) {
        authHeader = null;
        instanceUrl = config.instancecUrl();
        //instanceUrl = PropertiesUtil.toString(properties.get(INSTANCE_URL_PROPERTY), DEFAULT_INSTANCE_URL);
        final String username = config.rrd_username();
        //final String username = PropertiesUtil.toString(properties.get(USERNAME_PROPERTY), StringUtils.EMPTY);
        final String password = config.rrd_password();
        //final String password = PropertiesUtil.toString(properties.get(PASSWORD_PROPERTY), StringUtils.EMPTY);

        if (StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password)) {
            byte[] authEncoded = Base64.encodeBase64((username + JhiConstants.COLON + password).getBytes());
            try {
				authHeader = new BasicHeader(HttpHeaders.AUTHORIZATION,
						AuthSchemes.BASIC + StringUtils.SPACE + new String(authEncoded, "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException(e);
			}
        }
    }
}
