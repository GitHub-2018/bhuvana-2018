package com.jhi.aem.website.v1.core.commerce.rrd.service.rrd;

import com.jhi.aem.website.v1.core.commerce.rrd.RrdException;
import com.jhi.aem.website.v1.core.commerce.rrd.models.CheckItemStatusResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.models.CheckOrderStatusResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.models.SubmitOrderRequest;
import com.jhi.aem.website.v1.core.commerce.rrd.models.SubmitOrderResponse;

public interface RrdService {

    String INSTANCE_URL_PROPERTY = "instanceUrl";
    String DEFAULT_INSTANCE_URL = "https://api85-qa.rrd.com";
    String USERNAME_PROPERTY = "rrd.username";
    String PASSWORD_PROPERTY = "rrd.password";

    SubmitOrderResponse submitOrder(SubmitOrderRequest request) throws RrdException;

    CheckOrderStatusResponse checkOrderStatus(String id) throws RrdException;

    CheckItemStatusResponse checkItemStatus(String id) throws RrdException;
}
