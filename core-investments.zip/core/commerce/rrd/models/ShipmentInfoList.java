package com.jhi.aem.website.v1.core.commerce.rrd.models;

import com.google.gson.annotations.SerializedName;

public class ShipmentInfoList {

    @SerializedName("ShippedQty")
    private String shippedQty;

    @SerializedName("BackOrderedQty")
    private String backOrderedQty;

    @SerializedName("Carrier")
    private String carrier;

    @SerializedName("ShipDate")
    private String shipDate;

    @SerializedName("TrackingNumber")
    private String trackingNumber;

    public String getShippedQty() {
        return shippedQty;
    }

    public String getBackOrderedQty() {
        return backOrderedQty;
    }

    public String getCarrier() {
        return carrier;
    }

    public String getShipDate() {
        return shipDate;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }
}
