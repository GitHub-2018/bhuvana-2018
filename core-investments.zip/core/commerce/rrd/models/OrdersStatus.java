package com.jhi.aem.website.v1.core.commerce.rrd.models;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.annotations.SerializedName;
import com.jhi.aem.website.v1.core.commerce.rrd.OrderItemShipmentDetails;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdCommerceSessionImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.DateUtil;

public class OrdersStatus {

    private static final String ZERO_QUANTITY = "0";

    @SerializedName("PurchaseOrder")
    private String purchaseOrder;

    @SerializedName("CustomerItemNumber")
    private String customerItemNumber;

    @SerializedName("OrderLineStatusCode")
    private String orderLineStatusCode;

    @SerializedName("ItemOrderedQty")
    private String itemOrderedQty;

    @SerializedName("ShipmentInfoList")
    private List<ShipmentInfoList> shipmentInfoList = null;

    public String getPurchaseOrder() {
        return purchaseOrder;
    }

    public String getCustomerItemNumber() {
        return customerItemNumber;
    }

    public String getOrderLineStatusCode() {
        return orderLineStatusCode;
    }

    public String getItemOrderedQty() {
        return itemOrderedQty;
    }

    public List<ShipmentInfoList> getShipmentInfoList() {
        return shipmentInfoList;
    }

    public String getShipmentStatus() {
        if (shipmentInfoList != null && !shipmentInfoList.isEmpty()) {
            List<String> statusList = new ArrayList<>(shipmentInfoList.size());
            for (ShipmentInfoList shipmentInfo : shipmentInfoList) {
                statusList.add(getShippedQuantity(shipmentInfo) + RrdCommerceSessionImpl.ITEM_ENTRY_SEPARATOR
                        + getFormattedShipDate(shipmentInfo.getShipDate()) + RrdCommerceSessionImpl.ITEM_ENTRY_SEPARATOR +
                        shipmentInfo.getTrackingNumber());
            }
            return StringUtils.join(statusList, JhiConstants.VALUES_SEPARATOR);
        }
        return StringUtils.EMPTY;
    }

    public List<OrderItemShipmentDetails> getShipmentDetailsList() {
        if (shipmentInfoList != null && !shipmentInfoList.isEmpty()) {
            List<OrderItemShipmentDetails> statusList = new ArrayList<>(shipmentInfoList.size());
            for (ShipmentInfoList shipmentInfo : shipmentInfoList) {
                statusList.add(new OrderItemShipmentDetails(getShippedQuantity(shipmentInfo), getFormattedShipDate(shipmentInfo.getShipDate()),
                        shipmentInfo.getTrackingNumber()));
            }
            return statusList;
        }
        return Collections.emptyList();
    }

    private String getShippedQuantity(ShipmentInfoList shipmentInfo) {
        if (StringUtils.isNotBlank(shipmentInfo.getShippedQty()) && !StringUtils.equals(ZERO_QUANTITY, shipmentInfo.getShippedQty())) {
            return shipmentInfo.getShippedQty();
        }
        return StringUtils.EMPTY;
    }

    private String getFormattedShipDate(String dateString) {
        if (StringUtils.isNotBlank(dateString)) {
            Calendar parsedDate = DateUtil.parseRrdDate(dateString, null);
            if (parsedDate != null) {
                return DateUtil.getFormattedFullDate(parsedDate, null);
            }
        }
        return StringUtils.EMPTY;
    }
}
