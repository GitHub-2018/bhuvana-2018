
package com.jhi.aem.website.v1.core.commerce.rrd.models;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class SubmitOrderRequest {

    @SerializedName("OrderHeader")
    private OrderHeader orderHeader;
    
    @SerializedName("OrderLine")
    private List<OrderLine> orderLine = null;

    public SubmitOrderRequest(OrderHeader orderHeader, List<OrderLine> orderLine) {
        super();
        this.orderHeader = orderHeader;
        this.orderLine = orderLine;
    }

    public SubmitOrderRequest() {
    }

    public OrderHeader getOrderHeader() {
        return orderHeader;
    }

    public List<OrderLine> getOrderLine() {
        return orderLine;
    }
}
