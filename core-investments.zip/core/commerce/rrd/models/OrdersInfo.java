package com.jhi.aem.website.v1.core.commerce.rrd.models;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class OrdersInfo {

    @SerializedName("OrdersStatus")
    private List<OrdersStatus> ordersStatus = null;

    public List<OrdersStatus> getOrdersStatus() {
        return ordersStatus;
    }
}
