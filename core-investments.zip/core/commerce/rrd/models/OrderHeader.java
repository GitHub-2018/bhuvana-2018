package com.jhi.aem.website.v1.core.commerce.rrd.models;

import com.google.gson.annotations.SerializedName;

public class OrderHeader {

    @SerializedName("PONumber")
    private String poNumber;

    @SerializedName("OrderDate")
    private String orderDate;

    @SerializedName("ShippingServiceLevel")
    private String shippingServiceLevel;

    @SerializedName("SpecialShippingInstructions")
    private String specialShippingInstructions;

    @SerializedName("ShipTo")
    private String shipTo;

    @SerializedName("ShiptoFields")
    private ShiptoFields shipToFields;

    public OrderHeader() {
    }

    public OrderHeader(String poNumber, String orderDate, String shippingServiceLevel, String specialShippingInstructions, String shipTo,
                       ShiptoFields shipToFields) {
        this.poNumber = poNumber;
        this.orderDate = orderDate;
        this.shippingServiceLevel = shippingServiceLevel;
        this.specialShippingInstructions = specialShippingInstructions;
        this.shipTo = shipTo;
        this.shipToFields = shipToFields;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public String getShippingServiceLevel() {
        return shippingServiceLevel;
    }

    public String getSpecialShippingInstructions() {
        return specialShippingInstructions;
    }

    public String getShipTo() {
        return shipTo;
    }

    public ShiptoFields getShipToFields() {
        return shipToFields;
    }
}
