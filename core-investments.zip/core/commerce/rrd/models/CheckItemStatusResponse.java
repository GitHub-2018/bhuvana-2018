package com.jhi.aem.website.v1.core.commerce.rrd.models;

import com.google.gson.annotations.SerializedName;

public class CheckItemStatusResponse {

    @SerializedName("JHItemNumber")
    private String jhItemNumber;

    @SerializedName("RRDItemDescription")
    private String rrdItemDescription;

    @SerializedName("ItemStatus")
    private String itemStatus;

    @SerializedName("InventoryAvailable")
    private String inventoryAvailable;

    public String getJhItemNumber() {
        return jhItemNumber;
    }

    public String getRrdItemDescription() {
        return rrdItemDescription;
    }

    public String getItemStatus() {
        return itemStatus;
    }

    public String getInventoryAvailable() {
        return inventoryAvailable;
    }
}
