package com.jhi.aem.website.v1.core.commerce.rrd.models;

import com.google.gson.annotations.SerializedName;

public class SubmitOrderResponse {

    @SerializedName("StatusFlag")
    private String statusFlag;

    public String getStatusFlag() {
        return statusFlag;
    }
}
