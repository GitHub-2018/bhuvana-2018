package com.jhi.aem.website.v1.core.commerce.rrd.models;

import com.google.gson.annotations.SerializedName;

public class OrderLine {

    @SerializedName("JHItemNumber")
    private String jhItemNumber;
    
    @SerializedName("Quantity")
    private String quantity;
    
    @SerializedName("UOM")
    private String uom;

    public OrderLine(String jhItemNumber, int quantity, String uom) {
        super();
        this.jhItemNumber = jhItemNumber;
        this.quantity = Integer.toString(quantity);
        this.uom = uom;
    }

    public OrderLine() {
    }
}
