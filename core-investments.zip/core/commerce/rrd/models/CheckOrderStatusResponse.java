package com.jhi.aem.website.v1.core.commerce.rrd.models;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.annotations.SerializedName;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdCommerceSessionImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdOrderStatus;

public class CheckOrderStatusResponse {

    @SerializedName("OrdersInfo")
    private OrdersInfo ordersInfo;

    public OrdersInfo getOrdersInfo() {
        return ordersInfo;
    }

    public String getProcessedOrderStatus() {
        if (ordersInfo == null || ordersInfo.getOrdersStatus() == null || ordersInfo.getOrdersStatus().isEmpty()) {
            return RrdCommerceSessionImpl.ORDER_OPEN;
        }
        for (OrdersStatus order : ordersInfo.getOrdersStatus()) {
            if (!isFinished(order)) {
                return RrdCommerceSessionImpl.ORDER_OPEN;
            }
        }
        return RrdCommerceSessionImpl.ORDER_CLOSED;
    }

    private boolean isFinished(OrdersStatus ordersStatus) {
        return StringUtils.equalsIgnoreCase(RrdOrderStatus.SHIPPED.getValue(), ordersStatus.getOrderLineStatusCode())
                || StringUtils.equalsIgnoreCase(RrdOrderStatus.CANCELED.getValue(), ordersStatus.getOrderLineStatusCode())
                || StringUtils.equalsIgnoreCase(RrdOrderStatus.INVOICED.getValue(), ordersStatus.getOrderLineStatusCode());
    }
}
