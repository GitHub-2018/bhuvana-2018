package com.jhi.aem.website.v1.core.commerce.rrd.models;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.annotations.SerializedName;
import com.jhi.aem.website.v1.core.models.user.AddressModel;

public class ShiptoFields {

    private static final int MAX_CHARACTERS = 35;

    @SerializedName("AttentionTo")
    private String attentionTo;

    @SerializedName("NameLine1")
    private String nameLine1;

    @SerializedName("Nameline2")
    private String nameLine2;

    @SerializedName("AddressLine1")
    private String addressLine1;

    @SerializedName("AddressLine2")
    private String addressLine2;

    @SerializedName("AddressLine3")
    private String addressLine3;

    @SerializedName("City")
    private String city;

    @SerializedName("StateorProvince")
    private String stateorProvince;

    @SerializedName("PostalCode")
    private String postalCode;

    @SerializedName("Country")
    private String country;

    public ShiptoFields(String attentionTo, String nameLine1, String nameLine2, String addressLine1,
                        String addressLine2, String addressLine3, String city, String stateorProvince, String postalCode,
                        String country) {
        super();
        this.attentionTo = attentionTo;
        this.nameLine1 = nameLine1;
        this.nameLine2 = nameLine2;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.addressLine3 = addressLine3;
        this.city = city;
        this.stateorProvince = stateorProvince;
        this.postalCode = postalCode;
        this.country = country;
    }

    public ShiptoFields(AddressModel address) {
        super();
        if (StringUtils.isNotBlank(address.getName())) {
            if (address.getName().length() <= MAX_CHARACTERS) {
                this.nameLine1 = address.getName();
            } else {
                String[] splitData = getMultilineData(address.getName(), 2);
                if (splitData.length > 0) {
                    this.nameLine1 = splitData[0];
                }
                if (splitData.length > 1) {
                    this.nameLine2 = splitData[1];
                }
            }
        }
        if (StringUtils.isNotBlank(address.getAddress())) {
            String fullAddress = address.getAddress() + StringUtils.SPACE + address.getBuildingDetail();
            if (fullAddress.length() <= MAX_CHARACTERS) {
                this.addressLine1 = fullAddress;
            } else {
                String[] splitData = getMultilineData(fullAddress, 3);
                if (splitData.length > 0) {
                    this.addressLine1 = splitData[0];
                }
                if (splitData.length > 1) {
                    this.addressLine2 = splitData[1];
                }
                if (splitData.length > 2) {
                    this.addressLine3 = splitData[2];
                }
            }
        }
        this.city = address.getCity();
        this.stateorProvince = address.getState();
        this.postalCode = address.getZip();
        this.country = address.getCountry();
    }

    public ShiptoFields() {
    }

    public String getAttentionTo() {
        return attentionTo;
    }

    public String getNameLine1() {
        return nameLine1;
    }

    public String getNameLine2() {
        return nameLine2;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public String getCity() {
        return city;
    }

    public String getStateorProvince() {
        return stateorProvince;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getCountry() {
        return country;
    }

    private String[] getMultilineData(String data, int maxLines) {
        if (StringUtils.isBlank(data)) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        if (data.length() <= 35) {
            return new String[]{data};
        }
        int numberOfElements = Math.min(maxLines, (data.length() + MAX_CHARACTERS - 1) / MAX_CHARACTERS);
        String[] result = new String[numberOfElements];
        for (int i = 0; i < numberOfElements; i++) {
            result[i] = data.substring(i * MAX_CHARACTERS, Math.min((i + 1) * MAX_CHARACTERS, data.length()));
        }
        return result;
    }
}
