package com.jhi.aem.website.v1.core.httpcache.invalidator.event;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Nonnull;


import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.observation.ResourceChange;
import org.apache.sling.api.resource.observation.ResourceChangeListener;
import org.apache.sling.commons.scheduler.Job;
import org.apache.sling.commons.scheduler.JobContext;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.event.jobs.JobManager;
import org.osgi.framework.Constants;
import org.osgi.framework.ServiceException;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.httpcache.invalidator.CacheInvalidationJobConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;

@Component(
		name = "JHI Website - HTTP Cache - Accept all extension for HttpCacheConfig and CacheKeyFactory.",
        immediate=true,
        service=ResourceChangeListener.class,
        configurationPid="com.jhi.aem.website.v1.core.httpcache.invalidator.event.HttpCacheInvalidationResourceChangeListener",
        property= {
        		Constants.SERVICE_DESCRIPTION+"=A resource listener for HTTP Cache invalidation events"
        })

@Designate(ocd=HttpCacheInvalidationResourceChangeListener.Config.class)
public class HttpCacheInvalidationResourceChangeListener
	implements ResourceChangeListener {
    private static final Logger LOG = LoggerFactory.getLogger(HttpCacheInvalidationResourceChangeListener.class);
	private static final long CACHE_INVALIDATION_PERIOD_SECONDS = 60;
    private static final long CACHE_INVALIDATION_BETWEEN_JOB_CREATION_SLEEP_MS = 800;
	private static final String KEY_CACHE_INVALIDATION_JOB_NAME = "HttpCacheInvalidationResourceChangeListener.CacheInvalidationJob";

	@ObjectClassDefinition(name="HTTP Cache Invalidation Resource change Listener Configurations for JHI website",description="ACS Common Configurations for HTTP Cache Validation Resource change listener")
	public @interface Config{

        @AttributeDefinition(
                name = "Paths",
                description = "[ Required ] A list of resource paths which will invalidate this resource.")
        String resource_paths() default JhiConstants.JHI_WEBSITE_ROOT;
        @AttributeDefinition(
                name = "Change Types",
                description = "[ Optional ] The change event types this listener will listener for, if empty will default to all events. " )
        String[] resource_change_types() default {"CHANGED","REMOVED"};

	}
    
    private JobManager jobManager;
    @Reference
    public void bindJobManager(JobManager jobManager ) {
    	this.jobManager=jobManager;
    }
    public void unbindJobManager(JobManager jobManager ) {
    	this.jobManager=jobManager;
    }

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory ) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory ) {
    	this.resolverFactory=resolverFactory;
    }

    
    private Scheduler scheduler;
    @Reference
    public void bindScheduler(Scheduler scheduler ) {
    	this.scheduler=scheduler;
    }
    public void unbindScheduler(Scheduler scheduler ) {
    	this.scheduler=scheduler;
    }

    
    private RunModeService runModeService;
    @Reference
    public void bindRunModeService(RunModeService runModeService ) {
    	this.runModeService=runModeService;
    }
    public void unbindRunModeService(RunModeService runModeService ) {
    	this.runModeService=runModeService;
    }

    private Set<String> cacheInvalidationPaths = new HashSet<>();
    private ReentrantLock cacheInvalidationPathsLock = new ReentrantLock();

    /**
     * Add the paths inside a job. Replication events take a while to process and may process
     * multiple components within a page so we accummulate them here.
     */
    private class CacheInvalidationJob implements Job {

		@Override
        public void execute(JobContext context) {
        	// Copy the old set
        	Set<String> invalidationPaths;
        	cacheInvalidationPathsLock.lock();

        	try {
        		invalidationPaths = new HashSet<>(cacheInvalidationPaths);
        		cacheInvalidationPaths.clear();
        	} finally {
        		cacheInvalidationPathsLock.unlock();
        	}

        	ResourceUtil.consumeResourceInElevatedResourceResolver(resolverFactory, resourceResolver -> {
        		Set<String> pagePathsProcessed = new HashSet<>();

        		// Go through each of the paths and create a job for it
	        	for (String path : invalidationPaths) {
		            Resource resource = resourceResolver.resolve(path);
	
		            if (resource != null &&
		            		!org.apache.sling.api.resource.ResourceUtil.isNonExistingResource(resource)) {
	
		            	// Get the resource's containing page
		            	Page containingPage = PageUtil.getContainingPage(resource);
	
		            	if (containingPage != null) {
				            String pagePath = containingPage.getPath() + JhiConstants.URL_HTML_EXTENSION;
				            
				            if (pagePathsProcessed.add(pagePath)) {
				        		// Create the required payload.
					            final Map<String, Object> payload = new HashMap<String, Object>();
					            payload.put(CacheInvalidationJobConstants.PAYLOAD_KEY_DATA_CHANGE_PATH, pagePath);
					
					            // Start a job.
					            jobManager.addJob(CacheInvalidationJobConstants.TOPIC_HTTP_CACHE_INVALIDATION_JOB, payload);	
					            LOG.trace("New invalidation job for path='{}'", pagePath);
					            try {
									Thread.sleep(CACHE_INVALIDATION_BETWEEN_JOB_CREATION_SLEEP_MS);
								} catch (InterruptedException e) {
								}
				            } else {
				            	LOG.trace("Page path already processed {}", pagePath);
				            }

		            	} else {
		                	LOG.trace("Cannot get containing page for resource '{}'", path);
		            	}
		            } else {
		            	LOG.trace("Cannot find resource '{}'", path);
		            }
		    	
	
	        	}
        	});

        }

    }

    @Activate
    public void activate(final Config config) throws IllegalAccessException, LoginException, IOException {
        doConfigure(config);
        LOG.info("Activated HTTP Cache Invalidation Resource Change Listener");
    }

    @Modified
    public void modified(final Config config) throws IllegalAccessException, LoginException, IOException {
        doConfigure(config);
        LOG.info("Modified HTTP Cache Invalidation Resource Change Listener");
    }
    
    private void doConfigure(final Config config) throws ServiceException {
    	if (runModeService.isAuthor()) {
    		throw new ServiceException("This service does not run on the author");
    	}

    	CacheInvalidationJob cacheInvalidationJob = new CacheInvalidationJob();
        ScheduleOptions options = scheduler.AT(new Date(), -1, CACHE_INVALIDATION_PERIOD_SECONDS)
                .canRunConcurrently(false)
                .name(KEY_CACHE_INVALIDATION_JOB_NAME);
        scheduler.schedule(cacheInvalidationJob, options);
        LOG.debug("Scheduled job '" + KEY_CACHE_INVALIDATION_JOB_NAME + "'");
    }

    @Deactivate
    public void deactivate() {
        scheduler.unschedule(KEY_CACHE_INVALIDATION_JOB_NAME);
        LOG.debug("Unscheduled job '" + KEY_CACHE_INVALIDATION_JOB_NAME + "'");
    }

    public void onChange(@Nonnull List<ResourceChange> changes) {
		// Iterate over the ResourceChanges and process them
        for (final ResourceChange change : changes) {

        	// Get the resource from the change path
            final String path = change.getPath();
            // Add the path
            cacheInvalidationPathsLock.lock();
            
            try {
	            if (cacheInvalidationPaths.add(path)) {
	            	if (LOG.isTraceEnabled()) {
	            		LOG.trace("Added change path for change type={}, path='{}'" + 
	            			change.getType().name(), path);
	            	}
	            }
            } finally {
            	cacheInvalidationPathsLock.unlock();
            }
        }
    }

}