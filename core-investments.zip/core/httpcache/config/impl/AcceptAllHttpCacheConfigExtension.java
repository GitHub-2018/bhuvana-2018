package com.jhi.aem.website.v1.core.httpcache.config.impl;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.sling.api.SlingHttpServletRequest;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import com.adobe.acs.commons.httpcache.config.HttpCacheConfig;
import com.adobe.acs.commons.httpcache.config.HttpCacheConfigExtension;
import com.adobe.acs.commons.httpcache.exception.HttpCacheKeyCreationException;
import com.adobe.acs.commons.httpcache.exception.HttpCacheRepositoryAccessException;
import com.adobe.acs.commons.httpcache.keys.AbstractCacheKey;
import com.adobe.acs.commons.httpcache.keys.CacheKey;
import com.adobe.acs.commons.httpcache.keys.CacheKeyFactory;

@Component(
	name = "ACS AEM Commons - HTTP Cache - Accept all extension for HttpCacheConfig and CacheKeyFactory.",
	configurationPolicy = ConfigurationPolicy.OPTIONAL,
	configurationPid="com.jhi.aem.website.v1.core.httpcache.config.impl.AcceptAllHttpCacheConfigExtension",
	service= {HttpCacheConfigExtension.class,CacheKeyFactory.class}
)

@Designate(ocd=AcceptAllHttpCacheConfigExtension.Config.class,factory=true)
public class AcceptAllHttpCacheConfigExtension implements HttpCacheConfigExtension, CacheKeyFactory {

	 
	@ObjectClassDefinition(name="Accept All HTTPCache Config Extension configurations for JHI Website")
	public @interface Config{
		@AttributeDefinition(name = "Enabled",type = AttributeType.BOOLEAN)
		boolean enabled() default true;	
	}
    
    private boolean enabled;
    
    @Activate
    protected void activate(final Config configs) {
    	enabled = configs.enabled();
    }

	@Override
    public boolean accepts(SlingHttpServletRequest request, HttpCacheConfig cacheConfig) throws
            HttpCacheRepositoryAccessException {
    	return enabled;
    }

    @Override
    public CacheKey build(final SlingHttpServletRequest slingHttpServletRequest, final HttpCacheConfig cacheConfig)
            throws HttpCacheKeyCreationException {
        return new AcceptAllCacheKey(slingHttpServletRequest, cacheConfig);
    }
    
    @Override
    public CacheKey build(final String resourcePath, final HttpCacheConfig cacheConfig)
            throws HttpCacheKeyCreationException {
        return new AcceptAllCacheKey(resourcePath, cacheConfig);
    }

    @Override
    public boolean doesKeyMatchConfig(CacheKey key, HttpCacheConfig cacheConfig) throws HttpCacheKeyCreationException {

        // Check if key is instance of ResourceTypeCacheKey.
        if (!(key instanceof AcceptAllCacheKey)) {
            return false;
        }
        // Validate if key request uri can be constructed out of uri patterns in cache config.
        return new AcceptAllCacheKey(key.getUri(), cacheConfig).equals(key);
    }

    /**
     * The ResourceTypeCacheKey is a custom CacheKey bound to this particular factory.
     */
    static class AcceptAllCacheKey extends AbstractCacheKey implements CacheKey, Serializable
    {
		private static final long serialVersionUID = 1L;

		public AcceptAllCacheKey(SlingHttpServletRequest request, HttpCacheConfig cacheConfig) throws
                HttpCacheKeyCreationException {
            super(request, cacheConfig);
        }

        public AcceptAllCacheKey(String uri, HttpCacheConfig cacheConfig) throws HttpCacheKeyCreationException {
            super(uri, cacheConfig);
        }

        @Override
        public boolean equals(Object o) {
            if (o == null) {
                return false;
            }

            if (!super.equals(o)) {
                return false;
            }

            AcceptAllCacheKey that = (AcceptAllCacheKey) o;
            return new EqualsBuilder()
                    .append(getUri(), that.getUri())
                    .append(getAuthenticationRequirement(), that.getAuthenticationRequirement())
                    .isEquals();
        }

        @Override
        public int hashCode() {
            return new HashCodeBuilder(17, 37)
                    .append(getUri())
                    .append(getAuthenticationRequirement()).toHashCode();
        }

        @Override
        public String toString() {
            return getUri() + " [AUTH_REQ:" + getAuthenticationRequirement() + "]";

        }
    }

	

}