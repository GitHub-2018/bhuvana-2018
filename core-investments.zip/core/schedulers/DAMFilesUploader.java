/*
 * Copyright 2017 Cognizant Technology Solutions and John Hancock Investments (JHI)
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant Technology Solutions and JHINV, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with JHINV. 
 */
package com.jhi.aem.website.v1.core.schedulers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.admin.EmailService;
import com.jhi.aem.website.v1.core.service.filehandler.FileHandlerService;
import com.jhi.aem.website.v1.core.service.filehandler.impl.LocalFileHandlerImpl;
import com.jhi.aem.website.v1.core.service.osgi.OsgiConfigurationService;
import com.jhi.aem.website.v1.core.utils.DamUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;
import com.jhi.aem.website.v1.core.utils.TransferFile;

/**
 * DamFilesUploader class is used to read the files from the folder where the
 * basket and trade files are downloaded and upload to the DAM
 */

@Component(
		name = "JHI Website BSKT/TDH File Uploader",
		immediate = true,
		service = Runnable.class,
		configurationPid="com.jhi.aem.website.v1.core.schedulers.DAMFilesUploader",
        configurationPolicy= ConfigurationPolicy.REQUIRE,
		property= {
				Constants.SERVICE_DESCRIPTION+"=JHI Website DAM Files Uploader Scheduler"
				})

@Designate(ocd=DAMFilesUploader.Config.class)
public class DAMFilesUploader implements Runnable {

	private static final Logger LOG = LoggerFactory.getLogger(DAMFilesUploader.class);

	@ObjectClassDefinition(name="JHI Website BSKT/TDH File Uploader Configurations", description="Configurations for JHI Website BSKT/TDH File Uploader scheduler")
	public @interface Config{
		 
		public static final String DEFAULT_EXPRESSION ="0 50 21,07 ? * MON-FRI *" ;
		@AttributeDefinition(name = "Enabled", description = "Enable Scheduler", type = AttributeType.BOOLEAN)
		 boolean serviceEnabled() default true;
		
		@AttributeDefinition(name = "Concurrent", description = "Schedule task concurrently", type = AttributeType.BOOLEAN)
		 boolean schedulerConcurrent() default false;
		
		@AttributeDefinition(name = "Scheduler name", description = "Scheduler name", type = AttributeType.STRING)
		 public String schedulerName() default "JHI Website DAM files Uploader scheduler";
		
		@AttributeDefinition(name="Scheduler Expression", description ="Specify the scheduler expression as a quartz regex pattern")
		public String schedulerExpression() default DEFAULT_EXPRESSION;
	}
	
	private Scheduler scheduler;
	
	@Reference
	public void bindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	public void unbindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}

	
	private ResourceResolverFactory resourceResolverFactory;
	@Reference
	public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory=resourceResolverFactory;
	}
	public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory=resourceResolverFactory;
	}

	
	OsgiConfigurationService configService;
	@Reference
	public void bindOsgiConfigurationService (OsgiConfigurationService configService) {
		this.configService=configService;
	}
	public void unbindOsgiConfigurationService (OsgiConfigurationService configService) {
		this.configService=configService;
	}

	
	private Replicator replicator;
	@Reference
	public void bindReplicator(Replicator replicator) {
		this.replicator=replicator;
	}
	public void unbindReplicator(Replicator replicator) {
		this.replicator=replicator;
	}

	
	private EmailService emailService;
	@Reference
	public void bindEmailService(EmailService emailService) {
		this.emailService=emailService;
	}
	public void unbindEmailService(EmailService emailService) {
		this.emailService=emailService;
	}
	
	private int schedulerID;
	@Activate
	protected void activate(Config config) {
		schedulerID = config.schedulerName().hashCode();
	}
	
	@Modified
	protected void modified(Config config) {
		LOG.debug("Modified Scheduler **** " );
		removeScheduler();
		schedulerID = config.schedulerName().hashCode();
		LOG.debug("Scheduler ID is {}" , schedulerID);
		addScheduler(config);
	}
	
	@Deactivate
	protected void deactivate(Config config) {
		removeScheduler();
	}
	
	private void removeScheduler() {
		  LOG.debug("Removing Scheduler Job '{}'", schedulerID);
		  scheduler.unschedule(String.valueOf(schedulerID));
		 }
	
	private void addScheduler(Config config) {
		LOG.debug("Adding Scheduler **** " );
		  if (config.serviceEnabled()) {
		   ScheduleOptions sopts = scheduler.EXPR(config.schedulerExpression());
		   sopts.name(String.valueOf(schedulerID));
		   sopts.canRunConcurrently(config.schedulerConcurrent());
		   scheduler.schedule(this, sopts);
		   LOG.debug("JHI DAM File Upload Scheduler added succesfully");
		  } else {
		   LOG.debug("JHI DAM File Upload Scheduler, no scheduler job created");
		  }
		 }
	
	@Override
	public void run() {
		LOG.debug("Running Scheduler **** " );
		ResourceResolver resourceResolver = null;
		try {
			LOG.info("DAM File Upload Job");
			String bsktTimeStamp = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
					JhiConstants.BSKT_TIMESTAMP_PROPERTY, new String());
			String tdhTimeStamp = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
					JhiConstants.TDH_TIMESTAMP_PROPERTY, new String());
			LOG.info("Time Stamp to match BSKT file pull is {}" , bsktTimeStamp);

			// Get the business holidays from the configuration mentioned in
			// COFNIG_PID
			String[] businessHolidays = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
					JhiConstants.HOLIDAYS_PROPERTY, new String[0]);

			// Convert the business holidays for the year to the list
			List<String> nonWorkingDays = Arrays.asList(businessHolidays);

			resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
			if (resourceResolver != null) {
				Calendar todayCal = Calendar.getInstance();
				todayCal.setTime(new Date());
				String today = DamUtil.dateToString("MM/dd/yyyy", new Date());

				// Check
				// if the Non-Working days list contains today
				// if today is Saturday or Sunday
				boolean isHoliday = nonWorkingDays.contains(today)
						|| (todayCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)
						|| todayCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
				if (isHoliday) {
					LOG.debug(today + " is holiday and the job will not execute today. Thank you for your patience !!");
				}

				String systemTime = LocalDateTime.now().getHour() + JhiConstants.COLON
						+ LocalDateTime.now().getMinute();
				LOG.info("Current System time is {}" ,  systemTime);
				if (StringUtils.equals(systemTime, bsktTimeStamp)) {
					LOG.info("BSKT file time matches the System time");
					List<TransferFile> uploadFiles = new ArrayList<TransferFile>();
					LOG.debug("Uploading BSKT File");
					String bsktFileConfig = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
							JhiConstants.BSKT_FILE_CONFIG_PROPERTY, new String());
					if (bsktFileConfig != null) {
						uploadFiles.add(new TransferFile(bsktFileConfig, nonWorkingDays));
					}

					// If it is not a holiday , then upload the files to DAM
					// author
					if (!isHoliday) {
						uploadFile(resourceResolver, uploadFiles, JhiConstants.EVENING_GREETING);
					}

				}

				if (StringUtils.equals(systemTime, tdhTimeStamp)) {
					List<TransferFile> uploadFiles = new ArrayList<TransferFile>();
					LOG.debug("Uploading TDH File");
					String tdhFileConfig = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
							JhiConstants.TDH_FILE_CONFIG_PROPERTY, new String());
					if (tdhFileConfig != null) {
						uploadFiles.add(new TransferFile(tdhFileConfig, nonWorkingDays));
					}

					// If it is not a holiday , then upload the files to DAM
					// author
					if (!isHoliday) {
						uploadFile(resourceResolver, uploadFiles, JhiConstants.MORNING_GREETING);
					}

				}

				// GIT issue #1712 - Closing all open ResourceResolver objects
				// This can leave sessions open internally if not closed
				// You open it , you close it
				if (resourceResolver.isLive()) {
					resourceResolver.close();
				}
			}
		} catch (Exception e) {
			LOG.error("Error while uploading files ", e);
		} finally {
			if (resourceResolver != null && resourceResolver.isLive()) {
				resourceResolver.close();
			}
		}

	}

	private void uploadFile(ResourceResolver resourceResolver, List<TransferFile> uploadFiles,String greeting) {
		Map<String, String> failures = null;
		if (resourceResolver != null) {
			Session jcrSession = resourceResolver.adaptTo(Session.class);

			FileHandlerService fileHandler = new LocalFileHandlerImpl();
			failures = uploadFiles(fileHandler, resourceResolver, jcrSession, uploadFiles);
			fileHandler.close();
		}

		// inside each failure..........
		if (failures == null || failures.size() == 0) {
			LOG.info("File transfer task was successful.");
		} else {
			LOG.error("File transfer task failed.");
			sendErrorMail(failures, resourceResolver,greeting);
		}
	}

	private void sendErrorMail(Map<String, String> failure, ResourceResolver resourceResolver,String greeting) {
		LOG.debug("File transfer failed . Sending error mail .");
		try {
			Session session = resourceResolver.adaptTo(Session.class);

			LOG.debug("Session is {} .", session);
			// error email template
			String emailTemplatePath = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
					JhiConstants.EMAIL_TEMPLATE_PATH_PROPERTY, new String());

			LOG.debug("Email Template Path is {} .", emailTemplatePath);
			// populate the email props map
			Map<String, String> emailProps = new HashMap<String, String>();

			emailProps.put("fileNames", failure.keySet().toString());
			emailProps.put("greeting", greeting);

			// get to email addresses
			String[] toList = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
					JhiConstants.EMAIL_TO_LIST_PROPERTY, new String[0]);
			try {
				LOG.debug("Sending email with emailProps as {}", emailProps);
				emailService.sendEmail(session, emailTemplatePath, emailProps, toList, new String[0]);
			} catch (Exception e) {
				LOG.error("Error while sending the email ", e);
			}
		}
		catch (Exception e) {
            LOG.error("Exception while sending the mail " , e);
		}
	}

	/**
	 * @param fileHandler
	 * @param resourceResolver
	 * @param jcrSession
	 * @param uploadFiles
	 * @param success
	 * @return
	 * @throws Exception
	 */
	private Map<String, String> uploadFiles(FileHandlerService fileHandler, ResourceResolver resourceResolver,
			javax.jcr.Session jcrSession, List<TransferFile> uploadFiles) {
		Map<String, String> failures = new HashMap<String, String>();
		for (TransferFile file : uploadFiles) {
			try {
				copyFileToDAMWithReplicate(file, fileHandler, resourceResolver, jcrSession);
			} catch (Exception e) {
				failures.put(file.getName(), e.getMessage());
				LOG.error("Error Loading file ", e);
			}
		}
		if (failures.size() > 0) {
			LOG.error("FAILED UPLOADING FILES");
			for (Map.Entry<String, String> failure : failures.entrySet()) {
				LOG.error("{} could not be uploaded. The process exited with the following message - {}",
						failure.getKey(), failure.getValue());
			}
		}
		return failures;
	}

	private boolean copyFileToDAMWithReplicate(final TransferFile file, FileHandlerService fileHandler,
			ResourceResolver resourceResolver, Session jcrSession)
			throws IOException, RepositoryException, ReplicationException {
		Date today = new Date();
		LOG.debug("Today is **" + today);
		// 1. find if the file exists
		Set<String> names = file.getFileNameCombinations(today);
		LOG.debug("File name is " + names);

		String damRemoteDir = configService.getProperty(JhiConstants.DAM_FILE_UPLOAD_CONFIG_PID,
				JhiConstants.REMOTE_DIRECTORY_PROPERTY, new String());

		String foundFileName = null;
		for (String name : names) {
			LOG.debug("File name is " + name);
			if (fileHandler.fileExists(name, damRemoteDir)) {
				foundFileName = name;
				LOG.debug("Found File name is " + name);
				break;
			}
		}
		// 2.a If exists - copy the file to DAM and return true
		if (foundFileName != null) {
			InputStream is = fileHandler.getFile(foundFileName);
			// 2.a.1 Upload the file to DAM
			DamUtil.uploadFileToDAM(is, file.getOutputFilePath(), resourceResolver, jcrSession);
			// 2.a.2 Update the timestamp of the uploaded file in DAM
			DamUtil.updateMetadata(file.getOutputFilePath(), file.getOffsetCalculatedDate(new Date()), jcrSession);
			// 2.a.2 Replicate the file
			DamUtil.replicateFile(replicator, file.getOutputFilePath(), jcrSession);
			return true;
		} else {
			throw new FileNotFoundException("The file " + file.getName()
					+ " was not found at remote location. Expected any of the following file names "
					+ fileHandler.getAbsoluteFilePathInfo(file.getFileNameCombinations(today)));
		}
	}

}
