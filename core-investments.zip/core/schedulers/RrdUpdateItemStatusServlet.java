package com.jhi.aem.website.v1.core.schedulers;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.RrdService;


@Component(
		name="RRD Update Item status servlet",
		immediate=true,
		service=Servlet.class,
		property= {
				"sling.servlet.paths=/bin/jhi-website/rrdupdate.trigger",
				"sling.servlet.methods="+HttpConstants.METHOD_GET
		})

public class RrdUpdateItemStatusServlet extends SlingAllMethodsServlet {

    private static final long serialVersionUID = -862710631708065909L;

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }

    
    private RrdService rrdService;
    @Reference
    public void bindRrdService(RrdService rrdService) {
    	this.rrdService=rrdService;
    }
    public void unbindRrdService(RrdService rrdService) {
    	this.rrdService=rrdService;
    }

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException {
        final RrdUpdateItemStatusTask task = new RrdUpdateItemStatusTask();
        task.run(resolverFactory, rrdService);
    }
}
