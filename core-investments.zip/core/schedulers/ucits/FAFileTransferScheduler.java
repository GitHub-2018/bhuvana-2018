package com.jhi.aem.website.v1.core.schedulers.ucits;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jhi.aem.website.v1.core.service.admin.EmailService;
import com.jhi.aem.website.v1.core.service.ucits.SFTPConnection;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;
import com.jhi.aem.website.v1.core.utils.SftpUtil;

/**
 * This scheduler is written for Fund Assist File Transfer from SFTP
 * All the values of the scheduler are configured in the configs
 * 
 * @author vikrave
 * @version 1.0
 * @since 03/11/2019
 * 
 */
@Designate(ocd = FAFileTransferScheduler.Config.class)
@Component(immediate = true, service = Runnable.class)
public class FAFileTransferScheduler implements Runnable {
	

	private static final String YYYY_MM_DD__HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

	private static final Logger LOG = LoggerFactory.getLogger(FAFileTransferScheduler.class);

	@ObjectClassDefinition(name = "FA File Transfer Scheduler", description = "Configurations for FA FTP")
	public @interface Config {

		public static final String DEFAULT_EXPRESSION = "0 0 09 * * ?";

		@AttributeDefinition(name = "Enabled", description = "Enable Scheduler", type = AttributeType.BOOLEAN)
		boolean serviceEnabled() default true;

		@AttributeDefinition(name = "Concurrent", description = "Schedule task concurrently", type = AttributeType.BOOLEAN)
		boolean scheduler_concurrent() default false;

		@AttributeDefinition(name = "Scheduler name", description = "Scheduler name", type = AttributeType.STRING)
		public String schedulerName() default "JHI UCITS Fund Assist File Transefer Scheduler";

		@AttributeDefinition(name = "Scheduler Expression", description = "Specify the scheduler expression as a quartz regex pattern")
		public String scheduler_expression() default DEFAULT_EXPRESSION;

		@AttributeDefinition(name = "Host Name", description = "Host Name for the SFTP Server")
		String hostname() default "";

		@AttributeDefinition(name = "User Name", description = "User Name for the SFTP Server")
		String username() default "";

		@AttributeDefinition(name = "Password", description = "Password Name for the SFTP Server")
		String password() default "";

		@AttributeDefinition(name = "Directory", description = "Directory Name for the SFTP Server")
		String directory() default "";

		@AttributeDefinition(name = "Strict Host Key Checking", description = "Strict Host Key Checking for the SFTP Server")
		String strictHostKeyChecking() default "";

		@AttributeDefinition(name = "Dam path", description = "DAM Path to load files")
		String damPath() default "";

		@AttributeDefinition(name = "Default DAM Folder", description = "Default DAM folder")
		String defaultFolder();

		@AttributeDefinition(name = "Email Template Path", description = "Path for the notification template for the FTP Default File messages")
		String emailTemplatePath();

		@AttributeDefinition(name = "To Address", description = "List of email addresses or DL to which the mail should be sent")
		String[] toList();

		@AttributeDefinition(name = "CC Address", description = "List of email addresses or DL to which the mail should be sent as CC")
		String[] ccList();

		@AttributeDefinition(name = "Error Email Template Path", description = "Path for the notification template for the FTP Upload Failure messages")
		String errorTemplatePath();

		@AttributeDefinition(name = "Error To Address", description = "List of email addresses or DL to which the mail should be sent if the upload fails")
		String[] errorToList();

		@AttributeDefinition(name = "Error CC Address", description = "List of email addresses or DL to which the mail should be sent as CC if upload fails")
		String[] errorCcList();

		@AttributeDefinition(name = "Start Date", description = "Start Date to look for files in EEE MMM dd HH:mm:ss zzz yyyy format eg:- Tue Feb 12 11:44:21 EST 2018")
		String startDate();

		@AttributeDefinition(name = "Initial Pull", description = "If set true it will take the startDate in config to run the pull")
		boolean isInitialRun();

		@AttributeDefinition(name = "Last Successful Run", description = "Node in which Last Successful Run value will be set")
		String setNode();
	}

	@Reference
	ResourceResolverFactory resourceResolverFactory;

	@Reference
	EmailService emailService;

	@Reference
	private SFTPConnection sftpConnection;

	@Reference
	private Scheduler scheduler;

	private int schedulerID;

	private String username;
	private String hostname;
	private String password;
	private String strictHostKeyChecking;
	private String directory;

	private String damPath;

	private String emailTemplatePath;

	private String[] toList;

	private String[] ccList;

	private String defaultFolder;

	private String[] errorToList;

	private String[] errorCcList;

	private String errorTemplatePath;

	private String startDate;

	private boolean isInitialRun;

	private String startSetNode;


	@Activate
	protected void activate(Config config) {
		LOG.debug("Scheduler Activated");
		LOG.info("FTA File Transfer scheduler activated");
		addConfigs(config);
	}

	@Modified
	protected void modified(Config config) {
		LOG.debug("Scheduler Modified ");
		LOG.info("FTA File Transfer scheduler modified");
		addConfigs(config);
	}

	@Deactivate
	protected void deactivate(Config config) {
		removeScheduler();
	}

	private void removeScheduler() {
		LOG.debug("Removing Scheduler Job '{}'", schedulerID);
		scheduler.unschedule(String.valueOf(schedulerID));
	}

	private void addConfigs(Config config) {
		username = config.username();
		hostname = config.hostname();
		password = config.password();
		strictHostKeyChecking = config.strictHostKeyChecking();
		directory = config.directory();
		damPath = config.damPath();
		emailTemplatePath = config.emailTemplatePath();
		toList = config.toList();
		ccList = config.ccList();
		defaultFolder = config.defaultFolder();
		errorTemplatePath = config.errorTemplatePath();
		errorToList = config.errorToList();
		errorCcList = config.errorCcList();
		startDate = config.startDate();
		isInitialRun = config.isInitialRun();
		startSetNode = config.setNode();
	}

	@Override
	public void run() {
		LocalDateTime start = null;
		List<String> filePaths = new ArrayList<>();
		ResourceResolver resolver = null;
		try {
			//Get a resource resolver to upload the files to DAM.
			//You open it ; you close it
			resolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
			Channel channel = sftpConnection.getChannelConnection(hostname, username, password, strictHostKeyChecking);
			boolean isSuccess = false; //This should be set true if all the files are uploaded successfully
			boolean noFileUploaded = true; //This flag is used to track if no files wer uploaded at all to DAM
			HashMap<String, Boolean> flags = new HashMap<>();
			if (channel != null) {
				ChannelSftp sftpChannel = sftpConnection.getSftpChannel(channel);

				if (sftpChannel != null) {

					if (isInitialRun) {
						LOG.debug("Is Initial Run");
						//If the initialRun value is true , then take the startDate form the cofig
						start = SftpUtil.getDate(startDate, YYYY_MM_DD__HH_MM_SS);
					} else {
						LOG.debug("Is not initial run");
						//Otherwise , take the value from the node.
						start = getDateFromNode(resolver);
					}
					LOG.debug("Start date is {}", start);

					synchronized (this) {
						flags = sftpConnection.uploadToDamModifiedAfter(sftpChannel, directory, "*", start, damPath,
								defaultFolder, filePaths, false, true);
					}
					LOG.debug("No file found flag is {} outside", noFileUploaded);
					LOG.debug("Is Success found flag is {} outside", isSuccess);
					LOG.debug("Closing connection");
					sftpConnection.closeConnection(channel, null, sftpChannel);
				} else {
					LOG.info("No Valid SFTP Connection");
				}
			}

			setStartDate(resolver, YYYY_MM_DD__HH_MM_SS);

			// After the execution send mail to business
			sendMails(start, filePaths, resolver, flags.get("isDefaultFolder"), flags.get("noFileUploaded"));
		} catch (Exception exception) {
			LOG.error("Error while sending Email", exception);
			Map<String, String[]> params = new HashMap<>();
			String[] message = { "FA File Transfer failed due to some error." };
			params.put("message", message);

			// On failure of FTP upload send mail to DEV Team to let them know that
			// the upload job failed
			sendMail(params, resolver, errorToList, errorCcList, errorTemplatePath);
		} finally {
			if (resolver != null && resolver.isLive()) {
				resolver.close();
			}
		}
	}

	/**
	 * Method send mail in below scenarios 
	 * <br>
	 * If no file is uploaded to the DAM
	 * <br>
	 * If files are uploaded to default folder. Files are uploaded to default folder 
	 * only when the same is not available in the DAM already. Except for initial run (config = initialRun (true))
	 * files will be uploaded to the path already in the DAM
	 * 
	 * @param start
	 * @param filePaths
	 * @param resolver
	 * @param isDefault
	 * @param noFileUploaded
	 * @throws PersistenceException
	 */
	private void sendMails(LocalDateTime start, List<String> filePaths, ResourceResolver resolver, boolean isDefault,
			boolean noFileUploaded) throws PersistenceException {
		LOG.debug("Sending mail ******");
		LOG.debug("Flag isSuccess is {}", isDefault);
		LOG.debug("Flag noFileupload is {}", noFileUploaded);
		if (noFileUploaded) {
			LOG.debug("No file uploded to DAM {} ", noFileUploaded);
			Map<String, String[]> params = new HashMap<>();
			String[] message = {
					"No Modified files available which was modified after " + start + " to upload to DAM . " };

			params.put("message", message);
			sendMail(params, resolver, toList, ccList, errorTemplatePath);
		} else if (isDefault) {
			LOG.debug("Upload is success and files are uploaded ");
			Map<String, String[]> params = new HashMap<>();
			params.put("filenames", filePaths.toArray(new String[filePaths.size()]));
			sendMail(params, resolver, toList, ccList, emailTemplatePath);
			
		}
	}
	
	/**
	 * After every successful execution , start date is set on a node mentioned in startNode(config)
	 * @param resolver
	 * @param pattern
	 * @throws PersistenceException
	 */
	private void setStartDate(ResourceResolver resolver, String pattern) throws PersistenceException {
		// Once the scheduler pulls all files successfully set the current time to the
		// node
		LOG.debug("Setting {} as next pull start date to {} node",
				SftpUtil.getDateString(LocalDateTime.now(), pattern), startSetNode);
		Resource startRes = resolver.getResource(startSetNode);
		if (startRes != null) {
			ModifiableValueMap map = startRes.adaptTo(ModifiableValueMap.class);
			if (map != null) {
				map.put("startDate", SftpUtil.getDateString(LocalDateTime.now(), pattern));
				resolver.commit();
				LOG.debug("start date set successfully to {}", startSetNode);
			}
		}
	}

	/**
	 * This method will retrieve the last successful run date of the scheduler
	 * from the node where the value is saved. The value gets saved to the node which is 
	 * mentioned in setNode config
	 * 
	 * If the value is empty or null , it will take the value from startNode config
	 * @param resolver
	 * @return
	 */
	private LocalDateTime getDateFromNode(ResourceResolver resolver) {
		LocalDateTime start = null;
		Resource startRes = resolver.getResource(startSetNode);

		LOG.debug("The resource for start set node is {}", startRes);

		if (startRes != null) {
			String startDateValue = startRes.getValueMap().get("startDate", String.class);
			LOG.debug("Start date value from the node is {}", startDateValue);
			if (StringUtils.isNotEmpty(startDateValue)) {
				start = SftpUtil.getDate(startDateValue, YYYY_MM_DD__HH_MM_SS);
			}else {
			// if no startDate is present in the node, we will take the start date from the
			// config
			start = SftpUtil.getDate(startDate, YYYY_MM_DD__HH_MM_SS);
			}
		}
		LOG.debug("Start date being set is {}", start);
		return start;
	}

	/**
	 * Method will send mail to the addresses with the params
	 * @param params
	 * @param resourceResolver
	 * @param toAddress
	 * @param ccAddress
	 * @param templatePath
	 */
	private void sendMail(Map<String, String[]> params, ResourceResolver resourceResolver, String[] toAddress,
			String[] ccAddress, String templatePath) {
		LOG.debug("Sending Mail ....... .");
		if (resourceResolver != null) {
			try {
				Session session = resourceResolver.adaptTo(Session.class);

				LOG.debug("Session is {} .", session);

				LOG.debug("Email Template Path is {} .", templatePath);
				// populate the email props map
				Map<String, String> emailProps = new HashMap<>();

				if (params != null) {

					if (params.get("filenames") != null) {
						emailProps.put("fileNames", String.join("\r\n", params.get("filenames")));
					}

					if (params.get("message") != null) {
						emailProps.put("message", String.join("\r\n", params.get("message")));
					}

				}

				String defaultPath = damPath + "/" + defaultFolder;
				if (StringUtils.isEmpty(defaultFolder)) {
					defaultPath = damPath;
				}
				emailProps.put("defaultpath", defaultPath);

				LOG.debug("Sending email with emailProps as {}", emailProps);
				emailService.sendEmail(session, templatePath, emailProps, toAddress, ccAddress);

			} catch (Exception e) {
				LOG.error("Exception while sending the mail ", e);
			}
		} else {
			LOG.info("Resource Resolver returned {} ", resourceResolver);
		}
	}

}
