package com.jhi.aem.website.v1.core.schedulers;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.Externalizer;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductScheduledActivationServiceImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.schedulers.DAMFilesUploader.Config;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Component(
		name="Page Thumbnail Generation Task",
		service = Runnable.class,
		configurationPid="com.jhi.aem.website.v1.core.schedulers.PageThumbnailGenerationTask",
		immediate = true
		)

@Designate(ocd=PageThumbnailGenerationTask.Config.class)
public class PageThumbnailGenerationTask implements Runnable {
	
    private final Logger LOG = LoggerFactory.getLogger(PageThumbnailGenerationTask.class);

    @ObjectClassDefinition(name="Page Thumbnail Generations Configuration",description="Configrations for Page Thumnail generation scheduler")
    public @interface Config{
    	 	
    	static final String SCHEDULER_EXPERSSION = "0 30 2 ? * *";
		@AttributeDefinition(name = "Enabled", description = "Enable Scheduler", type = AttributeType.BOOLEAN)
		 boolean serviceEnabled() default true;
		
		@AttributeDefinition(name = "Concurrent", description = "Schedule task concurrently", type = AttributeType.BOOLEAN)
		 boolean schedulerConcurrent() default false;
		
		@AttributeDefinition(name = "Scheduler name", description = "Scheduler name", type = AttributeType.STRING)
		 public String schedulerName() default "JHI Page thumbnail generation scheduler";
		
		@AttributeDefinition(name="Scheduler Expression", description ="Specify the scheduler expression as a quartz regex pattern")
		public String schedulerExpression() default SCHEDULER_EXPERSSION;
    	
    }
    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory)
    {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory)
    {
    	this.resolverFactory=resolverFactory;
    }

	private Resource currentResource;


	public void run(Resource currentResource, ResourceResolverFactory resolverFactory) {
        this.currentResource = currentResource;
		this.resolverFactory = resolverFactory;
        this.run();
    }
	
	private Scheduler scheduler;
	
	@Reference
	public void bindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	public void unbindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	
	private int schedulerID;
	@Activate
	protected void activate(Config config) {
		schedulerID = config.schedulerName().hashCode();
	}
	
	@Modified
	protected void modified(Config config) {
		removeScheduler();
		schedulerID = config.schedulerName().hashCode();
		addScheduler(config);
	}
	
	@Deactivate
	protected void deactivate(Config config) {
		removeScheduler();
	}
	
	private void removeScheduler() {
		  LOG.debug("Removing Scheduler Job '{}'", schedulerID);
		  scheduler.unschedule(String.valueOf(schedulerID));
		 }
	
	private void addScheduler(Config config) {
		  if (config.serviceEnabled()) {
		   ScheduleOptions sopts = scheduler.EXPR(config.schedulerExpression());
		   sopts.name(String.valueOf(schedulerID));
		   sopts.canRunConcurrently(config.schedulerConcurrent());
		   scheduler.schedule(this, sopts);
		   LOG.debug("Page Thumbnail Generation scheduler added succesfully");
		  } else {
		   LOG.debug("Page Thumbnail Generation scheduler, no scheduler job created");
		  }
		 }
	

    @Override
    public void run() {
        LOG.info("Starting pages thumbnails generation");

        ResourceResolver resolver = null;
        try {
            resolver = resolverFactory.getServiceResourceResolver(
                    Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));
            final Externalizer externalizer = resolver.adaptTo(Externalizer.class);

            List<Page> rootPages = PageUtil.getAllPagesByResourceType(resolver, JhiConstants.WEBSITE_LOGIN_PATH, ResourcesConstants.HOME_PAGE_RESOURCE_TYPE);
            for (Page rootPage : rootPages) {
                generateThumbnails(resolver, externalizer, rootPage);
            }
        } catch (LoginException e) {
            throw new RuntimeException("Could not access service resource resolver", e);
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException("Error generating thumbnails", e);
        } finally {
            if (resolver != null) {
                resolver.close();
            }
        }

        LOG.info("Thumbnails generation finished");
    }

    private void generateThumbnails(ResourceResolver resolver, Externalizer externalizer, Page parentPage)
            throws IOException, InterruptedException {
        generateThumbnail(resolver, externalizer, parentPage);

        Iterator<Page> iterator = parentPage.listChildren();
        while (iterator.hasNext()) {
            generateThumbnails(resolver, externalizer, iterator.next());
        }
    }

    private void generateThumbnail(ResourceResolver resolver, Externalizer externalizer, Page page)
            throws IOException, InterruptedException {
        LOG.debug("Checking page " + page.getPath());

        final Resource contentResource = page.getContentResource();
        if (contentResource == null) {
            return;
        }

        if (!isViewpointPage(page)) {
            return;
        }

        final ViewpointDetailModel model = ViewpointDetailModel.fromPage(page);
        if (model == null || !model.isValid()) {
            return;
        }
        InputStream is = null;
        try {
        	is = getImageStream(resolver, model.getImagePath());
	        if (is == null) {
	            return;
	        }
	
	        LOG.debug("Creating thumbnail for '{}'", page.getPath());
	
	        final Resource oldImageResource = contentResource.getChild("image");
	        if (oldImageResource != null) {
	            resolver.delete(oldImageResource);
	        }
	
	        final Map<String, Object> imageProps = new HashMap<>();
	        imageProps.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
	        final Resource imageResource = resolver.create(contentResource, "image", imageProps);
	
	        final Map<String, Object> fileProps = new HashMap<>();
	        fileProps.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_FILE);
	        final Resource fileResource = resolver.create(imageResource, "file", fileProps);
	
	        final Map<String, Object> fileContentProps = new HashMap<>();
	        fileContentProps.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_RESOURCE);
	        fileContentProps.put(JcrConstants.JCR_MIMETYPE, "image/png");
	        fileContentProps.put(JcrConstants.JCR_DATA, is);
	        resolver.create(fileResource, JcrConstants.JCR_CONTENT, fileContentProps);
	
	        resolver.commit();
	
        } catch (IOException e) {
            LOG.error("Problem while closing image input stream", e);
        } finally {
        	IOUtils.closeQuietly(is);
        }

        LOG.debug("Thumbnail for " + page.getPath() + " created.");
    }

    private InputStream getImageStream(ResourceResolver resolver, String path) {
	    if(StringUtils.isBlank(path) || path.startsWith("http")) {
	        LOG.debug("path is not set or it is external: {}", path);
	        return null;
        }
        Resource renditionResource = resolver.getResource(path);
        if (renditionResource == null) {
            LOG.debug("rendition resource is null");
            return null;
        }

        InputStream is = renditionResource.adaptTo(InputStream.class);
        if (is == null) {
            Asset asset = renditionResource.adaptTo(Asset.class);
            if (asset != null) {
                return asset.getOriginal().getStream();
            }
        }

        return is;
    }

    private boolean isViewpointPage(Page page) {
        return PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_PAGE_RESOURCE_TYPE)
                || PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_ARTICLE_PAGE_RESOURCE_TYPE)
                || PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_AUDIO_PAGE_RESOURCE_TYPE)
                || PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_DOCUMENT_PAGE_RESOURCE_TYPE)
                || PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_VIDEO_PAGE_RESOURCE_TYPE);
    }
}
