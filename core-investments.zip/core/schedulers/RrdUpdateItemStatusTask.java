package com.jhi.aem.website.v1.core.schedulers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.Product;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdException;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdItemStatus;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.models.CheckItemStatusResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductScheduledActivationServiceImpl.Config;
import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.RrdService;
import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.impl.RrdServiceImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Component(
		name="RRD Update Item Status Task - JHI Website",
		service = Runnable.class,
		configurationPid="com.jhi.aem.website.v1.core.schedulers.RrdUpdateItemStatusTask",
		immediate = true
		)

@Designate(ocd=RrdUpdateItemStatusTask.Config.class)
public class RrdUpdateItemStatusTask implements Runnable {

    private final Logger LOG = LoggerFactory.getLogger(RrdUpdateItemStatusTask.class);

    
    
    @ObjectClassDefinition(name="RRD Update item status task Configuration for JHI website",description="Configrations for RRD Update item status task scheduler")
    public @interface Config{
    	static final String SCHEDULER_EXPERSSION  ="0 30 1 ? * *";
    	
    	@AttributeDefinition(name = "Enabled", description = "Enable Scheduler", type = AttributeType.BOOLEAN)
		 boolean serviceEnabled() default true;
		
		@AttributeDefinition(name = "Concurrent", description = "Schedule task concurrently", type = AttributeType.BOOLEAN)
		 boolean schedulerConcurrent() default false;
		
		@AttributeDefinition(name = "Scheduler name", description = "Scheduler name", type = AttributeType.STRING)
		 public String schedulerName() default "JHI Website RRD Update item status task";
		
		@AttributeDefinition(name="Scheduler Expression", description ="Specify the scheduler expression as a quartz regex pattern")
		 public String schedulerExpression() default SCHEDULER_EXPERSSION;
    	
    }
    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }

    
    private RrdService rrdService;
    @Reference
    public void bindRrdService(RrdService rrdService) {
    	this.rrdService=rrdService;
    }
    public void unbindRrdService(RrdService rrdService) {
    	this.rrdService=rrdService;
    }

    public void run(ResourceResolverFactory resolverFactory, RrdService rrdService) {
        this.resolverFactory = resolverFactory;
        this.rrdService = rrdService;
        this.run();
    }

private Scheduler scheduler;
	
	@Reference
	public void bindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	public void unbindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	
    private int schedulerID;
	@Activate
	protected void activate(Config config) {
		schedulerID = config.schedulerName().hashCode();
	}
	
	@Modified
	protected void modified(Config config) {
		removeScheduler();
		schedulerID = config.schedulerName().hashCode();
		addScheduler(config);
	}
	
	@Deactivate
	protected void deactivate(Config config) {
		removeScheduler();
	}
	
	private void removeScheduler() {
		LOG.debug("Removing Scheduler Job '{}'", schedulerID);
		  scheduler.unschedule(String.valueOf(schedulerID));
		 }
	
	private void addScheduler(Config config) {
		  if (config.serviceEnabled()) {
		   ScheduleOptions sopts = scheduler.EXPR(config.schedulerExpression());
		   sopts.name(String.valueOf(schedulerID));
		   sopts.canRunConcurrently(config.schedulerConcurrent());
		   scheduler.schedule(this, sopts);
		   LOG.debug("JHI RRD Update item status task scheduler added succesfully");
		  } else {
			  LOG.debug("RRD Update item status task Scheduler, no scheduler job created");
		  }
		 }
	
	
    @Override
    public void run() {
        LOG.info("Starting RRD update item status");

        ResourceResolver resolver = ResourceResolverUtil.getResourceResolver(resolverFactory);
        if (resolver == null) {
            LOG.error("Could not access service resource resolver");
            return;
        }

        try {
            final Resource rootResource = resolver.getResource(JhiConstants.RRD_PRODUCTS_ROOT);
            final List<Resource> productResources = gatherResources(rootResource);

            for (Resource productResource : productResources) {
                final RrdProductImpl product = new RrdProductImpl(productResource);
                try {
                    final CheckItemStatusResponse response = rrdService.checkItemStatus(product.getCode());
                    if (response != null) {
                        final String newStatus = response.getItemStatus();
                        final String oldStatus = product.getItemStatus();

                        if (response.getJhItemNumber().equals(product.getCode())) {
                            if (StringUtils.isNotBlank(newStatus) && !newStatus.equals(oldStatus)) {
                                updateItemStatus(resolver, product, newStatus);
                            }
                        } else if (RrdServiceImpl.ITEM_NOT_FOUND_RESPONSE.equals(response.getJhItemNumber())
                                && !StringUtils.equals(oldStatus, RrdItemStatus.NOT_FOUND.name())) {
                            updateItemStatus(resolver, product, RrdItemStatus.NOT_FOUND.name());
                        }
                    }
                } catch (RrdException e) {
                    LOG.error("Error checking item status: " + product.getSKU(), e);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error updating items statuses", e);
        } finally {
            resolver.close();
        }
        LOG.info("RRD update item status finished");
    }

    private void updateItemStatus(ResourceResolver resolver, RrdProductImpl product, String newStatus) throws PersistenceException {
        final ModifiableValueMap props = product.adaptTo(ModifiableValueMap.class);
        if (props != null) {
            props.put(RrdProductImpl.ITEM_STATUS, newStatus);
            resolver.commit();
        } else {
            LOG.error("Cannot obtain product properties " + product.getCode());
        }
    }

    private List<Resource> gatherResources(Resource rootResource) {
        if (rootResource == null) {
            return Collections.emptyList();
        }
        final List<Resource> result = new ArrayList<>();
        for (Resource resource : rootResource.getChildren()) {
            if (resource.isResourceType(Product.RESOURCE_TYPE_PRODUCT)) {
                result.add(resource);
            } else if (resource.isResourceType(JcrResourceConstants.NT_SLING_FOLDER)
                    || resource.isResourceType(JcrResourceConstants.NT_SLING_ORDERED_FOLDER)) {
                result.addAll(gatherResources(resource));
            }
        }
        return result;
    }
}
