package com.jhi.aem.website.v1.core.schedulers;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(
		name="Page Thumbnail Generation Servlet",
		immediate=true,
		service=Servlet.class,
		property= {
				"sling.servlet.paths=/bin/jhi-website/thumbnails.trigger",
				"sling.servlet.methods="+HttpConstants.METHOD_GET
		})

public class PageThumbnailGenerationServlet extends SlingAllMethodsServlet {

    private static final long serialVersionUID = 3722329562516376656L;
    private static final Logger LOG = LoggerFactory.getLogger(PageThumbnailGenerationServlet.class);

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException {
        PageThumbnailGenerationTask task = new PageThumbnailGenerationTask();
        task.run(request.getResource(), resolverFactory);
    }
}
