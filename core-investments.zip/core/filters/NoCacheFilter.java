package com.jhi.aem.website.v1.core.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpHeaders;
import org.apache.sling.engine.EngineConstants;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Component(
		name="JHI Website No cache filter",
		service=Filter.class,
		immediate=true,
		property= {
				EngineConstants.SLING_FILTER_SCOPE + "=" + EngineConstants.FILTER_SCOPE_REQUEST,
				Constants.SERVICE_RANKING+":Integer=1",
				EngineConstants.SLING_FILTER_PATTERN+"="+NoCacheFilter.FILTER_PATTERN
		})
public class NoCacheFilter implements Filter {
    public static final String FILTER_PATTERN = JhiConstants.CONTENT_ROOT + ".*\\.nocache.*";

    private static final String CACHE_CONTOL_VALUE = "no-cache, no-store, must-revalidate";
    private static final String PRAGMA_VALUE = "no-cache";
    private static final String EXPIRES_VALUE = "0";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        if (httpResponse != null) {
            httpResponse.setHeader(HttpHeaders.CACHE_CONTROL, CACHE_CONTOL_VALUE);
            httpResponse.setHeader(HttpHeaders.PRAGMA, PRAGMA_VALUE);
            httpResponse.setHeader(HttpHeaders.EXPIRES, EXPIRES_VALUE);
        }
        filterChain.doFilter(request, httpResponse);
    }

    @Override
    public void init(FilterConfig filterConfig) {
    }

    @Override
    public void destroy() {
    }
}