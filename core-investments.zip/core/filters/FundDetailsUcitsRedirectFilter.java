package com.jhi.aem.website.v1.core.filters;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.commons.collections4.map.PassiveExpiringMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.engine.EngineConstants;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Component(
		name="JHI Website Fund Details UCITS redirect filter",
		service=Filter.class,
		immediate=true,
		property= {
				EngineConstants.SLING_FILTER_SCOPE + "=" + EngineConstants.FILTER_SCOPE_REQUEST,
				Constants.SERVICE_RANKING + ":Integer=100",
				"sling.filter.resourceTypes=" + ResourcesConstants.FUND_DETAILS_PAGE_RESOURCE_TYPE
		})
public class FundDetailsUcitsRedirectFilter implements Filter {
	private static final Logger LOG = LoggerFactory.getLogger(FundDetailsUcitsRedirectFilter.class);
	private Map<String,String> investmentsPageByHomePage = new PassiveExpiringMap<>(JhiConstants.DEFAULT_FUND_CACHE_VALUE);
	private Map<String,Boolean> tagAndCountryValid = new PassiveExpiringMap<>(JhiConstants.DEFAULT_FUND_CACHE_VALUE);

    @Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest)request;
    	final boolean isUcits = PageUtil.isInUcitsSite(slingRequest.getResource());
		final String countryFilterParameter = PageUtil.getUcitsCountry(slingRequest);
		final ResourceResolver resourceResolver = slingRequest.getResourceResolver();
    	boolean doRedirect = false;

    	if (isUcits) {
    		final Page page = slingRequest.getResource().adaptTo(Page.class);
    		
    		if (page != null) {
    			final Resource contentResource = page.getContentResource();
    			
    			// Must be the proper resource type for the fund details page
    			// (the sling filter thing at the top does not work hence this check)
    			if (StringUtils.equals(contentResource.getResourceType(), ResourcesConstants.FUND_DETAILS_PAGE_RESOURCE_TYPE)) {
		
		    		if (StringUtils.isEmpty(countryFilterParameter)) {
		    			LOG.warn("No country passed in, redirecting");
		    			doRedirect = true;
		    		} else {
		    			// Check the fund class is available for this fund
		    			final Tag shareClassTag = FundUtil.getTagFromSuffix(slingRequest);
		
		    	        if (shareClassTag != null) {
		    	        	String tagAndCountryKey = shareClassTag.getPath() + "-" + countryFilterParameter;
		
		    	        	if (!tagAndCountryValid.containsKey(tagAndCountryKey)) {
		    	        		tagAndCountryValid.put(tagAndCountryKey,
		    	        				isFundValidForCountry(resourceResolver, page, isUcits, countryFilterParameter, shareClassTag));
		    	        	}
		
		    	        	Boolean validResult = tagAndCountryValid.get(tagAndCountryKey);
			        		doRedirect = validResult == null || !validResult;
		    	        } else {
		    	        	doRedirect = true;
		    	        }
		    		}
    			}
    		}
    	}

    	if (doRedirect) {
			Page homePage = PageUtil.getHomePage(slingRequest.getResource());
			
			if (!investmentsPageByHomePage.containsKey(homePage.getPath())) {
        		Page investmentsPage = PageUtil.getPageByResourceType(
        				resourceResolver, homePage.getPath(), ResourcesConstants.INVESTMENTS_PAGE_RESOURCE_TYPE);

        		if (investmentsPage != null) {
        			investmentsPageByHomePage.put(homePage.getPath(), investmentsPage.getPath());
        		} else {
        			investmentsPageByHomePage.put(homePage.getPath(), StringUtils.EMPTY);
        		}
			}

			String redirectPage = investmentsPageByHomePage.get(homePage.getPath());
			if (StringUtils.isEmpty(redirectPage)) {
				// Redirect to home page if investments page is empty
				redirectPage = homePage.getPath();
				LOG.warn("No investments page found for home page {}", homePage.getPath());
			}

			// Redirect with the country at the end
			if (LOG.isDebugEnabled()) {
				LOG.debug("Redirecting because share class page {} does not exist for country {}",
						new Object[] {slingRequest.getRequestPathInfo().getResourcePath(),
						slingRequest.getRequestPathInfo().getSuffix(), countryFilterParameter});
			}

			((SlingHttpServletResponse)response).setHeader("X-Redirect-Reason", "No-Shareclass-Country-Match");
			((SlingHttpServletResponse)response).sendRedirect(LinkUtil.getLink(resourceResolver, redirectPage)
					+ "/" + StringUtils.defaultString(countryFilterParameter) + 
					"?" + JhiConstants.UCITS_COUNTRY_PARAMETER + "=" + countryFilterParameter);
    	} else {
    		// Continue with the request
    		chain.doFilter(slingRequest, response);
    	}
	}

    private boolean isFundValidForCountry(final ResourceResolver resourceResolver, final Page page, final boolean isUcits,
			final String countryFilterParameter, final Tag shareClassTag) {
		ValueMap tagValues = shareClassTag.adaptTo(Resource.class).getValueMap();
		String[] countries = tagValues.get(JhiConstants.UCITS_COUNTRIES, ArrayUtils.EMPTY_STRING_ARRAY);
		return Arrays.stream(countries).anyMatch(country -> StringUtils.equalsIgnoreCase(countryFilterParameter, country));
	}

    @Override
	public void init(FilterConfig filterConfig) throws ServletException {
    	LOG.info("Initialised filter");
	}

	@Override
	public void destroy() {
    	LOG.info("Destroyed filter");
	}

}
