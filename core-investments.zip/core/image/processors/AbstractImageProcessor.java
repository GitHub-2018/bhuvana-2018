package com.jhi.aem.website.v1.core.image.processors;

import java.awt.Dimension;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.im4java.core.IM4JavaException;
import org.im4java.core.IMOperation;
import org.im4java.core.ImageMagickCmd;
import org.im4java.process.Pipe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

public abstract class AbstractImageProcessor implements ImageProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractImageProcessor.class);
    protected static final String OVERLAYS_ROOT = "/etc.clientlibs/jhi-website-v1/clientlibs/clientlib-site/resources/overlays";

    protected final File tempDirectory;
    private final Map<String,ResourceOnDisk> diskResources = new HashMap<>();
	private String imageMagickBinDir;


    private class ResourceOnDisk {
    	private final File file;
    	private final long lastModified;
    	private final Dimension dimensions;
    	
    	ResourceOnDisk(File file, long lastModified) {
    		this.file = file;
    		this.lastModified = lastModified;    		
    		this.dimensions = getImageDimensions(file);
    	}

		public File getFile() {
			return file;
		}

		public long getLastModified() {
			return lastModified;
		}

		public Dimension getDimensions() {
			return dimensions;
		}
    }
    
    protected AbstractImageProcessor(String imageMagickBinDir, String tempDirectory) {
        super();
		this.imageMagickBinDir = imageMagickBinDir;
        this.tempDirectory = new File(tempDirectory);
        if (!this.tempDirectory.isDirectory()) {
        	throw new RuntimeException("Temp directory does not exist as a readable directory: " + tempDirectory);
        }
    }

    private Dimension getImageDimensions(File file) {
		String stdin =
				execImageMagickCommand(new String[] {imageMagickBinDir + "/convert", file.getAbsolutePath(), "-print", "%w,%h", "/dev/null"});

		String[] splitStdin = StringUtils.split(stdin, ",");
		if (splitStdin.length != 2) {
			throw new RuntimeException("Could not get dimensions for image " + file.getAbsolutePath() + ": " + stdin);
		}

		try {
			return new Dimension(Integer.parseInt(splitStdin[0]), Integer.parseInt(splitStdin[1]));
		} catch (NumberFormatException e) {
			LOG.error("Could not get image dimensions from: '{}'", splitStdin);
			throw e;
		}
    }

    private String execImageMagickCommand(String[] cmdArray) {

		try {
			// Execute
//			String[] cmdArray = new String[] {IMAGE_MAGICK_LOCATION, imageFile.getAbsolutePath(),
//					"-resize", "36!x36!", "-quality", "90", outputFile.getAbsolutePath()};
			Process p = Runtime.getRuntime().exec(cmdArray);

			// Read
			String stdin = readLines(p.getInputStream());
			String stderr = readLines(p.getErrorStream());

			// Wait for process
			int returnValue = p.waitFor();

			if (returnValue != 0) {
				LOG.error("Could not run ImageMagick command '{}', it returned: {}\n{}",
						new Object[] {StringUtils.join(cmdArray, " "), stdin, stderr});
				throw new RuntimeException("Could not run ImageMagick command");
			}
			
			return stdin;
		} catch (IOException | InterruptedException e) {
			LOG.error("Could not run ImageMagick command '{}'", StringUtils.join(cmdArray, " "), e);
			throw new RuntimeException("Could not run ImageMagick command");
		}
    }

	String readLines(InputStream stream) throws IOException {
		try {
			return IOUtils.toString(stream);
		} finally {
			IOUtils.closeQuietly(stream);
		}
	}

	private synchronized ResourceOnDisk getResourceOnDisk(Resource resource) throws IOException {
		String resourcePath = resource.getPath();
		Resource resourceJcrContent = resource.getChild(JcrConstants.JCR_CONTENT);
		Calendar nodeLastModified = resourceJcrContent.getValueMap().get(JcrConstants.JCR_LASTMODIFIED, Calendar.class);
		boolean refreshResource = false;

		ResourceOnDisk resourceOnDisk = diskResources.get(resourcePath);
		if (resourceOnDisk != null) {
			// Check last modified
			if (nodeLastModified.getTimeInMillis() > resourceOnDisk.getLastModified()) {
				refreshResource = true;
			}
		} else {
			refreshResource = true;
		}

		if (refreshResource) {
			LOG.debug("Refreshing disk resource {}", resourcePath);
			File resultPath = streamToDiskTempFile(resourcePath, resourceJcrContent.adaptTo(InputStream.class));
	        resourceOnDisk = new ResourceOnDisk(resultPath, nodeLastModified.getTimeInMillis());
	        diskResources.put(resourcePath, resourceOnDisk);
		}

		return resourceOnDisk;
    }

	private File streamToDiskTempFile(String resourcePath, InputStream resourceStream)
			throws IOException, FileNotFoundException {
		// Create a temp file for the resource
		File resultPath;
		try {
			resultPath =
				File.createTempFile(
						StringUtils.substring(StringUtils.substringBeforeLast(resourcePath, "."), 0, 3),
						"." + StringUtils.substringAfterLast(resourcePath, "."),
						tempDirectory);
		} catch (IOException e) {
			throw new RuntimeException("Could not create a temp file", e);
		}

		// Clean up after VM exit
		resultPath.deleteOnExit();

		try (FileOutputStream fileStream = new FileOutputStream(resultPath)) {
		    IOUtils.copy(resourceStream, fileStream);
		}

		return resultPath;
	}

    protected void cleanupFile(String path) {
        try {
            final Path filePath = Paths.get(path);
            Files.deleteIfExists(filePath);
        } catch (IOException e) {
            LOG.warn("Error during file cleanup", e);
        }
    }

    protected byte[] overlayImage(InputStream input, String overlayPath, String mode, Dimension dimensions, ResourceResolver resolver)
            throws IOException, InterruptedException, IM4JavaException {

    	// Get the overlay resource on disk
       	final Resource overlayResource = resolver.getResource(overlayPath);
        if (overlayResource == null) {
            throw new RuntimeException("Missing overlay asset: " + overlayPath);
        }
        
        ResourceOnDisk overlayResourceOnDisk = getResourceOnDisk(overlayResource);
	    File overlayFile = resizeOverlay(dimensions, overlayPath, overlayResourceOnDisk);
	    LOG.debug("Creating image composite with overlay={} ({})", overlayPath, overlayFile.getAbsolutePath());

	    File originalFile = streamToDiskTempFile("original.png", input);
	    try {
	        IMOperation op = new IMOperation();
	        op.density(460);
	        op.colorspace("sRGB");
	        op.addImage(originalFile.getAbsolutePath());
	        op.addImage(overlayFile.getAbsolutePath());
	        if (StringUtils.isNotBlank(mode)) {
	            op.compose(mode);
	        }
	        op.composite();
	        op.quality(1.0);
	        op.addImage("png:-");
	
	        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//	        Pipe pipeIn = new Pipe(input, null);
	        Pipe pipeOut = new Pipe(null, bos);
	
	        ImageMagickCmd cmd = new ImageMagickCmd("convert");
//	        cmd.setInputProvider(pipeIn);
	        cmd.setOutputConsumer(pipeOut);
	        cmd.run(op);
	
	        return bos.toByteArray();
        } finally {
        	if (!overlayResourceOnDisk.getFile().equals(overlayFile)) {
        		overlayFile.delete();
        		LOG.debug("Deleted temporary overlay file {}", overlayFile.getAbsolutePath());
        	}
        	if (!originalFile.delete()) {
        		LOG.warn("Could not delete temporary input file {}", originalFile.getAbsolutePath());
        	}
        }
    }

    private File resizeOverlay(Dimension targetDimensions, String overlayPath, ResourceOnDisk overlayResourceOnDisk) {
    	// Resize the overlay based on the target image
    	if (targetDimensions != null &&
    			(targetDimensions.getWidth() != overlayResourceOnDisk.getDimensions().getWidth() ||
    				targetDimensions.getHeight() != overlayResourceOnDisk.getDimensions().getHeight()) ) {
    		String targetSize = new StringBuilder(Integer.toString((int)targetDimensions.getWidth()))
    				.append("!x").append(Integer.toString((int)targetDimensions.getHeight()))
    				.append("!")
    				.toString();
    		
    		LOG.debug("Resizing overlay at {} to {}", overlayPath, targetSize);

    		// Create a temp file for the resource
    		File resultPath;
    		try {
    			resultPath =
    				File.createTempFile("tempOverlay", ".png", tempDirectory);
    			resultPath.deleteOnExit();
    		} catch (IOException e) {
    			throw new RuntimeException("Could not create a temp file", e);
    		}

    		// Move the overlay over to the right so that it fits in the overall image dimensions
    		execImageMagickCommand(
    				new String[] {imageMagickBinDir + "/convert",
    						"-density", "460",
    						"-colorspace", "sRGB",
    						overlayResourceOnDisk.file.getAbsolutePath(),
    						"-adaptive-resize", targetSize,
    						"-quality", "100",
    						resultPath.getAbsolutePath()});
    		
    		return resultPath;
    	}

    	// Use original overlay
		return overlayResourceOnDisk.getFile();
	}

	protected String getOverlayPath(String path, String position) {
        return String.format(path, position);
    }

    @Override
    public abstract byte[] processImage(ResourceResolver resolver, ImageProcessingModel model, Dimension dimensions, InputStream input);
}
