package com.jhi.aem.website.v1.core.image.processors;

public final class BlendingMode {

    public static final String OVERLAY = "overlay";
    public static final String MULTIPLY = "multiply";
    public static final String SCREEN = "screen";
    public static final String SOFT_LIGHT = "soft-light";
    public static final String DIVIDE = "divide";
}
