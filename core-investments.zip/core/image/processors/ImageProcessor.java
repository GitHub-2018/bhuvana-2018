package com.jhi.aem.website.v1.core.image.processors;

import java.awt.Dimension;
import java.io.InputStream;

import org.apache.sling.api.resource.ResourceResolver;

import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

public interface ImageProcessor {

    /**
     * Processes input stream and returns byte array containing result (which
     * allows chaining processors).
     * 
     * @param model
     * @param originalDimensions 
     * @param assetDimensions 
     * @param input
     */
    byte[] processImage(ResourceResolver resolver, ImageProcessingModel model, Dimension originalDimensions, InputStream input);
}
