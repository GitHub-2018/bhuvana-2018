package com.jhi.aem.website.v1.core.image.processors.impl;

import java.awt.Dimension;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.im4java.core.IM4JavaException;

import com.jhi.aem.website.v1.core.image.processors.AbstractImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.ImageProcessor;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

public class VariationDImageProcessor extends AbstractImageProcessor implements ImageProcessor {

    public static final String NAME = "variation_d";

    private static final String OVERLAY_1_PATH = OVERLAYS_ROOT + "/variation_d/%s/LG-D_01_Gradient-Color_Normal.png";

    public VariationDImageProcessor(String imageMagickBinDir, String tempDirectory) {
        super(imageMagickBinDir, tempDirectory);
    }

    @Override
    public byte[] processImage(ResourceResolver resolver, ImageProcessingModel model, Dimension dimensions, InputStream input) {
        try {
            return overlayImage(input, getOverlayPath(OVERLAY_1_PATH, model.getPosition()), StringUtils.EMPTY,
            		dimensions, resolver);
        } catch (IOException | InterruptedException | IM4JavaException e) {
            throw new RuntimeException("Error converting image", e);
        }
    }
}
