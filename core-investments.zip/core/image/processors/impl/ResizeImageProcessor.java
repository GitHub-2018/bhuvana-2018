package com.jhi.aem.website.v1.core.image.processors.impl;

import java.awt.Dimension;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.sling.api.resource.ResourceResolver;
import org.im4java.core.IM4JavaException;
import org.im4java.core.IMOperation;
import org.im4java.core.ImageMagickCmd;
import org.im4java.process.Pipe;

import com.jhi.aem.website.v1.core.image.processors.AbstractImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.ImageProcessor;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

public class ResizeImageProcessor extends AbstractImageProcessor implements ImageProcessor {

    public static final String NAME = "resize";

    private final int width;
    private final int height;

    public ResizeImageProcessor(String imageMagickBinDir, String tempDirectory, int width, int height) {
        super(imageMagickBinDir, tempDirectory);
        this.width = width;
        this.height = height;
    }

    @Override
    public byte[] processImage(ResourceResolver resolver, ImageProcessingModel model, Dimension dimensions, InputStream input) {
        try {
            return resize(input, resolver);
        } catch (IOException | InterruptedException | IM4JavaException e) {
            throw new RuntimeException("Error converting image", e);
        }
    }

    private byte[] resize(InputStream input, ResourceResolver resolver)
            throws IOException, InterruptedException, IM4JavaException {
        IMOperation op = new IMOperation();
        op.addImage("-");
        op.resize(width, height);
        op.addImage("png:-");

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        Pipe pipeIn = new Pipe(input, null);
        Pipe pipeOut = new Pipe(null, bos);

        ImageMagickCmd cmd = new ImageMagickCmd("convert");
        cmd.setInputProvider(pipeIn);
        cmd.setOutputConsumer(pipeOut);
        cmd.run(op);

        return bos.toByteArray();
    }
}
