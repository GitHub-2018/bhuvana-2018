package com.jhi.aem.website.v1.core.image.processors.impl;

import java.awt.Dimension;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.im4java.core.IM4JavaException;

import com.jhi.aem.website.v1.core.image.processors.AbstractImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.BlendingMode;
import com.jhi.aem.website.v1.core.image.processors.ImageProcessor;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

public class VariationCImageProcessor extends AbstractImageProcessor implements ImageProcessor {

    public static final String NAME = "variation_c";

    private static final String OVERLAY_1_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_01_Vertical-Color_Soft-Light.png";
    private static final String OVERLAY_2_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_02_Highlight_Overlay.png";
    private static final String OVERLAY_3_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_03_Highlight_Multiply.png";
    private static final String OVERLAY_4_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_04_Engraving_Normal.png";
    private static final String OVERLAY_5_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_05_Triangle_1_Screen.png";
    private static final String OVERLAY_6_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_06_Guilloche_Divide.png";
    private static final String OVERLAY_7_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_07_Triangle_2_Screen.png";
    private static final String OVERLAY_8_PATH = OVERLAYS_ROOT + "/variation_c/%s/LG-C_08_Triangle_3_Overlay.png";

    private final BlueChannelImageProcessor blueChannelImageProcessor;

    public VariationCImageProcessor(String imageMagickBinDir, String tempDirectory) {
        super(imageMagickBinDir, tempDirectory);

        blueChannelImageProcessor = new BlueChannelImageProcessor(imageMagickBinDir, tempDirectory);
    }

    @Override
    public byte[] processImage(ResourceResolver resolver, ImageProcessingModel model, Dimension dimensions, InputStream input) {
        try {
            byte[] result = blueChannelImageProcessor.processImage(resolver, model, dimensions, input);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_8_PATH, model.getPosition()),
                    BlendingMode.OVERLAY, dimensions, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_7_PATH, model.getPosition()),
                    BlendingMode.SCREEN, dimensions, resolver);
            //result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_6_PATH, model.getPosition()),
            //      BlendingMode.DIVIDE, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_5_PATH, model.getPosition()),
                    BlendingMode.SCREEN, dimensions, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_4_PATH, model.getPosition()),
                    StringUtils.EMPTY, dimensions, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_3_PATH, model.getPosition()),
                    BlendingMode.MULTIPLY, dimensions, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_2_PATH, model.getPosition()),
                    BlendingMode.OVERLAY, dimensions, resolver);
            return overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_1_PATH, model.getPosition()),
                    BlendingMode.SOFT_LIGHT, dimensions, resolver);
        } catch (IOException | InterruptedException | IM4JavaException e) {
            throw new RuntimeException("Error converting image", e);
        }
    }
}
