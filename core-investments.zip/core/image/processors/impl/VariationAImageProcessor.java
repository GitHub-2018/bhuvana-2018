package com.jhi.aem.website.v1.core.image.processors.impl;

import java.awt.Dimension;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.im4java.core.IM4JavaException;

import com.jhi.aem.website.v1.core.image.processors.AbstractImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.BlendingMode;
import com.jhi.aem.website.v1.core.image.processors.ImageProcessor;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

public class VariationAImageProcessor extends AbstractImageProcessor implements ImageProcessor {

    public static final String NAME = "variation_a";

    private static final String OVERLAY_1_PATH = OVERLAYS_ROOT + "/variation_a/%s/LG-A_01_Vertical-Color_Soft-Light.png";
    private static final String OVERLAY_2_PATH = OVERLAYS_ROOT + "/variation_a/%s/LG-A_02_Highlight_Screen.png";
    private static final String OVERLAY_3_PATH = OVERLAYS_ROOT + "/variation_a/%s/LG-A_03_Highlight_Multiply.png";
    private static final String OVERLAY_4_PATH = OVERLAYS_ROOT + "/variation_a/%s/LG-A_04_Engraving-Pattern_Normal.png";
    private static final String OVERLAY_5_PATH = OVERLAYS_ROOT + "/variation_a/%s/LG-A_05_Shapes_Normal.png";

    private final BlueChannelImageProcessor blueChannelImageProcessor;

    public VariationAImageProcessor(String imageMagickBinDir, String tempDirectory) {
        super(imageMagickBinDir, tempDirectory);

        blueChannelImageProcessor = new BlueChannelImageProcessor(imageMagickBinDir, tempDirectory);
    }

    @Override
    public byte[] processImage(ResourceResolver resolver, ImageProcessingModel model, Dimension dimensions, InputStream input) {
        try {
            byte[] result = blueChannelImageProcessor.processImage(resolver, model, dimensions, input);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_5_PATH, model.getPosition()),
                    StringUtils.EMPTY, dimensions, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_4_PATH, model.getPosition()),
                    StringUtils.EMPTY, dimensions, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_3_PATH, model.getPosition()),
                    BlendingMode.MULTIPLY, dimensions, resolver);
            result = overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_2_PATH, model.getPosition()),
                    BlendingMode.SCREEN, dimensions, resolver);
            return overlayImage(new ByteArrayInputStream(result), getOverlayPath(OVERLAY_1_PATH, model.getPosition()),
                    BlendingMode.SOFT_LIGHT, dimensions, resolver);
        } catch (IOException | InterruptedException | IM4JavaException e) {
            throw new RuntimeException("Error converting image", e);
        }
    }
}
