package com.jhi.aem.website.v1.core.image.listeners;

import java.awt.Dimension;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.im4java.process.ProcessStarter;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhi.aem.website.v1.core.constants.ComponentConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.image.processors.ImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.impl.BlueChannelImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.impl.ResizeImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.impl.VariationAImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.impl.VariationBImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.impl.VariationCImageProcessor;
import com.jhi.aem.website.v1.core.image.processors.impl.VariationDImageProcessor;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;
import com.jhi.aem.website.v1.core.models.image.ImageUtils;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;

@Component(
		name="Image Overlay Listener - JHI Website",
		service=EventHandler.class,
		immediate = true,
		configurationPolicy = ConfigurationPolicy.OPTIONAL,
		configurationPid="com.jhi.aem.website.v1.core.image.listeners.ImageOverlayListener",
		property= {
				EventConstants.EVENT_TOPIC+"="+SlingConstants.TOPIC_RESOURCE_CHANGED,
				EventConstants.EVENT_TOPIC+"="+SlingConstants.TOPIC_RESOURCE_ADDED,
				EventConstants.EVENT_FILTER+"=(|(resourceType=" + ComponentConstants.IMAGE_COMPONENT + ")(resourceType=" + ComponentConstants.VIDEO_COMPONENT + "))"
		})

@Designate(ocd=ImageOverlayListener.Config.class)
public class ImageOverlayListener implements EventHandler {

    private static final Logger LOG = LoggerFactory.getLogger(ImageOverlayListener.class);

   @ObjectClassDefinition(name="Image Overlay listener Configuration for JHI Website", description="Configuration properties for Image Overlay listener")
   public @interface Config{

            
       @AttributeDefinition(
               name = "ImageMagick Binary Directory",
               description="Binary Directory path for ImageMagick")
       String images_bin_dir() default ImageOverlayListener.DEFAULT_IMAGEMAGICK_BIN_DIR;
       
       @AttributeDefinition(
               name = "ImageMagick Temporary Directory",
               description="Temporary Directory path for Image magick")
       String images_temp_dir() default ImageOverlayListener.DEFAULT_IMAGEMAGICK_TEMP_DIR;
       
       @AttributeDefinition(
               name = "Reprocess images",
               type=AttributeType.BOOLEAN,
               description="Flag to enable or disable image reprocessing, by default set to false")
       boolean reprocessComponents() default ImageOverlayListener.DEFAULT_REPROCESS_COMPONENTS;
	   
   }
    static final String IMAGEMAGICK_BIN_DIR_PROPERTY = "images.bin.dir";
    static final String IMAGEMAGICK_TEMP_DIR_PROPERTY = "images.temp.dir";

    static final String DEFAULT_IMAGEMAGICK_BIN_DIR = "/usr/bin";
    static final String DEFAULT_IMAGEMAGICK_TEMP_DIR = "/tmp";

    static final boolean DEFAULT_REPROCESS_COMPONENTS = false;
    static final String REPROCESS_COMPONENTS = "reprocessComponents";

    
    private ResourceResolverFactory resolverFactory;
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory)
    {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory)
    {
    	this.resolverFactory=resolverFactory;
    }
    
    
    private Scheduler scheduler;
    @Reference
    public void bindScheduler(Scheduler scheduler)
    {
    	this.scheduler=scheduler;
    }
    public void unbindScheduler(Scheduler scheduler)
    {
    	this.scheduler=scheduler;
    }
    
    
    private RunModeService runModeService;
    @Reference
    public void bindRunModeService(RunModeService runModeService)
    {
    	this.runModeService=runModeService;
    }
    public void unbindRunModeService(RunModeService runModeService)
    {
    	this.runModeService=runModeService;
    }

    private String imagemagickBinDir;
    private String imagemagickTempDir;
    private boolean reprocessComponents;

    private Map<String, ImageProcessor> registry;

    
    private QueryBuilder queryBuilder;
    @Reference
    public void bindQueryBuilder(QueryBuilder queryBuilder)
    {
    	this.queryBuilder=queryBuilder;
    }
    public void unbindQueryBuilder(QueryBuilder queryBuilder)
    {
    	this.queryBuilder=queryBuilder;
    }


    @Activate
    protected void activate(final Config config) {
        initConfig(config);
    }

    @Modified
    protected void modified(final Config config) {
        initConfig(config);
    }

    private void initConfig(final Config config) {
        imagemagickBinDir = config.images_bin_dir();
        imagemagickTempDir = config.images_temp_dir();
        reprocessComponents = config.reprocessComponents();

        final Path dirPath = Paths.get(imagemagickTempDir);
        try {
            if (!Files.exists(dirPath)) {
                Files.createDirectory(dirPath);
            }
        } catch (IOException e) {
            LOG.error("Problem while creating imagemagic temporary directory", e);
        }

        ProcessStarter.setGlobalSearchPath(imagemagickBinDir);

        this.registry = new HashMap<>();
        this.registry.put(BlueChannelImageProcessor.NAME, new BlueChannelImageProcessor(imagemagickBinDir, imagemagickTempDir));
        this.registry.put(VariationAImageProcessor.NAME, new VariationAImageProcessor(imagemagickBinDir, imagemagickTempDir));
        this.registry.put(VariationBImageProcessor.NAME, new VariationBImageProcessor(imagemagickBinDir, imagemagickTempDir));
        this.registry.put(VariationCImageProcessor.NAME, new VariationCImageProcessor(imagemagickBinDir, imagemagickTempDir));
        this.registry.put(VariationDImageProcessor.NAME, new VariationDImageProcessor(imagemagickBinDir, imagemagickTempDir));

        // resize processors
        this.registry.put(generateResizeKey("large"), new ResizeImageProcessor(imagemagickBinDir, imagemagickTempDir, 632, 342));
        this.registry.put(generateResizeKey("medium"), new ResizeImageProcessor(imagemagickBinDir, imagemagickTempDir, 359, 194));
        this.registry.put(generateResizeKey("small"), new ResizeImageProcessor(imagemagickBinDir, imagemagickTempDir, 304, 164));
        this.registry.put(generateResizeKey("detail"), new ResizeImageProcessor(imagemagickBinDir, imagemagickTempDir, 742, 402));

        if (reprocessComponents) {
            reprocessComponentsInThread();
        }
    }

    void reprocessComponentsInThread() {
        // Reprocessing
        // http://localhost:4502/bin/querybuilder.json?1_property=sling:resourceType&1_property.value=&p.hits=full&p.offset=21
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(20000);
                } catch (InterruptedException e) {
                    LOG.error("Problem during delay", e);
                }

                ResourceResolver resolver = null;
                try {
                    resolver = resolverFactory.getServiceResourceResolver(
                            Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));

                    LOG.info("Starting reprocessing...");
                    reprocessComponents(resolver);
                    LOG.info("Finished reprocessing!");
                } catch (LoginException e1) {
                    throw new RuntimeException(e1);
                } finally {
                    if (resolver != null) {
                        resolver.close();
                    }
                }
            }
        });
    }

    private void reprocessComponents(ResourceResolver resolver) {
        String[] components = {ComponentConstants.IMAGE_COMPONENT, ComponentConstants.VIDEO_COMPONENT};
        for (String component : components) {
            final Map<String, String> searchParams = new HashMap<>();
            searchParams.put("1_" + JcrPropertyPredicateEvaluator.PROPERTY, "sling:resourceType");
            searchParams.put("1_" + JhiConstants.PROPERTY_VALUE_PARAMETER, component);

            Session jcrSession = resolver.adaptTo(Session.class);
            Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), jcrSession);
            query.setStart(0);
            long hitsPerPage = 25;
            query.setHitsPerPage(hitsPerPage);
            SearchResult result = query.getResult();

            boolean goOn = true;
            int counter = 0;
            while (goOn) {
                for (Hit hit : result.getHits()) {
                    counter++;
                    try {
                        String path = hit.getPath();
                        Resource resource = resolver.getResource(path);

                        if (!ResourceUtil.isNonExistingResource(resource)) {
                            ValueMap properties = resource.getValueMap();

                            if (StringUtils.isNotBlank((String) properties.get("position"))) {
                                // Reprocess
                                scheduleImageProcessingJob(path);
                                LOG.info("Reprocessed " + counter + " - " + path);
                            } else {
                                LOG.debug("Not reprocessing {}, no position: {}", path, properties);
                            }
                        } else {
                            LOG.debug("Cannot find resource {}", path);
                        }

                    } catch (RepositoryException e) {
                        LOG.warn("Could not reprocess", e);
                    }
                }

                long totalMatches = result.getTotalMatches();
                long startIndex = result.getStartIndex();
                if (result.getHits().isEmpty() || startIndex + hitsPerPage >= totalMatches) {
                    goOn = false;
                } else {
                    query = queryBuilder.createQuery(PredicateGroup.create(searchParams), jcrSession);
                    query.setStart(startIndex + hitsPerPage);
                    query.setHitsPerPage(hitsPerPage);
                    result = query.getResult();
                }
            }
        }
    }

    @Override
    public void handleEvent(Event event) {
        if (runModeService.isPublish()) {
            LOG.debug("Publish instance, aborting...");
            return;
        }

        final String path = (String) event.getProperty("path");
        if (StringUtils.isBlank(path)) {
            LOG.debug("Empty path, aborting...");
            return;
        }

        scheduleImageProcessingJob(path);
    }

    private void scheduleImageProcessingJob(final String path) {
        final ScheduleOptions options = scheduler.NOW();
        final String jobName = this.getClass().getSimpleName().toString().replace(".", "/") + "/" + path;
        options.name(jobName);
        options.canRunConcurrently(false);

        final ImageProcessingJob job = new ImageProcessingJob(path);
        scheduler.schedule(job, options);
    }

    private String generateResizeKey(String name) {
        return ResizeImageProcessor.NAME + "_" + name;
    }

    private class ImageProcessingJob implements Runnable {
        private static final String DEFAULT_IMAGE_TYPE = "image/png";
		private final String path;

        public ImageProcessingJob(String path) {
            this.path = path;
        }

        @Override
        public void run() {
            LOG.debug("Running job for: {}", path);

            ResourceResolver resolver = null;
            try {
                resolver = resolverFactory.getServiceResourceResolver(
                        Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));

                final Resource resource = resolver.getResource(path);
                if (resource == null) {
                    LOG.warn("Could not get resource {}", path);
                    return;
                }

                final ImageProcessingModel model = resource.adaptTo(ImageProcessingModel.class);
                if (model == null) {
                	LOG.warn("Could not get an image processing model from {}", path);
                	return;
                }
                if (!model.isImagePresent() || StringUtils.isBlank(model.getProcessing())) {
                    LOG.warn("Image model is not complete for '{}': {}", path, model);
                    return;
                }

                final Resource imageResource = resolver.getResource(model.getImagePath());
                if (imageResource == null) {
                    LOG.warn("Image resource does not exist for image '{}' with path '{}'", path, model.getImagePath());
                    return;
                }

                final Asset imageAsset = imageResource.adaptTo(Asset.class);
                if (imageAsset == null) {
                    LOG.warn("Could not adapt image resource '{}' to an asset with path '{}'", path, model.getImagePath());
                    return;
                }

                Dimension originalDimensions = ImageUtils.getAssetDimensions(imageAsset);
                InputStream assetOriginalStream = imageAsset.getOriginal().getStream();
                LOG.debug("Creating image overlay for '{}' at size {}", imageAsset.getPath(), originalDimensions);
                byte[] result = registry.get(model.getProcessing()).processImage(resolver, model, originalDimensions, assetOriginalStream);
                generateRenditions(imageAsset, model, resolver, result);
                if (assetOriginalStream != null) {
                    try {
                        assetOriginalStream.close();
                    } catch (IOException e) {
                        LOG.error("Problem wile closing asset stream", e);
                    }
                }
            } catch (LoginException e) {
                LOG.error("Could not get service resolver", e);
            } finally {
                if (resolver != null) {
                    resolver.close();
                }
            }
        }

        private void generateRenditions(Asset asset, ImageProcessingModel model, ResourceResolver resolver,
                                        byte[] original) {
            generateRendition(asset, model, resolver, original, "large");
            generateRendition(asset, model, resolver, original, "medium");
            generateRendition(asset, model, resolver, original, "small");
            generateRendition(asset, model, resolver, original, "detail");
        }

        private void generateRendition(Asset asset, ImageProcessingModel model, ResourceResolver resolver,
                                       byte[] original, String size) {
            final ImageProcessor resizeProcessor = registry.get(generateResizeKey(size));
            LOG.debug("Generating '{}' rendition for {}", size, asset.getPath());
            final byte[] resized = resizeProcessor.processImage(resolver, model, null, new ByteArrayInputStream(original));
            asset.addRendition(model.getRenditionName(size), new ByteArrayInputStream(resized), DEFAULT_IMAGE_TYPE);
        }
    }
}