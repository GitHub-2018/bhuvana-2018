package com.jhi.aem.website.v1.core.scheduler.admin;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.NodeIterator;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductScheduledActivationServiceImpl.Config;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.admin.EmailService;
import com.jhi.aem.website.v1.core.service.auth.external.IsamConstants;
import com.jhi.aem.website.v1.core.service.auth.external.IsamGroups;
import com.jhi.aem.website.v1.core.service.osgi.OsgiConfigurationService;

@Component(
		immediate = true,
		service=Runnable.class, 
		name = "Admin Pending Records Scheduler", 
		property= {
		Constants.SERVICE_DESCRIPTION+ "=Admin Check Pending Records Scheduler for UnverifiedPro Users"
		})
		
@Designate(ocd=AdminPendingRecordsScheduler.Config.class)
public class AdminPendingRecordsScheduler implements Runnable {

	private static final Logger LOG = LoggerFactory.getLogger(AdminPendingRecordsScheduler.class);

	@ObjectClassDefinition(name="JHI Admin Pending Records Scheduler Configurations", description="Configurations for Admin Pending Records scheduler")
	public @interface Config{
		 
		public static final String DEFAULT_EXPRESSION ="0 0 09 * * ?" ;
		@AttributeDefinition(name = "Enabled", description = "Enable Scheduler", type = AttributeType.BOOLEAN)
		 boolean serviceEnabled() default true;
		
		@AttributeDefinition(name = "Concurrent", description = "Schedule task concurrently", type = AttributeType.BOOLEAN)
		 boolean schedulerConcurrent() default true;
		
		@AttributeDefinition(name = "Scheduler name", description = "Scheduler name", type = AttributeType.STRING)
		 public String schedulerName() default "JHI Admin Pending Records Scheduler";
		
		@AttributeDefinition(name="Scheduler Expression", description ="Specify the scheduler expression as a quartz regex pattern")
		public String schedulerExpression() default DEFAULT_EXPRESSION;
	}
	
	ResourceResolverFactory resourceResolverFactory;
	@Reference
	public void bindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory=resourceResolverFactory;
	}
	public void unbindResourceResolverFactory(ResourceResolverFactory resourceResolverFactory) {
		this.resourceResolverFactory=resourceResolverFactory;
	}

	
	EmailService emailService;
	@Reference
	public void bindEmailService(EmailService emailService) {
		this.emailService=emailService;
	}
	public void unbindEmailService(EmailService emailService) {
		this.emailService=emailService;
	}

	
	OsgiConfigurationService configService;
	@Reference
	public void bindOsgiConfigurationService(OsgiConfigurationService configService) {
		this.configService=configService;
	}
	public void unbindOsgiConfigurationService(OsgiConfigurationService configService) {
		this.configService=configService;
	}

    private Scheduler scheduler;
	
	@Reference
	public void bindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	public void unbindScheduler(Scheduler scheduler ) {
		this.scheduler=scheduler;
	}
	
    private int schedulerID;
	@Activate
	protected void activate(Config config) {
		schedulerID = config.schedulerName().hashCode();
	}
	
	@Modified
	protected void modified(Config config) {
		removeScheduler();
		schedulerID = config.schedulerName().hashCode();
		addScheduler(config);
	}
	
	@Deactivate
	protected void deactivate(Config config) {
		removeScheduler();
	}
	
	private void removeScheduler() {
		LOG.debug("Removing Scheduler Job '{}'", schedulerID);
		  scheduler.unschedule(String.valueOf(schedulerID));
		 }
	
	private void addScheduler(Config config) {
		  if (config.serviceEnabled()) {
		   ScheduleOptions sopts = scheduler.EXPR(config.schedulerExpression());
		   sopts.name(String.valueOf(schedulerID));
		   sopts.canRunConcurrently(config.schedulerConcurrent());
		   scheduler.schedule(this, sopts);
		   LOG.debug("JHI Admin Pending Records Scheduler added succesfully");
		  } else {
			  LOG.debug("JHI Admin Pending Records Scheduler, no scheduler job created");
		  }
		 }
	
	@Override
	public void run() {
		ResourceResolver resolver = null;
		Map<String, String> emailProps = new HashMap<String, String>();

		try {
			String emailTemplatePath = configService.getProperty(JhiConstants.ADMIN_CONFIG_PID, "email.template.path",
					new String());
			String[] recipients = configService.getProperty(JhiConstants.ADMIN_CONFIG_PID, "email.to.address",
					new String[0]);

			String[] ccList = configService.getProperty(JhiConstants.ADMIN_CONFIG_PID, "email.cc.address",
					new String[0]);

			String searchPath = configService.getProperty(JhiConstants.ADMIN_CONFIG_PID, "searchPath", new String());

			String queryStr = "SELECT parent.* FROM [rep:User] AS parent WHERE ISDESCENDANTNODE('" + searchPath
					+ "') AND (parent.[isamGroup] ='" + IsamGroups.ISAM_UNVERIFIED_PRO_GROUP
					+ "') AND (parent.[userStatus]='" + IsamConstants.INACTIVE_USER_STATUS + "')";

			LOG.debug("queryString---" + queryStr);

			resolver = resourceResolverFactory.getServiceResourceResolver(Collections
					.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER));
			Session session = resolver.adaptTo(Session.class);

			QueryManager queryManager = session.getWorkspace().getQueryManager();
			Query query = queryManager.createQuery(queryStr.toString(), Query.JCR_SQL2);
			QueryResult result = query.execute();
			NodeIterator nodeIterator = result.getNodes();

			if (nodeIterator.getSize() >= 1) {
				emailService.sendEmail(session, emailTemplatePath, emailProps, recipients, ccList);
			}

		} catch (Exception exception) {
			LOG.error("Error while sending Email", exception);
		}
	}

}
