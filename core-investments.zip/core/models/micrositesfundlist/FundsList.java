package com.jhi.aem.website.v1.core.models.micrositesfundlist;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhi.aem.website.v1.core.models.fund.FundTag;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundsList {
	private final static Logger LOG = LoggerFactory.getLogger(FundsList.class);

	@Inject
	private List<String> fundIds;

    @Inject
    private ResourceResolver resourceResolver;

	private Set<FundTag> funds = new TreeSet<>();
	
	@PostConstruct
	protected void init() {
		final TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
		
		if (fundIds != null) {
			fundIds.stream().forEach(fundTagId -> {
	        	Tag tag = tagManager.resolve(fundTagId);
	        	
	        	if (tag != null) {
	        		funds.add(new FundTag(tag));
	        	} else {
	        		LOG.warn("Could not find tag for fund with id '{}'", fundTagId);
	        	}
	        });
		}
	}

	public boolean isBlank() {
		return fundIds == null || fundIds.isEmpty();
	}

	public List<String> getFundIds() {
		return fundIds;
	}

	public Set<FundTag> getFunds() {
		return funds;
	}

}
