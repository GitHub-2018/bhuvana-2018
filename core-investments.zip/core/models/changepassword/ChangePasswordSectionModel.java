package com.jhi.aem.website.v1.core.models.changepassword;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ChangePasswordSectionModel {

	@Inject @Via("resource")
	private String title;

	@Inject @Via("resource")
	private String oldPasswordLabel;

	@Inject @Via("resource")
	private String newPasswordLabel;

	@Inject @Via("resource")
	private String confirmPasswordLabel;
	
	@Inject
    @Via("resource")
    @Default
    private List<Resource> passwordCriterias;

	@Inject @Via("resource")
	private String submitButtonLabel;

	@Inject @Via("resource")
	private String successTitle;

	@Inject @Via("resource")
	private String successSubtitle;

	@Inject @Via("resource")
	private String continueButtonLabel;

	@Inject @Via("resource")
	private String continueButtonLink;

	@Inject @Via("resource")
	private Resource resource;

    @Self
    private SlingHttpServletRequest request;

    private String mappedResourcePath;

	@PostConstruct
	protected void init() {
		mappedResourcePath = resource.getResourceResolver().map(request, resource.getPath());
	}

	public String getTitle() {
		return title;
	}

	public String getNewPasswordLabel() {
		return newPasswordLabel;
	}

	public String getConfirmPasswordLabel() {
		return confirmPasswordLabel;
	}

	public List<Resource> getPasswordCriterias() {
		return passwordCriterias;
	}
	
	public String getSubmitButtonLabel() {
		return submitButtonLabel;
	}

	public String getSuccessTitle() {
		return successTitle;
	}

	public String getSuccessSubtitle() {
		return successSubtitle;
	}

	public String getContinueButtonLabel() {
		return continueButtonLabel;
	}

	public String getContinueButtonLink() {
		return LinkUtil.getLink(continueButtonLink);
	}

	public boolean isBlank() {
		return StringUtils.isBlank(title) && StringUtils.isBlank(newPasswordLabel)
				&& StringUtils.isBlank(confirmPasswordLabel) && StringUtils.isBlank(submitButtonLabel)
				&& StringUtils.isBlank(successTitle) && StringUtils.isBlank(successSubtitle)
				&& StringUtils.isBlank(continueButtonLabel);
	}

    public String getChangePasswordActionPath() {
        return mappedResourcePath + JhiConstants.SLING_SECURITY_CHECK_PATH;
    }

	public String getOldPasswordLabel() {
		return oldPasswordLabel;
	}

}
