package com.jhi.aem.website.v1.core.models.micrositevideo;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeInlineVideo {
	
    @Inject
    private ImageProcessingModel image;

    @Inject
    private String videoLink;	

    @Inject
    private String videoLinkOnClick;	

    @Inject
    private String linkText;	

    @Inject
    private String linkTitle;
    
    @Inject
    private String textLinkOnClick;
    
    @Inject
    private String text;

	public String getVideoLink() {
		return videoLink;
	}

	public String getVideoLinkOnClick() {
		return videoLinkOnClick;
	}

	public String getLinkText() {
		return linkText;
	}

	public String getLinkTitle() {
		return linkTitle;
	}

	public String getTextLinkOnClick() {
		return textLinkOnClick;
	}

	public String getText() {
		return text;
	}

	public String getVideoImage() {
        return ImageModel.getImagePath(image);
	}

    public boolean isBlank() {
    	return image == null || StringUtils.isBlank(linkText) || StringUtils.isBlank(videoLink) || StringUtils.isBlank(text);
    }

}
