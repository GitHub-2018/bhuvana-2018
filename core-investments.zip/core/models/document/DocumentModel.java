package com.jhi.aem.website.v1.core.models.document;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.dam.api.Asset;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.AssetUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DocumentModel {

    @Inject
    @Default
    private String fileReference;

    @Inject
    @Default
    protected String fileName;

    @Inject
    protected ResourceResolver resourceResolver;

    protected Asset asset;

    @PostConstruct
    protected void init() {
        if (StringUtils.isNotBlank(fileReference)) {
            Resource assetResource = resourceResolver.getResource(fileReference);
            if (assetResource != null) {
                asset = assetResource.adaptTo(Asset.class);
            }
        }
    }

    public String getPath() {
        return fileReference;
    }

    public String getThumbnailPath() {
        return AssetUtil.getThumbnailPath(asset);
    }

    public String getFileName() {
        return fileName;
    }

    public String getType() {
        return StringUtils.upperCase(StringUtils.substringAfterLast(fileName, JhiConstants.DOT));
    }

    public String getDisplaySize() {
        long size = asset.getOriginal().getSize();
        return FileUtils.byteCountToDisplaySize(size);
    }

    public long getSize() {
        return asset.getOriginal().getSize();
    }

    public static String getDocumentPath(DocumentModel model) {
        if (model == null) {
            return StringUtils.EMPTY;
        }
        return model.getPath();
    }

    public boolean isBlank() {
        return StringUtils.isBlank(fileReference) || asset == null;
    }
}
