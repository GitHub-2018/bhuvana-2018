package com.jhi.aem.website.v1.core.models.document;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.commons.DownloadResource;
import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ProductDocumentModel extends DocumentModel {

    @Inject
    @Default
    private String productPath;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    private String assetPath;
    private String productTitle;
    private String productDescription;
    private boolean orderable;
    private String resourcePagePath;

    private Page cartPage;

	private String cartPageLink;

    @Override
    @PostConstruct
    protected void init() {
        fileName = StringUtils.EMPTY;
        assetPath = StringUtils.EMPTY;
        productTitle = StringUtils.EMPTY;
        productDescription = StringUtils.EMPTY;
        orderable = false;
        if (StringUtils.isNotBlank(productPath)) {
            Resource productResource = resourceResolver.getResource(productPath);
            if (productResource != null) {
                RrdProductImpl product = new RrdProductImpl(productResource);
                orderable = product.isOrderable();
                productTitle = StringUtils.defaultIfBlank(product.getDisplayTitle(), product.getMetaTitle());
                productDescription = product.getDisplayDescription();
                Resource productAssetResource = product.getAsset();
                if (productAssetResource != null) {
                    assetPath = productAssetResource.getValueMap().get(DownloadResource.PN_REFERENCE, String.class);
                    if (StringUtils.isNotBlank(assetPath)) {
                        Resource assetResource = resourceResolver.getResource(assetPath);
                        if (assetResource != null) {
                            asset = assetResource.adaptTo(Asset.class);
                            if (asset != null) {
                                fileName = asset.getName();
                            }
                        }
                    }
                }
                String resourcePagePath = product.getResourcePagePath();
                if (StringUtils.isNotBlank(resourcePagePath)) {
                    Resource resourcePageResource = resourceResolver.getResource(resourcePagePath);
                    if (resourcePageResource != null) {
                        this.resourcePagePath = resourcePagePath;
                    }
                }
            }
        }

        cartPage = PageUtil.getSitePageByResourceType(resourcePage, ResourcesConstants.CART_PAGE_RESOURCE_TYPE);
        cartPageLink = LinkUtil.getPageLink(resourceResolver, cartPage);
    }

    @Override
    public String getPath() {
        return assetPath;
    }

    public String getProductPath() {
        return productPath;
    }

    public String getProductTitle() {
        return productTitle;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public boolean isOrderable() {
        return orderable;
    }

    public String getResourcePagePath() {
        return resourcePagePath;
    }

    public String getCartPage() {
        return cartPageLink;
    }

    @Override
    public boolean isBlank() {
        return StringUtils.isBlank(productPath) || asset == null;
    }
}
