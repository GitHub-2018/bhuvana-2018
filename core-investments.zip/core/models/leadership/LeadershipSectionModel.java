package com.jhi.aem.website.v1.core.models.leadership;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.person.PersonalBiographyDetails;
import com.jhi.aem.website.v1.core.service.person.PersonService;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class LeadershipSectionModel {

    @Inject
    private String title;

    @Inject
    private String readBioLabel;

    @Inject
    private String closeModalLabel;

    @Inject
    private List<String> people;

    private List<PersonalBiographyDetails> peopleModels;

    @Inject
    private PersonService personService;

    @Inject
    private Page resourcePage;

    @PostConstruct
    private void init() {
        peopleModels = new ArrayList<>();
        if (people == null || people.size() == 0) {
            return;
        }

        peopleModels = fetchBiographyModelsByTags(people);
    }

    private List<PersonalBiographyDetails> fetchBiographyModelsByTags(List<String> tags) {
        return personService.getPersonalBiographyDetailsModelsByTags(tags, resourcePage);
    }

    public String getTitle() {
        return title;
    }

    public String getReadBioLabel() {
        return readBioLabel;
    }

    public String getCloseModalLabel() {
        return closeModalLabel;
    }

    public List<String> getPeople() {
        return people;
    }

    public List<PersonalBiographyDetails> getPeopleModels() {
        return peopleModels;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(readBioLabel) && StringUtils.isBlank(closeModalLabel);
    }
}
