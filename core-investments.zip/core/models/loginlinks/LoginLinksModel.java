package com.jhi.aem.website.v1.core.models.loginlinks;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class LoginLinksModel {

    @Inject
    private String copy;

    @Inject
    private String registerLink;

    @Inject
    private String registerLabel;

    public String getCopy() {
        return copy;
    }

    public String getRegisterLink() {
        return registerLink;
    }

    public String getRegisterLabel() {
        return registerLabel;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(copy) && StringUtils.isBlank(registerLabel) && StringUtils.isBlank(registerLink);
    }
}
