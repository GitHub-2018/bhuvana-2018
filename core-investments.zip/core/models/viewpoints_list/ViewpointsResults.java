package com.jhi.aem.website.v1.core.models.viewpoints_list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;

public class ViewpointsResults {
    private static final List<ViewpointDetailModel> EMPTY_LIST = Collections.emptyList();
    public static final ViewpointsResults EMPTY = new ViewpointsResults();

    private List<ViewpointDetailModel> items;
    private int totalResults;

    public ViewpointsResults() {
        items = EMPTY_LIST;
        totalResults = 0;
    }

    public ViewpointsResults(int size, int totalResults) {
        if (size > 0) {
        	// Ensure we don't allocate a huge array the size of Integer.MAX_VALUE
            items = new ArrayList<>(Math.min(100, size));
        } else if (size < 0) { // NO_LIMIT
            items = new ArrayList<>();
        } else {
            items = EMPTY_LIST;
        }
        this.totalResults = totalResults;
    }

    public void addItem(ViewpointDetailModel viewpointDetailModel) {
        items.add(viewpointDetailModel);
    }

    public List<ViewpointDetailModel> getItems() {
        return items;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public boolean isEmpty() {
        return items == null || items.isEmpty();
    }
}
