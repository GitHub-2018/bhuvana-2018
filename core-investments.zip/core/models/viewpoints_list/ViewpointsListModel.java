package com.jhi.aem.website.v1.core.models.viewpoints_list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang.ArrayUtils;
import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.eval.TypePredicateEvaluator;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.generic.pagination.Pagination;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.models.viewpoint_asset_manager.ViewpointAssetManagerHeaderModel;
import com.jhi.aem.website.v1.core.models.viewpoint_author.ViewpointsAuthorDetails;
import com.jhi.aem.website.v1.core.service.person.PersonService;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.PaginationUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ViewpointsListModel {
    private static final int DEFAULT_RESULTS_PER_PAGE = 10;

    private static final Logger LOGGER = LoggerFactory.getLogger(ViewpointsListModel.class);

    @Inject
    private Page currentPage;

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private ResourceResolver resourceResolver;

    @Inject
    private ViewpointsService viewpointsService;

    @Inject
    private PersonService personService;

    @OSGiService
    private QueryBuilder queryBuilder;

    private ViewpointsResults viewpointsResults;
    private Pagination pagination;
    private int pageNumber;

    @PostConstruct
    protected void init() {
        pageNumber = RequestUtil.getPageNumber(request);
        initViewpointsResults();
        initPagination();
    }

    private void initViewpointsResults() {
        Page viewpointsRoot = ViewpointUtil.getViewpointsMainPage(currentPage);
        if (viewpointsRoot != null) {
            int offset = (pageNumber - 1) * DEFAULT_RESULTS_PER_PAGE;
            if (PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_AUTHOR_PAGE_RESOURCE_TYPE)) {
                viewpointsResults = viewpointsService.getAuthorsViewpoints(resourceResolver, viewpointsRoot.getPath(), offset,
                        DEFAULT_RESULTS_PER_PAGE, new String[]{currentPage.getPath()});
            } else if (PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_ASSET_MANAGER_PAGE_RESOURCE_TYPE)) {
                viewpointsResults = viewpointsService.getAuthorsViewpoints(resourceResolver, viewpointsRoot.getPath(), offset,
                        DEFAULT_RESULTS_PER_PAGE, getAuthorsPaths(viewpointsRoot));
            } else if (PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_TOPIC_PAGE_RESOURCE_TYPE)) {
                viewpointsResults = viewpointsService.getViewpoints(resourceResolver, currentPage.getPath(), offset, DEFAULT_RESULTS_PER_PAGE);
            } else if (PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_TAG_PAGE_RESOURCE_TYPE)) {
                viewpointsResults = viewpointsService.getTagViewpoints(resourceResolver, viewpointsRoot.getPath(), offset,
                        DEFAULT_RESULTS_PER_PAGE, currentPage.getPath());
            } else if (PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_LIST_PAGE_RESOURCE_TYPE)) {
                viewpointsResults = viewpointsService.getViewpoints(resourceResolver, viewpointsRoot.getPath(), offset, DEFAULT_RESULTS_PER_PAGE);
            }
        }
    }

    private void initPagination() {
        String currentPath = currentPage.getPath() + JhiConstants.URL_HTML_EXTENSION;
        pagination = PaginationUtil.preparePagination(currentPath, pageNumber, viewpointsResults.getTotalResults(), DEFAULT_RESULTS_PER_PAGE);
    }

    public List<ViewpointDetailModel> getViewpointsDetailsList() {
        return viewpointsResults.getItems();
    }

    public Pagination getPagination() {
        return pagination;
    }

    public boolean isBlank() {
        return viewpointsResults == null || viewpointsResults.getItems().isEmpty();
    }

    private String[] getAuthorsPaths(Page viewpointsRoot) {
        String assetManagerReferencePath = ViewpointAssetManagerHeaderModel.getAssetManagerReferencePath(currentPage);
        Page homePage = PageUtil.getHomePage(currentPage);
        List<Page> authorsReferencesPages = personService.getAssetManagerPeople(resourceResolver, homePage.getPath(),
                assetManagerReferencePath);
        return getAuthorsPaths(viewpointsRoot, authorsReferencesPages);
    }

    private String[] getAuthorsPaths(Page viewpointsRoot, List<Page> authorsReferencesPages) {
        if (viewpointsRoot != null && authorsReferencesPages != null && !authorsReferencesPages.isEmpty()) {
            Map<String, String> searchParams = new HashMap<>(5 + authorsReferencesPages.size());
            searchParams.put(PathPredicateEvaluator.PATH, viewpointsRoot.getPath());
            searchParams.put(TypePredicateEvaluator.TYPE, NameConstants.NT_PAGE);
            searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY,
                    JhiConstants.PAGE_RESOURCE_TYPE_PROPERTY);
            searchParams.put(JhiConstants.QUERY_FIRST_ITEM_PREFIX + JhiConstants.PROPERTY_VALUE_PARAMETER,
                    ResourcesConstants.VIEWPOINTS_AUTHOR_PAGE_RESOURCE_TYPE);
            searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY,
                    JcrConstants.JCR_CONTENT + JhiConstants.SLASH + ViewpointsAuthorDetails.AUTHOR_REFERENCE);

            List<String> authorsIds = new ArrayList<>();
            int i = 1;
            for (Page authorReferencePage : authorsReferencesPages) {
                if (authorReferencePage.isValid()) {
                    searchParams.put(JhiConstants.QUERY_SECOND_ITEM_PREFIX + JcrPropertyPredicateEvaluator.PROPERTY + JhiConstants.DOT
                            + i++ + JhiConstants.UNDERSCORE + JcrPropertyPredicateEvaluator.VALUE, authorReferencePage.getPath());
                    authorsIds.add(authorReferencePage.getName());
                }
            }
            Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
            SearchResult result = query.getResult();
            List<String> authorsPaths = new ArrayList<>();
            if (!result.getHits().isEmpty()) {
                for (Hit hit : result.getHits()) {
                    try {
                        authorsPaths.add(hit.getPath());
                    } catch (RepositoryException e) {
                        LOGGER.error("Problem while taking author page path", e);
                    }
                }
            }
            Page authorsRoot = PageUtil.getChildByResourceType(viewpointsRoot, ResourcesConstants
                    .VIEWPOINTS_AUTHORS_ROOT_PAGE_RESOURCE_TYPE);
            if (authorsRoot != null) {
                String authorsRootPath = authorsRoot.getPath() + JhiConstants.SLASH;
                for (String authorId : authorsIds) {
                    String authorIdPath = authorsRootPath + authorId;
                    if (!authorsPaths.contains(authorIdPath)) {
                        authorsPaths.add(authorIdPath);
                    }
                }
            }
            if (!authorsPaths.isEmpty()) {
                return authorsPaths.toArray(new String[authorsPaths.size()]);
            }
        }
        return ArrayUtils.EMPTY_STRING_ARRAY;
    }
}
