package com.jhi.aem.website.v1.core.models.viewpoints_list;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointsListTitleModel {

    @Inject
    private Page resourcePage;

    private String pageResourceType;

    @PostConstruct
    protected void init() {
        pageResourceType = PageUtil.getResourceType(resourcePage);
    }

    public String getTitle() {
        return PageUtil.getPageNavigationTitle(resourcePage);
    }
    
    public String getTitleLowerCase() {
        return StringUtils.lowerCase(PageUtil.getPageNavigationTitle(resourcePage));
    }

    public boolean isTag() {
        return StringUtils.equals(ResourcesConstants.VIEWPOINTS_TAG_PAGE_RESOURCE_TYPE, pageResourceType);
    }

    public boolean isTopic() {
        return StringUtils.equals(ResourcesConstants.VIEWPOINTS_TOPIC_PAGE_RESOURCE_TYPE, pageResourceType);
    }
}
