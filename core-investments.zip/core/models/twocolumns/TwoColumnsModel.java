package com.jhi.aem.website.v1.core.models.twocolumns;

import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class TwoColumnsModel {

    private static final String DEFAULT_COLUMN_WIDTH = "6";

    @ValueMapValue
    private String layout = StringUtils.EMPTY;

    @ValueMapValue
    private String column1CssClass = StringUtils.EMPTY;

    @ValueMapValue
    private String column2CssClass = StringUtils.EMPTY;

    @SlingObject
    private Resource resource;

    private Integer columnDivisionRate;
    private String column1width;
    private String column2width;

    @PostConstruct
    protected void init() {

        columnDivisionRate = getColumnDivision(resource);

        String[] columnWidths = Optional.of(layout)
                .map(str -> StringUtils.split(str, JhiConstants.VALUES_SEPARATOR))
                .filter(layoutParts -> layoutParts.length == 2)
                .orElse(new String[] { DEFAULT_COLUMN_WIDTH, DEFAULT_COLUMN_WIDTH });

        column1width = getColumnWidth(columnWidths[0]);
        column2width = getColumnWidth(columnWidths[1]);

    }

    private String getColumnWidth(String part) {
        return Integer.toString(Integer.valueOf(part) / columnDivisionRate);
    }

    private Integer getColumnDivision(final Resource root) {
        Optional<Resource> optionalResource = Optional.ofNullable(root)
                .map(Resource::getParent);
        if (optionalResource.isPresent()) {
            Resource parent = optionalResource.get();
            if (parent.isResourceType(ResourcesConstants.RESOURCE_TYPE_WCM_PARSYS)) {
                return getColumnDivision(parent);
            }
            if (parent.isResourceType(ResourcesConstants.RESOURCE_TWO_COLUMNS)) {
                return 2;
            }
        }
        return 1;
    }

    public String getColumn1width() {
        return column1width;
    }

    public String getColumn2width() {
        return column2width;
    }

    public String getColumn1CssClass() {
        return column1CssClass;
    }

    public String getColumn2CssClass() {
        return column2CssClass;
    }
}
