package com.jhi.aem.website.v1.core.models;

import java.util.HashMap;
import java.util.Map;

public class NullValueDiscardingMap<K extends Object, V extends Object> extends HashMap<K,V> {
	private static final long serialVersionUID = 1L;

	public NullValueDiscardingMap() {
		super();
	}

	public NullValueDiscardingMap(int initialCapacity, float loadFactor) {
		super(initialCapacity, loadFactor);
	}

	public NullValueDiscardingMap(int initialCapacity) {
		super(initialCapacity);
	}

	public NullValueDiscardingMap(Map<? extends K, ? extends V> m) {
		super(m);
	}

	@Override
	public V put(K key, V value) {
		if (value == null) {
			// Discard null values
			return null;
		}

		return super.put(key, value);
	}
	
	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		m.forEach((k,v) -> put(k,v));
	}

}
