package com.jhi.aem.website.v1.core.models.audio;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;


@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AudioModel {
	private final static String STATIC_AUDIO_IMAGE = "/etc.clientlibs/jhi-website-v1/clientlibs/clientlib-site/resources/audio-player-static-waveform.png";
	
    @Inject
    @Default
    private String fileReference;

    @Inject
    @Default
    private String text;

    @Inject
    private ResourceResolver resourceResolver;

    private Asset asset;

    @PostConstruct
    protected void init() {
        if (StringUtils.isNotBlank(fileReference)) {
            Resource assetResource = resourceResolver.getResource(fileReference);
            if (assetResource != null) {
                asset = assetResource.adaptTo(Asset.class);
            }
        }
    }

    public String getPath() {
        return fileReference;
    }

    public String getAudioType() {
        if (asset == null) {
            return StringUtils.EMPTY;
        }
        return asset.getMetadataValue(DamConstants.DC_FORMAT);
    }

    public boolean isValid() {
        return asset != null;
    }

	public String getText() {
		return text;
	}

	public String getImagePath() {
		return STATIC_AUDIO_IMAGE;
	}
}
