package com.jhi.aem.website.v1.core.models.presslist;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.generic.pagination.Pagination;
import com.jhi.aem.website.v1.core.models.news.NewsPageModel;
import com.jhi.aem.website.v1.core.service.news.NewsService;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PressListModel {

    @Inject
    private Page resourcePage;

    @SlingObject
    private ResourceResolver resolver;

    @ValueMapValue
    private String readMoreLabel;

    @OSGiService
    private NewsService service;

    private List<NewsPageModel> items;
    private Pagination pagination;

    @PostConstruct
    private void init() {
        items = service.getNews(resourcePage);
        pagination = new Pagination(-1, items.size(), items.size(), items.size());
    }

    public String getReadMoreLabel() {
        return readMoreLabel;
    }

    public List<NewsPageModel> getItems() {
        return items;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(readMoreLabel);
    }
}
