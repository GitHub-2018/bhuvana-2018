package com.jhi.aem.website.v1.core.models.image;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ImageProcessingModel extends ImageModel {

    private static final String CLASS_PREFIX = "overlay_";
	private static final String RENDITION_PATH_FORMAT = "%s/jcr:content/renditions/%s";
    private static final String FILENAME_FORMAT = "processed_%s_%s_%s.png";
    private static final String DEFAULT_PROCESSING = "none";
    public final static ImageProcessingModel EMPTY_MODEL = new ImageProcessingModel();

    @Inject
    private String processing;

    @Inject
    private String position;

    @Inject
    private String cssClass;

    public String getImagePath() {
        return ImageModel.getImagePath(this);
    }

    public String getRenditionPath() {
        final String imagePath = getImagePath();
        if (StringUtils.isBlank(imagePath)) {
            return StringUtils.EMPTY;
        }
        if (!isProcessedImage()) {
            return imagePath;
        }

        return String.format(RENDITION_PATH_FORMAT, imagePath, getRenditionName("large"));
    }

	public boolean isProcessedImage() {
		return !StringUtils.isBlank(processing) && !StringUtils.isBlank(position) &&
				!StringUtils.equals(DEFAULT_PROCESSING, processing);
	}

    public String getRenditionName(String size) {
        return String.format(FILENAME_FORMAT, processing, position, size);
    }

    public String getProcessing() {
        return processing;
    }

    public String getProcessingClass() {
        return CLASS_PREFIX + processing;
    }

    public String getPosition() {
        return position;
    }

    public String getPositionClass() {
        return CLASS_PREFIX + position;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(getImagePath()) && StringUtils.isBlank(processing) && StringUtils.isBlank(position);
    }

    public boolean isImagePresent() {
        return StringUtils.isNotBlank(getImagePath());
    }

    public static String getRenditionPath(ImageProcessingModel model) {
        if (model == null) {
            return StringUtils.EMPTY;
        }

        return model.getRenditionPath();
    }
    
    @Override
    public String toString() {
    	return ReflectionToStringBuilder.toString(this);
    }

	public String getCssClass() {
		return cssClass;
	}

}
