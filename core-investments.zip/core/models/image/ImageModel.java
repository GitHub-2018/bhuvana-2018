package com.jhi.aem.website.v1.core.models.image;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.day.cq.wcm.foundation.Image;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ImageModel {
    private static final Logger LOG = LoggerFactory.getLogger(ImageModel.class);
    private static final String IMG_SELECTOR = ".img";
    private static final String DATA_PREFIX = "data:";
    private static final String BASE_64 = "base64";
    private static final String IMAGE_DATA_FORMAT = DATA_PREFIX + "%s" + JhiConstants.VALUES_SEPARATOR + BASE_64
            + JhiConstants.MULTIPLE_VALUES_SEPARATOR + "%s";


    @Inject
    @Default
    private String fileReference;

    @Inject
    private Resource resource;

    @OSGiService
    private ResourceResolverFactory resourceResolverFactory;

    private String path;

    private Dimension imageDimensions;

    @PostConstruct
    protected void init() {
        path = getImagePath(fileReference, resource);

        // Work out the default image width/height
        if (StringUtils.isNotBlank(path)) {
            Resource pathResource = resource.getResourceResolver().getResource(path);

            if (pathResource != null) {
                imageDimensions = ImageUtils.getResourceDimensions(pathResource);
            }
        }
    }

    public String getPath() {
        return path;
    }

    private String getImagePath(String fileReference, Resource imageResource) {
        if (StringUtils.isNotBlank(fileReference)) {
            return fileReference;
        } else {
            Image image = new Image(imageResource);
            if (image.hasContent()) {
                image.setSelector(IMG_SELECTOR);
                return image.getSrc();
            }
            return StringUtils.EMPTY;
        }
    }

    public String getThumbnailRendition() {
        Asset asset = resource.adaptTo(Asset.class);
        if (asset != null) {
            List<Rendition> renditions = asset.getRenditions();
            Rendition thumbnailRendition = null;

            for (Rendition rendition : renditions) {
                if (thumbnailRendition == null || thumbnailRendition.getSize() > rendition.getSize()) {
                    thumbnailRendition = rendition;
                }
            }

            return thumbnailRendition == null ? getPath() : thumbnailRendition.getPath();
        }
        return getPath();
    }

    public String getRenditionPath(String renditionName) {
        Asset asset = resource.adaptTo(Asset.class);
        if (asset != null) {
            Rendition rendition = asset.getRendition(renditionName);

            if (rendition != null) {
                return rendition.getPath();
            }
        }
        return StringUtils.EMPTY;
    }

    public String getBase64String() {
        String resultString = StringUtils.EMPTY;
        Resource imageResource = null;
        ResourceResolver resourceResolver = resource.getResourceResolver();
        boolean additionalResolver = false;
        if (!resourceResolver.isLive()) {
            resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
            additionalResolver = true;
        }
        if (resourceResolver != null) {
            if (StringUtils.isNotBlank(fileReference)) {
                imageResource = resourceResolver.getResource(fileReference);
            }
            if (imageResource == null) {
                imageResource = resource;
            }
            if (imageResource != null) {
                Asset asset = imageResource.adaptTo(Asset.class);
                if (asset != null) {
                    String mimeType = asset.getMimeType();
                    try {
                        try (InputStream assetStream = asset.getOriginal().getStream()) {
                            resultString = String.format(IMAGE_DATA_FORMAT, mimeType,
                                    Base64.getEncoder().encodeToString(IOUtils.toByteArray(assetStream)));
                        }
                    } catch (IOException e) {
                        LOG.error("Problem while getting image content", e);
                    }
                }
            }
            if (additionalResolver && resourceResolver.isLive()) {
                resourceResolver.close();
            }
        }
        return resultString;
    }

    public static String getImagePath(ImageModel model) {
        if (model == null) {
            return StringUtils.EMPTY;
        }
        return model.getPath();
    }

    public int getImageHeight() {
        return imageDimensions != null ? (int) imageDimensions.getHeight() : 0;
    }

    public int getImageWidth() {
        return imageDimensions != null ? (int) imageDimensions.getWidth() : 0;
    }
}
