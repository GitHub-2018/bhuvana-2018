package com.jhi.aem.website.v1.core.models.image;

import java.awt.Dimension;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;

import com.day.cq.dam.api.Asset;

public final class ImageUtils {
	
	private ImageUtils() {}

	public static Dimension getResourceDimensions(Resource resource) {
		return getAssetDimensions(resource.adaptTo(Asset.class));
	}

	public static Dimension getAssetDimensions(Asset asset) {
    	int imageHeight = 0;
    	int imageWidth = 0;

    	if (asset != null) {
        	String imageHeightString = asset.getMetadataValueFromJcr("tiff:ImageLength");
        	if (StringUtils.isNotBlank(imageHeightString)) {
        		imageHeight = Integer.parseInt(imageHeightString);
        	}
        	String imageWidthString = asset.getMetadataValueFromJcr("tiff:ImageWidth");
        	if (StringUtils.isNotBlank(imageWidthString)) {
        		imageWidth = Integer.parseInt(imageWidthString);
        	}
    	}
    	
    	return new Dimension(imageWidth, imageHeight);
	}

}
