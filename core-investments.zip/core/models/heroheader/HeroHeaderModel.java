package com.jhi.aem.website.v1.core.models.heroheader;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HeroHeaderModel {

    @Inject
    private String title;

    @Inject
    private String text;

    @Inject
    private String downloadButtonUrl;

    @Inject
    private String downloadButtonLabel;

    @Inject
    private String downloadButtonSubtext;

    @Inject
    private String account;

    @Inject
    private String videoPlayer;

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getDownloadButtonUrl() {
        return LinkUtil.getLink(downloadButtonUrl);
    }

    public String getDownloadButtonLabel() {
        return downloadButtonLabel;
    }

    public String getDownloadButtonSubtext() {
        return downloadButtonSubtext;
    }

    public String getAccount() {
        return account;
    }

    public String getVideoPlayer() {
        return videoPlayer;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(downloadButtonUrl)
                && StringUtils.isBlank(downloadButtonLabel) && StringUtils.isBlank(downloadButtonSubtext);
    }

    public boolean isVideoPresent() {
        return StringUtils.isNotBlank(account) && StringUtils.isNotBlank(videoPlayer);
    }
}
