package com.jhi.aem.website.v1.core.models.resources;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ResourcesViewTypeModel {

    @Self
    private SlingHttpServletRequest request;

    private String accessSelector;

    private String getAccessSelector() {
        if (accessSelector == null) {
            accessSelector = RequestUtil.getAccessSelector(request);
        }
        return accessSelector;
    }

    public boolean isAnonymousView() {
        return StringUtils.isBlank(getAccessSelector());
    }

    public boolean isPublicView() {
        return getAccessSelector().contains(JhiConstants.ACCESS_PUBLIC);
    }

    public boolean isAdvisorView() {
        return getAccessSelector().contains(JhiConstants.ACCESS_ADVISOR);
    }

    public boolean isNotInvestorView() {
        return !getAccessSelector().contains(JhiConstants.ACCESS_INVESTOR);
    }
    
    public boolean isDisplayInterstitalPage() {
    	return !PageUtil.isInUcitsSite(request.getResource());
    }

}
