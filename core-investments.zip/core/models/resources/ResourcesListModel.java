package com.jhi.aem.website.v1.core.models.resources;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.generic.link.Link;
import com.jhi.aem.website.v1.core.generic.pagination.Pagination;
import com.jhi.aem.website.v1.core.service.resources.ResourceTypeModel;
import com.jhi.aem.website.v1.core.service.resources.ResourcesResult;
import com.jhi.aem.website.v1.core.service.resources.ResourcesService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ResourcesListModel {

    private static final int MAX_ITEMS = 10;
    private static final String LIST_CONTENT_SELECTOR = "listContent";
    private static final String PAGINATION_PATH_PATTERN = "%s." + LIST_CONTENT_SELECTOR + "%s" + "%s" + JhiConstants
            .URL_HTML_EXTENSION + JhiConstants.SLASH + "%s" + JhiConstants.SLASH;
    private static final String LIST_CONTENT_SELECTOR_PATH = "." + LIST_CONTENT_SELECTOR + JhiConstants.ACCESS_SELECTOR_PLACEHOLDER
            + JhiConstants.URL_HTML_EXTENSION;
    private static final String NAVIGATION_SELECTOR = "navigation";
    private static final String NAVIGATION_SELECTOR_PATH = "." + NAVIGATION_SELECTOR + JhiConstants.ACCESS_SELECTOR_PLACEHOLDER
            + JhiConstants.URL_HTML_EXTENSION;

    private static final String QUERY_PREFIX = "query_";

    private static final Logger LOGGER = LoggerFactory.getLogger(ResourcesListModel.class);

    @Inject
    @Via("resource")
    @Default
    private String rootPath;

    @Inject
    private ResourceResolver resourceResolver;

    @Inject
    private Page resourcePage;

    @Self
    private SlingHttpServletRequest request;

    @OSGiService
    private ResourcesService resourcesService;

    @OSGiService
    private UserProfileService userProfileService;

    private ResourceCategoryType resourceCategory;
    private String topic;
    private String queryText;
    private String queryParameter;
    private int page;
    private List<ResourceDetailModel> resources;
    private int resultsCount;
    private Pagination pagination;
    private String cartPageLink;
    private String firmSelector;
    private String accessSelector;

    @PostConstruct
    protected void init() {
        if (StringUtils.isBlank(rootPath)) {
            Page homePage = PageUtil.getHomePage(resourcePage);
            if (homePage != null) {
                Page resourcesMainPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants.RESOURCES_PAGE_RESOURCE_TYPE);
                if (resourcesMainPage != null) {
                    rootPath = resourcesMainPage.getPath();
                }
            }
        }
        parseParameters();
        firmSelector = RequestUtil.getFirmSelector(request);
        accessSelector = RequestUtil.getAccessSelector(request);
        if (ArrayUtils.contains(request.getRequestPathInfo().getSelectors(), LIST_CONTENT_SELECTOR)) {
            ResourcesResult resourcesResult = prepareResources();
            preparePagination(resourcesResult);
            resultsCount = resourcesResult.getTotalMatches();
        }
        final Page cartPage = PageUtil.getSitePageByResourceType(resourcePage, ResourcesConstants.CART_PAGE_RESOURCE_TYPE);
        cartPageLink = resourceResolver.map(LinkUtil.getPageLink(cartPage));
    }

    public long getFormsCount() {
        return getCount(ResourceCategoryType.FORMS);
    }

    public long getBusinessCount() {
        return getCount(ResourceCategoryType.BUSINESS);
    }

    public long getEducationCount() {
        return getCount(ResourceCategoryType.EDUCATION);
    }

    public List<ResourceTypeModel> getTopics() {
        return resourcesService.getTopics(resourceResolver, rootPath);
    }

    public String getContentPath() {
        return resourceResolver.map(request.getResource().getPath()) + LIST_CONTENT_SELECTOR_PATH;
    }

    public String getNavigationPath() {
        return resourceResolver.map(request.getResource().getPath()) + NAVIGATION_SELECTOR_PATH;
    }

    private long getCount(ResourceCategoryType resourceType) {
        return resourcesService.getResourcesCount(resourceResolver, rootPath, resourceType, accessSelector, firmSelector);
    }

    public boolean isFormsSelected() {
        return resourceCategory == ResourceCategoryType.FORMS;
    }

    public boolean isBusinessSelected() {
        return resourceCategory == ResourceCategoryType.BUSINESS;
    }

    public boolean isEducationSelected() {
        return resourceCategory == ResourceCategoryType.EDUCATION;
    }

    public List<ResourceDetailModel> getResources() {
        return resources;
    }

    public int getResultsCount() {
        return resultsCount;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public String getSearchPath() {
        return resourceResolver.map(request.getResource().getPath() + JhiConstants.URL_HTML_EXTENSION);
    }

    public String getCartPageLink() {
        return cartPageLink;
    }

    public String getType() {
        return StringUtils.lowerCase(resourceCategory.name());
    }

    public boolean isAnonymousView() {
        return StringUtils.isBlank(accessSelector);
    }

    public boolean isPublicView() {
        return accessSelector.contains(JhiConstants.ACCESS_PUBLIC);
    }

    public boolean isAdvisorView() {
        return accessSelector.contains(JhiConstants.ACCESS_ADVISOR) || accessSelector.contains(JhiConstants.ACCESS_UFPADVISOR);
    }

    public boolean isNotInvestorView() {
        return !accessSelector.contains(JhiConstants.ACCESS_INVESTOR);
    }

    /**
     * Suffix options: /forms.html
     * /forms/college_saving.html /forms/2.html
     * /forms/college_saving/2.html
     */
    private void parseParameters() {
        String suffix = RequestUtil.getSuffix(request);
        resourceCategory = ResourceCategoryType.FORMS;
        topic = StringUtils.EMPTY;
        page = 1;

        if (StringUtils.isNotBlank(suffix)) {
            String[] parts = StringUtils.split(suffix, JhiConstants.SLASH);
            for (String part : StringUtils.split(suffix, JhiConstants.SLASH)) {
                if (!StringUtils.contains(part, JhiConstants.UNDERSCORE)) {
                    if (StringUtils.isNumeric(part)) {
                        page = Integer.parseInt(part);
                        if (page < 1) {
                            page = 1;
                        }
                    } else {
                        ResourceCategoryType requestedResourceCategory = ResourceCategoryType.getByName(parts[0]);
                        if (requestedResourceCategory != null) {
                            resourceCategory = requestedResourceCategory;
                        }
                    }
                } else if (StringUtils.startsWith(part, ResourceTypeModel.TOPICS_PARAMETER)) {
                    topic = part;

                } else if (StringUtils.startsWith(part, QUERY_PREFIX)) {
                    queryParameter = part;
                    try {
                        queryText = URLDecoder.decode(StringUtils.removeStart(part, QUERY_PREFIX), JhiConstants.DEFAULT_CHARSET_NAME);
                        if (queryText.length() < JhiConstants.MIN_TEXT_QUERY_LENGTH) {
                            queryText = StringUtils.EMPTY;
                            queryParameter = StringUtils.EMPTY;
                        }
                    } catch (UnsupportedEncodingException e) {
                        LOGGER.error("Problem while decoding query text parameter", e);
                    }
                }
            }

            if (parts.length > 0) {
                ResourceCategoryType requestedResourceCategory = ResourceCategoryType.getByName(parts[0]);
                if (requestedResourceCategory != null) {
                    resourceCategory = requestedResourceCategory;
                }
            }
            if (parts.length > 1) {
                if (StringUtils.isNumeric(parts[1])) {
                    page = Integer.parseInt(parts[1]);
                    if (page < 1) {
                        page = 1;
                    }
                } else if (StringUtils.startsWith(parts[1], ResourceTypeModel.TOPICS_PARAMETER)) {
                    topic = parts[1];
                } else if (StringUtils.startsWith(parts[1], QUERY_PREFIX)) {
                    queryParameter = parts[1];
                    try {
                        queryText = URLDecoder.decode(StringUtils.removeStart(parts[1], QUERY_PREFIX), JhiConstants.DEFAULT_CHARSET_NAME);
                        if (queryText.length() < JhiConstants.MIN_TEXT_QUERY_LENGTH) {
                            queryText = StringUtils.EMPTY;
                            queryParameter = StringUtils.EMPTY;
                        }
                    } catch (UnsupportedEncodingException e) {
                        LOGGER.error("Problem while decoding query text parameter", e);
                    }
                }
            }
            if (parts.length > 2) {
                if (StringUtils.isNumeric(parts[2])) {
                    page = Integer.parseInt(parts[2]);
                    if (page < 1) {
                        page = 1;
                    }
                }
            }
        }
    }

    private ResourcesResult prepareResources() {
        int start = (page - 1) * MAX_ITEMS;
        ResourcesResult resourcesResult = resourcesService.getResources(request.getResourceResolver(), rootPath, resourceCategory, topic,
                queryText, accessSelector, firmSelector, MAX_ITEMS, start);
        resources = resourcesResult.getResources();
        return resourcesResult;
    }

    private void preparePagination(ResourcesResult resourcesResult) {
        if (resourcesResult != null && resourcesResult.getResources() != null && !resourcesResult.getResources().isEmpty()) {
            String firmSelectorPart = StringUtils.EMPTY;
            String accessSelectorsPart = StringUtils.EMPTY;
            if (StringUtils.isNotBlank(firmSelector)) {
                firmSelectorPart = JhiConstants.DOT + firmSelector;
            }
            if (!accessSelector.isEmpty()) {
                accessSelectorsPart = JhiConstants.DOT + StringUtils.join(accessSelector, JhiConstants.DOT);
            }
            String basePath = resourceResolver.map(String.format(PAGINATION_PATH_PATTERN, request.getResource().getPath(),
                    accessSelectorsPart, firmSelectorPart, getType()));
            int resultPages = (resourcesResult.getTotalMatches() + MAX_ITEMS - 1) / MAX_ITEMS;
            pagination = new Pagination(page, MAX_ITEMS, resultPages, resourcesResult.getTotalMatches());
            for (int i = 1; i <= resultPages; i++) {
                pagination.addLink(new Link(preparePaginationLink(basePath, i), String.valueOf(i), i == page));
            }
        }
    }

    private String preparePaginationLink(String basePath, int pageNumber) {
        String link = basePath;
        if (StringUtils.isNotBlank(topic)) {
            link = basePath + topic + JhiConstants.SLASH;
        }
        if (StringUtils.isNotBlank(queryParameter)) {
            link = link + queryParameter + JhiConstants.SLASH;
        }
        return link + pageNumber + JhiConstants.URL_HTML_EXTENSION;
    }
}
