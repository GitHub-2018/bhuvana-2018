package com.jhi.aem.website.v1.core.models.resources;

import org.apache.commons.lang3.StringUtils;

public enum ResourceCategoryType {
    FORMS("forms-and-applications", "Forms & Applications"),
    BUSINESS("business-building", "Business Building"),
    EDUCATION("education", "Education");

    private String categoryLocation;
    private String categoryName;

    ResourceCategoryType(String categoryLocation, String categoryName) {
        this.categoryLocation = categoryLocation;
        this.categoryName = categoryName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String getCategoryLocation() {
        return categoryLocation;
    }


    public static ResourceCategoryType getByName(String name) {
        if (StringUtils.isNotBlank(name)) {
            for (ResourceCategoryType itemType : ResourceCategoryType.values()) {
                if (StringUtils.equalsIgnoreCase(name, itemType.name())) {
                    return itemType;
                }
            }
        }
        return null;
    }
}
