package com.jhi.aem.website.v1.core.models.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.PageManager;
import com.google.common.collect.ImmutableMap;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class RelatedResourcesModel {
	private final static Logger LOG = LoggerFactory.getLogger(RelatedResourcesModel.class);

    public static final int RELATED_ITEMS_COUNT = 3;

    @Inject
    @Default
    private String first;

    @Inject
    @Default
    private String second;

    @Inject
    @Default
    private String third;

    @Inject
    private PageManager pageManager;

    @Self
    private Resource resource;

    static final Map<String, String> TITLES_MAP = ImmutableMap.of(
            "relatedArticles", "Related articles",
            "relatedDocuments", "Related documents",
            "relatedForms", "Related forms"
    );

    private List<ResourceDetailModel> resources;

    @PostConstruct
    protected void init() {
        resources = new ArrayList<>(RELATED_ITEMS_COUNT);
        addResource(first);
        addResource(second);
        addResource(third);
    }

    public List<ResourceDetailModel> getResources() {
        return resources;
    }

    public String getTitle() {
        return StringUtils.defaultString(TITLES_MAP.get(resource.getName()));
    }

    public boolean isBlank() {
        return resources.isEmpty();
    }

    private void addResource(String resourcePath) {
        ResourceDetailModel detailModel = ResourceDetailModel.fromPage(pageManager.getPage(resourcePath));
        if (detailModel != null && detailModel.isValid()) {
            resources.add(detailModel);
        } else {
        	LOG.warn("Could not find related resource for '{}'", resourcePath);
        }
    }
}
