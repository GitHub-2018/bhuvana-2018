package com.jhi.aem.website.v1.core.models.resources;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ResourcesNavigationModel {

    @Inject
    @Default(intValues = 3)
    private int items;

    public boolean isItemFourAvailable() {
        return items == 4;
    }
}
