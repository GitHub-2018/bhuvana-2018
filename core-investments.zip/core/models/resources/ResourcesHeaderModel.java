package com.jhi.aem.website.v1.core.models.resources;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ResourcesHeaderModel {

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String allResourcesLabel;

    @Inject
    private Page resourcePage;

    private String allResourcesPageLink;

    @PostConstruct
    protected void init() {
        allResourcesPageLink = JhiConstants.HASH;
        Page homePage = PageUtil.getHomePage(resourcePage);
        if (homePage != null) {
            Page resourcesPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants
                    .RESOURCES_PAGE_RESOURCE_TYPE);
            if (resourcesPage != null) {
                Page resourcesListPage = PageUtil.getChildByResourceType(resourcesPage, ResourcesConstants
                        .RESOURCES_LIST_PAGE_RESOURCE_TYPE);
                allResourcesPageLink = LinkUtil.getPageLink(resourcesListPage);
            }
        }
    }

    public String getTitle() {
        return title;
    }

    public String getAllResourcesLabel() {
        return allResourcesLabel;
    }

    public String getAllResourcesPageLink() {
        return allResourcesPageLink;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(allResourcesLabel);
    }
}
