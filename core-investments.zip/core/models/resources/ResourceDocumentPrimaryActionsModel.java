package com.jhi.aem.website.v1.core.models.resources;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;
import com.jhi.aem.website.v1.core.utils.ResourceDocumentUtil;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ResourceDocumentPrimaryActionsModel {

    @Inject
    @Via("resource")
    @Default
    private String productPath;

    @Inject
    @Via("resource")
    @Default
    private String assetPath;

    @Inject
    @Via("resource")
    @Default
    private String fileType;

    @Inject
    @Via("resource")
    @Default
    private Integer fileSize;

    @Inject
    @Via("resource")
    @Default
    private Boolean orderable;

    @Inject
    @Via("resource")
    @Default
    private String eFormLink;

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    private Page cartPage;
    private String accessSelector;
    private String firmSelector;
    private RrdProductImpl product;
    private String assetLink;

    private String cartPageLink;

    @PostConstruct
    protected void init() {
        if (product == null) {
            if (StringUtils.isNotBlank(productPath)) {
                Resource productResource = resourceResolver.getResource(productPath);
                if (productResource != null) {
                    product = new RrdProductImpl(productResource);
                }
            }
        }

        firmSelector = RequestUtil.getFirmSelector(request);
        accessSelector = RequestUtil.getAccessSelector(request);
        assetLink = LinkUtil.getHostBaseUrlFromRequest(request) + assetPath;
        cartPage = PageUtil.getSitePageByResourceType(resourcePage, ResourcesConstants.CART_PAGE_RESOURCE_TYPE);
        cartPageLink = LinkUtil.getPageLink(request.getResourceResolver(), cartPage);
    }

    public String getAssetPath() {
        return assetPath;
    }

    public String getAssetLink() {
        return assetLink;
    }

    public String getEFormLink() {
        return eFormLink;
    }

    public String getFileType() {
        return fileType;
    }

    public Integer getFileSize() {
        return fileSize;
    }

    public String getDisplayFileSize() {
        return FileUtils.byteCountToDisplaySize(getFileSize());
    }

    public boolean isOrderable() {
        return Boolean.TRUE.equals(orderable);
    }

    public Page getCartPage() {
        return cartPage;
    }

    public String getCartPageLink() {
        return cartPageLink;
    }

    public boolean isAccessible() {
        return ResourceDocumentUtil.isAccessible(product, firmSelector, accessSelector);
    }

    public boolean isAdvisorAccess() {
        return ResourceDocumentUtil.isAdvisorAccess(product, accessSelector);
    }

    public boolean isExclusive() {
        return ResourceDocumentUtil.isExclusive(product, accessSelector);
    }

    public boolean isLocked() {
        return ResourceDocumentUtil.isLocked(product, firmSelector, accessSelector);
    }

    public boolean isAddToCartPossible() {
        return ResourceDocumentUtil.isAddToCartPossible(product, firmSelector, accessSelector);
    }
}
