package com.jhi.aem.website.v1.core.models.resources;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

public class ResourceDetailModel implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final ResourceDetailModel EMPTY = new ResourceDetailModel();

    @Inject
    @Default
    @Named("title/jcr:title")
    private String title;

    @Inject
    @Default
    @Named("summary/text")
    private String summary;

    @Inject
    @Default
    private Boolean orderable;

    @Inject
    @Default
    private String access;

    @Inject
    private String documentType;

    @Inject
    protected transient Resource resource;
    
	@OSGiService
	private ResourceResolverFactory resourceResolverFactory;

    @Inject
    protected transient Page resourcePage;

    private String pagePath;
    private String resourcePath;

	private String pageLink;
	
	private String resourceThumbnailPath;

	@PostConstruct
    protected void init() {
    	ResourceResolver pageResourceResolver = null;
		try {
			pageResourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
	        if (StringUtils.isBlank(title)) {
	            title = PageUtil.getPageNavigationTitle(resourcePage);
	        }

	        pagePath = PageUtil.getPagePath(resourcePage);
	        pageLink = LinkUtil.getLink(pageResourceResolver, pagePath);
	        resourcePath = resource == null ? StringUtils.EMPTY : resource.getPath();
		} finally {
			if (pageResourceResolver != null && pageResourceResolver.isLive()) {
				pageResourceResolver.close();
			}
		}

    }
    
    public String getResourceThumbnailPath() {
		return resourceThumbnailPath;
	}

	public void setResourceThumbnailPath(String resourceThumbnailPath) {
		this.resourceThumbnailPath = resourceThumbnailPath;
	}

    public String getThumbnailPath() {
        return StringUtils.EMPTY;
    }

    public String getTitle() {
        return title;
    }

    public String getSummary() {
        return summary;
    }

    public String getPagePath() {
        return pagePath;
    }

    public String getPageLink() {
        return pageLink;
    }

    public String getAssetPath() {
        return StringUtils.EMPTY;
    }

    public String getMoreLabel() {
        return StringUtils.EMPTY;
    }

    public boolean isOrderable() {
        return Boolean.TRUE.equals(orderable);
    }

    public boolean isPublic() {
        return StringUtils.equals(access, JhiConstants.ACCESS_PUBLIC);
    }

    public boolean isExclusive() {
        return StringUtils.equals(access, JhiConstants.ACCESS_EXCLUSIVE);
    }

    public String getDocumentPath() {
        return resourcePath;
    }

    public String getDocumentType() {
        return documentType;
    }

    public boolean isValid() {
        return StringUtils.isNotEmpty(resourcePath) && StringUtils.isNotBlank(getTitle()) && StringUtils.isNotBlank(getSummary());
    }

	public boolean isValidInUcits() {
        return StringUtils.isNotEmpty(resourcePath) && StringUtils.isNotBlank(getTitle());
	}

	public static ResourceDetailModel fromPage(Page page) {
        if (page != null) {
            Resource contentResource = page.getContentResource();
            if (contentResource != null) {
                return contentResource.adaptTo(ResourceDetailModel.class);
            }
        }
        return EMPTY;
    }

}
