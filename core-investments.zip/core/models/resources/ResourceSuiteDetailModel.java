package com.jhi.aem.website.v1.core.models.resources;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.injectors.qualifiers.TargetResourceTypes;

@Model(adaptables = Resource.class, adapters = ResourceDetailModel.class)
@TargetResourceTypes(ResourcesConstants.RESOURCE_SUITE_PAGE_RESOURCE_TYPE)
public class ResourceSuiteDetailModel extends ResourceDetailModel {

    public static final String MAIN_PARAGRAPH_PATH = "mainParagraph";
    public static final String DOCUMENTS_PATH = "documents";
    public static final String DOCUMENT_ITEM_PATH = "document";

    @Override
    public boolean isValid() {
        return resource != null && StringUtils.isNotBlank(getTitle());
    }

    public boolean isValidInUcits() {
    	return isValid();
    }

    @Override
    public String getMoreLabel() {
        return "View document";
    }
}
