package com.jhi.aem.website.v1.core.models.resources;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.generic.link.SimpleLink;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ResourcesNavigationTileModel {

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String text;

    @Inject
    @Default
    private String buttonLink;

    @Inject
    @Default
    private String buttonLabel;

    @Inject
    @Default
    private List<Resource> linksList;

    @Inject
    private ResourceResolver resourceResolver;

    @OSGiService
    private ResourceResolverFactory resourceResolverFactory;

    private String buttonLinkUrl;
    private List<SimpleLink> links;

	@PostConstruct
	protected void init() {
		ResourceResolver linksResourceResolver = null;
		try {
			linksResourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
			if (linksResourceResolver == null) {
				linksResourceResolver = resourceResolver;
			}
			if (linksResourceResolver != null) {
				PageManager pageManager = linksResourceResolver.adaptTo(PageManager.class);
				if (pageManager != null) {
					if (LinkUtil.isInternalPath(buttonLink)) {
						Page page = pageManager.getPage(buttonLink);
						buttonLinkUrl = LinkUtil.getPageLink(linksResourceResolver, page);
					} else {
						buttonLinkUrl = buttonLink;
					}
				}
			}
			links = LinkUtil.prepareLinks(linksResourceResolver, linksList);

			// GIT issue #1712 - Closing all open ResourceResolver objects
			// This can leave sessions open internally if not closed
			// You open it , you close it
		} finally {
			if (linksResourceResolver != null && linksResourceResolver.isLive()) {
				linksResourceResolver.close();
			}
		}
	}

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getButtonLink() {
        return buttonLink;
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public List<SimpleLink> getLinks() {
        return links;
    }

	public boolean isBlank() {
		return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(buttonLabel)
				&& linksList.isEmpty();
	}

    public String getButtonLinkUrl() {
        return buttonLinkUrl;
    }

	public boolean isButtonValid() {
		return StringUtils.isNotBlank(buttonLabel) && StringUtils.isNotBlank(buttonLinkUrl)
				&& !StringUtils.equals(buttonLinkUrl, JhiConstants.HASH);
	}
}
