package com.jhi.aem.website.v1.core.models.resources;

import org.apache.commons.io.FileUtils;

public class DocumentsInfo {

    private int count;
    private long size;

    public DocumentsInfo() {
        count = 0;
        size = 0;
    }

    public void addDocument(long size) {
        count ++;
        this.size += size;
    }

    public int getCount() {
        return count;
    }

    public long getSize() {
        return size;
    }

    public String getDisplaySize() {
        return FileUtils.byteCountToDisplaySize(size);
    }
}
