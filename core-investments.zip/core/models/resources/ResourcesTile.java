package com.jhi.aem.website.v1.core.models.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.generic.link.Link;
import com.jhi.aem.website.v1.core.generic.link.SimpleLink;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ResourcesTile {

    private static final Logger LOG = LoggerFactory.getLogger(ResourcesTile.class);

    @Inject
    @Default
    private String section;

    @Inject
    @Default
    private String text;

    @Inject
    @Default
    private String first;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String firstTitle;

    @Inject
    @Default
    private String second;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String secondTitle;

    @Inject
    @Default
    private String third;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String thirdTitle;

    @Inject
    @Default
    private String moreLabel;

    @Inject
    private ResourceResolverFactory resolverFactory;

    @Inject
    private Resource resource;

    private Page sectionPage;
    private List<SimpleLink> links;
    private int trackingId;
    private String morePath;
    private String sectionTitle;

    @PostConstruct
    protected void init() {
    	ResourceUtil.consumeResourceInElevatedResourceResolver(resolverFactory,
			resolver -> {
		        PageManager pageManager = resolver.adaptTo(PageManager.class);

		        sectionPage = pageManager.getPage(section);
		        
		        links = new ArrayList<>(3);
		        addPageLink(first, firstTitle, resolver);
		        addPageLink(second, secondTitle, resolver);
		        addPageLink(third, thirdTitle, resolver);

		        trackingId = generateTrackingId();

		        morePath = Optional.ofNullable(sectionPage)
		                .map(path -> LinkUtil.getLink(resolver, path.getPath()))
		                .orElse(StringUtils.EMPTY);
                sectionTitle = PageUtil.getPageNavigationTitle(sectionPage);
			});
    }

    public String getSectionTitle() {
        return sectionTitle;
    }

    public String getText() {
        return text;
    }

    public List<SimpleLink> getLinks() {
        return links;
    }

    public String getMorePath() {
        return morePath;
    }

    public String getMoreLabel() {
        return moreLabel;
    }

    public int getTrackingId() {
        return trackingId;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(section) && StringUtils.isBlank(first) && StringUtils.isBlank(second)
                && StringUtils.isBlank(third) && StringUtils.isBlank(moreLabel);
    }

    private int generateTrackingId() {
        final String name = resource.getName();

        switch (name) {
        case "first":
            return 1;
        case "second":
            return 2;
        case "third":
            return 3;
        case "forth":
            return 4;
        case "fifth":
            return 5;
        default:
            return 0;
        }
    }

    private void addPageLink(String pageLink, String title, ResourceResolver resolver) {
        if (StringUtils.isBlank(pageLink)) {
            return;
        }
        if (LinkUtil.isInternalPath(pageLink)) {
            Page page = resolver.adaptTo(PageManager.class).getPage(pageLink);
            if (page != null) {
                if (StringUtils.isBlank(title)) {
                    links.add(Link.fromPage(page));
                } else {
                    links.add(new SimpleLink(LinkUtil.getLink(resolver, pageLink), title));
                }
            }
        } else if (StringUtils.isNotBlank(title)) {
            links.add(new SimpleLink(pageLink, title));
        }
    }
}
