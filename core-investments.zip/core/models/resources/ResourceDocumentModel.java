package com.jhi.aem.website.v1.core.models.resources;

import java.util.Calendar;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.DateUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ResourceDocumentModel {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ResourceDocumentModel.class);

	public static final String TITLE_PROPERTY = "title";
	public static final String DESCRIPTION_PROPERTY = "description";
	public static final String PRODUCT_PATH_PROPERTY = "productPath";
	public static final String PRODUCT_CODE_PROPERTY = "productCode";
	public static final String ASSET_PATH_PROPERTY = "assetPath";
	public static final String THUMBNAIL_PATH_PROPERTY = "thumbnailPath";
	public static final String FILE_TYPE_PROPERTY = "fileType";
	public static final String FILE_SIZE_PROPERTY = "fileSize";
	public static final String REVISION_DATE_PROPERTY = "revisionDate";
	public static final String ORDERABLE_PROPERTY = "orderable";
	public static final String APPROVED_FOR_PROPERTY = "approvedFor";
	public static final String ELECTRONIC_FORM_LINK_PROPERTY = "eFormLink";
	private static final String REDIRECT_TARGET_PROPERTY = "redirectTarget";

	private static final String ACTIONS_CONTENT_SELECTOR = "primaryActionsContent";
	private static final String PRIMARY_ACTIONS_CONTENT_PATH = JhiConstants.DOT + ACTIONS_CONTENT_SELECTOR
			+ JhiConstants.ACCESS_SELECTOR_PLACEHOLDER + JhiConstants.URL_HTML_EXTENSION;

	@Inject
	@Default
	private String title;

	@Inject
	@Default
	private String description;

	@Inject
	@Default
	private String notes;

	@Inject
	@Default
	private String productPath;

	@Inject
	@Default
	private String assetPath;

	@Inject
	@Default
	private String thumbnailPath;

	@Inject
	@Default
	private String fileType;

	@Inject
	@Default
	private Integer fileSize;

	@Inject
	@Optional
	private Calendar revisionDate;

	@Inject
	@Optional
	private Calendar lastUpdated;

	@Inject
	@Default
	private String approvedFor;

	@Inject
	@Default
	private Boolean orderable;

	@Self
	private Resource resource;

	@Inject
	private Page resourcePage;

	@OSGiService
	private ResourceResolverFactory resourceResolverFactory;

	private Page cartPage;
	private boolean publicAccess = false;
	private String cartPageLink;
	private String primaryActionsPath;

	@PostConstruct
	protected void init() {
		ResourceResolver pageResourceResolver = null;
		try {
			pageResourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
			Resource pageContentResource = resourcePage.getContentResource();
			if (pageContentResource != null) {
				ValueMap values = pageContentResource.getValueMap();
				if (values.containsKey(JhiConstants.ACCESS_PROPERTY)) {
					publicAccess = StringUtils.equals(values.get(JhiConstants.ACCESS_PROPERTY, StringUtils.EMPTY),
							JhiConstants.ACCESS_PUBLIC);
				}
			}
			cartPage = PageUtil.getSitePageByResourceType(pageResourceResolver, resourcePage, ResourcesConstants.CART_PAGE_RESOURCE_TYPE);  
			// GIT issue #1712 - Closing all open ResourceResolver objects
			// This can leave sessions open internally if not closed
			// You open it , you close it
	        PageManager pageManager = pageResourceResolver.adaptTo(PageManager.class);  
	        Page currentCartPage = cartPage == null ? null : pageManager.getPage(cartPage.getPath()); 
			cartPageLink = getPageLink(pageResourceResolver, currentCartPage);
			primaryActionsPath = pageResourceResolver.map(resource.getPath()) + PRIMARY_ACTIONS_CONTENT_PATH;

		} finally {
			if (pageResourceResolver != null && pageResourceResolver.isLive()) {
				pageResourceResolver.close();
			}
		}

	}
	
    public static String getPageLink(ResourceResolver resourceResolver, Page page) {
        if (page == null) {
            return JhiConstants.HASH;
        }
        if (PageUtil.isResourceType(page, ResourcesConstants.REDIRECT_PAGE_RESOURCE_TYPE)) {
            Resource contentResource = page.getContentResource();
            if (contentResource == null) {
                return JhiConstants.HASH;
            }
            ValueMap values = contentResource.getValueMap();
            String redirectTarget = values.get(REDIRECT_TARGET_PROPERTY, StringUtils.EMPTY);
            if (StringUtils.isBlank(redirectTarget)) {
                return JhiConstants.HASH;
            }
            return LinkUtil.getLink(resourceResolver, redirectTarget);
        }
        return LinkUtil.getLink(resourceResolver, page.getPath());
    }

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getNotes() {
		return notes;
	}

	public String getProductPath() {
		return productPath;
	}

	public String getAssetPath() {
		return assetPath;
	}

	public String getThumbnailPath() {
		return thumbnailPath;
	}

	public String getFileType() {
		return fileType;
	}

	public Integer getFileSize() {
		return fileSize;
	}

	public String getDisplayFileSize() {
		return FileUtils.byteCountToDisplaySize(getFileSize());
	}

	public Calendar getRevisionDate() {
		return revisionDate;
	}

	public Calendar getLastUpdated() {
		return lastUpdated;
	}

	public String getDate() {
		return DateUtil.getFormattedUsDate(revisionDate, resourcePage);
	}

	public String getApprovedForText() {
		if (StringUtils.isNotBlank(approvedFor)) {
			ApprovedForType approvedForType = ApprovedForType.getByName(approvedFor);
			if (approvedForType != null) {
				return approvedForType.getText();
			}
		}
		return StringUtils.EMPTY;
	}

	public Page getCartPage() {
		return cartPage;
	}

	public String getCartPageLink() {
		return cartPageLink;
	}

	public boolean isOrderable() {
		return Boolean.TRUE.equals(orderable);
	}

	public boolean isPublicAccess() {
		return publicAccess;
	}

	public String getPrimaryActionsPath() {
		return primaryActionsPath;
	}
}
