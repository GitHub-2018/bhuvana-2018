package com.jhi.aem.website.v1.core.models.resources;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.generic.link.SimpleLink;
import com.jhi.aem.website.v1.core.service.resources.DocumentsUtil;
import com.jhi.aem.website.v1.core.servlets.redirect.ResourceThumbnailServlet;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ResourceIntroModel {

    @Inject
    private Page resourcePage;

    private SimpleLink categoryLink = null;

    private String imagePath = null;
    
    private ResourceDetailModel document;

    @PostConstruct
    protected void init() {
        if (resourcePage == null || resourcePage.getContentResource() == null) {
            return;
        }
        document = ResourceDetailModel.fromPage(resourcePage);
        final ResourcePageModel resourcePageModel = resourcePage.getContentResource().adaptTo(ResourcePageModel.class);
        if (resourcePageModel != null && StringUtils.isNotBlank(resourcePageModel.getCategory())
                && DocumentsUtil.isResource(resourcePageModel.getDocumentType())) {
            ResourceCategoryType categoryType = ResourceCategoryType.getByName(resourcePageModel.getCategory());
            Page homePage = PageUtil.getHomePage(resourcePage);
            if (homePage != null) {
                Page resourcesPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants.RESOURCES_PAGE_RESOURCE_TYPE);
                if (resourcesPage != null) {
                    if (categoryType != null) {
                        categoryLink = new SimpleLink(LinkUtil.getPageLink(resourcesPage) + JhiConstants.HASH + StringUtils
                                .lowerCase(resourcePageModel.getCategory()), categoryType.getCategoryName());
                    }
                }
            }
        }
    }

    public String getThumbnailPath() {
        if (imagePath == null) {
            imagePath = StringUtils.EMPTY;
            ResourceDetailModel detailModel = ResourceDetailModel.fromPage(resourcePage);
            String thumbnailPath = detailModel.getThumbnailPath();
            if (StringUtils.isNotBlank(thumbnailPath)) {
	            String fileExtension = "." + FilenameUtils.getExtension(thumbnailPath);
	            imagePath = resourcePage.getPath() + "." + ResourceThumbnailServlet.THUMBNAIL_IMAGE_SELECTOR +
	            		JhiConstants.ACCESS_SELECTOR_PLACEHOLDER + fileExtension;
            }
        }
        return imagePath;
    }

    public SimpleLink getCategoryLink() {
        return categoryLink;
    }
    
    public ResourceDetailModel getDocument() {
        return document;
    }
}
