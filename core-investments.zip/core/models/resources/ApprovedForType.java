package com.jhi.aem.website.v1.core.models.resources;

import org.apache.commons.lang3.StringUtils;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

public enum ApprovedForType {
    INVESTORS("Approved for use with investors"),
    FINANCIAL_PROFESSIONAL("For financial professional use only"),
    INSTITUTIONAL("For institutional use only");

    private String text;

    ApprovedForType(String text) {
        this.text = text;
    }

    public static ApprovedForType getByName(String name) {
        if (StringUtils.isNotBlank(name)) {
            for (ApprovedForType itemType : ApprovedForType.values()) {
                if (StringUtils.equalsIgnoreCase(name.replace(JhiConstants.DASH, JhiConstants.UNDERSCORE), itemType.name())) {
                    return itemType;
                }
            }
        }
        return null;
    }

    public String getText() {
        return text;
    }
}
