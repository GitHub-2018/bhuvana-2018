package com.jhi.aem.website.v1.core.models.resources;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

public class SyntheticResourceDetailModel extends ResourceDetailModel {

    private static final long serialVersionUID = 1L;

    public static final SyntheticResourceDetailModel EMPTY = new SyntheticResourceDetailModel();

    private String title;
    private String summary;
    private Boolean orderable;
    private String access;
    private String documentType;
    private String assetPath;

    private Resource resource;
    private Page resourcePage;

    private String pagePath;
    private String resourcePath;
    private String pageLink;
    private String resourceThumbnailPath;

    public SyntheticResourceDetailModel() {
    }

    public SyntheticResourceDetailModel(Page page, boolean isDocument) {
        if (page == null || page.getContentResource() == null) {
            return;
        }

        this.resourcePage = page;
        this.resource = page.getContentResource();

        final ValueMap props = this.resource.getValueMap();
        this.access = props.get("access", String.class);
        this.documentType = props.get("documentType", String.class);
        if (isDocument) {
            initDocumentProps(props);
        } else {
            initBaseProps(props);
        }

        if (StringUtils.isBlank(title)) {
            title = PageUtil.getPageNavigationTitle(resourcePage);
        }

        pagePath = PageUtil.getPagePath(resourcePage);
        pageLink = LinkUtil.getLink(PageUtil.getResourceResolver(resourcePage), pagePath);
        resourcePath = resource == null ? StringUtils.EMPTY : resource.getPath();
    }

    private void initDocumentProps(ValueMap props) {
        this.title = StringUtils.defaultString(props.get("document/title", String.class));
        this.summary = StringUtils.defaultString(props.get("document/description", String.class));
        this.orderable = props.get("document/orderable", Boolean.FALSE);
        this.assetPath = StringUtils.defaultString(props.get("document/assetPath", String.class));
    }

    private void initBaseProps(ValueMap props) {
        this.title = StringUtils.defaultString(props.get("title", String.class), props.get("jcr:title", String.class));
        this.summary = StringUtils.defaultString(props.get("summary", String.class), props.get("text", String.class));
        this.orderable = props.get("orderable", Boolean.class);
        this.assetPath = StringUtils.EMPTY;
    }

    public String getResourceThumbnailPath() {
        return resourceThumbnailPath;
    }

    public String getThumbnailPath() {
        return StringUtils.EMPTY;
    }

    public String getTitle() {
        return title;
    }

    public String getSummary() {
        return summary;
    }

    public String getPagePath() {
        return pagePath;
    }

    public String getPageLink() {
        return pageLink;
    }

    public String getAssetPath() {
        return assetPath;
    }

    public String getMoreLabel() {
        return StringUtils.EMPTY;
    }

    public boolean isOrderable() {
        return Boolean.TRUE.equals(orderable);
    }

    public boolean isPublic() {
        return StringUtils.equals(access, JhiConstants.ACCESS_PUBLIC);
    }

    public boolean isExclusive() {
        return StringUtils.equals(access, JhiConstants.ACCESS_EXCLUSIVE);
    }

    public String getDocumentPath() {
        return resourcePath;
    }

    public String getDocumentType() {
        return documentType;
    }

    public boolean isValid() {
        return StringUtils.isNotEmpty(resourcePath) && StringUtils.isNotBlank(getTitle())
                && StringUtils.isNotBlank(getSummary());
    }
    
    public boolean isValidInUcits() {
        return StringUtils.isNotEmpty(resourcePath) && StringUtils.isNotBlank(getTitle());
    }

    public static SyntheticResourceDetailModel fromResourcePage(Page resourcePage) {
        if (PageUtil.isExactResourceType(resourcePage, ResourcesConstants.RESOURCE_DOCUMENT_PAGE_RESOURCE_TYPE)) {
            return new SyntheticResourceDetailModel(resourcePage, true);
        } else if (PageUtil.isResourceType(resourcePage, ResourcesConstants.RESOURCE_PAGE_RESOURCE_TYPE)) {
            return new SyntheticResourceDetailModel(resourcePage, false);
        } else {
            return EMPTY;
        }
    }
}
