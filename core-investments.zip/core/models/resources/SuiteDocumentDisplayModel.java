package com.jhi.aem.website.v1.core.models.resources;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.document.ProductDocumentModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;
import com.jhi.aem.website.v1.core.utils.ResourceDocumentUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SuiteDocumentDisplayModel {
	
	private static final Logger LOG = LoggerFactory.getLogger(SuiteDocumentDisplayModel.class);

	@Inject
    @Via("resource")
    @Default
    private String title;

    @Inject
    @Via("resource")
    @Default
    private String text;

    @Inject
    @Via("resource")
    @Default
    private String productPath;

    @Self
    private SlingHttpServletRequest request;

    private ProductDocumentModel document;
	private String documentTitle = StringUtils.EMPTY;
	private String thumbnailPath = StringUtils.EMPTY;
	private String documentPath = StringUtils.EMPTY;
	private boolean isResourcePageAvailable = false;
	private String resourcePageLink = StringUtils.EMPTY;
	private String firmSelector;
	private String accessSelector;
	private RrdProductImpl product = null;
	private String cartPageLink;

    @PostConstruct
    protected void init() {
		firmSelector = RequestUtil.getFirmSelector(request);
		accessSelector = RequestUtil.getAccessSelector(request);
		Resource resource = request.getResource();
		ResourceResolver resourceResolver = request.getResourceResolver();
		
		// Resolve the cart page
		Page cartPage = PageUtil.getSitePageByResourceType(PageUtil.getContainingPage(resource),
			 ResourcesConstants.CART_PAGE_RESOURCE_TYPE);
		cartPageLink = LinkUtil.getPageLink(request.getResourceResolver(), cartPage);

		// Resolve the product
		if (StringUtils.isNotBlank(productPath)) {
	        Resource productResource = resourceResolver.getResource(productPath);
	        if (productResource != null) {
	            product = new RrdProductImpl(productResource);
	        }
	
	        document = resource.adaptTo(ProductDocumentModel.class);
	
	        if (document != null) {
	        	documentTitle = document.getProductTitle();
				thumbnailPath = LinkUtil.getLink(resourceResolver, document.getThumbnailPath());
	        	documentPath = LinkUtil.getLink(resourceResolver, document.getPath());
	        	resourcePageLink = LinkUtil.getLink(resourceResolver, document.getResourcePagePath());
	        	isResourcePageAvailable = StringUtils.isNotBlank(document.getResourcePagePath())
	                    && resourceResolver.getResource(document.getResourcePagePath()) != null;
	        }
	    }
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getDocumentTitle() {
        return documentTitle;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }

    public String getDocumentPath() {
        return documentPath;
    }

    public boolean isOrderable() {
        return document != null && document.isOrderable();
    }

    public boolean isResourcePageAvailable() {
        return isResourcePageAvailable;
    }

    public String getResourcePageLink() {
        return resourcePageLink;
    }

    public boolean isBlank() {
        return StringUtils.isAnyBlank(text, title) || document == null;
    }

    public String getCartPageLink() {
        return cartPageLink;
    }

    public String getEFormLink() {
        if (product != null) {
            return product.getElectronicFormLink();
        }
        return null;
    }

    public boolean isAddToCartPossible() {
        return ResourceDocumentUtil.isAddToCartPossible(product, firmSelector, accessSelector);
    }

    public boolean isAccessible() {
    	if (LOG.isDebugEnabled()) {
    		LOG.debug("isAccessible: {} ('{}', {}, {})", 
    				new Object[] {ResourceDocumentUtil.isAccessible(product, firmSelector, accessSelector),
    						request.getRequestPathInfo().getResourcePath(), firmSelector, accessSelector});
    	}
        return ResourceDocumentUtil.isAccessible(product, firmSelector, accessSelector);
    }

    public boolean isAdvisorAccess() {
    	if (LOG.isDebugEnabled()) {
    		LOG.debug("isAdvisorAccess: {} ('{}', {}, {})", 
    				new Object[] {ResourceDocumentUtil.isAdvisorAccess(product, accessSelector),
    						request.getRequestPathInfo().getResourcePath(), firmSelector, accessSelector});
    	}
    	return ResourceDocumentUtil.isAdvisorAccess(product, accessSelector);
    }

    public boolean isExclusive() {
    	if (LOG.isDebugEnabled()) {
    		LOG.debug("isExclusive: {} ('{}', {}, {})", 
    				new Object[] {ResourceDocumentUtil.isExclusive(product, accessSelector),
    						request.getRequestPathInfo().getResourcePath(), firmSelector, accessSelector});
    	}
    	return ResourceDocumentUtil.isExclusive(product, accessSelector);
    }

    public boolean isLocked() {
    	if (LOG.isDebugEnabled()) {
    		LOG.debug("isLocked: {} ('{}', {}, {})", 
    				new Object[] {ResourceDocumentUtil.isLocked(product, firmSelector, accessSelector),
    						request.getRequestPathInfo().getResourcePath(), firmSelector, accessSelector});
    	}
    	return ResourceDocumentUtil.isLocked(product, firmSelector, accessSelector);
    }

}
