package com.jhi.aem.website.v1.core.models.resources;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.resources.ResourcesService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.utils.RequestUtil;



import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PopularResourcesModel {
    private static final Logger LOGGER = LoggerFactory.getLogger(PopularResourcesModel.class);
    private static final int MAX_ITEMS = 3;

    private static final String RESOURCES_CONTENT_SELECTOR = "resourcesContent";
    private static final String RESOURCES_CONTENT_SELECTOR_PATH = "." + RESOURCES_CONTENT_SELECTOR + JhiConstants.ACCESS_SELECTOR_PLACEHOLDER
            + JhiConstants.URL_HTML_EXTENSION;

    private List<ResourceDetailModel> forms;
    private List<ResourceDetailModel> business;
    private List<ResourceDetailModel> education;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    @Self
    private SlingHttpServletRequest request;

    @OSGiService
    private ResourcesService resourcesService;

    @OSGiService
    private UserProfileService userProfileService;

    @PostConstruct
    protected void init() {
        String[] selectors = request.getRequestPathInfo().getSelectors();
        if (ArrayUtils.contains(selectors, RESOURCES_CONTENT_SELECTOR)) {
            forms = getResources(ResourceCategoryType.FORMS);
            business = getResources(ResourceCategoryType.BUSINESS);
            education = getResources(ResourceCategoryType.EDUCATION);
        }
    }

    public List<ResourceDetailModel> getForms() {
        return forms;
    }

    public List<ResourceDetailModel> getBusiness() {
        return business;
    }

    public List<ResourceDetailModel> getEducation() {
        return education;
    }

    private List<ResourceDetailModel> getResources(ResourceCategoryType resourceCategory) {
        String firmSelector = RequestUtil.getFirmSelector(request);
        String accessSelector = RequestUtil.getAccessSelector(request);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Getting popular resources for path={}, resource type={}, firm selector={}",
                    new Object[]{resourcePage.getPath(), resourceCategory, firmSelector});
        }
        return resourcesService.getPopularResources(resourceResolver, resourcePage.getPath(), resourceCategory, accessSelector,
                firmSelector, MAX_ITEMS);
    }

    public String getContentPath() {
        return resourceResolver.map(request.getResource().getPath()) + RESOURCES_CONTENT_SELECTOR_PATH;
    }
}
