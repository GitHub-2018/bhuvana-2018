package com.jhi.aem.website.v1.core.models.resources;

import java.util.List;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SuiteDocumentsModel {

    private static final String DOCUMENTS_SELECTOR_PART = JhiConstants.DOT + JhiConstants.DOWNLOAD_SELECTOR + JhiConstants.DOT
            + JhiConstants.ZIP_EXTENSION;
    @Inject
    @Optional
    private List<SuiteDocumentModel> documents;

    @Inject
    private Resource resource;

    public List<SuiteDocumentModel> getDocuments() {
        return documents;
    }

    public boolean isNotEmpty() {
        return (documents != null && !documents.isEmpty());
    }

    public String getDownloadLink() {
        return resource.getResourceResolver().map(resource.getPath() + DOCUMENTS_SELECTOR_PART);
    }
}
