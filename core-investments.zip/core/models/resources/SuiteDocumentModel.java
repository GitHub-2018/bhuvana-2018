package com.jhi.aem.website.v1.core.models.resources;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.document.ProductDocumentModel;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SuiteDocumentModel {

    private static final String ACTIONS_CONTENT_SELECTOR = "suiteDocumentDisplay";
    private static final String SUITE_DOCUMENT_DISPLAY_PATH = JhiConstants.DOT + ACTIONS_CONTENT_SELECTOR
            + JhiConstants.ACCESS_SELECTOR_PLACEHOLDER + JhiConstants.URL_HTML_EXTENSION;

	@Inject
    @Default
    private String title;

    @Inject
    @Default
    private String text;

    @Self
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

	private String suiteDocumentDisplayPath;

    @PostConstruct
    protected void init() {
        suiteDocumentDisplayPath = resourceResolver.map(resource.getPath()) + SUITE_DOCUMENT_DISPLAY_PATH;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public boolean isBlank() {
        return StringUtils.isAnyBlank(text, title);
    }

	public String getSuiteDocumentDisplayPath() {
		return suiteDocumentDisplayPath;
	}

	public void setSuiteDocumentDisplayPath(String suiteDocumentDisplayPath) {
		this.suiteDocumentDisplayPath = suiteDocumentDisplayPath;
	}
	
	public ProductDocumentModel asProductDocumentModel() {
		return resource.adaptTo(ProductDocumentModel.class);
	}

}
