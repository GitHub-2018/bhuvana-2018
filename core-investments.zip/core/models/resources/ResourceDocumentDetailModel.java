package com.jhi.aem.website.v1.core.models.resources;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.injectors.qualifiers.TargetResourceTypes;

@Model(adaptables = Resource.class, adapters = ResourceDetailModel.class)
@TargetResourceTypes(ResourcesConstants.RESOURCE_DOCUMENT_PAGE_RESOURCE_TYPE)
public class ResourceDocumentDetailModel extends ResourceDetailModel {

	public static final ResourceDocumentDetailModel EMPTY = new ResourceDocumentDetailModel();

    private static final String DOCUMENT_PATH = "/document";
	private static final long serialVersionUID = 1L;

    @Inject
    @Optional
    private ResourceDocumentModel document;

    @Override
    public String getTitle() {
        if (document != null) {
            return document.getTitle();
        }
        return StringUtils.EMPTY;
    }

    @Override
    public String getSummary() {
        if (document != null) {
            return document.getDescription();
        }
        return StringUtils.EMPTY;
    }

    @Override
    public String getThumbnailPath() {
        if (document == null) {
            return StringUtils.EMPTY;
        }
        return document.getThumbnailPath();
    }

    @Override
    public String getAssetPath() {
        if (document == null) {
            return StringUtils.EMPTY;
        }
        return document.getAssetPath();
    }

    @Override
    public String getMoreLabel() {
        return "View document";
    }

    @Override
    public boolean isOrderable() {
        return document.isOrderable();
    }

    @Override
    public String getDocumentPath() {
        return resource.getPath() + DOCUMENT_PATH;
    }
    
    @Override
    public String toString() {
    	return ReflectionToStringBuilder.toString(this);
    }
 
    public static ResourceDocumentDetailModel fromPage(Page page) {
        if (page != null) {
            Resource contentResource = page.getContentResource();
            if (contentResource != null) {
                return contentResource.adaptTo(ResourceDocumentDetailModel.class);
            }
        }
        return EMPTY;
    }
}