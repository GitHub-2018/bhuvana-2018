package com.jhi.aem.website.v1.core.models.resources;

import java.util.List;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ResourcePageModel {

    @Inject
    private String category;

    @Inject
    private List<String> topics;

    @Inject
    private List<String> audiences;

    @Inject
    private String documentType;

    public String getCategory() {
        return category;
    }

    public List<String> getTopics() {
        return topics;
    }

    public List<String> getAudiences() {
        return audiences;
    }

    public String getDocumentType() {
        return documentType;
    }
}
