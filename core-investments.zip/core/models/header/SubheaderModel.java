package com.jhi.aem.website.v1.core.models.header;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.generic.link.AnalyticsLink;
import com.jhi.aem.website.v1.core.generic.link.LinkUtils;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SubheaderModel {
	
	private final static Logger LOG = LoggerFactory.getLogger(SubheaderModel.class);

	private static final String LABEL_PROP_NAME = "label";

	private static final String LINK_PROP_NAME = "navigation";

    @Inject
    @Via("resource")
    @Default
    private String title;
    
    //Fix for AU-99 . As per new multifield , the values will be added to subnodes
    //under subHeaders node
    @Inject
    @Via("resource")
    @Default
    private Resource subHeaders;
    
   
    private String[] subheaderLabels;

    private String[] subheaderLinks;
    
    @Inject
    @Via("resource")
    @Default
    private String subheaderNavOnClick;
    
    @Inject
    @Via("resource")
    @Default
    private int subheaderNavigationStartEventId;

    @Self
    private SlingHttpServletRequest request;


    @Inject
    private Page currentPage;

    @OSGiService
    private ResourceResolverFactory resolverFactory;

    private List<AnalyticsLink> subheaderNav;

    @PostConstruct
    protected void init() {
        String currentPagePath = StringUtils.EMPTY;
        if (currentPage != null) {
            currentPagePath = currentPage.getPath();
        }

        String countryFilterParameter = PageUtil.getUcitsCountry(request);

    	//Fix for AU -99 
        //The existing createNavigation method is used in many classes and so we will not chnage the logic of this class
        //Instead we will fetch the subheaderLinks and subheaderLabels into string[] and supply it.
		if (null != subHeaders && subHeaders.hasChildren()) {
			Iterable<Resource> children = subHeaders.getChildren();
			subheaderLabels = getPropertyStringArray(children, LABEL_PROP_NAME);
			subheaderLinks = getPropertyStringArray(children, LINK_PROP_NAME);
			LOG.debug("Subheader Links are {} ", subheaderLinks.toString());
			LOG.debug("Subheader Labels are {} ", subheaderLabels.toString());
			if (null != subheaderLabels && null != subheaderLinks) {
				subheaderNav = LinkUtils.createNavigation(request, resolverFactory, subheaderNavOnClick,
						subheaderNavigationStartEventId, subheaderLabels, subheaderLinks, currentPagePath, countryFilterParameter);
			}
		}
    }

    //Fix AU 99
    //Get the property values from all the child nodes and return as a string array
	private String[] getPropertyStringArray(Iterable<Resource> children, String propertyName) {
		List<String> values = new ArrayList<>();
		try {
			for (Resource child : children) {
				ValueMap headerProperties = child.getValueMap();
				LOG.debug("Properties of the child is {}" , headerProperties);
                String propertyValue = headerProperties.get(propertyName, StringUtils.EMPTY);
                values.add(propertyValue);
			}
			
		} catch (Exception e) {
			LOG.error("Exception while fetching properties", e);
		}
		
		return values.toArray(new String[values.size()]);
	}

    public String getTitle() {
    	return title;
    }
    
    public List<AnalyticsLink> getSubheaderNav() {
    	
        return (null != subheaderNav ? subheaderNav: new ArrayList<>());
    }
    
    public boolean isBlank() {
    	return StringUtils.isBlank(title) && getSubheaderNav().isEmpty();
    }
}
