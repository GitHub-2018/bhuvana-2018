package com.jhi.aem.website.v1.core.models.header;

public class NavigationEntry {
    private String title;
    private String path;

    public String getTitle() {
        return title;
    }

    public String getPath() {
        return path;
    }
}
