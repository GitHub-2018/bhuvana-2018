package com.jhi.aem.website.v1.core.models.header;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.crypto.CryptoException;
import com.adobe.granite.crypto.CryptoSupport;
import com.jhi.aem.website.v1.core.generic.link.LinkUtils;
import com.jhi.aem.website.v1.core.utils.UserUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HtmlEditModel {

    @Inject
    @Via("resource")
    @Optional
	private Boolean enabled;
	
    @Inject
    @Via("resource")
    @Default(values = "")
	private String html;
    
    @Inject
    private CryptoSupport cryptoSupport;
    
    @Self
    private SlingHttpServletRequest request;
    
    private String loggedInUser;
    
    private static final Logger LOG = LoggerFactory.getLogger(HtmlEditModel.class);

   
	public Boolean getEnabled() {
		return enabled == null ? Boolean.FALSE : enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public String getHtml() {
		return html;
	}

	public void setHtml(String html) {
		this.html = html;
	}
	
	public String getLoggedInUser() {
		LOG.info("Logged in User :" + loggedInUser);
		return loggedInUser;
	}
	
	@PostConstruct
	protected void init() {
		try {
			ResourceResolver resolver = request.getResourceResolver();
			Authorizable authorizable = UserUtil.getCurrentAuthorizable(resolver);
			loggedInUser = (authorizable != null) ? authorizable.getID() : null;
			LOG.info("Logged In user :" + loggedInUser);
			LOG.info("Check user is not blank :"+StringUtils.isNotBlank(loggedInUser));
			if (StringUtils.isNotBlank(loggedInUser)) {
				loggedInUser = cryptoSupport.protect(loggedInUser);
				LOG.info("Masked User :" + loggedInUser);
			}
			
		} catch (RepositoryException e) {
			LOG.info("Repository Exception "+ e.getMessage());
			e.printStackTrace();
		}
		catch(CryptoException e) {
			LOG.info("Crypto Exception "+ e.getMessage());
			e.printStackTrace();
		}
    }

}

