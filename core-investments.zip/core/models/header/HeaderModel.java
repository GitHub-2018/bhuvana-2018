package com.jhi.aem.website.v1.core.models.header;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.generic.link.AnalyticsLink;
import com.jhi.aem.website.v1.core.generic.link.LinkUtils;
import com.jhi.aem.website.v1.core.models.html.AbstractHtmlEditableModel;
import com.jhi.aem.website.v1.core.service.html.HtmlComponentEditService;
import com.jhi.aem.website.v1.core.servlets.suggestion.SuggestionServlet;
import com.jhi.aem.website.v1.core.servlets.user.UserInfoServlet;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HeaderModel extends AbstractHtmlEditableModel {

    private static final String USER_INFO_SELECTOR_PART = JhiConstants.DOT + UserInfoServlet.USER_INFO_SELECTOR
            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
    private static final String LOGIN_MAIN_PARAGRAPH_PATH = "/jcr:content/mainParagraph";
    private static final String DEFAULT_UCITS_GATEWAY_PATH = "/content/jhi-website/en/ucits-international-gateway";
    private static final Logger LOG = LoggerFactory.getLogger(HeaderModel.class);

    @Inject
    @Via("resource")
    @Default
    private String logoAlt;

    @Inject
    @Via("resource")
    @Default
    private String customlogoImageLink;

    @Inject
    @Via("resource")
    @Default
    private String siteLogoLink;

    @Inject
    @Via("resource")
    @Default
    private String searchResultsPage;

    @Inject
    @Via("resource")
    @Default
    private String primaryNavOnClick;

    @Inject
    @Via("resource")
    @Default
    private String secondaryNavOnClick;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> primaryNavigationNames;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> primaryNavigation;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> primaryNavigationIcons;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> secondaryNavigationNames;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> secondaryNavigation;

    @Inject
    @Via("resource")
    @Default
    private int primaryNavigationStartEventId;

    @Inject
    @Via("resource")
    @Default
    private int secondaryNavigationStartEventId;

    @Self
    private SlingHttpServletRequest request;

    @Inject
    @Via("resource")
    @Optional
    private Resource htmlEdit;

    @Inject
    @Via("resource")
    @Optional
    private Boolean ucitsModalDisabled;

    @Inject
    @Via("resource")
    @Optional
    private String ucitsTitle;

    @Inject
    @Via("resource")
    @Optional
    private String ucitsSubtitle;

    @Inject
    @Via("resource")
    @Optional
    private String ucitsTermsAndConditions;

    @Inject
    @Via("resource")
    @Optional
    private String ucitsReturnButtonText;

    @Inject
    @Via("resource")
    @Optional
    private String ucitsSiteLink;

    @Inject
    @Via("resource")
    @Optional
    private String ucitsSiteLinkText;

    @Inject
    private Page resourcePage;

    @Inject
    private Page currentPage;

    @Inject
    private PageManager pageManager;

    @Inject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    @ValueMapValue
    private String ucitsGatePath;
    
    private HtmlEditModel  htmlEditModel;

    private Page profilePage;
    private Page literaturePage;
    private Page cartPage;
    private Page searchPage;

    @OSGiService
    private HtmlComponentEditService htmlComponentEditService;

    @OSGiService
    private ResourceResolverFactory resolverFactory;

    private List<AnalyticsLink> primaryNav;

    private List<AnalyticsLink> secondaryNav;

    @Override
    public HtmlEditModel getHtmlEditModel() {
    	htmlEditModel = new HtmlEditModel();
    	htmlEditModel.setEnabled(htmlEdit.getValueMap().get("enabled", false));
    	htmlEditModel.setHtml(htmlEdit.getValueMap().get("html", ""));
        return htmlEditModel;
    }

    @PostConstruct
    protected void init() {
    	String countryFilterParameter = PageUtil.getUcitsCountry(request);
        searchPage = getSearchPage();
        String currentPagePath = StringUtils.EMPTY;

        if (currentPage != null) {
            currentPagePath = currentPage.getPath();
        }

        primaryNav = LinkUtils.createNavigation(request, resolverFactory, primaryNavOnClick, primaryNavigationStartEventId,
                primaryNavigationNames, primaryNavigation, primaryNavigationIcons, currentPagePath, countryFilterParameter);
        secondaryNav = LinkUtils.createNavigation(request, resolverFactory, secondaryNavOnClick, secondaryNavigationStartEventId,
                secondaryNavigationNames, secondaryNavigation, null, currentPagePath, countryFilterParameter);
        htmlEditModel = initialiseHtmlEdit(request, resource, htmlComponentEditService, DEFAULT_HTML_EDIT_RESOURCE_PATH);
    }

    public String getLogoAlt() {
        return logoAlt;
    }

    public String getCustomlogoImageLink() {
        return customlogoImageLink;
    }

    public String getSiteLogoLink() {
        if (StringUtils.isNotBlank(siteLogoLink)) {
            return LinkUtil.getLink(siteLogoLink);
        }
        return LinkUtil.getPageLink(PageUtil.getHomePage(resourcePage), currentPage);
    }

    public String getDashboardPageLink() {
        return LinkUtil.getPageLink(getDashboardPage(), currentPage);
    }

    public Page getDashboardPage() {
        if (profilePage == null) {
            profilePage = PageUtil.getSitePageByResourceType(resourcePage,
                    ResourcesConstants.DASHBOARD_PAGE_RESOURCE_TYPE);
        }
        return profilePage;
    }

    public String getLiteraturePageLink() {
        return LinkUtil.getPageLink(getLiteraturePage(), currentPage);
    }

    public String getLiteratureTitle() {
        return PageUtil.getPageNavigationTitle(getLiteraturePage());
    }

    private Page getLiteraturePage() {
        if (literaturePage == null) {
            Page resourcesMainPage = PageUtil.getSitePageByResourceType(resourcePage,
                    ResourcesConstants.RESOURCES_PAGE_RESOURCE_TYPE);
            if (resourcePage != null) {
                literaturePage = PageUtil.getChildByResourceType(resourcesMainPage,
                        ResourcesConstants.RESOURCES_LIST_PAGE_RESOURCE_TYPE);
            }
        }
        return literaturePage;
    }

    private Page getCartPage() {
        if (cartPage == null) {
            cartPage = PageUtil.getSitePageByResourceType(resourcePage, ResourcesConstants.CART_PAGE_RESOURCE_TYPE);
        }
        return cartPage;
    }

    public String getCartLink() {
        return LinkUtil.getPageLink(getCartPage(), currentPage);
    }

    public String getCartTitle() {
        return PageUtil.getPageNavigationTitle(getCartPage());
    }

    public boolean isSearchAvailable() {
        return StringUtils.isNoneBlank(searchResultsPage) && (getSearchPage() != null);
    }

    public Page getSearchPage() {
        if (searchPage == null) {
            searchPage = pageManager.getPage(searchResultsPage);
        }
        return searchPage;
    }

    public List<AnalyticsLink> getPrimaryNav() {
        return primaryNav;
    }

    public void setPrimaryNav(List<AnalyticsLink> primaryNav) {
        this.primaryNav = primaryNav;
    }

    public List<AnalyticsLink> getSecondaryNav() {
        return secondaryNav;
    }

    public void setSecondaryNav(List<AnalyticsLink> secondaryNav) {
        this.secondaryNav = secondaryNav;
    }

    public String getPrimaryNavOnClick() {
        return primaryNavOnClick;
    }

    public void setPrimaryNavOnClick(String primaryNavOnClick) {
        this.primaryNavOnClick = primaryNavOnClick;
    }

    public String getSecondaryNavOnClick() {
        return secondaryNavOnClick;
    }

    public void setSecondaryNavOnClick(String secondaryNavOnClick) {
        this.secondaryNavOnClick = secondaryNavOnClick;
    }

    public String getUserInfoPath() {
        return resource.getResourceResolver().map(resource.getPath()) + USER_INFO_SELECTOR_PART;
    }

    public String getSearchPageLink() {
        if (searchPage == null) {
            return StringUtils.EMPTY;
        }
        return resourceResolver.map(LinkUtil.getPageLink(searchPage));
    }

    public boolean isSuggestionsAvailable() {
        return PageUtil.isExactResourceType(searchPage, ResourcesConstants.SEARCH_PAGE_RESOURCE_TYPE);
    }

    public String getSuggestionLink() {
        if (isSuggestionsAvailable()) {
            return resourceResolver.map(SuggestionServlet.getServletPath(searchPage.getPath()));
        }
        return StringUtils.EMPTY;
    }

    public String getCurrentPageLink() {
        return LinkUtil.getPageLink(currentPage);
    }

    public String getLoginFormPath() {
        Page homePage = PageUtil.getHomePage(resourcePage);
        Page loginPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants.LOGIN_PAGE_RESOURCE_TYPE);
        if (loginPage != null) {
            Resource mainParagraph = resourceResolver.getResource(loginPage.getPath() + LOGIN_MAIN_PARAGRAPH_PATH);
            if (mainParagraph != null) {
                for (Resource child : mainParagraph.getChildren()) {
                    if (child.isResourceType(ResourcesConstants.LOGIN_SECTION_RESOURCE_TYPE)) {
                        return resourceResolver.map(child.getPath() + JhiConstants.URL_HTML_EXTENSION);
                    }
                }
            }
        }
        return StringUtils.EMPTY;
    }

    public String getUcitsTitle() {
        return ucitsTitle;
    }

    public String getUcitsSubtitle() {
        return ucitsSubtitle;
    }

    public String getUcitsTermsAndConditions() {
        return ucitsTermsAndConditions;
    }

    public String getUcitsReturnButtonText() {
        return ucitsReturnButtonText;
    }

    public String getUcitsSiteLink() {
        return ucitsSiteLink;
    }

    public String getUcitsSiteLinkText() {
        return ucitsSiteLinkText;
    }

    public Boolean getUcitsModalDisabled() {
        return BooleanUtils.isTrue(ucitsModalDisabled);
    }

    public String getUcitsGatePath() {
        String ucitsPath = java.util.Optional.ofNullable(ucitsGatePath)
                .orElse(DEFAULT_UCITS_GATEWAY_PATH);
        LOG.debug("ucitsPath: {}", ucitsPath);
        String link = LinkUtil.getLink(ucitsPath);
        LOG.debug("ucits link: {}", link);
        String mappedLink = resourceResolver.map(link);
        LOG.debug("mappedLink: {}", mappedLink);
        return mappedLink;
    }

    public String getHomePageLink() {
        return LinkUtil.getPageLink(resourceResolver, PageUtil.getHomePage(resourcePage));
    }

}
