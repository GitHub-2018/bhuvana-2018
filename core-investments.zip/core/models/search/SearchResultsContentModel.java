package com.jhi.aem.website.v1.core.models.search;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.QueryBuilder;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.generic.link.Link;
import com.jhi.aem.website.v1.core.generic.pagination.Pagination;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.service.pressrelease.PressReleaseService;
import com.jhi.aem.website.v1.core.service.resources.ResourcesService;
import com.jhi.aem.website.v1.core.service.search.ContentSearchService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;
import com.jhi.aem.website.v1.core.utils.TextUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SearchResultsContentModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(SearchResultsContentModel.class);

    private static final String CATEGORY_CONTENT_SELECTOR = "categoryContent";

    private CategoryType category;

    private SearchResultsItems searchResultsItems;

    private static final String QUERY_PARAMETER = "query";
    private static final String FORMAT_SELECTOR_PREFIX = "format";

    private static final List<ViewpointType> STANDARD_FORMATS = Arrays.asList(ViewpointType.values());

    private static final String PAGINATION_PATH_PATTERN = "%s." + CATEGORY_CONTENT_SELECTOR + "%s" + "%s" + JhiConstants
            .URL_HTML_EXTENSION + JhiConstants.SLASH + "%s" + JhiConstants.SLASH;

    protected Pagination pagination;
    protected int pageNumber;

    @Self
    protected SlingHttpServletRequest request;

    @OSGiService
    protected ContentSearchService contentSearchService;

    @OSGiService
    protected FundService fundService;

    @OSGiService
    protected ResourcesService resourcesService;

    @OSGiService
    protected AssetManagerService assetManagerService;

    @OSGiService
    protected ViewpointsService viewpointsService;

    @OSGiService
    private UserProfileService userProfileService;

    @OSGiService
    private PressReleaseService pressReleaseService;

    @OSGiService
    private QueryBuilder queryBuilder;

    private String formatSelector;
    private List<ViewpointType> formats;
    protected String originalQuery;
    protected String queryText;
    private String firmSelector = null;
    protected String accessSelector = null;
    private String resourcesRootPath = null;

    @PostConstruct
    protected void init() {
        prepareQueryText();
        prepareFormats();
        parseParameters();
        prepareResults();
        preparePagination();
    }

    public boolean isTopResults() {
        return category == CategoryType.TOP_RESULTS;
    }

    public boolean isInvestments() {
        return category == CategoryType.INVESTMENTS;
    }

    public boolean isResources() {
        return category == CategoryType.RESOURCES;
    }

    public boolean isAssetManagers() {
        return category == CategoryType.ASSET_MANAGERS;
    }

    public boolean isViewpoints() {
        return category == CategoryType.VIEWPOINTS;
    }

    public boolean isFundDocuments() {
        return category == CategoryType.FUND_DOCUMENTS;
    }

    public boolean isPressReleases() {
        return category == CategoryType.PRESS_RELEASES;
    }

    public SearchResultsItems getResults() {
        return searchResultsItems;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public String getOriginalQuery() {
        return originalQuery;
    }

    public String getQueryText() {
        return queryText;
    }

    public String getEncodedQuery() {
        try {
            return URLEncoder.encode(queryText, JhiConstants.DEFAULT_CHARSET_NAME);
        } catch (UnsupportedEncodingException e) {
            LOGGER.error("Cannot encode query text " + queryText, e);
        }
        return StringUtils.EMPTY;
    }

    private void parseParameters() {
        String suffix = RequestUtil.getSuffix(request);
        category = CategoryType.TOP_RESULTS;
        pageNumber = 1;
        if (StringUtils.isNotBlank(suffix)) {
            String[] parts = StringUtils.split(suffix, JhiConstants.SLASH);
            if (parts.length > 0) {
                CategoryType resolvedCategory = CategoryType.getByName(parts[0]);
                if (resolvedCategory != null) {
                    category = resolvedCategory;
                }
            }
            if (parts.length > 1) {
                pageNumber = Pagination.getPageNumber(parts[1]);
            }
        }
    }

    private void prepareResults() {
        ResourceResolver resourceResolver = request.getResourceResolver();
        int offset = (pageNumber - 1) * SearchResultsItems.CATEGORY_MAX_RESULTS;
        int limit = SearchResultsItems.CATEGORY_MAX_RESULTS;
        switch (category) {
            case TOP_RESULTS:
                searchResultsItems = getTopResults(resourceResolver, offset, limit);
                break;
            case INVESTMENTS:
                searchResultsItems = getInvestmentsResults(resourceResolver, offset, limit);
                break;
            case RESOURCES:
                searchResultsItems = getResourcesResults(resourceResolver, offset, limit);
                break;
            case ASSET_MANAGERS:
                searchResultsItems = getAssetManagersResults(resourceResolver, offset, limit);
                break;
            case VIEWPOINTS:
                searchResultsItems = getViewpointsResults(resourceResolver, offset, limit);
                break;
            case FUND_DOCUMENTS:
                searchResultsItems = getFundDocumentsResults(resourceResolver, offset, limit);
                break;
            case PRESS_RELEASES:
                searchResultsItems = getPressReleasesResults(resourceResolver, offset, limit);
                break;
        }
    }

    protected void prepareFormats() {
        formatSelector = getFormatSelector();
        if (StringUtils.isBlank(formatSelector)) {
            formats = STANDARD_FORMATS;
        } else {
            String requestedFormats = StringUtils.removeStart(formatSelector, FORMAT_SELECTOR_PREFIX);
            formats = new ArrayList<>(requestedFormats.length());

            for (int i = 0; i < requestedFormats.length(); i++) {
                ViewpointType format = ViewpointType.getByFirstChar(requestedFormats.charAt(i));
                if (format != null) {
                    formats.add(format);
                }
            }
        }
    }

    protected String getFormatSelector() {
        for (String selector : request.getRequestPathInfo().getSelectors()) {
            if (StringUtils.startsWith(selector, FORMAT_SELECTOR_PREFIX)) {
                return selector;
            }
        }
        return StringUtils.EMPTY;
    }

    protected void prepareQueryText() {
        originalQuery = StringUtils.EMPTY;
        queryText = StringUtils.EMPTY;
        RequestParameter queryParameter = request.getRequestParameter(QUERY_PARAMETER);
        if (queryParameter != null) {
            originalQuery = StringUtils.defaultString(queryParameter.getString());
            queryText = TextUtil.getSanitizedQueryText(originalQuery);
        }
    }

    protected SearchResultsItems getTopResults(ResourceResolver resourceResolver, int offset, int maxItems) {
        String contentRootPath = StringUtils.EMPTY;
        final Page homePage = PageUtil.getHomePage(request.getResource());
        if (homePage != null) {
            contentRootPath = homePage.getPath();
        }
        return contentSearchService.getTopResults(resourceResolver, contentRootPath, queryText, getAccessSelector(),
                getFirmSelector(), offset, maxItems);
    }

    protected SearchResultsItems getInvestmentsResults(ResourceResolver resourceResolver, int offset, int maxItems) {
        final Page homePage = PageUtil.getHomePage(request.getResource());
        final Page fundsRoot = PageUtil.getSitePageByResourceType(homePage, ResourcesConstants.FUNDS_ROOT_PAGE_RESOURCE_TYPE);
        String fundsRootPath = fundsRoot != null ? fundsRoot.getPath() : homePage.getPath();
        return fundService.searchFunds(resourceResolver, fundsRootPath, queryText, offset, maxItems);
    }

    protected SearchResultsItems getResourcesResults(ResourceResolver resourceResolver, int offset, int maxItems) {
        return resourcesService.searchPlainResources(resourceResolver, getResourcesRootPath(), queryText, getAccessSelector(),
                getFirmSelector(), offset, maxItems);
    }

    protected SearchResultsItems getAssetManagersResults(ResourceResolver resourceResolver, int offset, int maxItems) {
        String assetManagersPath = PageUtil.getAssetManagersConfigRootPath(PageUtil.getContainingPage(request.getResource()));
        return assetManagerService.searchAssetManagers(resourceResolver, assetManagersPath, queryText, offset, maxItems);
    }

    protected SearchResultsItems getViewpointsResults(ResourceResolver resourceResolver, int offset, int maxItems) {
        String viewpointsPath = StringUtils.EMPTY;
        Page viewpointsMainPage = ViewpointUtil.getViewpointsMainPage(request.getResource());
        if (viewpointsMainPage != null) {
            viewpointsPath = viewpointsMainPage.getPath();
        }
        return viewpointsService.searchViewpoints(resourceResolver, viewpointsPath, queryText, offset, maxItems, formats);
    }

    protected SearchResultsItems getFundDocumentsResults(ResourceResolver resourceResolver, int offset, int maxItems) {
        return resourcesService.searchFundDocuments(resourceResolver, getResourcesRootPath(), queryText, getAccessSelector(),
                getFirmSelector(), offset, maxItems);
    }

    protected SearchResultsItems getPressReleasesResults(ResourceResolver resourceResolver, int offset, int maxItems) {
        String pressReleasesPath = StringUtils.EMPTY;
        final Page homePage = PageUtil.getHomePage(request.getResource());
        final Page aboutUsPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants.ABOUT_US_PAGE_RESOURCE_TYPE);
        if (aboutUsPage != null) {
            Page pressReleaseRoot = PageUtil.getChildByResourceType(aboutUsPage, ResourcesConstants.PRESS_RELEASES_ROOT_RESOURCE_TYPE);
            if (pressReleaseRoot != null) {
                pressReleasesPath = pressReleaseRoot.getPath();
            }
        }
        return pressReleaseService.searchPressReleases(resourceResolver, pressReleasesPath, queryText, offset, maxItems);
    }

    protected String getFirmSelector() {
        if (firmSelector == null) {
            firmSelector = RequestUtil.getFirmSelector(request);
        }
        return firmSelector;
    }

    protected String getAccessSelector() {
        if (accessSelector == null) {
            accessSelector = RequestUtil.getAccessSelector(request);
        }
        return accessSelector;
    }

    private String getResourcesRootPath() {
        if (resourcesRootPath == null) {
            resourcesRootPath = StringUtils.EMPTY;
            final Page homePage = PageUtil.getHomePage(request.getResource());
            final Page resourcesPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants.RESOURCES_PAGE_RESOURCE_TYPE);
            if (resourcesPage != null) {
                resourcesRootPath = resourcesPage.getPath();
            }
        }
        return resourcesRootPath;
    }

    public String getAccessPlaceholder() {
        return JhiConstants.ACCESS_SELECTOR_PLACEHOLDER;
    }

    private void preparePagination() {
        int totalMatches = searchResultsItems.getTotalMatches();
        int resultPages = (totalMatches + SearchResultsItems.CATEGORY_MAX_RESULTS - 1) / SearchResultsItems.CATEGORY_MAX_RESULTS;
        pagination = new Pagination(pageNumber, SearchResultsItems.CATEGORY_MAX_RESULTS, resultPages, totalMatches);
        String formatPart = StringUtils.EMPTY;
        if (StringUtils.isNotBlank(formatSelector)) {
            formatPart = JhiConstants.DOT + formatSelector;
        }
        String accessSelectorPart = StringUtils.EMPTY;
        if (StringUtils.isNotBlank(getAccessSelector())) {
            accessSelectorPart = JhiConstants.DOT + getAccessSelector();
        }
        if (StringUtils.isNotBlank(getFirmSelector())) {
            accessSelectorPart = JhiConstants.DOT + getFirmSelector();
        }
        String basePath = String.format(PAGINATION_PATH_PATTERN, request.getResource().getPath(), formatPart, accessSelectorPart,
                category.getParameterName());
        String queryStringPart = StringUtils.isBlank(request.getQueryString()) ? StringUtils.EMPTY : "?" + request.getQueryString();

        int lowerWidth = Math.min(pageNumber - 1, Pagination.MAX_PAGINATION_ITEMS / 2);
        int upperWidth = Math.min(resultPages - pageNumber, Pagination.MAX_PAGINATION_ITEMS / 2 - 1);

        int finalLowerWidth = lowerWidth + (Pagination.MAX_PAGINATION_ITEMS / 2 - upperWidth - 1);
        int finalUpperWidth = upperWidth + (Pagination.MAX_PAGINATION_ITEMS / 2 - lowerWidth);

        int paginationStart = Math.max(1, pageNumber - finalLowerWidth);
        int paginationStop = Math.min(resultPages, pageNumber + finalUpperWidth);

        boolean upperSeparator = false;
        if (paginationStart > 1) {
            paginationStart++;
            pagination.addSeparator();
        }
        if (resultPages > paginationStop) {
            paginationStop--;
            upperSeparator = true;
        }
        for (int i = paginationStart; i <= paginationStop; i++) {
            pagination.addLink(new Link(basePath + i + JhiConstants.URL_HTML_EXTENSION + queryStringPart, String.valueOf(i),
                    i == pageNumber));
        }
        if (upperSeparator) {
            pagination.addSeparator();
        }
    }
}
