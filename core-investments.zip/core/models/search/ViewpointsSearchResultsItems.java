package com.jhi.aem.website.v1.core.models.search;

public class ViewpointsSearchResultsItems extends SearchResultsItems {
    private int pageCount;
    private int documentCount;
    private int audioCount;
    private int videoCount;
    private int whitepaperCount;

    public ViewpointsSearchResultsItems() {
        super();
    }

    public ViewpointsSearchResultsItems(boolean isCategory) {
        super(isCategory);
        pageCount = 0;
        documentCount = 0;
        audioCount = 0;
        videoCount = 0;
        whitepaperCount = 0;
    }

    public int getTotalCount() {
        return pageCount + documentCount + audioCount + videoCount + whitepaperCount;
    }

    public int getPageCount() {
        return pageCount;
    }

    public int getDocumentCount() {
        return documentCount;
    }

    public int getAudioCount() {
        return audioCount;
    }

    public int getVideoCount() {
        return videoCount;
    }

    public int getWhitepaperCount() {
        return whitepaperCount;
    }

    public void addPage() {
        pageCount++;
    }

    public void addDocument() {
        documentCount++;
    }

    public void addAudio() {
        audioCount++;
    }

    public void addVideo() {
        videoCount++;
    }

    public void addWhitepaper() {
        whitepaperCount++;
    }
}
