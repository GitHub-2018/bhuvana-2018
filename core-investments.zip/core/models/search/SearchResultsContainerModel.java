package com.jhi.aem.website.v1.core.models.search;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SearchResultsContainerModel {

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page currentPage;

    private static final String RESULTS_SELECTOR = "resultsContent";
    private static final String RESULTS_CONTENT_PATH = JhiConstants.DOT + RESULTS_SELECTOR
            + JhiConstants.ACCESS_SELECTOR_PLACEHOLDER + JhiConstants.URL_HTML_EXTENSION;

    public String getResultsPath() {
        return request.getResourceResolver().map(currentPage.getPath() + JhiConstants.SLASH + JcrConstants.JCR_CONTENT)
                + RESULTS_CONTENT_PATH;
    }
}
