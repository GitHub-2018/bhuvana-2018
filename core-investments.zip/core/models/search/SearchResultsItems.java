package com.jhi.aem.website.v1.core.models.search;

import java.util.ArrayList;
import java.util.List;

public class SearchResultsItems {
    public static final int GENERAL_MAX_TOP_RESULTS = 1;
    public static final int CATEGORY_MAX_RESULTS = 10;
    public static final SearchResultsItems EMPTY = new SearchResultsItems();

    private List<Object> results;

    private int totalMatches;
    private int maxItems;

    public SearchResultsItems() {
        this(false);
    }

    public SearchResultsItems(boolean isCategory) {
        maxItems = isCategory ? CATEGORY_MAX_RESULTS : GENERAL_MAX_TOP_RESULTS;
        results = new ArrayList<>(maxItems);
    }

    public int getMoreCount() {
        return totalMatches - GENERAL_MAX_TOP_RESULTS;
    }

    public boolean isMoreAvailable() {
        return totalMatches > GENERAL_MAX_TOP_RESULTS;
    }

    public List<Object> getResults() {
        return results;
    }

    public int getTotalMatches() {
        return totalMatches;
    }

    public void addResult(Object item) {
        results.add(item);
    }

    public void setTotalMatches(int totalMatches) {
        this.totalMatches = totalMatches;
    }

    public int getMaxItems() {
        return maxItems;
    }
}
