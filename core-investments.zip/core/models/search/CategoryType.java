package com.jhi.aem.website.v1.core.models.search;

import org.apache.commons.lang3.StringUtils;

public enum CategoryType {
    TOP_RESULTS, INVESTMENTS, RESOURCES, ASSET_MANAGERS, VIEWPOINTS, FUND_DOCUMENTS, PRESS_RELEASES;

    public static final String UNDERSCORE = "_";

    public String getDisplayName() {
        return StringUtils.capitalize(StringUtils.lowerCase(StringUtils.replace(name(), UNDERSCORE, StringUtils
                .SPACE)));
    }

    public String getParameterName() {
        return StringUtils.lowerCase(name());
    }

    public static CategoryType getByName(String name) {
        if (StringUtils.isNotBlank(name)) {
            for (CategoryType itemType : CategoryType.values()) {
                if (StringUtils.equalsIgnoreCase(name, itemType.name())) {
                    return itemType;
                }
            }
        }
        return null;
    }
}
