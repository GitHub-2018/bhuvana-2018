package com.jhi.aem.website.v1.core.models.search;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SuggestionsSettingsModel {

    public static final SuggestionsSettingsModel EMPTY = new SuggestionsSettingsModel();
    private static final String SEARCH_RESULTS_PATH = "searchResults";

    @Inject
    @Default
    private String[] fundsCharts;

    @Inject
    @Default
    private String[] fundsDocuments;

    @Inject
    @Default
    private String[] investmentsViews;

    public String[] getFundsCharts() {
        return fundsCharts;
    }

    public String[] getFundsDocuments() {
        return fundsDocuments;
    }

    public String[] getInvestmentsViews() {
        return investmentsViews;
    }

    private boolean isIncluded(String[] keywordsArray, String term) {
        for (String keyword : keywordsArray) {
            if (StringUtils.containsIgnoreCase(keyword, term)) {
                return true;
            }
        }
        return false;
    }

    public boolean isFundChart(String term) {
        return isIncluded(fundsCharts, term);
    }

    public boolean isFundDocument(String term) {
        return isIncluded(fundsDocuments, term);
    }

    public boolean isInvestmentView(String term) {
        return isIncluded(investmentsViews, term);
    }

    public boolean isKeyword(String term) {
        return isFundChart(term) || isFundDocument(term) || isInvestmentView(term);
    }

    public static SuggestionsSettingsModel fromPage(Page page) {
        SuggestionsSettingsModel model = EMPTY;
        if (page != null) {
            Resource contentResource = page.getContentResource();
            if (contentResource != null) {
                Resource searchResultsResource = contentResource.getChild(SEARCH_RESULTS_PATH);
                if (searchResultsResource != null) {
                    SuggestionsSettingsModel suggestionsSettingsModel = searchResultsResource.adaptTo(SuggestionsSettingsModel.class);
                    if (suggestionsSettingsModel != null) {
                        model = suggestionsSettingsModel;
                    }
                }
            }
        }
        return model;
    }
}
