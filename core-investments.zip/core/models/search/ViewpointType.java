package com.jhi.aem.website.v1.core.models.search;

import org.apache.commons.lang3.StringUtils;

import com.jhi.aem.website.v1.core.constants.ResourcesConstants;

public enum ViewpointType {
    PAGE(ResourcesConstants.VIEWPOINT_ARTICLE_PAGE_RESOURCE_TYPE),
    DOCUMENT(ResourcesConstants.VIEWPOINT_DOCUMENT_PAGE_RESOURCE_TYPE),
    AUDIO(ResourcesConstants.VIEWPOINT_AUDIO_PAGE_RESOURCE_TYPE),
    VIDEO(ResourcesConstants.VIEWPOINT_VIDEO_PAGE_RESOURCE_TYPE),
    WHITEPAPER(ResourcesConstants.VIEWPOINT_WHITEPAPER_RESOURCE_TYPE);

    private String type;

    ViewpointType(String type) {
        this.type = type;
    }

    public String getDisplayName() {
        return StringUtils.capitalize(StringUtils.lowerCase(name()));
    }

    public static ViewpointType getByFirstChar(char firstChar) {
        for (ViewpointType itemType : ViewpointType.values()) {
            if (itemType.name().charAt(0) == firstChar) {
                return itemType;
            }
        }
        return null;
    }

    public String getType() {
        return type;
    }
}