package com.jhi.aem.website.v1.core.models.search;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.commerce.rrd.service.product.impl.ProductPagesServiceImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.models.viewpoint_asset_manager.ViewpointsAssetManagerModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.TextUtil;

public class TopResultsItem {

    private static final String TITLE_PATH = "title";
    private static final String SUMMARY_PATH = "summary";
    private String title;
    private String description;
    private String pageLink;
    private Page page;

    public TopResultsItem(Page page) {
        this.page = page;
    }

    public String getTitle() {
        if (StringUtils.isBlank(title)) {
            if (page != null) {
                Resource contentResource = page.getContentResource();
                if (PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_PAGE_RESOURCE_TYPE)) {
                    if (contentResource != null) {
                        Resource titleResource = contentResource.getChild(TITLE_PATH);
                        if (titleResource != null) {
                            ValueMap values = titleResource.getValueMap();
                            title = StringUtils.defaultIfBlank(values.get(JcrConstants.JCR_TITLE, String.class), PageUtil.getTitle(page));
                            return title;
                        }
                    }
                }
                title = PageUtil.getTitle(page);
            }
        }
        return title;
    }

    public String getDescription() {
        if (StringUtils.isBlank(description)) {
            if (page != null) {
                Resource contentResource = page.getContentResource();
                if (PageUtil.isResourceType(page, ResourcesConstants.RESOURCE_SUITE_PAGE_RESOURCE_TYPE)
                        || PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_PAGE_RESOURCE_TYPE)) {
                    if (contentResource != null) {
                        Resource summaryResource = contentResource.getChild(SUMMARY_PATH);
                        if (summaryResource != null) {
                            ValueMap values = summaryResource.getValueMap();
                            description = values.get(JhiConstants.TEXT_PROPERTY, String.class);
                            if (StringUtils.isNotBlank(description)) {
                                description = TextUtil.getPlainText(description);
                            } else {
                                description = page.getDescription();
                            }
                            return description;
                        }
                    }
                }
                if (PageUtil.isResourceType(page, ResourcesConstants.RESOURCE_DOCUMENT_RESOURCE_TYPE)) {
                    if (contentResource != null) {
                        Resource documentResource = contentResource.getChild(ProductPagesServiceImpl.DOCUMENT_PATH);
                        if (documentResource != null) {
                            ValueMap values = documentResource.getValueMap();
                            description = StringUtils.defaultIfBlank(values.get(ResourceDocumentModel.DESCRIPTION_PROPERTY, String.class),
                                    page.getDescription());
                            return description;
                        }
                    }
                }
                if (PageUtil.isResourceType(page, ResourcesConstants.PRESS_RELEASE_PAGE_RESOURCE_TYPE)) {
                    if (contentResource != null) {
                        ValueMap values = contentResource.getValueMap();
                        description = StringUtils.defaultIfBlank(values.get(SUMMARY_PATH, String.class), page.getDescription());
                        return description;
                    }
                }
                if (PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINTS_ASSET_MANAGER_PAGE_RESOURCE_TYPE)) {
                    if (contentResource != null) {
                        String assetManagerReference = contentResource.getValueMap()
                                .get(ViewpointsAssetManagerModel.ASSET_MANAGER_REFERENCE, String.class);
                        Resource assetManagerResource = contentResource.getResourceResolver().getResource(assetManagerReference
                                + JhiConstants.SLASH + JcrConstants.JCR_CONTENT + JhiConstants.SLASH
                                + ViewpointsAssetManagerModel.ASSET_MANAGER_PATH);
                        if (assetManagerResource != null) {
                            ValueMap values = assetManagerResource.getValueMap();
                            description = values.get(ViewpointsAssetManagerModel.DESCRIPTION_PROPERTY, String.class);
                            if (StringUtils.isNotBlank(description)) {
                                description = TextUtil.getPlainText(description);
                            } else {
                                description = page.getDescription();
                            }
                            return description;
                        }
                    }
                }
                if (PageUtil.isResourceType(page, ResourcesConstants.RESOURCES_TOPIC_PAGE_RESOURCE_TYPE)
                        || PageUtil.isResourceType(page, ResourcesConstants.RESOURCES_AUDIENCE_PAGE_RESOURCE_TYPE)) {
                    if (contentResource != null) {
                        Resource textResource = contentResource.getChild(JhiConstants.TEXT_PROPERTY);
                        if (textResource != null) {
                            description = textResource.getValueMap().get(JhiConstants.TEXT_PROPERTY, String.class);
                            if (StringUtils.isNotBlank(description)) {
                                description = TextUtil.getPlainText(description);
                            } else {
                                description = page.getDescription();
                            }
                            return description;
                        }
                    }
                }
                description = page.getDescription();
            }
        }
        return description;
    }

    public String getPageLink() {
        if (StringUtils.isBlank(pageLink)) {
            if (page != null) {
                if (page.getContentResource() != null)
                    pageLink = LinkUtil.getLink(page.getContentResource().getResourceResolver(), page.getPath());
            }
        }
        return pageLink;
    }
}
