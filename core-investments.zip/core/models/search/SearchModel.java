package com.jhi.aem.website.v1.core.models.search;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.servlets.suggestion.SuggestionServlet;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SearchModel {

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private List<Resource> placeholders;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    private Page searchPage;

    @PostConstruct
    protected void init() {
        Page homePage = PageUtil.getHomePage(resourcePage);
        if (homePage != null) {
            searchPage = PageUtil.getChildByResourceType(homePage, ResourcesConstants.SEARCH_PAGE_RESOURCE_TYPE);
        }
    }

    public String getTitle() {
        return title;
    }

    public List<Resource> getPlaceholders() {
        return placeholders;
    }

    public String getSearchPageLink() {
        if (searchPage == null) {
            return StringUtils.EMPTY;
        }
        return resourceResolver.map(LinkUtil.getPageLink(searchPage));
    }

    public String getSuggestionLink() {
        if (searchPage == null) {
            return StringUtils.EMPTY;
        }
        return resourceResolver.map(SuggestionServlet.getServletPath(searchPage.getPath()));
    }
}
