package com.jhi.aem.website.v1.core.models.search;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SearchResultsModel extends SearchResultsContentModel {

    private static final String RESULTS_NUMBER_PLACEHOLDER = "${count}";
    private static final String QUERY_PLACEHOLDER = "${query}";

    @Inject
    @Via("resource")
    private String filtersHeader;

    @Inject
    @Via("resource")
    private String topResultsLabel;

    @Inject
    @Via("resource")
    private String formatHeader;

    @Inject
    @Via("resource")
    private String noResultsText;

    @Inject
    @Via("resource")
    private String oneResultText;

    @Inject
    @Via("resource")
    private String manyResultsText;

    @Inject
    @Via("resource")
    private Boolean showInvestments;

    @Inject
    @Via("resource")
    private Boolean showResources;

    @Inject
    @Via("resource")
    private Boolean showAssetManagers;

    @Inject
    @Via("resource")
    private Boolean showViewpoints;

    @Inject
    @Via("resource")
    private Boolean showFundDocuments;

    @Inject
    @Via("resource")
    private Boolean showPressReleases;

    private SearchResultsItems topResults;
    private SearchResultsItems investmentsResults;
    private SearchResultsItems resourcesResults;
    private SearchResultsItems assetManagersResults;
    private SearchResultsItems viewpointsResults;
    private SearchResultsItems fundDocumentsResults;
    private SearchResultsItems pressReleasesResults;

    @Override
    @PostConstruct
    protected void init() {
        prepareQueryText();
        prepareFormats();
        collectResults();
    }

    private void collectResults() {
        ResourceResolver resourceResolver = request.getResourceResolver();

        topResults = getTopResults(resourceResolver, 0, 0);

        if (isShowInvestments()) {
            investmentsResults = getInvestmentsResults(resourceResolver, 0, 0);
        }

        if (isShowResources()) {
            resourcesResults = getResourcesResults(resourceResolver, 0, 0);
        }

        if (isShowAssetManagers()) {
            assetManagersResults = getAssetManagersResults(resourceResolver, 0, 0);
        }

        if (isShowViewpoints()) {
            viewpointsResults = getViewpointsResults(resourceResolver, 0, 0);
        }

        if (isShowFundDocuments()) {
            fundDocumentsResults = getFundDocumentsResults(resourceResolver, 0, 0);
        }

        if (isShowPressReleases()) {
            pressReleasesResults = getPressReleasesResults(resourceResolver, 0, 0);
        }
    }

    public String getFiltersHeader() {
        return filtersHeader;
    }

    public String getTopResultsLabel() {
        return topResultsLabel;
    }

    public CategoryType[] getCategories() {
        return CategoryType.values();
    }

    public String getFormatHeader() {
        return formatHeader;
    }

    public String getResultsText() {
        int allResultsCount = topResults.getTotalMatches();
        if (investmentsResults != null) {
            allResultsCount += investmentsResults.getTotalMatches();
        }
        if (allResultsCount == 0) {
            return prepareResultsText(noResultsText, allResultsCount);
        }
        if (allResultsCount == 1) {
            return prepareResultsText(oneResultText, allResultsCount);
        }
        return prepareResultsText(manyResultsText, allResultsCount);
    }

    private String prepareResultsText(String pattern, int allResultsCount) {
        if (!StringUtils.contains(pattern, JhiConstants.PLACEHOLDER_START)) {
            return allResultsCount + StringUtils.SPACE + pattern + "\"" + originalQuery + "\"";
        }
        String resultsText = StringUtils.replace(pattern, RESULTS_NUMBER_PLACEHOLDER, String.valueOf(allResultsCount));
        resultsText = StringUtils.replace(resultsText, QUERY_PLACEHOLDER, originalQuery);
        return resultsText;
    }

    public SearchResultsItems getTopResults() {
        return topResults;
    }

    public SearchResultsItems getInvestmentsResults() {
        return investmentsResults;
    }

    public SearchResultsItems getResourcesResults() {
        return resourcesResults;
    }

    public SearchResultsItems getAssetManagersResults() {
        return assetManagersResults;
    }

    public SearchResultsItems getViewpointsResults() {
        return viewpointsResults;
    }

    public SearchResultsItems getFundDocumentsResults() {
        return fundDocumentsResults;
    }

    public SearchResultsItems getPressReleasesResults() {
        return pressReleasesResults;
    }

    public boolean isShowInvestments() {
        return Boolean.TRUE.equals(showInvestments);
    }

    public boolean isShowResources() {
        return Boolean.TRUE.equals(showResources);
    }

    public boolean isShowAssetManagers() {
        return Boolean.TRUE.equals(showAssetManagers);
    }

    public boolean isShowViewpoints() {
        return Boolean.TRUE.equals(showViewpoints);
    }

    public boolean isShowFundDocuments() {
        return Boolean.TRUE.equals(showFundDocuments);
    }

    public boolean isShowPressReleases() {
        return Boolean.TRUE.equals(showPressReleases);
    }
}

