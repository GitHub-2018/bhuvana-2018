package com.jhi.aem.website.v1.core.models.social;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class LatestTweetsModel {

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String moreLabel;

    @Inject
    @Default
    private String twitterScreenName;

    public String getTitle() {
        return title;
    }

    public String getMoreLabel() {
        return moreLabel;
    }

    public String getTwitterScreenName() {
        return twitterScreenName;
    }
}
