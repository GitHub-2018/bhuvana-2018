package com.jhi.aem.website.v1.core.models.social;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SocialMediaModel {

    @Inject
    @Default
    private String twitterText;

    @Inject
    @Default
    private String twitterLink;

    @Inject
    @Default(values="/etc.clientlibs/jhi-website-v1/clientlibs/clientlib-site/resources/share-twitter-icon.svg")
    private String twitterIcon;

    @Inject
    @Default
    private String facebookText;

    @Inject
    @Default
    private String facebookLink;

    @Inject
    @Default(values="/etc.clientlibs/jhi-website-v1/clientlibs/clientlib-site/resources/share-facebook-icon.svg")
    private String facebookIcon;

    @Inject
    @Default
    private String linkedInText;

    @Inject
    @Default
    private String linkedInLink;

    @Inject
    @Default(values="/etc.clientlibs/jhi-website-v1/clientlibs/clientlib-site/resources/share-linkedin-icon.svg")
    private String linkedInIcon;

    @Inject
    @Default
    private String googlePlusText;

    @Inject
    @Default
    private String googlePlusLink;

    @Inject
    @Default(values="/etc.clientlibs/jhi-website-v1/clientlibs/clientlib-site/resources/share-youtube-icon.png")
    private String googlePlusIcon;

    public String getTwitterText() {
        return twitterText;
    }

    public String getTwitterLink() {
        return twitterLink;
    }

    public String getTwitterIcon() {
        return twitterIcon;
    }

    public String getFacebookText() {
        return facebookText;
    }

    public String getFacebookLink() {
        return facebookLink;
    }

    public String getFacebookIcon() {
        return facebookIcon;
    }
    
    public String getLinkedInText() {
        return linkedInText;
    }

    public String getLinkedInLink() {
        return linkedInLink;
    }

    public String getLinkedInIcon() {
        return linkedInIcon;
    }
    
    public String getGooglePlusText() {
        return googlePlusText;
    }

    public String getGooglePlusLink() {
        return googlePlusLink;
    }

    public String getGooglePlusIcon() {
        return googlePlusIcon;
    }
}
