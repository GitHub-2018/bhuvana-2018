package com.jhi.aem.website.v1.core.models.svg;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Collections;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import org.slf4j.Logger;


import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SvgModel  {

	@Inject
	private ResourceResolverFactory resolverFactory;
	
	@Inject
	private String filePath;
	
	private String fileContent;
	private ResourceResolver resolver;
	
	private static final Logger LOG = org.slf4j.LoggerFactory.getLogger(SvgModel.class);
	
	@PostConstruct
	protected void init() throws LoginException, IOException {
		try {
		resolver = resolverFactory.getServiceResourceResolver(
                Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));

		//final String filePath = get("filePath", String.class);
		if (StringUtils.isBlank(filePath)) {
			return;
		}

		//final ResourceResolver resolver = getResourceResolver();
		final Resource fileResource = resolver.getResource(filePath + "/" + JcrConstants.JCR_CONTENT);
		if (fileResource == null) {
			return;
		}

		final InputStream is = fileResource.adaptTo(InputStream.class);
		if (is == null) {
			return;
		}

		final StringWriter writer = new StringWriter();
		IOUtils.copy(is, writer, "UTF-8");
		fileContent = writer.toString();
		}catch (LoginException e) {
			LOG.error(e.getMessage());
		}catch (IOException e) {
			LOG.error(e.getMessage());
		}finally {
			if (null != resolver && resolver.isLive() ) {
				resolver.close();
			}
		}
	
	}
	

	public String getFileContent() {
		return fileContent;
	}
}