package com.jhi.aem.website.v1.core.models;

import java.util.ArrayList;
import java.util.List;

public class BiList {

	public static class BiListPair<T extends Object> {
		private T element1;
		private T element2;

		protected BiListPair(T element1, T element2) {
			this.element1 = element1;
			this.element2 = element2;
		}

		public T getFirst() {
			return element1;
		}
		
		public T getSecond() {
			return element2;
		}

		public boolean isSecondExists() {
			return element2 != null;
		}

		public boolean isFirstExists() {
			return element1 != null;
		}
	}

	private BiList() {
	}

	public static <T extends Object> List<BiListPair<T>> createBiList(List<T> list) {
		List<BiListPair<T>> biList = new ArrayList<>();

		for (int i=0; i<list.size(); i+=2) {
			T element1 = list.get(i);
			T element2 = i+1 < list.size() ? list.get(i+1) : null;
			biList.add(new BiListPair<T>(element1, element2));
		}

		return biList;
	}

}
