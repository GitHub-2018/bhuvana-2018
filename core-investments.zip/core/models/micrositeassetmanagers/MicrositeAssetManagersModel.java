package com.jhi.aem.website.v1.core.models.micrositeassetmanagers;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.aboutus.AssetManagersContainerModel;
import com.jhi.aem.website.v1.core.models.micrositesubnavmarker.MicrositeSubnavMarkerModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeAssetManagersModel extends AssetManagersContainerModel {

    @Inject
    private MicrositeSubnavMarkerModel subnav;

    public MicrositeSubnavMarkerModel getSubnav() {
        return subnav;
    }
}
