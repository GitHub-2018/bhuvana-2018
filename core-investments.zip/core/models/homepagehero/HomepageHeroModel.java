package com.jhi.aem.website.v1.core.models.homepagehero;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.models.aboutus.AssetManagersContainerModel;
import com.jhi.aem.website.v1.core.models.dashboard.DashboardTabsModel;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.user.FundModel;
import com.jhi.aem.website.v1.core.models.user.InvestmentPortfolioModel;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.service.dashboard.Dashboard;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HomepageHeroModel {

    private static final String ASSET_MANAGERS_CONTAINER_PATH = "/" + JcrConstants.JCR_CONTENT
            + "/asset-managers-container";

    @Inject
    private DashboardService dashboardService;

    @OSGiService
    private UserProfileService userProfileService;

    @Inject
    private PageManager pageManager;

    @Inject
    private ResourceResolver resolver;

    @Inject
    private Page resourcePage;

    @Inject
    private Resource resource;

    @Inject
    private String primaryViewpoint;

    @Inject
    private String secondaryViewpoint1;

    @Inject
    private String secondaryViewpoint2;

    @Inject
    private String aboutUsPage;

    @Inject
    private String adTitle;

    @Inject
    private String adText;

    @Inject
    private String adButtonUrl;

    @Inject
    private String adButtonLabel;

    @Inject
    private String dashboardTitle;

    @Inject
    private String dashboardNavLabel;

    @Inject
    private String dashboardChgLabel;

    @Inject
    private String dashboardButtonUrl;

    @Inject
    private String dashboardButtonLabel;

    @ValueMapValue
    private String logoutText;

    @ChildResource
    private ImageModel image;

    @ChildResource
    private ImageModel background;

    @ValueMapValue
    private String secondButtonUrl;

    @ValueMapValue
    private String secondbuttonLabel;

    @OSGiService
    private ResourceResolverFactory resourceResolverFactory;

    private ViewpointDetailModel primaryViewpointModel;

    private ViewpointDetailModel secondaryViewpointModel1;

    private ViewpointDetailModel secondaryViewpointModel2;

    private AssetManagersContainerModel popupConfig;

    private Dashboard dashboard;

    private FundModel firstFund;

    @PostConstruct
    private void init() {
        primaryViewpointModel = fetchViewpointFromPage(primaryViewpoint);
        secondaryViewpointModel1 = fetchViewpointFromPage(secondaryViewpoint1);
        secondaryViewpointModel2 = fetchViewpointFromPage(secondaryViewpoint2);
        popupConfig = fetchAssetManagersContainerFromPage(aboutUsPage);

        dashboard = dashboardService.getDashboard(resourcePage);

        final InvestmentPortfolioModel investmentPortfolio = userProfileService.getInvestmentPortfolio(resolver);
        if (investmentPortfolio != null) {
            final List<FundModel> funds = investmentPortfolio.getInvestedFunds();
            if (funds != null && funds.size() > 0) {
                firstFund = funds.get(0);
            }
        }
    }

    private ViewpointDetailModel fetchViewpointFromPage(String pagePath) {
        if (StringUtils.isBlank(pagePath)) {
            return null;
        }

        return ViewpointDetailModel.fromPage(pageManager.getPage(pagePath));
    }

    private AssetManagersContainerModel fetchAssetManagersContainerFromPage(String pagePath) {
        if (StringUtils.isBlank(aboutUsPage)) {
            return null;
        }

        final Resource assetManagersContainerResource = resolver.getResource(pagePath + ASSET_MANAGERS_CONTAINER_PATH);
        if (assetManagersContainerResource == null) {
            return null;
        }

        return assetManagersContainerResource.adaptTo(AssetManagersContainerModel.class);
    }

    public String getDashboardStatusPath() {
        return resource.getPath() + DashboardTabsModel.INFO_SELECTOR_PART;
    }

    public String getAdTitle() {
        return adTitle;
    }

    public String getAdText() {
        return adText;
    }

    public String getAdButtonUrl() {
        return LinkUtil.getLink(adButtonUrl);
    }

    public String getAdButtonLabel() {
        return adButtonLabel;
    }

    public String getPrimaryViewpoint() {
        return primaryViewpoint;
    }

    public String getSecondaryViewpoint1() {
        return secondaryViewpoint1;
    }

    public String getSecondaryViewpoint2() {
        return secondaryViewpoint2;
    }

    public String getDashboardTitle() {
        return dashboardTitle;
    }

    public String getDashboardNavLabel() {
        return dashboardNavLabel;
    }

    public String getDashboardChgLabel() {
        return dashboardChgLabel;
    }

    public String getDashboardButtonLink() {
        String link = StringUtils.EMPTY;
        ResourceResolver elevatedResourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
        if (elevatedResourceResolver != null) {
            PageManager pageManager = elevatedResourceResolver.adaptTo(PageManager.class);
            if (pageManager != null) {
                Page dashboardPage = pageManager.getPage(dashboardButtonUrl);
                if (dashboardPage != null) {
                    link = elevatedResourceResolver.map(LinkUtil.getPageLink(dashboardPage));
                }
            }
            elevatedResourceResolver.close();
        }
        if (StringUtils.isNotBlank(link)) {
            return link;
        }
        return LinkUtil.getLink(dashboardButtonUrl);
    }

    public String getDashboardButtonLabel() {
        return dashboardButtonLabel;
    }

    public PageManager getPageManager() {
        return pageManager;
    }

    public ViewpointDetailModel getPrimaryViewpointModel() {
        return primaryViewpointModel;
    }

    public ViewpointDetailModel getSecondaryViewpointModel1() {
        return secondaryViewpointModel1;
    }

    public ViewpointDetailModel getSecondaryViewpointModel2() {
        return secondaryViewpointModel2;
    }

    public AssetManagersContainerModel getPopupConfig() {
        return popupConfig;
    }

    public Dashboard getDashboard() {
        return dashboard;
    }

    public FundModel getFirstFund() {
        return firstFund;
    }

    public String getLogoutText() {
        return logoutText;
    }

    public String getImage() {
        return getImagePath(image);
    }

    public Boolean hasImage() {
        return !getImage().isEmpty();
    }

    public boolean isBlank() {
        return StringUtils.isBlank(primaryViewpoint) && StringUtils.isBlank(secondaryViewpoint1)
                && StringUtils.isBlank(secondaryViewpoint2) && StringUtils.isBlank(adTitle)
                && StringUtils.isBlank(adText) && StringUtils.isBlank(adButtonLabel)
                && StringUtils.isBlank(adButtonUrl);
    }

    public boolean hasSecondLink() {
        return StringUtils.isNotBlank(secondbuttonLabel) && StringUtils.isNotBlank(secondButtonUrl);
    }

    public String getSecondButtonUrl() {
        return LinkUtil.getLink(secondButtonUrl);
    }

    public String getSecondbuttonLabel() {
        return secondbuttonLabel;
    }

    public String getBackground() {
        return getImagePath(background);
    }

    public Boolean hasBackground() {
        return !getBackground().isEmpty();
    }

    public String getImagePath(ImageModel image) {
        return Optional.ofNullable(image)
                .map(ImageModel::getPath)
                .orElse(StringUtils.EMPTY);
    }
}
