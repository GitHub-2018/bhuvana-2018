package com.jhi.aem.website.v1.core.models.pressrelease;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class PressReleaseDataModel {
	private static final Logger LOG = LoggerFactory.getLogger(PressReleaseDataModel.class);

	@Inject
    @Default
    private String title;

    @Inject
    @Default
    private String description;

    @Inject
    @Default
    private String buttonLink;

    @Inject
    @Default
    private String buttonLabel;

    @Inject
    @Optional
    private Calendar date; 

    @Self
    protected Resource resource;

    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
		return description;
	}

	public String getButtonLink() {
		return buttonLink;
	}

	public String getButtonLabel() {
		return buttonLabel;
	}

	public String getDate() {
	    String formattedValue = StringUtils.EMPTY;
	    SimpleDateFormat formatTo = new SimpleDateFormat("MMMM dd, yyyy");
	    if(date!=null) {
	    	formattedValue = formatTo.format(date.getTime());
	    }
		return formattedValue;
	}

    public boolean isValid() {
        return resource != null && StringUtils.isNotBlank(getTitle());
    }

}
