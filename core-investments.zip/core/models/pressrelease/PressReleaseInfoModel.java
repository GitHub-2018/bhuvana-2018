package com.jhi.aem.website.v1.core.models.pressrelease;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class PressReleaseInfoModel {

    @Inject
    @Default
    @Named("jcr:title")
    private String title;

    @Inject
    @Default
    private String summary;

    @Inject
    protected Page resourcePage;

    @Self
    protected Resource resource;

    public String getTitle() {
        return title;
    }

    public String getSummary() {
        return summary;
    }

    public String getPageLink() {
        return LinkUtil.getPageLink(resourcePage);
    }

    public boolean isValid() {
        return resource != null && StringUtils.isNotBlank(getTitle()) && StringUtils.isNotBlank(getSummary());
    }

}
