package com.jhi.aem.website.v1.core.models.user;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;


@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class AddressModel implements UserDataModel {

    public static final String ID_PROPERTY = "id";
    public static final String NAME_PROPERTY = "name";
    public static final String ADDRESS_PROPERTY = "address";
    public static final String BUILDING_DETAIL_PROPERTY = "buildingDetail";
    public static final String CITY_PROPERTY = "city";
    public static final String STATE_PROPERTY = "state";
    public static final String ZIP_PROPERTY = "zip";
    public static final String COUNTRY_PROPERTY = "country";
    public static final String PATH_PROPERTY = "path";

    @Inject
    @Default
    private String id;

    @Inject
    @Default
    private String name;

    @Inject
    @Default
    private String address;

    @Inject
    @Default
    private String buildingDetail;

    @Inject
    @Default
    private String city;

    @Inject
    @Default
    private String state;

    @Inject
    @Default
    private String zip;

    @Inject
    @Default
    private String country;

    @Self
    private Resource resource;

    public AddressModel() {
    }

    public AddressModel(String id, String name, String address, String buildingDetail, String city, String state,
                        String zip, String country) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.buildingDetail = buildingDetail;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.country = country;
    }

    public AddressModel(Map <String, Object> values) {
        this.id = (String) values.get(AddressModel.ID_PROPERTY);
        this.name = (String) values.get(AddressModel.NAME_PROPERTY);
        this.address = (String) values.get(AddressModel.ADDRESS_PROPERTY);
        this.buildingDetail = (String) values.get(AddressModel.BUILDING_DETAIL_PROPERTY);
        this.city = (String) values.get(AddressModel.CITY_PROPERTY);
        this.state = (String) values.get(AddressModel.STATE_PROPERTY);
        this.zip = (String) values.get(AddressModel.ZIP_PROPERTY);
        this.country = (String) values.get(AddressModel.COUNTRY_PROPERTY);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getBuildingDetail() {
        return buildingDetail;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZip() {
        return zip;
    }

    public String getCountry() {
        return country;
    }

    @Override
    public Map<String, Object> getValueMap() {
        return getValueMap(true);
    }

    public Map<String, Object> getValueMap(boolean auxData) {
        Map<String, Object> map = new HashMap<>(9);
        map.put(ID_PROPERTY, id);
        map.put(NAME_PROPERTY, name);
        map.put(ADDRESS_PROPERTY, address);
        map.put(BUILDING_DETAIL_PROPERTY, buildingDetail);
        map.put(CITY_PROPERTY, city);
        map.put(STATE_PROPERTY, state);
        map.put(ZIP_PROPERTY, zip);
        map.put(COUNTRY_PROPERTY, country);
        String path = getPath();
        if (auxData && StringUtils.isNotBlank(path)) {
            map.put(PATH_PROPERTY, path);
        }
        return map;
    }

    @Override
    public boolean isValid() {
        return StringUtils.isNoneBlank(id, name, address, city);
    }

    public String getPath() {
        if (resource != null) {
            return resource.getName();
        }
        return StringUtils.EMPTY;
    }
 }
