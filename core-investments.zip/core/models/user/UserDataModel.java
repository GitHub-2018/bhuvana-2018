package com.jhi.aem.website.v1.core.models.user;

import java.util.Map;

public interface UserDataModel {

    boolean isValid();

    /**
     * @return A map containing keys and values which represents this data object. The values in the map
     * cannot be null.
     */
    Map<String, Object> getValueMap();

}
