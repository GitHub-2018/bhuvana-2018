package com.jhi.aem.website.v1.core.models.user;

import java.util.Calendar;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.models.NullValueDiscardingMap;
import com.jhi.aem.website.v1.core.service.user.UserProfileConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ProfileModel implements UserDataModel, UserProfileConstants {

	public static final ProfileModel EMPTY = new ProfileModel();

	@Inject
	@Default
	private String externalId;

	@Inject
	@Default
	private String email;

	@Inject
	@Default
	private String screenName;

	@Inject
	@Default
	private String givenName;

	@Inject
	@Default
	private String familyName;

	@Inject
	@Default
	private String firmName;

	@Inject
	@Default
	private String role;

	@Inject
	@Default
	private String crdNumber;

	@Inject
	@Optional
	private Calendar lastLogin;

	@Inject
	@Optional
	private Calendar previousLogin;

	public ProfileModel() {
	}

	public String getExternalId() {
		return externalId;
	}

	public String getEmail() {
		return email;
	}

	public String getScreenName() {
		return screenName;
	}

	public String getGivenName() {
		return givenName;
	}

	public String getFamilyName() {
		return familyName;
	}

	public String getFirmName() {
		return firmName;
	}

	public String getRole() {
		return role;
	}

	public String getCrdNumber() {
		return crdNumber;
	}

	public Calendar getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Calendar lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Calendar getPreviousLogin() {
		return previousLogin;
	}

	public void setPreviousLogin(Calendar previousLogin) {
		this.previousLogin = previousLogin;
	}

	@Override
	public boolean isValid() {
		return StringUtils.isNoneBlank(email, givenName, familyName);
	}

	@Override
	public Map<String, Object> getValueMap() {
		Map<String, Object> properties = new NullValueDiscardingMap<>(10);
		properties.put(EMAIL_PROPERTY, email);
		properties.put(SCREEN_NAME_PROPERTY, screenName);
		properties.put(FIRST_NAME_PROPERTY, givenName);
		properties.put(LAST_NAME_PROPERTY, familyName);
		properties.put(FIRM_NAME_PROPERTY, firmName);
		properties.put(ROLE_PROPERTY, role);
		properties.put(CRD_NUMBER_PROPERTY, crdNumber);
		properties.put(LAST_LOGIN_PROPERTY, lastLogin);
		properties.put(PREVIOUS_LOGIN_PROPERTY, previousLogin);
		return properties;
	}

	public static class Builder {
		private String externalId;
		private String email;
		private String screenName;
		private String givenName;
		private String familyName;
		private String firmName;
		private String role;
		private String crdNumber;
		private Calendar lastLogin;
		private Calendar previousLogin;

		public Builder externalId(String externalId) {
			this.externalId = externalId;
			return this;
		}

		public Builder email(String email) {
			this.email = email;
			return this;
		}

		public Builder screenName(String screenName) {
			this.screenName = screenName;
			return this;
		}

		public Builder givenName(String givenName) {
			this.givenName = givenName;
			return this;
		}

		public Builder familyName(String familyName) {
			this.familyName = familyName;
			return this;
		}

		public Builder firmName(String firmName) {
			this.firmName = firmName;
			return this;
		}

		public Builder role(String role) {
			this.role = role;
			return this;
		}

		public Builder crdNumber(String crdNumber) {
			this.crdNumber = crdNumber;
			return this;
		}

		public Builder lastLogin(Calendar lastLogin) {
			this.lastLogin = lastLogin;
			return this;
		}

		public Builder previousLogin(Calendar previousLogin) {
			this.previousLogin = previousLogin;
			return this;
		}

		public ProfileModel build() {
			ProfileModel profileModel = new ProfileModel();
			profileModel.externalId = externalId;
			profileModel.email = email;
			profileModel.screenName = screenName;
			profileModel.givenName = givenName;
			profileModel.familyName = familyName;
			profileModel.firmName = firmName;
			profileModel.role = role;
			profileModel.crdNumber = crdNumber;
			profileModel.lastLogin = lastLogin;
			profileModel.previousLogin = previousLogin;
			return profileModel;
		}
	}
}
