package com.jhi.aem.website.v1.core.models.user;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class AuditModel implements UserDataModel {
	
    public final String ADMIN_USER_MAIL_PROPERTY = "adminUserEmail";
    public final String USER_MAIL_PROPERTY = "userEmail";
    public final String ACTIVITY_TYPE_PROPERTY = "activityType";	
    public final String ACTIVITY_MSG_PROPERTY = "activityMsg";	
    public static final String DATE_PROPERTY = "date";
	
	private String adminUserEmail;
	private String userEmail;
	private String activityType;
	private String activityMsg;
	
	public static class Builder {
		private String adminUserEmail;
		private String userEmail;
		private String activityType;
		private String activityMsg;

		public Builder adminUserEmail(String adminUserEmail) {
			this.adminUserEmail = adminUserEmail;
			return this;
		}

		public Builder userEmail(String userEmail) {
			this.userEmail = userEmail;
			return this;
		}

		public Builder activityType(String activityType) {
			this.activityType = activityType;
			return this;
		}

		public Builder activityMsg(String activityMsg) {
			this.activityMsg = activityMsg;
			return this;
		}

		public AuditModel build() {
			AuditModel auditModel = new AuditModel();
			auditModel.adminUserEmail = adminUserEmail;
			auditModel.userEmail = userEmail;
			auditModel.activityType = activityType;
			auditModel.activityMsg = activityMsg;
			return auditModel;
		}
	}	

	@Override
	public boolean isValid() {
		return true;
	}

	@Override
	public Map<String, Object> getValueMap() {
        Map<String, Object> map = new HashMap<>(4);
        map.put(ADMIN_USER_MAIL_PROPERTY, StringUtils.defaultIfBlank(adminUserEmail, StringUtils.EMPTY));
        map.put(USER_MAIL_PROPERTY, StringUtils.defaultIfBlank(userEmail, StringUtils.EMPTY));
        map.put(ACTIVITY_TYPE_PROPERTY, StringUtils.defaultIfBlank(activityType, StringUtils.EMPTY));
        map.put(ACTIVITY_MSG_PROPERTY, StringUtils.defaultIfBlank(activityMsg, StringUtils.EMPTY));
        Calendar date = Calendar.getInstance(Locale.US);
        map.put(DATE_PROPERTY, date);
        return map;
	}
	public String getUserEmail() {
		return userEmail;
	}
}