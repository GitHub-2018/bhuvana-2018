package com.jhi.aem.website.v1.core.models.user;

import java.util.Collections;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class DownloadedReport implements UserDataModel {

    @ValueMapValue
    private String path;

    public DownloadedReport() {
    }

    public DownloadedReport(String path) {
        super();
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    @Override
    public boolean isValid() {
        return true;
    }

    @Override
    public Map<String, Object> getValueMap() {
        return Collections.singletonMap("path", path);
    }
}
