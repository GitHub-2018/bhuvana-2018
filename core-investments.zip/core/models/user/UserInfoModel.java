package com.jhi.aem.website.v1.core.models.user;

import java.util.Collections;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class UserInfoModel implements UserDataModel {

    public static final UserInfoModel EMPTY = new UserInfoModel();

    @Inject
    @Default
    private String screenName;

    @Inject
    @Default
    private String givenName;

    @Inject
    @Default
    private String familyName;

    @Inject
    @Default
    private String email;

    @Inject
    private String firmId;

    @Inject
    private String firmName;

    @Inject
    private Boolean isPipVerifiedFinancialAdvisor;
    
    @Inject
    private String marsRepId;
    
    @Inject
    private String webId;

    @Inject
    private String topIndustryProducer;

    @Inject
    private String oaeSegment;

    @Inject
    private String externalId;


    public String getScreenName() {
        return screenName;
    }

    public String getUserName() {
        if (StringUtils.isNotBlank(screenName)) {
            return screenName;
        }
        if (StringUtils.isNotBlank(givenName)) {
            return givenName + StringUtils.SPACE + familyName;
        }
        return StringUtils.isNotBlank(familyName) ? familyName : "Unknown";
    }

    public String getEmail() {
        return email;
    }

    public String getEmailDomain() {
        if (StringUtils.isNotBlank(email)) {
            String domainPart = StringUtils.substringAfter(email, JhiConstants.AT);
            return StringUtils.substringBeforeLast(domainPart, JhiConstants.DOT);
        }
        return StringUtils.EMPTY;
    }

    @Override
    public boolean isValid() {
        return StringUtils.isNotBlank(getUserName());
    }

    public Map<String, Object> getValueMap() {
        return Collections.singletonMap(ProfileModel.SCREEN_NAME_PROPERTY, screenName);
    }

	public boolean isPipVerifiedFinancialAdvisor() {
        return BooleanUtils.isTrue(isPipVerifiedFinancialAdvisor);
    }

	public String getFirmId() {
        return firmId;
    }

	public String getMarsRepId() {
		return marsRepId;
	}

	public String getWebId() {
		return webId;
	}

	public String getFirmName() {
		return firmName;
	}

	public String getTopIndustryProducer() {
		return topIndustryProducer;
	}

	public String getOaeSegment() {
		return oaeSegment;
	}

	public String getExternalId() {
		return externalId;
	}

}
