package com.jhi.aem.website.v1.core.models.user;

import java.util.Calendar;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.utils.DateUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ActivityModel implements Comparable<ActivityModel> {

    public static final String TYPE_PROPERTY = "type";
    public static final String TARGET_TYPE_PROPERTY = "targetType";
    public static final String TITLE_PROPERTY = "title";
    public static final String PATH_PROPERTY = "path";
    public static final String ITEM_PATH_PROPERTY = "itemPath";
    public static final String DATE_PROPERTY = "date";

    @Inject
    @Default
    private String type;

    @Inject
    @Default
    private String targetType;

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String path;

    @Inject
    @Default
    private String itemPath;

    @Inject
    @Optional
    private Calendar date;

    private ActivityType activityType;

    @PostConstruct
    protected void init() {
        activityType = ActivityType.getByName(type);
    }

    public String getActivityName() {
        if (activityType != null) {
            return activityType.getActivityName();
        }
        return StringUtils.EMPTY;
    }

    public String getReuseName() {
        if (activityType != null) {
            return activityType.getReuseName();
        }
        return StringUtils.EMPTY;
    }

    public String getTargetType() {
        return targetType;
    }

    public String getTitle() {
        return title;
    }

    public String getPath() {
        return path;
    }

    public String getItemPath() {
        return itemPath;
    }

    public Calendar getDate() {
        return date;
    }

    public String getDateFormatted() {
        return DateUtil.getFormattedUsDate(date, null);
    }

    public boolean isValid() {
        return type != null && StringUtils.isNotBlank(targetType) && StringUtils.isNotBlank(title) &&
                StringUtils.isNotBlank(path) && date != null;
    }

    public boolean isTypeDownload() {
        return activityType == ActivityType.DOWNLOAD;
    }

    @Override
    public int compareTo(ActivityModel other) {
        return other.date.compareTo(date);
    }
}
