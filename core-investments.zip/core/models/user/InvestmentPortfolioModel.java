package com.jhi.aem.website.v1.core.models.user;

import java.util.List;

public class InvestmentPortfolioModel {

    private List<FundModel> investedFunds;

    public InvestmentPortfolioModel(List<FundModel> investedFunds) {
        super();
        this.investedFunds = investedFunds;
    }

    public List<FundModel> getInvestedFunds() {
        return investedFunds;
    }

    public boolean isValid() {
        return investedFunds != null;
    }
}
