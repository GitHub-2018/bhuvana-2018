package com.jhi.aem.website.v1.core.models.user;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

public class DocumentDownloadAuditModel implements UserDataModel {

    private static final String FIRST_NAME_PROPERTY = "firstName";
    private static final String LAST_NAME_PROPERTY = "lastName";
    private static final String DOCUMENT_LINK_PROPERTY = "documentLink";
    private static final String USER_MAIL_PROPERTY = "userEmail";
    private static final String ACTIVITY_TYPE_PROPERTY = "activityType";
    private static final String DATE_PROPERTY = "date";
    private static final String DATE_AS_STRING = "dateAsString";
    private static final String CLIENT_IP = "clientIP";
    private static final String REFERER = "referer";
    private static final String FILE_TYPE = "fileType";

    private String firstName;
    private String lastName;
    private String userEmail;
    private String documentLink;
    private String clientIP;
    private String referer;

    public String getUserEmail() {
        return userEmail;
    }

    public static class Builder {
        private String firstName;
        private String userEmail;
        private String lastName;
        private String documentLink;
        private String clientIP;
        private String referer;

        public Builder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder lastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }

        public Builder documentLink(String documentLink) {
            this.documentLink = documentLink;
            return this;
        }

        public Builder clientIP(String clientIP) {
            this.clientIP = clientIP;
            return this;
        }

        public Builder referer(String referer) {
            this.referer = referer;
            return this;
        }

        public DocumentDownloadAuditModel build() {
            if (!isValid()) {
                throw new IllegalStateException(String.format(
                        "Cannot build DocumentDownloadAuditModel, because not all the required parameters are present. firstName: [%s], lastName: [%s], documentLink: [%s], userEmail: [%s]",
                        firstName, lastName, documentLink, userEmail));
            }
            DocumentDownloadAuditModel auditModel = new DocumentDownloadAuditModel();
            auditModel.firstName = firstName;
            auditModel.lastName = lastName;
            auditModel.documentLink = documentLink;
            auditModel.userEmail = userEmail;
            auditModel.clientIP = clientIP;
            auditModel.referer = referer;

            return auditModel;
        }

        private Boolean isValid() {
            return StringUtils.isNotBlank(firstName) && StringUtils.isNotBlank(lastName) && StringUtils.isNotBlank(documentLink)
                    && StringUtils.isNotBlank(userEmail);
        }
    }

    @Override
    public boolean isValid() {
        return true;
    }

    @Override
    public Map<String, Object> getValueMap() {
        Map<String, Object> map = new HashMap<>(4);
        map.put(FIRST_NAME_PROPERTY, firstName);
        map.put(LAST_NAME_PROPERTY, lastName);
        map.put(USER_MAIL_PROPERTY, userEmail);
        map.put(DOCUMENT_LINK_PROPERTY, documentLink);
        map.put(ACTIVITY_TYPE_PROPERTY, ActivityType.DOWNLOAD.getActivityName());
        Calendar date = Calendar.getInstance(Locale.US);
        map.put(DATE_PROPERTY, date);
        map.put(DATE_AS_STRING, DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.format(date));
        map.put(CLIENT_IP, clientIP);
        map.put(REFERER, referer);
        map.put(FILE_TYPE, StringUtils.upperCase(StringUtils.substringAfterLast(documentLink, ".")));
        return map;
    }

    public String getDocumentLink() {
        return documentLink;
    }

    @Override
    public String toString() {
        return "DocumentDownloadAuditModel{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", documentLink='" + documentLink + '\'' +
                ", clientIP='" + clientIP + '\'' +
                ", referer='" + referer + '\'' +
                '}';
    }
}