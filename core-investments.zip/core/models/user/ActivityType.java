package com.jhi.aem.website.v1.core.models.user;

import org.apache.commons.lang3.StringUtils;

public enum ActivityType {
    VIEW("Viewed", "View"),
    DOWNLOAD("Downloaded","Download"),
    SHARE("Shared","Share");

    ActivityType(String activityName, String reuseName) {
        this.activityName = activityName;
        this.reuseName = reuseName;
    }

    private String activityName;
    private String reuseName;

    public String getActivityName() {
        return activityName;
    }

    public String getReuseName() {
        return reuseName;
    }

    public static ActivityType getByName(String name){
        if (StringUtils.isNotBlank(name)) {
            for(ActivityType itemType : ActivityType.values()) {
                if (StringUtils.equalsIgnoreCase(name, itemType.name())){
                    return itemType;
                }
            }
        }
        return null;
    }
}
