package com.jhi.aem.website.v1.core.models.user;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ShippingModel implements UserDataModel {

    public static final String EMAIL_PROPERTY = "email";

    @Inject
    private String email;
    
    public ShippingModel() {
    }

    public ShippingModel(String email) {
        super();
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public boolean isValid() {
        return StringUtils.isNotBlank(email);
    }

    @Override
    public Map<String, Object> getValueMap() {
        Map<String, Object> map = new HashMap<>(1);
        map.put(EMAIL_PROPERTY, email);
        return map;
    }
}
