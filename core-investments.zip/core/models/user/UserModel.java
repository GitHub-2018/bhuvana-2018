package com.jhi.aem.website.v1.core.models.user;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.personalization.UserPropertiesUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class UserModel {

    @Self
    private SlingHttpServletRequest request;

    public boolean isLoggedIn() {
        return !UserPropertiesUtil.isAnonymous(request);
    }
}
