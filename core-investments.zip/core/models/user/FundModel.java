package com.jhi.aem.website.v1.core.models.user;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.tagging.TagManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundModel implements UserDataModel {

    public static final String AMOUNT_INVESTED_PROPERTY = "amountInvested";
    public static final String CURRENCY_CODE_PROPERTY = "currencyCode";
    public static final String TAG_ID_PROPERTY = "tagId";
    public static final String DEFAULT_CURRENCY = "USD";
    public static final BigDecimal DEFAULT_AMOUNT_INVESTED = new BigDecimal(10000);

    @ValueMapValue
    private BigDecimal amountInvested = new BigDecimal(10000);

    @ValueMapValue
    private String currencyCode = DEFAULT_CURRENCY;

    @ValueMapValue
    private String tagId;

    @SlingObject
    private Resource resource;

    @SlingObject
    private ResourceResolver resolver;

    private String shareClass;

    public FundModel() {
    }

    public FundModel(String shareClass, String tagId) {
        super();
        this.shareClass = shareClass;
        this.tagId = tagId;
    }

    @PostConstruct
    public void init() {
        Optional.ofNullable(resource)
                .map(res -> StringUtils.substringAfterLast(res.getName(), "-"))
                .ifPresent(id -> shareClass = id);
    }

    public BigDecimal getAmountInvested() {
        return amountInvested != null ? amountInvested : DEFAULT_AMOUNT_INVESTED;
    }

    public String getAmountInvestedFormatted() {
        return new DecimalFormat(JhiConstants.CURRENCY_DECIMAL_PATTERNS).format(getAmountInvested());
    }

    public String getCurrencyCode() {
        return StringUtils.isNotBlank(currencyCode) ? currencyCode : DEFAULT_CURRENCY;
    }

    public String getTagId() {
        return tagId;
    }

    public String getShareClass() {
        return shareClass;
    }

    @Override
    public boolean isValid() {
        return StringUtils.isNotBlank(tagId) && StringUtils.isNotBlank(shareClass) && (resolver == null || resolver.adaptTo(TagManager.class).resolve(tagId) != null);

    }

    @Override
    public Map<String, Object> getValueMap() {
        Map<String, Object> map = new HashMap<>(4);
        map.put(TAG_ID_PROPERTY, getTagId());
        map.put(AMOUNT_INVESTED_PROPERTY, getAmountInvested());
        map.put(CURRENCY_CODE_PROPERTY, getCurrencyCode());
        return map;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof FundModel))
            return false;
        FundModel fundModel = (FundModel) o;
        return Objects.equals(tagId, fundModel.tagId) &&
                Objects.equals(shareClass, fundModel.shareClass);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tagId, shareClass);
    }
}
