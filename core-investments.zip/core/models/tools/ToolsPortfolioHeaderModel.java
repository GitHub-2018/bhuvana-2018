package com.jhi.aem.website.v1.core.models.tools;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ToolsPortfolioHeaderModel {

    @Inject
    private String title;

    @Inject
    private String linkUrl;

    public String getTitle() {
        return title;
    }

    public String getLinkUrl() {
        return LinkUtil.getLink(linkUrl);
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(linkUrl);
    }
}
