package com.jhi.aem.website.v1.core.models.tools;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ToolsCardModel {

    @Inject
    private String title;

    @Inject
    private String subtitle;

    @Inject
    private String text;

    @Inject
    private String buttonUrl;

    @Inject
    private String buttonLabel;

    @Inject
    private String style;

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getText() {
        return text;
    }

    public String getButtonUrl() {
        return LinkUtil.getLink(buttonUrl);
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public String getStyle() {
        return style;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(subtitle) && StringUtils.isBlank(text)
                && StringUtils.isBlank(buttonUrl) && StringUtils.isBlank(buttonLabel) && StringUtils.isBlank(style);
    }
}
