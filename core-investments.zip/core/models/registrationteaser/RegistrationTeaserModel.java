package com.jhi.aem.website.v1.core.models.registrationteaser;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.models.image.ImageModel;

@Model(adaptables = Resource.class)
public class RegistrationTeaserModel {

    @Inject
    @Default
    private String index;

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String topText;

    @Inject
    @Optional
    private ImageModel image;

    @Inject
    @Default
    private String sideText;

    public String getIndex() {
        return index;
    }

    public String getTitle() {
        return title;
    }

    public String getTopText() {
        return topText;
    }

    public String getImagePath() {
        return ImageModel.getImagePath(image);
    }

    public String getSideText() {
        return sideText;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(topText) && StringUtils.isBlank(sideText) && image == null;
    }
}
