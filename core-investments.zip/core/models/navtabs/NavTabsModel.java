package com.jhi.aem.website.v1.core.models.navtabs;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class NavTabsModel {
	private final static CharsetEncoder ASCII_ENCODER = Charset.forName("US-ASCII").newEncoder();

	@Inject @Named("tabsContainerId") @Default(values="")
	private String tabsContainerId;

	@Inject @Named("tabsListId") @Default(values="")
	private String tabsListId;

	@Inject @Named("navType") @Default(values="")
	private String navType;

	@Inject @Named("tabNames") @Default(values="")
	private List<Resource> tabNames;

	private List<TabIdentifier> tabIdentifiers;
	
	public static class TabIdentifier {
		private final String tabName;
		private final String tabHtmlIdentifier;

		TabIdentifier(String tabName) {
			this.tabName = tabName;
			this.tabHtmlIdentifier = normaliseIdentifier(tabName);
		}

		public String getTabName() {
			return tabName;
		}

		public String getTabHtmlIdentifier() {
			return tabHtmlIdentifier;
		}
		
		private String normaliseIdentifier(String filename) {
			StringBuilder normalised = new StringBuilder();
			
			for (int i=0; i<filename.length(); i++) {
				char character = filename.charAt(i);
				if (ASCII_ENCODER.canEncode(character) && Character.isLetterOrDigit(character)) {
					normalised.append(character);
				} else {
					normalised.append("_");
				}
			}
			
			return normalised.toString();
		}
	}

	@PostConstruct
	private void init() {
		tabIdentifiers = new ArrayList<>(tabNames != null ? tabNames.size() : 0);
		for(Resource resource:tabNames) {
			String tabName = (String) resource.getValueMap().get("tabText");
			tabIdentifiers.add(new TabIdentifier(tabName));
		}
		//Arrays.stream(tabNames).forEach(tabName -> tabIdentifiers.add(new TabIdentifier(tabName)));
	}

	public String getTabsContainerId() {
		return tabsContainerId;
	}

	public String getTabsListId() {
		return tabsListId;
	}

	public String getNavType() {
		return navType;
	}

	public List<Resource> getTabNames() {
		return tabNames == null ? new ArrayList<Resource>(): tabNames;
	}

	public List<TabIdentifier> getTabIdentifiers() {
		return tabIdentifiers;
	}
}
