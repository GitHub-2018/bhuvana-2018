package com.jhi.aem.website.v1.core.models.download_assets;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class DownloadAssetsModel {

    @Inject
    @Optional
    private DownloadAssetModel assetOne;

    @Inject
    @Optional
    private DownloadAssetModel assetTwo;

    public DownloadAssetModel getAssetOne() {
        return assetOne;
    }
    
    public boolean getAssetOneValid() {
    	return assetOne != null && assetOne.isValid();
    }

    public DownloadAssetModel getAssetTwo() {
        return assetTwo;
    }

    public boolean getAssetTwoValid() {
    	return assetTwo != null && assetTwo.isValid();
    }

    public boolean isBlank() {
        return assetOne == null && assetTwo == null;
    }
}
