package com.jhi.aem.website.v1.core.models.download_assets;

import java.util.Collections;

import javax.annotation.PostConstruct;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PipDownloadEntriesRootModel {

	private static final Logger LOG = LoggerFactory.getLogger(PipDownloadEntriesRootModel.class);
	
	@OSGiService
    private ResourceResolverFactory resolverFactory;

    private Resource pipDownloadsRoot;
    
    @PostConstruct
    private void init() {
    	ResourceResolver resolver;
		try {
			resolver = resolverFactory.getServiceResourceResolver(
			        Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));
			pipDownloadsRoot = resolver.getResource(JhiConstants.PIP_DOWNLOADS_PATH);
		} catch (LoginException e) {
			LOG.error("Exception initializing PipDownloadEntriesRootModel", e);
		}
    }
    
    public Resource getPipDownloadsRoot() {
    	return pipDownloadsRoot;
    }
}
