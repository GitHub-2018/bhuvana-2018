package com.jhi.aem.website.v1.core.models.download_assets;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DownloadAssetModel {

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String link;

    @Inject
    @Default
    private String copy;

    @Inject
    @Default
    private String cta;

    @Inject
    @Default
    private String downloadLabel;

    @Inject
    @Optional
    private ImageModel thumbnail;

    @Inject
    @Default
    private String thumbnailAlt;

    @Inject
    private ResourceResolver resourceResolver;

    public boolean isTitleExists() {
        return StringUtils.isNotBlank(title);
    }

    public String getTitle() {
        return title;
    }

    public String getLink() {
        return link;
    }

    public boolean isCopyExists() {
        return StringUtils.isNotBlank(copy);
    }

    public String getCopy() {
        return copy;
    }

    public String getCta() {
        return cta;
    }

    public String getDownloadLabel() {
        return downloadLabel;
    }

    public boolean isThumbnailExists() {
        return thumbnail != null && StringUtils.isNotBlank(thumbnail.getPath());
    }

    public String getThumbnailPath() {
        return ImageModel.getImagePath(thumbnail);
    }

    public String getThumbnailAlt() {
        return thumbnailAlt;
    }

    public boolean isPublic() {
        if (LinkUtil.isInternalPath(link)) {
            String resourcePath = org.apache.commons.lang.StringUtils.removeEnd(link, JhiConstants.URL_HTML_EXTENSION);
            Resource resourcePageContentResource =
                    resourceResolver.getResource(resourcePath + JhiConstants.SLASH + JcrConstants.JCR_CONTENT);
            if (resourcePageContentResource != null) {
                ValueMap resourcePageContentValues = resourcePageContentResource.getValueMap();
                return !resourcePageContentValues.containsKey(JhiConstants.ACCESS_PROPERTY)
                        || StringUtils.equals(resourcePageContentValues.get(JhiConstants.ACCESS_PROPERTY, String.class), JhiConstants.ACCESS_PUBLIC);
            }
        }
        return true;
    }

    public boolean isValid() {
        return StringUtils.isNoneBlank(link, downloadLabel);
    }
}
