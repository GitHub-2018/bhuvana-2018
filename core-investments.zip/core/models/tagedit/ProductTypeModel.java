package com.jhi.aem.website.v1.core.models.tagedit;

import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
/** Should show for only product type tags */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ProductTypeModel {

    @Self
    private SlingHttpServletRequest request;

    @Inject
    @Via("resource")
    @Default
    private String fieldLabel;

    @Inject
    @Via("resource")
    @Default
    private String id;

    @Inject
    @Via("resource")
    @Default
    private String name;

    @Inject
    private ResourceResolver resolver;

    private String tagPath;
    private String fundDetailsTitle;
    private Integer fundDetailsOrderNumber;
    private Boolean isProductType;

    @PostConstruct
    public void init() {
        tagPath = request.getRequestPathInfo().getSuffix();
        Optional.ofNullable(tagPath)
                .filter(this::isProductType)
                .map(resolver::getResource)
                .map(Resource::getValueMap)
                .ifPresent(valueMap -> {
                    fundDetailsTitle = valueMap.get("fundDetailsTitle", String.class);
                    fundDetailsOrderNumber = valueMap.get("fundDetailsOrderNumber", Integer.class);
                });
    }

    public Boolean getProductType() {
        return isProductType;
    }

    public String getFundDetailsTitle() {
        return fundDetailsTitle;
    }

    public Integer getFundDetailsOrderNumber() {
        return fundDetailsOrderNumber;
    }

    public String getTagPath() {
        return tagPath;
    }

    public String getFieldLabel() {
        return fieldLabel;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    private boolean isProductType(String tagsPath) {
        isProductType = StringUtils.substringBeforeLast(tagsPath, "/").equalsIgnoreCase(JhiConstants.FUNDS_TAG_PATH);
        return isProductType;
    }
}
