package com.jhi.aem.website.v1.core.models.tagedit;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.jhi.aem.website.v1.core.models.fund.FundTag;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
/**
 * Should show for only asset class tags
 */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AssetClassPickerModel {
	private final static Logger LOG = LoggerFactory.getLogger(AssetClassPickerModel.class);

    @Self
    private SlingHttpServletRequest request;

    @Inject
    @Via("resource")
    @Default
    private String fieldLabel;

    @Inject
    @Via("resource")
    @Default
    private String id;

    @Inject
    @Via("resource")
    @Default
    private String name;
    
    @Inject
    private ResourceResolver resolver;

    @OSGiService
    private AssetManagerService assetManagerService;
    
    private String tagPath;
    
    private String assetClass = "";

    private Set<AssetClassDescription> assetClasses;

    private boolean shouldShow = false;
    
    public static class AssetClassDescription {
    	private String tag;
    	private String name;
		private boolean isSelected;
    	
		public AssetClassDescription(Tag assetClassTag, boolean isSelected) {
			this.isSelected = isSelected;
			this.tag = assetClassTag.getTagID();
			this.name = assetClassTag.getTitle();
		}

		public String getTagID() {
			return tag;
		}

		public String getName() {
			return name;
		}

		public boolean isSelected() {
			return isSelected;
		}
    }

    @PostConstruct
    public void init() {
    	// Get the current tag path from the suffix
    	tagPath = request.getRequestPathInfo().getSuffix();

        if (StringUtils.isNotBlank(tagPath) && StringUtils.isNotBlank(name)) {
        	Resource resource = resolver.getResource(tagPath);

        	if (!ResourceUtil.isNonExistingResource(resource)) {
        		Tag tag = resource.adaptTo(Tag.class);
        		
        		if (tag != null) {
    				shouldShow = new FundTag(tag).isFundTag();
        		}

        		if (shouldShow) {
	        		ValueMap valueMap = resource.getValueMap();
	        		assetClass = (String) valueMap.get(StringUtils.removeStart(name, "./"));
        		}
        	} else {
				LOG.warn("Cannot find tag with path {}", tagPath);
				tagPath = null;
			}
        }

        assetClasses = new LinkedHashSet<>();
    	assetManagerService.getAllAssetClassesTags(request.getResourceResolver())
        		.stream()
        		.forEach(assetClassTag -> {
        			boolean isSelected = assetClass != null && StringUtils.equals(assetClass, assetClassTag.getTagID());
        			assetClasses.add(new AssetClassDescription(assetClassTag, isSelected));
        		});

    }

    public String getTagPath() {
    	return tagPath;
    }

	public boolean isShouldShow() {
		return shouldShow;
	}

	public String getFieldLabel() {
		return fieldLabel;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public Set<AssetClassDescription> getAssetClasses() {
		return assetClasses;
	}

}
