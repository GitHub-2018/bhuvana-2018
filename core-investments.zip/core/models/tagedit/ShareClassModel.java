package com.jhi.aem.website.v1.core.models.tagedit;

import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.models.fund.tags.ShareClass;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
/** Should show for only share class tags */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ShareClassModel {

    @Self
    private SlingHttpServletRequest request;

    @Inject
    @Via("resource")
    @Default
    private String fieldLabel;

    @Inject
    @Via("resource")
    @Default
    private String id;

    @Inject
    @Via("resource")
    @Default
    private String name;

    @Inject
    private ResourceResolver resolver;

    private String tagPath;

    private ShareClass shareClass;

    @PostConstruct
    public void init() {
        tagPath = request.getRequestPathInfo().getSuffix();

        if (StringUtils.isNotBlank(tagPath)) {
            shareClass = Optional.ofNullable(resolver.getResource(tagPath))
                    .map(resource -> resource.adaptTo(ShareClass.class))
                    .orElse(ShareClass.EMPTY);
        }
    }

    public String getTagPath() {
        return tagPath;
    }

    public String getFieldLabel() {
        return fieldLabel;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getShareClass() {
        return shareClass.getShareClass();
    }

    public boolean isActive() {
        return shareClass.isActive();
    }

}
