package com.jhi.aem.website.v1.core.models.tagedit;

import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.jhi.aem.website.v1.core.models.fund.FundTag;

/**
 * The Ticker id model should show ticker id for fund and class share tags only.
 */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class TickerIdModel {

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue(via = "resource")
    private String fieldLabel;

    @ValueMapValue(via = "resource")
    private String id;

    @ValueMapValue(via = "resource")
    private String name;

    private String tickerId;

    @SlingObject
    private ResourceResolver resolver;

    @PostConstruct
    public void init() {
        String tagPath = request.getRequestPathInfo().getSuffix();
        if (StringUtils.isNotBlank(tagPath)) {
            tickerId = Optional.ofNullable(resolver.getResource(tagPath))
                    .map(resource -> resource.adaptTo(FundTag.class))
                    .map(FundTag::getFundCode)
                    .orElse(StringUtils.EMPTY);
        }
    }

    public String getFieldLabel() {
        return fieldLabel;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getTickerId() {
        return tickerId;
    }
}
