package com.jhi.aem.website.v1.core.models.runmode;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.jhi.aem.website.v1.core.service.runmode.RunModeService;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RunmodeModel {
	
    @OSGiService
	private RunModeService runmodeService;

	public boolean isAuthor() {
		return runmodeService.isAuthor();
	}

	public boolean isPublish() {
		return runmodeService.isPublish();
	}

	public boolean isLocal() {
		return runmodeService.isLocal();
	}

	public boolean isDevelopment() {
		return runmodeService.isDevelopment();
	}

	public boolean isStaging() {
		return runmodeService.isStaging();
	}

	public boolean isProduction() {
		return runmodeService.isProduction();
	}

}
