package com.jhi.aem.website.v1.core.models.html;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.wcm.api.WCMMode;
import com.jhi.aem.website.v1.core.models.header.HtmlEditModel;
import com.jhi.aem.website.v1.core.service.html.HtmlComponentEditService;

public abstract class AbstractHtmlEditableModel {
	public static final String DEFAULT_HTML_EDIT_RESOURCE_PATH = "htmlEdit";
	private static final Logger LOG = LoggerFactory.getLogger(AbstractHtmlEditableModel.class);

    @OSGiService
    private HtmlComponentEditService htmlComponentEditService;

    public abstract HtmlEditModel getHtmlEditModel();

	protected HtmlEditModel initialiseHtmlEdit(SlingHttpServletRequest request, Resource resource,
			HtmlComponentEditService htmlComponentEditService, String htmlEditPath) {
		HtmlEditModel htmlEdit = getHtmlEditModel();

		// If there is no HTML override or the HTML is empty then get the inner HTML for this resource
        if (WCMMode.fromRequest(request) == WCMMode.EDIT && (htmlEdit == null || StringUtils.isBlank(htmlEdit.getHtml())) ) {
        	if (htmlEdit == null) {
        		htmlEdit = new HtmlEditModel();
        	}

        	if (resource != null) {
	        	String innerHtmlForResource = htmlComponentEditService.getInnerHtmlForResource(request, resource.getPath());
	        	if (StringUtils.isNotBlank(innerHtmlForResource)) {
		        	htmlEdit.setHtml(innerHtmlForResource);
		        	
		        	// Set the content so it shows in the dialog
		        	Session jcrSession = resource.getResourceResolver().adaptTo(Session.class);
		        	String path = resource.getPath() + "/" + htmlEditPath;
		        	Node jcrNode = null;
		        	
		        	try {
		    			if (!jcrSession.nodeExists(path)) {
		    				// Create the path
		    				jcrNode = JcrUtil.createPath(path, JcrConstants.NT_UNSTRUCTURED , JcrConstants.NT_UNSTRUCTURED , jcrSession, true);
		    			} else {
		    				jcrNode = jcrSession.getNode(path);
		    			}
		    		} catch (RepositoryException e) {
						LOG.warn("Error setting up HTML content for dialog with path '" + path + "'", e);
		    		}
		
		        	if (jcrNode != null) {
			        	try {
							jcrNode.setProperty("enabled", Boolean.FALSE);
				        	jcrNode.setProperty("html", htmlEdit.getHtml());
				        	jcrSession.save();
				        	LOG.debug("Set up HTML properties for '{}'", path);
						} catch (RepositoryException e) {
							LOG.warn("Could not set up HTML properties for '{}'", path, e);
						}
		        	}
	        	}
        	}
        }
        
        return htmlEdit;
	}

	public boolean getHtmlOverride() {
		return getHtmlEditModel() != null && getHtmlEditModel().getEnabled();
	}

	public String getHtml() {
		return getHtmlEditModel() != null ? getHtmlEditModel().getHtml() : "";
	}

}
