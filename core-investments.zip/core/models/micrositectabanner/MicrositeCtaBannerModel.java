package com.jhi.aem.website.v1.core.models.micrositectabanner;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeCtaBannerModel {

    @Inject
    private String title;

    @Inject
    private String text;

    @Inject
    private String buttonUrl;

    @Inject
    private String buttonLabel;

    @Inject
    private String wrappingClass;

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getButtonUrl() {
        return buttonUrl;
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public String getWrappingClass() {
        return wrappingClass;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(buttonUrl)
                && StringUtils.isBlank(buttonLabel) && StringUtils.isBlank(wrappingClass);
    }
}
