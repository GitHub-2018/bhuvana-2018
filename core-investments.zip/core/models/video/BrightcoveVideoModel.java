package com.jhi.aem.website.v1.core.models.video;

import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class BrightcoveVideoModel extends ImageProcessingModel {

    public static final char UUID_SEPARATOR = '-';

	@Inject @Optional
	public boolean renderContainerDiv;
	
	@Inject @Optional
	public boolean playInPlace;
	
	@Inject
    @Default
    private String account;

    @Inject
    @Default
    private String videoPlayer;

    @Inject
    @Default
    private String text;
    
    @Inject
    @Default
    private String videoPlayerId;

    private String componentId;

    public String getAccount() {
        return account;
    }

    public String getVideoPlayer() {
        return videoPlayer;
    }

    public String getComponentId() {
        if (StringUtils.isBlank(componentId)) {
            componentId = StringUtils.remove(UUID.randomUUID().toString(), UUID_SEPARATOR);
        }
        return componentId;
    }

    public boolean isBlank() {
        return super.isBlank() && StringUtils.isBlank(account) && StringUtils.isBlank(videoPlayer);
    }

    public String getText() {
		return text;
	}

	public String getVideoPlayerId() {
		return videoPlayerId;
	}

	public void setVideoPlayerId(String videoPlayerId) {
		this.videoPlayerId = videoPlayerId;
	}

	public boolean isRenderContainerDiv() {
		return renderContainerDiv;
	}
	
	public boolean isPlayInPlace() {
		return playInPlace;
	}

}
