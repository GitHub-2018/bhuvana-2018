package com.jhi.aem.website.v1.core.models.separator;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SeparatorModel {

    @Inject
    @Default
    private String cssClass;

    public String getCssClass() {
        return cssClass;
    }
}
