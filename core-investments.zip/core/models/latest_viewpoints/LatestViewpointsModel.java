package com.jhi.aem.website.v1.core.models.latest_viewpoints;

import java.util.List;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class LatestViewpointsModel {

    private static final int LATEST_VIEWPOINTS_LIST_MAX_ITEMS = 4;
    private static final int LATEST_VIEWPOINTS_MAX_ITEMS = 3;

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String allItemsLabel;

    @Inject
    @Default
    private String analyticsClass;

    @Inject
    private Page resourcePage;

    @Self
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    @OSGiService
    private ViewpointsService viewpointsService;

    private List<ViewpointDetailModel> latestViewpoints;
    private String allItemsPath;

    @PostConstruct
    protected void init() {
        Page viewpointsRootPage = ViewpointUtil.getViewpointsMainPage(resourcePage);
        if (viewpointsRootPage != null) {
            int maxItems = LATEST_VIEWPOINTS_LIST_MAX_ITEMS;
            if (resource.isResourceType(ResourcesConstants.LATEST_VIEWPOINTS_RESOURCE_TYPE)) {
                maxItems = LATEST_VIEWPOINTS_MAX_ITEMS;
            }
            latestViewpoints = viewpointsService.getLatestViewpoints(resourceResolver, viewpointsRootPage.getPath(), maxItems);
            Page allItemsPage = PageUtil.getChildByResourceType(viewpointsRootPage, ResourcesConstants.VIEWPOINT_LIST_PAGE_RESOURCE_TYPE);
            if (allItemsPage != null) {
                allItemsPath = allItemsPage.getPath();
            }
        }
    }

    public String getTitle() {
        return title;
    }

    public String getAllItemsLabel() {
        return allItemsLabel;
    }

    public String getAllItemsPath() {
        return LinkUtil.getLink(allItemsPath);
    }

    public String getAnalyticsClass() {
        return analyticsClass;
    }

    public List<ViewpointDetailModel> getViewpoints() {
        return latestViewpoints;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(allItemsLabel);
    }
}
