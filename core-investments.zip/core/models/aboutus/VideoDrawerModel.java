package com.jhi.aem.website.v1.core.models.aboutus;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class VideoDrawerModel {

    @ValueMapValue
    private String heading;

    @ValueMapValue
    private String text;

    @ChildResource
    private VideoTabModel first;

    @ChildResource
    private VideoTabModel second;

    @ChildResource
    private VideoTabModel third;

    public String getHeading() {
        return heading;
    }

    public String getText() {
        return text;
    }

    public VideoTabModel getFirst() {
        return first;
    }

    public VideoTabModel getSecond() {
        return second;
    }

    public VideoTabModel getThird() {
        return third;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(heading) && StringUtils.isBlank(text) && Objects.isNull(first) && Objects.isNull(second)
                && Objects.isNull(third);
    }
}
