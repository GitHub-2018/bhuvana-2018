package com.jhi.aem.website.v1.core.models.aboutus;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DiscoverSectionModel {

    @ValueMapValue
    private String heading;

    @ValueMapValue
    private String text;

    @ChildResource
    private VideoTabModel video;

    public String getHeading() {
        return heading;
    }

    public String getText() {
        return text;
    }

	public VideoTabModel getVideo() {
		return video;
	}

	public boolean isBlank() {
        return StringUtils.isBlank(heading) && StringUtils.isBlank(text) && Objects.isNull(video);
    }
}
