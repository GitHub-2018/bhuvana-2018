package com.jhi.aem.website.v1.core.models.aboutus;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.servlets.assetmanager.AssetManagerServlet;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AssetManagersContainerModel {

    @Inject
    private String heading;

    @Inject
    private String text;

    @Inject
    private String buttonLabel;

    @Inject
    private String closeLabel;

    @Inject
    private String popupTitle;

    @Inject
    private String allAssetClassesLabel;

    @Inject
    private String allInvestmentTypesLabel;

    @Inject
    private String emptyListMessage;

    @Inject
    private String legalCopy;

    @Inject
    private AssetManagerService assetManagerService;

    @Inject
    private ResourceResolver resolver;

    @Inject
    private Page resourcePage;

    private List<AssetManagerModel> assetManagers;

    @PostConstruct
    private void init() {
        assetManagers = assetManagerService.getGridAssetManagers(PageUtil.getAssetManagersConfigRootPath(resourcePage));
    }

    public String getHeading() {
        return heading;
    }

    public String getText() {
        return text;
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public String getCloseLabel() {
        return closeLabel;
    }

    public String getPopupTitle() {
        return popupTitle;
    }

    public String getAllAssetClassesLabel() {
        return allAssetClassesLabel;
    }

    public String getAllInvestmentTypesLabel() {
        return allInvestmentTypesLabel;
    }

    public String getEmptyListMessage() {
        return emptyListMessage;
    }

    public String getLegalCopy() {
        return legalCopy;
    }

    public List<AssetManagerModel> getAssetManagers() {
        return assetManagers;
    }

    public String getAssetManagerListUrl() {
        return getAssetManagersRootPath() + AssetManagerServlet.LIST_SELECTOR_ENDING;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(heading) && StringUtils.isBlank(text) && StringUtils.isBlank(buttonLabel);
    }

    private String getAssetManagersRootPath() {
        return Optional.ofNullable(PageUtil.getChildByResourceType(PageUtil.getHomePage(resourcePage),
                ResourcesConstants.ASSET_MANAGERS_ROOT_PAGE_RESOURCE_TYPE))
                .map(Page::getContentResource)
                .map(Resource::getPath)
                .orElse(StringUtils.EMPTY);
    }
}
