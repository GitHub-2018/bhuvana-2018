package com.jhi.aem.website.v1.core.models.aboutus;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class VideoTabModel {

    @Inject
    private String title;

    @Inject
    private String text;

    @Inject
    private String videoLink;

    @Inject
    private String videoTitle;

    @Inject
    private ImageProcessingModel image;

    @Inject
    private String linkUrl;

    @Inject
    private String linkLabel;

    @Inject
    private String linkId;

    @OSGiService
    private ResourceResolverFactory resolverFactory;

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getVideoLink() {
        return videoLink;
    }

    public String getVideoTitle() {
        return videoTitle;
    }

    public String getVideoImage() {
        return ImageModel.getImagePath(image);
    }

    public String getLinkUrl() {
        return LinkUtil.getLinkWithDefaultResolver(resolverFactory, linkUrl);
    }

    public String getLinkLabel() {
        return linkLabel;
    }

    public String getLinkId() {
        return linkId;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(videoLink)
                && StringUtils.isBlank(getVideoImage())
                && StringUtils.isBlank(linkUrl) && StringUtils.isBlank(linkLabel) && StringUtils.isBlank(linkId);
    }
}
