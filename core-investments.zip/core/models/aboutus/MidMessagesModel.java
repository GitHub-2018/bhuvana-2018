package com.jhi.aem.website.v1.core.models.aboutus;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MidMessagesModel {

	@Inject
	private VideoTabModel left;

	@Inject
	private VideoTabModel right;

	public VideoTabModel getLeft() {
		return left;
	}

	public VideoTabModel getRight() {
		return right;
	}

	public boolean isBlank() {
		return (left == null || left.isBlank()) && (right == null || right.isBlank());
	}
}
