package com.jhi.aem.website.v1.core.models.viewpoint_asset_manager;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointAssetManagerHeaderModel {

    @Inject
    protected ResourceResolver resourceResolver;

    @Inject
    private Page resourcePage;

    @Inject
    private PageManager pageManager;

    private ViewpointsAssetManagerModel assetManagerModel;

    @PostConstruct
    protected void init() {
        String assetManagerReferencePath = getAssetManagerReferencePath(resourcePage);
        if (StringUtils.isNotBlank(assetManagerReferencePath)) {
            Page assetManagerPage = pageManager.getPage(assetManagerReferencePath);
            if (assetManagerPage != null) {
                assetManagerModel = ViewpointsAssetManagerModel.fromAssetManagerPage(assetManagerPage);
            }
        }
    }

    public ViewpointsAssetManagerModel getAssetManager() {
        return assetManagerModel;
    }

    public boolean isBlank() {
        return assetManagerModel == null;
    }

    public static String getAssetManagerReferencePath(Page page) {
        if (page != null) {
            String assetManagerReferencePath = PageUtil.getPageContentProperty(page, ViewpointsAssetManagerModel.ASSET_MANAGER_REFERENCE,
                    String.class);
            if (StringUtils.isNotBlank(assetManagerReferencePath)) {
                return assetManagerReferencePath;
            }
            String assetManagersRootPath = PageUtil.getAssetManagersConfigRootPath(page);
            if (StringUtils.isNotBlank(assetManagersRootPath)) {
                return assetManagersRootPath + JhiConstants.SLASH + page.getName();
            }
        }
        return StringUtils.EMPTY;
    }
}
