package com.jhi.aem.website.v1.core.models.viewpoint_asset_manager;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointsAssetManagerModel implements Comparable<ViewpointsAssetManagerModel> {

    public static final String ASSET_MANAGER_PATH = "assetManager";
    public static final String ASSET_MANAGER_REFERENCE = "assetManagerReference";
    public static final String DESCRIPTION_PROPERTY = "longDescription";

    @Inject
    @Optional
    private ImageModel logo;

    @Inject
    @Default
    private String longDescription;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    private String name;
    private String logoPath;
    private String pageLink;

    @PostConstruct
    private void init() {
        name = PageUtil.getPageNavigationTitle(resourcePage);
        logoPath = ImageModel.getImagePath(logo);
        pageLink = null;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public String getName() {
        return name;
    }

    public String getPageLink() {
        if (pageLink == null) {
            pageLink = LinkUtil.getPageLink(ViewpointUtil.getViewpointsAssetManagerPage(resourceResolver, resourcePage));
        }
        return pageLink;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(name) || logo == null;
    }

    public static ViewpointsAssetManagerModel fromAssetManagerPage(Page page) {
        return PageUtil.getModelFromPage(page, ASSET_MANAGER_PATH, ViewpointsAssetManagerModel.class);
    }

    public static ViewpointsAssetManagerModel fromViewpointsAssetManagerPage(Page page) {
        if (page != null) {
            String assetManagerReferencePath = PageUtil.getPageContentProperty(page, ASSET_MANAGER_REFERENCE, String.class);
            if (StringUtils.isBlank(assetManagerReferencePath)) {
                String assetManagersRootPath = PageUtil.getAssetManagersConfigRootPath(page);
                if (StringUtils.isNotBlank(assetManagersRootPath)) {
                    assetManagerReferencePath = assetManagersRootPath + JhiConstants.SLASH + page.getName();
                }
            }
            if (StringUtils.isNotBlank(assetManagerReferencePath)) {
                PageManager pageManager = page.getContentResource().getResourceResolver().adaptTo(PageManager.class);
                if (pageManager != null) {
                    Page assetManagerPage = pageManager.getPage(assetManagerReferencePath);
                    if (assetManagerPage != null) {
                        ViewpointsAssetManagerModel viewpointsAssetManagerModel = ViewpointsAssetManagerModel
                                .fromAssetManagerPage(assetManagerPage);
                        viewpointsAssetManagerModel.pageLink = LinkUtil.getPageLink(page);
                        return viewpointsAssetManagerModel;
                    }
                }
            }
        }
        return null;
    }

    public static ViewpointsAssetManagerModel fetchDefaultAssetManager(Page resourcePage) {
        String defaultAssetManagerPath = ViewpointUtil.getDefaultAssetManager(resourcePage);
        if (StringUtils.isNotBlank(defaultAssetManagerPath)) {
            PageManager pageManager = PageUtil.getPageManager(resourcePage);
            if (pageManager != null) {
                Page defaultViewpointsAssetManagerPage = pageManager.getPage(defaultAssetManagerPath);
                if (defaultViewpointsAssetManagerPage != null) {
                    return ViewpointsAssetManagerModel.fromViewpointsAssetManagerPage(defaultViewpointsAssetManagerPage);
                }
            }
        }
        return null;
    }

    @Override
    public int compareTo(ViewpointsAssetManagerModel other) {
        if (StringUtils.isBlank(name)) {
            return 1;
        }
        return name.compareTo(other.name);
    }
}
