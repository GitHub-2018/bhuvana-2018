package com.jhi.aem.website.v1.core.models.pressinfo;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PressInfoModel {

	@Inject
	private String heading;

	@Inject
	private String text;

	@Inject
	private String email;

	@Inject
	private String emailDescription;

	@Inject
	private String phone;

	@Inject
	private String phoneDescription;

	public String getHeading() {
		return heading;
	}

	public String getText() {
		return text;
	}

	public String getEmail() {
		return email;
	}

	public String getEmailDescription() {
		return emailDescription;
	}

	public String getPhone() {
		return phone;
	}

	public String getPhoneDescription() {
		return phoneDescription;
	}

	public boolean isBlank() {
		return StringUtils.isBlank(heading) && StringUtils.isBlank(text) && StringUtils.isBlank(email)
				&& StringUtils.isBlank(emailDescription) && StringUtils.isBlank(phone)
				&& StringUtils.isBlank(phoneDescription);
	}
}
