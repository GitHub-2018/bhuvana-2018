package com.jhi.aem.website.v1.core.models.footer;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.generic.link.AnalyticsLink;
import com.jhi.aem.website.v1.core.generic.link.LinkUtils;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FooterModel {

    @Inject
    @Via("resource")
    @Default
    private String logoAlt;

    @Inject
    @Via("resource")
    @Default
    private String customlogoImageLink;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> primaryNavigation;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> secondaryNavigation;

    @Inject
    @Via("resource")
    @Default
    private String copyrightText;

    @Inject
    @Via("resource")
    @Default
    private String copyrightText1;

    @Inject
    @Via("resource")
    @Default
    private String copyrightText2;

    @Inject
    @Via("resource")
    @Default
    private String copyrightText3;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> secondaryNavigationNames;

    @Inject
    @Via("resource")
    @Default
    private List<Resource> primaryNavigationNames;

    @Inject
    private Page currentPage;

    @OSGiService
    private ResourceResolverFactory resolverFactory;

    @Self
    private SlingHttpServletRequest request;

    private List<AnalyticsLink> primaryNav;
    private List<AnalyticsLink> secondaryNav;

    @PostConstruct
    public void init() {
    	String countryFilterParameter = PageUtil.getUcitsCountry(request);
        String currentPagePath = currentPage.getPath();
        primaryNav = LinkUtils.createNavigation(request, resolverFactory, StringUtils.EMPTY, 0,
                primaryNavigationNames, primaryNavigation, null, currentPagePath, countryFilterParameter);
        secondaryNav = LinkUtils.createNavigation(request, resolverFactory, StringUtils.EMPTY, 0,
                secondaryNavigationNames, secondaryNavigation, null, currentPagePath, countryFilterParameter);
    }

    public String getLogoAlt() {
        return logoAlt;
    }

    public String getCustomlogoImageLink() {
        return customlogoImageLink;
    }

    public List<AnalyticsLink> getPrimaryNavigation() {
        return primaryNav;
    }

    public List<AnalyticsLink> getSecondaryNavigation() {
        return secondaryNav;
    }

    public String getCopyrightText() {
        return copyrightText;
    }

    public String getCopyrightText1() {
        return copyrightText1;
    }

    public String getCopyrightText2() {
        return copyrightText2;
    }

    public String getCopyrightText3() {
        return copyrightText3;
    }
}
