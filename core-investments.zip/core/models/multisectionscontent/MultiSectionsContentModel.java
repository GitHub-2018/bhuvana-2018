package com.jhi.aem.website.v1.core.models.multisectionscontent;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MultiSectionsContentModel {
	private final static Logger LOG = LoggerFactory.getLogger(MultiSectionsContentModel.class);

	@Inject
	private Resource sections;

	private List<SectionItem> sectionItems;


	@PostConstruct
	public void init() {
		LOG.debug("Multisite Content **** Invoked ****");
		
		Iterable<Resource> children = sections.getChildren();
		sectionItems = new ArrayList<>();
		try {
			for (Resource child : children) {
				SectionItem item = child.adaptTo(SectionItem.class);
				LOG.debug("Child one is " + item.getId());
				sectionItems.add(item);
			}
		} catch (Exception e) {
			LOG.error("Exception ", e);
		}
	}


	/**
	 * @return the sectionItems
	 */
	public final List<SectionItem> getSectionItems() {
		return sectionItems;
	}

	public boolean isBlank() {
		return sections == null;
	}

}
