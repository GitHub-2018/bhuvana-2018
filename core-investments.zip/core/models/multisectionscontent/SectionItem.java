package com.jhi.aem.website.v1.core.models.multisectionscontent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SectionItem {
	public static final String NON_ALPHANUMERICAL_PATTERN = "[^\\p{Alnum}]";
	
	@Inject
	private String title;
	
	@Inject
	private String hideInNav;
	
	@Inject
	private String cssClass;
	
	private ThreadLocal<Matcher> titleIdReplacementMatcher = new ThreadLocal<Matcher>() {
		protected Matcher initialValue() {
			return Pattern.compile(NON_ALPHANUMERICAL_PATTERN).matcher("");
		}
	};

	public String getTitle() {
		return title;
	}

	public String getId() {
		if (StringUtils.isNotBlank(title)) {
			Matcher replacementMatcher = titleIdReplacementMatcher.get().reset(title);
			return StringUtils.lowerCase(replacementMatcher.replaceAll(JhiConstants.DASH));
		}
		
		return "UNKNOWN";
	}

	public boolean isHideInNav() {
		return BooleanUtils.toBoolean(hideInNav);
	}

	public void setHideInNav(String hideInNav) {
		this.hideInNav = hideInNav;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCssClass() {
		return cssClass;
	}

}
