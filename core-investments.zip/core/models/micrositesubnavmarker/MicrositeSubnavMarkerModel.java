package com.jhi.aem.website.v1.core.models.micrositesubnavmarker;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeSubnavMarkerModel {

    @Inject
    private Boolean enabled;

    @Inject
    private String id;

    @Inject
    private String name;

    @Inject
    private String label;

    public boolean getEnabled() {
        return Boolean.TRUE.equals(enabled);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLabel() {
        return label;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(id) && StringUtils.isBlank(name) && StringUtils.isBlank(label);
    }

    public boolean isValid() {
        return StringUtils.isNotBlank(id) && StringUtils.isNotBlank(name) && StringUtils.isNotBlank(label);
    }
}
