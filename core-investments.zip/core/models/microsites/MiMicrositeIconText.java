package com.jhi.aem.website.v1.core.models.microsites;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.image.ImageModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MiMicrositeIconText {

	@Inject @Default(values = "Title")
	private String title;

	@Inject @Default(values = "Text")
	private String text;

	@Inject @Default(values = "icon")
	private String style;

	@Inject
	private ImageModel image;

	@Inject
	private String imageAlt;

	public String getTitle() {
		return title;
	}

	public String getText() {
		return text;
	}
	
	public String getStyle() {
		return style;
	}

	public String getImagePath() {
		return ImageModel.getImagePath(image);
	}

	public String getImageAlt() {
		return imageAlt;
	}

}
