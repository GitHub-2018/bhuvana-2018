package com.jhi.aem.website.v1.core.models.microsites;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.image.ImageModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MiMicrositeClassificationModel {

	@Inject @Default(values = "Title")
	private String title;

	@Inject @Default(values = "Top Body Copy")
	private String topBodyCopy;

	@Inject @Default(values = "Image Label")
	private String imageLabel;

	@Inject @Default(values = "Bottom Body Copy")
	private String bottomBodyCopy;

	@Inject
	private ImageModel image;

	@Inject
	private String imageAlt;

	@Inject
	private ImageModel chartKeyImage;

	@Inject
	private String chartKeyImageAlt;
	
	@Inject
	private String chartKeyImageAnnotation;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTopBodyCopy() {
		return topBodyCopy;
	}

	public void setTopBodyCopy(String topBodyCopy) {
		this.topBodyCopy = topBodyCopy;
	}

	public String getImageLabel() {
		return imageLabel;
	}

	public void setImageLabel(String imageLabel) {
		this.imageLabel = imageLabel;
	}

	public String getBottomBodyCopy() {
		return bottomBodyCopy;
	}

	public void setBottomBodyCopy(String bottomBodyCopy) {
		this.bottomBodyCopy = bottomBodyCopy;
	}

	public ImageModel getImage() {
		return image;
	}

	public void setImage(ImageModel image) {
		this.image = image;
	}

	public String getImageAlt() {
		return imageAlt;
	}

	public void setImageAlt(String imageAlt) {
		this.imageAlt = imageAlt;
	}

	public ImageModel getChartKeyImage() {
		return chartKeyImage;
	}

	public void setChartKeyImage(ImageModel mobileImage) {
		this.chartKeyImage = mobileImage;
	}

	public String getChartKeyImageAlt() {
		return chartKeyImageAlt;
	}

	public void setChartKeyImageAlt(String mobileImageAlt) {
		this.chartKeyImageAlt = mobileImageAlt;
	}

	public String getImagePath() {
		return ImageModel.getImagePath(image);
	}

	public String getChartKeyImagePath() {
		return ImageModel.getImagePath(chartKeyImage);
	}

	public String getChartKeyImageAnnotation() {
		return chartKeyImageAnnotation;
	}

	public void setChartKeyImageAnnotation(String chartKeyImageAnnotation) {
		this.chartKeyImageAnnotation = chartKeyImageAnnotation;
	}

}
