package com.jhi.aem.website.v1.core.models.mi;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.image.ImageModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MiThemesImageTileModel {

	@Inject
	private String title;

	@Inject
	private String text;

	@Inject
	private ImageModel image;

	@Inject
	private String imageAlt;

	public String getTitle() {
		return title;
	}

	public String getText() {
		return text;
	}

	public String getImagePath() {
		return ImageModel.getImagePath(image);
	}

	public String getImageAlt() {
		return imageAlt;
	}

	public boolean isBlank() {
		return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(getImagePath())
				&& StringUtils.isBlank(imageAlt);
	}
}
