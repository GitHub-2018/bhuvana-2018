package com.jhi.aem.website.v1.core.models.mi;

import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.person.PersonalBiographyDetails;
import com.jhi.aem.website.v1.core.service.person.PersonService;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MiTeamBehindModel {

    private static final Logger LOG = LoggerFactory.getLogger(MiTeamBehindModel.class);

    @Inject
    private String title;

    @Inject
    private String text;

    @Inject
    private String leftPerson;

    @Inject
    private String rightPerson;

    @Inject
    private Page resourcePage;

    @Inject
    private PersonService personService;

    private PersonalBiographyDetails leftMember;

    private PersonalBiographyDetails rightMember;

    @PostConstruct
    private void init() {
        leftMember = fetchSinglePerson(leftPerson);
        rightMember = fetchSinglePerson(rightPerson);
    }

    private PersonalBiographyDetails fetchSinglePerson(String tag) {
        if (StringUtils.isBlank(tag)) {
            return null;
        }

        List<PersonalBiographyDetails> result = personService
                .getPersonalBiographyDetailsModelsByTags(Collections.singletonList(tag), resourcePage);
        if (result == null || result.size() == 0) {
            return null;
        }

        if (result.size() > 1) {
            LOG.warn("More than 1 person tagged with " + tag + " found. Please fix content.");
        }

        return result.get(0);
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public PersonalBiographyDetails getLeftMember() {
        return leftMember;
    }

    public PersonalBiographyDetails getRightMember() {
        return rightMember;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text) && (leftMember == null || leftMember.isBlank())
                && (rightMember == null || rightMember.isBlank());
    }
}
