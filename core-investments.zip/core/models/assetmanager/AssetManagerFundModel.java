package com.jhi.aem.website.v1.core.models.assetmanager;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.google.gson.annotations.Expose;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AssetManagerFundModel implements Comparable<AssetManagerFundModel> {

	@Inject
	@Default
	@Expose
	private String name;

	@Inject
	@Default
	@Expose
	private String url;

	public AssetManagerFundModel(String name, String url) {
		super();
		this.name = name;
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public String getUrl() {
		return url;
	}

	@Override
	public int compareTo(AssetManagerFundModel other) {
		if (StringUtils.isBlank(name) && StringUtils.isNotBlank(other.name)) {
			return -1;
		}
		
		if (StringUtils.isNotBlank(name) && StringUtils.isBlank(other.name)) {
			return 1;
		}

		if (StringUtils.isBlank(name) && StringUtils.isBlank(other.name)) {
			return 0;
		}

		return name.compareTo(other.name);
	}
}
