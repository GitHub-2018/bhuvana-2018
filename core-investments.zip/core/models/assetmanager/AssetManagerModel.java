package com.jhi.aem.website.v1.core.models.assetmanager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.google.gson.annotations.Expose;
import com.jhi.aem.website.v1.core.models.fund.tags.Fund;
import com.jhi.aem.website.v1.core.models.fund.tags.FundInvestmentType;
import com.jhi.aem.website.v1.core.models.fund.tags.FundProductType;
import com.jhi.aem.website.v1.core.models.fund.tags.ShareClass;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointTagsModel;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListMapper;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;
import com.jhi.aem.website.v1.core.utils.StreamUtils;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AssetManagerModel implements Comparable<AssetManagerModel> {

    public static final AssetManagerModel EMPTY = new AssetManagerModel();
    public static final String ASSET_MANAGER_PATH = "assetManager";

    private final static Logger LOG = LoggerFactory.getLogger(AssetManagerModel.class);

    @Inject
    @Optional
    private ImageModel logo;

    @Expose
    private String logoPath;

    @Inject
    @Default
    @Expose
    private String longDescription;

    @Inject
    @Default
    @Expose
    private String shortDescription;

    @Inject
    @Optional
    private List<String> assetsClasses;

    @Inject
    @Optional
    private List<String> investmentTypes;

    @Inject
    @Optional
    @Expose
    private Set<AssetManagerFundModel> funds = new TreeSet<>();

    @Expose
    private String name;

    @Expose
    private List<String> assetsClassesLabels;

    @Expose
    private List<String> investmentTypesLabels;

    @Inject
    private Page resourcePage;

	@OSGiService
	private ResourceResolverFactory resourceResolverFactory;

    private TagManager tagManager;
    private String pagePath;

    @Expose
    private String id;

    @ValueMapValue
    private boolean hideLogoInGrid;

    @Inject
    private AssetManagerService assetManagerService;

    @OSGiService
    private FundListMapper mapper;

    @OSGiService
    private RunModeService runModeService;

    @PostConstruct
    private void init() {
    	ResourceResolver resourceResolver = null;
    	try {
    		resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
	        final Page homePage = PageUtil.getHomePage(resourcePage);
	        tagManager = resourceResolver.adaptTo(TagManager.class);
	
	        name = PageUtil.getPageNavigationTitle(resourcePage);
	
	        if (StringUtils.isNotBlank(name)) {
	            id = JcrUtil.createValidName(name);
	        }
	
	        setFunds(homePage,resourceResolver);
	
	        logoPath = ImageModel.getImagePath(logo);
	        assetsClassesLabels = gatherTagTitles(assetsClasses);
	        investmentTypesLabels = gatherTagTitles(investmentTypes);
	
	        if (resourcePage != null) {
	            Resource pageContent = resourcePage.getContentResource();
	            if (pageContent != null) {
	                ViewpointTagsModel viewpointTagsModel = pageContent.adaptTo(ViewpointTagsModel.class);
	                if (viewpointTagsModel != null) {
	                    Tag assetManagerTag = viewpointTagsModel.getAssetManagerTag();
	                    if (assetManagerTag != null) {
	                        pagePath = ViewpointUtil.createPathToAssetManagerPage(resourceResolver, resourcePage, assetManagerTag.getTagID());
	                    }
	                }
	            }
	        }
    	} finally {
			if (resourceResolver != null && resourceResolver.isLive()) {
				resourceResolver.close();
			}
		}
    }

    private void setFunds(Page homePage,ResourceResolver resourceResolver) {
        Set<String> fundTags = assetManagerService.getFundsForAssetManager(homePage, resourcePage.getPath());
        LOG.debug("asset manager [{}] tags found: [{}]", name, fundTags.size());

        fundTags.forEach(fundTagId -> {
            String tagPath = FundUtil.getTagPath(fundTagId);
            Class clazz = FundUtil.getFundTagClass(tagPath);
            if (Objects.isNull(clazz)) {
                LOG.debug("wrong fund tag id: {}", fundTagId);
            } else {
                funds.addAll(getFundsForTagPath(homePage, tagPath, clazz,resourceResolver));
            }
        });
    }

    private Set<AssetManagerFundModel> getFundsForTagPath(Page homePage, String tagPath, Class clazz,ResourceResolver resourceResolver) {
        return java.util.Optional.ofNullable(resourceResolver.getResource(tagPath))
                .map(resource -> getFundResources(clazz, resource).stream()
                        .map(r -> r.adaptTo(Fund.class))
                        .filter(Objects::nonNull)
                        .map(Fund::getDefaultShareClass)
                        .filter(shareClass -> !shareClass.equals(ShareClass.EMPTY))
                        .map(shareClass -> mapper.mapToAssetManagerFundModel(shareClass, homePage))
                        .collect(Collectors.toSet()))
                .orElseGet(() -> {
                    LOG.debug("Could not get fund tags from path: {}", tagPath);
                    return Collections.emptySet();
                });
    }

    private List<Resource> getFundResources(Class clazz, Resource resource) {
        List<Resource> fundResources = Collections.emptyList();
        if (clazz.getName().equalsIgnoreCase(ShareClass.class.getName())) {
            fundResources = getResourcesFromShareClass(resource);
        } else if (clazz.getName().equalsIgnoreCase(Fund.class.getName())) {
            fundResources = Collections.singletonList(resource);
        } else if (clazz.getName().equalsIgnoreCase(FundInvestmentType.class.getName())) {
            fundResources = IteratorUtils.toList(resource.listChildren());
        } else if (clazz.getName().equalsIgnoreCase(FundProductType.class.getName())) {
            fundResources = getResourcesFromProductType(resource);
        }
        LOG.debug("[{}] fund resources found for resource path: [{}]", fundResources.size(), resource.getPath());
        return fundResources;
    }

    private List<Resource> getResourcesFromProductType(Resource resource) {
        return IteratorUtils.toList(resource.listChildren())
                .stream()
                .flatMap(StreamUtils.getResourceChildrenFlattened())
                .collect(Collectors.toList());
    }

    private List<Resource> getResourcesFromShareClass(Resource resource) {
        return java.util.Optional.ofNullable(resource.getParent())
                .map(Collections::singletonList)
                .orElseGet(() -> {
                    LOG.debug("No share class resources found for: {}", resource.getPath());
                    return Collections.emptyList();
                });
    }

    private List<String> gatherTagTitles(List<String> tags) {
        final List<String> result = new ArrayList<>();
        if (tags == null || tags.size() == 0) {
            return result;
        }

        for (String tagPath : tags) {
            final Tag tag = tagManager.resolve(tagPath);
            if (tag != null) {
                result.add(tag.getTitle());
            }
        }

        return result;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ImageModel getLogo() {
        return logo;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public List<String> getAssetsClasses() {
        return assetsClasses;
    }

    public List<String> getInvestmentTypes() {
        return investmentTypes;
    }

    public Set<AssetManagerFundModel> getFunds() {
        return funds;
    }

    public String getPageLink() {
        if (StringUtils.isBlank(pagePath)) {
            return StringUtils.EMPTY;
        }
        return LinkUtil.getLink(pagePath);
    }

    public String getAssetManagerReference() {
        return resourcePage.getPath();
    }

    public boolean isBlank() {
        return logo == null && StringUtils.isBlank(name);
    }

    public boolean isValid() {
        return !isBlank();
    }

    public boolean showLogoInGrid() {
        return !hideLogoInGrid;
    }

    public static AssetManagerModel fromPage(Page page) {
        AssetManagerModel model = EMPTY;
        if (page != null) {
            Resource contentResource = page.getContentResource();
            if (contentResource != null) {
                Resource assetManagerResource = contentResource.getChild(ASSET_MANAGER_PATH);
                if (assetManagerResource != null) {
                    AssetManagerModel assetManagerModel = assetManagerResource.adaptTo(AssetManagerModel.class);
                    if (assetManagerModel != null) {
                        model = assetManagerModel;
                    }
                }
            }
        }
        return model;
    }

    @Override
    public int compareTo(AssetManagerModel other) {
        if (name == null) {
            return 1;
        }
        return name.compareTo(other.name);
    }
}
