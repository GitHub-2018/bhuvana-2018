package com.jhi.aem.website.v1.core.models.linklist;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jhi.aem.website.v1.core.models.fund.links.FundLink;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class LinkListModel {

    private static GsonBuilder gsonBuilder = new GsonBuilder();

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String description;

    @Inject
    private List<FundLink> linkList;
    private List<FundLink> links;

    @PostConstruct
    protected void init() {
    	/*
        if (!linkList.isEmpty()) {
            Gson gson = gsonBuilder.create();
            links = linkList.stream()
                    .map(link -> gson.fromJson(link, FundLink.class))
                    .collect(Collectors.toList());
        }
    */
    	}

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public List<FundLink> getLinks() {
        return linkList;
    }

    public boolean isConfigured() {
        return StringUtils.isNotBlank(title) || StringUtils.isNotBlank(description) || !linkList.isEmpty();
    }

}
