package com.jhi.aem.website.v1.core.models.dashboard_tail;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.PageUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DashboardTailModel {

    @Inject
    private String text;

    @Inject
    private String buttonLabel;

    @Inject
    private Page resourcePage;

    public String getText() {
        return text;
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public String getDashboardPath() {
        Page homepage = PageUtil.getHomePage(resourcePage);
        if (homepage != null) {
            return PageUtil.getPagePath(PageUtil.getChildByResourceType(homepage, ResourcesConstants
                    .DASHBOARD_PAGE_RESOURCE_TYPE));
        }
        return StringUtils.EMPTY;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(text) && StringUtils.isBlank(buttonLabel);
    }
}
