package com.jhi.aem.website.v1.core.models.recap;

import java.util.Optional;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;

import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class RecapModel {

    @Inject
    @Default
    private String text;

    @Inject
    @Default
    private String pagePath;

    @Inject
    @Default
    private String background;

    @ChildResource(injectionStrategy = InjectionStrategy.OPTIONAL)
    private ImageModel image;

    @ChildResource(injectionStrategy = InjectionStrategy.OPTIONAL)
    private ImageModel backgroundImage;

    public String getText() {
        return text;
    }

    public String getPageLink() {
        return LinkUtil.getLink(pagePath);
    }

    public String getBackground() {
        return background;
    }

    public String getImage() {
        return getImagePath(image);
    }

    public String getBackgroundImage() {
        return getImagePath(backgroundImage);
    }

    private String getImagePath(ImageModel imageModel) {
        return Optional.ofNullable(imageModel)
                .map(ImageModel::getPath)
                .orElse(StringUtils.EMPTY);
    }

    public boolean isBlank() {
        return StringUtils.isBlank(text) && StringUtils.isBlank(pagePath) && StringUtils.isBlank(background);
    }
}
