package com.jhi.aem.website.v1.core.models.micrositecta;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import com.jhi.aem.website.v1.core.models.micrositehero.WhitepaperModel;
import com.jhi.aem.website.v1.core.models.micrositesubnavmarker.MicrositeSubnavMarkerModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeCtaModel {

    private static final String TWO_COLUMN_STYLE = "twoColumn";
    private static final String THREE_COLUMN_STYLE = "threeColumn";

	@Inject
    private String title;

    @Inject
    private String copy;

    @Inject
    private String copy2;

    @Inject
    private String legalCopy;

    @Inject
    private String formMarkup;

    @Inject
    private String successMessage;

    @Inject
    private WhitepaperModel whitepaper1;

    @Inject
    private WhitepaperModel whitepaper2;

    @Inject
    private MicrositeSubnavMarkerModel subnav;

    @Inject
    private String renderStyle;
    
    @Inject
    private String formTitle;
    
    @Self
    private Resource resource;
    
    private ResourceResolver resolver;
    private Resource pageResource;
    
    
    
    private static final String JCR_CONTENT="jcr:content";
    private static final String SEPARATOR ="/";
    private static final String PRODUCT ="productName";
    private static final String MANAGER="manager";
    private static final String JCR_TITLE="jcr:title";

    public String getTitle() {
        return title;
    }

    public String getCopy() {
        return copy;
    }

    public String getLegalCopy() {
        return legalCopy;
    }

    public String getFormMarkup() {
        return formMarkup;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public WhitepaperModel getWhitepaper1() {
        return whitepaper1;
    }

    public WhitepaperModel getWhitepaper2() {
        return whitepaper2;
    }

    public MicrositeSubnavMarkerModel getSubnav() {
        return subnav;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(formMarkup) && StringUtils.isBlank(successMessage);
    }

	public String getRenderStyle() {
		return renderStyle;
	}
	
	public boolean isTwoColumnStyle() {
		// Default to this style
		return StringUtils.equals(TWO_COLUMN_STYLE, renderStyle) || !isThreeColumnStyle();
	}

	public boolean isThreeColumnStyle() {
		return StringUtils.equals(THREE_COLUMN_STYLE, renderStyle);
	}

	public String getFormTitle() {
		return formTitle;
	}

	public String getCopy2() {
		return copy2;
	}
	
	@PostConstruct 
	private  void init() {
		
		resolver = resource.getResourceResolver();
		String path =resource.getPath();
		int idx = path.lastIndexOf(SEPARATOR+JCR_CONTENT);
		path = path.substring(0, idx);
		
		pageResource = resolver.getResource(path);
		
	}
	
	public String getProduct() {
		ValueMap vm = pageResource.getChild(JCR_CONTENT).getValueMap();
		return (vm.get(PRODUCT) != null ? vm.get(PRODUCT).toString() : vm.get(JCR_TITLE, "").toString());
		
	}
	
	public String getPage() {
		ValueMap vm =pageResource.getChild(JCR_CONTENT).getValueMap();
		return (vm.get(JCR_TITLE) != null ? vm.get(JCR_TITLE).toString() : pageResource.getName());
	}

	public String getPagePath() {
		String pagePath = pageResource.getPath();
		if (LinkUtil.isInternalPath(pagePath)) {
			Page page = resolver.adaptTo(PageManager.class).getPage(pagePath);
			if (page != null) {
				pagePath = LinkUtil.getPageLink(page);
			} else {
				pagePath = LinkUtil.getLink(resolver, pagePath);
			}
		}

		return resolver.map(pagePath);
	}
	
	public String getManager() {
		ValueMap vm =pageResource.getChild(JCR_CONTENT).getValueMap();
		return vm.get(MANAGER,"").toString();
	}

}
