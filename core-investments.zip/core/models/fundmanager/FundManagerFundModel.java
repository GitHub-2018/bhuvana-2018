package com.jhi.aem.website.v1.core.models.fundmanager;

import java.util.Calendar;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundManagerFundModel {

    public static final String FUND_PATH = "fund";

    @Inject
    private String fund;

    @Inject
    private Integer startYear;

    @ValueMapValue
    private Boolean lead = false;

    private String title;

    private String path;

    private Integer yearsOnFund;

    @Inject
    private ResourceResolver resolver;

    @PostConstruct
    private void init() {
        if (StringUtils.isBlank(fund)) {
            return;
        }

        final TagManager tagManager = resolver.adaptTo(TagManager.class);
        final Tag tag = tagManager.resolve(fund);
        if (tag == null) {
            return;
        }

        title = tag.getTitle();
        path = tag.getPath();

        final int currentYear = Calendar.getInstance(Locale.US).get(Calendar.YEAR);
        yearsOnFund = currentYear - (startYear == null ? 0 : startYear);
    }

    public String getFund() {
        return fund;
    }

    public Integer getStartYear() {
        return startYear;
    }

    public String getTitle() {
        return title;
    }

    public String getPath() {
        return path;
    }

    public Integer getYearsOnFund() {
        return yearsOnFund;
    }

    public Boolean getLead() {
        return lead;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(fund) && startYear == null;
    }
}
