package com.jhi.aem.website.v1.core.models.micrositefundlisting;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.models.micrositesubnavmarker.MicrositeSubnavMarkerModel;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeFundListingModel {

    @Inject
    private String title;

    @Inject
    private String text;

    @Inject
    private String featuredViewpoint;

    @Inject
    private PageManager pageManager;

    @Inject
    private MicrositeSubnavMarkerModel subnav;

    private ViewpointDetailModel featuredViewpointModel;

    @PostConstruct
    private void init() {
        featuredViewpointModel = fetchViewpointFromPage(featuredViewpoint);
    }

    private ViewpointDetailModel fetchViewpointFromPage(String pagePath) {
        if (StringUtils.isBlank(pagePath)) {
            return null;
        }

        return ViewpointDetailModel.fromPage(pageManager.getPage(pagePath));
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public ViewpointDetailModel getFeaturedViewpoint() {
        return featuredViewpointModel;
    }

    public MicrositeSubnavMarkerModel getSubnav() {
        return subnav;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(featuredViewpoint);
    }
}
