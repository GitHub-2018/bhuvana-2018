package com.jhi.aem.website.v1.core.models.subscription;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.service.user.UserProfileService;

import javax.inject.Inject;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SubscriptionModel {

    @Inject
    private String title;

    @Inject
    private String text;

    @Inject
    private String loggedInButtonLabel;

    @Inject
    private String loggedInButtonUrl;

    @Inject
    private String firstNameLabel;

    @Inject
    private String lastNameLabel;

    @Inject
    private String emailLabel;

    @Inject
    private String investorTypeLabel;

    @Inject
    private String loggedOutButtonLabel;

    @Inject
    private String loggedOutButtonUrl;

    @Inject
    private ResourceResolver resourceResolver;

    @Inject
    private UserProfileService userProfileService;

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getLoggedInButtonLabel() {
        return loggedInButtonLabel;
    }

    public String getLoggedInButtonUrl() {
        return loggedInButtonUrl;
    }

    public String getFirstNameLabel() {
        return firstNameLabel;
    }

    public String getLastNameLabel() {
        return lastNameLabel;
    }

    public String getEmailLabel() {
        return emailLabel;
    }

    public String getInvestorTypeLabel() {
        return investorTypeLabel;
    }

    public String getLoggedOutButtonLabel() {
        return loggedOutButtonLabel;
    }

    public String getLoggedOutButtonUrl() {
        return loggedOutButtonUrl;
    }

    public boolean isLoggedIn() {
        return userProfileService.isLoggedIn(resourceResolver);
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(loggedInButtonLabel)
                && StringUtils.isBlank(loggedInButtonUrl) && StringUtils.isBlank(firstNameLabel)
                && StringUtils.isBlank(lastNameLabel) && StringUtils.isBlank(emailLabel)
                && StringUtils.isBlank(investorTypeLabel) && StringUtils.isBlank(loggedOutButtonLabel)
                && StringUtils.isBlank(loggedOutButtonUrl);
    }
}
