package com.jhi.aem.website.v1.core.models.literature;

import com.day.cq.commons.DownloadResource;
import com.day.cq.commons.jcr.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class LiteratureModel {

    private static final String IMAGE_PATH = "image";

    @Inject
    @Default
    private String productData;

    @Inject
    private Resource resource;

    private ValueMap productValues;

    @PostConstruct
    protected void init() {
        if (StringUtils.isNotBlank(productData)) {
            Resource productResource = resource.getResourceResolver().getResource(productData);
            if (productData != null) {
                productValues = productResource.getValueMap();
            }
        }
    }

    public String getImagePath() {
        Resource imageResource = resource.getChild(IMAGE_PATH);
        if (imageResource != null) {
            ValueMap imageValues = imageResource.getValueMap();
            return imageValues.get(DownloadResource.PN_REFERENCE, StringUtils.EMPTY);
        }
        return StringUtils.EMPTY;
    }

    public String getTitle() {
        return getProperty(JcrConstants.JCR_TITLE);
    }

    public String getDescription() {
        return getProperty(JcrConstants.JCR_DESCRIPTION);
    }

    public boolean isValid() {
        return StringUtils.isNotBlank(productData);
    }

    private String getProperty(String propertyName) {
        if (productValues == null) {
            return StringUtils.EMPTY;
        }
        return productValues.get(propertyName, StringUtils.EMPTY);
    }
}
