package com.jhi.aem.website.v1.core.models.forgotpassword;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.servlets.user.GenerateForgotPassWordLinkServlet;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ForgotPasswordSectionModel {
	public static final String FORGOT_PASSWORD_SELECTOR_PART = JhiConstants.DOT + GenerateForgotPassWordLinkServlet.FORGOT_PASSWORD_SELECTOR
            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;

	@Inject @Via("resource")
    private String title;

	@Inject @Via("resource")
    private String subtitle;

	@Inject @Via("resource")
    private String emailLabel;

	@Inject @Via("resource")
    private String submitButtonLabel;

	@Inject @Via("resource")
    private String thankYouTitle;

	@Inject @Via("resource")
    private String thankYouSubtitle;

	@Inject @Via("resource")
    private String resendButtonLabel;
    
	@Inject @Via("resource")
	private Resource resource;
	
	@Self
	private SlingHttpServletRequest request;

	private String mappedResourcePath;

    
    @PostConstruct
    protected void init(){
    	mappedResourcePath= resource.getResourceResolver().map(request, resource.getPath());
    }
    
    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getEmailLabel() {
        return emailLabel;
    }

    public String getSubmitButtonLabel() {
        return submitButtonLabel;
    }

    public String getThankYouTitle() {
        return thankYouTitle;
    }

    public String getThankYouSubtitle() {
        return thankYouSubtitle;
    }

    public String getResendButtonLabel() {
        return resendButtonLabel;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(emailLabel)
                && StringUtils.isBlank(submitButtonLabel) && StringUtils.isBlank(thankYouTitle)
                && StringUtils.isBlank(thankYouSubtitle) && StringUtils.isBlank(resendButtonLabel);
    }
    
    public String getForgotPasswordActionPath() {
        return mappedResourcePath + FORGOT_PASSWORD_SELECTOR_PART;
    }
}
