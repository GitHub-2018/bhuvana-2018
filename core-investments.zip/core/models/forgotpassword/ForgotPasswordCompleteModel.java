package com.jhi.aem.website.v1.core.models.forgotpassword;

import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.WCMMode;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.auth.IsamAuthenticationConfigService;
import com.jhi.aem.website.v1.core.service.crypto.CryptoService;
import com.jhi.aem.website.v1.core.utils.AuthHelper;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ForgotPasswordCompleteModel {
	private final static Logger LOG = LoggerFactory.getLogger(ForgotPasswordCompleteModel.class);

	@Inject @Via("resource")
	private String title;

	@Inject @Via("resource")
	private String subtitle;

	@Inject @Via("resource")
	private String passwordLabel;

	@Inject @Via("resource")
	private String confirmPasswordLabel;
	
	@Inject
    @Via("resource")
    @Default
    private List<Resource> passwordCriterias;

	@Inject @Via("resource")
	private String submitButtonLabel;

	@Inject @Via("resource")
	private String errorTitle;

	@Inject @Via("resource")
	private String errorSubtitle;
	
	@Inject @Via("resource")
	private String 	thankYouTitle;
	@Inject @Via("resource")
	private String 	thankYouSubtitle;
	@Inject @Via("resource")
	private String 	thankYouButtonLink;
	@Inject @Via("resource")
	private String 	thankYouButtonText;

	@Inject @Via("resource")
	private String invalidLinkErrorTitle;
	
	@Inject @Via("resource")
	private String invalidLinkErrorText;

	@Inject @Via("resource")
	private String unverifiedErrorTitle;

	@Inject @Via("resource")
	private String unverifiedErrorText;

	@Inject @Via("resource")
	private String unverifiedErrorContactFormText;

	@Inject @Via("resource")
	private Resource resource;
	
    @Self
	private SlingHttpServletRequest request;

    @OSGiService
    private ResourceResolverFactory resolverFactory;

    @OSGiService
	private CryptoService cryptoService;

    @OSGiService
	private IsamAuthenticationConfigService isamAuthConfigService;

	private String mappedResourcePath;

	private String user;

	private String resetPasswordToken;

	private boolean validLink = false;


	@PostConstruct
    protected void init(){
    	mappedResourcePath = resource.getResourceResolver().map(request, resource.getPath());
    	
    	if (WCMMode.fromRequest(request) != WCMMode.EDIT) {
	    	String resetPasswordJwt = request.getParameter(JhiConstants.RESET_PASSWORD_QUERY_STRING_TOKEN_PARAMETER);
	
	    	// Parse the JWT and get the user/token out
	    	try {
		    	Jws<Claims> claimsJws = Jwts.parser()
				        .setSigningKey(cryptoService.getHmacSigningKey())
				        .parseClaimsJws(resetPasswordJwt);
				resetPasswordToken = claimsJws.getBody().getId();
				user = claimsJws.getBody().getSubject();
	    	} catch (JwtException | IllegalArgumentException e) {
	    		LOG.error("Could not parse JWT", e);
	    		throw e;
	    	}
	
	    	// Check that this user exists, and that it's not just someone messing around
	    	ResourceResolver elevatedResolver = null;
	        try {
	            elevatedResolver = resolverFactory.getServiceResourceResolver(
	                    Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER));
	            if (elevatedResolver == null) {
	            	LOG.error("Could not retrieve resource resolver for '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER);
	            } else {	
	            	validLink = AuthHelper.validateResetPasswordToken(elevatedResolver,
	            			isamAuthConfigService, resetPasswordToken, user);
	            }
	        } catch (LoginException e) {
	            LOG.error("Unable to get the user management service user '{}'", JhiConstants.JHI_USER_MANAGEMENT_SERVICE_USER, e);
			} finally {
	            if (elevatedResolver != null) {
	            	elevatedResolver.close();
	            }
	        }
    	} else {
    		validLink = true;
    	}

        LOG.debug("Forgot password model valid={}", validLink);
    }
	
    public boolean isValidLink() {
    	return validLink;
	}
	
	public String getResetPasswordActionPath() {
        return mappedResourcePath + JhiConstants.SLING_SECURITY_CHECK_PATH;
	}

	public String getTitle() {
		return title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public String getPasswordLabel() {
		return passwordLabel;
	}

	public String getConfirmPasswordLabel() {
		return confirmPasswordLabel;
	}

	public List<Resource> getPasswordCriterias() {
		return passwordCriterias;
	}
	
	public String getSubmitButtonLabel() {
		return submitButtonLabel;
	}

	public String getErrorTitle() {
		return errorTitle;
	}

	public String getErrorSubtitle() {
		return errorSubtitle;
	}

	public String getInvalidLinkErrorTitle() {
		return invalidLinkErrorTitle;
	}

	public String getInvalidLinkErrorText() {
		return invalidLinkErrorText;
	}

	public String getMappedResourcePath() {
		return mappedResourcePath;
	}

	public String getUser() {
		return user;
	}

	public String getResetPasswordToken() {
		return resetPasswordToken;
	}

	public String getThankYouTitle() {
		return thankYouTitle;
	}

	public String getThankYouSubtitle() {
		return thankYouSubtitle;
	}

	public String getThankYouButtonLink() {
		return LinkUtil.getLink(request.getResourceResolver(), thankYouButtonLink);
	}

	public String getThankYouButtonText() {
		return thankYouButtonText;
	}

	public String getUnverifiedErrorTitle() {
		return unverifiedErrorTitle;
	}

	public String getUnverifiedErrorText() {
		return unverifiedErrorText;
	}

	public String getUnverifiedErrorContactFormText() {
		return unverifiedErrorContactFormText;
	}

}
