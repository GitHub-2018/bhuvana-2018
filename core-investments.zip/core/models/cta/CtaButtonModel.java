package com.jhi.aem.website.v1.core.models.cta;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CtaButtonModel {
    @Inject
    @Default
    private String buttonLabel;

    @Inject
    @Default
    private String buttonPath;
    
	@Inject
	private Resource resource;

    public boolean isBlank() {
    	return StringUtils.isBlank(buttonLabel);
    }

	public String getButtonLabel() {
		return buttonLabel;
	}

	public String getButtonPath() {
		return buttonPath;
	}

	public String getButtonLink() {
		return LinkUtil.getLink(resource.getResourceResolver(), buttonPath);
	}

}
