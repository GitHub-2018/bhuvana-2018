package com.jhi.aem.website.v1.core.models.cta;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

import javax.inject.Inject;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CtaTileModel {
    private static final String PAGE_LINK_STYLE = "page-link";

    @Inject
    @Default
    private String title;

    @Inject
    @Default
    private String text;

    @Inject
    @Default
    private String buttonLabel;

    @Inject
    @Default
    private String buttonPath;

    @Inject
    @Default(values = PAGE_LINK_STYLE)
    private String style;

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public String getButtonLink() {
        return LinkUtil.getLink(buttonPath);
    }

    public String getStyle() {
        return style;
    }

    public boolean isNotPageLink() {
        return !StringUtils.equals(style, PAGE_LINK_STYLE);
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(buttonLabel) &&
                StringUtils.isBlank(buttonPath);
    }
}
