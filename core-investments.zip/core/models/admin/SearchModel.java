package com.jhi.aem.website.v1.core.models.admin;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SearchModel {

	@Inject
	private Resource resource;

	public String getSearchPath() {
		return resource.getPath() + JhiConstants.DOT + JhiConstants.ADMIN_SEARCH_SELECTOR + JhiConstants.DOT
				+ JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
	}

	public String getSearchOptionPath() {
		return resource.getPath() + JhiConstants.DOT + JhiConstants.ADMIN_SEARCH_OPTIONS_SELECTOR + JhiConstants.DOT
				+ JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
	}
	
	public String getReportPath() {
		return resource.getPath() + JhiConstants.DOT + JhiConstants.ADMIN_EXCEPTION_REPORT_SELECTOR + JhiConstants.DOT
				+ JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
	}
	
	public String getGroupUpdatePath() {
		return resource.getPath() + JhiConstants.DOT + JhiConstants.ADMIN_GROUP_SELECTOR + JhiConstants.DOT
				+ JhiConstants.NO_CACHE_SELECTOR +  JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
	}
	
	public String getStatusUpdatePath() {
		return resource.getPath() + JhiConstants.DOT + JhiConstants.ADMIN_STATUS_SELECTOR + JhiConstants.DOT
				+ JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
	}
}
