package com.jhi.aem.website.v1.core.models.person;

import java.util.Calendar;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.utils.DateUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PersonalBiographyDetails implements Comparable<PersonalBiographyDetails> {

    public static final String PERSONAL_BIOGRAPHY_PATH = "personalBiography";
    public static final int BIOGRAPHY_EXCEPT_LENGTH = 100;
    public static final String FUNDS_PARAGRAPH_CONTENT_PATH = JcrConstants.JCR_CONTENT
            + "/fundManagerFunds/fundsParagraph";

    private static final int MAX_SHORT_BIO_WIDTH = 200;

    @Inject
    @Default(values = "")
    private String name;

    @Inject
    @Default(values = "")
    private String position;

    @Inject
    @Optional
    private Calendar careerStartDate;

    @Inject
    @Optional
    private ImageModel image;

    @Inject
    @Default(values = "")
    private String biography;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    @OSGiService
    private AssetManagerService assetManagerService;

    @Inject
    private String assetManager;

    private AssetManagerModel assetManagerModel;

    private int yearsOfExperience;

    @PostConstruct
    public void init() {
    	if (StringUtils.isNotEmpty(assetManager)) {
	    	Page assetManagerPage = resourceResolver.resolve(assetManager).adaptTo(Page.class);
	    	assetManagerModel = AssetManagerModel.fromPage(assetManagerPage);
    	}

    	final int currentYear = Calendar.getInstance(Locale.US).get(Calendar.YEAR);
        yearsOfExperience = currentYear - (careerStartDate == null ? 0 : careerStartDate.get(Calendar.YEAR));
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public Calendar getCareerStartDate() {
        return careerStartDate;
    }

    public String getCareerStartDateFormatted() {
        return DateUtil.getFormattedDate(careerStartDate, resourcePage);
    }

    public ImageModel getImage() {
        return image;
    }

    public String getImagePath() {
        return ImageModel.getImagePath(image);
    }

    public String getBiography() {
        return biography;
    }

    public String getBiographyExcerpt() {
        if (StringUtils.isBlank(biography)) {
            return StringUtils.EMPTY;
        }
        String biographyExcerpt = biography.replaceAll("<[^>]*>", StringUtils.EMPTY);
        if (biographyExcerpt.length() > BIOGRAPHY_EXCEPT_LENGTH) {
            biographyExcerpt = biographyExcerpt.substring(0, BIOGRAPHY_EXCEPT_LENGTH) + "&hellip;";
        }
        return biographyExcerpt;
    }

    public String getBiographyShort() {
        if (StringUtils.isBlank(biography)) {
            return StringUtils.EMPTY;
        }
        return StringUtils.abbreviate(biography, MAX_SHORT_BIO_WIDTH);
    }

    public int getYearsOfExperience() {
        return yearsOfExperience;
    }

    public AssetManagerModel getAssetManager() {
        return assetManagerModel;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(name) && StringUtils.isBlank(position);
    }

    public boolean isAssetManagerBlank() {
        return assetManagerModel == null || (StringUtils.isBlank(assetManagerModel.getName()));
    }

    @Override
    public int compareTo(PersonalBiographyDetails other) {
        if (this == other) {
            return 0;
        }

        if (this.name == null) {
            return 1;
        }

        if (other.name == null) {
            return -1;
        }

        return this.name.compareTo(other.name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PersonalBiographyDetails)) return false;
        return super.equals(o);
    }

    public static PersonalBiographyDetails fromPage(Page page) {
        return PageUtil.getModelFromPage(page, PERSONAL_BIOGRAPHY_PATH, PersonalBiographyDetails.class);
    }
}
