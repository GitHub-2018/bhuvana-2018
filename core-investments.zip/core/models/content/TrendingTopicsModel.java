package com.jhi.aem.website.v1.core.models.content;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class TrendingTopicsModel {

    @Inject
    @Default
    private String title;

    @Inject
    @Optional
    private TrendingTopicModel first;

    @Inject
    @Optional
    private TrendingTopicModel second;

    @PostConstruct
    private void init() {
        if (first != null) {
            first.setStart(1);
        }
        if (second != null) {
            second.setStart(2);
        }
    }

    public String getTitle() {
        return title;
    }

    public TrendingTopicModel getFirstsTopicModel() {
        return first;
    }

    public TrendingTopicModel getSecondTopicModel() {
        return second;
    }

    public boolean isFirstValid() {
        return first != null;
    }

    public boolean isSecondValid() {
        return second != null;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && first == null && second == null;
    }
}
