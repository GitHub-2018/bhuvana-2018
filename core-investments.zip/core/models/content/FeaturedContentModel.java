package com.jhi.aem.website.v1.core.models.content;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FeaturedContentModel {
    private static final int MAX_ITEMS = 5;

    @Inject
    @Default
    private String firstItem;

    @Inject
    @Default
    private String secondItem;

    @Inject
    @Default
    private String thirdItem;

    @Inject
    @Default
    private String fourthItem;

    @Inject
    private PageManager pageManager;

    private ViewpointDetailModel first;
    private ViewpointDetailModel second;
    private ViewpointDetailModel third;
    private ViewpointDetailModel fourth;

    @PostConstruct
    protected void init() {
        first = ViewpointDetailModel.fromPage(pageManager.getPage(firstItem));
        second = ViewpointDetailModel.fromPage(pageManager.getPage(secondItem));
        third = ViewpointDetailModel.fromPage(pageManager.getPage(thirdItem));
        fourth = ViewpointDetailModel.fromPage(pageManager.getPage(fourthItem));
    }

    public ViewpointDetailModel getFirstItem() {
        return first;
    }

    public ViewpointDetailModel getSecondItem() {
        return second;
    }

    public ViewpointDetailModel getThirdItem() {
        return third;
    }

    public ViewpointDetailModel getFourthItem() {
        return fourth;
    }

    public boolean isFirstItemValid() {
        return first != null && first.isValid();
    }

    public boolean isBlank() {
        return StringUtils.isBlank(firstItem) && StringUtils.isBlank(secondItem) && StringUtils.isBlank(thirdItem)
                && StringUtils.isBlank(fourthItem);
    }

}
