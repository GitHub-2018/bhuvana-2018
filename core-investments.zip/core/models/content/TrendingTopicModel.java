package com.jhi.aem.website.v1.core.models.content;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class TrendingTopicModel {

    @Inject
    @Default
    private String topic;

    @Inject
    @Default
    private String firstViewpoint;

    @Inject
    @Default
    private String secondViewpoint;

    @Inject
    @Default
    private String thirdViewpoint;

    @Inject
    private PageManager pageManager;

    private String topicTitle;
    private ViewpointDetailModel firstViewpointModel;
    private ViewpointDetailModel secondViewpointModel;
    private ViewpointDetailModel thirdViewpointModel;

    @PostConstruct
    protected void init() {
        topicTitle = PageUtil.getPageNavigationTitle(pageManager.getPage(topic));
        firstViewpointModel = ViewpointDetailModel.fromPage(pageManager.getPage(firstViewpoint));
        secondViewpointModel = ViewpointDetailModel.fromPage(pageManager.getPage(secondViewpoint));
        thirdViewpointModel = ViewpointDetailModel.fromPage(pageManager.getPage(thirdViewpoint));
    }

    public String getTitle() {
        return topicTitle;
    }

    public ViewpointDetailModel getFirstViewpoint() {
        return firstViewpointModel;
    }

    public List<ViewpointDetailModel> getOtherViewpoints() {
        List<ViewpointDetailModel> viewpoints = new ArrayList<>(2);
        if (secondViewpointModel != null && secondViewpointModel.isValid()) {
            viewpoints.add(secondViewpointModel);
        }
        if (thirdViewpointModel != null && thirdViewpointModel.isValid()) {
            viewpoints.add(thirdViewpointModel);
        }
        return viewpoints;
    }

    public void setStart(int start) {
        if (firstViewpointModel != null) {
            firstViewpointModel.setAnalyticsIndex(start);
        }
        if (secondViewpointModel != null) {
            secondViewpointModel.setAnalyticsIndex(start + 2);
        }
        if (thirdViewpointModel != null) {
            thirdViewpointModel.setAnalyticsIndex(start + 4);
        }
    }
}
