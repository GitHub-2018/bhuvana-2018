package com.jhi.aem.website.v1.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables=Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class HreflangTag {

	@Inject
    private String link;
    
    @Inject
    private String title;
    
    @Inject
    private String lang;
    

	public String getLink() {
		return link;
	}

	public String getTitle() {
		return title;
	}

	public String getLang() {
		return lang;
	}
}
