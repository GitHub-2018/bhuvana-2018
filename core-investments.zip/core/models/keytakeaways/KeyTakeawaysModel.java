package com.jhi.aem.website.v1.core.models.keytakeaways;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class KeyTakeawaysModel {

	@Inject
	private String keyTakeawaysHeading;
	
	@Inject
	private List<Resource> keyTakeaways;

	public String getKeyTakeawaysHeading() {
		return keyTakeawaysHeading;
	}

	public List<Resource> getKeyTakeaways() {
		return keyTakeaways;
	}

	public boolean isBlank() {
		return StringUtils.isBlank(keyTakeawaysHeading) &&
				(keyTakeaways == null || keyTakeaways.isEmpty());
	}

}
