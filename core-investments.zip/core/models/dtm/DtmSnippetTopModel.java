package com.jhi.aem.website.v1.core.models.dtm;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DtmSnippetTopModel {

    @Inject
    private DtmSnippetModel bottom;

    public boolean getIncludeSnippet() {
        if (bottom == null) {
            return false;
        }

        return bottom.isIncludeSnippet();
    }

    public String getSnippet() {
        if (bottom == null) {
            return StringUtils.EMPTY;
        }

        return bottom.getSnippet();
    }
}
