package com.jhi.aem.website.v1.core.models.dtm;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.jhi.aem.website.v1.core.service.runmode.RunModeService;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DtmSnippetModel {

    @Inject
    @Default
    private String productionSnippet;

    @Inject
    @Default
    private String stagingSnippet;

    @Inject
    @Default
    private String developmentSnippet;

    @OSGiService
    private RunModeService runModeService;

    public boolean isIncludeSnippet() {
        return runModeService.isPublish() && StringUtils.isNotBlank(getSnippetInternal());
    }

    public String getSnippet() {
        if (isIncludeSnippet()) {
            return getSnippetInternal();
        }
        return StringUtils.EMPTY;
    }

    private String getSnippetInternal() {
        if (runModeService.isStaging()) {
            return stagingSnippet;
        } else if (runModeService.isProduction()) {
            return productionSnippet;
        }
        return developmentSnippet;
    }
}
