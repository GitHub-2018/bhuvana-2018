package com.jhi.aem.website.v1.core.models.cart;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CartTitleModel {

    private static final String CART_CONTENT_SELECTOR = "cartContent";
    private static final String CART_CONTENT_SELECTOR_PATH = JhiConstants.DOT + CART_CONTENT_SELECTOR + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;

    @Inject
    @Default
    private String title;

    @Inject
    private ResourceResolver resourceResolver;

    @Self
    private Resource resource;

    public String getTitle() {
        return title;
    }

    public String getContentPath() {
        return resourceResolver.map(resource.getPath()) + CART_CONTENT_SELECTOR_PATH;
    }
}
