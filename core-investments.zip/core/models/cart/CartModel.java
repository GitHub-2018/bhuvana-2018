package com.jhi.aem.website.v1.core.models.cart;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.inject.Inject;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CartModel {

    private static final String NUMBER_OF_ITEMS_PLACEHOLDER = "${number}";
    private static final String NUMBER_OF_ITEMS_REPLACEMENT = "{0}";

    @Inject
    private Page resourcePage;

    @Inject
    @Default
    private String title;

    @Inject
    @Default(values = "1 item in your cart")
    private String singleItemMessage;

    @Inject
    @Default(values = "${number} items in your cart")
    private String multipleItemsMessage;

    @Inject
    @Default(values = "There currently are no items in your cart")
    private String emptyCartMessage;

    @Inject
    @Default
    private String viewLiteraturePath;

    @Inject
    @Default(values = "ORDER AND VIEW LITERATURE")
    private String viewLiteratureLabel;

    @Inject
    @Default(values = "Quantity")
    private String quantityLabel;

    @Inject
    @Default(values = "Remove from cart")
    private String removeLabel;

    @Inject
    @Default(values = "Continue to checkout")
    private String checkoutLabel;

    private String checkoutPagePath;

    public String getTitle() {
        return title;
    }

    public String getSingleItemMessage() {
        return singleItemMessage;
    }

    public String getMultipleItemsMessage() {
        return StringUtils.replace(multipleItemsMessage, NUMBER_OF_ITEMS_PLACEHOLDER, NUMBER_OF_ITEMS_REPLACEMENT);
    }

    public String getEmptyCartMessage() {
        return emptyCartMessage;
    }

    public String getViewLiteraturePath() {
        return LinkUtil.getLink(viewLiteraturePath);
    }

    public String getViewLiteratureLabel() {
        return viewLiteratureLabel;
    }

    public String getQuantityLabel() {
        return quantityLabel;
    }

    public String getRemoveLabel() {
        return removeLabel;
    }

    public String getCheckoutPath() {
        if (checkoutPagePath != null) {
            return checkoutPagePath;
        }
        Page parentPage = resourcePage.getParent();
        if (parentPage != null) {
            Page checkoutPage = PageUtil.getChildByResourceType(parentPage, ResourcesConstants
                    .CHECKOUT_PAGE_RESOURCE_TYPE);
            if (checkoutPage != null) {
                checkoutPagePath = LinkUtil.getLink(checkoutPage.getPath());
            }
        }
        if (checkoutPagePath == null) {
            checkoutPagePath = StringUtils.EMPTY;
        }
        return checkoutPagePath;
    }

    public String getCheckoutLabel() {
        return checkoutLabel;
    }
}
