package com.jhi.aem.website.v1.core.models.cart;

import com.adobe.cq.commerce.api.CommerceService;
import com.day.cq.personalization.UserPropertiesUtil;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RecentOrdersModel {

    private static final int MAX_ITEMS = 3;

    @Self
    private SlingHttpServletRequest request;

    @SlingObject
    private SlingHttpServletResponse response;

    private List<RrdProductImpl> items;

    @PostConstruct
    protected void init() {
        Resource resource = request.getResource();
        CommerceService commerceService = resource.adaptTo(CommerceService.class);
        if (!UserPropertiesUtil.isAnonymous(request)) {
            items = new ArrayList<>(MAX_ITEMS);

        }
        items = Collections.emptyList();
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
