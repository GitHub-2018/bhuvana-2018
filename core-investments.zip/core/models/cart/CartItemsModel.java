package com.jhi.aem.website.v1.core.models.cart;

import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.CommerceService;
import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.commerce.api.PlacedOrder;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdOrderUtils;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CartItemsModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(CartModel.class);
    private static final String ORDER_ID_PARAMETER = "orderId";

    @Self
    private SlingHttpServletRequest request;

    @SlingObject
    private SlingHttpServletResponse response;

    private List<CommerceSession.CartEntry> cartEntries;

    public boolean isEmpty() {
        return getCartEntries().isEmpty();
    }

    public boolean isOneItemInCart() {
        return getCartEntries().size() == 1;
    }

    public int getItemsCount() {
        return getCartEntries().size();
    }

    public List<CommerceSession.CartEntry> getCartEntries() {
        if (cartEntries == null) {
            cartEntries = getEntriesList();
        }
        return cartEntries;
    }

    private List<CommerceSession.CartEntry> getEntriesList() {
        Resource resource = request.getResource();
        CommerceService commerceService = resource.adaptTo(CommerceService.class);
        if (commerceService != null) {
            try {
                final CommerceSession commerceSession = commerceService.login(request, response);
                final String orderIdString = request.getParameter(ORDER_ID_PARAMETER);
                if (StringUtils.isNotBlank(orderIdString)) {
                    try {
                        // Parse the order id coming from the request to deny XSS/log forging
                        final Long orderId = RrdOrderUtils.parseOrderId(orderIdString);
                        PlacedOrder placedOrder = commerceSession.getPlacedOrder(orderId.toString());
                        if (placedOrder != null) {
                            return placedOrder.getCartEntries();
                        }
                    } catch (CommerceException e) {
                        LOGGER.error("Problem while getting placed order", e);
                    }
                } else {
                    try {
                        return commerceSession.getCartEntries();
                    } catch (CommerceException e) {
                        LOGGER.error("Problem while getting cart entries", e);
                    }
                }
                commerceSession.logout();
            } catch (CommerceException e) {
                LOGGER.error("Cannot create commerce session", e);
            }
        } else {
            LOGGER.error("Commerce service is not available");
        }
        return Collections.emptyList();
    }
}
