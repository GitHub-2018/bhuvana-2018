package com.jhi.aem.website.v1.core.models.fund;

import java.util.Objects;

public class FundPartnerDto {

    public static final FundPartnerDto EMPTY = new FundPartnerDto();

    private String partnerLogo;
    private String partnerName;
    private String partnerDescription;
    private String partnerShortDescription;

    public String getPartnerLogo() {
        return partnerLogo;
    }

    public void setPartnerLogo(String partnerLogo) {
        this.partnerLogo = partnerLogo;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getPartnerDescription() {
        return partnerDescription;
    }

    public void setPartnerDescription(String partnerDescription) {
        this.partnerDescription = partnerDescription;
    }

    public String getPartnerShortDescription() {
        return partnerShortDescription;
    }

    public void setPartnerShortDescription(String partnerShortDescription) {
        this.partnerShortDescription = partnerShortDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof FundPartnerDto))
            return false;
        FundPartnerDto that = (FundPartnerDto) o;
        return Objects.equals(partnerName, that.partnerName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(partnerName);
    }
}
