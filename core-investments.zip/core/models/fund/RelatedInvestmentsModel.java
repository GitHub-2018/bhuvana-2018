package com.jhi.aem.website.v1.core.models.fund;

import java.util.ArrayList;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.fund.tags.Fund;
import com.jhi.aem.website.v1.core.models.fund.tags.FundInvestmentType;
import com.jhi.aem.website.v1.core.models.fund.tags.FundProductType;
import com.jhi.aem.website.v1.core.models.fund.tags.ShareClass;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListMapper;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDto;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.StreamUtils;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class RelatedInvestmentsModel {
    private static final Logger LOG = LoggerFactory.getLogger(RelatedInvestmentsModel.class);
    private static final int MAX_ITEMS = 4;
    protected static final int MAX_RELATED_FUNDS = 2;

    @Inject
    private Page resourcePage;

    @OSGiService
    private FundService fundService;

    @OSGiService
    private FundListMapper mapper;

    @SlingObject
    private ResourceResolver resolver;

    protected Set<ShareClassDto> funds = new TreeSet<>();

    private String investmentsPagePath;

    @PostConstruct
    protected void init() {
        setShareClasses();
        investmentsPagePath = LinkUtil
                .getPageLink(PageUtil.getSitePageByResourceType(PageUtil.getHomePage(resourcePage),
                        ResourcesConstants.INVESTMENTS_PAGE_RESOURCE_TYPE));
    }

    private void setShareClasses() {
        for (String fundTag : readFundsIdFromTags()) {
            String tagPath = FundUtil.getTagPath(fundTag);
            Class clazz = FundUtil.getFundTagClass(tagPath);
            if (Objects.isNull(clazz)) {
                LOG.debug("wrong fund tag id: {}", fundTag);
            } else {
                funds.addAll(getShareClassDtos(tagPath, clazz));
            }
        }
    }

    private List<String> readFundsIdFromTags() {
        // Get all of the fund tags from the page
        String[] viewpointTags = resourcePage.getProperties().get(JhiConstants.INVESTMENT_TAGS_PROPERTY, ArrayUtils.EMPTY_STRING_ARRAY);
        List<String> relatedFundTags = new ArrayList<>();
        if (viewpointTags != null) {
            Arrays.stream(viewpointTags).forEach(viewpointTag -> {
                if (StringUtils.startsWith(viewpointTag, JhiConstants.FUNDS_TAG_PREFIX)) {
                    relatedFundTags.add(viewpointTag);
                }
            });
        }
        return relatedFundTags;
    }

    private Set<ShareClassDto> getShareClassDtos(String tagPath, Class clazz) {
        return Optional.ofNullable(resolver.getResource(tagPath))
                .map(resource -> getShareClassResources(clazz, resource)
                        .stream()
                        .map(shareClassResource -> shareClassResource.adaptTo(ShareClass.class))
                        .filter(Objects::nonNull)
                        .map(shareClass -> mapper.mapShareClass(shareClass, resourcePage))
                        .filter(shareClassDto -> !shareClassDto.equals(ShareClassDto.EMPTY))
                        .limit(MAX_ITEMS)
                        .collect(Collectors.toSet()))
                .orElseGet(() -> {
                    LOG.debug("Could not get fund tags from path: {}", tagPath);
                    return Collections.emptySet();
                });
    }

    public Set<ShareClassDto> getRelatedInvestmentFunds() {
        return funds;
    }

    public Set<ShareClassDto> getRelatedFunds() {
        return funds.stream().limit(MAX_RELATED_FUNDS).collect(Collectors.toSet());
    }

    public String getInvestmentsPagePath() {
        return investmentsPagePath;
    }

    public boolean isBlank() {
        return funds.isEmpty();
    }

    private List<Resource> getShareClassResources(Class clazz, Resource resource) {
        List<Resource> shareClassResources = Collections.emptyList();
        if (clazz.getName().equalsIgnoreCase(ShareClass.class.getName())) {
            shareClassResources = Collections.singletonList(resource);
        } else if (clazz.getName().equalsIgnoreCase(Fund.class.getName())) {
            shareClassResources = IteratorUtils.toList(resource.listChildren());
        } else if (clazz.getName().equalsIgnoreCase(FundInvestmentType.class.getName())) {
            shareClassResources = getResourcesFromInvestmentClass(resource);
        } else if (clazz.getName().equalsIgnoreCase(FundProductType.class.getName())) {
            shareClassResources = getResourcesFromProductType(resource);
        }
        LOG.debug("[{}] fund resources found for resource path: [{}]", shareClassResources.size(), resource.getPath());
        return shareClassResources;
    }

    private List<Resource> getResourcesFromProductType(Resource resource) {
        return IteratorUtils.toList(resource.listChildren())
                .stream()
                .flatMap(investments -> this.getResourcesFromProductType(investments).stream())
                .collect(Collectors.toList());
    }

    private List<Resource> getResourcesFromInvestmentClass(Resource resource) {
        return IteratorUtils.toList(resource.listChildren())
                .stream()
                .flatMap(StreamUtils.getResourceChildrenFlattened())
                .collect(Collectors.toList());

    }
}
