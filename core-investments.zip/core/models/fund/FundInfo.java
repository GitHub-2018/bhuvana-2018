package com.jhi.aem.website.v1.core.models.fund;

public class FundInfo {
    private final String code;
    private final String assetManager;
    private final String link;
    private final String title;

    public FundInfo(String code, String title, String assetManager, String link) {
        this.code = code;
        this.title = title;
        this.assetManager = assetManager;
        this.link = link;
    }

    public String getCode() {
        return code;
    }

    public String getAssetManager() {
        return assetManager;
    }

    public String getLink() {
        return link;
    }

    public String getTitle() {
        return title;
    }
}
