package com.jhi.aem.website.v1.core.models.fund;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class FundPageModel {
    public static final FundPageModel EMPTY = new FundPageModel();

    @Inject
    protected Page resourcePage;

    @Inject
    protected ResourceResolver resourceResolver;

    private FundIdModel fundIdModel;

    @OSGiService
    private RunModeService runModeService;

    @PostConstruct
    protected void init() {
        fundIdModel = FundIdModel.fromPage(resourcePage);
    }

    public String getTitle() {
        return StringUtils.defaultIfBlank(PageUtil.getPageTitle(resourcePage), fundIdModel.getName());
    }

    public String getDescription() {
        if (resourcePage != null) {
            return resourcePage.getDescription();
        }
        return StringUtils.EMPTY;
    }

    public String getCode() {
        return fundIdModel.getClassId();
    }

    public static FundPageModel fromPage(Page page) {
        FundPageModel model = EMPTY;
        if (page != null) {
            Resource contentResource = page.getContentResource();
            if (contentResource != null) {
                FundPageModel fundPageModel = contentResource.adaptTo(FundPageModel.class);
                if (fundPageModel != null) {
                    model = fundPageModel;
                }
            }
        }
        return model;
    }

    public String getLink() {
        return fundIdModel.getFundPageLink();
    }

    public boolean isFundActive() {
        return fundIdModel.isActive();
    }

    public boolean isFundActiveAndPublished() {
        return fundIdModel.isActive() && fundIdModel.isPublished();
    }

    public boolean isValid() {
        return resourcePage != null && resourcePage.isValid() && fundIdModel.isActive();
    }
}
