package com.jhi.aem.website.v1.core.models.fund;

import javax.annotation.PostConstruct;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class FundTagInPageModel {
    private static final Logger LOG = LoggerFactory.getLogger(FundTagInPageModel.class);

	@Inject
    private Page resourcePage;

	private Tag shareClassIdTag;
	private Tag fundIdTag;

	@PostConstruct
	public void init() {
        TagManager tagManager = resourcePage.getContentResource().getResourceResolver().adaptTo(TagManager.class);

        // Get the current fund page's tag
        String[] fundTags = resourcePage.getProperties().get(JhiConstants.FUND_PAGE_FUND_TAGS_PROPERTY,
                ArrayUtils.EMPTY_STRING_ARRAY);

        if (fundTags == null || fundTags.length == 0) {
            LOG.warn("No fund manager tag set on the page {}", resourcePage.getPath());
        } else {
            String tagId = fundTags[0];

            if (StringUtils.isNotBlank(tagId)) {
            	shareClassIdTag = tagManager.resolve(tagId);
            	fundIdTag = shareClassIdTag.getParent();
            }
        }
	}

	public Tag getShareClassIdTag() {
		return shareClassIdTag;
	}

	public Tag getFundIdTag() {
		return fundIdTag;
	}

}
