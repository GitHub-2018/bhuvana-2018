package com.jhi.aem.website.v1.core.models.fund;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class FundIdModel {
    private static final FundIdModel EMPTY = new FundIdModel();

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    private String id;
    private String name;
    private String classId;
    private String shareClass;
    private String fundPageLink;
    private Tag fundClassTag;
    private boolean active = false;
    private boolean published = false;


    @PostConstruct
    protected void init() {
        String tagId = PageUtil.getPageContentProperty(resourcePage, JhiConstants.FUND_PAGE_FUND_TAGS_PROPERTY, String.class);
        if (StringUtils.isNotBlank(tagId)) {
            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            if (tagManager != null) {
                fundClassTag = tagManager.resolve(tagId);
                if (fundClassTag != null) {
                    FundTag fundTag = new FundTag(fundClassTag);
                    name = fundClassTag.getTitle();
                    classId = fundTag.getTickerId();
                    shareClass = fundTag.getShareClass();
                    id = fundTag.getFundCode();
                    active = fundTag.isActive();
                    published = fundTag.isPublished();
                }
            }
        }
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getClassId() {
        return classId;
    }

    public String getShareClass() {
        return shareClass;
    }

    public String getFundPageLink() {
        if (fundPageLink == null) {
            fundPageLink = FundUtil.getFundDisplayPathForShareClassTag(resourcePage, fundClassTag);
        }

        return fundPageLink;
    }

    public boolean isBlank() {
        return StringUtils.isAnyBlank(classId, name, shareClass);
    }

    public static FundIdModel fromPage(Page page) {
        if (PageUtil.isResourceType(page, ResourcesConstants.FUND_CLASS_PAGE_RESOURCE_TYPE)) {
            return PageUtil.getModelFromPage(page, StringUtils.EMPTY, FundIdModel.class, EMPTY);
        }
        return EMPTY;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isPublished() {
        return published;
    }
}
