package com.jhi.aem.website.v1.core.models.fund;

import java.util.List;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.MaxSizeSet;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.models.viewpoints_list.ViewpointsResults;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundRelatedViewpointsModel {

    private static final int MAX_RESULTS = 4;

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    @OSGiService
    private FundService fundService;

    @OSGiService
    private ViewpointsService viewpointsService;

    private MaxSizeSet<ViewpointDetailModel> relatedViewpoints = new MaxSizeSet<>(MAX_RESULTS);

    @PostConstruct
    protected void init() {
        Tag fundTag = FundUtil.getTagFromSuffix(request);
        if (fundTag != null) {
        	String viewpointsMainPagePath = ViewpointUtil.getViewpointsMainPage(resourcePage).getPath();

        	// Search for latest viewpoints related to this fund
            ViewpointsResults viewpointsTaggedWithFund = viewpointsService.getViewpoints(resourceResolver,
            		viewpointsMainPagePath, MAX_RESULTS, fundTag);
            relatedViewpoints.addAll(viewpointsTaggedWithFund.getItems());

            // If we don't have enough results then retrieve viewpoint articles
            // written by people related to the fund
            if (!relatedViewpoints.isFull()) {
            	
            	// Turn fund managers (people) into viewpoints authors
                String authorPagePath = PageUtil.getAuthorPagePath(resourcePage);

                // Now for those viewpoint authors (the fund managers) get related viewpoints
                ViewpointsResults viewpointsWithAuthors =
                		viewpointsService.getAuthorsViewpoints(resourceResolver, viewpointsMainPagePath, 0,
                				MAX_RESULTS - relatedViewpoints.size(),
                					new String[] {authorPagePath});
                relatedViewpoints.addAll(viewpointsWithAuthors.getItems());
            }

            // Still not full? Get latest viewpoints.
            if (!relatedViewpoints.isFull()) {
            	List<ViewpointDetailModel> latestViewpoints =
            		viewpointsService.getLatestViewpoints(resourceResolver, viewpointsMainPagePath,
            			MAX_RESULTS - relatedViewpoints.size());
            	relatedViewpoints.addAll(latestViewpoints);
            }
        }
    }

    public Set<ViewpointDetailModel> getRelatedViewpoints() {
        return relatedViewpoints;
    }

    public boolean isBlank() {
        return relatedViewpoints == null || relatedViewpoints.isEmpty();
    }

}
