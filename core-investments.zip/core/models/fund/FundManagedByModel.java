package com.jhi.aem.website.v1.core.models.fund;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.jhi.aem.website.v1.core.models.BiList;
import com.jhi.aem.website.v1.core.models.BiList.BiListPair;
import com.jhi.aem.website.v1.core.models.person.PersonalBiographyDetails;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.service.fund.FundManagerFullDetails;
import com.jhi.aem.website.v1.core.service.fund.FundPartnerMapper;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundManagedByModel {
    private static final Logger LOG = LoggerFactory.getLogger(FundManagedByModel.class);
    public static final int MAX_PARTNERS_SIZE = 4;
    private static final List<DateTimeFormatter> incomingDateFormats =
    		Arrays.asList(new DateTimeFormatter[] {
    				DateTimeFormatter.ofPattern("yyyy-MM-dd"), 
    				DateTimeFormatter.ofPattern("yy-M-d"), 
    				DateTimeFormatter.ofPattern("M/d/yy"),
    				DateTimeFormatter.ofPattern("MM/dd/yy"),
    				DateTimeFormatter.ofPattern("MM/dd/yyyy")});
    private static final DateTimeFormatter dateFormatRequired = DateTimeFormatter.ofPattern("yyyy");
    public static final int EXCEEDS_MAX_ITEMS_SHOWN = 5;
    public static final int MAX_FUND_MANAGERS = 3;
    private static final int ALIGN_EXPERIENCE_RIGHT_THRESHOLD = 55; // (%) Difference in Percent

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page currentPage;

    @Inject
    private ResourceResolver resourceResolver;

    @OSGiService
    private AssetManagerService assetManagerService;

    @OSGiService
    private FundService fundService;

    @OSGiService
    private FundPartnerMapper mapper;

    private boolean fundPageTagExists = false;
    private boolean partnerExists = false;
    private boolean fundManagersExist = false;
    private String inceptionDate;
    private int fundManagersSize;
    private int partnersSize;
    private int averageManagerTenure;
    private int longestTenure;
    private int longestExperience;
    private int yearsSinceInceptionWidth;
    private int yearsSinceInception;

    private List<Map<String, Object>> fundManagers = new ArrayList<>();
    private Set<FundPartnerDto> partners = new LinkedHashSet<>();

    @PostConstruct
    private void init() {
        String suffix = request.getRequestPathInfo().getSuffix();
        Optional<LocalDate> optionalLocalDate = getLocalDate();

        inceptionDate = optionalLocalDate
                .map(localDate -> localDate.format(dateFormatRequired))
                .orElse(StringUtils.EMPTY);

        yearsSinceInception = Math.abs(optionalLocalDate
                .map(localDate -> LocalDate.now().getYear() - localDate.getYear())
                .orElse(0));

        int totalYearsTenure = 0;

        if (StringUtils.isBlank(suffix)) {
            LOG.warn("No fund manager tag found on the page {} (suffix was '{}')", currentPage.getPath(), suffix);
        } else {
            fundPageTagExists = true;

            // Get the first tag and resolve it
            Tag fundTag = Optional.ofNullable(resourceResolver.adaptTo(TagManager.class))
                                .map(tagManager -> 
                                	FundUtil.getShareClassTagFromSuffix(suffix, tagManager, PageUtil.isInUcitsSite(currentPage)))
                                .orElse(null);

            Set<FundManagerFullDetails> peopleManagingFund = fundService.getPeopleManagingFund(fundTag, currentPage);

            for (FundManagerFullDetails personManagingFund : peopleManagingFund) {
                // Load up the fund managers
                PersonalBiographyDetails personalBiographyDetails = personManagingFund.getPersonalBiographyDetails();
                mapPartners(personalBiographyDetails);

                Map<String, Object> fundManager = new HashMap<>();
                fundManager.put("thumbnail", personalBiographyDetails.getImage().getPath());
                fundManager.put("name", personalBiographyDetails.getName());
                fundManager.put("biography", personalBiographyDetails.getBiography());
                fundManager.put("biographyShort", personalBiographyDetails.getBiographyShort());
                fundManager.put("biographyLong", personalBiographyDetails.getBiography());
                fundManager.put("lead", personManagingFund.getFundManagerFundModel().getLead());

                int yearsOnFund = personManagingFund.getFundManagerFundModel().getYearsOnFund();
                int yearsOfExperience = personalBiographyDetails.getYearsOfExperience();
                fundManager.put("yearsOnFund", Math.min(yearsOnFund, yearsOfExperience));
                fundManager.put("yearsOfExperience", Math.max(yearsOfExperience, yearsOnFund));

                totalYearsTenure += yearsOnFund;

                if (yearsOnFund > longestTenure) {
                    longestTenure = yearsOnFund;
                }

                if (yearsOfExperience > longestExperience) {
                    longestExperience = yearsOfExperience;
                }

                fundManagers.add(fundManager);
            }

            int absLongestExperience = Math.max(yearsSinceInception, Math.max(longestTenure, longestExperience));
            yearsSinceInceptionWidth = (absLongestExperience <= 0) ? 0 : Math.min(100, Math.max(0, (int) ((100 * yearsSinceInception) / absLongestExperience)));

            for (Map<String, Object> fundManager : fundManagers) {
                int yearsOnFundWidth = (absLongestExperience <= 0) ? 0 : Math.min(100, Math.max(0, (int) (100 * ((int) fundManager.get("yearsOnFund")) / absLongestExperience)));
                int yearsOfExperienceWidth = (absLongestExperience <= 0) ? 0 : Math.min(100, Math.max(0, (int) (100 * ((int) fundManager.get("yearsOfExperience")) / absLongestExperience)));
                fundManager.put("yearsOnFundWidth", yearsOnFundWidth);
                fundManager.put("yearsOfExperienceWidth", yearsOfExperienceWidth);
                fundManager.put("alignExperienceRight", (yearsOfExperienceWidth <= ALIGN_EXPERIENCE_RIGHT_THRESHOLD));
            }
        }

        partnersSize = partners.size();
        partnerExists = partnersSize > 0;
        fundManagersSize = fundManagers.size();
        fundManagersExist = fundManagersSize > 0;

        if (fundManagersSize != 0) {
            averageManagerTenure = totalYearsTenure / fundManagersSize;
        }
        
        sortFundManagers();
    }

    private Optional<LocalDate> getLocalDate() {
        return Optional.ofNullable(FundUtil.getFundTagFromSuffix(request))
                .map(FundTag::getInceptionDate)
                .filter(StringUtils::isNotBlank)
                .map(date -> parseLocalDate(date));
    }
    
    private LocalDate parseLocalDate(String date) {
    	for (DateTimeFormatter incomingDateFormat : incomingDateFormats) {
    		try {
    			return LocalDate.parse(date, incomingDateFormat);
    		} catch (DateTimeParseException e) {
    		}
    	}
    	
    	throw new RuntimeException("Cannot parse date of format: " + date);
    }

    private void mapPartners(PersonalBiographyDetails personalBiographyDetails) {
        FundPartnerDto dto = mapper.map2dto(personalBiographyDetails);
        if (!dto.equals(FundPartnerDto.EMPTY)) {
            partners.add(dto);
        }
    }

    public Set<FundPartnerDto> getPartners() {
        return ImmutableSet.copyOf(Iterables.limit(partners, Math.min(partnersSize, MAX_PARTNERS_SIZE)));
    }

    public List<Map<String, Object>> getFundManagers() {
        if (!isFundManagersExist() || partnersSize > 2) {
            return Collections.emptyList();
        }
        return fundManagers.subList(0, Math.min(MAX_PARTNERS_SIZE - partnersSize, fundManagersSize));
    }

    public Set<FundPartnerDto> getAllPartners() {
        return partners;
    }

    public Integer getFundManagersSize() {
        return fundManagersSize;
    }

    public List<BiListPair<Map<String, Object>>> getFundManagersBiList() {
        return BiList.createBiList(fundManagers);
    }

    public boolean isPartnerExists() {
        return partnerExists;
    }

    public boolean isFundManagersExist() {
        return fundManagersExist;
    }

    public boolean isFundPageTagExists() {
        return fundPageTagExists;
    }

    public boolean isSeeAllTitle() {
        return fundManagersSize > MAX_PARTNERS_SIZE;
    }

    public boolean isFullBioTitle() {
        return !isSeeAllTitle() && fundManagersSize < MAX_FUND_MANAGERS && (fundManagersSize + partnersSize) < EXCEEDS_MAX_ITEMS_SHOWN;
    }

    public boolean isAllPortfolioManagersTitle() {
        return !isSeeAllTitle() && !isFullBioTitle();
    }

    public String getInceptionDate() {
        return inceptionDate;
    }

    public int getAverageManagerTenure() {
        return averageManagerTenure;
    }

    public int getLongestTenure() {
        return longestTenure;
    }

    public int getLongestExperience() {
        return longestExperience;
    }

    public int getYearsSinceInception() {
        return yearsSinceInception;
    }

    public int getYearsSinceInceptionWidth() {
        return yearsSinceInceptionWidth;
    }
    
    private void sortFundManagers() {
    	Collections.sort(fundManagers, new Comparator<Map<String,Object>>() {
			@Override
			public int compare(Map<String, Object> o1, Map<String, Object> o2) {
				boolean o1lead = (boolean) o1.get("lead");
				boolean o2lead = (boolean) o2.get("lead");
				Integer o1yearsOnFund = (Integer) o1.get("yearsOnFund");
				Integer o2yearsOnFund = (Integer) o2.get("yearsOnFund");
				Integer o1years = (Integer) o1.get("yearsOfExperience") - (Integer) o1.get("yearsOnFund");
				Integer o2years = (Integer) o2.get("yearsOfExperience") - (Integer) o2.get("yearsOnFund");
				
			    if (o1lead == o2lead) {
					if (o1yearsOnFund.compareTo(o2yearsOnFund) == 0) {	
						return o1years.compareTo(o2years);
					} else {
						return o1yearsOnFund.compareTo(o2yearsOnFund);
					}
				} else {
					if (o1lead) {
						return 1;
					} else {
						return -1;
					}
				}
			}
    	});
    	Collections.reverse(fundManagers);
    }
}
