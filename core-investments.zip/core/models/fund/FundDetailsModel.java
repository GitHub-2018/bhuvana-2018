package com.jhi.aem.website.v1.core.models.fund;

import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.ShareClassImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UnpublishedFundImport;
import com.jhi.aem.website.v1.core.external.services.funds.maestro.MaestroFundsApi;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListMapper;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDto;
import com.jhi.aem.website.v1.core.servlets.dashboard.DashboardFundServlet;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundDetailsModel {

    private static final Logger LOG = LoggerFactory.getLogger(FundDetailsModel.class);

    private static final String DOCUMENTS_CONTENT_SELECTOR = "documentsContent";
    private static final String DOCUMENTS_CONTENT_PATH = JhiConstants.DOT + DOCUMENTS_CONTENT_SELECTOR
            + JhiConstants.ACCESS_SELECTOR_PLACEHOLDER + JhiConstants.URL_HTML_EXTENSION;
    private static final String VIEWPOINTS_SELECTOR = "fundDetailViewpoints";
    private static final String VIEWPOINTS_CONTENT_PATH = JhiConstants.DOT + VIEWPOINTS_SELECTOR
            + JhiConstants.ACCESS_SELECTOR_PLACEHOLDER + JhiConstants.URL_HTML_EXTENSION;

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page currentPage;

    @OSGiService
    private FundListMapper mapper;

    @Self
    private FundClassesLinksModel linksModel;

    @SlingObject
    private ResourceResolver resolver;

    @OSGiService
    private MaestroFundsApi maestroFundsApi;

    private ShareClassDto shareClassTag;
    private String fundComparisonPagePath;
    private String dashboardFundUrl = StringUtils.EMPTY;

    @PostConstruct
    protected void init() {

        fundComparisonPagePath = Optional.ofNullable(getFundComparisonPage())
                .map(LinkUtil::getPageLink)
                .orElse(StringUtils.EMPTY);

        Tag tagFromSuffix = FundUtil.getTagFromSuffix(request);
        if (tagFromSuffix == null) {
        	LOG.debug("Null suffix for fund page request");

        	// Attempt to get the share class DTO from the API
        	String unpublishedFundToken = request.getParameter(MaestroFundsApi.UNPUBLISHED_FUND_REQUEST_PARAMETER);
        	if (StringUtils.isNotBlank(unpublishedFundToken)) {
        		LOG.debug("Trying unpublished fund API");
        		UnpublishedFundImport unpublishedFund = maestroFundsApi.getUnpublishedShareClassDetails(unpublishedFundToken);
        		shareClassTag = new ShareClassDto();
        		ShareClassImport shareClassImport = unpublishedFund.getShareclass();
        		shareClassTag.setCurrency(shareClassImport.getCurrencyCode());
        		shareClassTag.setCusip(shareClassImport.getCusip());
        		shareClassTag.setFundCode(unpublishedFund.getFundId());
        		shareClassTag.setFundTitle(unpublishedFund.getName());
        		shareClassTag.setShareClass(shareClassImport.getSymbol());
        		shareClassTag.setShareClassCode(shareClassImport.getShareClassId());
        		shareClassTag.setShareClassLetter(shareClassImport.getSymbol());
        		shareClassTag.setTickerId(shareClassImport.getShareClassId());
        		shareClassTag.setTitle(shareClassImport.getName());
        		shareClassTag.setIsin(shareClassImport.getIsIn());
        	} else {
        		shareClassTag = ShareClassDto.EMPTY;
        	}
        } else {
			shareClassTag = Optional.ofNullable(tagFromSuffix)
	                .map(shareClass -> mapper.mapShareClass(shareClass, currentPage))
	                .orElseGet(() -> {
	                    LOG.warn("Couldn't adapt to share class.");
	                    return ShareClassDto.EMPTY;
	                });
    		LOG.debug("Got share class tag for share class {}: {}", tagFromSuffix, shareClassTag);
        }

        dashboardFundUrl = currentPage.getParent().getContentResource().getPath() +
        		DashboardFundServlet.DASHBOARD_REQUEST_TOGGLE_FUND_TAG_STRING +
                getShareClass();

    }

    public FundClassesLinksModel getLinksModel() {
        return linksModel;
    }

    public ShareClassDto getShareClassTag() {
        return shareClassTag;
    }

    public String getFundComparisonPagePath() {
        return fundComparisonPagePath;
    }

    public String getDashboardFundUrl() {
        return dashboardFundUrl;
    }

    public String getDocumentsPath() {
        return resolver.map(currentPage.getPath() + JhiConstants.SLASH + JcrConstants.JCR_CONTENT) + DOCUMENTS_CONTENT_PATH
                + request.getRequestPathInfo().getSuffix();
    }

    public String getViewpointsPath() {
        return resolver.map(currentPage.getPath() + JhiConstants.SLASH + JcrConstants.JCR_CONTENT) + VIEWPOINTS_CONTENT_PATH
                + request.getRequestPathInfo().getSuffix();
    }

    private String getShareClass() {
        return Optional.ofNullable(shareClassTag)
                .map(ShareClassDto::getShareClass)
                .orElse(StringUtils.EMPTY);
    }

    private Page getFundComparisonPage() {
        return PageUtil.getPageByResourceType(currentPage, currentPage.getParent().getPath(),
                ResourcesConstants.FUND_COMPARISON_PAGE_RESOURCE_TYPE);
    }
}
