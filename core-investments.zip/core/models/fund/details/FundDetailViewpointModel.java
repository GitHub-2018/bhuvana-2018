package com.jhi.aem.website.v1.core.models.fund.details;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundDetailViewpointModel {

    @ValueMapValue
    private String headline;

    @ValueMapValue
    private String description;

    @ValueMapValue
    private String link;

    @ValueMapValue(name = "image/fileReference")
    private String imagePath;

    public String getHeadline() {
        return headline;
    }

    public String getDescription() {
        return description;
    }

    public String getLink() {
        return LinkUtil.getLink(link);
    }

    public String getImagePath() {
        return imagePath;
    }

    public boolean isBlank() {
        return headline == null && description == null && link == null && imagePath == null;
    }
}
