package com.jhi.aem.website.v1.core.models.fund.details;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdProductImpl;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.resources.ResourceDocumentModel;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;

@Model(adaptables = SlingHttpServletRequest.class)
public class FundDetailsViewpointsModel {

    private static final String VIEWPOINTS_PATH = "viewpoints";

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page currentPage;

    @OSGiService
    private FundService fundService;

    private String accessSelector;

    private List<FundDetailViewpointModel> viewpoints;

    public List<FundDetailViewpointModel> getViewpoints() {
        if (viewpoints == null) {
            viewpoints = new ArrayList<>(4);
            Tag fundTag = FundUtil.getTagFromSuffix(request);
            Page fundPage = fundService.getPageForTag(fundTag, currentPage);
            if (fundPage != null) {
                Resource contentResource = fundPage.getContentResource();
                if (contentResource != null) {
                    Resource viewpointsResource = contentResource.getChild(VIEWPOINTS_PATH);
                    if (viewpointsResource != null) {
                        for (Resource viewpointItem : viewpointsResource.getChildren()) {
                            FundDetailViewpointModel viewpointModel = viewpointItem.adaptTo(FundDetailViewpointModel.class);
                            if (viewpointModel != null && !viewpointModel.isBlank()) {
                                String link = viewpointModel.getLink();
                                if (LinkUtil.isInternalPath(link)) {
                                    String viewpointPath = StringUtils.removeEnd(viewpointModel.getLink(), JhiConstants.URL_HTML_EXTENSION);
                                    Resource viewpointResource =
                                            request.getResourceResolver().getResource(viewpointPath + JhiConstants.SLASH + JcrConstants.JCR_CONTENT);
                                    checkViewpoint(viewpointModel, viewpointResource);
                                } else if (StringUtils.isNotBlank(link)) {
                                    viewpoints.add(viewpointModel);
                                }
                            }
                        }
                    }
                }
            }
        }
        return viewpoints;
    }

    private void checkViewpoint(FundDetailViewpointModel viewpointModel, Resource viewpointResource) {
        if (viewpointResource != null) {
            if (viewpointResource.isResourceType(ResourcesConstants.VIEWPOINT_DOCUMENT_PAGE_RESOURCE_TYPE)) {
                Resource summaryItemResource =
                        viewpointResource.getChild(ViewpointDetailModel.SUMMARY_ITEM_PATH);
                if (summaryItemResource != null) {
                    ValueMap summaryItemValues = summaryItemResource.getValueMap();
                    String productPath = summaryItemValues.get(ResourceDocumentModel.PRODUCT_PATH_PROPERTY,
                            String.class);
                    if (StringUtils.isNotBlank(productPath)) {
                        checkProduct(viewpointModel, productPath);
                    }
                }
            } else {
                viewpoints.add(viewpointModel);
            }
        }
    }

    private void checkProduct(FundDetailViewpointModel viewpointModel, String productPath) {
        Resource productResource = request.getResourceResolver().getResource(productPath);
        if (productResource != null) {
            if (StringUtils.equals(getAccessSelector(), JhiConstants.ACCESS_INVESTOR)) {
                RrdProductImpl product = new RrdProductImpl(productResource);
                if (product.isAccessPublic()) {
                    viewpoints.add(viewpointModel);
                }
            } else {
                viewpoints.add(viewpointModel);
            }
        }
    }

    public boolean isNotEmpty() {
        return !getViewpoints().isEmpty();
    }

    public String getAccessSelector() {
        if (accessSelector == null) {
            accessSelector = RequestUtil.getAccessSelector(request);
        }
        return accessSelector;
    }
}
