package com.jhi.aem.website.v1.core.models.fund.details;

import java.util.Date;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundKeyFactsModel {

    @Inject
    @Default
    private String typicalHoldingRate;

    @Inject
    @Default
    private String typicalPortfolioTurnover;

    @Inject
    @Default
    private String lipperCategory;

    @Inject
    @Default
    private String benchmark;

    @Inject
    @Optional
    private Date inceptionDate;

    @Inject
    @Optional
    private Date prospectusDate;

    @Inject
    @Optional
    private Date fiscalYearEnd;

    @Inject
    @Default
    private String averageManagerTenure;

    @Inject
    @Default
    private String keyFactsDisclosure;

    public String getTypicalHoldingRate() {
        return typicalHoldingRate;
    }

    public String getTypicalPortfolioTurnover() {
        return typicalPortfolioTurnover;
    }

    public String getLipperCategory() {
        return lipperCategory;
    }

    public String getBenchmark() {
        return benchmark;
    }

    public Date getInceptionDate() {
        return inceptionDate;
    }

    public Date getProspectusDate() {
        return prospectusDate;
    }

    public Date getFiscalYearEnd() {
        return fiscalYearEnd;
    }

    public String getAverageManagerTenure() {
        return averageManagerTenure;
    }

    public String getKeyFactsDisclosure() {
        return keyFactsDisclosure;
    }
}
