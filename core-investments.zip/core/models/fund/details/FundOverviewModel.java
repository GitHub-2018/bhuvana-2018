package com.jhi.aem.website.v1.core.models.fund.details;

import java.util.List;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.document.DocumentModel;
import com.jhi.aem.website.v1.core.models.person.PersonalBiographyDetails;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundOverviewModel {

    @Inject
    @Default
    private String objective;

    @Inject
    @Default
    private String useFor;

    @Inject
    @Default
    private String strategy;

    @Inject
    @Default
    private String lipperFundAward;

    @Inject
    @Default
    private String[] keyDocumentsIds;

    private List<DocumentModel> keyDocuments;
    private List<PersonalBiographyDetails> managedBy;

    public String getObjective() {
        return objective;
    }

    public String getUseFor() {
        return useFor;
    }

    public String getStrategy() {
        return strategy;
    }

    public String getLipperFundAward() {
        return lipperFundAward;
    }

    public List<DocumentModel> getKeyDocuments() {
        return keyDocuments;
    }

    public List<PersonalBiographyDetails> getManagedBy() {
        return managedBy;
    }
}
