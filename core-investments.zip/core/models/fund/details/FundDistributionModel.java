package com.jhi.aem.website.v1.core.models.fund.details;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundDistributionModel {

    @Inject
    @Default
    private String distributionDisclosure;

    @Inject
    @Default
    private String priceHistoryDisclosure;

    @Inject
    @Default
    private String feesAndExpensesDisclosure;

    @Inject
    @Default
    private String riskDisclosure;

    public String getDistributionDisclosure() {
        return distributionDisclosure;
    }

    public String getPriceHistoryDisclosure() {
        return priceHistoryDisclosure;
    }

    public String getFeesAndExpensesDisclosure() {
        return feesAndExpensesDisclosure;
    }

    public String getRiskDisclosure() {
        return riskDisclosure;
    }
}
