package com.jhi.aem.website.v1.core.models.fund.details;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.resources.ResourceDetailModel;
import com.jhi.aem.website.v1.core.service.resources.ResourcesService;
import com.jhi.aem.website.v1.core.servlets.redirect.ResourceThumbnailServlet;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.RequestUtil;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class KeyDocumentsModel {
	
	public static final Logger LOG = LoggerFactory.getLogger(KeyDocumentsModel.class);

    private static final int FIRST_SIZE = 3;

    @Self
    private SlingHttpServletRequest request;

    @SlingObject
    private ResourceResolver resolver;

    @Inject
    private Page resourcePage;

    @OSGiService
    private ResourcesService resourcesService;

    private List<ResourceDetailModel> firsts;
    private List<ResourceDetailModel> others;

    private String accessSelector;

    public String getAccessSelector() {
        if (accessSelector == null) {
            accessSelector = RequestUtil.getAccessSelector(request);
        }
        return accessSelector;
    }

    @PostConstruct
    protected void init() {
    	LOG.debug("Entering Init method of KeyDocumentsModel");
        List<ResourceDetailModel> keyDocuments = new ArrayList<>();
        Optional.ofNullable(RequestUtil.getSuffix(request))
                .map(suffix -> FundUtil.getShareClassTagFromSuffix(suffix, 
                		resolver.adaptTo(TagManager.class), PageUtil.isInUcitsSite(resourcePage)))
                .ifPresent(fundTag -> {
                    collectDocuments(keyDocuments, fundTag);
                });
        if (!keyDocuments.isEmpty()) {
        	for (ResourceDetailModel resourceDetailModel : keyDocuments) {
        		String thumbnailPath = resourceDetailModel.getThumbnailPath();
        		if (StringUtils.isNotBlank(thumbnailPath)) {
        			LOG.debug("Setting the resource thumbnail path for :: " + thumbnailPath);
    	            String fileExtension = "." + FilenameUtils.getExtension(thumbnailPath);
    	            resourceDetailModel.setResourceThumbnailPath(resourceDetailModel.getPagePath() + "." + ResourceThumbnailServlet.THUMBNAIL_IMAGE_SELECTOR + "." +
    	            		JhiConstants.ACCESS_INTERNAL + fileExtension);
    	            LOG.debug("Setting the resource thumbnail path :: " + resourceDetailModel.getResourceThumbnailPath());
                }
        	}
            firsts = keyDocuments.subList(0, Math.min(FIRST_SIZE, keyDocuments.size()));
            if (keyDocuments.size() > FIRST_SIZE) {
                others = keyDocuments.subList(FIRST_SIZE, keyDocuments.size());
            } else {
                others = Collections.emptyList();
            }
        } else {
            firsts = Collections.emptyList();
            others = Collections.emptyList();
        }
    }

    private void collectDocuments(List<ResourceDetailModel> keyDocuments, Tag fundTag) {
        if (!StringUtils.equals(getAccessSelector(), JhiConstants.ACCESS_INVESTOR)) {
            keyDocuments.addAll(
                    resourcesService.getFundKeyDocuments(fundTag, resourcePage.getContentResource().getResourceResolver(),
                            resourcePage.getContentResource()));
        } else {
            resourcesService
                    .getFundKeyDocuments(fundTag, resourcePage.getContentResource().getResourceResolver(), resourcePage.getContentResource())
                    .stream()
                    .filter(ResourceDetailModel::isPublic)
                    .collect(Collectors.toCollection(() -> keyDocuments));
        }
    }

    public List<ResourceDetailModel> getFirsts() {
        return firsts;
    }

    public List<ResourceDetailModel> getOthers() {
        return others;
    }

    public Integer getTotalSize() {
        return (others.size() + firsts.size());
    }
}
