package com.jhi.aem.website.v1.core.models.fund.details;

import javax.inject.Inject;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import javax.inject.Named;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.fund.FundIdModel;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class FundDetailsDataModel {
    public static final FundDetailsDataModel EMPTY = new FundDetailsDataModel();

    @Inject
    @Named(".")
    private FundIdModel base;

    @Inject
    @Optional
    private FundMetaModel meta;

    @Inject
    @Optional
    private FundOverviewModel overview;

    @Inject
    @Optional
    private FundKeyFactsModel keyFacts;

    @Inject
    @Optional
    private FundPerformanceModel performance;

    @Inject
    @Optional
    private FundRatingsModel ratings;

    @Inject
    @Optional
    private FundDistributionModel distribution;

    public FundIdModel getBase() {
        return base;
    }

    public FundMetaModel getMeta() {
        return meta;
    }

    public FundOverviewModel getOverview() {
        return overview;
    }

    public FundKeyFactsModel getKeyFacts() {
        return keyFacts;
    }

    public FundPerformanceModel getPerformance() {
        return performance;
    }

    public FundRatingsModel getRatings() {
        return ratings;
    }

    public FundDistributionModel getDistribution() {
        return distribution;
    }

    public boolean isBlank() {
        return base != null && !base.isBlank();
    }

    public static FundDetailsDataModel fromPage(Page page) {
        if (PageUtil.isResourceType(page, ResourcesConstants.FUND_CLASS_PAGE_RESOURCE_TYPE)) {
            return PageUtil.getModelFromPage(page, StringUtils.EMPTY, FundDetailsDataModel.class, EMPTY);
        }
        return EMPTY;
    }
}
