package com.jhi.aem.website.v1.core.models.fund.details;

import java.util.Optional;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.utils.FundUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundDetailsReferenceModel {

    private static final String LINKS_NODE = "links";
    private static final String MONTHLY_TOP_HOLDINGS_LINK = "monthlyTopHoldingsLink";

    @SlingObject
    private SlingHttpServletRequest request;

    @ScriptVariable
    private Page currentPage;

    @OSGiService
    private FundService fundService;

    private String linksReferencePath = StringUtils.EMPTY;
    private String monthlyTopHoldingsLink = StringUtils.EMPTY;
    private String topHoldingsQuarterEndLink = StringUtils.EMPTY;

    @PostConstruct
    public void init() {
        Optional.ofNullable(FundUtil.getTagFromSuffix(request))
                .map(tag -> fundService.getPageForTag(tag, currentPage))
                .map(Page::getContentResource)
                .ifPresent(this::setReferences);
    }

    public String getLinksReferencePath() {
        return linksReferencePath;
    }


    public String getMonthlyTopHoldingsLink() {
        return monthlyTopHoldingsLink;
    }

    private void setReferences(Resource resource) {
        linksReferencePath = getReferencePath(resource, LINKS_NODE);
        Optional<ValueMap> monthlyTopHoldingsValueMap = Optional.ofNullable(resource.getChild(MONTHLY_TOP_HOLDINGS_LINK))
                .map(Resource::getValueMap);
        if (monthlyTopHoldingsValueMap.isPresent()) {
            ValueMap valueMap = monthlyTopHoldingsValueMap.get();
            monthlyTopHoldingsLink = StringUtils.defaultString(valueMap.get("path", String.class), StringUtils.EMPTY);
            topHoldingsQuarterEndLink = StringUtils.defaultString(valueMap.get("pathQuarterEnd", String.class), StringUtils.EMPTY);
        }

    }

    private String getReferencePath(Resource resource, String childNode) {
        return Optional.ofNullable(resource.getChild(childNode))
                .map(Resource::getPath)
                .orElse(StringUtils.EMPTY);
    }

    public String getTopHoldingsQuarterEndLink() {
        return topHoldingsQuarterEndLink;
    }
}
