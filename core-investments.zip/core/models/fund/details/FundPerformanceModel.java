package com.jhi.aem.website.v1.core.models.fund.details;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundPerformanceModel {

    @Inject
    @Default
    private String performanceDisclosure;

    @Inject
    @Default
    private String calendarYearDisclosure;

    @Inject
    @Default
    private String institutionalCompositeDisclosure;

    @Inject
    @Default
    private String hypotheticalGrowthDisclosure;

    @Inject
    @Default
    private String marketCyclePerformanceDisclosure;

    @Inject
    @Default
    private String styleExposureDisclosure;

    @Inject
    @Default
    private String topContributorsAndDetractorsDisclosure;

    @Inject
    @Default
    private String riskMeasuresDisclosure;

    @Inject
    @Default
    private String riskAndVolatilityDisclosure;

    @Inject
    @Default
    private String upsideDownsideDisclosure;

    public String getPerformanceDisclosure() {
        return performanceDisclosure;
    }

    public String getCalendarYearDisclosure() {
        return calendarYearDisclosure;
    }

    public String getInstitutionalCompositeDisclosure() {
        return institutionalCompositeDisclosure;
    }

    public String getHypotheticalGrowthDisclosure() {
        return hypotheticalGrowthDisclosure;
    }

    public String getMarketCyclePerformanceDisclosure() {
        return marketCyclePerformanceDisclosure;
    }

    public String getStyleExposureDisclosure() {
        return styleExposureDisclosure;
    }

    public String getTopContributorsAndDetractorsDisclosure() {
        return topContributorsAndDetractorsDisclosure;
    }

    public String getRiskMeasuresDisclosure() {
        return riskMeasuresDisclosure;
    }

    public String getRiskAndVolatilityDisclosure() {
        return riskAndVolatilityDisclosure;
    }

    public String getUpsideDownsideDisclosure() {
        return upsideDownsideDisclosure;
    }
}
