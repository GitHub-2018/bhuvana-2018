package com.jhi.aem.website.v1.core.models.fund.details;

import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.fund.FundTag;
import com.jhi.aem.website.v1.core.models.page.PageModel;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundDetailsPageModel extends PageModel {

    private String title;
	private String description;
	
	@PostConstruct
	protected void init() {
		super.init();
		setTitle();
		setDescription();
	}
	
    protected void setTitle() {
    	title = getHiddenFundDetailsPageProperty("pageTitle");
    	if (StringUtils.isBlank(title)) {
    		title = Optional.ofNullable(FundUtil.getFundTagFromSuffix(this.request))
                    .map(this::getFundTitle)
                    .orElse(super.getTitle());
    	}
    }
    
    protected void setDescription() {
    	description = getHiddenFundDetailsPageProperty(JcrConstants.JCR_DESCRIPTION);
    	if (StringUtils.isBlank(description)) {
    		description = super.getDescription();
    	}
    }
    
    protected String getHiddenFundDetailsPageProperty(String propertyName) {
    	FundTag fundTag = FundUtil.getFundTagFromSuffix(request);
    	if (fundTag != null) {
    		String shareClassName = StringUtils.join(fundTag.getDisplayFundName().toLowerCase().replaceAll(" ", JhiConstants.DASH), JhiConstants.SLASH, fundTag.getShareClassLetter().toLowerCase());
    		Resource hiddenShareClassPageResource = resourceResolver.getResource(
    				resourceResolver.getResource(StringUtils.join(PageUtil.getHomePage(resourcePage).getPath(), JhiConstants.SLASH, JhiConstants.HIDDEN_FUND_DETAILS_ROOT)), shareClassName);
    		if (hiddenShareClassPageResource != null) {
    			 Resource content = hiddenShareClassPageResource.getChild(JcrConstants.JCR_CONTENT);
    			 if (content != null && StringUtils.isNotBlank(content.getValueMap().get(propertyName, StringUtils.EMPTY))) {
    				 return (String) content.getValueMap().get(propertyName);
    			 }
    		}
    	}
    	return null;
    }
    
    private String getFundTitle(FundTag fundTag) {
    	String ticker = isInUcitsSite ?
    			fundTag.getIsin() :
    			StringUtils.defaultIfBlank(fundTag.getTickerId(), fundTag.getIsin());
    	return fundTag.getDisplayName() + " - " + ticker;
    }
    
    @Override
    public String getTitle() {
    	return title;
    }
    
    @Override
    public String getDescription() {
    	return description;
    } 
}
