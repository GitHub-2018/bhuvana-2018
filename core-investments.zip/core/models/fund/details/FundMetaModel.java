package com.jhi.aem.website.v1.core.models.fund.details;

import java.util.Date;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundMetaModel {

    @Inject
    @Default
    private String type;

    @Inject
    @Optional
    private Date date;

    @Inject
    @Default
    private String cusip;

    @Inject
    @Default
    private String ticker;

    public String getType() {
        return type;
    }

    public Date getDate() {
        return date;
    }

    public String getCusip() {
        return cusip;
    }

    public String getTicker() {
        return ticker;
    }
}
