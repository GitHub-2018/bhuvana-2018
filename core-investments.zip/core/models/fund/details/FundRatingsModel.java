package com.jhi.aem.website.v1.core.models.fund.details;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundRatingsModel {

    @Inject
    @Default
    private String morningstarRatingsDisclosure;

    @Inject
    @Default
    private String overallRatingsDisclosure;

    @Inject
    @Default
    private String morningstarPercentileDisclosure;

    @Inject
    @Default
    private String characteristicsDisclosure;

    @Inject
    @Default
    private String valuationDisclosure;

    public String getMorningstarRatingsDisclosure() {
        return morningstarRatingsDisclosure;
    }

    public String getOverallRatingsDisclosure() {
        return overallRatingsDisclosure;
    }

    public String getMorningstarPercentileDisclosure() {
        return morningstarPercentileDisclosure;
    }

    public String getCharacteristicsDisclosure() {
        return characteristicsDisclosure;
    }

    public String getValuationDisclosure() {
        return valuationDisclosure;
    }
}
