package com.jhi.aem.website.v1.core.models.fund.listing;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.oak.commons.DebugTimer;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.models.ucits.UcitsModel;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListService;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListingType;
import com.jhi.aem.website.v1.core.service.fund.listing.ProductTypeDto;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDto;
import com.jhi.aem.website.v1.core.servlets.dashboard.DashboardFundServlet;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

/**
 * The Fund listing model retrieves all the funds listing data needed with links
 * to fund details page.
 */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundListingModel {

	private static final String DEFAULT_UCITS_FUND_NAME = "UCITS funds";

	private static final Logger LOG = LoggerFactory.getLogger(FundListingModel.class);

	public static final String TABLE_DATA_SELECTOR = "fundsTableData";
	private static final String TABLE_DATA_PATH = JhiConstants.DOT + TABLE_DATA_SELECTOR + JhiConstants.DOT
			+ JhiConstants.JSON_EXTENSION;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Page resourcePage;

	@SlingObject
	private ResourceResolver resolver;

	@OSGiService
	private ResourceResolverFactory resourceResolverFactory;

	@OSGiService
	private FundListService service;

	@OSGiService
	private AssetManagerService assetManagerService;

	@Inject
	@Via("resource")
	@Default
	private String ucitsFundsLink;

	@Self
	private UcitsModel ucitsModel;

	private SortedSet<ProductTypeDto> productTypes = new TreeSet<>();
	private List<ProductTypeDto> filterProductTypes = new ArrayList<>();
	private Set<String> filterClassCodes = new TreeSet<>();
	private Set<String> filterInvestmentTypes = new TreeSet<>();
	private Set<String> filterMorningstarCategories = new TreeSet<>();
	private Set<String> filterMorningstarRatings = new TreeSet<>();
	private Set<String> filterAssetManagers;
	private Set<String> filterCurrencies = new TreeSet<>();

	private String dashboardPagePath;
	private String fundComparisonPagePath;
	private String countryFilterParameter;

	@PostConstruct
	public void init() {
		DebugTimer timer = new DebugTimer();

		if (ucitsModel.isUcits()) {
			countryFilterParameter = PageUtil.getUcitsCountry(request);
			productTypes = service.getFundListing(resourcePage, FundListingType.UCITS_ONLY);
		} else {
			productTypes = service.getFundListing(resourcePage, FundListingType.NON_UCITS);
		}
		timer.mark("getFundListing");

		fundComparisonPagePath = Optional.ofNullable(getFundComparisonPage()).map(LinkUtil::getPageLink)
				.orElse(StringUtils.EMPTY);
		timer.mark("getFundComparisonPage");

		dashboardPagePath = Optional.ofNullable(getDashboardPagePath()).orElse(StringUtils.EMPTY);
		timer.mark("getDashboardPagePath");

		setFilters();
		timer.mark("setFilters");

		LOG.debug("FundListingModel::init -> {}", timer.getString());
	}

	public SortedSet<ProductTypeDto> getProductTypes() {
		return productTypes;
	}

	public List<ProductTypeDto> getFilterProductTypes() {
		return filterProductTypes;
	}

	public Set<String> getFilterClassCodes() {
		return filterClassCodes;
	}

	public Set<String> getFilterInvestmentTypes() {
		return filterInvestmentTypes;
	}

	public Set<String> getFilterMorningstarCategories() {
		return filterMorningstarCategories;
	}

	public Set<String> getFilterMorningstarRatings() {
		return filterMorningstarRatings;
	}

	public Set<String> getFilterAssetManagers() {
		return filterAssetManagers;
	}

	public String getFundComparisonPagePath() {
		return fundComparisonPagePath;
	}

	public String getDashboardPath() {
		return dashboardPagePath;
	}

	public Set<String> getFilterCurrencies() {
		return filterCurrencies;
	}

	public String getUcitsFundName() {
		ResourceResolver resourceResolver = null;
		String ucitsFundName;
		try {
			resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
			ucitsFundName = Optional
					.ofNullable(resourceResolver
							.getResource(JhiConstants.FUNDS_TAG_PATH + JhiConstants.SLASH + JhiConstants.UCITS_FUND))
					.map(Resource::getValueMap).map(valueMap -> valueMap.get("fundDetailsTitle", String.class))
					.orElseGet(() -> {
						LOG.warn("No UCITS fund tag found");
						return DEFAULT_UCITS_FUND_NAME;
					});
		} finally {
			if (resourceResolver != null && resourceResolver.isLive()) {
				resourceResolver.close();
			}
		}
		return ucitsFundName;

	}

    public String getUcitsInvestmentPageUrl() {
    	if (StringUtils.isNotBlank(ucitsFundsLink)) {
    		return ucitsFundsLink;
    	}

        return getUcitsPageLink(ResourcesConstants.INVESTMENTS_PAGE_RESOURCE_TYPE);
    }

    public String getUcitsPageLink(String resourceType) {
        return Optional.ofNullable(PageUtil.getPageByResourceType(resourcePage, PageUtil.getHomePage(resourcePage).getPath(),
                resourceType))
                .map(LinkUtil::getPageLink)
                .orElseGet(() -> {
                    LOG.warn("UCITS Page with resourcetype: {} not found", resourceType);
                    return StringUtils.EMPTY;
                });
    }

    private void setFilters() {
		filterAssetManagers = getAssetManagers();

		productTypes.forEach(productTypes -> {
			productTypes.getInvestmentTypes().forEach(investmentTypeDto -> {
				filterInvestmentTypes.add(investmentTypeDto.getTitle());
				investmentTypeDto.getFunds().forEach(fundDto -> {
					List<ShareClassDto> shareClasses = fundDto.getShareClasses();

					if (shareClasses != null) {
						Iterator<ShareClassDto> iterator = shareClasses.iterator();

						while (iterator.hasNext()) {
							ShareClassDto shareClassDto = iterator.next();

							Optional.ofNullable(shareClassDto.getCurrency()).filter(StringUtils::isNotBlank)
									.ifPresent(filterCurrencies::add);
							Optional.ofNullable(shareClassDto.getShareClassCode()).filter(StringUtils::isNotEmpty)
									.ifPresent(filterClassCodes::add);
							Optional.ofNullable(shareClassDto.getMorningStarCategory())
									.filter(StringUtils::isNotEmpty).ifPresent(filterMorningstarCategories::add);
							Optional.ofNullable(shareClassDto.getMorningStarRating())
									.filter(StringUtils::isNotEmpty).ifPresent(filterMorningstarRatings::add);
						}
					}
				});
			});
		});
	}

	private SortedSet<String> getAssetManagers() {
		SortedSet<String> assetManagers;
		ResourceResolver resourceResolver = null;
		try {
			resourceResolver = ResourceResolverUtil.getResourceResolver(resourceResolverFactory);
			assetManagers = assetManagerService
					.getAllAssetManagers(resourceResolver, PageUtil.getAssetManagersConfigRootPath(resourcePage))
					.stream().map(AssetManagerModel::getName).filter(StringUtils::isNotEmpty)
					.collect(Collectors.toCollection(TreeSet::new));
		} finally {
			if (resourceResolver != null && resourceResolver.isLive()) {
				resourceResolver.close();
			}
		}
		return assetManagers;
	}

	private Page getFundComparisonPage() {
		return PageUtil.getPageByResourceType(resourcePage, resourcePage.getParent().getPath(),
				ResourcesConstants.FUND_COMPARISON_PAGE_RESOURCE_TYPE);
	}

	private String getDashboardPagePath() {
		return resourcePage.getContentResource().getPath()
				+ DashboardFundServlet.DASHBOARD_REQUEST_TOGGLE_FUND_TAG_STRING;
	}

	public String getTableDataPath() {
		return resolver.map(resourcePage.getPath() + JhiConstants.SLASH + JcrConstants.JCR_CONTENT) + TABLE_DATA_PATH;
	}
}
