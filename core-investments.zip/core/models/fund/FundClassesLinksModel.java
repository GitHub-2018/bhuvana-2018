package com.jhi.aem.website.v1.core.models.fund;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.generic.link.SimpleLink;
import com.jhi.aem.website.v1.core.models.fund.tags.Fund;
import com.jhi.aem.website.v1.core.models.fund.tags.ShareClass;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListMapper;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDto;
import com.jhi.aem.website.v1.core.utils.FundUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ValueMapUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundClassesLinksModel {

    private static final Logger LOG = LoggerFactory.getLogger(FundClassesLinksModel.class);

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Page resourcePage;

    @SlingObject
    private ResourceResolver resolver;

    @OSGiService
    private FundListMapper mapper;

    private List<SimpleLink> classesLinks = new ArrayList<>();

    @PostConstruct
    protected void init() {
    	final boolean isUcits = PageUtil.isInUcitsSite(resourcePage);
    	final String countryFilterParameter = isUcits ? PageUtil.getUcitsCountry(request) : StringUtils.EMPTY;

    	final Tag shareClassTag = FundUtil.getTagFromSuffix(request);

        if (shareClassTag != null) {
            final Tag fundTag = shareClassTag.getParent();
            classesLinks = Optional.ofNullable(request.getResourceResolver().getResource(fundTag.getPath()))
                    .map(resource -> resource.adaptTo(Fund.class))
                    .map(fund -> getClassLinks(shareClassTag, fund, isUcits, countryFilterParameter))
                    .orElseGet(ArrayList::new);
        }
    }

    private List<SimpleLink> getClassLinks(Tag shareClassTag, Fund fund, boolean isUcits, String countryFilterParameter) {
        String shareClassVal = Optional.ofNullable(resolver.getResource(shareClassTag.getPath()))
                .map(Resource::getValueMap)
                .map(valueMap -> ValueMapUtil.getProperty(valueMap, isUcits ? JhiConstants.ISIN : JhiConstants.SHARE_CLASS))
                .orElse(StringUtils.EMPTY);
        
        List<SimpleLink> links = new ArrayList<>();

        for (ShareClass shareClass : fund.getShareClasses()) {
        	ShareClassDto shareClassDto = mapper.mapShareClass(shareClass, resourcePage);

        	if (!ShareClassDto.EMPTY.equals(shareClassDto)) {
        		
        		// Check country for UCITS
        		if (!isUcits || 
        				(StringUtils.isNotBlank(countryFilterParameter) && 
        						shareClassDto.getUcitsCountries().contains(countryFilterParameter))) {
        			String shareClassLink = isUcits ?
        					shareClassDto.getLink() + "/" + countryFilterParameter : shareClassDto.getLink();
        			links.add(new SimpleLink(shareClassLink, shareClassDto.getShareClassCode(),
                          shareClassDto.getCurrency(), 
                          shareClassVal.equalsIgnoreCase(isUcits ? shareClassDto.getIsin() : shareClassDto.getShareClass())));
        		} else {
        			LOG.debug("Eliminated UCITS country with country='{}' for share class {} with country list: {}",
        					new Object[] {countryFilterParameter, shareClass.getIsin(), shareClassDto.getUcitsCountries()});
        		}

        	} else {
        		LOG.debug("Empty share class found for share class: {}", shareClass.getIsin());
        	}
        }
        
        return links;
    }

    public Set<SimpleLink> getLinks() {
        Set<SimpleLink> links = new TreeSet<>();
        SimpleLink activeLink = getActiveLink();

        if (activeLink != SimpleLink.EMPTY) {
        	links.add(getActiveLink());
        }

        links.addAll(classesLinks);
        return links;
    }

    public List<SimpleLink> getCurrencyLinks() {
        String activeLinkTitle = getActiveLink().getTitle();
        return classesLinks.stream()
                .filter(link -> link.getTitle().equalsIgnoreCase(activeLinkTitle))
                .collect(Collectors.toList());
    }

    public SimpleLink getActiveLink() {
        return classesLinks.stream()
                .filter(SimpleLink::isActive)
                .findFirst()
                .orElse(SimpleLink.EMPTY);
    }
}
