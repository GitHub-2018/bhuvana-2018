package com.jhi.aem.website.v1.core.models.fund.tags;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.jhi.aem.website.v1.core.service.runmode.RunModeService;

/**
 * The Fund tag model.
 */
@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class Fund {
	private static final Logger LOG = LoggerFactory.getLogger(Fund.class);

    List<String> priorities = Arrays.asList("aa", "a", "r6", "i");

    @ValueMapValue(name = JcrConstants.JCR_TITLE)
    private String title;

    @SlingObject
    private Resource resource;

    @ValueMapValue
    private String fundId;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String useFor;

    @OSGiService
    private RunModeService runModeService;

    private List<ShareClass> shareClasses = new ArrayList<>();

    @PostConstruct
    public void init() {
    	for (Resource child : resource.getChildren()) {
    		ShareClass shareClass = child.adaptTo(ShareClass.class);
    		if (shareClass !=null) {
    			if (runModeService.isAuthor() || (shareClass.isActive() && shareClass.isPublished())) {
    				shareClasses.add(shareClass);
    			} else {
    				if (LOG.isDebugEnabled()) {
    					LOG.debug("Share class not added in {} mode for path {}, active={}, published={}", 
    							new Object[] {runModeService.isAuthor() ? "Author" : "Publisher", child.getPath(), shareClass.isActive(), shareClass.isPublished()});
    				}
    			}
    		} else {
    			LOG.warn("Cannot adapt resource to " + ShareClass.class + ": {}", child.getPath());
    		}
    	}
    }
    
    public boolean isActive() {
    	return !shareClasses.isEmpty();
    }

    public String getTitle() {
        return title;
    }

    public String getFundId() {
        return fundId;
    }

    public List<ShareClass> getShareClasses() {
        return shareClasses;
    }

    public String getUseFor() {
        return useFor;
    }

    public String getName() {
        return Optional.ofNullable(resource)
                .map(Resource::getName)
                .orElse(StringUtils.EMPTY);
    }

    public ShareClass getDefaultShareClass() {
        if (shareClasses.isEmpty()) {
            return ShareClass.EMPTY;
        }

        if (shareClasses.size() > 1) {
            shareClasses.sort(Comparator.comparing(o -> priorities.indexOf(o.getShareClassCode().toLowerCase())));
        }

        return shareClasses.get(shareClasses.size() - 1);
    }

    public Resource getResource() {
        return resource;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof Fund))
            return false;
        Fund fund = (Fund) o;
        return Objects.equals(getResource().getPath(), fund.getResource().getPath());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getResource().getPath());
    }
}
