package com.jhi.aem.website.v1.core.models.fund.tags;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;

/**
 * The Fund investment type tag model.
 */
@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundInvestmentType {
	private static final Logger LOG = LoggerFactory.getLogger(FundInvestmentType.class);

    private static final Map<String, String> INVESTMENT_RESOURCE_TYPES;
    static {
        Map<String, String> aMap = new HashMap<>();
        aMap.put("alternative-funds", "jhi-website-v1/pages/landingPages/alternativeinvestments");
        aMap.put("asset-allocation-funds", "jhi-website-v1/pages/landingPages/assetallocation");
        aMap.put("fixed-income-funds", "jhi-website-v1/pages/landingPages/fixedincome");
        aMap.put("international-equity-funds", "jhi-website-v1/pages/landingPages/internationalinvesting");
        aMap.put("us-equity-funds", "jhi-website-v1/pages/landingPages/usequity");
        INVESTMENT_RESOURCE_TYPES = Collections.unmodifiableMap(aMap);
    }

    @ValueMapValue(name = JcrConstants.JCR_TITLE)
    private String title;

    @SlingObject
    private Resource resource;

    private List<Fund> funds = new ArrayList<>();

    @PostConstruct
    public void init() {
        for (Resource child : resource.getChildren()) {
        	Fund fund = child.adaptTo(Fund.class);
        	
        	if (fund != null) {
        		funds.add(fund);
        	} else{
        		LOG.debug("Could not add fund {}", child.getPath());
        	}
        }
    }

    public String getTitle() {
        return title;
    }

    public String getResourceName() {
        return resource.getName();
    }

    public List<Fund> getFunds() {
        return funds;
    }

    public String getLandingPageResourceType() {
        return Optional.ofNullable(INVESTMENT_RESOURCE_TYPES.get(resource.getName()))
                .orElse(StringUtils.EMPTY);
    }
}
