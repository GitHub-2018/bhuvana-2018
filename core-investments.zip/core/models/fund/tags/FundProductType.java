package com.jhi.aem.website.v1.core.models.fund.tags;

import java.util.ArrayList;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.commons.jcr.JcrConstants;

/** The Fund product type tag model. */
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class FundProductType {

    @ValueMapValue(name = JcrConstants.JCR_TITLE)
    private String title;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String fundDetailsTitle;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private Integer fundDetailsOrderNumber = Integer.MAX_VALUE;

    @SlingObject
    private Resource resource;

    private List<FundInvestmentType> investmentTypes = new ArrayList<>();

    @PostConstruct
    public void init() {
        resource.getChildren()
                .forEach(r -> Optional.ofNullable(r.adaptTo(FundInvestmentType.class))
                        .ifPresent(investmentTypes::add));
    }

    public String getFundDetailsTitle() {
        return Optional.ofNullable(fundDetailsTitle)
                .orElse(title);
    }

    public String getTitle() {
        return title;
    }

    public List<FundInvestmentType> getInvestmentTypes() {
        return investmentTypes;
    }

    public List<FundInvestmentType> getFilteredInvestmentTypes(String investmentType) {
        return investmentTypes
                .stream()
                .filter(isInvestmentType(investmentType))
                .collect(Collectors.toList());
    }

    public Integer getFundDetailsOrderNumber() {
        return fundDetailsOrderNumber;
    }

    private Predicate<FundInvestmentType> isInvestmentType(String investmentType) {
        return fundInvestmentType -> StringUtils.isBlank(investmentType)
                || fundInvestmentType.getResourceName().equalsIgnoreCase(investmentType);
    }
}
