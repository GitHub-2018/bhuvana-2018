package com.jhi.aem.website.v1.core.models.fund.tags;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.tagging.Tag;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.utils.ValueMapUtil;

/** The Share class tag model. */
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ShareClass {
    private static final Logger LOG = LoggerFactory.getLogger(ShareClass.class);

    public static final ShareClass EMPTY = new ShareClass();

    @ValueMapValue(name = JcrConstants.JCR_TITLE)
    private String title;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String tickerId;

    @ValueMapValue
    private String shareClass;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String morningStarCategory;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String morningStarRating;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String isin;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String currency;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String shareClassCode;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String cusip;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String active;

    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String published;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private List<String> ucitsCountries;
    

    @SlingObject
    private Resource resource;

    private Tag tag;
    private String fundTitle = StringUtils.EMPTY;
    private String fundTypeTitle = StringUtils.EMPTY;
    private String useFor = StringUtils.EMPTY;
    private String fundCode = StringUtils.EMPTY;

    @PostConstruct
    protected void init() {
        tag = resource.adaptTo(Tag.class);
        Optional.ofNullable(resource)
                .map(Resource::getParent)
                .ifPresent(resource -> {
                    ValueMap valueMap = resource.getValueMap();
                    fundTitle = ValueMapUtil.getProperty(valueMap, JcrConstants.JCR_TITLE);
                    useFor = ValueMapUtil.getProperty(valueMap, JhiConstants.USE_FOR);
                    fundCode = ValueMapUtil.getProperty(valueMap, JhiConstants.FUND_ID);
                    fundTypeTitle = Optional.ofNullable(resource.getParent())
                            .map(Resource::getValueMap)
                            .map(valueMap1 -> ValueMapUtil.getProperty(valueMap1, JcrConstants.JCR_TITLE))
                            .orElse(StringUtils.EMPTY);
                });
    }

    public String getTitle() {
        return title;
    }

    public String getShareClass() {
        return shareClass;
    }

    public String getShareClassCode() {
        return Optional.ofNullable(shareClassCode)
                .orElse(Optional.ofNullable(resource)
                        .map(Resource::getName)
                        .map(str -> StringUtils.replace(str, "-", " ").toUpperCase())
                        .orElse(StringUtils.EMPTY));
    }

    public String getShareClassLetter() {
        return Optional.of(getShareClassCode().split(" "))
                .filter(strings -> strings.length > 0)
                .map(strings -> strings[0].toUpperCase())
                .orElse(getShareClassCode());
    }

    public String getDistType() {
        return Optional.of(getShareClassCode().split(" "))
                .filter(strings -> strings.length > 1)
                .map(strings -> StringUtils.capitalize(strings[1].toLowerCase()))
                .orElse("—");
    }

    public String getTickerId() {
        return tickerId;
    }

    public String getMorningStarCategory() {
        return morningStarCategory;
    }

    public String getMorningStarRating() {
        return morningStarRating;
    }

    public String getUseFor() {
        return useFor;
    }

    public Tag getTag() {
        return tag;
    }

    public String getFundTitle() {
        return fundTitle;
    }

    public String getFundTypeTitle() {
        return fundTypeTitle;
    }

    public String getName() {
        return resource.getName();
    }

    public String getIsin() {
        return isin;
    }

    public String getCurrency() {
        return currency;
    }

    public String getCusip() {
        return cusip;
    }

    public String getFundCode() {
        return fundCode;
    }

    public boolean isActive() {
        return BooleanUtils.toBoolean(active);
    }

    public boolean isPublished() {
        return BooleanUtils.toBoolean(published);
    }

	public List<String> getUcitsCountries() {
		return ucitsCountries;
	}
}
