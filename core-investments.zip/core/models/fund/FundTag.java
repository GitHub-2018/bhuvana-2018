package com.jhi.aem.website.v1.core.models.fund;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.tagging.Tag;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundTag implements Comparable<FundTag> {
    private static final SortedSet<String> EMPTY_SORTED_SET = new TreeSet<>();

	@Inject
    private String tagId;

    @ValueMapValue(name = "fundId")
    private String fundCode;

    @ValueMapValue(name = "jcr:title")
    private String displayName;

    @ValueMapValue
    private String shareClass;

    @ValueMapValue
    private String tickerId;

    @ValueMapValue
    private Boolean isFund;

    @ValueMapValue
    private Boolean isShareClass;

    @ValueMapValue
    private String cusip;

    @ValueMapValue
    private String inceptionDate;

    @ValueMapValue
    private String isin;

    @ValueMapValue
    private Boolean active;

    @ValueMapValue
    private Boolean published;

    @SlingObject
    private Resource resource;

    private FundTag fund;
    private String shareClassLetter;
    private ValueMap valueMap;
    private String tagPath;
	private Boolean isUcits;
	private SortedSet<String> ucitsCountriesList;

    public FundTag() {
    }

    public FundTag(Tag fundTag) {
        fillMetadata(fundTag);
    }

    public final void fillMetadata(Tag fundTag) {
        tagPath = fundTag.getPath();
        valueMap = getValueMap(fundTag);
        isFund = getNonNullBoolean(JhiConstants.IS_FUND);
        isShareClass = getNonNullBoolean(JhiConstants.IS_SHARE_CLASS);
        tagId = fundTag.getTagID();
        displayName = fundTag.getTitle();
        if (isShareClass) {
            shareClassLetter = fundTag.getName().toUpperCase();
            shareClass = getNonNullString(JhiConstants.SHARE_CLASS);
            fund = new FundTag(fundTag.getParent());
            tickerId = getNonNullString(JhiConstants.TICKER_ID);
            cusip = getNonNullString(JhiConstants.CUSIP);
            fundCode = getFundId();
            inceptionDate = getNonNullString(JhiConstants.INCEPTION_DATE);
            isin = getNonNullString(JhiConstants.ISIN);
            isUcits = BooleanUtils.isTrue(valueMap.get(JhiConstants.IS_UCITS_PROPERTY, Boolean.class));
            
            if (isUcits) {
            	String[] countries = valueMap.get(JhiConstants.UCITS_COUNTRIES, String[].class);
            	if (countries != null) {
            		ucitsCountriesList = Arrays.stream(countries).collect(Collectors.toCollection(TreeSet::new));
            	} else {
            		ucitsCountriesList = EMPTY_SORTED_SET;
            	}
            }
            
            Object activeVal = valueMap.get(JhiConstants.ACTIVE);
            active = activeVal instanceof String ?
                    BooleanUtils.toBooleanObject((String) activeVal) : BooleanUtils.isTrue((Boolean) activeVal);
            published = BooleanUtils.isTrue((Boolean) valueMap.get(JhiConstants.PUBLISHED));

        } else {
            fundCode = getNonNullString(JhiConstants.FUND_ID);
        }
    }

    public Boolean isFundTag() {
        return isFund;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public String getFundCode() {
        return fundCode;
    }

    public void setFundCode(String fundCode) {
        this.fundCode = fundCode;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getShareClass() {
        return shareClass;
    }

    public void setShareClass(String shareClass) {
        this.shareClass = shareClass;
    }

    public boolean isValid() {
        return StringUtils.isNoneBlank(tagId, fundCode);
    }

    public String getShareClassLetter() {
        return shareClassLetter;
    }

    public String getTickerId() {
        return tickerId;
    }

    public String getCusip() {
        return cusip;
    }

    public Boolean isShareClassTag() {
        return isShareClass;
    }

    public String getTagPath() {
        return tagPath;
    }

    public String getDisplayFundName() {
        return Optional.ofNullable(fund)
                .map(FundTag::getDisplayName)
                .orElse(displayName);
    }

    public String getInceptionDate() {
        return inceptionDate;
    }

    public String getIsin() {
        return isin;
    }

    public boolean isActive() {
        return !isShareClass || BooleanUtils.isTrue(active);
    }

    public boolean isPublished() {
        return !isShareClass || BooleanUtils.isTrue(published);
    }

    public boolean isActiveAndPublished() {
        return !isShareClass || (BooleanUtils.isTrue(active) && BooleanUtils.isTrue(published));
    }
    
    public boolean isUcits() {
    	return isUcits;
    }

    private ValueMap getValueMap(Tag fundTag) {
        return Optional.ofNullable(fundTag)
                .map(fTag -> fTag.adaptTo(Resource.class))
                .map(Resource::getValueMap)
                .orElse(new ValueMapDecorator(new HashMap<>()));
    }

    private String getFundId() {
        return Optional.ofNullable(fund)
                .map(FundTag::getFundCode)
                .orElse(StringUtils.EMPTY);
    }

    private String getNonNullString(String property) {
        return Optional.ofNullable(valueMap.get(property, String.class))
                .orElse(StringUtils.EMPTY);
    }

    private Boolean getNonNullBoolean(String property) {
        return Optional.ofNullable(valueMap.get(property, Boolean.class))
                .orElse(Boolean.FALSE);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof FundTag))
            return false;
        FundTag fundTag = (FundTag) o;
        return Objects.equals(getTagPath(), fundTag.getTagPath());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getTagPath());
    }

    @Override
    public int compareTo(FundTag b) {
        if (this == b)
            return 0;
        if (b == null)
            return -1;
        return this.getDisplayName().compareTo(b.getDisplayName());
    }

	public SortedSet<String> getUcitsCountries() {
		return ucitsCountriesList;
	}

}
