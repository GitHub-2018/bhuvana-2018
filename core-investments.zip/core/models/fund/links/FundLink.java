package com.jhi.aem.website.v1.core.models.fund.links;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables=Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class FundLink {

    private static final String BLANK = "_blank";
    
    @Inject
    private String link;
    
    @Inject
    private String title;


    public String getLink() {
        return LinkUtil.getLink(link);
    }

    public String getTitle() {
        return title;
    }

    public String getTarget() {
        return LinkUtil.isInternalPath(link) ? StringUtils.EMPTY : BLANK;
    }
}
