package com.jhi.aem.website.v1.core.models.fund.links;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FundLinksModel {

    private final Logger Log = LoggerFactory.getLogger(FundLinksModel.class);

   @Inject
    private List<FundLink> links;

    

    @PostConstruct
    public void init() {
        Log.debug("Initializing FundLinks Model");
    }

    public List<FundLink> getLinks() {
        return links;
    }
    
    public List<FundLink> getFundLinksItems() {
        return links;
    }
}
