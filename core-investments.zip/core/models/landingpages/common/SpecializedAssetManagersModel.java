package com.jhi.aem.website.v1.core.models.landingpages.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SpecializedAssetManagersModel {

	@Inject
	private String heading;

	@Inject
	private String leftBodyCopy;

	@Inject
	private String videoUrl;
	
    @Inject
    private ImageModel videoImage;

	@Inject
	private String videoImageAltText;
	
	@Inject
	private String rightBodyHeading;

	@Inject
	private String rightBodyCopy;

	@Inject
	private List<Resource> assetManagers;

    @Inject
    private Page resourcePage;

    @OSGiService
    private AssetManagerService assetManagerService;

    @SlingObject
	private ResourceResolver resolver;
    
	private Set<AssetManagerModel> managers;

    @PostConstruct
    public void init() {
		managers = assetManagerService.getConfiguredAssetManagers(resolver, assetManagers);
    }

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public String getLeftBodyCopy() {
		return leftBodyCopy;
	}

	public void setLeftBodyCopy(String leftBodyCopy) {
		this.leftBodyCopy = leftBodyCopy;
	}

	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}

	public ImageModel getVideoImage() {
		return videoImage;
	}

    public String getVideoImagePath() {
        return ImageModel.getImagePath(videoImage);
    }

	public String getVideoImageAltText() {
		return videoImageAltText;
	}

	public void setVideoImageAltText(String videoImageAltText) {
		this.videoImageAltText = videoImageAltText;
	}

	public String getRightBodyHeading() {
		return rightBodyHeading;
	}

	public void setRightBodyHeading(String rightBodyHeading) {
		this.rightBodyHeading = rightBodyHeading;
	}

	public String getRightBodyCopy() {
		return rightBodyCopy;
	}

	public void setRightBodyCopy(String rightBodyCopy) {
		this.rightBodyCopy = rightBodyCopy;
	}

	public Set<AssetManagerModel> getAssetManagers() {
		return managers;
	}

	public void setAssetManagers(Set<AssetManagerModel> assetManagers) {
		this.managers = assetManagers;
	}

}
