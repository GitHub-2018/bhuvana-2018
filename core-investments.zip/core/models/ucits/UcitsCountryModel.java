package com.jhi.aem.website.v1.core.models.ucits;

import org.apache.commons.lang3.StringUtils;

public class UcitsCountryModel implements Comparable<UcitsCountryModel> {
	private final String countryCode;
	private final String displayName;
	
	public UcitsCountryModel(String countryCode, String displayName) {
		this.countryCode = countryCode;
		this.displayName = displayName;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public String getDisplayName() {
		return displayName;
	}

	@Override
	public int compareTo(UcitsCountryModel other) {
		return StringUtils.compare(displayName, other.displayName);
	}

}
