package com.jhi.aem.website.v1.core.models.ucits;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class UcitsContainerModel {

    @Inject
    private String title;

    @Inject
    private String description;

    @Inject
    private String mainText;
    
    @Inject
    private String chooseCountryLabel;
    
    @Inject
    private String internationalButtonLabel;

    @Inject
    private String internationalButtonUrl;

    @Inject
    private String usButtonLabel;

    @Inject
    private String usButtonUrl;

    @OSGiService
    private ResourceResolverFactory resolverFactory;

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getMainText() {
        return mainText;
    }

    public String getUsButtonLabel() {
        return usButtonLabel;
    }

    public String getUsButtonUrl() {
        return LinkUtil.getLinkWithDefaultResolver(resolverFactory, usButtonUrl);
    }

    public String getInternationalButtonLabel() {
        return internationalButtonLabel;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(description) && StringUtils.isBlank(mainText)
                && StringUtils.isBlank(usButtonLabel) && StringUtils.isBlank(usButtonUrl)
                && StringUtils.isBlank(internationalButtonLabel);
    }

	public String getChooseCountryLabel() {
		return chooseCountryLabel;
	}

	public String getInternationalButtonUrl() {
		return LinkUtil.getLinkWithDefaultResolver(resolverFactory, internationalButtonUrl);
	}

}
