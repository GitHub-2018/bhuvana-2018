package com.jhi.aem.website.v1.core.models.ucits;

import java.util.Locale;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.service.i18n.I18nService;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class UcitsModel {
	private static final Logger LOG = LoggerFactory.getLogger(UcitsModel.class);

	@Self
    private SlingHttpServletRequest request;
	
	@Inject
    private Page currentPage;

    private boolean isUcits;

    @OSGiService
    private FundService fundService;

    @OSGiService
	private I18nService i18nService;

    private SortedSet<UcitsCountryModel> ucitsCountries;

    @PostConstruct
    public void init() {
        isUcits = PageUtil.isInUcitsSite(currentPage);
        Locale localeFromPage = PageUtil.getLocaleFromPage(currentPage);
        String displayLang;

        if (localeFromPage != null && localeFromPage.getDisplayLanguage() != null) {
        	displayLang = localeFromPage.getDisplayLanguage();
        } else {
        	LOG.debug("No display language set for page {}, using default language", currentPage.getPath());
        	displayLang = "en";
        }

        SortedSet<String> ucitsCountryCodes = fundService.getUcitsCountryCodes();
        ucitsCountries = new TreeSet<>();
        
        for (String ucitsCountryCode : ucitsCountryCodes) {
        	String messageKey = "country_display_" + displayLang + "_" + ucitsCountryCode;
			String displayName = i18nService.getMessageWithKey(request, messageKey);

			if (StringUtils.isEmpty(displayName) || StringUtils.equals(messageKey, displayName)) {
        		// Default if no key available
        		displayName = new Locale(displayLang, ucitsCountryCode).getDisplayCountry();
        	}

        	ucitsCountries.add(new UcitsCountryModel(ucitsCountryCode, displayName));
        }
    }

    public boolean isUcits() {
        return isUcits;
    }

	public SortedSet<UcitsCountryModel> getUcitsCountries() {
		return ucitsCountries;
	}

}
