package com.jhi.aem.website.v1.core.models.micrositehero;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MiMicrositeHeroModel {
    @Inject @Default(values="")
    private String heading;

    @Inject @Default(values="")
    private String subheading;
    
    @Inject @Named("ITunesAppDownload")
    private ITunesDownloadModel ITunesAppDownload;

    @Inject @Named("pdfDownload")
    private PdfDownloadModel pdfDownload;

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public String getSubheading() {
		return subheading;
	}

	public void setSubheading(String subheading) {
		this.subheading = subheading;
	}

	public ITunesDownloadModel getITunesAppDownload() {
		return ITunesAppDownload;
	}

	public void setITunesAppDownload(ITunesDownloadModel iTunesAppDownload) {
		this.ITunesAppDownload = iTunesAppDownload;
	}

	public PdfDownloadModel getPdfDownload() {
		return pdfDownload;
	}

	public void setPdfDownload(PdfDownloadModel pdfDownload) {
		this.pdfDownload = pdfDownload;
	}

}
