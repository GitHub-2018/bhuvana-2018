package com.jhi.aem.website.v1.core.models.micrositehero;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class WhitepaperModel {

    @Inject
    private String link;

    @Inject
    private String copy;

    @Inject
    private String cta;

    @Inject
    private String downloadLabel;

    @Inject
    private ImageModel thumbnail;

    @Inject
    private String thumbnailAlt;

    @Inject
    private String downloadStyle;

    public String getLink() {
        return LinkUtil.getLink(link);
    }

    public String getCopy() {
        return copy;
    }

    public String getCta() {
        return cta;
    }

    public String getDownloadLabel() {
        return downloadLabel;
    }

    public String getThumbnailPath() {
        return ImageModel.getImagePath(thumbnail);
    }

    public String getThumbnailAlt() {
        return thumbnailAlt;
    }

    public boolean isValid() {
        return StringUtils.isNotBlank(link) && StringUtils.isNotBlank(cta)
                && StringUtils.isNotBlank(downloadLabel);
    }

	public String getDownloadStyle() {
		return downloadStyle == null ? "" : downloadStyle;
	}

	public void setDownloadStyle(String downloadStyle) {
		this.downloadStyle = downloadStyle;
	}
}
