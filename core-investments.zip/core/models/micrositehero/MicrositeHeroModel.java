package com.jhi.aem.website.v1.core.models.micrositehero;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.video.BrightcoveVideoModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeHeroModel {

    @Inject
    private String title;

    @Inject
    private String text;

    @Inject
    private ImageModel backgroundLeft;
    
    @Inject
    private ImageModel backgroundRight;
    
    @Inject
    private String rightLayoutClass;

    @Inject
    private WhitepaperModel whitepaper1;

    @Inject
    private WhitepaperModel whitepaper2;
    
    @ChildResource
    private BrightcoveVideoModel video;

    @Inject
    private String ctaTitle;

    @Inject
    private String ctaCopy;

    @Inject
    private String ctaLink;

    @Inject
    private String ctaButtonLabel;

    @Inject
    private ImageModel ctaImage;

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getRightLayoutClass() {
        return rightLayoutClass;
    }

    public WhitepaperModel getWhitepaper1() {
        return whitepaper1;
    }

    public WhitepaperModel getWhitepaper2() {
        return whitepaper2;
    }

    public String getCtaTitle() {
        return ctaTitle;
    }

    public String getCtaCopy() {
        return ctaCopy;
    }

    public String getCtaLink() {
        return LinkUtil.getLink(ctaLink);
    }

    public String getCtaButtonLabel() {
        return ctaButtonLabel;
    }

    public ImageModel getCtaImage() {
        return ctaImage;
    }

    public String getCtaImagePath() {
        return ImageModel.getImagePath(ctaImage);
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(text);
    }

    public boolean isVideoExists() {
    	return video != null && !video.isBlank();
    }

    public BrightcoveVideoModel getVideo() {
		return video;
	}

	public String getBackgroundLeftPath() {
        return ImageModel.getImagePath(backgroundLeft);
	}

	public String getBackgroundRightPath() {
        return ImageModel.getImagePath(backgroundRight);
	}

	public boolean isSingleBackground() {
		return backgroundLeft != null && backgroundRight == null;
	}

}
