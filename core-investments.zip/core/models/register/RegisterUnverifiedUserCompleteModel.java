package com.jhi.aem.website.v1.core.models.register;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.IsamUserProfileConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RegisterUnverifiedUserCompleteModel {
	private static final String VALIDATE_PASSWORD_SELECTOR_PART =
			  JhiConstants.DOT + IsamUserProfileConstants.VALIDATE_PASSWORD_SELECTOR
	            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;

	@Inject @Via("resource")
    private String title;

    @Inject @Via("resource")
    private String subtitle;

    @Inject @Via("resource")
    private String passwordLabel;

    @Inject @Via("resource")
    private String confirmPasswordLabel;

    @Inject @Via("resource")
    private String submitButtonLabel;
    
    @Inject
    @Via("resource")
    @Default
    private List<Resource> passwordCriterias;
    
    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Resource resource;

//    @Inject
//    private ResourceResolver resourceResolver;

//    private String mappedResourcePath;

//    @PostConstruct
//    protected void init() {
//        mappedResourcePath = resourceResolver.map(request, resource.getPath());
//    }

    public String getTitle() {
        return title;
    }

    public String getPasswordLabel() {
        return passwordLabel;
    }

    public String getConfirmPasswordLabel() {
        return confirmPasswordLabel;
    }

    public String getSubmitButtonLabel() {
        return submitButtonLabel;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title);
    }

    public String getCompleteRegistrationPath() {
        return resource.getPath() + JhiConstants.SLING_SECURITY_CHECK_PATH;
    }
    
    public String getValidatePasswordPath() {
        return resource.getPath() + VALIDATE_PASSWORD_SELECTOR_PART;
    }

	public String getSubtitle() {
		return subtitle;
	}

	public List<Resource> getPasswordCriterias() {
		return passwordCriterias;
	}
}
