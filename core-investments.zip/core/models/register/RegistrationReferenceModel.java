package com.jhi.aem.website.v1.core.models.register;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class)
public class RegistrationReferenceModel {

    public static final String MAIN_PARAGRAPH_PATH = "mainParagraph";

    @Inject
    @Default
    private String registrationReferencePage;

    @Inject
    private Page resourcePage;

    @Inject
    private PageManager pageManager;

    private String registrationReference;

    public String getRegistrationReferencePath() {
        Page registrationPage = null;
        if (registrationReference == null) {
            if (StringUtils.isNotBlank(registrationReferencePage)) {
                registrationPage = pageManager.getPage(registrationReferencePage);
                if (!PageUtil.isResourceType(registrationPage, ResourcesConstants.REGISTRATION_PAGE_RESOURCE_TYPE)) {
                    registrationPage = null;
                }
            }
            if (registrationPage == null
                    && PageUtil.isResourceType(resourcePage.getParent(), ResourcesConstants.REGISTRATION_PAGE_RESOURCE_TYPE)) {
                registrationPage = resourcePage.getParent();
            }

            if (registrationPage != null) {
                Resource registrationPageContent = registrationPage.getContentResource();
                if (registrationPageContent != null) {
                    Resource mainParagraphResource = registrationPageContent.getChild(MAIN_PARAGRAPH_PATH);
                    if (mainParagraphResource != null) {
                        for (Resource resource : mainParagraphResource.getChildren()) {
                            if (resource.isResourceType(ResourcesConstants.REGISTRATION_START_RESOURCE_TYPE)) {
                                return resource.getPath();
                            }
                        }
                    }
                }
            } else {
                registrationReference = StringUtils.EMPTY;
            }
        }
        return registrationReference;
    }
}
