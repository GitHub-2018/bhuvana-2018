package com.jhi.aem.website.v1.core.models.register;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.forgotpassword.ForgotPasswordSectionModel;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RegistrationStartModel {

    @Inject
    private Resource resource;

    @Inject
    private String title;

    @Inject
    private String subtitle;

    @Inject
    private String emailPlaceholderText;

    @Inject
    private String emailFieldLabel;

    @Inject
    private String prompt;

    @Inject
    private Boolean hideHero;

    @Inject
    private String heroTitle;

    @Inject
    private String leftImageTitle;

    @ChildResource(injectionStrategy = InjectionStrategy.OPTIONAL)
    private ImageModel leftImage;

    @Inject
    private String centerImageTitle;

    @ChildResource(injectionStrategy = InjectionStrategy.OPTIONAL)
    private ImageModel centerImage;

    @Inject
    private String rightImageTitle;

    @ChildResource(injectionStrategy = InjectionStrategy.OPTIONAL)
    private ImageModel rightImage;

    @Inject
    private String emailAddressProfessionalAddressFailedMessage;

    @Inject
    private String emailAddressFormatFailedMessage;

    @Inject
    private String submitButtonLabel;

    @Inject
    private String techErrorTitle;

    @Inject
    private String techErrorSubtitle;

    @Inject
    private String userExistsTitle;

    @Inject
    private String userExistsSubtitle;

    @Inject
    private String userExistsEmailFieldLabel;

    @Inject
    private String userExistsContinueButtonLabel;

    @Inject
    private String rejectedTitle;

    @Inject
    private String rejectedSubtitle;

    @Inject
    private String rejectedContinueButtonLabel;

    @Inject
    private String rejectedContinueButtonLink;

    @Inject
    private String vfpSuccessTitle;

    @Inject
    private String vfpSuccessSubtitle;

    @Inject
    private String vfpContinueButtonLabel;

    @Inject
    private String vfpContinueButtonLink;

    @Inject
    private String ufpTitle;

    @Inject
    private String ufpSubtitle;

    @Inject
    private String ufpFirstNameLabel;

    @Inject
    private String ufpLastNameLabel;

    @Inject
    private String ufpEmailLabel;

    @Inject
    private String ufpFirmLabel;

    @Inject
    private String ufpRoleLabel;

    @Inject
    private List<Resource> ufpRoles;

    @Inject
    private String ufpCrdNumberLabel;

    @Inject
    private String ufpContinueButtonLabel;

    @Inject
    private String employeeTitle;

    @Inject
    private String employeeSubtitle;

    @Inject
    private String employeeFirstNameLabel;

    @Inject
    private String employeeLastNameLabel;

    @Inject
    private String employeeEmailLabel;

    @Inject
    private String employeeContinueButtonLabel;

    @Inject
    private String resetPasswordResetTitle;

    @Inject
    private String resetPasswordResendSubtitle;

    @Inject
    private String resetPasswordResendButtonLabel;

    @Inject
    private String resetPasswordResendFailedMessage;

    @Inject
    private String resetPasswordResendSuccessMessage;

    @Inject
    private boolean allowInvestorUser;

    @Inject
    @Default(values = "I am financial advisor")
    private String financialAdvisorOptionLabel;

    @Inject
    @Default(values = "I am investor")
    private String investorOptionLabel;

    public String getResetPasswordSubmitPath() {
        return resource.getPath() + ForgotPasswordSectionModel.FORGOT_PASSWORD_SELECTOR_PART;
    }

    public String getRegisterUserPath() {
        return resource.getPath() + JhiConstants.SLING_SECURITY_CHECK_PATH;
    }

    public boolean isBlank() {
        return false;
    }

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getEmailFieldLabel() {
        return emailFieldLabel;
    }

    public String getPrompt() {
        return prompt;
    }

    public boolean isShowHero() {
        return !Boolean.TRUE.equals(hideHero)
                && (StringUtils.isNotBlank(heroTitle) || StringUtils.isNotBlank(leftImageTitle) || StringUtils.isNotBlank(centerImageTitle) || StringUtils.isNotBlank(rightImageTitle));
    }

    public String getHeroTitle() {
        return heroTitle;
    }

    public String getLeftImageTitle() {
        return leftImageTitle;
    }

    public String getLeftImagePath() {
        return ResourceUtil.getImagePath(leftImage);
    }

    public String getCenterImageTitle() {
        return centerImageTitle;
    }

    public String getCenterImagePath() {
        return ResourceUtil.getImagePath(centerImage);
    }

    public String getRightImageTitle() {
        return rightImageTitle;
    }

    public String getRightImagePath() {
        return ResourceUtil.getImagePath(rightImage);
    }

    public String getEmailAddressProfessionalAddressFailedMessage() {
        return emailAddressProfessionalAddressFailedMessage;
    }

    public String getEmailAddressFormatFailedMessage() {
        return emailAddressFormatFailedMessage;
    }

    public String getSubmitButtonLabel() {
        return submitButtonLabel;
    }

    public String getTechErrorTitle() {
        return techErrorTitle;
    }

    public String getTechErrorSubtitle() {
        return techErrorSubtitle;
    }

    public String getUserExistsTitle() {
        return userExistsTitle;
    }

    public String getUserExistsSubtitle() {
        return userExistsSubtitle;
    }

    public String getUserExistsEmailFieldLabel() {
        return userExistsEmailFieldLabel;
    }

    public String getUserExistsContinueButtonLabel() {
        return userExistsContinueButtonLabel;
    }

    public String getRejectedTitle() {
        return rejectedTitle;
    }

    public String getRejectedSubtitle() {
        return rejectedSubtitle;
    }

    public String getRejectedContinueButtonLabel() {
        return rejectedContinueButtonLabel;
    }

    public String getRejectedContinueButtonLink() {
        return LinkUtil.getLink(resource.getResourceResolver(), rejectedContinueButtonLink);
    }

    public String getVfpSuccessTitle() {
        return vfpSuccessTitle;
    }

    public String getVfpSuccessSubtitle() {
        return vfpSuccessSubtitle;
    }

    public String getVfpContinueButtonLabel() {
        return vfpContinueButtonLabel;
    }

    public String getVfpContinueButtonLink() {
        return LinkUtil.getLink(resource.getResourceResolver(), vfpContinueButtonLink);
    }

    public String getUfpTitle() {
        return ufpTitle;
    }

    public String getUfpSubtitle() {
        return ufpSubtitle;
    }

    public String getUfpFirstNameLabel() {
        return ufpFirstNameLabel;
    }

    public String getUfpLastNameLabel() {
        return ufpLastNameLabel;
    }

    public String getUfpEmailLabel() {
        return ufpEmailLabel;
    }

    public String getUfpFirmLabel() {
        return ufpFirmLabel;
    }

    public String getUfpRoleLabel() {
        return ufpRoleLabel;
    }

    public String getUfpCrdNumberLabel() {
        return ufpCrdNumberLabel;
    }

    public String getUfpContinueButtonLabel() {
        return ufpContinueButtonLabel;
    }

    public String getResetPasswordResendButtonLabel() {
        return resetPasswordResendButtonLabel;
    }

    public String getResetPasswordResetTitle() {
        return resetPasswordResetTitle;
    }

    public String getResetPasswordResendSubtitle() {
        return resetPasswordResendSubtitle;
    }

    public String getResetPasswordResendFailedMessage() {
        return resetPasswordResendFailedMessage;
    }

    public String getResetPasswordResendSuccessMessage() {
        return resetPasswordResendSuccessMessage;
    }

    public List<Resource> getUfpRoles() {
        return ufpRoles;
    }

    public String getEmployeeTitle() {
        return employeeTitle;
    }

    public String getEmployeeSubtitle() {
        return employeeSubtitle;
    }

    public String getEmployeeFirstNameLabel() {
        return employeeFirstNameLabel;
    }

    public String getEmployeeLastNameLabel() {
        return employeeLastNameLabel;
    }

    public String getEmployeeEmailLabel() {
        return employeeEmailLabel;
    }

    public String getEmployeeContinueButtonLabel() {
        return employeeContinueButtonLabel;
    }

    public String getEmailPlaceholderText() {
        return emailPlaceholderText;
    }

    public boolean isAllowInvestorUser() {
        return Boolean.TRUE.equals(allowInvestorUser);
    }

    public String getFinancialAdvisorOptionLabel() {
        return financialAdvisorOptionLabel;
    }

    public String getInvestorOptionLabel() {
        return investorOptionLabel;
    }
}
