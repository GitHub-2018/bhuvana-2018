package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.Calendar;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.utils.DateUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointDate {

    @Inject
    private Page resourcePage;

    private Calendar articleDate;

    @PostConstruct
    protected void init() {
        articleDate = ViewpointUtil.getPublicationDate(resourcePage);
    }

    public boolean isFormattedArticleDateBlank() {
        return StringUtils.isBlank(getFormattedArticleDate());
    }

    public boolean isFormattedArticleShortDateBlank() {
        return StringUtils.isBlank(getFormattedArticleShortDate());
    }

    public String getFormattedArticleDate() {
        return DateUtil.getFormattedFullDate(articleDate, resourcePage);
    }

    public String getFormattedArticleShortDate() {
        return DateUtil.getFormattedUsShortDate(articleDate, resourcePage);
    }

    public Calendar getArticleDate() {
        return articleDate;
    }
}
