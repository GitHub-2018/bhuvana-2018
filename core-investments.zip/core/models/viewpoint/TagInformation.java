package com.jhi.aem.website.v1.core.models.viewpoint;

public class TagInformation {
    private final String title;
    private final String path;
    private final Long viewpointsCount;

    TagInformation(String title, String path, Long viewpointsCount) {
        this.title = title;
        this.path = path;
        this.viewpointsCount = viewpointsCount;
    }

    public String getTitle() {
        return title;
    }

    public String getPath() {
        return path;
    }

    public Long getViewpointsCount() {
        return viewpointsCount;
    }
}