package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.generic.link.Link;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointTagsModel {

    public static final ViewpointTagsModel EMPTY = new ViewpointTagsModel();

    @Inject
    @Default
    private String[] viewpointTags;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolver resourceResolver;

    @OSGiService
    private ViewpointsService viewpointsService;

    public Tag getAuthorTag() {
        return getTagString(JhiConstants.PEOPLE_TAG_PREFIX);
    }

    public List<Tag> getAuthorTags() {
        return getTagStrings(JhiConstants.PEOPLE_TAG_PREFIX);
    }

    public Tag getAssetManagerTag() {
        return getTagString(JhiConstants.ASSET_MANAGER_TAG_PREFIX);
    }


    public List<Link> getTopicsTagsLinks() {
        return getTagsLinks(JhiConstants.TOPIC_TAG_PREFIX, ResourcesConstants.VIEWPOINTS_TOPICS_ROOT_PAGE_RESOURCE_TYPE);
    }

    public List<Link> getArticleTagsLinks() {
        return getTagsLinks(JhiConstants.ARTICLE_TAG_PREFIX, ResourcesConstants.VIEWPOINTS_TAG_PAGE_RESOURCE_TYPE);
    }

    private Tag getTagString(String prefix) {
        if (viewpointTags != null) {
            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            for (String tagString : viewpointTags) {
                if (StringUtils.startsWith(tagString, prefix)) {
                    Tag tag = tagManager.resolve(tagString);
                    if (tag != null) {
                        return tag;
                    }
                }
            }
        }
        return null;
    }

    private List<Tag> getTagStrings(String prefix) {
        final List<Tag> result = new ArrayList<>();
        if (viewpointTags != null) {
            TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
            for (String tagString : viewpointTags) {
                if (StringUtils.startsWith(tagString, prefix)) {
                    Tag tag = tagManager.resolve(tagString);
                    if (tag != null) {
                        result.add(tag);
                    }
                }
            }
        }

        return result;
    }

    private List<Link> getTagsLinks(String prefix, String searchRootType) {
        if (ArrayUtils.isEmpty(viewpointTags)) {
            return Collections.emptyList();
        }
        String searchPath = ViewpointUtil.getViewpointsPageByType(resourcePage, searchRootType);
        List<Link> tagsLinks = new ArrayList<>(viewpointTags.length);
        TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
        for (String tagString : viewpointTags) {
            if (StringUtils.startsWith(tagString, prefix)) {
                Tag tag = tagManager.resolve(tagString);
                if (tag != null) {
                    String link;
                    if (StringUtils.equals(searchRootType, ResourcesConstants
                            .VIEWPOINTS_TAG_PAGE_RESOURCE_TYPE)) {
                        link = getTagLink(searchPath, tag);
                    } else {
                        link = getPageLink(searchPath, tag);
                    }
                    tagsLinks.add(new Link(link, tag.getTitle()));
                }
            }
        }
        Collections.sort(tagsLinks);
        return tagsLinks;
    }

    private String getTagLink(String searchPath, Tag tag) {
        return ViewpointUtil.getTagListingPageLink(searchPath, tag);
    }

    private String getPageLink(String searchPath, Tag tag) {
        return LinkUtil.getPageLink(viewpointsService.getTaggedViewpoint(resourceResolver, searchPath, tag));
    }

    public static ViewpointTagsModel fromPage(Page page) {
        if (page != null) {
            Resource contentResource = page.getContentResource();
            if (contentResource != null) {
                ViewpointTagsModel viewpointTagsModel = contentResource.adaptTo(ViewpointTagsModel.class);
                if (viewpointTagsModel != null) {
                    return viewpointTagsModel;
                }
            }
        }
        return EMPTY;
    }
}
