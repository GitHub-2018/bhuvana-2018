package com.jhi.aem.website.v1.core.models.viewpoint;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.injectors.qualifiers.TargetResourceTypes;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

@Model(adaptables = Resource.class, adapters = ViewpointDetailModel.class)
@TargetResourceTypes(ResourcesConstants.VIEWPOINT_ARTICLE_PAGE_RESOURCE_TYPE)
public class ViewpointArticleDetailModel extends ViewpointDetailModel {

    @Inject
    @Optional
    private ImageProcessingModel summaryItem;

	@Override
	public ImageProcessingModel getImageProcessingModel() {
		return summaryItem;
	}

	@Override
    public String getImagePath() {
        return ImageProcessingModel.getRenditionPath(summaryItem);
    }

    @Override
    public String getType() {
        return "Viewpoint";
    }

    @Override
    public String getMoreLabel() {
        return "Read more";
    }

    @Override
    public boolean isTypeArticle() {
        return true;
    }

    @Override
    public boolean isSummaryItemNotBlank() {
        return StringUtils.isNotBlank(ImageModel.getImagePath(summaryItem));
    }

	@Override
	public String getViewpointType() {
		return "article";
	}

}
