package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.Calendar;

import com.jhi.aem.website.v1.core.models.assetmanager.AssetManagerModel;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.person.PersonalBiographyDetails;

public class ViewpointAuthor extends PersonalBiographyDetails {
	private final PersonalBiographyDetails personalBiographyDetails;
	private final String pagePath;

	public ViewpointAuthor(PersonalBiographyDetails personalBiographyDetails, String pagePath) {
		this.personalBiographyDetails = personalBiographyDetails;
		this.pagePath = pagePath;
	}

	public boolean equals(Object obj) {
		return personalBiographyDetails.equals(obj);
	}

	public int hashCode() {
		return personalBiographyDetails.hashCode();
	}

	public String getName() {
		return personalBiographyDetails.getName();
	}

	public String getPosition() {
		return personalBiographyDetails.getPosition();
	}

	public Calendar getCareerStartDate() {
		return personalBiographyDetails.getCareerStartDate();
	}

	public String getCareerStartDateFormatted() {
		return personalBiographyDetails.getCareerStartDateFormatted();
	}

	public ImageModel getImage() {
		return personalBiographyDetails.getImage();
	}

	public String getBiography() {
		return personalBiographyDetails.getBiography();
	}

	public int getYearsOfExperience() {
		return personalBiographyDetails.getYearsOfExperience();
	}

	public AssetManagerModel getAssetManager() {
		return personalBiographyDetails.getAssetManager();
	}

	public int compareTo(PersonalBiographyDetails other) {
		return personalBiographyDetails.compareTo(other);
	}

	public String toString() {
		return personalBiographyDetails.toString();
	}

	public String getPagePath() {
		return pagePath;
	}

}
