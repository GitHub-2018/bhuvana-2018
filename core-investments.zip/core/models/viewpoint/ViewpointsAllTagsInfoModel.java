package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.PathPredicateEvaluator;
import com.day.cq.search.eval.TypePredicateEvaluator;
import com.day.cq.search.facets.Bucket;
import com.day.cq.search.facets.Facet;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointsAllTagsInfoModel {

    private static Logger LOGGER = LoggerFactory.getLogger(ViewpointsAllTagsInfoModel.class);

    @Inject
    private QueryBuilder queryBuilder;

    @Inject
    private ResourceResolver resourceResolver;

    @Inject
    private PageManager pageManager;

    @Inject
    private Page resourcePage;

    @OSGiService
    private ViewpointsService viewpointsService;

    public Set<TagInformation> getTagsInfo() {
        Page viewpointsRoot = ViewpointUtil.getViewpointsMainPage(resourcePage);
        if (viewpointsRoot != null) {
            String rootPath = viewpointsRoot.getPath();
            Map<String, String> searchParams = new HashMap<>();
            searchParams.put(PathPredicateEvaluator.PATH, rootPath);
            searchParams.put(TypePredicateEvaluator.TYPE, NameConstants.NT_PAGE);
            searchParams.put(JcrPropertyPredicateEvaluator.PROPERTY, JhiConstants.PAGE_CONTENT_VIEWPOINTS_TAGS_PROPERTY);
            searchParams.put("p.facets", "true");
            searchParams.put("p.limit", "1"); // Don't need any results but this doesn't obey 0

            Query query = queryBuilder.createQuery(PredicateGroup.create(searchParams), resourceResolver.adaptTo(Session.class));
            Set<TagInformation> tagInfoSet = new TreeSet<>(Comparator.comparing(TagInformation::getTitle));

            SearchResult result = query.getResult();
            try {
                Map<String, Facet> facets = result.getFacets();
                for (Entry<String, Facet> facet : facets.entrySet()) {
                    Facet tagFacet = facet.getValue();
                    if (tagFacet.getContainsHit()) {
                        for (Bucket bucket : tagFacet.getBuckets()) {
                            Map<String, String> facetParams = bucket.getPredicate().getParameters();
                            String facetTagPath = bucket.getValue();
                            if (StringUtils.equals(facetParams.get(JcrPropertyPredicateEvaluator.PROPERTY), JhiConstants
                                    .PAGE_CONTENT_VIEWPOINTS_TAGS_PROPERTY)) {
                                Page page = pageManager.getPage(facetTagPath);
                                if (page != null && page.isValid()) {
                                    tagInfoSet.add(new TagInformation(PageUtil.getPageNavigationTitle(page), LinkUtil.getPageLink(page),
                                            bucket.getCount()));
                                }
                            }
                        }
                    }
                }
            } catch (RepositoryException e) {
                LOGGER.error("Could not get facets from query", e);
            }
            return tagInfoSet;
        }
        return Collections.emptySet();
    }
}
