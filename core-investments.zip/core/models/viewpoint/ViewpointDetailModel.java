package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.Calendar;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;
import com.jhi.aem.website.v1.core.models.viewpoint_author.ViewpointAuthorsModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

public abstract class ViewpointDetailModel implements Comparable<ViewpointDetailModel> {

    public static final String VIEWPOINT_ID_PROPERTY = "viewpointId";
    public static final String SUMMARY_ITEM_PATH = "summaryItem";

    @Inject
    @Default
    @Named("title/jcr:title")
    private String title;

    @Inject
    @Default
    @Named("summary/text")
    private String summary;

    @Inject
    private Resource resource;

    @Inject
    private Page resourcePage;

    private String description;

    private String previewText;

    private Calendar publicationDate;

    private ViewpointAuthorsModel viewpointAuthors;

    private String path;

    private int analyticsIndex;

    @PostConstruct
    protected void init() {
        viewpointAuthors = ViewpointAuthorsModel.fromPage(resourcePage);
        path = resourcePage.getPath();
        if (StringUtils.isBlank(title)) {
            title = PageUtil.getPageNavigationTitle(resourcePage);
        }
        
        if (resourcePage != null) {
        	description = resourcePage.getDescription();
        	previewText = (String)resourcePage.getProperties().get("previewText");
        }
    }

    public String getTitle() {
        return title;
    }

    public String getSummary() {
        return summary;
    }

    public ViewpointAuthorsModel getAuthors() {
        return viewpointAuthors;
    }

    public boolean isAuthorBlank() {
        return viewpointAuthors == null || viewpointAuthors.isBlank();
    }

    public Calendar getPublicationDate() {
        if (publicationDate == null) {
            ViewpointDate dateModel = resource.adaptTo(ViewpointDate.class);
            if (dateModel != null) {
                publicationDate = dateModel.getArticleDate();
            } else {
                publicationDate = Calendar.getInstance(Locale.US);
            }
        }
        return publicationDate;
    }

    public boolean isPublicationDateStringBlank() {
        ViewpointDate dateModel = resource.adaptTo(ViewpointDate.class);
        if (dateModel != null) {
            return dateModel.isFormattedArticleDateBlank();
        }
        return true;
    }

    public boolean isPublicationShortDateStringBlank() {
        ViewpointDate dateModel = resource.adaptTo(ViewpointDate.class);
        if (dateModel != null) {
            return dateModel.isFormattedArticleShortDateBlank();
        }
        return true;
    }

    public String getPublicationDateString() {
        ViewpointDate dateModel = resource.adaptTo(ViewpointDate.class);
        if (dateModel != null) {
            return dateModel.getFormattedArticleDate();
        }
        return StringUtils.EMPTY;
    }

    public String getPublicationShortDateString() {
        ViewpointDate dateModel = resource.adaptTo(ViewpointDate.class);
        if (dateModel != null) {
            return dateModel.getFormattedArticleShortDate();
        }
        return StringUtils.EMPTY;
    }

    public String getPagePath() {
        return resourcePage.getPath();
    }

    public String getPageLink() {
        return LinkUtil.getLink(resourcePage.getPath());
    }

    public static ViewpointDetailModel fromPage(Page page) {
        if (page != null) {
            Resource contentResource = page.getContentResource();
            if (contentResource != null) {
                return contentResource.adaptTo(ViewpointDetailModel.class);
            }
        }
        return null;
    }

    public boolean isValid() {
        return resource != null && StringUtils.isNotBlank(summary) && isSummaryItemNotBlank();
    }

    public abstract ImageProcessingModel getImageProcessingModel();

    public abstract String getImagePath();

    public abstract String getType();

    public abstract String getMoreLabel();

    public boolean isSummaryVisible() {
        return true;
    }

    public boolean isImageVisible() {
        return true;
    }

    public boolean isTypeVideo() {
        return false;
    }

    public boolean isTypeDocument() {
        return false;
    }

    public boolean isTypeAudio() {
        return false;
    }

    public boolean isTypeArticle() {
        return false;
    }

    public boolean isSummaryItemNotBlank() {
        return false;
    }

    public String getPath() {
        return path;
    }

    @Override
    public int compareTo(ViewpointDetailModel other) {
        return other.getPublicationDate().compareTo(getPublicationDate());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(this.getClass().isAssignableFrom(obj.getClass()))) {
            return false;
        }

        ViewpointDetailModel other = (ViewpointDetailModel) obj;
        return new EqualsBuilder().append(getPath(), other.getPath()).isEquals();
    }

    public String getId() {
        if (resource != null) {
            ValueMap properties = resource.getValueMap();
            if (properties.containsKey(VIEWPOINT_ID_PROPERTY)) {
                return properties.get(VIEWPOINT_ID_PROPERTY, String.class);
            }
        }
        return StringUtils.EMPTY;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(getPath()).toHashCode();
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

    public int getAnalyticsIndex() {
        return analyticsIndex;
    }

    public void setAnalyticsIndex(int analyticsIndex) {
        this.analyticsIndex = analyticsIndex;
    }

	public String getDescription() {
		return StringUtils.defaultIfBlank(description, summary);
	}

	public String getPreviewText() {
		return StringUtils.defaultIfBlank(previewText, summary);
	}
	
	public abstract String getViewpointType();

}
