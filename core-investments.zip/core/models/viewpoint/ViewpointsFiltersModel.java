package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.List;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.generic.link.SimpleLink;
import com.jhi.aem.website.v1.core.models.viewpoint_asset_manager.ViewpointsAssetManagerModel;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ViewpointsFiltersModel {

    @Inject
    @Via("resource")
    @Default
    private String title;

    @Inject
    @Via("resource")
    @Default
    private String text;

    @Inject
    private Page currentPage;


    @OSGiService
    private ViewpointsService viewpointsService;

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public List<SimpleLink> getAuthors() {
        return viewpointsService.getAuthors(currentPage);
    }

    public List<ViewpointsAssetManagerModel> getAssetManagers() {
        return viewpointsService.getAssetManagers(currentPage);
    }

    public List<SimpleLink> getTopics() {
        return viewpointsService.getTopics(currentPage);
    }

    public boolean isAuthorsVisible() {
        return !PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_AUTHOR_PAGE_RESOURCE_TYPE);
    }

    public boolean isAssetManagersVisible() {
        return !PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_ASSET_MANAGER_PAGE_RESOURCE_TYPE);
    }

    public boolean isTopicsVisible() {
        return !PageUtil.isResourceType(currentPage, ResourcesConstants.VIEWPOINTS_TOPIC_PAGE_RESOURCE_TYPE);
    }
}
