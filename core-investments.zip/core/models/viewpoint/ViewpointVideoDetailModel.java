package com.jhi.aem.website.v1.core.models.viewpoint;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.injectors.qualifiers.TargetResourceTypes;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;
import com.jhi.aem.website.v1.core.models.video.BrightcoveVideoModel;
import com.jhi.aem.website.v1.core.service.video.BrightcoveService;

@Model(adaptables = Resource.class, adapters = ViewpointDetailModel.class)
@TargetResourceTypes(ResourcesConstants.VIEWPOINT_VIDEO_PAGE_RESOURCE_TYPE)
public class ViewpointVideoDetailModel extends ViewpointDetailModel {

    @Inject
    @Optional
    private BrightcoveVideoModel summaryItem;

    @OSGiService
    private BrightcoveService brightcoveService;

	@Override
	public ImageProcessingModel getImageProcessingModel() {
		return ImageProcessingModel.EMPTY_MODEL;
	}

	@Override
    public String getImagePath() {
		// Use the supplied thumbnail if it exists
		String imagePath = summaryItem.getRenditionPath();
		if (StringUtils.isNotBlank(imagePath)) {
			return imagePath;
		}

		if (brightcoveService == null) {
            return StringUtils.EMPTY;
        }
        return brightcoveService.getVideoImage(summaryItem.getAccount(), summaryItem.getVideoPlayer());
    }

    @Override
    public boolean isTypeVideo() {
        return true;
    }

    @Override
    public String getType() {
        return "Video";
    }

    @Override
    public String getMoreLabel() {
        return "Watch video";
    }

    @Override
    public boolean isSummaryVisible() {
        return false;
    }

    @Override
    public boolean isSummaryItemNotBlank() {
        return summaryItem != null && !summaryItem.isBlank();
    }
    
	@Override
	public String getViewpointType() {
		return "video";
	}

}
