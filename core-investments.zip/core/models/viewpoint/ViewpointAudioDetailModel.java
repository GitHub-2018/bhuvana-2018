package com.jhi.aem.website.v1.core.models.viewpoint;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.injectors.qualifiers.TargetResourceTypes;
import com.jhi.aem.website.v1.core.models.audio.AudioModel;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

import javax.inject.Inject;

@Model(adaptables = Resource.class, adapters = ViewpointDetailModel.class)
@TargetResourceTypes(ResourcesConstants.VIEWPOINT_AUDIO_PAGE_RESOURCE_TYPE)
public class ViewpointAudioDetailModel extends ViewpointDetailModel {

    @Inject
    @Optional
    private AudioModel summaryItem;

	@Override
	public ImageProcessingModel getImageProcessingModel() {
		return ImageProcessingModel.EMPTY_MODEL;
	}

    @Override
    public String getImagePath() {
        return summaryItem.getImagePath();
    }

    @Override
    public String getType() {
        return summaryItem.getAudioType();
    }

    @Override
    public String getMoreLabel() {
        return "Listen";
    }

    public boolean isTypeAudio() {
    	return true;
    }

    @Override
    public boolean isSummaryItemNotBlank() {
        return summaryItem != null && summaryItem.isValid();
    }
    
	@Override
	public String getViewpointType() {
		return "audio";
	}

}
