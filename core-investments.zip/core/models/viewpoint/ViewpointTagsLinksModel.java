package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.generic.link.Link;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointTagsLinksModel {

    @Inject
    private Page resourcePage;

    @Inject
    private PageManager pageManager;

    private List<Link> topicsLinks;
    private List<Link> tagsLinks;

    @PostConstruct
    protected void init() {
        Page topicPage = ViewpointUtil.getTopicPage(resourcePage);
        if (topicPage != null && topicPage.isValid()) {
            topicsLinks = new ArrayList<>(1);
            topicsLinks.add(new Link(LinkUtil.getPageLink(topicPage), PageUtil.getPageNavigationTitle(topicPage)));
        }
        String[] tagsPaths = PageUtil.getPageContentProperty(resourcePage, JhiConstants.VIEWPOINTS_TAGS_PROPERTY, String[].class);
        if (tagsPaths != null) {
            tagsLinks = new ArrayList<>(tagsPaths.length);
            for (String tagPath : tagsPaths) {
                Page tagPage = pageManager.getPage(tagPath);
                if (tagPage != null && tagPage.isValid()) {
                    tagsLinks.add(new Link(LinkUtil.getPageLink(tagPage), PageUtil.getPageNavigationTitle(tagPage)));
                }
            }
        }
    }

    public List<Link> getTopicsLinks() {
        return topicsLinks;
    }

    public boolean isTopicsNotEmpty() {
        return topicsLinks != null && !topicsLinks.isEmpty();
    }

    public List<Link> getTagsLinks() {
        return tagsLinks;
    }

    public boolean isTagsNotEmpty() {
        return tagsLinks != null && !tagsLinks.isEmpty();
    }
}
