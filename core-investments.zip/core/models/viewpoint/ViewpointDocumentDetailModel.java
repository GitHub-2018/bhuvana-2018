package com.jhi.aem.website.v1.core.models.viewpoint;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.injectors.qualifiers.TargetResourceTypes;
import com.jhi.aem.website.v1.core.models.document.ProductDocumentModel;
import com.jhi.aem.website.v1.core.models.image.ImageProcessingModel;

@Model(adaptables = Resource.class, adapters = ViewpointDetailModel.class)
@TargetResourceTypes(ResourcesConstants.VIEWPOINT_DOCUMENT_PAGE_RESOURCE_TYPE)
public class ViewpointDocumentDetailModel extends ViewpointDetailModel {

    @Inject
    @Optional
    private ProductDocumentModel summaryItem;

    @Override
    public ImageProcessingModel getImageProcessingModel() {
        return ImageProcessingModel.EMPTY_MODEL;
    }

    @Override
    public String getImagePath() {
        return summaryItem.getThumbnailPath();
    }

    @Override
    public String getType() {
        return summaryItem.getType();
    }

    @Override
    public String getMoreLabel() {
        return "Download " + getType();
    }

    public String getDownloadPath() {
        return summaryItem.getPath();
    }

    public String getDocumentType() {
        return summaryItem.getType();
    }

    public String getDocumentSize() {
        return summaryItem.getDisplaySize();
    }

    @Override
    public boolean isImageVisible() {
        return false;
    }

    @Override
    public boolean isTypeDocument() {
        return true;
    }

    @Override
    public boolean isSummaryItemNotBlank() {
        return summaryItem != null && !summaryItem.isBlank();
    }

    @Override
    public String getViewpointType() {
        return "document";
    }

}
