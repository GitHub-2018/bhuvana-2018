package com.jhi.aem.website.v1.core.models.viewpoint;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.PageManager;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RelatedViewpointsModel {

    @Inject
    @Default
    private Boolean hideTitle;

    @Inject
    @Default
    private String first;

    @Inject
    @Default
    private String second;

    @Inject
    @Default
    private String third;

    @Inject
    @Default
    private String fourth;

    @Inject
    private PageManager pageManager;

    private List<ViewpointDetailModel> viewpoints;

    @PostConstruct
    protected void init() {
        viewpoints = new ArrayList<>(2);
        ViewpointDetailModel firstModel = ViewpointDetailModel.fromPage(pageManager.getPage(first));
        ViewpointDetailModel secondModel = ViewpointDetailModel.fromPage(pageManager.getPage(second));
        ViewpointDetailModel thirdModel = ViewpointDetailModel.fromPage(pageManager.getPage(third));
        ViewpointDetailModel fourthModel = ViewpointDetailModel.fromPage(pageManager.getPage(fourth));
        if (firstModel != null && firstModel.isValid()) {
            viewpoints.add(firstModel);
        }
        if (secondModel != null && secondModel.isValid()) {
            viewpoints.add(secondModel);
        }
        if (thirdModel != null && thirdModel.isValid()) {
            viewpoints.add(thirdModel);
        }
        if (fourthModel != null && fourthModel.isValid()) {
            viewpoints.add(fourthModel);
        }
    }

    public List<ViewpointDetailModel> getViewpoints() {
        return viewpoints;
    }

    public boolean isValid() {
        return viewpoints != null && !viewpoints.isEmpty();
    }

	public boolean getHideTitle() {
		return BooleanUtils.isTrue(hideTitle);
	}
}
