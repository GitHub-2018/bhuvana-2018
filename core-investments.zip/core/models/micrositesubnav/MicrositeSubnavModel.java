package com.jhi.aem.website.v1.core.models.micrositesubnav;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.micrositesubnavmarker.MicrositeSubnavMarkerModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MicrositeSubnavModel {

    private static final String PARSYS_PATH = "mainParagraph";

    private static final String FUND_LISTING_PATH = "fundlisting";
    private static final String ASSET_MANAGERS_PATH = "assetmanagers";
    private static final String CALL_TO_ACTION_PATH = "cta";

    private static final String SUBNAV_SUFFIX = "/subnav";

    @Inject
    private Page resourcePage;

    private List<MicrositeSubnavMarkerModel> items = new ArrayList<>();

    @PostConstruct
    private void init() {
        final Resource contentResource = resourcePage.getContentResource();
        if (contentResource == null) {
            return;
        }

        final Resource parsysResource = contentResource.getChild(PARSYS_PATH);
        if (parsysResource == null) {
            return;
        }

        // parsys
        Iterator<Resource> childrenIterator = parsysResource.listChildren();
        while (childrenIterator.hasNext()) {
            final Resource childResource = childrenIterator.next();
            if (childResource.isResourceType(ResourcesConstants.SUBNAV_MARKER_RESOURCE_TYPE)) {
                final MicrositeSubnavMarkerModel markerModel = childResource.adaptTo(MicrositeSubnavMarkerModel.class);
                if (markerModel.isValid()) {
                    items.add(markerModel);
                }
            }
        }

        // fixed components
        addSubnavItem(contentResource, FUND_LISTING_PATH);
        addSubnavItem(contentResource, ASSET_MANAGERS_PATH);
        addSubnavItem(contentResource, CALL_TO_ACTION_PATH);
    }

    private void addSubnavItem(Resource contentResource, String childPath) {
        final Resource childResource = contentResource.getChild(childPath + SUBNAV_SUFFIX);
        if (childResource == null) {
            return;
        }

        final MicrositeSubnavMarkerModel markerModel = childResource.adaptTo(MicrositeSubnavMarkerModel.class);
        if (markerModel.isValid() && markerModel.getEnabled()) {
            items.add(markerModel);
        }
    }

    public List<MicrositeSubnavMarkerModel> getItems() {
        return items;
    }

    public boolean isBlank() {
        return items.isEmpty();
    }
}
