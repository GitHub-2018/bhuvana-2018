package com.jhi.aem.website.v1.core.models.thankyou;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ThankYouSectionModel {

    @Inject
    private String title;

    @Inject
    private String subtitle;

    @Inject
    private String dashboardText;

    @Inject
    private String dashboardButtonLabel;

    @Inject
    private String dashboardButtonLink;

    @Inject
    private String investmentsText;

    @Inject
    private String investmentsButtonLabel;

    @Inject
    private String investmentsButtonLink;

    @Inject
    private String insightsText;

    @Inject
    private String insightsButtonLabel;

    @Inject
    private String insightsButtonLink;

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getDashboardText() {
        return dashboardText;
    }

    public String getDashboardButtonLabel() {
        return dashboardButtonLabel;
    }

    public String getDashboardButtonLink() {
        return LinkUtil.getLink(dashboardButtonLink);
    }

    public String getInvestmentsText() {
        return investmentsText;
    }

    public String getInvestmentsButtonLabel() {
        return investmentsButtonLabel;
    }

    public String getInvestmentsButtonLink() {
        return LinkUtil.getLink(investmentsButtonLink);
    }

    public String getInsightsText() {
        return insightsText;
    }

    public String getInsightsButtonLabel() {
        return insightsButtonLabel;
    }

    public String getInsightsButtonLink() {
        return LinkUtil.getLink(insightsButtonLink);
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(subtitle) && StringUtils.isBlank(dashboardText)
                && StringUtils.isBlank(dashboardButtonLabel) && StringUtils.isBlank(dashboardButtonLink)
                && StringUtils.isBlank(investmentsText) && StringUtils.isBlank(investmentsButtonLabel)
                && StringUtils.isBlank(investmentsButtonLink) && StringUtils.isBlank(insightsText)
                && StringUtils.isBlank(insightsButtonLabel) && StringUtils.isBlank(insightsButtonLink);
    }
}
