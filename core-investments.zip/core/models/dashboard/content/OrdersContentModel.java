package com.jhi.aem.website.v1.core.models.dashboard.content;

import java.util.ArrayList;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingException;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.commerce.api.Product;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdCartEntry;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdCommerceSessionImpl;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdException;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdPlacedOrder;
import com.jhi.aem.website.v1.core.commerce.rrd.models.CheckOrderStatusResponse;
import com.jhi.aem.website.v1.core.commerce.rrd.models.OrdersStatus;
import com.jhi.aem.website.v1.core.commerce.rrd.service.rrd.RrdService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class OrdersContentModel extends AbstractPaginationModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrdersContentModel.class);
    private static final int MAX_ORDERS = 5;
    protected static final String PAGINATION_HTML = ".pagination.html/";

    @Inject
    @Optional
    @Via("resource")
    private String ordersLabel;

    @Inject
    @Optional
    @Via("resource")
    private String noOrdersLabel;

    @Inject
    @Optional
    @Via("resource")
    private String reorderLabel;

    @Inject
    @Optional
    @Via("resource")
    private String shippedToLabel;

    @Inject
    @Optional
    @Via("resource")
    private String shippedDateLabel;

    @Inject
    @Optional
    @Via("resource")
    private String orderIdLabel;

    @Inject
    @Optional
    @Via("resource")
    private String trackingLabel;

    @Inject
    @Optional
    @Via("resource")
    private String statusLabel;

    @Self
    private SlingHttpServletRequest request;

    @SlingObject
    private SlingHttpServletResponse response;

    @OSGiService
    private UserProfileService userProfileService;

    @OSGiService
    private RrdService rrdService;

    private List<RrdPlacedOrder> orders = new ArrayList<>();

    @PostConstruct
    private void init() {
        try {
            setPageNumber(request);
            setOffset(MAX_ORDERS);
            final List<RrdPlacedOrder> openOrders = userProfileService.getOrders(request, response);
            setOrders(openOrders);
            setPagination(request, openOrders.size(), MAX_ORDERS, PAGINATION_HTML);
        } catch (RrdException e) {
            LOGGER.error("Error reading orders", e);
        }
    }

    private void setOrders(List<RrdPlacedOrder> openOrders) throws RrdException {
        if (!openOrders.isEmpty()) {
            for (RrdPlacedOrder order : openOrders.subList(getStartPosition(getOffset()), getEndPosition(openOrders))) {
                if (order == null || order.getOrderResource() == null || order.isClosed()) {
                    LOGGER.debug("Order is null or closed. No need to update it. {}", order);
                } else {
                    final CheckOrderStatusResponse orderStatusResponse = rrdService.checkOrderStatus(order.getOrderId());
                    updateOrderStatus(order, orderStatusResponse);
                }
                orders.add(order);
            }
        }
    }

    private int getEndPosition(List<RrdPlacedOrder> openOrders) {
        return Math.min(MAX_ORDERS * getPageNumber(), openOrders.size());
    }

    private void updateOrderStatus(RrdPlacedOrder order, CheckOrderStatusResponse statusResponse) {
        final String rrdStatus = statusResponse.getProcessedOrderStatus();
        if (RrdCommerceSessionImpl.ORDER_CLOSED.equals(rrdStatus)) {
            updateClosedOrder(order, statusResponse);
        } else {
            updateOpenOrders(order, statusResponse);
        }
    }

    private void updateOpenOrders(RrdPlacedOrder order, CheckOrderStatusResponse statusResponse) {
        for (CommerceSession.CartEntry cartEntry : order.getCartEntries()) {
            RrdCartEntry rrdCartEntry = (RrdCartEntry) cartEntry;
            if (rrdCartEntry != null) {
                if (statusResponse.getOrdersInfo() != null) {
                    for (OrdersStatus status : statusResponse.getOrdersInfo().getOrdersStatus()) {
                        String productCode = StringUtils.EMPTY;
                        Product product = null;
                        try {
                            product = rrdCartEntry.getProduct();
                        } catch (CommerceException e) {
                            LOGGER.error("Problem with product", e);
                        }
                        if (product != null) {
                            productCode = product.getSKU();
                        }
                        if (StringUtils.isNotBlank(productCode)) {
                            if (status != null && StringUtils.equals(status.getCustomerItemNumber(), productCode)) {
                                rrdCartEntry.setStatus(StringUtils.capitalize(StringUtils.lowerCase(status.getOrderLineStatusCode())));
                                rrdCartEntry.setShipmentDetails(status.getShipmentDetailsList());
                            }
                        }
                    }
                }
            }
        }
    }

    private void updateClosedOrder(RrdPlacedOrder order, CheckOrderStatusResponse statusResponse) {
        try {
            ModifiableValueMap values = order.getOrderResource().adaptTo(ModifiableValueMap.class);
            if (values != null) {
                if (values.containsKey(RrdCommerceSessionImpl.CART_ITEMS_PROPERTY)) {
                    String[] orderedItems = values.get(RrdCommerceSessionImpl.CART_ITEMS_PROPERTY, ArrayUtils.EMPTY_STRING_ARRAY);
                    String[] shipmentStatuses = new String[orderedItems.length];
                    int i = 0;
                    for (final String orderedItem : orderedItems) {
                        String[] itemParts = StringUtils.split(orderedItem, RrdCommerceSessionImpl.ITEM_ENTRY_SEPARATOR);
                        if (itemParts.length > 0) {
                            String itemCode = itemParts[0];
                            if (statusResponse.getOrdersInfo() != null) {
                                for (OrdersStatus status : statusResponse.getOrdersInfo().getOrdersStatus()) {
                                    if (status != null && StringUtils.equals(status.getCustomerItemNumber(), itemCode)) {
                                        shipmentStatuses[i++] = orderedItem + RrdCommerceSessionImpl.ORDER_STATUS_SEPARATOR
                                                + status.getShipmentStatus();
                                    }
                                }
                            }
                        }
                    }
                    values.put(RrdCommerceSessionImpl.ORDER_STATUS_PROPERTY, RrdCommerceSessionImpl.ORDER_CLOSED);
                    values.put(RrdCommerceSessionImpl.CART_ITEMS_PROPERTY, shipmentStatuses);
                }
                request.getResourceResolver().commit();
            }

        } catch (PersistenceException | SlingException e) {
            LOGGER.error("Error updating order status", e);
        }
    }

    public String getOrdersLabel() {
        return ordersLabel;
    }

    public String getNoOrdersLabel() {
        return noOrdersLabel;
    }

    public String getReorderLabel() {
        return reorderLabel;
    }

    public String getShippedToLabel() {
        return shippedToLabel;
    }

    public String getShippedDateLabel() {
        return shippedDateLabel;
    }

    public String getOrderIdLabel() {
        return orderIdLabel;
    }

    public String getTrackingLabel() {
        return trackingLabel;
    }

    public List<RrdPlacedOrder> getOrders() {
        return orders;
    }

    public String getStatusLabel() {
        return statusLabel;
    }

}
