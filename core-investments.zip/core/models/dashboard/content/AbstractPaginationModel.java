package com.jhi.aem.website.v1.core.models.dashboard.content;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.generic.link.Link;
import com.jhi.aem.website.v1.core.generic.pagination.Pagination;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;

public abstract class AbstractPaginationModel {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractPaginationModel.class);

    private Pagination pagination;
    private int pageNumber;
    private int offset;

    public Pagination getPagination() {
        return pagination;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public int getOffset() {
        return offset;
    }

    protected void setOffset(int pageSize) {
        offset = (pageNumber - 1) * pageSize;
    }

    protected int getEndPosition(List<ViewpointDetailModel> results, int pageSize) {
        return Math.min(pageSize * pageNumber, results.size() - 1);
    }

    protected int getStartPosition(int offset) {
        return Math.max(0, offset);
    }

    protected void setPageNumber(SlingHttpServletRequest request) {
        pageNumber = java.util.Optional.ofNullable(request.getRequestPathInfo().getSuffix())
                .map(suffix -> suffix.replaceAll(JhiConstants.SLASH, StringUtils.EMPTY))
                .map(Pagination::getPageNumber)
                .orElse((1));
        LOG.debug("Page number: {}", pageNumber);
    }

    protected void setPagination(SlingHttpServletRequest request, int total, int pageSize, String htmlPath) {
        int pages = (total / pageSize) + (total % pageSize > 0 ? 1 : 0);
        pagination = new Pagination(pageNumber, pageSize, pages, total);

        String path = request.getResource().getPath() + htmlPath;
        for (int i = 1; i <= pagination.getTotalPages(); i++) {
            pagination.addLink(new Link(path + i, String.valueOf(i), i == pageNumber));
        }
    }
}
