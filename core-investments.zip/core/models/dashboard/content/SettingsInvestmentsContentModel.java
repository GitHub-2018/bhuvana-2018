package com.jhi.aem.website.v1.core.models.dashboard.content;

import java.util.Collections;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.dashboard.Dashboard;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardService;
import com.jhi.aem.website.v1.core.service.dashboard.Fund;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SettingsInvestmentsContentModel {

    @OSGiService
    private DashboardService userProfileService;

    @Inject
    private Page resourcePage;

    public List<Fund> getFunds() {
        return Optional.ofNullable(userProfileService.getDashboard(resourcePage))
                .map(Dashboard::getFunds)
                .orElse(Collections.emptyList());
    }
}
