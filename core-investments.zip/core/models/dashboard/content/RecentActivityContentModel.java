package com.jhi.aem.website.v1.core.models.dashboard.content;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.models.user.ActivityModel;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

import java.util.List;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RecentActivityContentModel {

    @Self
    private SlingHttpServletRequest request;

    @OSGiService
    private UserProfileService userProfileService;

    private List<ActivityModel> recentActivity;

    public List<ActivityModel> getRecentActivity() {
        if (recentActivity == null) {
            recentActivity = userProfileService.getRecentActivity(request.getResourceResolver());
        }
        return recentActivity;
    }
}
