package com.jhi.aem.website.v1.core.models.dashboard.content;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.dashboard.tabs.YourReportsTabModel;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardService;
import com.jhi.aem.website.v1.core.service.dashboard.Fund;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class YourReportsContentModel {

    @Inject
    private Page currentPage;

    @SlingObject
    private SlingHttpServletRequest request;

    @OSGiService
    private DashboardService dashboardService;

    private String reportNameLabel;
    private String reportDateLabel;
    private List<Fund> funds;

    @PostConstruct
    public void init() {
        Optional.ofNullable(request.adaptTo(YourReportsTabModel.class))
                .ifPresent(model -> {
                    reportNameLabel = model.getReportNameLabel();
                    reportDateLabel = model.getReportDateLabel();
                });
        funds = dashboardService.getDashboardFunds(currentPage).stream()
                .filter(fund -> !fund.getReports().isEmpty())
                .sorted(Comparator.comparing(Fund::getDisplayName))
                .collect(Collectors.toList());
    }

    public List<Fund> getFunds() {
        return funds;
    }

    public String getReportNameLabel() {
        return reportNameLabel;
    }

    public String getReportDateLabel() {
        return reportDateLabel;
    }
}
