package com.jhi.aem.website.v1.core.models.dashboard.content;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.user.AddressModel;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.servlets.user.AddressUpdateServlet;

import java.util.Collections;
import java.util.List;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SettingsAddressesContentModel {

    private static final String ADDRESS_SELECTOR_PART = JhiConstants.DOT + AddressUpdateServlet.ADDRESS_SELECTOR
            + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;

    @Self
    private Resource resource;

    @OSGiService
    private UserProfileService userProfileService;

    public List<AddressModel> getAddresses() {
        if (userProfileService != null) {
            return userProfileService.getAddresses(resource.getResourceResolver());
        }
        return Collections.emptyList();
    }

    public String getEditAddressPath() {
        return resource.getResourceResolver().map(resource.getPath()) + ADDRESS_SELECTOR_PART;
    }
}
