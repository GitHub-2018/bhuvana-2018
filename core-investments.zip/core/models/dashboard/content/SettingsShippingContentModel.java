package com.jhi.aem.website.v1.core.models.dashboard.content;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.jhi.aem.website.v1.core.models.user.ShippingModel;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SettingsShippingContentModel {

    @Inject
    private String settingsShippingEmailLabel;

    @Inject
    private ResourceResolver resolver;

    @OSGiService
    private UserProfileService userProfileService;

    private ShippingModel shipping;

    @PostConstruct
    private void init() {
        shipping = userProfileService.getShipping(resolver);
    }

    public String getEmailLabel() {
        return settingsShippingEmailLabel;
    }

    public String getEmail() {
        return shipping.getEmail();
    }
}
