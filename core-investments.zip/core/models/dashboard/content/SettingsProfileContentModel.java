package com.jhi.aem.website.v1.core.models.dashboard.content;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.jhi.aem.website.v1.core.models.user.ProfileModel;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SettingsProfileContentModel {

    @Inject
    @Default
    private String screenNameLabel;

    @Inject
    @Default
    private String givenNameLabel;

    @Inject
    @Default
    private String middleNameLabel;

    @Inject
    @Default
    private String familyNameLabel;

    @Inject
    @Default
    private String emailLabel;

    @Inject
    @Default
    private String firmNameLabel;

    @Inject
    @Default
    private String roleLabel;

    @Inject
    @Default
    private String crdNumberLabel;

    @Inject
    private ResourceResolver resourceResolver;

    @OSGiService
    private UserProfileService userProfileService;

    private ProfileModel profileModel;

    @PostConstruct
    private void init() {
        profileModel = userProfileService.getProfile(resourceResolver);
    }

    public String getScreenName() {
        return profileModel.getScreenName();
    }

    public String getGivenName() {
        return profileModel.getGivenName();
    }

    public String getFamilyName() {
        return profileModel.getFamilyName();
    }

    public String getEmail() {
        return profileModel.getEmail();
    }

    public String getFirmName() {
        return profileModel.getFirmName();
    }

    public String getRole() {
        return profileModel.getRole();
    }

    public String getCrdNumber() {
        return profileModel.getCrdNumber();
    }

    public String getScreenNameLabel() {
        return screenNameLabel;
    }

    public String getGivenNameLabel() {
        return givenNameLabel;
    }

    public String getMiddleNameLabel() {
        return middleNameLabel;
    }

    public String getFamilyNameLabel() {
        return familyNameLabel;
    }

    public String getEmailLabel() {
        return emailLabel;
    }

    public String getFirmNameLabel() {
        return firmNameLabel;
    }

    public String getRoleLabel() {
        return roleLabel;
    }

    public String getCrdNumberLabel() {
        return crdNumberLabel;
    }
}
