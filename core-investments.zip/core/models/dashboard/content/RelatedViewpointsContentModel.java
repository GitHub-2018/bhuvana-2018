package com.jhi.aem.website.v1.core.models.dashboard.content;

import java.util.Collection;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.generic.pagination.Pagination;
import com.jhi.aem.website.v1.core.models.fund.FundTag;
import com.jhi.aem.website.v1.core.models.user.FundModel;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;
import com.jhi.aem.website.v1.core.models.viewpoints_list.ViewpointsResults;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardService;
import com.jhi.aem.website.v1.core.service.fund.FundManagerFullDetails;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointsService;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RelatedViewpointsContentModel extends AbstractPaginationModel {
    private static final Logger LOG = LoggerFactory.getLogger(RelatedViewpointsContentModel.class);
    private static final Tag[] EMPTY_TAGS_ARRAY = new Tag[0];
    private static final int PAGE_SIZE = 7;
    private static final String RELATED_VIEWPOINTS_HTML = ".relatedViewpoints.html/";

    /** A special comparator for the set of viewpoints. It will only return 0 and omit the item from the set if the paths are equivalent. */
    private static Comparator<ViewpointDetailModel> viewpointDetailModelComparator = new Comparator<ViewpointDetailModel>() {

        @Override
        public int compare(ViewpointDetailModel o1, ViewpointDetailModel o2) {
            if (StringUtils.equals(o1.getPath(), o2.getPath())) {
                // Return equals, the item doesn't make it into the set
                return 0;
            }

            if (o1.getPublicationDate() == null && o2.getPublicationDate() != null) {
                return -1;
            }

            if (o2.getPublicationDate() == null && o1.getPublicationDate() != null) {
                return 1;
            }

            if (o1.getPublicationDate() == null && o2.getPublicationDate() == null) {
                return 1;
            }

            // Publication date before
            if (o1.getPublicationDate().before(o2.getPublicationDate())) {
                return -1;
            }

            // In all other cases return greater than (1), never 0 or the item
            // will not make it into the set
            return 1;
        }

    };

    @Inject
    private Page currentPage;

    @Inject
    private ResourceResolver resourceResolver;

    @Self
    private SlingHttpServletRequest request;

    @OSGiService
    private ViewpointsService viewpointsService;

    @OSGiService
    private UserProfileService userProfileService;

    @OSGiService
    private FundService fundService;

    @OSGiService
    private DashboardService dashboardService;

    private Set<ViewpointDetailModel> viewpoints = new LinkedHashSet<>();

    private Pagination pagination;
    private int pageNumber;
    private int offset;

    @PostConstruct
    private void init() {
        setPageNumber(request);
        setOffset(PAGE_SIZE);
        setAllViewpoints();
        setPagination(request, viewpoints.size(), PAGE_SIZE, RELATED_VIEWPOINTS_HTML);
        setViewpointsPage();
    }

    private void setAllViewpoints() {
        final Page homePage = PageUtil.getHomePage(currentPage);
        final Page viewpointsRootPage = ViewpointUtil.getViewpointsMainPage(currentPage);

        if (viewpointsRootPage != null && homePage != null) {

            // Get the user's funds from their profile
            List<FundModel> funds = userProfileService.getFunds(resourceResolver);

            // Get all of the fund managers this user is following through the funds in their profile
            viewpoints.addAll(getLatestViewpointsForAssetManagersOfFunds(viewpointsRootPage, funds));

            // Get all associated asset classes
            viewpoints.addAll(getLatestViewpointsForSiblingFunds(resourceResolver, viewpointsRootPage, funds));

            // Add static categories
            viewpoints.addAll(getViewpointsForStaticCategories(resourceResolver, homePage));

            // If empty after all of that then set up latest viewpoints
            if (viewpoints.isEmpty()) {
                List<ViewpointDetailModel> latestViewpoints = viewpointsService.getLatestViewpoints(resourceResolver,
                        viewpointsRootPage.getPath(), dashboardService.getRelatedViewpointsMaxAge(), Integer.MAX_VALUE);

                if (latestViewpoints != null && !latestViewpoints.isEmpty()) {
                    viewpoints.addAll(latestViewpoints);
                } else {
                    LOG.debug("No latest viewpoints found up until -{} prior to today",
                            dashboardService.getRelatedViewpointsMaxAge());
                }
            }

        } else {
            LOG.error("Could not find viewpoints root page from '{}'", currentPage.getPath());
        }
    }

    private void setViewpointsPage() {
        viewpoints = viewpoints.stream()
                .skip(getOffset())
                .limit(PAGE_SIZE)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    @SuppressWarnings("unchecked")
    private Collection<? extends ViewpointDetailModel> getLatestViewpointsForAssetManagersOfFunds(
            Page viewpointsRootPage, List<FundModel> userFunds) {
        if (userFunds != null && !userFunds.isEmpty()) {

            // Get a set of all of the fund managers
            Set<String> peopleManagingFundsPaths = new HashSet<>();
            TagManager tagManager = viewpointsRootPage.getContentResource().getResourceResolver().adaptTo(TagManager.class);
            userFunds.stream().forEach(fund -> {
                LOG.debug("Finding fund managers of fund: '{}'", fund.getTagId());
                Set<FundManagerFullDetails> peopleManagingFund = fundService.getPeopleManagingFund(tagManager.resolve(fund.getTagId()),
                        currentPage);
                if (peopleManagingFund != null && !peopleManagingFund.isEmpty()) {
                    peopleManagingFund.stream().forEach(person -> peopleManagingFundsPaths.add(person.getFundManagerPagePath()));
                }
            });

            if (!peopleManagingFundsPaths.isEmpty()) {
                LOG.debug("Found people managing funds: {}", peopleManagingFundsPaths);

                // Get the paths for the viewpoints author pages from the people pages
                Set<String> viewpointsAuthorPagePaths = viewpointsService.getViewpointsContributorPagePathsFromPeople(resourceResolver,
                        viewpointsRootPage.getPath(),
                        peopleManagingFundsPaths);

                if (!viewpointsAuthorPagePaths.isEmpty()) {
                    LOG.debug("Found authors for funds from people managing funds: {}", viewpointsAuthorPagePaths);
                    // Now we have this set, get all of the viewpoints tagged with these authors
                    ViewpointsResults authorsViewpoints = viewpointsService.getAuthorsViewpoints(resourceResolver,
                            viewpointsRootPage.getPath(),
                            0, ViewpointsService.NO_LIMIT, dashboardService.getRelatedViewpointsMaxAge(),
                            viewpointsAuthorPagePaths.toArray(ArrayUtils.EMPTY_STRING_ARRAY));

                    if (!authorsViewpoints.isEmpty()) {
                        return authorsViewpoints.getItems();
                    } else {
                        LOG.debug("Could not find any related viewpoints up until -{} prior to today for: {}",
                                dashboardService.getRelatedViewpointsMaxAge(), viewpointsAuthorPagePaths);
                    }
                } else {
                    LOG.debug("Could not find any author page paths for fund managers: {}", peopleManagingFundsPaths);
                }
            } else {
                LOG.debug("Could not find any people managing the user funds");
            }
        } else {
            LOG.debug("No user funds set for this user");
        }

        return Collections.EMPTY_SET;
    }

    @SuppressWarnings("unchecked")
    private Collection<? extends ViewpointDetailModel> getLatestViewpointsForSiblingFunds(
            ResourceResolver resolver, Page viewpointsRootPage, List<FundModel> userFunds) {

        if (userFunds != null && !userFunds.isEmpty()) {
            final TagManager tagManager = resolver.adaptTo(TagManager.class);
            if (tagManager != null) {
                final Set<Tag> tagsToSearch = new HashSet<>();

                // Go through each of the funds and find the sibling tags
                userFunds.stream().forEach(fund -> {
                    // From the fund tag find the category tag, then all sub-tags
                    if (StringUtils.isNotBlank(fund.getTagId())) {
                        Tag tag = tagManager.resolve(fund.getTagId());

                        if (tag != null) {
                            FundTag fundTag = new FundTag(tag);
                            Tag categoryTag = null;

                            if (fundTag.isShareClassTag()) {
                                categoryTag = tag.getParent().getParent();
                            } else if (fundTag.isFundTag()) {
                                categoryTag = tag.getParent();
                            } else {
                                LOG.warn("Fund tag '{}' is not a fund tag or share class tag", fundTag.getTagId());
                            }

                            // If there is a category tag then get the viewpoints for all tags underneath this one
                            if (categoryTag != null) {
                                categoryTag.listChildren().forEachRemaining(fundParentTag -> {
                                    // Add this fund tag
                                    tagsToSearch.add(fundParentTag);
                                    fundParentTag.listChildren().forEachRemaining(tagsToSearch::add);
                                });
                            }
                        } else {
                            LOG.warn("Could not get fund tag with id: {}", fund.getTagId());
                        }
                    }
                });

                // Get the viewpoints associated with any of these tags
                if (!tagsToSearch.isEmpty()) {
                    ViewpointsResults viewpointsResults = viewpointsService.getViewpoints(resolver, viewpointsRootPage.getPath(),
                            -1, 0, tagsToSearch.toArray(EMPTY_TAGS_ARRAY));
                    return viewpointsResults.getItems();
                } else {
                    LOG.warn("No investment tags were extracted to search from");
                }
            } else {
                LOG.error("Cannot obtain tag manager");
            }
        } else {
            LOG.debug("No user funds set for this user");
        }

        return Collections.EMPTY_SET;
    }

    private Collection<? extends ViewpointDetailModel> getViewpointsForStaticCategories(ResourceResolver resourceResolver, Page homePage) {

        String[] staticViewpointCategories = dashboardService.getStaticViewpointCategories();
        if (staticViewpointCategories != null && staticViewpointCategories.length > 0) {
            Set<ViewpointDetailModel> viewpoints = new LinkedHashSet<>();
            String homePagePath = homePage.getPath();

            for (String staticViewpointCategoryPath : staticViewpointCategories) {
                if (StringUtils.startsWith(staticViewpointCategoryPath, homePagePath)) {
                    viewpoints.addAll(
                            viewpointsService.getViewpoints(
                                    resourceResolver, staticViewpointCategoryPath, 0, ViewpointsService.NO_LIMIT).getItems());
                } else {
                    LOG.debug("Discarding static category path '{}' which doesn't have this home page as it's root {}",
                            staticViewpointCategoryPath, homePagePath);
                }
            }
            return viewpoints;
        } else {
            LOG.warn("No static viewpoints categories have been configured");
        }

        return Collections.emptySet();
    }

    public Set<ViewpointDetailModel> getViewpoints() {
        return viewpoints;
    }
}
