package com.jhi.aem.website.v1.core.models.dashboard;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.dashboard.Dashboard;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardService;
import com.jhi.aem.website.v1.core.service.dashboard.Fund;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DashboardPortfolioModel {

    @OSGiService
    private DashboardService dashboardService;

    @OSGiService
    private UserProfileService userProfileService;

    @Inject
    private Page resourcePage;

    @Self
    private Resource resource;

    @Inject
    private String title;

    @Inject
    private String updatedLabel;

    @Inject
    private String asOfLabel;

    @Inject
    private String oneMonthLabel;

    @Inject
    private String threeMonthsLabel;

    @Inject
    private String oneYearLabel;

    @Inject
    private String fiveYearsLabel;

    @ValueMapValue
    private String tenYearsLabel;

    @Inject
    private String ytdLabel;

    @Inject
    private String incepLabel;

    @Inject
    private String currentValueLabel;

    @Inject
    private String expandButtonLabel;

    @Inject
    private String navLabel;

    @Inject
    private String chgLabel;

    @Inject
    private String hypotheticalGrowthLabel;

    @Inject
    private String keyDocumentsLabel;

    @Inject
    private String expandAllLabel;

    @Inject
    private String totalReturnsLabel;

    @Inject
    private String salesChargeLabel;

    @Inject
    private String maximumSalesChargeLabel;

    @Inject
    private String morningstarRatingLabel;

    @Inject
    private String morningstarOverallLabel;

    @Inject
    private String morningstarInformationLabel;

    @Inject
    private String morningstarInformation;

    @Inject
    private String disclosure;

    @Inject
    private String investorDisclosure;

    private Dashboard dashboard;

    private List<Fund> funds;

    @PostConstruct
    private void init() {
        dashboard = dashboardService.getDashboard(resourcePage);
        funds = dashboard.getFunds();
    }

    public String getTitle() {
        return title;
    }

    public String getUpdatedLabel() {
        return updatedLabel;
    }

    public String getAsOfLabel() {
        return asOfLabel;
    }

    public String getOneMonthLabel() {
        return oneMonthLabel;
    }

    public String getThreeMonthsLabel() {
        return threeMonthsLabel;
    }

    public String getOneYearLabel() {
        return oneYearLabel;
    }

    public String getFiveYearsLabel() {
        return fiveYearsLabel;
    }

    public String getYtdLabel() {
        return ytdLabel;
    }

    public String getIncepLabel() {
        return incepLabel;
    }

    public String getCurrentValueLabel() {
        return currentValueLabel;
    }

    public String getExpandButtonLabel() {
        return expandButtonLabel;
    }

    public String getNavLabel() {
        return navLabel;
    }

    public String getChgLabel() {
        return chgLabel;
    }

    public String getHypotheticalGrowthLabel() {
        return hypotheticalGrowthLabel;
    }

    public String getKeyDocumentsLabel() {
        return keyDocumentsLabel;
    }

    public String getExpandAllLabel() {
        return expandAllLabel;
    }

    public String getTotalReturnsLabel() {
        return totalReturnsLabel;
    }

    public String getSalesChargeLabel() {
        return salesChargeLabel;
    }

    public String getMaximumSalesChargeLabel() {
        return maximumSalesChargeLabel;
    }

    public String getMorningstarRatingLabel() {
        return morningstarRatingLabel;
    }

    public String getMorningstarOverallLabel() {
        return morningstarOverallLabel;
    }

    public String getMorningstarInformationLabel() {
        return morningstarInformationLabel;
    }

    public String getMorningstarInformation() {
        return morningstarInformation;
    }

    public String getTenYearsLabel() {
        return tenYearsLabel;
    }

    public Dashboard getDashboard() {
        return dashboard;
    }

    public List<Fund> getFunds() {
        return funds;
    }

    public String getDisclosure() {
        return disclosure;
    }

    public String getInvestorDisclosure() {
        return investorDisclosure;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title);
    }
}
