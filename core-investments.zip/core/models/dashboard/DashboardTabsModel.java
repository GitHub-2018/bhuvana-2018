package com.jhi.aem.website.v1.core.models.dashboard;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.servlets.dashboard.DashboardStatusServlet;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DashboardTabsModel {

    public static final String INFO_SELECTOR_PART = JhiConstants.DOT + DashboardStatusServlet.INFO_SELECTOR + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;

    @Inject
    private Page resourcePage;

    @Inject
    private String loggedInLabel;

    @Inject
    private String relatedViewpointsTabLabel;

    @Inject
    private String recentActivityTabLabel;

    @Inject
    private String yourReportsTabLabel;

    @Inject
    private String ordersTabLabel;

    @Inject
    private String toolsTabLabel;

    @Inject
    private String toolsPageUrl;

    @Inject
    private String notificationsTabLabel;

    @Inject
    private String settingsTabLabel;

    @Inject
    private String emptyViewpointsText;

    @Inject
    private String viewpointsText;

    @Inject
    private String emptyRecentActivityText;

    @Inject
    private String recentActivityText;

    @Inject
    private String emptyReportsText;

    @Inject
    private String reportsText;

    @Inject
    private String emptyOrdersText;

    @Inject
    private String ordersText;

    @Inject
    private String toolsTabDescription;

    @Inject
    private String notificationsTabDescription;

    @Inject
    private String settingsTabDescription;

    @ValueMapValue
    private String accountsTabDescription;

    @ValueMapValue
    private String accountsTabLabel;

    @Self
    private Resource resource;

    @PostConstruct
    private void init() {
    }

    public String getLoggedInLabel() {
        return loggedInLabel;
    }

    public String getRelatedViewpointsTabLabel() {
        return relatedViewpointsTabLabel;
    }

    public boolean isRelatedViewpointsTabLabelExists() {
        return StringUtils.isNotBlank(relatedViewpointsTabLabel);
    }

    public String getRecentActivityTabLabel() {
        return recentActivityTabLabel;
    }

    public String getYourReportsTabLabel() {
        return yourReportsTabLabel;
    }

    public boolean isYourReportsTabLabelExists() {
        return StringUtils.isNotBlank(yourReportsTabLabel);
    }

    public String getOrdersTabLabel() {
        return ordersTabLabel;
    }

    public boolean isOrdersTabLabelExists() {
        return StringUtils.isNotBlank(ordersTabLabel);
    }

    public String getToolsTabLabel() {
        return toolsTabLabel;
    }

    public boolean isToolsTabLabelExists() {
        return StringUtils.isNotBlank(toolsTabLabel);
    }

    public String getNotificationsTabLabel() {
        return notificationsTabLabel;
    }

    public boolean isNotificationsTabLabelExists() {
        return StringUtils.isNotBlank(notificationsTabLabel);
    }

    public String getSettingsTabLabel() {
        return settingsTabLabel;
    }

    public boolean isSettingsTabLabelExists() {
        return StringUtils.isNotBlank(settingsTabLabel);
    }

    public String getEmptyViewpointsText() {
        return emptyViewpointsText;
    }

    public String getViewpointsText() {
        return viewpointsText;
    }

    public String getEmptyRecentActivityText() {
        return emptyRecentActivityText;
    }

    public String getRecentActivityText() {
        return recentActivityText;
    }

    public String getEmptyReportsText() {
        return emptyReportsText;
    }

    public String getReportsText() {
        return reportsText;
    }

    public String getEmptyOrdersText() {
        return emptyOrdersText;
    }

    public String getOrdersText() {
        return ordersText;
    }

    public String getToolsTabDescription() {
        return toolsTabDescription;
    }

    public String getNotificationsTabDescription() {
        return notificationsTabDescription;
    }

    public String getSettingsTabDescription() {
        return settingsTabDescription;
    }

    public String getAccountsTabDescription() {
        return accountsTabDescription;
    }

    public String getAccountsTabLabel() {
        return accountsTabLabel;
    }

    public boolean isAccountsTabLabelExists() {
        return StringUtils.isNotBlank(accountsTabLabel);
    }

    public boolean isBlank() {
        return StringUtils.isBlank(loggedInLabel) && StringUtils.isBlank(relatedViewpointsTabLabel)
                && StringUtils.isBlank(recentActivityTabLabel) && StringUtils.isBlank(yourReportsTabLabel)
                && StringUtils.isBlank(ordersTabLabel) && StringUtils.isBlank(toolsTabLabel)
                && StringUtils.isBlank(notificationsTabLabel) && StringUtils.isBlank(settingsTabLabel);
    }

    public String getToolsPageLink() {
        if (StringUtils.isNotBlank(toolsPageUrl)) {
            return toolsPageUrl;
        }
        return LinkUtil.getLink(PageUtil.getToolsPagePath(resourcePage));
    }

    public String getDashboardStatusPath() {
        return resource.getResourceResolver().map(resource.getPath()) + INFO_SELECTOR_PART;
    }
}
