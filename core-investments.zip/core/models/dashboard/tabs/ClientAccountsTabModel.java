package com.jhi.aem.website.v1.core.models.dashboard.tabs;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.generic.link.Link;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ClientAccountsTabModel {

    @ValueMapValue
    private String clientAccountsTitle;

    @ValueMapValue
    private String dstAccountsAccessTitle;

    @ValueMapValue
    private String dstAccountsLoginPath;

    @ValueMapValue
    private String individualInvestorsTitle;

    @ValueMapValue
    private String[] individualInvestorsLinks;

    @ValueMapValue
    private String planAdministratorsTitle;

    @ValueMapValue
    private String[] planAdministratorsLinks;

    @Inject
    private Page resourcePage;

    @OSGiService
    private ResourceResolverFactory factory;

    private List<Link> accessIndividualInvestorsLinks;
    private List<Link> accessPlanAdministratorsLinks;
    private Link dstAccountsLoginLink;

    @PostConstruct
    public void init() {
        ResourceResolver resolver = ResourceResolverUtil.getResourceResolver(factory);
        PageManager pageManager = resolver.adaptTo(PageManager.class);

        accessIndividualInvestorsLinks = Link.getLinksFromPaths(individualInvestorsLinks, pageManager, resourcePage);
        accessPlanAdministratorsLinks = Link.getLinksFromPaths(planAdministratorsLinks, pageManager, resourcePage);
        dstAccountsLoginLink = Link.getLinkFromPath(dstAccountsLoginPath, pageManager, resourcePage);

        if (resolver.isLive()) {
            resolver.close();
        }
    }

    public String getClientAccountsTitle() {
        return clientAccountsTitle;
    }

    public String getDstAccountsAccessTitle() {
        return dstAccountsAccessTitle;
    }

    public String getIndividualInvestorsTitle() {
        return individualInvestorsTitle;
    }

    public String getPlanAdministratorsTitle() {
        return planAdministratorsTitle;
    }

    public List<Link> getAccessIndividualInvestorsLinks() {
        return accessIndividualInvestorsLinks;
    }

    public List<Link> getAccessPlanAdministratorsLinks() {
        return accessPlanAdministratorsLinks;
    }

    public Link getDstAccountsLoginLink() {
        return dstAccountsLoginLink;
    }
}
