package com.jhi.aem.website.v1.core.models.dashboard.tabs;

import javax.annotation.PostConstruct;
import javax.inject.Inject;


import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DashboardNotificationOption implements Comparable<DashboardNotificationOption> {

	@Inject
    private String title;
	@Inject
    private String id;
	@Inject
    private String description;
	@Inject
    private String link;
	
	@PostConstruct
	private void init(){
		
	}

    public String getTitle() {
        return title;
    }

    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getLink() {
        return LinkUtil.getLink(link);
    }

    @Override
    public int compareTo(DashboardNotificationOption o) {
        return this.id.compareTo(o.id);
    }
}
