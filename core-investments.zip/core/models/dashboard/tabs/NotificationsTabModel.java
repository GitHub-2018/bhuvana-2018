package com.jhi.aem.website.v1.core.models.dashboard.tabs;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.adobe.granite.crypto.CryptoException;
import com.adobe.granite.crypto.CryptoSupport;
import com.day.cq.wcm.api.Page;
import com.google.gson.GsonBuilder;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;
import com.jhi.aem.website.v1.core.utils.UserUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NotificationsTabModel {

    private static GsonBuilder gsonBuilder = new GsonBuilder();

    @Inject
    private String notificationsTitle;

    @Inject
    private String notificationsFundsLabel;

    @Inject
    private String notificationsFundsDescription;

    @Inject
    private String allFundsLabel;

    @Inject
    private String sendPerformanceUpdatesLabel;

    @Inject
    private String weeklyNotificationsLabel;

    @Inject
    private String monthlyNotificationsLabel;

    @Inject
    private String sendFundCommentariesLabel;

    @Inject
    private String sendDividendsUpdatesLabel;

    @Inject
    private String sendReportsUpdatesLabel;

    @Inject
    private String sendSingleMessageLabel;

    @Inject
    private String sendSingleMessageDescription;

    @Inject
    private String notificationsViewpointsLabel;

    @Inject
    @Via("resource")
    private String notificationsViewpointsDescription;

    @Inject
    @Via("resource")
    private String weeklyViewpointsUpdateLabel;

    @Inject
    @Via("resource")
    private String weeklyMarketRecapUpdateLabel;

    @Inject
    @Via("resource")
    private String connectNewsletterUpdateLabel;

    @Inject
    @Via("resource")
    private String generalUpdatesLabel;

    @Inject
    @Via("resource")
    private String eventsUpdatesLabel;

    @Inject
    @Via("resource")
    private String subscriptionsSuccessMessage;

    @Inject
    @Via("resource")
    private String unsubscribeLabel;

    @Inject
    @Via("resource")
    private List<DashboardNotificationOption> notificationOptions;

    @Inject
    @Via("resource")
    private String socialMediaLabel;

    @Inject
    private Page resourcePage;

    @SlingObject
    private ResourceResolver resolver;

	@Inject
	private CryptoSupport cryptoSupport;

	@Self
	private SlingHttpServletRequest request;

	private String loggedInUser;

	private Set<DashboardNotificationOption> options = new LinkedHashSet<DashboardNotificationOption>();
	private String socialResourcePath;

	@PostConstruct
	private void init() {
		Page homePage = PageUtil.getHomePage(resourcePage);
		socialResourcePath = ResourceUtil
				.getAllSubResourcesInPath(resolver, homePage.getPath(), "jhi-website-v1/components/content/socialMedia")
				.stream().findFirst().map(Resource::getPath).orElse(StringUtils.EMPTY);

		/*
		 * options = Optional.ofNullable(notificationOptions).map(Arrays::stream)
		 * .map(stream -> stream .map(option -> gsonBuilder.create().fromJson(option,
		 * DashboardNotificationOption.class))
		 * .collect(Collectors.toCollection(LinkedHashSet::new)))
		 * .orElseGet(LinkedHashSet::new);
		 */
		if (null != notificationOptions && notificationOptions.size() > 0) {
			ListIterator<DashboardNotificationOption> iter = notificationOptions.listIterator();
			while (iter.hasNext()) {
				DashboardNotificationOption notificationResource = iter.next();
				options.add(notificationResource);
			}
		}
		//options = new LinkedHashSet<DashboardNotificationOption>(notificationOptions);

		try {
			ResourceResolver resourceResolver = request.getResourceResolver();
			Authorizable authorizable = UserUtil.getCurrentAuthorizable(resourceResolver);
			loggedInUser = (authorizable != null) ? authorizable.getID() : null;
			// LOG.info("Logged In user :" + loggedInUser);
			// LOG.info("Check user is not blank :"+StringUtils.isNotBlank(loggedInUser));
			if (StringUtils.isNotBlank(loggedInUser)) {
				loggedInUser = cryptoSupport.protect(loggedInUser);
				// LOG.info("Masked User :" + loggedInUser);
			}

		} catch (RepositoryException e) {
			// LOG.info("Repository Exception "+ e.getMessage());
			e.printStackTrace();
		} catch (CryptoException e) {
			// LOG.info("Crypto Exception "+ e.getMessage());
			e.printStackTrace();
		}
	}

    public String getNotificationsTitle() {
        return notificationsTitle;
    }

    public String getNotificationsFundsLabel() {
        return notificationsFundsLabel;
    }

    public String getNotificationsFundsDescription() {
        return notificationsFundsDescription;
    }

    public String getAllFundsLabel() {
        return allFundsLabel;
    }

    public String getSendPerformanceUpdatesLabel() {
        return sendPerformanceUpdatesLabel;
    }

    public String getWeeklyNotificationsLabel() {
        return weeklyNotificationsLabel;
    }

    public String getMonthlyNotificationsLabel() {
        return monthlyNotificationsLabel;
    }

    public String getSendFundCommentariesLabel() {
        return sendFundCommentariesLabel;
    }

    public String getSendDividendsUpdatesLabel() {
        return sendDividendsUpdatesLabel;
    }

    public String getSendReportsUpdatesLabel() {
        return sendReportsUpdatesLabel;
    }

    public String getSendSingleMessageLabel() {
        return sendSingleMessageLabel;
    }

    public String getSendSingleMessageDescription() {
        return sendSingleMessageDescription;
    }

    public String getNotificationsViewpointsLabel() {
        return notificationsViewpointsLabel;
    }

    public String getNotificationsViewpointsDescription() {
        return notificationsViewpointsDescription;
    }

    public String getWeeklyViewpointsUpdateLabel() {
        return weeklyViewpointsUpdateLabel;
    }

    public String getWeeklyMarketRecapUpdateLabel() {
        return weeklyMarketRecapUpdateLabel;
    }

    public String getConnectNewsletterUpdateLabel() {
        return connectNewsletterUpdateLabel;
    }

    public String getGeneralUpdatesLabel() {
        return generalUpdatesLabel;
    }

    public String getEventsUpdatesLabel() {
        return eventsUpdatesLabel;
    }


    public String getSubscriptionsSuccessMessage() {
        return subscriptionsSuccessMessage;
    }

    public Set<DashboardNotificationOption> getNotificationOptions() {
        return options;
    }

    public String getUnsubscribeLabel() {
        return unsubscribeLabel;
    }

    public String getSocialResourcePath() {
        return socialResourcePath;
    }

	public String getSocialMediaLabel() {
		return socialMediaLabel;
	}

	public String getLoggedInUser() {
		return loggedInUser;
	}
}
