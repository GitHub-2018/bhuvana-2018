package com.jhi.aem.website.v1.core.models.dashboard.tabs;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class RelatedViewpointsTabModel {
    private static final String RELATED_VIEWPOINTS_SELECTOR_PART =
    		JhiConstants.DOT + JhiConstants.RELATED_VIEWPOINTS_SELECTOR + JhiConstants.DOT +
            JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;

    @Inject
    @Via("resource")
    private String relatedViewpointsTitle;

    @Inject
    private Resource resource;

    @Self
    private SlingHttpServletRequest request;

    @OSGiService
    private UserProfileService userProfileService;

    public String getRelatedViewpointsTitle() {
        return relatedViewpointsTitle;
    }

    public String getViewpointsContentPath() {
        return resource.getResourceResolver().map(request, resource.getPath()) + RELATED_VIEWPOINTS_SELECTOR_PART;
    }

}
