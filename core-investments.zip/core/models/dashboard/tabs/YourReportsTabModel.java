package com.jhi.aem.website.v1.core.models.dashboard.tabs;

import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class YourReportsTabModel {

    private static final String YOUR_REPORTS_SELECTOR_PART = ".yourReports" + JhiConstants.DOT + JhiConstants
            .NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;

    @Inject
    @Via("resource")
    private String yourReportsTitle;

    @Inject
    @Via("resource")
    private String reportNameLabel;

    @Inject
    @Via("resource")
    private String reportDateLabel;

    @Inject
    private Resource resource;

    @Self
    private SlingHttpServletRequest request;

    public String getYourReportsTitle() {
        return yourReportsTitle;
    }

    public String getReportNameLabel() {
        return reportNameLabel;
    }

    public String getReportDateLabel() {
        return reportDateLabel;
    }

    public String getReportsContentPath() {
        return resource.getResourceResolver().map(request, resource.getPath()) + YOUR_REPORTS_SELECTOR_PART;
    }
}
