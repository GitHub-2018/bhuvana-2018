package com.jhi.aem.website.v1.core.models.dashboard.tabs;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.servlets.user.AddressUpdateServlet;
import com.jhi.aem.website.v1.core.servlets.user.FundsListingServlet;
import com.jhi.aem.website.v1.core.servlets.user.ProfileUpdateServlet;
import com.jhi.aem.website.v1.core.servlets.user.ShippingUpdateServlet;
import com.jhi.aem.website.v1.core.servlets.user.UserInvestmentServlet;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SettingsTabModel {

	public static final String INVESTMENTS_SETTINGS_TAB_NAME = ".settings-investments";

	private static final String INVESTMENTS_SELECTOR_PART = INVESTMENTS_SETTINGS_TAB_NAME + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;
    private static final String PROFILE_SELECTOR_PART = ".settings-profile" + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;
    private static final String ADDRESSES_SELECTOR_PART = ".settings-addresses" + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;
    private static final String SHIPPING_SELECTOR_PART = ".settings-shipping" + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;
    private static final String ADDRESS_SELECTOR_PART = JhiConstants.DOT + AddressUpdateServlet.ADDRESS_SELECTOR
            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;

    private static final String FUND_LISTING_SELECTOR_PART = JhiConstants.DOT + FundsListingServlet.FUNDS_LIST_SELECTOR
            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
    private static final String EDIT_SHIPPING_SELECTOR_PART = JhiConstants.DOT + ShippingUpdateServlet.SHIPPING_SELECTOR
            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
    private static final String EDIT_INVESTMENTS_SELECTOR_PART = JhiConstants.DOT + UserInvestmentServlet.INVESTMENT_SELECTOR
            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;
    private static final String EDIT_PROFILE_SELECTOR_PART = JhiConstants.DOT + ProfileUpdateServlet.PROFILE_SELECTOR
            + JhiConstants.DOT + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.DOT + JhiConstants.JSON_EXTENSION;

    @Inject
    @Via("resource")
    private String settingsTitle;

    @Inject
    @Via("resource")
    private String settingsPortfolioTitle;

    @Inject
    @Via("resource")
    private String settingsYourFundsLabel;

    @Inject
    @Via("resource")
    private String settingsAllocationLabel;

    @Inject
    @Via("resource")
    private String settingsProfileTitle;

    @Inject
    @Via("resource")
    private String settingsAddressesTitle;

    @Inject
    @Via("resource")
    private String settingsAddressesDescription;

    @Inject
    @Via("resource")
    private String settingsAddAddressLabel;

    @Inject
    @Via("resource")
    private String settingsShippingTitle;

    @Inject
    @Via("resource")
    private String settingsChangePasswordTitle;

    @Inject
    @Via("resource")
    private String settingsChangePasswordLabel;

    // ADDRESS

    @Inject
    @Via("resource")
    private String addressIdLabel;

    @Inject
    @Via("resource")
    private String addressNameLabel;

    @Inject
    @Via("resource")
    private String addressAddressLabel;

    @Inject
    @Via("resource")
    private String addressBuildingDetailLabel;

    @Inject
    @Via("resource")
    private String addressCityLabel;

    @Inject
    @Via("resource")
    private String addressStateLabel;

    @Inject
    @Via("resource")
    private String addressZipLabel;

    @Inject
    @Via("resource")
    private String addressCountryLabel;

    @Inject
    @Via("resource")
    private String addressDeleteLabel;

    // POPUP TITLES

    @Inject
    @Via("resource")
    private String popupFundsTitle;

    @Inject
    @Via("resource")
    private String popupProfileTitle;

    @Inject
    @Via("resource")
    private String popupAddressTitle;

    @Inject
    @Via("resource")
    private String popupDeleteAddressTitle;

    @Inject
    @Via("resource")
    private String popupShippingTitle;

    @Inject
    @Via("resource")
    private String popupPasswordTitle;

    // POPUP GENERAL

    @Inject
    @Via("resource")
    private String popupSaveLabel;

    @Inject
    @Via("resource")
    private String popupCancelLabel;

    @Inject
    @Via("resource")
    private String popupDeleteLabel;

    @Inject
    @Via("resource")
    private String popupDeleteAddressDisclaimer;

    @Inject
    @Via("resource")
    private String popupShippingLabel;

    @Inject
    @Via("resource")
    private String popupEmailLabel;

    @Inject
    @Via("resource")
    private String popupCurrentPasswordLabel;

    @Inject
    @Via("resource")
    private String popupNewPasswordLabel;

    @Inject
    @Via("resource")
    private String popupConfirmPasswordLabel;

    @Inject
    private Resource resource;

    @Self
    private SlingHttpServletRequest request;

    private String mappedResourcePath;

    @PostConstruct
    protected void init() {
        mappedResourcePath = resource.getResourceResolver().map(request, resource.getPath());
    }

    public String getSettingsTitle() {
        return settingsTitle;
    }

    public String getSettingsPortfolioTitle() {
        return settingsPortfolioTitle;
    }

    public String getSettingsYourFundsLabel() {
        return settingsYourFundsLabel;
    }

    public String getSettingsAllocationLabel() {
        return settingsAllocationLabel;
    }

    public String getSettingsProfileTitle() {
        return settingsProfileTitle;
    }

    public String getSettingsAddressesTitle() {
        return settingsAddressesTitle;
    }

    public String getSettingsAddressesDescription() {
        return settingsAddressesDescription;
    }

    public String getSettingsAddAddressLabel() {
        return settingsAddAddressLabel;
    }

    public String getSettingsShippingTitle() {
        return settingsShippingTitle;
    }

    public String getSettingsChangePasswordTitle() {
        return settingsChangePasswordTitle;
    }

    public String getSettingsChangePasswordLabel() {
        return settingsChangePasswordLabel;
    }

    public String getAddressIdLabel() {
        return addressIdLabel;
    }

    public String getAddressNameLabel() {
        return addressNameLabel;
    }

    public String getAddressAddressLabel() {
        return addressAddressLabel;
    }

    public String getAddressBuildingDetailLabel() {
        return addressBuildingDetailLabel;
    }

    public String getAddressCityLabel() {
        return addressCityLabel;
    }

    public String getAddressStateLabel() {
        return addressStateLabel;
    }

    public String getAddressZipLabel() {
        return addressZipLabel;
    }

    public String getAddressCountryLabel() {
        return addressCountryLabel;
    }

    public String getAddressDeleteLabel() {
        return addressDeleteLabel;
    }

    public String getPopupFundsTitle() {
        return popupFundsTitle;
    }

    public String getPopupProfileTitle() {
        return popupProfileTitle;
    }

    public String getPopupAddressTitle() {
        return popupAddressTitle;
    }

    public String getPopupDeleteAddressTitle() {
        return popupDeleteAddressTitle;
    }

    public String getPopupShippingTitle() {
        return popupShippingTitle;
    }

    public String getPopupPasswordTitle() {
        return popupPasswordTitle;
    }

    public String getPopupSaveLabel() {
        return popupSaveLabel;
    }

    public String getPopupCancelLabel() {
        return popupCancelLabel;
    }

    public String getPopupDeleteLabel() {
        return popupDeleteLabel;
    }

    public String getPopupDeleteAddressDisclaimer() {
        return popupDeleteAddressDisclaimer;
    }

    public String getPopupShippingLabel() {
        return popupShippingLabel;
    }

    public String getPopupEmailLabel() {
        return popupEmailLabel;
    }

    public String getPopupCurrentPasswordLabel() {
        return popupCurrentPasswordLabel;
    }

    public String getPopupNewPasswordLabel() {
        return popupNewPasswordLabel;
    }

    public String getPopupConfirmPasswordLabel() {
        return popupConfirmPasswordLabel;
    }

    public String getInvestmentsContentPath() {
        return mappedResourcePath + INVESTMENTS_SELECTOR_PART;
    }

    public String getProfileContentPath() {
        return mappedResourcePath + PROFILE_SELECTOR_PART;
    }

    public String getAddressesContentPath() {
        return mappedResourcePath + ADDRESSES_SELECTOR_PART;
    }

    public String getShippingContentPath() {
        return mappedResourcePath + SHIPPING_SELECTOR_PART;
    }

    public String getAddAddressPath() {
        return mappedResourcePath + ADDRESS_SELECTOR_PART;
    }

    public String getEditShippingPath() {
        return mappedResourcePath + EDIT_SHIPPING_SELECTOR_PART;
    }

    public String getEditInvestmentsPath() {
        return mappedResourcePath + EDIT_INVESTMENTS_SELECTOR_PART;
    }

    public String getEditProfilePath() {
        return mappedResourcePath + EDIT_PROFILE_SELECTOR_PART;
    }
    
    public String getFundListingsPath() {
    	return mappedResourcePath + FUND_LISTING_SELECTOR_PART;
    }

    public String getChangePasswordActionPath() {
        return mappedResourcePath + JhiConstants.SLING_SECURITY_CHECK_PATH;
    }

}
