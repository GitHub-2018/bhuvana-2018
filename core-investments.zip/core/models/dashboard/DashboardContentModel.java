package com.jhi.aem.website.v1.core.models.dashboard;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.user.ShippingModel;
import com.jhi.aem.website.v1.core.service.dashboard.Dashboard;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardContentService;
import com.jhi.aem.website.v1.core.service.dashboard.DashboardService;
import com.jhi.aem.website.v1.core.service.dashboard.Fund;
import com.jhi.aem.website.v1.core.service.user.UserProfileService;
import com.jhi.aem.website.v1.core.servlets.dashboard.DashboardFundServlet;
import com.jhi.aem.website.v1.core.servlets.funds.FundCodeSearchServlet;
import com.jhi.aem.website.v1.core.servlets.user.ProfileUpdateServlet;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DashboardContentModel {

    @OSGiService
    private DashboardService dashboardService;

    @OSGiService
    private UserProfileService userProfileService;

    @OSGiService
    private DashboardContentService dashboardContentService;

    @Inject
    private Page resourcePage;

    @Self
    private Resource resource;

    // ADDRESS

    @Inject
    private String addressIdLabel;

    @Inject
    private String addressNameLabel;

    @Inject
    private String addressAddressLabel;

    @Inject
    private String addressBuildingDetailLabel;

    @Inject
    private String addressCityLabel;

    @Inject
    private String addressStateLabel;

    @Inject
    private String addressZipLabel;

    @Inject
    private String addressCountryLabel;

    @Inject
    private String addressDeleteLabel;

    // PROFILE

    @Inject
    @Default
    private String screenNameLabel;

    @Inject
    @Default
    private String givenNameLabel;

    @Inject
    @Default
    private String middleNameLabel;

    @Inject
    @Default
    private String familyNameLabel;

    @Inject
    @Default
    private String emailLabel;

    @Inject
    @Default
    private String firmNameLabel;

    @Inject
    @Default
    private String roleLabel;

    @Inject
    @Default
    private String crdNumberLabel;

    // POPUP TITLES

    @Inject
    private String popupFundsTitle;

    @Inject
    private String popupProfileTitle;

    @Inject
    private String popupAddressTitle;

    @Inject
    private String popupDeleteAddressTitle;

    @Inject
    private String popupShippingTitle;

    @Inject
    private String popupPasswordTitle;

    // POPUP GENERAL

    @Inject
    private String popupSaveLabel;

    @Inject
    private String popupCancelLabel;

    @Inject
    private String popupDeleteLabel;

    @Inject
    private String popupDeleteAddressDisclaimer;

    @Inject
    private String popupShippingLabel;

    @Inject
    private String popupEmailLabel;

    @Inject
    private String popupCurrentPasswordLabel;

    @Inject
    private String popupNewPasswordLabel;

    @Inject
    private String popupConfirmPasswordLabel;
    
    @Inject
    private List<Resource> passwordCriterias;

    @ValueMapValue
    private String popupAddKeywordButton;

    private String userEmailNotification = StringUtils.EMPTY;

    private List<Fund> funds;
    private List<String> roles;

    @PostConstruct
    private void init() {
        final ShippingModel shipping = userProfileService.getShipping(resource.getResourceResolver());
        if (shipping != null) {
            userEmailNotification = shipping.getEmail();
        }

        funds = Optional.ofNullable(dashboardService.getDashboard(resourcePage))
                .map(Dashboard::getFunds)
                .orElse(Collections.emptyList());


        roles = dashboardContentService.getUfpRoles(resourcePage);
    }

    public String getAddressIdLabel() {
        return addressIdLabel;
    }

    public String getAddressNameLabel() {
        return addressNameLabel;
    }

    public String getAddressAddressLabel() {
        return addressAddressLabel;
    }

    public String getAddressBuildingDetailLabel() {
        return addressBuildingDetailLabel;
    }

    public String getAddressCityLabel() {
        return addressCityLabel;
    }

    public String getAddressStateLabel() {
        return addressStateLabel;
    }

    public String getAddressZipLabel() {
        return addressZipLabel;
    }

    public String getAddressCountryLabel() {
        return addressCountryLabel;
    }

    public String getAddressDeleteLabel() {
        return addressDeleteLabel;
    }

    public String getPopupFundsTitle() {
        return popupFundsTitle;
    }

    public String getPopupProfileTitle() {
        return popupProfileTitle;
    }

    public String getPopupAddressTitle() {
        return popupAddressTitle;
    }

    public String getPopupDeleteAddressTitle() {
        return popupDeleteAddressTitle;
    }

    public String getPopupShippingTitle() {
        return popupShippingTitle;
    }

    public String getPopupPasswordTitle() {
        return popupPasswordTitle;
    }

    public String getPopupSaveLabel() {
        return popupSaveLabel;
    }

    public String getPopupCancelLabel() {
        return popupCancelLabel;
    }

    public String getPopupDeleteLabel() {
        return popupDeleteLabel;
    }

    public String getPopupDeleteAddressDisclaimer() {
        return popupDeleteAddressDisclaimer;
    }

    public String getPopupShippingLabel() {
        return popupShippingLabel;
    }

    public String getPopupEmailLabel() {
        return popupEmailLabel;
    }

    public String getPopupCurrentPasswordLabel() {
        return popupCurrentPasswordLabel;
    }

    public String getPopupNewPasswordLabel() {
        return popupNewPasswordLabel;
    }

    public String getPopupConfirmPasswordLabel() {
        return popupConfirmPasswordLabel;
    }

    public List<Resource> getPasswordCriterias() {
		return passwordCriterias;
	}
    
    public String getUserEmailNotification() {
        return userEmailNotification;
    }

    public List<Fund> getFunds() {
        return funds;
    }

    public String getScreenNameLabel() {
        return screenNameLabel;
    }

    public String getGivenNameLabel() {
        return givenNameLabel;
    }

    public String getMiddleNameLabel() {
        return middleNameLabel;
    }

    public String getFamilyNameLabel() {
        return familyNameLabel;
    }

    public String getEmailLabel() {
        return emailLabel;
    }

    public String getFirmNameLabel() {
        return firmNameLabel;
    }

    public String getRoleLabel() {
        return roleLabel;
    }

    public String getCrdNumberLabel() {
        return crdNumberLabel;
    }

    public String getSearchFundsUrl() {
        return FundCodeSearchServlet.FUND_CODE_SEARCH_PATH + "." + JhiConstants.JSON_EXTENSION;
    }

    public String getAddDashboardFundsUrl() {
        return resourcePage.getContentResource().getPath() + DashboardFundServlet.ADD_FUNDS_REQUEST_STRING;
    }

    public String getEditDashboardFundsUrl() {
        return resourcePage.getContentResource().getPath() + DashboardFundServlet.DASHBOARD_REQUEST_STRING;
    }

    public List<String> getRoles() {
        return roles;
    }

    public String getUpdateProfileUrl() {
        return resource.getPath() + "." + ProfileUpdateServlet.PROFILE_SELECTOR + "." + JhiConstants.JSON_EXTENSION;
    }

    public String getPopupAddKeywordButton() {
        return popupAddKeywordButton;
    }
}
