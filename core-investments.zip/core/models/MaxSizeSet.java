package com.jhi.aem.website.v1.core.models;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Spliterator;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class MaxSizeSet <T extends Object> implements Set<T> {
	private final Set<T> delegatedSet;
	private final int maxSize;

	public MaxSizeSet(int maxSize) {
		this(maxSize, new LinkedHashSet<T>(maxSize));
	}

	public MaxSizeSet(int maxSize, Set<T> delegatedSet) {
		this.maxSize = maxSize;
		this.delegatedSet = delegatedSet;
	}

	public boolean isFull() {
		return size() >= maxSize;
	}

	public void forEach(Consumer<? super T> action) {
		delegatedSet.forEach(action);
	}

	public int size() {
		return delegatedSet.size();
	}

	public boolean isEmpty() {
		return delegatedSet.isEmpty();
	}

	public boolean contains(Object o) {
		return delegatedSet.contains(o);
	}

	public Iterator<T> iterator() {
		return delegatedSet.iterator();
	}

	public Object[] toArray() {
		return delegatedSet.toArray();
	}

	public <I> I[] toArray(I[] a) {
		return delegatedSet.toArray(a);
	}

	public boolean add(T e) {
		if (!isFull()) {
			return delegatedSet.add(e);
		}
		
		return false;
	}

	public boolean remove(Object o) {
		return delegatedSet.remove(o);
	}

	public boolean containsAll(Collection<?> c) {
		return delegatedSet.containsAll(c);
	}

	public boolean addAll(Collection<? extends T> c) {
		if (c == null) {
			return false;
		}

		AtomicBoolean allAdded = new AtomicBoolean(true);
		c.stream().forEach(item -> {
			boolean added = add(item);
			allAdded.set(allAdded.get() == false ? false : added);
		});
		return allAdded.get();
	}

	public boolean retainAll(Collection<?> c) {
		return delegatedSet.retainAll(c);
	}

	public boolean removeAll(Collection<?> c) {
		return delegatedSet.removeAll(c);
	}

	public void clear() {
		delegatedSet.clear();
	}

	public boolean equals(Object o) {
		return delegatedSet.equals(o);
	}

	public int hashCode() {
		return delegatedSet.hashCode();
	}

	public Spliterator<T> spliterator() {
		return delegatedSet.spliterator();
	}

	public boolean removeIf(Predicate<? super T> filter) {
		return delegatedSet.removeIf(filter);
	}

	public Stream<T> stream() {
		return delegatedSet.stream();
	}

	public Stream<T> parallelStream() {
		return delegatedSet.parallelStream();
	}
}
