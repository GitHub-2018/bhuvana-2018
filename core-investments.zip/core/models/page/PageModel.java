package com.jhi.aem.website.v1.core.models.page;

import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.models.HreflangTag;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.social.LatestTweetsModel;
import com.jhi.aem.website.v1.core.service.osgi.OsgiConfigurationService;
import com.jhi.aem.website.v1.core.utils.DateUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;
import com.jhi.aem.website.v1.core.utils.ViewpointUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PageModel {
    private static final Logger log = LoggerFactory.getLogger(PageModel.class);
    private static final String CANONICAL = "canonical";

    @Inject
    protected Page resourcePage;

    @Inject
    protected ResourceResolver resourceResolver;

    @Inject
    protected OsgiConfigurationService configService;

    @Self
    protected SlingHttpServletRequest request;

    @Inject
    @Via("resource")
    private ImageModel socialShareImage;

    @Inject
    @Via("resource")
    private String bodyCssClass;

	@ValueMapValue
    @Via("resource")
	private Boolean redirectOnLogin = false;
	
	@Inject
    @Via("resource")
	private Boolean hideCanonical ;

	@Inject
    @Via("resource")
    private String canonicalPath;

	@Inject
    @Via("resource")
	private Boolean hreflang = false;

	@Inject
	@Via("resource")
    private List<HreflangTag> hreflangLinks;

	private PageType pageType = null;

    private String hostUrl;

    private String twitterLink;

    private String noIndex;

    protected Boolean isInUcitsSite;

    @PostConstruct
    protected void init() {
        noIndex = configService.getProperty("com.jhi.aem.website.v1.core.config.PageComponent", "noindextext", StringUtils.EMPTY);
        isInUcitsSite = PageUtil.isInUcitsSite(resourcePage);
    }

    public String getHomePagePath() {
        Page homePage = PageUtil.getHomePage(resourcePage);
        if (homePage != null) {
            return homePage.getPath();
        }
        return StringUtils.EMPTY;
    }

    public String getViewpointsPagePath() {
        Page viewpointsPage = ViewpointUtil.getViewpointsMainPage(resourcePage);
        if (viewpointsPage != null) {
            return viewpointsPage.getPath();
        }
        return StringUtils.EMPTY;
    }

    public String getSiteName() {
        Page homePage = PageUtil.getHomePage(resourcePage);
        if (homePage == null) {
            return StringUtils.EMPTY;
        }
        return PageUtil.getPageNavigationTitle(homePage);
    }

    public String getClazz() {
        if (resourcePage == null) {
            return StringUtils.EMPTY;
        }
        return resourcePage.getName();
    }

    public String getTitle() {
        return PageUtil.getTitle(resourcePage);
    }

    public String getPageTitle() {
        return PageUtil.getPageTitle(resourcePage);
    }

    public String getDescription() {
        if (resourcePage != null) {
            return resourcePage.getDescription();
        }
        return StringUtils.EMPTY;
    }

    public String getLastModificationDate() {
        if (resourcePage != null) {
            return DateUtil.getFormattedUsDate(resourcePage.getLastModified(), resourcePage);
        }
        return StringUtils.EMPTY;
    }

    public PageType getPageType() {
        if (pageType == null) {
            pageType = PageType.getForPage(resourcePage);
        }
        return pageType;
    }

    public String getPageResourcePath() {
        if (resourceResolver != null && request != null) {
            return resourceResolver.map(request.getResource().getPath());
        }
        return StringUtils.EMPTY;
    }

    public String getLanguageCode() {
        if (resourcePage != null) {
            Page targetPage = resourcePage.adaptTo(Page.class);
            if (targetPage != null) {
                Locale pageLocale = targetPage.getLanguage(true);
                return pageLocale.getLanguage();
            }
        }

        return StringUtils.EMPTY;
    }

    public String getCountryLanguageCode() {
        if (resourcePage != null) {
            Page targetPage = resourcePage.adaptTo(Page.class);
            if (targetPage != null) {
                Locale pageLocale = targetPage.getLanguage(true);
                if (pageLocale.getCountry() == null || StringUtils.isBlank(pageLocale.getCountry())) { // avoid "en_"
                    return pageLocale.getLanguage();
                }
                return pageLocale.getLanguage() + "_" + pageLocale.getCountry();
            }
        }
        return StringUtils.EMPTY;
    }
    /**
     * if canonical URL is not defined in page properties,  this method will return a default value
     * @return
     */
	public String getCanonicalUrl() {
		if (StringUtils.isNotEmpty(canonicalPath)) {
			return canonicalPath;   //GIT #2647 - Handle the authoring capability for canonical URL
		} else if (resourceResolver != null && resourcePage != null) {
			String canonicalUrl = LinkUtil.getPageLink(resourceResolver, resourcePage);

			if (!StringUtils.startsWithAny(canonicalUrl, LinkUtil.URL_PROTOCOLS)
					&& StringUtils.isNotBlank(getHostUrl())) {
				return getHostUrl() + canonicalUrl;
			} else {
				return canonicalUrl;
			}
		}

		return StringUtils.EMPTY;
	}

    public boolean hasSocialShareImage() {
        return socialShareImage != null;
    }

    private String getHostUrl() {
        if (hostUrl == null) {
            if (request != null) {
                StringBuilder url = LinkUtil.getHostBaseUrlFromRequest(request);
                hostUrl = url.toString();
            }
        }
        return hostUrl;
    }

    public String getSocialShareImagePath() {
        if (StringUtils.isNotBlank(getHostUrl()) && socialShareImage != null) {
            return getHostUrl() + socialShareImage.getPath();
        }

        return StringUtils.EMPTY;
    }

    public Integer getSocialShareImageHeight() {
        if (socialShareImage != null) {
            return socialShareImage.getImageHeight();
        }

        return null;
    }

    public Integer getSocialShareImageWidth() {
        if (socialShareImage != null) {
            return socialShareImage.getImageWidth();
        }

        return null;
    }

    public boolean isTwitterHandleExists() {
        return StringUtils.isNotBlank(getTwitterHandle());
    }

    public String getTwitterHandle() {
        if (StringUtils.isBlank(twitterLink)) {
            Resource latestTweetsPageResource =
                    ResourceUtil.getSubResourcesOfPage(resourceResolver, resourcePage, ResourcesConstants.LATEST_TWEETS_RESOURCE_TYPE)
                            .stream().findFirst().orElse(null);

            if (latestTweetsPageResource != null) {
                LatestTweetsModel model = latestTweetsPageResource.adaptTo(LatestTweetsModel.class);
                twitterLink = model != null ? StringUtils.defaultIfEmpty(model.getTwitterScreenName(), StringUtils.EMPTY) : StringUtils.EMPTY;
            }
        }

        return twitterLink;
    }

    public String getResourceIdentifier() {
        return StringUtils.substringAfterLast(resourcePage.getContentResource().getResourceType(), "/");
    }

    public boolean isValid() {
        return resourcePage != null && resourcePage.isValid();
    }

    public String getBodyCssClass() {
        return bodyCssClass;
    }

    public String getNoIndex() {
        return noIndex;
    }

	public String getRedirectOnLogin() {
		return BooleanUtils.isTrue(redirectOnLogin) ? Boolean.TRUE.toString() : StringUtils.EMPTY;
	}

	public String isUcits() {
		return BooleanUtils.isTrue(isInUcitsSite) ? Boolean.TRUE.toString() : StringUtils.EMPTY;
	}

	public Boolean getHideCanonical() {
		return hideCanonical;
	}

	public String getCanonicalPath() {
		return canonicalPath;
	}

	public Boolean getHreflang() {
		return hreflang;
	}

	public List<HreflangTag> getHreflangLinks() {
		return hreflangLinks;
	}

	public String getEnableUcitsDialog() {
		return BooleanUtils.isTrue(PageUtil.isFeatureEnabled(resourcePage, "enableUcitsDialog")) ? Boolean.TRUE.toString() : StringUtils.EMPTY;
	}


}

