package com.jhi.aem.website.v1.core.models.page;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.PageUtil;

public enum PageType {
    FUND("Fund"),
    RESOURCE("Resource"),
    OTHER("Other");

    PageType(String displayName) {
        this.displayName = displayName;
    }

    private String displayName;

    public String getDisplayName() {
        return displayName;
    }

    public static PageType getForPage(Page page) {
        if (PageUtil.isResourceType(page, ResourcesConstants.RESOURCE_PAGE_RESOURCE_TYPE)) {
            return RESOURCE;
        }
        if (PageUtil.isResourceType(page, ResourcesConstants.FUND_CLASS_PAGE_RESOURCE_TYPE)) {
            return FUND;
        }
        return OTHER;
    }
}
