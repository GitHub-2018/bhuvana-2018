package com.jhi.aem.website.v1.core.models.contact;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContactFormModel {

    private static final String SUBMIT_SUFFIX = ".submit.noCache.json";

    @Inject
    private String heading;

    @Inject
    private String intro;

    @Inject
    private String note;

    @Inject
    private String sendLabel;

    @Inject
    private String titleLabel;

    @Inject
    private String firstNameLabel;

    @Inject
    private String lastNameLabel;

    @Inject
    private String emailLabel;

    @Inject
    private String cityLabel;

    @Inject
    private String stateLabel;

    @Inject
    private String zipLabel;

    @Inject
    private String phoneLabel;

    @Inject
    private String accountLabel;

    @Inject
    private String topicLabel;

    @Inject
    private String messageLabel;

    @Inject
    private String titleError;

    @Inject
    private String firstNameError;

    @Inject
    private String lastNameError;

    @Inject
    private String emailError;

    @Inject
    private String cityError;

    @Inject
    private String stateError;

    @Inject
    private String zipError;

    @Inject
    private String topicError;

    @Inject
    private String messageError;

    @Inject
    private String thankyouHeading;

    @Inject
    private String thankyouNote;

    @Inject
    private String sendAnotherLabel;

    @Inject
    private Resource resource;

    public String getHeading() {
        return heading;
    }

    public String getIntro() {
        return intro;
    }

    public String getNote() {
        return note;
    }

    public String getSendLabel() {
        return sendLabel;
    }

    public String getTitleLabel() {
        return titleLabel;
    }

    public String getFirstNameLabel() {
        return firstNameLabel;
    }

    public String getLastNameLabel() {
        return lastNameLabel;
    }

    public String getEmailLabel() {
        return emailLabel;
    }

    public String getCityLabel() {
        return cityLabel;
    }

    public String getStateLabel() {
        return stateLabel;
    }

    public String getZipLabel() {
        return zipLabel;
    }

    public String getPhoneLabel() {
        return phoneLabel;
    }

    public String getAccountLabel() {
        return accountLabel;
    }

    public String getTopicLabel() {
        return topicLabel;
    }

    public String getMessageLabel() {
        return messageLabel;
    }

    public String getTitleError() {
        return titleError;
    }

    public String getFirstNameError() {
        return firstNameError;
    }

    public String getLastNameError() {
        return lastNameError;
    }

    public String getEmailError() {
        return emailError;
    }

    public String getCityError() {
        return cityError;
    }

    public String getStateError() {
        return stateError;
    }

    public String getZipError() {
        return zipError;
    }

    public String getTopicError() {
        return topicError;
    }

    public String getMessageError() {
        return messageError;
    }

    public String getThankyouHeading() {
        return thankyouHeading;
    }

    public String getThankyouNote() {
        return thankyouNote;
    }

    public String getSendAnotherLabel() {
        return sendAnotherLabel;
    }

    public String getSubmitPath() {
        return resource.getPath() + SUBMIT_SUFFIX;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(heading) && StringUtils.isBlank(intro);
    }
}
