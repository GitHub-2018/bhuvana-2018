package com.jhi.aem.website.v1.core.models.contact;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.DateUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContactFormEntryModel {

    public static final String ID_PARAMETER = "id";
    public static final String TIMESTAMP_PARAMETER = "timestamp";
    public static final String FIRST_NAME_PARAMETER = "first-name";
    public static final String LAST_NAME_PARAMETER = "last-name";
    public static final String EMAIL_PARAMETER = "email";
    public static final String CITY_PARAMETER = "city";
    public static final String STATE_PARAMETER = "state";
    public static final String ZIP_PARAMETER = "zip";
    public static final String PHONE_PARAMETER = "phone";
    public static final String TOPIC_PARAMETER = "topic";
    public static final String MESSAGE_PARAMETER = "message";

    @Inject
    private String id;

    @Inject
    private Calendar timestamp;

    @Inject
    @Named("first-name")
    private String firstName;

    @Inject
    @Named("last-name")
    private String lastName;

    @Inject
    private String email;

    @Inject
    private String city;

    @Inject
    private String state;

    @Inject
    private String zip;

    @Inject
    private String phone;

    @Inject
    private String topic;

    @Inject
    private String message;

    @Inject
    private String title;

    @Inject
    @Named("account")
    private String accountNumber;

    @Inject
    private Page resourcePage;

    public ContactFormEntryModel() {
    }

    public ContactFormEntryModel(String id, Calendar timestamp, String firstName, String lastName,
                                 String email, String city, String state, String zip, String phone, String topic,
                                 String message) {
        super();
        this.id = id;
        this.timestamp = timestamp;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.phone = phone;
        this.topic = topic;
        this.message = message;
    }

    public ContactFormEntryModel(SlingHttpServletRequest request) {
        super();
        this.id = UUID.randomUUID().toString();
        this.timestamp = Calendar.getInstance(Locale.US);
        this.firstName = request.getParameter(FIRST_NAME_PARAMETER);
        this.lastName = request.getParameter(LAST_NAME_PARAMETER);
        this.email = request.getParameter(EMAIL_PARAMETER);
        this.city = request.getParameter(CITY_PARAMETER);
        this.state = request.getParameter(STATE_PARAMETER);
        this.zip = request.getParameter(ZIP_PARAMETER);
        this.phone = request.getParameter(PHONE_PARAMETER);
        this.topic = request.getParameter(TOPIC_PARAMETER);
        this.message = request.getParameter(MESSAGE_PARAMETER);
    }

    public Map<String, Object> toProperties() {
        final Map<String, Object> result = new HashMap<>();

        result.put(JcrConstants.JCR_PRIMARYTYPE, JcrConstants.NT_UNSTRUCTURED);
        result.put(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY,
                ResourcesConstants.CONTACT_FORM_ENTRY_RESOURCE_TYPE);

        result.put(ID_PARAMETER, this.id);
        result.put(TIMESTAMP_PARAMETER, this.timestamp);
        result.put(FIRST_NAME_PARAMETER, this.firstName);
        result.put(LAST_NAME_PARAMETER, this.lastName);
        result.put(EMAIL_PARAMETER, this.email);
        result.put(CITY_PARAMETER, this.city);
        result.put(STATE_PARAMETER, this.state);
        result.put(ZIP_PARAMETER, this.zip);
        result.put(PHONE_PARAMETER, this.phone);
        result.put(TOPIC_PARAMETER, this.topic);
        result.put(MESSAGE_PARAMETER, this.message);

        return result;
    }
    
    public String getId() {
        return id;
    }

    public Calendar getTimestamp() {
        return timestamp;
    }

    public String getFormattedTimestamp() {
        return DateUtil.getFormattedDateTime(timestamp, resourcePage);
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFormattedName() {
        return String.format("%s %s", firstName, lastName);
    }

    public String getEmail() {
        return email;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZip() {
        return zip;
    }

    public String getPhone() {
        return phone;
    }

    public String getTopic() {
        return topic;
    }

    public String getMessage() {
        return message;
    }

    // Title and Account Number are captured in the old entries prior to when these fields were removed from the form
    public String getTitle() {
        return title;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public boolean isValid() {
        return timestamp != null && StringUtils.isNotBlank(id)
                && StringUtils.isNotBlank(firstName) && StringUtils.isNotBlank(lastName)
                && StringUtils.isNotBlank(email) && StringUtils.isNotBlank(city) && StringUtils.isNotBlank(state)
                && StringUtils.isNotBlank(zip) && StringUtils.isNotBlank(topic) && StringUtils.isNotBlank(message);
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("id=");
		builder.append(id);
		builder.append(", timestamp=");
		builder.append(timestamp);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", email=");
		builder.append(email);
		builder.append(", city=");
		builder.append(city);
		builder.append(", state=");
		builder.append(state);
		builder.append(", zip=");
		builder.append(zip);
		builder.append(", phone=");
		builder.append(phone);
		builder.append(", topic=");
		builder.append(topic);
		builder.append(", message=");
		builder.append(message);
		return builder.toString();
	}
	
	public String getFormContentAsString() {
		StringBuilder builder = new StringBuilder();

		builder.append(city);
		builder.append(",");
		builder.append(state);
		builder.append(",");
		builder.append(zip);
		builder.append(",");
		builder.append(phone);
		builder.append(",");
		builder.append(topic);
		builder.append(",");
		builder.append(message);
		
		return builder.toString();
	}
	
	 //##Fix for ticket 1930
    // Created a new method to load email content as Set object
	
	public Set<String> getFormContentAsObject() {
		Set<String> contentSet = new LinkedHashSet<String>();
		contentSet.add(city);
		contentSet.add(state);
		contentSet.add(zip);
		contentSet.add(phone);
		contentSet.add(topic);
		contentSet.add(message);

		
		return contentSet;
		
	}
}
