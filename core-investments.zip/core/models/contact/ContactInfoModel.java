package com.jhi.aem.website.v1.core.models.contact;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContactInfoModel {

	@Inject
	@Optional
	private String heading1;

	@Inject
	@Optional
	private String title1;

	@Inject
	@Optional
	private String text1;

	@Inject
	@Optional
	private String heading2;

	@Inject
	@Optional
	private String title2;

	@Inject
	@Optional
	private String text2;

	@Inject
	@Optional
	private String heading3;

	@Inject
	@Optional
	private String title3;

	@Inject
	@Optional
	private String text3;

	@Inject
	@Optional
	private String heading4;

	@Inject
	@Optional
	private String title4;

	@Inject
	@Optional
	private String text4;

	public String getHeading1() {
		return heading1;
	}

	public String getTitle1() {
		return title1;
	}

	public String getText1() {
		return text1;
	}

	public String getHeading2() {
		return heading2;
	}

	public String getTitle2() {
		return title2;
	}

	public String getText2() {
		return text2;
	}

	public String getHeading3() {
		return heading3;
	}

	public String getTitle3() {
		return title3;
	}

	public String getText3() {
		return text3;
	}

	public String getHeading4() {
		return heading4;
	}

	public String getTitle4() {
		return title4;
	}

	public String getText4() {
		return text4;
	}

	public boolean isBlank() {
		return StringUtils.isBlank(heading1) && StringUtils.isBlank(title1) && StringUtils.isBlank(heading2)
				&& StringUtils.isBlank(title2) && StringUtils.isBlank(heading3) && StringUtils.isBlank(title3)
				&& StringUtils.isBlank(heading4) && StringUtils.isBlank(title4);
	}
}
