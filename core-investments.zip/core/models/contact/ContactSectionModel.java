package com.jhi.aem.website.v1.core.models.contact;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContactSectionModel {

    @ValueMapValue
    private String heading;

    @ValueMapValue
    private String subheading;

    @ValueMapValue
    private String phone;

    @ValueMapValue
    private String phoneDescription;

    @ValueMapValue
    private String subtext;

    @ValueMapValue
    private String address1;

    @ValueMapValue
    private String addressDescription1;

    @ValueMapValue
    private String address2;

    @ValueMapValue
    private String addressDescription2;

    public String getHeading() {
        return heading;
    }

    public String getSubheading() {
        return subheading;
    }

    public String getPhone() {
        return phone;
    }

    public String getPhoneDescription() {
        return phoneDescription;
    }

    public String getSubtext() {
        return subtext;
    }

    public String getAddressDescription1() {
        return addressDescription1;
    }

    public String getAddressDescription2() {
        return addressDescription2;
    }

    public String getAddress1() {
        return address1;
    }

    public String getAddress2() {
        return address2;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(heading);
    }
}
