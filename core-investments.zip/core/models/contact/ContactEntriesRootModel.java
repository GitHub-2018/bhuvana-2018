package com.jhi.aem.website.v1.core.models.contact;

import java.util.Collections;

import javax.annotation.PostConstruct;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.constants.JhiConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContactEntriesRootModel {

	private static final Logger LOG = LoggerFactory.getLogger(ContactEntriesRootModel.class);
	
	@OSGiService
    private ResourceResolverFactory resolverFactory;

    private Resource contactEntriesRoot;
    
    @PostConstruct
    private void init() {
    	ResourceResolver resolver;
		try {
			resolver = resolverFactory.getServiceResourceResolver(
			        Collections.singletonMap(ResourceResolverFactory.SUBSERVICE, JhiConstants.JHI_ADMIN_SERVICE_USER));
			contactEntriesRoot = resolver.getResource(JhiConstants.CONTACT_ENTRIES_PATH);
		} catch (LoginException e) {
			LOG.error("Exception initializing ContactEntriesRootModel", e);
		}
    }
    
    public Resource getContactEntriesRoot() {
    	return contactEntriesRoot;
    }
}
