package com.jhi.aem.website.v1.core.models.contact;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContactSectionIntroModel {

	@Inject
	@Optional
	private String title;

	@Inject
	@Optional
	private String text;

	public String getTitle() {
		return title;
	}

	public String getText() {
		return text;
	}

	public boolean isBlank() {
		return StringUtils.isBlank(title) && StringUtils.isBlank(text);
	}
}
