package com.jhi.aem.website.v1.core.models.contact;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContactSectionShortModel {

	@Inject
	@Optional
	private String heading;

	@Inject
	@Optional
	private String phone;

	@Inject
	@Optional
	private String subtext;

	public String getHeading() {
		return heading;
	}

	public String getPhone() {
		return phone;
	}

	public String getSubtext() {
		return subtext;
	}

	public boolean isBlank() {
		return StringUtils.isBlank(heading) && StringUtils.isBlank(phone) && StringUtils.isBlank(subtext);
	}
}
