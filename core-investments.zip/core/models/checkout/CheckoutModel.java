package com.jhi.aem.website.v1.core.models.checkout;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CheckoutModel {

    private static final String ADDRESS_OPTIONS_SELECTOR = "addressOptions";
    private static final String ADDRESS_OPTIONS_PART = JhiConstants.DOT + ADDRESS_OPTIONS_SELECTOR + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;

    private static final String CART_ITEMS_SELECTOR = "cartItems";
    private static final String CART_ITEMS_PART = JhiConstants.DOT + CART_ITEMS_SELECTOR + JhiConstants.DOT
            + JhiConstants.NO_CACHE_SELECTOR + JhiConstants.URL_HTML_EXTENSION;

    @Inject
    @Default
    private String title;

    @Inject
    @Default(values = "PLACE ORDER")
    private String placeOrderLabel;

    @Inject
    @Default
    private String cartContentHeader;

    @Inject
    @Default(values = "Quantity:")
    private String quantityLabel;

    @Inject
    @Default(values = "Total items:")
    private String totalItemsLabel;

    @Inject
    @Default
    private String shippingAddressLabel;

    @Inject
    @Default(values = "Enter new address")
    private String newAddressText;

    @Inject
    @Default(values = "Address name (e.g. \"office\")")
    private String addressNameLabel;

    @Inject
    @Default(values = "Full Name")
    private String fullNameLabel;

    @Inject
    @Default(values = "Address")
    private String addressLabel;

    @Inject
    @Default(values = "Apt, suite, etc")
    private String buildingDetailLabel;

    @Inject
    @Default(values = "City")
    private String cityLabel;

    @Inject
    @Default(values = "State")
    private String stateLabel;

    @Inject
    @Default(values = "Zip")
    private String zipLabel;

    @Inject
    @Default(values = "Phone number (optional)")
    private String phoneLabel;

    @Inject
    @Default(values = "Save address to address book")
    private String saveAddressLabel;

    @Inject
    @Default(values = "Return to cart")
    private String returnToCartLabel;

    @Inject
    @Default
    private String submitErrorMessage;

    @Inject
    private Page resourcePage;

    @Self
    private Resource resource;

    private Page cartPage;

    private String resourceMappedPath;

    @PostConstruct
    protected void init() {
        resourceMappedPath = resource.getResourceResolver().map(resource.getPath());
    }

    public String getTitle() {
        return title;
    }

    public String getPlaceOrderLabel() {
        return placeOrderLabel;
    }

    public String getCartContentHeader() {
        return cartContentHeader;
    }

    public String getQuantityLabel() {
        return quantityLabel;
    }

    public String getTotalItemsLabel() {
        return totalItemsLabel;
    }

    public String getShippingAddressLabel() {
        return shippingAddressLabel;
    }

    public String getNewAddressText() {
        return newAddressText;
    }

    public String getAddressNameLabel() {
        return addressNameLabel;
    }

    public String getFullNameLabel() {
        return fullNameLabel;
    }

    public String getAddressLabel() {
        return addressLabel;
    }

    public String getBuildingDetailLabel() {
        return buildingDetailLabel;
    }

    public String getCityLabel() {
        return cityLabel;
    }

    public String getStateLabel() {
        return stateLabel;
    }

    public String getZipLabel() {
        return zipLabel;
    }

    public String getPhoneLabel() {
        return phoneLabel;
    }

    public String getSaveAddressLabel() {
        return saveAddressLabel;
    }

    public String getReturnToCartLabel() {
        return returnToCartLabel;
    }

    public String getSubmitErrorMessage() {
        return submitErrorMessage;
    }

    public String getCartLink() {
        return LinkUtil.getPageLink(getCartPage());
    }

    private Page getCartPage() {
        if (cartPage == null) {
            cartPage = PageUtil.getSitePageByResourceType(resourcePage, ResourcesConstants.CART_PAGE_RESOURCE_TYPE);
        }
        return cartPage;
    }

    public String getAddressOptionsContentPath() {
        return resourceMappedPath + ADDRESS_OPTIONS_PART;
    }

    public String getCartItemsContentPath() {
        return resourceMappedPath + CART_ITEMS_PART;
    }
}
