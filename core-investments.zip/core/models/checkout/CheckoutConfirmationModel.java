package com.jhi.aem.website.v1.core.models.checkout;

import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.CommerceService;
import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.commerce.api.PlacedOrder;
import com.jhi.aem.website.v1.core.commerce.rrd.RrdOrderUtils;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.servlets.checkout.CheckoutServlet;

@Model(adaptables = SlingHttpServletRequest.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CheckoutConfirmationModel {

    private static final Logger LOGGER = LoggerFactory.getLogger(CheckoutConfirmationModel.class);
    private static final String ORDER_ID_PLACEHOLDER = "${orderId}";

    @Inject
    @Via("resource")
    @Default(values = "Your order number is ${orderId}.")
    private String orderNumberText;

    @Inject
    @Via("resource")
    @Default
    private String viewAllOrdersLabel;

    @Inject
    @Via("resource")
    @Default
    private String shippedToLabel;

    @Inject
    @Via("resource")
    @Default
    private String itemsShippedLabel;

    @Self
    private SlingHttpServletRequest request;

    @SlingObject
    private SlingHttpServletResponse response;

    private Long orderId;

    private PlacedOrder order;

    private List<CommerceSession.CartEntry> orderedItems;

    @PostConstruct
    protected void init() {
        final String orderIdString = StringUtils.defaultString(request.getParameter(CheckoutServlet.ORDER_ID_PARAMETER));
        final Resource resource = request.getResource();
        final CommerceService commerceService = resource.adaptTo(CommerceService.class);
        if (commerceService != null) {
            try {
                final CommerceSession commerceSession = commerceService.login(request, response);
                if (StringUtils.isNotBlank(orderIdString)) {
                    orderId = RrdOrderUtils.parseOrderId(orderIdString);
                    order = commerceSession.getPlacedOrder(orderId.toString());
                    if (order != null) {
                        orderedItems = order.getCartEntries();
                    } else {
                        orderedItems = Collections.emptyList();
                    }
                }
                commerceSession.logout();
            } catch (CommerceException e) {
                LOGGER.error("Problem while getting placed order", e);
            }
        }
    }

    public String getOrderNumberText() {
        if (StringUtils.contains(orderNumberText, JhiConstants.PLACEHOLDER_START)) {
            return StringUtils.replace(orderNumberText, ORDER_ID_PLACEHOLDER, orderId != null ? orderId.toString() : StringUtils.EMPTY);
        }
        return orderNumberText + StringUtils.SPACE + orderId;
    }

    public String getOrderNumber() {
        return orderId != null ? orderId.toString() : StringUtils.EMPTY;
    }

    public String getAllOrdersPath() {
        return StringUtils.EMPTY;
    }

    public String getViewAllOrdersLabel() {
        return viewAllOrdersLabel;
    }

    public String getShippedToLabel() {
        return shippedToLabel;
    }

    public String getItemsShippedLabel() {
        return itemsShippedLabel;
    }

    public PlacedOrder getOrder() {
        return order;
    }

    public List<CommerceSession.CartEntry> getOrderedItems() {
        return orderedItems;
    }
}
