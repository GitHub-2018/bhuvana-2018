package com.jhi.aem.website.v1.core.models.news;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.news.NewsService;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NewsSectionModel {

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String allNewsLabel;

    @ValueMapValue
    private String allNewsUrl;

    @ValueMapValue
    private String readMoreLabel;

    @Inject
    private Page resourcePage;

    @SlingObject
    private ResourceResolver resolver;

    @OSGiService
    private NewsService service;

    private List<NewsPageModel> news;

    @PostConstruct
    private void init() {
        news = service.getNews(resourcePage).stream()
                .limit(4)
                .collect(Collectors.toList());
    }

    public String getTitle() {
        return title;
    }

    public String getAllNewsLabel() {
        return allNewsLabel;
    }

    public String getAllNewsUrl() {
        return LinkUtil.getLink(allNewsUrl);
    }

    public String getReadMoreLabel() {
        return readMoreLabel;
    }

    public List<NewsPageModel> getNews() {
        return news;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(allNewsLabel) && StringUtils.isBlank(allNewsUrl)
                && StringUtils.isBlank(readMoreLabel);
    }
}
