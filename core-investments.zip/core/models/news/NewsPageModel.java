package com.jhi.aem.website.v1.core.models.news;

import java.util.Calendar;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.utils.DateUtil;
import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NewsPageModel implements Comparable<NewsPageModel> {

    @Inject
    @Named("jcr:title")
    private String title;

    @Inject
    private String summary;

    @Inject
    private Calendar articlePublished;

    @Inject
    private Page resourcePage;

    private String url;

    @PostConstruct
    public void init() {
        url = LinkUtil.getLink(resourcePage.getPath());
    }

    public String getTitle() {
        return title;
    }

    public String getSummary() {
        return summary;
    }

    public Calendar getArticlePublished() {
        return articlePublished;
    }

    public String getFormattedDate() {
        return DateUtil.getFormattedFullDate(articlePublished, resourcePage);
    }

    public String getUrl() {
        return url;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(title) && StringUtils.isBlank(summary) && articlePublished == null
                && StringUtils.isBlank(url);
    }

    @Override
    public int compareTo(@Nonnull NewsPageModel o) {
        if (articlePublished == null) {
            return -1;
        }
        if (o.articlePublished == null) {
            return 1;
        }
        return o.articlePublished.compareTo(articlePublished);
    }
}
