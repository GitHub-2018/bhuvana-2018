package com.jhi.aem.website.v1.core.models.loginform;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.utils.LinkUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class LoginFormModel {

    @Inject
    private String heading;

    @Inject
    private String usernameLabel;

    @Inject
    private String passwordLabel;

    @Inject
    private String submitButtonLabel;

    @Inject
    private String forgotPasswordLabel;

    @Inject
    private String forgotPasswordLink;

    @Inject
    private String redirectLink;

    @Inject
    private String registerLink;

    @Inject
    private String registerLabel;
    
    @Inject
    private ResourceResolver resourceResolver;

    public String getHeading() {
        return heading;
    }

    public String getUsernameLabel() {
        return usernameLabel;
    }

    public String getPasswordLabel() {
        return passwordLabel;
    }

    public String getSubmitButtonLabel() {
        return submitButtonLabel;
    }

    public String getForgotPasswordLabel() {
        return forgotPasswordLabel;
    }

    public String getForgotPasswordLink() {
        return LinkUtil.getLink(resourceResolver, forgotPasswordLink);
    }

    public String getRedirectLink() {
        return LinkUtil.getLink(resourceResolver, redirectLink);
    }

    public String getRegisterLink() {
        return registerLink;
    }

    public String getRegisterLabel() {
        return registerLabel;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(heading) && StringUtils.isBlank(usernameLabel) && StringUtils.isBlank(passwordLabel)
                && StringUtils.isBlank(submitButtonLabel) && StringUtils.isBlank(forgotPasswordLabel)
                && StringUtils.isBlank(forgotPasswordLink) && StringUtils.isBlank(redirectLink)
                && StringUtils.isBlank(registerLabel) && StringUtils.isBlank(registerLink);
    }
}
