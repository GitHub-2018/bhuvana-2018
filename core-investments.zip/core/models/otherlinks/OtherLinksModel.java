package com.jhi.aem.website.v1.core.models.otherlinks;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.generic.link.SimpleLink;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.ResourceResolverUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class OtherLinksModel {

    @Inject
    private String upperLinksTitle;

    @Inject
    private String description;

    @Inject
    private List<Resource> upperLinks;

    @Inject
    private String bottomLinksTitle;

    @Inject
    private List<Resource> bottomLinks;
    
    @Inject
    private String middleLinksTitle;

    @Inject
    private List<Resource> middleLinks;

    @Inject
    private Page resourcePage;

    @Inject
    private ResourceResolverFactory factory;

    private List<SimpleLink> upperLinkList;
    private List<SimpleLink> bottomLinkList;
    private List<SimpleLink> middleLinkList;

    @PostConstruct
    public void init() {
        ResourceResolver resolver = ResourceResolverUtil.getResourceResolver(factory);

        upperLinkList = (upperLinks != null )?LinkUtil.prepareLinks(resolver, upperLinks):null;
        middleLinkList =(middleLinks != null)? LinkUtil.prepareLinks(resolver, middleLinks):null;
        bottomLinkList = (bottomLinks != null)?LinkUtil.prepareLinks(resolver, bottomLinks):null;

        if (resolver.isLive()) {
            resolver.close();
        }
    }

    public List<SimpleLink> getUpperLinkList() {
        return upperLinkList;
    }

    public List<SimpleLink> getBottomLinkList() {
        return bottomLinkList;
    }
    public List<SimpleLink> getMiddleLinkList() {
        return middleLinkList;
    }

    public String getUpperLinksTitle() {
        return upperLinksTitle;
    }

    public String getDescription() {
        return description;
    }

    public String getMiddleLinksTitle() {
        return middleLinksTitle;
    }
    public String getBottomLinksTitle() {
        return bottomLinksTitle;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(upperLinksTitle) && StringUtils.isBlank(bottomLinksTitle);
    }

}
