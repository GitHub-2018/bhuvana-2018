package com.jhi.aem.website.v1.core.models.sitemap;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.google.gson.GsonBuilder;
import com.jhi.aem.website.v1.core.service.assetmanager.AssetManagerService;
import com.jhi.aem.website.v1.core.service.fund.FundService;
import com.jhi.aem.website.v1.core.service.fund.listing.FundDto;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListService;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListingType;
import com.jhi.aem.website.v1.core.service.fund.listing.InvestmentTypeDto;
import com.jhi.aem.website.v1.core.service.fund.listing.ProductTypeDto;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SitemapModel {
    private final static Logger LOG = LoggerFactory.getLogger(SitemapModel.class);

    private static GsonBuilder gsonBuilder = new GsonBuilder();

    @Inject
    @Via("resource")
    private String header;
    
    @Inject
    @Via("resource")
    private Page resourcePage;

    @Inject
    @Via("resource")
    private ResourceResolver resourceResolver;

    @Inject
    @Via("resource")
    private String sectionLinks1Title;

    @Inject
    @Via("resource")
    private List<SectionLink> sectionLinks1Links;

    @Inject
    @Via("resource")
    private String sectionLinks2Title;

    @Inject
    @Via("resource")
    private List<SectionLink> sectionLinks2Links;

    @Inject
    @Via("resource")
    private String sectionLinks3Title;

    @Inject
    @Via("resource")
    private List<SectionLink> sectionLinks3Links;

    @Self
    private SlingHttpServletRequest request;

    @OSGiService
    private FundService fundService;

    @OSGiService
    private FundListService fundListService;

    @OSGiService
    private AssetManagerService assetManagerService;

    private Collection<ProductTypeDto> productTypes;
    
	private String ucitsCountry;

	private boolean inUcitsSite;

  //  private List<SectionLink> sectionLinks1;

  //  private List<SectionLink> sectionLinks2;

  //  private List<SectionLink> sectionLinks3;
	
	private class UcitsProductTypeDtoDecorator extends ProductTypeDto {
		private ProductTypeDto productTypeDto;
		private List<FundDto> allFundsSorted;

		UcitsProductTypeDtoDecorator(ProductTypeDto productTypeDto) {
			this.productTypeDto = productTypeDto;
			this.allFundsSorted = productTypeDto.getAllFundsSorted();
			
			if (inUcitsSite && StringUtils.isNotEmpty(ucitsCountry)) {
				allFundsSorted = allFundsSorted.stream()
						.filter(fund -> {
								boolean anyMatch = fund.getShareClasses().stream().anyMatch(
		        						shareClass -> {
		        							boolean anyCountryMatch = shareClass.getUcitsCountries().contains(ucitsCountry);
		        							if (LOG.isDebugEnabled()) {
		        								LOG.debug("Match for share class {} with {} ({}): {}",
		        										new Object[] {shareClass.getShareClass(), ucitsCountry, shareClass.getUcitsCountries(), anyCountryMatch});
		        							}
		        							return anyCountryMatch;
		        						});
								if (LOG.isDebugEnabled()) {
									LOG.debug("Match for fund {}: {}", fund.getFundId(), anyMatch);
								}
								return anyMatch;
							})
						.collect(Collectors.toCollection(LinkedList::new));
			}
		}
		
		@Override
		public List<InvestmentTypeDto> getInvestmentTypes() {
			return productTypeDto.getInvestmentTypes();
		}
		
		@Override
		public String getTitle() {
			return productTypeDto.getTitle();
		}
		
		@Override
		public List<FundDto> getAllFundsSorted() {
			return allFundsSorted;
		}

	}
    
	@PostConstruct
    protected void init() {
		inUcitsSite = PageUtil.isInUcitsSite(resourcePage);
        ucitsCountry = inUcitsSite ? PageUtil.getUcitsCountry(request) : StringUtils.EMPTY;
        
        productTypes = fundListService.getFundListing(resourcePage,
        		inUcitsSite ? FundListingType.UCITS_ONLY : FundListingType.NON_UCITS);
        
        if (inUcitsSite) {
        	productTypes = productTypes.stream()
        			.map(productType -> new UcitsProductTypeDtoDecorator(productType))
        			.collect(Collectors.toCollection(LinkedList::new));
        }
    }

    public String getHeader() {
    	return header;
    }
    
    public String getSectionLinks1Title() {
        return sectionLinks1Title;
    }

    public String getSectionLinks2Title() {
        return sectionLinks2Title;
    }

    public String getSectionLinks3Title() {
        return sectionLinks3Title;
    }

    public List<SectionLink> getSectionLinks1() {
        return sectionLinks1Links;
    }

    public List<SectionLink> getSectionLinks2() {
        return sectionLinks2Links;
    }

    public List<SectionLink> getSectionLinks3() {
        return sectionLinks3Links;
    }

    public Collection<ProductTypeDto> getProductTypes() {
        return productTypes;
    }
    
    public String getUcitsCountry() {
		return ucitsCountry;
	}


}
