package com.jhi.aem.website.v1.core.models.viewpoint_author;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.models.person.PersonalBiographyDetails;
import com.jhi.aem.website.v1.core.models.viewpoint_asset_manager.ViewpointsAssetManagerModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.TextUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointsAuthorDetails {

    public static final String AUTHOR_REFERENCE = "authorReference";
    public static final int BIOGRAPHY_EXCEPT_LENGTH = 100;
    public static final int BIOGRAPHY_SHORT_LENGTH = 200;
    public static final ViewpointsAuthorDetails EMPTY = new ViewpointsAuthorDetails();

    @Inject
    @Default
    private String name;

    @Inject
    @Default
    private String position;

    @Inject
    @Optional
    private ImageModel image;

    @Inject
    @Default
    private String biography;

    @Inject
    @Default
    private String assetManager;

    @Inject
    private PageManager pageManager;

    private ViewpointsAssetManagerModel assetManagerModel;
    private String viewpointsLink = StringUtils.EMPTY;

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public String getImagePath() {
        return ImageModel.getImagePath(image);
    }

    public String getBiography() {
        return biography;
    }

    public String getBiographyExcerpt() {
        return TextUtil.getLimitedText(biography, BIOGRAPHY_EXCEPT_LENGTH);
    }

    public String getBiographyShort() {
        return TextUtil.getLimitedText(biography, BIOGRAPHY_SHORT_LENGTH);
    }

    public ViewpointsAssetManagerModel getAssetManager() {
        if (assetManagerModel == null) {
            if (StringUtils.isNotBlank(assetManager)) {
                Page assetManagerPage = pageManager.getPage(assetManager);
                if (assetManagerPage != null) {
                    assetManagerModel = ViewpointsAssetManagerModel.fromAssetManagerPage(assetManagerPage);
                }
            }
        }
        return assetManagerModel;
    }

    public String getViewpointsLink() {
        return viewpointsLink;
    }

    public boolean isBlank() {
        return StringUtils.isAnyBlank(name, biography, assetManager);
    }

    public static ViewpointsAuthorDetails fromPersonPage(Page page) {
        return PageUtil.getModelFromPage(page, PersonalBiographyDetails.PERSONAL_BIOGRAPHY_PATH, ViewpointsAuthorDetails.class, EMPTY);
    }

    public static ViewpointsAuthorDetails fromAuthorPage(Page page) {
        if (page != null) {
            String authorReferencePath = PageUtil.getPageContentProperty(page, AUTHOR_REFERENCE, String.class);
            if (StringUtils.isBlank(authorReferencePath)) {
                String peopleRootPath = PageUtil.getPeopleRootPath(page);
                if (StringUtils.isNotBlank(peopleRootPath)) {
                    authorReferencePath = peopleRootPath + JhiConstants.SLASH + page.getName();
                }
            }
            if (StringUtils.isNotBlank(authorReferencePath)) {
                PageManager pageManager = page.getContentResource().getResourceResolver().adaptTo(PageManager.class);
                if (pageManager != null) {
                    Page biographyPage = pageManager.getPage(authorReferencePath);
                    if (biographyPage != null) {
                        ViewpointsAuthorDetails viewpointsAuthorDetails = ViewpointsAuthorDetails.fromPersonPage(biographyPage);
                        viewpointsAuthorDetails.viewpointsLink = LinkUtil.getPageLink(page);
                        return viewpointsAuthorDetails;
                    }
                }
            }
        }
        return EMPTY;
    }
}
