package com.jhi.aem.website.v1.core.models.viewpoint_author;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointsAuthorHeaderModel {

    @Inject
    protected ResourceResolver resourceResolver;

    @Inject
    private Page resourcePage;

    private ViewpointsAuthorDetails viewpointsAuthorDetails;

    @PostConstruct
    protected void init() {
        viewpointsAuthorDetails = ViewpointsAuthorDetails.fromAuthorPage(resourcePage);
    }

    public ViewpointsAuthorDetails getAuthor() {
        return viewpointsAuthorDetails;
    }

    public boolean isBlank() {
        return viewpointsAuthorDetails == null || viewpointsAuthorDetails.isBlank();
    }
}