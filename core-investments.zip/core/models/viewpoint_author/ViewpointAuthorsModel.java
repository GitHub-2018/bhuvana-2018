package com.jhi.aem.website.v1.core.models.viewpoint_author;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.models.viewpoint_asset_manager.ViewpointsAssetManagerModel;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables = Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class ViewpointAuthorsModel {

    public static final String VIEWPOINT_AUTHORS_PROPERTY = "viewpointAuthors";
    public static final int MULTIPLE_AUTORS_COUNT = 2;

    @Inject
    private Page resourcePage;

    @Inject
    private PageManager pageManager;

    private List<ViewpointsAuthorDetails> authorsDetailsList;
    private List<ViewpointsAssetManagerModel> assetManagersList;

    @PostConstruct
    protected void init() {
        if (resourcePage != null) {
            String[] authorsPaths = getAuthorsPaths(resourcePage);
            if (authorsPaths != null) {
                authorsDetailsList = new ArrayList<>(authorsPaths.length);
                assetManagersList = new ArrayList<>(authorsPaths.length);
                List<String> addedElements = new ArrayList<>(2 * authorsPaths.length);
                for (String authorPath : authorsPaths) {
                    Page authorPage = pageManager.getPage(authorPath);
                    ViewpointsAuthorDetails viewpointsAuthorDetails = ViewpointsAuthorDetails.fromAuthorPage(authorPage);
                    if (viewpointsAuthorDetails != null && !viewpointsAuthorDetails.isBlank()
                            && !addedElements.contains(viewpointsAuthorDetails.getViewpointsLink())) {
                        authorsDetailsList.add(viewpointsAuthorDetails);
                        addedElements.add(viewpointsAuthorDetails.getViewpointsLink());
                        ViewpointsAssetManagerModel assetManagerModel = viewpointsAuthorDetails.getAssetManager();
                        if (assetManagerModel != null && !addedElements.contains(assetManagerModel.getPageLink())) {
                            assetManagersList.add(assetManagerModel);
                            addedElements.add(assetManagerModel.getPageLink());
                        }
                    }
                }
            }

        }
        if (isAssetManagersBlank() && isAuthorsBlank()) {
            if (assetManagersList == null) {
                assetManagersList = new ArrayList<>(1);
            }
            assetManagersList.add(ViewpointsAssetManagerModel.fetchDefaultAssetManager(resourcePage));
        }
    }

    public ViewpointsAssetManagerModel getAssetManager() {
    	return isAssetManagersBlank() ? null : assetManagersList.stream().findFirst().get();
    }

    public List<ViewpointsAssetManagerModel> getAssetManagers() {
        return assetManagersList;
    }

    public ViewpointsAuthorDetails getAuthor() {
    	return isAuthorsBlank() ? null : authorsDetailsList.stream().findFirst().get();
    }

    public List<ViewpointsAuthorDetails> getAuthors() {
        return authorsDetailsList;
    }

    public boolean isBlank() {
        return isAuthorsBlank() && isAssetManagersBlank();
    }

    public boolean isAuthorsBlank() {
        return authorsDetailsList == null || authorsDetailsList.isEmpty();
    }

    public boolean isAssetManagersBlank() {
        return assetManagersList == null || assetManagersList.isEmpty();
    }

    public boolean isAuthorsVisible() {
        return !isAuthorsBlank() && authorsDetailsList.size() <= MULTIPLE_AUTORS_COUNT;
    }

    public boolean isSingle() {
        return authorsDetailsList != null && authorsDetailsList.size() == 1;
    }

    public static ViewpointAuthorsModel fromPage(Page page) {
        return PageUtil.getModelFromPage(page, StringUtils.EMPTY, ViewpointAuthorsModel.class);
    }

    public static String[] getAuthorsPaths(Page page) {
        return PageUtil.getPageContentProperty(page, VIEWPOINT_AUTHORS_PROPERTY, String[].class);
    }
}
