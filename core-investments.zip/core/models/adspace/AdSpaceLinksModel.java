package com.jhi.aem.website.v1.core.models.adspace;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AdSpaceLinksModel extends AdSpaceModel {

    @Inject
    private String downloadSize;

    @Inject
    private String leftLinkLabel;

    @Inject
    private String leftLinkUrl;

    @Inject
    private String rightLinkLabel;

    @Inject
    private String rightLinkUrl;

    @ChildResource
    private ImageModel rightBackground;

    public String getDownloadSize() {
        return downloadSize;
    }

    public String getLeftLinkLabel() {
        return leftLinkLabel;
    }

    public String getLeftLinkUrl() {
        return LinkUtil.getLink(leftLinkUrl);
    }

    public String getRightLinkLabel() {
        return rightLinkLabel;
    }

    public String getRightLinkUrl() {
        return LinkUtil.getLink(rightLinkUrl);
    }

    public String getRightBackground() {
        return ResourceUtil.getImagePath(rightBackground);
    }
}
