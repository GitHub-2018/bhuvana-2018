package com.jhi.aem.website.v1.core.models.adspace;

import javax.inject.Inject;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;

import com.jhi.aem.website.v1.core.models.image.ImageModel;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AdSpaceModel {

    // not changing to primaryText to not break legacy content
    @Inject
    private String text;

    @Inject
    private String secondaryText;

    @Inject
    private String downloadPath;

    @Inject
    private String downloadLabel;

    @Inject
    private String downloadId;

    @Inject
    private String wrappingClass;

    @Inject
    private Boolean hidden;

    @ChildResource(injectionStrategy = InjectionStrategy.OPTIONAL)
    private ImageModel image;

    @ChildResource(injectionStrategy = InjectionStrategy.OPTIONAL)
    private ImageModel background;

    public String getText() {
        return text;
    }

    public String getSecondaryText() {
        return secondaryText;
    }

    public String getDownloadLink() {
        return LinkUtil.getLink(downloadPath);
    }

    public String getDownloadLabel() {
        return downloadLabel;
    }

    public String getDownloadId() {
        return downloadId;
    }

    public String getWrappingClass() {
        return wrappingClass;
    }

    public boolean isBlank() {
        return StringUtils.isBlank(text) && StringUtils.isBlank(secondaryText) && StringUtils.isBlank(downloadPath) && StringUtils.isBlank(downloadLabel)
                && StringUtils.isBlank(downloadId) && StringUtils.isBlank(wrappingClass);
    }
    
    public boolean getHidden() {
    	return BooleanUtils.isTrue(hidden);
    }

    public String getImage() {
        return ResourceUtil.getImagePath(image);
    }

    public String getBackground() {
        return ResourceUtil.getImagePath(background);
    }
}
