package com.jhi.aem.website.v1.core.models.adspace;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AdSpaceColumnsModel {

	@Inject
	private AdSpaceColumnModel left;

	@Inject
	private AdSpaceColumnModel right;

	public AdSpaceColumnModel getLeft() {
		return left;
	}

	public AdSpaceColumnModel getRight() {
		return right;
	}

	public boolean isBlank() {
		return (left == null || left.isBlank()) && (right == null || right.isBlank());
	}
}
