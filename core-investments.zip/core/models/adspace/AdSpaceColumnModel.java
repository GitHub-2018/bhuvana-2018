package com.jhi.aem.website.v1.core.models.adspace;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.jhi.aem.website.v1.core.models.image.ImageModel;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class AdSpaceColumnModel {

	@Inject
	private String title;

	@Inject
	private String text;

	@Inject
    private ImageModel backgroundImage;
	
	@Inject
	private String backgroundColorFrom;
	
	@Inject
	private String backgroundColorTo;
	
	@Inject
	private String linkUrl;

	@Inject
	private String linkLabel;

	@Inject
	private String linkId;

	public String getTitle() {
		return title;
	}

	public String getText() {
		return text;
	}

	public boolean hasBackground() {
		return ((backgroundImage != null) &&
				!StringUtils.isBlank(backgroundImage.getPath()) &&
				!StringUtils.isBlank(backgroundColorFrom) &&
				!StringUtils.isBlank(backgroundColorTo));
	}
	
	public ImageModel getBackgroundImage() {
		return backgroundImage;
	}

	public String getBackgroundColorFrom() {
		return backgroundColorFrom;
	}

	public String getBackgroundColorTo() {
		return backgroundColorTo;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public String getLinkLabel() {
		return linkLabel;
	}

	public String getLinkId() {
		return linkId;
	}

	public boolean isBlank() {
		return StringUtils.isBlank(title) && StringUtils.isBlank(text) && StringUtils.isBlank(linkUrl)
				&& StringUtils.isBlank(linkLabel) && StringUtils.isBlank(linkId);
	}
}
