package com.jhi.aem.website.v1.core.landingpages.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author cognizant
 *
 */
public class MultifieldHelper {
	private static final Logger LOG = LoggerFactory.getLogger(MultifieldHelper.class);

	public static List<HashMap<String, String>> getMultiFieldValues(String[] map) {
		LOG.debug("Get Multifield Values " );
		List<HashMap<String, String>> fieldList = new ArrayList<HashMap<String, String>>();
		try {
			HashMap<String, String> fieldValues = new HashMap<String, String>();
			ObjectMapper objectMapper = new ObjectMapper();
			for (String item : map) {
				fieldValues = objectMapper.readValue(item, new TypeReference<HashMap<String, String>>() {
				});
				fieldList.add(fieldValues);
			}

		} catch (Exception exception) {
			LOG.error("Exception occured while retriving json vales : " + exception);
		}

		return fieldList;
	}

}
