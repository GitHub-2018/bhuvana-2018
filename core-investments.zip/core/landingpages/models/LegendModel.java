package com.jhi.aem.website.v1.core.landingpages.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.landingpages.utils.MultifieldHelper;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class LegendModel {

	// Logger
	private static final Logger LOG = LoggerFactory.getLogger(LegendModel.class);

	@Inject @Optional
	public boolean needTwo;
	
	@Inject
	@Named("legend")
	public List<Resource> legend;

	private List<Resource> legendList;
	private List<Resource> legendList2;

	@PostConstruct
	protected void init() {

		/*if (legend != null && legend.length > 0) {
			legendList = MultifieldHelper.getMultiFieldValues(legend);
			LOG.info("legendList Values :" + legendList);
		}*/
		legendList = legend;
		
		if(needTwo){
			split(legendList);
		}

	}

	public List<Resource> getLegendList() {
		return legendList;
	}

	public void setLegendList(List<Resource> legendList) {
		this.legendList = legendList;
	}

	// Generic function to split a list in Java 8
		public void split(List<Resource> list)
		{
			int midIndex = (list.size() - 1) / 2;

			List<List<Resource>> lists = new ArrayList<>(list.stream()
									.collect(Collectors.groupingBy(s -> list.indexOf(s) > midIndex))
									.values());

			legendList = lists.get(0);
			setLegendList2(lists.get(1));
			
		}

		public List<Resource> getLegendList2() {
			return legendList2;
		}

		public void setLegendList2(List<Resource> legendList2) {
			this.legendList2 = legendList2;
		}
}
