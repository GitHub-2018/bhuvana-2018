package com.jhi.aem.website.v1.core.landingpages.models;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.models.fund.tags.Fund;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListService;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDto;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDtoDecorator;
import com.jhi.aem.website.v1.core.utils.AdapterUtils;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SelectedFundListModel {

    private static final Logger LOG = LoggerFactory.getLogger(SelectedFundListModel.class);

    @ValueMapValue
    private List<String> funds;

    @ValueMapValue
    private String title;

    @Inject
    private Page resourcePage;

    @OSGiService
    private FundListService service;

    private Set<ShareClassDtoDecorator> shareClasses;

    @PostConstruct
    public void init() {
    	shareClasses = new TreeSet<>();
    	ResourceResolver resolver = resourcePage.getContentResource().getResourceResolver();
        TagManager tagManager = AdapterUtils.adaptTo(resolver, TagManager.class);

        for (String shareClassId : funds) {
    		ShareClassDto shareClassDTO = service.getShareClassListing(resourcePage, shareClassId);

    		if (!ShareClassDto.EMPTY.equals(shareClassDTO)) {
    			// Get the parent fund tag
    			Tag shareClassTag = tagManager.resolve(shareClassId);
    			Tag parentTag = shareClassTag.getParent();
    			
    			// Resolve to a fund
    			Fund fund = parentTag.adaptTo(Fund.class);
    			
    			// Create the decorator with the useFor
    			shareClasses.add(new ShareClassDtoDecorator(fund.getUseFor(), shareClassDTO));
    		}
    	}

    }

    public String getTitle() {
        return title;
    }

    public Set<ShareClassDtoDecorator> getShareClasses() {
        return shareClasses;
    }
}
