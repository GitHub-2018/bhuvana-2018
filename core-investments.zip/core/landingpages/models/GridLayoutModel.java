package com.jhi.aem.website.v1.core.landingpages.models;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.landingpages.models.dto.GridLayoutDTO;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class GridLayoutModel {

    // Logger
    private static final Logger LOG = LoggerFactory.getLogger(GridLayoutModel.class);

    @Inject
    private String layoutTitle;

    @Inject
    private String rows;

    private List<GridLayoutDTO> row;

    @PostConstruct
    protected void init() {

        if (!StringUtils.isBlank(rows) && !StringUtils.isEmpty(rows)) {
            int numberOfrows = Integer.parseInt(rows);

            row = new ArrayList<GridLayoutDTO>();

            for (int i = 0; i < numberOfrows; i++) {
                GridLayoutDTO item = new GridLayoutDTO();
                item.setRowCount(i);
                row.add(item);
                LOG.info("numberOfrows" + row.toString());
            }

        }

    }

    public String getLayoutTitle() {
        return layoutTitle;
    }

    public List<GridLayoutDTO> getRow() {
        return row;
    }

}
