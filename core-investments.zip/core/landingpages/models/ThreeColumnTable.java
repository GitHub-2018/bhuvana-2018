package com.jhi.aem.website.v1.core.landingpages.models;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.jhi.aem.website.v1.core.landingpages.utils.MultifieldHelper;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ThreeColumnTable {

    @Inject
    private List<Resource> table;

    @ValueMapValue
    private String column1Label;

    @ValueMapValue
    private String column2Label;

    @ValueMapValue
    private String column3Label;

    //private List<HashMap<String, String>> tableList;

    @PostConstruct
    protected void init() {
    	
        /*tableList = Optional.ofNullable(table)
                .filter(t -> t.length > 0)
                .map(MultifieldHelper::getMultiFieldValues)
                .orElse(Collections.emptyList());*/
    }

    public List<Resource> getTableList() {
        return table;
    }

    public String getColumn1Label() {
        return column1Label;
    }

    public String getColumn2Label() {
        return column2Label;
    }

    public String getColumn3Label() {
        return column3Label;
    }
}
