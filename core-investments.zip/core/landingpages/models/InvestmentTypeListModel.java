package com.jhi.aem.website.v1.core.landingpages.models;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.service.fund.listing.FundDto;
import com.jhi.aem.website.v1.core.service.fund.listing.FundListService;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDto;
import com.jhi.aem.website.v1.core.service.fund.listing.ShareClassDtoDecorator;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class InvestmentTypeListModel {

    private static final Logger LOG = LoggerFactory.getLogger(InvestmentTypeListModel.class);

    @ValueMapValue
    private String investmentType;

    @ValueMapValue
    private String productType;

    @Inject
    private Page resourcePage;

    @OSGiService
    private FundListService service;

    private List<ShareClassDto> shareClasses;

    @PostConstruct
    public void init() {
        shareClasses = service.getFundListing(resourcePage, productType, investmentType)
                .stream()
                .flatMap(productTypeDto -> productTypeDto.getInvestmentTypes().stream())
                .flatMap(investmentTypeDto -> investmentTypeDto.getFunds().stream())
                .map(this::getShareClassDto)
                .filter(shareClassDto -> !shareClassDto.equals(ShareClassDto.EMPTY))
                .sorted()
                .collect(Collectors.toList());
    }

    private ShareClassDtoDecorator getShareClassDto(FundDto fund) {
        List<ShareClassDto> shareClassDtos = fund.getShareClasses();
        ShareClassDto shareClassDto = Optional.of(shareClassDtos)
                .filter(list -> list.size() == 1)
                .map(list -> list.get(0))
                .orElseGet(() -> filterShareClass(shareClassDtos));

        return new ShareClassDtoDecorator(fund.getUseFor(), shareClassDto);
    }

    private ShareClassDto filterShareClass(List<ShareClassDto> shareClassDtos) {
        if(shareClassDtos.isEmpty()) {
            LOG.debug("No Share classes found for productType: [{}] and investmentType: [{}].", productType, investmentType);
            return ShareClassDto.EMPTY;
        }

        return shareClassDtos.stream()
                .filter(this::filterShareClass)
                .findFirst()
                .orElseGet(() -> {
                    LOG.warn("{}, shareclasses: {}", shareClassDtos.get(0).getFundTitle(),
                            shareClassDtos.stream().map(ShareClassDto::getShareClassCode).collect(Collectors.toList()));
                    return ShareClassDto.EMPTY;
                });

    }

    private boolean filterShareClass(ShareClassDto shareClassDto) {
        boolean isTargetDate = StringUtils.isNotBlank(investmentType) && investmentType.equalsIgnoreCase("target-date");
        String shareClassCode = shareClassDto.getShareClassCode();
        return isTargetDate && shareClassCode.equalsIgnoreCase("r6")
                || !isTargetDate && shareClassCode.equalsIgnoreCase("i");
    }

    public List<ShareClassDto> getShareClasses() {
        return shareClasses;
    }
}
