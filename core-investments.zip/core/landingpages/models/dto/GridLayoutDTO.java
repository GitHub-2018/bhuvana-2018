package com.jhi.aem.website.v1.core.landingpages.models.dto;

public class GridLayoutDTO {

	private int rowCount;

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

}
