package com.jhi.aem.website.v1.core.generic.link;

import java.lang.reflect.Field;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.wcm.api.Page;
import com.google.common.base.CaseFormat;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

public class AnalyticsLink implements Comparable<AnalyticsLink> {
    private String link;
    private String title;
    private String icon;
    private boolean active;
    private String analyticsClass;
    private int eventId;
    private String trackingCode;
    private LinkType linkType;

    public AnalyticsLink(String link, String title, String icon) {
        this.link = link;
        this.title = title;
        this.icon = icon;
        this.analyticsClass = generateAnalyticsClass(title);
        this.linkType = LinkType.GENERIC;
    }

    public AnalyticsLink(String link, String title, String icon, boolean active) {
        this(link, title, icon);
        this.active = active;
    }

    public AnalyticsLink(String link, LinkType linkType, String title, String icon, boolean active, int linkEventId) {
        this(link, title, icon, active);
        this.linkType = linkType;
        this.eventId = linkEventId;
    }

    public AnalyticsLink(String link, LinkType linkType, String title, String icon, boolean active, int linkEventId, String trackingCode) {
        this(link, linkType, title, icon, active, linkEventId);
        interpolateTrackingCode(trackingCode);
    }

    /**
     * Interpolates variables in the tracking code. The tracking code contains variables such as ${analyticsClass}
     * which through reflection is mapped to a value in this object and replaced in the tracking code.
     *
     * @param trackingCode
     */
    private void interpolateTrackingCode(String trackingCode) {
        Field[] fields = AnalyticsLink.class.getFields();
        String interpolatedTrackingCode = trackingCode;

        for (Field field : fields) {
            String interpolatedVariable = "${" + field.getName() + "}";
            Object fieldValue;
            try {
                fieldValue = field.get(this);
            } catch (IllegalArgumentException | IllegalAccessException e) {
                fieldValue = "Error";
            }

            String stringValue;
            if (int.class.isAssignableFrom(fieldValue.getClass())) {
                stringValue = Integer.valueOf((int) fieldValue).toString();
            } else if (boolean.class.isAssignableFrom(fieldValue.getClass())) {
                stringValue = Boolean.valueOf((boolean) fieldValue).toString();
            } else {
                stringValue = fieldValue.toString();
            }

            interpolatedTrackingCode = StringUtils.replace(interpolatedTrackingCode, interpolatedVariable, stringValue);
        }

        this.trackingCode = interpolatedTrackingCode;
    }

    private String generateAnalyticsClass(String base) {
        final String lowerUnderscore = JcrUtil.createValidName(base);
        return CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, lowerUnderscore);
    }

    public String getLink() {
        return link;
    }

    public String getTitle() {
        return title;
    }

    public String getIcon() {
        return icon;
    }

    public boolean isActive() {
        return BooleanUtils.isTrue(active);
    }

    public String getAnalyticsClass() {
        return analyticsClass;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public static AnalyticsLink fromPage(Page page, Page currentPage) {
        return new AnalyticsLink(LinkUtil.getPageLink(page, currentPage), PageUtil.getPageNavigationTitle(page), null,
                StringUtils.startsWith(currentPage.getPath(), page.getPath()));
    }

    public static AnalyticsLink fromPage(Page page) {
        return new AnalyticsLink(LinkUtil.getPageLink(page), PageUtil.getPageNavigationTitle(page), null, false);
    }

    @Override
    public int compareTo(AnalyticsLink other) {
        if (StringUtils.isBlank(title)) {
            return 1;
        }
        return title.compareTo(other.title);
    }

    public String getTrackingCode() {
        return trackingCode;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setAnalyticsClass(String analyticsClass) {
        this.analyticsClass = analyticsClass;
    }

    public void setTrackingCode(String trackingCode) {
        this.trackingCode = trackingCode;
    }

    public LinkType getLinkType() {
        return linkType;
    }

    public String getLinkTypeString() {
        return linkType.toString();
    }

    public boolean isLoginType() {
        return linkType == LinkType.LOGIN;
    }

    public boolean isAccountsType() {
        return linkType == LinkType.ACCOUNTS;
    }

    public boolean isLogoutType() {
        return linkType == LinkType.LOGOUT;
    }
}
