package com.jhi.aem.website.v1.core.generic.link;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.common.base.CaseFormat;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

public class Link extends SimpleLink {

    private String analyticsClass;
    private String cssClass;

    public Link(String link, String title) {
        super(link, title);
    }

    public Link(String link, String title, boolean active) {
        this(link, title);
        this.active = active;
    }

    private String generateAnalyticsClass(String base) {
        final String lowerUnderscore = JcrUtil.createValidName(base);
        return CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, lowerUnderscore);
    }

    public String getAnalyticsClass() {
        if (analyticsClass == null) {
            analyticsClass = generateAnalyticsClass(title);
        }
        return analyticsClass;
    }

    public String getCssClass() {
        return cssClass;
    }

    public void setCssClass(String cssClass) {
        this.cssClass = cssClass;
    }

    public static Link fromPage(Page page, Page currentPage) {
        return new Link(LinkUtil.getPageLink(page, currentPage), PageUtil.getPageNavigationTitle(page),
                StringUtils.startsWith(currentPage.getPath(), page.getPath()));
    }

    public static List<Link> getLinksFromPaths(String[] links, PageManager pageManager, Page resourcePage) {
        return Optional.ofNullable(links)
                .map(link -> mapLinks(link, pageManager, resourcePage))
                .orElse(Collections.emptyList());
    }

    public static Link getLinkFromPath(String path, PageManager pageManager, Page resourcePage) {
        if (pageManager != null && StringUtils.isNotBlank(path)) {
            final Page page = pageManager.getPage(path);
            if (page != null) {
                return Link.fromPage(page, resourcePage);
            }
        }
        return null;
    }

    private static List<Link> mapLinks(String[] array, PageManager pageManager, Page resourcePage) {
        return Arrays.stream(array)
                .map(link -> getLinkFromPath(link, pageManager, resourcePage))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
}
