package com.jhi.aem.website.v1.core.generic.link;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;

@Model(adaptables=Resource.class,defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class SimpleLink implements Comparable<SimpleLink> {
	public final static SimpleLink EMPTY = new SimpleLink(StringUtils.EMPTY, StringUtils.EMPTY);
    protected String link;
    protected String title;
    protected boolean active;
    private String currency;

    public SimpleLink(String link, String title) {
        this.link = link;
        this.title = title;
    }

    public SimpleLink(String link, String title, String currency, boolean active) {
        this(link, title);
        this.active = active;
        this.currency = currency;
    }

    public String getLink() {
        return link;
    }
    
    public void setLink(String link) {
    	this.link=link;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public String getCurrency() {
        return currency;
    }

    public boolean isActive() {
        return active;
    }

    public static SimpleLink fromPage(Page page) {
        return new SimpleLink(LinkUtil.getPageLink(page), PageUtil.getPageNavigationTitle(page));
    }

    @Override
    public int compareTo(SimpleLink other) {
        if (StringUtils.isBlank(title)) {
            return 1;
        }
        return title.compareTo(other.title);
    }
}
