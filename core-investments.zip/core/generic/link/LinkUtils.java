package com.jhi.aem.website.v1.core.generic.link;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.servlets.LogoutServlet;
import com.jhi.aem.website.v1.core.utils.LinkUtil;
import com.jhi.aem.website.v1.core.utils.PageUtil;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;

public final class LinkUtils {

    private LinkUtils() {
    }

    /**
     * Creates navigation from two arrays, one holding the display name for the link, the other holding the link
     *
     * @param request
     * @param resolverFactory
     * @param linkNames
     * @param links
     * @param countryFilterParameter 
     * @return
     */
    @SuppressWarnings("unchecked")
	public static List<AnalyticsLink> createNavigation(SlingHttpServletRequest request,
    				ResourceResolverFactory resolverFactory,
					String trackingCode, int startEventId, String[] linkNames, String[] links,
					String currentPagePath, String ucitsCountryFilterParameter) {
    	
    	return (List<AnalyticsLink>)ResourceUtil.executeResourceActionInElevatedResourceResolver(resolverFactory,
    			resourceResolver -> {
			        int maxLinks = Math.max(linkNames.length, links.length);
			        List<AnalyticsLink> navigation = new ArrayList<>(maxLinks);
			        int eventId = startEventId;
					PageManager pageManager = resourceResolver.adaptTo(PageManager.class);

                    for (int i = 0; i < maxLinks; i++) {
                        String link = i >= links.length ? "#undefined" : links[i];
                        String linkName = i >= linkNames.length ? PageUtil.getPageNavigationTitle(pageManager.getPage(link)) : linkNames[i];
                        LinkType linkType = LinkType.GENERIC;

                        if (StringUtils.endsWith(StringUtils.removeEnd(link, JhiConstants.URL_HTML_EXTENSION), LogoutServlet.LOGOUT_SELECTOR_PART)) {
                            linkType = LinkType.LOGOUT;
                        } else if (StringUtils.endsWith(StringUtils.removeEnd(link, JhiConstants.URL_HTML_EXTENSION), JhiConstants.ACCOUNTS_PAGE_SELECTOR_PART)) {
                            linkType = LinkType.ACCOUNTS;
                        } else {

                            // Remap relative links
                            Resource linkResource = LinkUtil.getInternalPageResource(resourceResolver, link);
                            if (linkResource != null) {
                                // Map relative links using the resource resolver and mappings
                                link = LinkUtil.mapResourceToPath(request, linkResource);

                                // Check if this is the login page
                                Page linkPage = linkResource.adaptTo(Page.class);
                                if (PageUtil.isResourceType(linkPage, ResourcesConstants.LOGIN_PAGE_RESOURCE_TYPE)) {
                                    linkType = LinkType.LOGIN;
                                }
                            }

                        }
                        
                        // Is this the active link?
                        boolean active = StringUtils.startsWith(currentPagePath, StringUtils.removeEnd(link, JhiConstants.URL_HTML_EXTENSION));

    	                // Add UCITS country as required
    	                if (StringUtils.isNotEmpty(ucitsCountryFilterParameter)) {
    	                	link = link + "/" + ucitsCountryFilterParameter;
    	                }

    	                AnalyticsLink linkObj = new AnalyticsLink(link, linkType, linkName, null, active, eventId++, trackingCode);
                        navigation.add(linkObj);
                    }

                    return navigation;
                });
    }

    @SuppressWarnings("unchecked")
    public static List<AnalyticsLink> createNavigation(SlingHttpServletRequest request,
    			ResourceResolverFactory resolverFactory, String trackingCode, int startEventId,
    			List<Resource> linkNames, List<Resource> links, List<Resource> icons, String currentPagePath,
    			String ucitsCountryFilterParameter) {

    	return (List<AnalyticsLink>)ResourceUtil.executeResourceActionInElevatedResourceResolver(resolverFactory,
			resourceResolver -> {
		        int maxLinks = Math.max(linkNames.size(), links.size());
		        List<AnalyticsLink> navigation = new ArrayList<>(maxLinks);
		        int eventId = startEventId;
				PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
	
	            for (int i = 0; i < maxLinks; i++) {
	                Resource linkResource = i >= links.size() ? null : links.get(i);
					String link = (null != linkResource) ? (String)linkResource.getValueMap().get("navigation"):"#undefined";
					
					Resource iconResource = null;
					String icon = null;
					if(icons != null) {
						iconResource = i >= icons.size() ? null : icons.get(i);
						icon = (null != iconResource) ? (String)iconResource.getValueMap().get("icon"):"#undefined";
					}
					
	                Resource linkNameResource = i >= linkNames.size() ? null : linkNames.get(i);
	                String linkName = i >= linkNames.size() ? PageUtil.getPageNavigationTitle(pageManager.getPage(link)) :(String) linkNameResource.getValueMap().get("name");
	                LinkType linkType = LinkType.GENERIC;
	
	                if (StringUtils.endsWith(StringUtils.removeEnd(link, JhiConstants.URL_HTML_EXTENSION), LogoutServlet.LOGOUT_SELECTOR_PART)) {
	                    linkType = LinkType.LOGOUT;
	                } else if (StringUtils.endsWith(StringUtils.removeEnd(link, JhiConstants.URL_HTML_EXTENSION), JhiConstants.ACCOUNTS_PAGE_SELECTOR_PART)) {
	                    linkType = LinkType.ACCOUNTS;
	                } else {
	
	                    // Remap relative links
	                    Resource resource = LinkUtil.getInternalPageResource(resourceResolver, link);
	                    if (resource != null) {
	                        // Map relative links using the resource resolver and mappings
	                        link = LinkUtil.mapResourceToPath(request, resource,true);
	
	                        // Check if this is the login page
	                        Page linkPage = resource.adaptTo(Page.class);
	                        if (PageUtil.isResourceType(linkPage, ResourcesConstants.LOGIN_PAGE_RESOURCE_TYPE)) {
	                            linkType = LinkType.LOGIN;
	                        }
	                    }
	
	                }

	                // Is this the active link?
	                boolean active = StringUtils.startsWith(currentPagePath, StringUtils.removeEnd(link, JhiConstants.URL_HTML_EXTENSION));
	                
	                // Add UCITS country as required for relative links
	                if (StringUtils.isNotEmpty(ucitsCountryFilterParameter) && 
	                		StringUtils.startsWith(ucitsCountryFilterParameter, "/")) {
	                	link = link + "/" + ucitsCountryFilterParameter;
	                }
	
	                AnalyticsLink linkObj = new AnalyticsLink(link, linkType, linkName, icon, active, eventId++, trackingCode);
	                navigation.add(linkObj);
	            }
	
	            return navigation;
			});	      
    }


}
