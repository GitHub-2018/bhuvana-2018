package com.jhi.aem.website.v1.core.generic.link;

public enum LinkType {
	GENERIC,
	LOGIN,
	ACCOUNTS,
	LOGOUT
}
