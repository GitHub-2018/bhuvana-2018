package com.jhi.aem.website.v1.core.generic.page.filter;

import com.day.cq.commons.Filter;
import com.day.cq.wcm.api.Page;

public class PageFilter implements Filter<Page> {
    public static final PageFilter INSTANCE = new PageFilter();

    @Override
    public boolean includes(Page page) {
        return page != null && !page.isHideInNav() && page.isValid() && page.getContentResource() != null;
    }
}
