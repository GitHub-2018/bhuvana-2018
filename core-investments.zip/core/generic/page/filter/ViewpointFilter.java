package com.jhi.aem.website.v1.core.generic.page.filter;

import com.day.cq.commons.Filter;
import com.day.cq.wcm.api.Page;
import com.jhi.aem.website.v1.core.constants.ResourcesConstants;
import com.jhi.aem.website.v1.core.utils.PageUtil;

public class ViewpointFilter implements Filter<Page> {
    public static final ViewpointFilter INSTANCE = new ViewpointFilter();

    @Override
    public boolean includes(Page page) {
        return page != null && !page.isHideInNav() && page.isValid()
                && PageUtil.isResourceType(page, ResourcesConstants.VIEWPOINT_PAGE_RESOURCE_TYPE);
    }
}
