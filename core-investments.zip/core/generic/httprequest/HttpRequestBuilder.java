package com.jhi.aem.website.v1.core.generic.httprequest;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;

public class HttpRequestBuilder {
    private HttpPost postMethod;

    public HttpRequestBuilder url(String url) {
        postMethod = new HttpPost(url);
        return this;
    }

    public HttpRequestBuilder post(HttpRequestBody body) {
        postMethod.setEntity(new StringEntity(body.getBody(), body.getContentType()));
        return this;
    }

    public HttpRequestBuilder addHeader(String name, String value) {
        postMethod.addHeader(name, value);
        return this;
    }

    public HttpPost build() {
        return postMethod;
    }
}
