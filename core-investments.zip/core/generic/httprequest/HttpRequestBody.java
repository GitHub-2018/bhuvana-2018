package com.jhi.aem.website.v1.core.generic.httprequest;

import org.apache.http.entity.ContentType;

public class HttpRequestBody {

    private ContentType contentType;
    private String body;

    private HttpRequestBody() {
    }

    public static HttpRequestBody create(ContentType contentType, String body) {
        HttpRequestBody httpRequestBody = new HttpRequestBody();
        httpRequestBody.contentType = contentType;
        httpRequestBody.body = body;
        return httpRequestBody;
    }

    public ContentType getContentType() {
        return contentType;
    }

    public String getBody() {
        return body;
    }
}
