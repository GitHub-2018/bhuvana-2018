package com.jhi.aem.website.v1.core.generic.pagination;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.jhi.aem.website.v1.core.generic.link.Link;

public class Pagination {

    public static final int MAX_PAGINATION_ITEMS = 20;
    public static final String PAGE_SUFFIX = "page";
    private static final Link SEPARATOR = new Link(StringUtils.EMPTY, "&hellip;");

    private List<Link> links;
    private Link prev;
    private Link next;

    private int currentPage;
    private int pageSize;
    private int totalPages;
    private int totalResults;
    private boolean hasActive;

    public Pagination(int currentPage, int pageSize, int totalPages, int totalResults) {
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.totalPages = totalPages;
        this.totalResults = totalResults;
        this.links = new ArrayList<>(pageSize);
        prev = null;
        next = null;
        hasActive = false;
    }

    public void addLink(Link link) {
        if (hasActive && next == null) {
            next = link;
        }
        if (link.isActive()) {
            hasActive = true;
            if (!links.isEmpty()) {
                prev = links.get(links.size() - 1);
            }
        }
        links.add(link);
    }

    public List<Link> getLinks() {
        return links;
    }

    public Link getPrev() {
        return prev;
    }

    public Link getNext() {
        return next;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public int getPageSize() {
        return pageSize;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public void addSeparator() {
        if (links != null) {
            links.add(SEPARATOR);
        }
    }

    public static int getPageNumber(String numberParameter) {
        int pageNumber = 1;
        if (StringUtils.isNumeric(numberParameter)) {
            pageNumber = Integer.parseInt(numberParameter);
            if (pageNumber < 1) {
                pageNumber = 1;
            }
        }
        return pageNumber;
    }
}
