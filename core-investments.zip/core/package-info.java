@Version("1.0")
package com.jhi.aem.website.v1.core;

import org.osgi.annotation.versioning.Version;