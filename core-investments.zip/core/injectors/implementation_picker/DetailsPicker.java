package com.jhi.aem.website.v1.core.injectors.implementation_picker;

import static org.osgi.framework.Constants.SERVICE_RANKING;


import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.spi.ImplementationPicker;
import org.osgi.service.component.annotations.Component;

import com.jhi.aem.website.v1.core.injectors.qualifiers.TargetResourceTypes;
import com.jhi.aem.website.v1.core.models.resources.ResourceDetailModel;
import com.jhi.aem.website.v1.core.models.viewpoint.ViewpointDetailModel;

@Component(
		name="Details Picket component",
		service=ImplementationPicker.class,
		immediate=true,
		property= {
				SERVICE_RANKING+":Integer=50"	
		})

public class DetailsPicker implements ImplementationPicker {

    @Override
    public Class<?> pick(Class<?> adapterType, Class<?>[] implementationsTypes, Object adaptable) {
        if (!(adaptable instanceof Resource)
                || (adapterType != ViewpointDetailModel.class && adapterType != ResourceDetailModel.class)) {
            return null;
        }
        Resource resource = (Resource) adaptable;
        String pageResourceType = resource.getResourceType();
        Class<?> defaultHandler = null;
        for (Class<?> clazz : implementationsTypes) {
            TargetResourceTypes targets = clazz.getAnnotation(TargetResourceTypes.class);
            if (targets == null) {
                defaultHandler = clazz;
            } else {
                for (String resourceType : targets.value()) {
                    if (resourceType.equals(pageResourceType)) {
                        return clazz;
                    }
                }
            }
        }
        return defaultHandler;
    }
}
