package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class AvrgAnnualTotalRtnData {
	private MonthlyReturnData monthlyReturnData;

	/**
	 * @return the monthlyReturnData
	 */
	public MonthlyReturnData getMonthlyReturnData() {
		return monthlyReturnData;
	}

	/**
	 * @param monthlyReturnData the monthlyReturnData to set
	 */
	public void setMonthlyReturnData(MonthlyReturnData monthlyReturnData) {
		this.monthlyReturnData = monthlyReturnData;
	}
}
