package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class OverviewImport {
    private String objective;
    private String useFor;
	public String getObjective() {
		return objective;
	}
	public void setObjective(String objective) {
		this.objective = objective;
	}
	public String getUseFor() {
		return useFor;
	}
	public void setUseFor(String useFor) {
		this.useFor = useFor;
	}

}
