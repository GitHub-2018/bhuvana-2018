package com.jhi.aem.website.v1.core.external.models.funds.maestro;

import java.util.List;

public class MonthlyReturnData {
	
	private List<ReturnList> returnsList;

	public List<ReturnList> getReturnList() {
		return returnsList;
	}

	public void setReturnList(List<ReturnList> returnList) {
		this.returnsList = returnList;
	}

}
