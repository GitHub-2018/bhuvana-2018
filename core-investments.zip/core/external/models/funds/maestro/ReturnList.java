package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class ReturnList {

	private String label;
	private String month1;
	private String month3;
	private String year1;
	private String year3;
	private String year5;
	private String year10;
	private String monthEndYtd;
	private String ytd;
	private String inception;
	private String dateAsOf;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getMonth1() {
		return month1;
	}
	public void setMonth1(String month1) {
		this.month1 = month1;
	}
	public String getMonth3() {
		return month3;
	}
	public void setMonth3(String month3) {
		this.month3 = month3;
	}
	public String getYear1() {
		return year1;
	}
	public void setYear1(String year1) {
		this.year1 = year1;
	}
	public String getYear3() {
		return year3;
	}
	public void setYear3(String year3) {
		this.year3 = year3;
	}
	public String getYear5() {
		return year5;
	}
	public void setYear5(String year5) {
		this.year5 = year5;
	}
	public String getYear10() {
		return year10;
	}
	public void setYear10(String year10) {
		this.year10 = year10;
	}
	public String getMonthEndYtd() {
		return monthEndYtd;
	}
	public void setMonthEndYtd(String monthEndYtd) {
		this.monthEndYtd = monthEndYtd;
	}
	public String getInception() {
		return inception;
	}
	public void setInception(String inception) {
		this.inception = inception;
	}
	public String getDateAsOf() {
		return dateAsOf;
	}
	public void setDateAsOf(String dateAsOf) {
		this.dateAsOf = dateAsOf;
	}
	public String getYtd() {
		return ytd;
	}
	public void setYtd(String ytd) {
		this.ytd = ytd;
	}
}
