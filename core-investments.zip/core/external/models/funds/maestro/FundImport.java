package com.jhi.aem.website.v1.core.external.models.funds.maestro;

import java.util.Set;

public abstract class FundImport<T extends ShareClassImport> extends AbstractFundImport {
    private Set<T> shareclasses;

    public Set<T> getShareclasses() {
		return shareclasses;
	}
	public void setShareclasses(Set<T> shareclasses) {
		this.shareclasses = shareclasses;
	}

}
