package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class MorningstarDataImport {
    private Integer overallRating;
    private String analystRating;
    private String category;

    public Integer getOverallRating() {
		return overallRating;
	}
	public void setOverallRating(Integer overallRating) {
		this.overallRating = overallRating;
	}
	public String getAnalystRating() {
		return analystRating;
	}
	public void setAnalystRating(String analystRating) {
		this.analystRating = analystRating;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

}
