package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class UnpublishedFundImport extends AbstractFundImport {
    private ShareClassImport shareclass;

	public ShareClassImport getShareclass() {
		return shareclass;
	}

	public void setShareclass(ShareClassImport shareclass) {
		this.shareclass = shareclass;
	}

}
