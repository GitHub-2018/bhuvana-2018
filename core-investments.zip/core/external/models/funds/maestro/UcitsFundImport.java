package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class UcitsFundImport extends FundImport<UcitsShareClassImport> {

}
