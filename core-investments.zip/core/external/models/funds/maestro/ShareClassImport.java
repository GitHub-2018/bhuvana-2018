package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class ShareClassImport {
    private String symbol;
	private String name;
	private String shareClassId;
	private String cusip;
	private String mstarId;
    private String classCode;
    private String isIn;
    private String currencyCode;
	private String dateInception;
	private Boolean published;
	private MorningstarDataImport morningStarData;
	
	//GIT #1843
	private AvrgAnnualTotalRtnData averageAnnualTotalReturnData;
	private String navPrice;
	private String yieldDistribution;

    public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShareClassId() {
		return shareClassId;
	}
	public void setShareClassId(String shareClassId) {
		this.shareClassId = shareClassId;
	}
	public String getCusip() {
		return cusip;
	}
	public void setCusip(String cusip) {
		this.cusip = cusip;
	}
	public String getMstarId() {
		return mstarId;
	}
	public void setMstarId(String mstarId) {
		this.mstarId = mstarId;
	}
	public String getClassCode() {
		return classCode;
	}
	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}
	public String getIsIn() {
		return isIn;
	}
	public void setIsIn(String isIn) {
		this.isIn = isIn;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getDateInception() {
		return dateInception;
	}
	public void setDateInception(String dateInception) {
		this.dateInception = dateInception;
	}
	public Boolean isPublished() {
		return published;
	}
	public void setPublished(Boolean published) {
		this.published = published;
	}
	public MorningstarDataImport getMorningStarData() {
		return morningStarData;
	}
	public void setMorningStarData(MorningstarDataImport morningStarData) {
		this.morningStarData = morningStarData;
	}
    //GIT #1843
	public AvrgAnnualTotalRtnData getAverageAnnualTotalReturnData() {
		return averageAnnualTotalReturnData;
	}
	public void setAverageAnnualTotalReturnData(AvrgAnnualTotalRtnData averageAnnualTotalReturnData) {
		this.averageAnnualTotalReturnData = averageAnnualTotalReturnData;
	}
	/**
	 * @return the navPrice
	 */
	public String getNavPrice() {
		return navPrice;
	}
	/**
	 * @param navPrice the navPrice to set
	 */
	public void setNavPrice(String navPrice) {
		this.navPrice = navPrice;
	}
	public String getYieldDistribution() {
		return yieldDistribution;
	}
	public void setYieldDistribution(String yieldDistribution) {
		this.yieldDistribution = yieldDistribution;
	}
}
