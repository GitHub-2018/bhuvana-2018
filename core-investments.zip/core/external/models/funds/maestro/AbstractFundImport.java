package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public abstract class AbstractFundImport {
    private String fundId;
    private Boolean published;
	private String name;
	private String assetClass;
	private String productType;
	private OverviewImport overviewData;

	public String getFundId() {
		return fundId;
	}
	public void setFundId(String fundId) {
		this.fundId = fundId;
	}
	public Boolean getPublished() {
		return published;
	}
	public void setPublished(Boolean published) {
		this.published = published;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAssetClass() {
		return assetClass;
	}
	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public OverviewImport getOverviewData() {
		return overviewData;
	}
	public void setOverviewData(OverviewImport overviewData) {
		this.overviewData = overviewData;
	}
}
