package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class UcitsCountry {
	private String countryCode;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

}
