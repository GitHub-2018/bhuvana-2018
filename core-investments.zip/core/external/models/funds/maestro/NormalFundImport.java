package com.jhi.aem.website.v1.core.external.models.funds.maestro;

public class NormalFundImport extends FundImport<ShareClassImport> {

}
