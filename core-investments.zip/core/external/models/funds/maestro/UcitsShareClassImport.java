package com.jhi.aem.website.v1.core.external.models.funds.maestro;

import java.util.Set;

public class UcitsShareClassImport extends ShareClassImport {
	private Set<UcitsCountry> countries;

	public Set<UcitsCountry> getCountries() {
		return countries;
	}

	public void setCountries(Set<UcitsCountry> countries) {
		this.countries = countries;
	}

}
