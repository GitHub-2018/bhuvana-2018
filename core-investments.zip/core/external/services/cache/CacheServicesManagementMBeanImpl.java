package com.jhi.aem.website.v1.core.external.services.cache;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;

import javax.management.DynamicMBean;
import javax.management.NotCompliantMBeanException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.adobe.granite.jmx.annotation.AnnotatedStandardMBean;
import com.google.common.cache.Cache;

@Component(
		name="Cache Services Management MBean Implementations",
		service= DynamicMBean.class,
		immediate = true,
		property= {
				"jmx.objectname=com.jhi.aem.website.v1.core.external.services.cache:type=Cache Services Management"			
		})
public class CacheServicesManagementMBeanImpl extends AnnotatedStandardMBean implements CacheServicesManagementMBean {
	
	
	private CacheServicesLocator cacheServicesLocator;
	
	@Reference
	public void bindCacheServicesLocator(CacheServicesLocator cacheServicesLocator) {
		this.cacheServicesLocator=cacheServicesLocator;
	}
	public void unbindCacheServicesLocator(CacheServicesLocator cacheServicesLocator) {
		this.cacheServicesLocator=cacheServicesLocator;
	}

	
	public CacheServicesManagementMBeanImpl() throws NotCompliantMBeanException {
		super(CacheServicesManagementMBean.class);
	}

	@Override
	public Set<String> listCacheServices() {
		return cacheServicesLocator.listCacheServices();
	}

	@Override
	public void clearCache(String cacheName) {
		Cache<Object, Object> cache = cacheServicesLocator.getCache(cacheName);
		cache.invalidateAll();
	}

	@Override
	public Set<String> listCacheKeys(String cacheName) {
		Cache<Object, Object> cache = cacheServicesLocator.getCache(cacheName);
		ConcurrentMap<Object, Object> cacheMap = cache.asMap();
		Set<String> cacheKeys = new HashSet<>(cacheMap.size());

		for (Object cacheKey : cacheMap.keySet()) {
			cacheKeys.add(cacheKey.toString());
		}
		
		return cacheKeys;
	}

}
