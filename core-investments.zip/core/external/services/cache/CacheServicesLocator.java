package com.jhi.aem.website.v1.core.external.services.cache;

import java.util.Collections;
import java.util.Set;

import com.google.common.cache.Cache;

/**
 * A locator for {@link CacheServiceFactory} instances
 */
public interface CacheServicesLocator {

	/**
	 * Locates a cache service factory by the cache name
	 * @param cacheName
	 * @return
	 */
	CacheServiceFactory getCacheServiceFactory(String cacheName);

	/**
	 * Gets a cache given the cache name
	 * @param cacheName
	 * @return
	 * @throws IllegalArgumentException
	 * 			If the cache factory for the given name does not exist
	 * @throws IllegalStateException
	 * 			If the cache cannot be initialised through {@link CacheServiceFactory#getCache()}
	 */
	<K extends Object, V extends Object> Cache<K,V> getCache(String cacheName)
		throws IllegalStateException, IllegalArgumentException;

	/**
	 * Gets a cache given the cache name
	 * @param cacheName
	 * @param timeoutMs
	 * @return
	 * @throws IllegalArgumentException
	 * 			If the cache factory for the given name does not exist
	 * @throws IllegalStateException
	 * 			If the cache cannot be initialised through {@link CacheServiceFactory#getCache()}
	 */
	<K, V> Cache<K, V> getCache(String cacheName, long timeoutMs)
			throws IllegalStateException, IllegalArgumentException;

	Set<String> listCacheServices();

}
