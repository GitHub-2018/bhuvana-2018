package com.jhi.aem.website.v1.core.external.services.cache;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.collect.ImmutableSet;

@Component(
		name="Cache Services Location Implementation",
		service=CacheServicesLocator.class,	
		immediate = true,
		configurationPolicy = ConfigurationPolicy.IGNORE,
		property= {
				Constants.SERVICE_VENDOR+"=Maark LLC"
		})
public class CacheServicesLocatorImpl implements CacheServicesLocator {
	private static final Logger logger = LoggerFactory.getLogger(CacheServicesLocatorImpl.class);
	private static final long DEFAULT_SLEEP_TIME = 0;
	
	private Map<String,CacheServiceFactory> cacheServiceFactoryMap = new HashMap<>();

	@Reference(name = "cacheServiceFactoryMap",
			service=CacheServiceFactory.class,
			policy = ReferencePolicy.DYNAMIC,
			cardinality = ReferenceCardinality.MULTIPLE)
    protected void bindCacheServiceFactory(CacheServiceFactory cacheServiceFactory, Map<String, Object> config) {
    	if (StringUtils.isNotEmpty(cacheServiceFactory.getCacheName())) {
    		if (cacheServiceFactoryMap.put(cacheServiceFactory.getCacheName(), cacheServiceFactory) != null) {
    			logger.info("Replaced cache with name {} (factory instance {})", cacheServiceFactory.getCacheName(),
    				cacheServiceFactory.getClass().getName());

    		} else {
    			logger.info("Bound cache with name {} (factory instance {})", cacheServiceFactory.getCacheName(),
    				cacheServiceFactory.getClass().getName());
    		}
    	}
    }

    protected void unbindCacheServiceFactory(CacheServiceFactory cacheServiceFactory, Map<String, Object> config) {
    	if (cacheServiceFactoryMap.remove(cacheServiceFactory.getCacheName()) != null) {
    		logger.info("Unbound cache with name {}", cacheServiceFactory.getCacheName());
    	}
    }
    
    @Override
	public Set<String> listCacheServices() {
    	return Collections.unmodifiableSet(cacheServiceFactoryMap.keySet());
    }

	@Override
	public CacheServiceFactory getCacheServiceFactory(String cacheName) {
		return cacheServiceFactoryMap.get(cacheName);
	}

	@Override
	public <K, V> Cache<K, V> getCache(String cacheName) throws IllegalStateException, IllegalArgumentException {
		CacheServiceFactory cacheServiceFactory = getCacheServiceFactory(cacheName);

		if (cacheServiceFactory == null) {
			throw new IllegalArgumentException("The cache factory for cache with name '" + cacheName + "' cannot be found");
		}

		return cacheServiceFactory.getCache();
	}

	@Override
	public <K, V> Cache<K, V> getCache(String cacheName, long timeoutMs) throws IllegalStateException, IllegalArgumentException {
		CacheServiceFactory cacheServiceFactory = null;
		long startTime = System.currentTimeMillis();
		long timeout = startTime + timeoutMs;

		while (cacheServiceFactory == null && timeout < System.currentTimeMillis()) {
			cacheServiceFactory = getCacheServiceFactory(cacheName);

			if (cacheServiceFactory == null) {
				try {
					Thread.sleep(DEFAULT_SLEEP_TIME);
				} catch (InterruptedException e) {
				}
			}
		}
		
		if (cacheServiceFactory == null) {
			throw new IllegalArgumentException("The cache factory for cache with name '" + cacheName + "' cannot be "
					+ "found after " + timeoutMs + "ms");
		}

		return cacheServiceFactory.getCache();
	}

}
