package com.jhi.aem.website.v1.core.external.services.cache;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.osgi.service.metatype.annotations.Option;
import org.osgi.util.tracker.ServiceTracker;
import org.osgi.util.tracker.ServiceTrackerCustomizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;
import com.jhi.aem.website.v1.core.constants.JhiConstants;

//@Component(label = "Cache Service (In Memory)", metatype = true,
//	policy = ConfigurationPolicy.REQUIRE, factory = "com.jhi.aem.website.v1.core.external.services.cache.InMemoryCacheServiceImpl")
//@Properties({ 
//	@Property(name = Constants.SERVICE_DESCRIPTION, value = "In-memory cache service provider"),
//	@Property(name = Constants.SERVICE_VENDOR, value = "Maark LLC"),
//	@Property(name = CacheService.CACHE_NAME_SERVICE_REFERENCE_PROPERTY,
//				label = "The reference name of the cache instance"),
//	@Property(name = CacheLoaderService.CACHE_LOADER_NAME_SERVICE_REFERENCE_PROPERTY,
//		label = "The reference name of the cache loader instance")
//})
//@References({
//	@Reference(
//		cardinality = ReferenceCardinality.OPTIONAL_MULTIPLE,
//		policy = ReferencePolicy.DYNAMIC,
//		referenceInterface = CacheLoaderService.class,
//		name = "CacheLoaderService",
//		bind="bindCacheLoaderService",
//		unbind="unbindCacheLoaderService")
//})
//@Service

@Component(
		name = "Cache Service Factory (In Memory) Implementation -JHI Website",
        service=CacheServiceFactory.class,
        configurationPolicy = ConfigurationPolicy.REQUIRE,
        configurationPid="com.jhi.aem.website.v1.core.external.services.cache.InMemoryCacheServiceFactoryImpl",
        property= {
        		Constants.SERVICE_DESCRIPTION+"=An in-memory cache service factory for creating a cache service which operates in memory within a single JVM instance",
        		Constants.SERVICE_VENDOR+"="+JhiConstants.SERVICE_VENDOR
        })

@Designate(ocd=InMemoryCacheServiceFactoryImpl.Config.class, factory=true)
public class InMemoryCacheServiceFactoryImpl implements CacheServiceFactory, ServiceTrackerCustomizer {
    private static final Logger logger = LoggerFactory.getLogger(InMemoryCacheServiceFactoryImpl.class);
    private static final int DEFAULT_MAX_SIZE = 10000;
    private static final int DEFAULT_TTL_MS = 0;
    
    @ObjectClassDefinition(name="InMemory Cache Service Factory Configurations for JHI Website", description="Factory configurations for InMemory cache service")
    public @interface Config{
    	@AttributeDefinition(name = "Cache Name",
                description = "A name for this cache")
    	String cacheName() default StringUtils.EMPTY;
    	
    	@AttributeDefinition(name = "Cache Loader Reference",
                description = "A reference (the name) of the cache loader service instance to use.If not specified "
                		+ "then the cache will not use a cache loader service.")
    	String cacheLoaderName() default StringUtils.EMPTY;
    	
    	@AttributeDefinition(name = "Max Size",
                description = "Maximum number of objects which can be stored in the cache",type = AttributeType.INTEGER)
        int maxSize() default DEFAULT_MAX_SIZE;
    	
    	@AttributeDefinition(name = "Object TTL",
    	            description = "TTL for objects in the cache (ms), must be greater than 0 to be effective",type = AttributeType.INTEGER)
    	int ttlMs() default DEFAULT_TTL_MS;
    	
    	@AttributeDefinition(name = "Cache TTL behaviour",
                description = "TTL behaviour of cache expiration, the TTL is calculated as expiring either the last time" +
                				" that the object was accessed or from the time that the object was written to cache",
                options = {
                		@Option(label = TTL_BEHAVIOUR_EXPIRE_AFTER_ACCESS, value = "Last Access"),
                		@Option(label = TTL_BEHAVIOUR_EXPIRE_AFTER_WRITE, value = "Last Written") })
        String ttlExpiryBehaviour() default TTL_BEHAVIOUR_EXPIRE_AFTER_ACCESS;
    }
    

    private String cacheName;

    
   // public static final String CACHE_LOADER_NAME_PARAMETER = CacheLoaderServiceFactory.CACHE_LOADER_NAME_PARAMETER;
    private String cacheLoaderName;
    private int maxSize;
    private static final String TTL_BEHAVIOUR_EXPIRE_AFTER_ACCESS = "access";
    private static final String TTL_BEHAVIOUR_EXPIRE_AFTER_WRITE = "write";
    

    private int ttlMs;
    private Cache<?, ?> cache;
    private ServiceTracker cacheLoaderTracker;
    private BundleContext bundleContext;

	private String ttlExpiryBehaviour;


    @Activate
    protected void activate(BundleContext bundleContext, ComponentContext context,  Config config) throws InvalidSyntaxException {
        logger.info("Activating");
        configureCache(bundleContext, context, config);
        logger.info("Activated");
    }

    @Modified
    protected void modified(BundleContext bundleContext, ComponentContext context, Config config) throws InvalidSyntaxException {
        logger.info("Modifying cache configuration for {}", cacheName);
        cache = null;
        configureCache(bundleContext, context, config);
        logger.info("Modified cache configuration for {}", cacheName);
    }

    private void configureCache(BundleContext bundleContext, ComponentContext context, Config config) throws InvalidSyntaxException {
        this.bundleContext = bundleContext;

        cacheName = config.cacheName();
        if (StringUtils.isEmpty(cacheName)) {
            throw new IllegalArgumentException("The cache name parameter must not be empty");
        }

        cacheLoaderName = config.cacheLoaderName();
        if (StringUtils.isEmpty(cacheLoaderName)) {
        	logger.info("Cache loader service is empty, will not preload values for cache {}", cacheName);
        }

        maxSize = config.maxSize();
        ttlMs = config.ttlMs();
        ttlExpiryBehaviour = config.ttlExpiryBehaviour();
        logger.info("Configured cache with name='{}', cache loader='{}', max size={}, TTL ms={}, TTL expiry behaviour={}",
        		new Object[] {cacheName, cacheLoaderName, maxSize, ttlMs, ttlExpiryBehaviour});

        // Create the cache if possible
        createCacheService();

        // Open a service tracker to track the service instance
        if (cacheLoaderTracker != null) {
            logger.debug("Closing old service tracker instance");
            cacheLoaderTracker.close();
            cacheLoaderTracker = null;
        }

        if (StringUtils.isEmpty(cacheLoaderName)) {
        	createCache();
        } else {
	        logger.debug("Opening service tracker for cache loader service factory");
	        cacheLoaderTracker = new ServiceTracker(bundleContext, CacheLoaderServiceFactory.class.getName(), this);
	        cacheLoaderTracker.open();
        }
    }

	private void createCacheService() throws InvalidSyntaxException {
    	if (!StringUtils.isEmpty(cacheLoaderName)) {
	        // Filter to retrieve service references for the cache loader associated with this
	        // service factory
	        String cacheLoaderServiceReferenceFilter =
	                "(&(objectClass=" + CacheLoaderServiceFactory.class.getName() + ")" +
	                        "(" + CacheLoaderServiceFactory.CACHE_LOADER_NAME_PARAMETER + "=" + cacheLoaderName + "))";
	
	        ServiceReference[] serviceRefs =
	        		bundleContext.getAllServiceReferences(null, cacheLoaderServiceReferenceFilter);
	
	        if (serviceRefs != null && serviceRefs.length > 0) {
	
	            // Go through each service ref to find a cache loader
	            for (ServiceReference serviceRef : serviceRefs) {
	                CacheLoaderServiceFactory<?, ?> cacheLoaderService =
	                        (CacheLoaderServiceFactory<?, ?>) bundleContext.getService(serviceRef);
	                if (createCacheService(cacheLoaderService)) {
	                	logger.info("Created cache service {}", cacheName);
	                    return;
	                }
	            }
	
	        } else {
	            logger.info("No cache loader service found yet for filter: {}",
	                    cacheLoaderServiceReferenceFilter);
	        }
    	}
    }

    private boolean createCacheService(CacheLoaderServiceFactory<?, ?> cacheLoaderService) {
        if (cacheLoaderService != null) {
            if (StringUtils.equals(cacheLoaderService.getName(), cacheLoaderName)) {
                logger.info("Initialising cache service {} with loader {}", cacheName, cacheLoaderService.getCacheLoader());
                createCache(cacheName, cacheLoaderService, maxSize, ttlMs);
                logger.info("Initialised cache service {}", cacheName);
                return true;
            } else {
                logger.warn("Cache service {} is not available yet (initialised cache loader {}), will wait and watch...",
                        cacheLoaderName, cacheLoaderService.getName());
            }
        } else {
            logger.warn("Cache service {} is not available yet, will wait and watch...", cacheLoaderName);
        }

        return false;
    }

    @Override
    public Object addingService(ServiceReference serviceReference) {
        // Check if this service ref matches the loader we are expecting
        logger.info("Cache loader service added/modified and triggered cache creation");
        CacheLoaderServiceFactory<?, ?> cacheLoaderService =
                (CacheLoaderServiceFactory<?, ?>) bundleContext.getService(serviceReference);
        createCacheService(cacheLoaderService);
        return cacheLoaderService;
    }

    @Override
    public void modifiedService(ServiceReference serviceReference, Object service) {
        logger.info("Cache loader service modified");
        addingService(serviceReference);
    }

    @Override
    public void removedService(ServiceReference serviceReference, Object service) {
        cache = null;
        logger.info("Removed cache service {} after cache loader was removed", cacheName);
    }

    @Deactivate
    protected void deactive() {
        cache = null;

        if (cacheLoaderTracker != null) {
            cacheLoaderTracker.close();
            cacheLoaderTracker = null;
        }

        logger.info("Deactivate cache service factory for cache {}", cacheName);
    }

    /**
     * Creates a cache without a cache loader
     */
    private void createCache() {
    	createCache(cacheName, null, maxSize, ttlMs);
	}

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void createCache(
            String cacheName, CacheLoaderServiceFactory<?, ?> cacheLoaderService, int maxCacheSize, int ttlMs) {
        // Build the cache
        CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder();

        // Set up a TTL?
        if (ttlMs > 0) {
        	if (StringUtils.equals(TTL_BEHAVIOUR_EXPIRE_AFTER_ACCESS, ttlExpiryBehaviour)) {
        		logger.debug("Cache '{}' - configuring cache expiry TTL {}ms after last access", cacheName, ttlMs);
        		builder.expireAfterAccess(ttlMs, TimeUnit.MILLISECONDS);
        	} else {
        		logger.debug("Cache '{}' - configuring cache expiry TTL {}ms after cache write", cacheName, ttlMs);
        		builder.expireAfterWrite(ttlMs, TimeUnit.MILLISECONDS);
        	}

        	if (logger.isDebugEnabled()) {
	        	builder.removalListener(new RemovalListener<Object,Object>() {
					@Override
					public void onRemoval(RemovalNotification<Object, Object> cacheRemovalNotification) {
						logger.debug("Cache '{}' removed key '{}': {}",
								new Object[] {cacheName, cacheRemovalNotification.getKey(), 
										cacheRemovalNotification.getCause().name()});
					}
	        	});
        	}
        }

        builder.maximumSize(maxCacheSize);

        if (cacheLoaderService == null){
        	cache = builder.build();
        } else {
	        cache = builder.build((CacheLoader) cacheLoaderService.getCacheLoader());
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <K, V> Cache<K, V> getCache() {
        if (cache == null) {
            throw new IllegalStateException("The cache '" + cacheName +
                    "' has not been fully configured yet and a cache cannot be retrieved from it");
        }

        return (Cache<K, V>) cache;
    }

    @Override
    public String getCacheName() {
        return cacheName;
    }

	@Override
	public int getTtlMs() {
		return ttlMs;
	}

}