package com.jhi.aem.website.v1.core.external.services.cache;

import com.google.common.cache.Cache;

/**
 * A factory which provides cache services
 */
public interface CacheServiceFactory {
	
	/**
	 * Gets the name of the cache in this configuration
	 * @return
	 */
	String getCacheName();

	/**
	 * Gets an instance of the cache for this configuration
	 * 
	 * @return
	 * @throws IllegalStateException
	 * 			If the cache cannot be initialised through {@link CacheServiceFactory#getCache()}
	 */
	<K extends Object, V extends Object> Cache<K,V> getCache()
		throws IllegalStateException;

	int getTtlMs();

}