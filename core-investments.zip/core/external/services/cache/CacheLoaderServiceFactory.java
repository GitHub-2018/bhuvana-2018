package com.jhi.aem.website.v1.core.external.services.cache;

import com.google.common.cache.CacheLoader;

public interface CacheLoaderServiceFactory<K extends Object, V extends Object> {
	String CACHE_LOADER_NAME_PARAMETER = "cacheLoaderName";
	
	String getName();

	Class<K> getKeyClass();
	
	Class<V> getValueClass();

	CacheLoader<K,V> getCacheLoader();

}
