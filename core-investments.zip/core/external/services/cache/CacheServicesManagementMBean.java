package com.jhi.aem.website.v1.core.external.services.cache;

import java.util.Set;

public interface CacheServicesManagementMBean {

	Set<String> listCacheKeys(String cacheName);

	void clearCache(String cacheName);

	Set<String> listCacheServices();

}
