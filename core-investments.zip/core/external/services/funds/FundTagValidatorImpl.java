package com.jhi.aem.website.v1.core.external.services.funds;

import org.apache.commons.lang3.StringUtils;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhi.aem.website.v1.core.external.models.funds.maestro.FundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.ShareClassImport;

@Component(
		name = "JHI Kurtosys Import Tags Validator",
		service=FundTagValidator.class,
		immediate=true,
		configurationPid="com.jhi.aem.website.v1.core.external.services.funds.FundTagValidatorImpl",
		property= {
	    		Constants.SERVICE_DESCRIPTION+"=Kurtosys Import Tags Validator",
	    		Constants.SERVICE_VENDOR+"=Maark LLC"
	    })
public class FundTagValidatorImpl implements FundTagValidator {

    private static final Logger LOG = LoggerFactory.getLogger(FundTagValidatorImpl.class);

    @Override
    public boolean validate(ShareClassImport shareClass, boolean isUcits) {
        if (!validateStringValue("share class id", shareClass.getShareClassId())) {
            return false;
        }

        // UCITS funds are allowed not have a share class symbol
        if (!isUcits && !validateStringValue("share class symbol", shareClass.getSymbol())) {
            return false;
        }

        return validateStringValue("share class display name", shareClass.getName());
    }

    @Override public boolean validate(FundImport<?> fund) {
        if (!validateStringValue("fund id", fund.getFundId())) {
            return false;
        }

        if (!validateStringValue("category type of ID " + fund.getFundId(), fund.getAssetClass())) {
            return false;
        }

        if (!validateStringValue("fund display name of ID" + fund.getFundId(), fund.getName())) {
            return false;
        }

        return validateStringValue("product type of ID " + fund.getFundId(), fund.getProductType());

    }

    private boolean validateStringValue(String propertyName, String value) {
        if (StringUtils.isBlank(value)) {
            LOG.error("Invalid string value for entity property '{}', value does not exist", propertyName);
            return false;
        }

        return true;
    }
}

