package com.jhi.aem.website.v1.core.external.services.funds;

import com.jhi.aem.website.v1.core.external.models.funds.maestro.FundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.ShareClassImport;

public interface FundTagValidator {

    boolean validate(final FundImport<?> fund);

    boolean validate(final ShareClassImport clss, boolean isUcits);
}
