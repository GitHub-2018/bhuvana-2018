package com.jhi.aem.website.v1.core.external.services.funds.maestro;

import java.util.Collection;

public class UserInfo {
	private Collection<String> roles;
	private String name;
	private String email;
	private String username;
	public Collection<String> getRoles() {
		return roles;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public String getUsername() {
		return username;
	}
	public void setRoles(Collection<String> roles) {
		this.roles = roles;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setUsername(String username) {
		this.username = username;
	}
}
