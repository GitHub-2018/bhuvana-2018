package com.jhi.aem.website.v1.core.external.services.funds.maestro;

import java.util.Collection;

import com.jhi.aem.website.v1.core.external.models.funds.maestro.NormalFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UcitsFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UnpublishedFundImport;

public interface MaestroFundsApi {
	static String UNPUBLISHED_FUND_REQUEST_PARAMETER = "fundToken";

	OAuthCredentials getOAuthToken();

	Collection<NormalFundImport> getAllFunds();

	Collection<UcitsFundImport> getAllUcistsFunds();

	UnpublishedFundImport getUnpublishedShareClassDetails(String fundToken);

}
