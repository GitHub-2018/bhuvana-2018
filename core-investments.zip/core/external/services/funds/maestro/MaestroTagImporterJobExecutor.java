package com.jhi.aem.website.v1.core.external.services.funds.maestro;

import java.util.Collection;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.apache.sling.event.jobs.consumer.JobExecutionContext;
import org.apache.sling.event.jobs.consumer.JobExecutionResult;
import org.apache.sling.event.jobs.consumer.JobExecutor;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.maintenance.MaintenanceConstants;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.NormalFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UcitsFundImport;
import com.jhi.aem.website.v1.core.external.services.funds.FundTagImportService;
import com.jhi.aem.website.v1.core.service.SuccessFailedCountStats;
import com.jhi.aem.website.v1.core.service.replication.ReplicationService;
import com.jhi.aem.website.v1.core.service.viewpoints.ViewpointPageCreationService;
import com.jhi.aem.website.v1.core.utils.ResourceUtil;


@Component(
		name = "JHI Maestro Tag Importer Maintenance Task",
		service= JobExecutor.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.external.services.funds.maestro.MaestroTagImporterJobExecutor",
		configurationPolicy=ConfigurationPolicy.OPTIONAL,
		property= {
	    		Constants.SERVICE_DESCRIPTION+"=Maintenance Task which imports Maestro tags every 24 hours.",
	    		Constants.SERVICE_VENDOR+"=Maark LLC",
	    		MaintenanceConstants.PROPERTY_TASK_NAME+"=MaestroTagImporterTask",
	    		MaintenanceConstants.PROPERTY_TASK_TITLE+"=Maestro Tag Importer",
	    		JobConsumer.PROPERTY_TOPICS+"="+MaintenanceConstants.TASK_TOPIC_PREFIX+"MaestroTagImporterTask"
	    })

@Designate(ocd=MaestroTagImporterJobExecutor.Config.class) 
public class MaestroTagImporterJobExecutor implements JobExecutor {
    private static final Logger LOG = LoggerFactory.getLogger(MaestroTagImporterJobExecutor.class);
    private static final long JOB_RETRY_DELAY_MS_DEFAULT = 60000;

    @ObjectClassDefinition(name="JHI Maestro Tag Importer JobExecutor configurations",description="Configurations for Maestro Tag importer job executor")
    public @interface Config{
    	
    	@AttributeDefinition(name = "Job Retry Delay ms", description = "Job retry delay on job failure in milliseconds")
    	long jobRetryDelayMs() default JOB_RETRY_DELAY_MS_DEFAULT;
    	
    }
    
    
    public static final String JOB_RETRY_DELAY_MS_PARAMETER = "jobRetryDelayMs";

 
    private MaestroFundsApi maestroFundsApi;
    
    @Reference
    public void bindMaestroFundsApi(MaestroFundsApi maestroFundsApi) {
    	this.maestroFundsApi=maestroFundsApi;
    }
    public void unbindMaestroFundsApi(MaestroFundsApi maestroFundsApi) {
    	this.maestroFundsApi=maestroFundsApi;
    }
    
    private ResourceResolverFactory resolverFactory;
    
    @Reference
    public void bindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    public void unbindResourceResolverFactory(ResourceResolverFactory resolverFactory) {
    	this.resolverFactory=resolverFactory;
    }
    
    
    private FundTagImportService fundTagImportService;
    
    @Reference
    public void bindFundTagImportService(FundTagImportService fundTagImportService) {
    	this.fundTagImportService = fundTagImportService;
    }
    
    public void unbindFundTagImportService(FundTagImportService fundTagImportService) {
    	this.fundTagImportService = fundTagImportService;
    }
    
    
    private ReplicationService replicationService;
    
    @Reference
    public void bindReplicationService(ReplicationService replicationService) {
    	this.replicationService=replicationService;
    }
    public void unbindReplicationService(ReplicationService replicationService) {
    	this.replicationService=replicationService;
    }
    
    
    private ViewpointPageCreationService pageCreationService;
    
    @Reference
    public void bindViewpointPageCreationService(ViewpointPageCreationService pageCreationService) {
    	this.pageCreationService=pageCreationService;
    }
    public void unbindViewpointPageCreationService(ViewpointPageCreationService pageCreationService) {
    	this.pageCreationService=pageCreationService;
    }
    
    
    JobExecutionResult cancelledJobResult(JobExecutionContext context, String message) {
        return context.result().message(message).cancelled();
    }

    JobExecutionResult failedJobResult(JobExecutionContext context, String message) {
        return context.result().message(message).failed();
    }

    JobExecutionResult successfulJobResult(JobExecutionContext context, int totalProcessed) {
        return context.result().message("Processed " + totalProcessed + " tags").succeeded();
    }

    @Override
    public JobExecutionResult process(Job job, JobExecutionContext context) {
        context.initProgress(-1, -1);

        LOG.info("Searching all funds in Maestro...");
        final Collection<NormalFundImport> allFunds;
        try {
        	allFunds = maestroFundsApi.getAllFunds();
        } catch (Exception e) {
            LOG.error("Maestro tag import failed", e);
            context.log("Execution failed, please check the logs");
            return failedJobResult(context, "Execution failed, please check the logs");
        }
        LOG.info("Finished searching all funds in Maestro, found {}", allFunds.size());

        LOG.info("Searching all UCITS funds in Maestro...");
        final Collection<UcitsFundImport> allUcitsFunds;
        try {
        	allUcitsFunds = maestroFundsApi.getAllUcistsFunds();
        } catch (Exception e) {
            LOG.error("Maestro tag import failed", e);
            context.log("Execution failed, please check the logs");
            return failedJobResult(context, "Execution failed, please check the logs");
        }
        LOG.info("Finished searching all UCITS funds in Maestro, found {}", allFunds.size());

        return (JobExecutionResult)ResourceUtil.executeResourceActionInElevatedResourceResolver(resolverFactory, resourceResolver -> {
            int createTagFailed = 0;

            try {
		        context.log("Creating fund tags in AEM...");
		        Map<String, Resource> importedFunds =
		        		fundTagImportService.createFundTags(resourceResolver, allFunds);	
		        LOG.debug("Imported successfully {}/{} normal funds", importedFunds.size(), allFunds.size());

		        Map<String, Resource> importedUcitsFunds =
		        		fundTagImportService.createUcitsFundTags(resourceResolver, allUcitsFunds);	
		        LOG.debug("Imported successfully {}/{} UCITS funds", importedUcitsFunds.size(), allUcitsFunds.size());

		        LOG.info("Creating hidden pages for funds in AEM...");
	            SuccessFailedCountStats stats = pageCreationService.createViewpointPagesForFunds();
	            LOG.info("Created {}/{} hidden pages in AEM", stats.getSuccess(), stats.getTotal());
	
	        } catch (Exception e) {
	            LOG.error("Maestro tag import failed", e);
	            context.log("Execution failed, please check the logs");
	            return failedJobResult(context, "Execution failed, please check the logs");
	        }
	
            LOG.info("Replicating all fund tags from: " + JhiConstants.FUNDS_TAG_PATH);
            replicationService.activateTree(JhiConstants.FUNDS_TAG_PATH);

	        return createTagFailed == 0 ?
	                successfulJobResult(context, allFunds.size()) :
	                failedJobResult(context,
	                        createTagFailed + " tag creations failed, " + (allFunds.size() - createTagFailed) + " successful");
        });
    }

}
