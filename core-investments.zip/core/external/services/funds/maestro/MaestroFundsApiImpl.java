package com.jhi.aem.website.v1.core.external.services.funds.maestro;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.message.BasicNameValuePair;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.FundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.NormalFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UcitsFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UnpublishedFundImport;
import com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolService;
import com.jhi.aem.website.v1.core.utils.JsonUtil;

@Component(
		name = "JHI Maestro funds API service",
		service = MaestroFundsApi.class,
		configurationPid="com.jhi.aem.website.v1.core.external.services.funds.maestro.MaestroFundsApiImpl",
        configurationPolicy= ConfigurationPolicy.REQUIRE,
        property= {
	    		Constants.SERVICE_DESCRIPTION+"=Provides communications with the Maestro funds API",
	    		Constants.SERVICE_VENDOR+"=Maark LLC"
	    }
)

@Designate(ocd=MaestroFundsApiImpl.Config.class)
public class MaestroFundsApiImpl implements MaestroFundsApi {
    private final static Logger logger = LoggerFactory.getLogger(MaestroFundsApiImpl.class);
    
    public static final String MAESTRO_API_ENDPOINT_PARAMETER = "maestroEndPointUrl";
    public static final String MAESTRO_API_CLIENT_ID = "maestroApiClientId";
    public static final String MAESTRO_API_SECRET = "maestroApiSecret";
    public static final String MAESTRO_API_TIMEOUT_MS = "maestroApiTimeoutMs";

    private static final String MAESTRO_TOKEN_ENDPOINT_SUFFIX = "/oauth/token" ;
	private static final String MAESTRO_ALL_FUNDS_SUFFIX = "/fund";
	private static final String MAESTRO_UCITS_FUNDS_SUFFIX = "/fund/ucits";
	private static final String MAESTRO_UNPUBLISHED_FUNDS_SUFFIX="/fund/unpublished";
	
    @ObjectClassDefinition(name="JHI Maestro Funds Api configuration", description="Configurations for Maestro Funds API")
    public @interface Config{
    	final int DEFAULT_MAESTRO_API_TIMEOUT_MS = 30000;
    	
    	
    	@AttributeDefinition(name="Maestro API Endpoint",description="The endpoint URL for the Maestro API")
    	String maestroEndPointUrl() default  StringUtils.EMPTY;
    	
    	@AttributeDefinition(name = "Maestro API Client ID", description = "The Maestro API client id")
    	 String maestroApiClientId() default StringUtils.EMPTY;
    	
    	@AttributeDefinition(name = "Maestro API Secret", description = "The Maestro API secret")
    	 String maestroApiSecret() default StringUtils.EMPTY;
    	
    	@AttributeDefinition(name = "Maestro API Timeout (ms)", description = "Timeout in ms for Maestro requests",
 		type=AttributeType.INTEGER)
    	int maestroApiTimeoutMs() default DEFAULT_MAESTRO_API_TIMEOUT_MS;
    }
    
    

    
    private AsyncHttpClientPoolService asyncHttpClientPoolService;
    @Reference
    public void bindAsyncHttpClientPoolService(AsyncHttpClientPoolService asyncHttpClientPoolService) {
    	this.asyncHttpClientPoolService = asyncHttpClientPoolService;
    }
    public void unbindAsyncHttpClientPoolService(AsyncHttpClientPoolService asyncHttpClientPoolService) {
    	this.asyncHttpClientPoolService = asyncHttpClientPoolService;
    }
    

    private int maestroApiTimeoutMs;
    private String maestroApiEndpointUrl;
	private RequestConfig requestConfig;
	private String authHeader;
    private GsonBuilder gsonBuilder;
	private ArrayList<NameValuePair> oauthCredentialsRequestParameters;
	private String maestroTokenEndpointUrl;
	private String maestroAllFundsEndpointUri;
	private String maestroUcitsFundsEndpointUri;
	private String maestroUnpublishedFundsEndpointUri;

    @Activate
    protected void activate(final Config config) {
        configure(config);
    }
    
    @Modified
    protected void modified(final Config config) {
        configure(config);
    }

    void configure(final Config config) {
    	maestroApiEndpointUrl = StringUtils.removeStart(config.maestroEndPointUrl(), "/");
        logger.debug("Maestro API Endpoint URL: {}", maestroApiEndpointUrl);
        maestroTokenEndpointUrl = maestroApiEndpointUrl + MAESTRO_TOKEN_ENDPOINT_SUFFIX;
	    maestroAllFundsEndpointUri = maestroApiEndpointUrl + MAESTRO_ALL_FUNDS_SUFFIX;
	    maestroUcitsFundsEndpointUri = maestroApiEndpointUrl + MAESTRO_UCITS_FUNDS_SUFFIX;
	    maestroUnpublishedFundsEndpointUri = maestroApiEndpointUrl + MAESTRO_UNPUBLISHED_FUNDS_SUFFIX;
        
    	String maestroApiClientId = config.maestroApiClientId();
    	String maestroApiSecret = config.maestroApiSecret();
    	
    	if (StringUtils.isBlank(maestroApiClientId)) {
    		throw new RuntimeException("Maestro API client id is empty");
    	}

    	if (StringUtils.isBlank(maestroApiSecret)) {
    		throw new RuntimeException("Maestro API secret is empty");
    	}

    	authHeader = "Basic " + Base64.getEncoder().encodeToString(
    			new String(maestroApiClientId + ":" + maestroApiSecret).getBytes());

        oauthCredentialsRequestParameters = new ArrayList<NameValuePair>();
        oauthCredentialsRequestParameters.add(new BasicNameValuePair("grant_type", "client_credentials"));
        oauthCredentialsRequestParameters.add(new BasicNameValuePair("resource_id", "jhi-admin"));

    	maestroApiTimeoutMs = config.maestroApiTimeoutMs();
    	
        logger.debug("Set Maestro API timeout (ms): {}", maestroApiTimeoutMs);

        requestConfig = RequestConfig.custom()
                .setCookieSpec(CookieSpecs.STANDARD)
                .setRedirectsEnabled(true)
                .build();

        gsonBuilder = new GsonBuilder();
    }

    String executePost(HttpUriRequest httpRequest) {
        HttpClientContext httpClientContext = HttpClientContext.create();
        httpClientContext.setRequestConfig(requestConfig);

        InputStream is = null;
        try {
        	HttpResponse response;
            try (CloseableHttpAsyncClient client = asyncHttpClientPoolService.getClient()) {
                Future<HttpResponse> future = client.execute(httpRequest, httpClientContext, null);
                response = future.get(maestroApiTimeoutMs, TimeUnit.MILLISECONDS);
                StatusLine statusLine = response.getStatusLine();
                if (statusLine.getStatusCode() != HttpStatus.SC_OK) {
                	throw new IllegalStateException("HTTP error accessing '" + httpRequest.getURI().toString() + "' - " +
                			statusLine.getStatusCode() + ": " + statusLine.getReasonPhrase());
                }

                return JsonUtil.getJsonContent(response.getEntity().getContent());
            }
        } catch (IOException | InterruptedException | ExecutionException | TimeoutException e) {
            throw new IllegalStateException("Could not execute request to '" + httpRequest.getURI().toString() + "'", e);
        } finally {
            IOUtils.closeQuietly(is);
        }
    }
    
    @Override
	public OAuthCredentials getOAuthToken() {
		HttpPost post = new HttpPost(maestroTokenEndpointUrl);
        post.addHeader("Authorization", authHeader);

        try {
			post.setEntity(new UrlEncodedFormEntity(oauthCredentialsRequestParameters));
		} catch (UnsupportedEncodingException e) {
			logger.error("Could not URL encode form entity", e);
		}

    	String jsonResponse = executePost(post);
    	OAuthCredentials creds = gsonBuilder.create().fromJson(jsonResponse, OAuthCredentials.class);
    	creds.setEndpointUrl(maestroApiEndpointUrl);
    	return creds;
    }

	@Override
	public Collection<NormalFundImport> getAllFunds() {
		return (Collection<NormalFundImport>)getFunds(maestroAllFundsEndpointUri, new TypeToken<Collection<NormalFundImport>>(){}.getType());
	}
	
	@Override
	public Collection<UcitsFundImport> getAllUcistsFunds() {
		return (Collection<UcitsFundImport>)getFunds(maestroUcitsFundsEndpointUri, new TypeToken<Collection<UcitsFundImport>>(){}.getType());
	}
	
	Collection<? extends FundImport<?>> getFunds(String url, Type type) {
		OAuthCredentials oAuthToken = getOAuthToken();
		String authHeaderWithToken = "Bearer " + oAuthToken.getAccessToken();

		HttpGet get = new HttpGet(url);
		get.addHeader("Authorization", authHeaderWithToken);
    	String jsonResponse = executePost(get);
		return gsonBuilder.create().fromJson(jsonResponse, type);
	}
	
	@Override
	public UnpublishedFundImport getUnpublishedShareClassDetails(String fundToken) {
		URI uri;
		try {
			URIBuilder uriBuilder = new URIBuilder(maestroUnpublishedFundsEndpointUri);
			uriBuilder.addParameter(UNPUBLISHED_FUND_REQUEST_PARAMETER, fundToken);
			uri = uriBuilder.build();
		} catch (URISyntaxException e) {
			throw new IllegalArgumentException("Cannot build URI to unpublished funds endpoint " + 
					maestroUnpublishedFundsEndpointUri, e);
		}
		
		OAuthCredentials oAuthToken = getOAuthToken();
		String authHeaderWithToken = "Bearer " + oAuthToken.getAccessToken();

		HttpGet get = new HttpGet(uri);
		get.addHeader("Authorization", authHeaderWithToken);
    	String jsonResponse = executePost(get);
		return gsonBuilder.create().fromJson(jsonResponse, UnpublishedFundImport.class);
	}

}
