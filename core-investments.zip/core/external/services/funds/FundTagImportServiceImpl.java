package com.jhi.aem.website.v1.core.external.services.funds;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.jcr.query.Query;

import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.tagging.TagConstants;
import com.drew.lang.annotations.NotNull;
import com.jhi.aem.website.v1.core.constants.JhiConstants;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.FundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.NormalFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.ShareClassImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UcitsCountry;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UcitsFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UcitsShareClassImport;
import com.jhi.aem.website.v1.core.service.replication.ReplicationService;

@Component(
		name = "JHI Fund Tag Importer Service",
		service=FundTagImportService.class,
		immediate=true,
		configurationPid="com.jhi.aem.website.v1.core.external.services.funds.FundTagImportServiceImpl",
		property= {
	    		Constants.SERVICE_DESCRIPTION+"=Funds Tag Importer service",
	    		Constants.SERVICE_VENDOR+"=Maark LLC"
	    })

public class FundTagImportServiceImpl implements FundTagImportService {

    private static final Logger LOG = LoggerFactory.getLogger(FundTagImportServiceImpl.class);
    private static final String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final DateTimeFormatter QUERY_DATE_FORMATTER = DateTimeFormatter.ofPattern(DATE_PATTERN,
            Locale.ENGLISH);
    private static final String REMOVED_FUNDS_FROM_FEED_QUERY = "SELECT * FROM [cq:Tag] AS s WHERE ISDESCENDANTNODE([/content/cq:tags/jhi-website/funds]) "
            + "and (s.[jcr:lastModified] is null or s.[jcr:lastModified] < CAST('%s' AS DATE)) "
            + "and (s.[isFund] = 'true' or s.[isShareClass] = 'true')";

    
    private FundTagValidator validator;
    @Reference 
    public void bindFundTagValidator(FundTagValidator validator) {
    	this.validator=validator;
    }
    public void unbindFundTagValidator(FundTagValidator validator) {
    	this.validator=validator;
    }

    
    private ReplicationService replicationService;
    @Reference
    public void bindReplicationService(ReplicationService replicationService) {
    	this.replicationService=replicationService;
    }
    public void unbindReplicationService(ReplicationService replicationService) {
    	this.replicationService=replicationService;
    }

    public Map<String, Resource> createUcitsFundTags(ResourceResolver resolver,
    		Collection<UcitsFundImport> funds) throws FundTagImportException {
        Resource rootFundResource = getRootResource(resolver, JhiConstants.UCITS_FUNDS_TAG_PATH);
    	return createFundTagsInternal(resolver, funds, rootFundResource, true);
	}

    public Map<String, Resource> createFundTags(ResourceResolver resolver, Collection<NormalFundImport> funds)
    		throws FundTagImportException {
        Resource rootFundResource = getRootResource(resolver, JhiConstants.FUNDS_TAG_PATH);
    	return createFundTagsInternal(resolver, funds, rootFundResource, false);
    }
    
    private Map<String, Resource> createFundTagsInternal(ResourceResolver resolver, Collection<? extends FundImport<?>> funds,
    		Resource rootFundResource, boolean isUcits) throws FundTagImportException {
        Map<String, Resource> importedFunds = new HashMap<>();
        for (FundImport<?> fund : funds) {
            if (validator.validate(fund)) {
                Resource fundTag = createFundTagHierarchy(resolver, rootFundResource, fund, isUcits);

                if (fundTag != null) {
                    importedFunds.put(fund.getFundId(), fundTag);
                	LOG.debug("Importing {} share classes for fund '{}'",
                			fund.getFundId(), fund.getShareclasses() == null ? 0 : fund.getShareclasses().size());
                    int failed = createShareClassTags(resolver, fundTag, fund.getShareclasses(), isUcits);
                } else {
                	LOG.warn("Could not import fund tag, cannot create fund tag hierarchy for: {}", fund);
                }
            } else {
            	LOG.warn("Could not import fund tag, fund validation failed for: {}", fund);
            }
        }
        int importedSuccessfully = importedFunds.size();
        LOG.info("Funds imported successfully: [{}], funds import failed: [{}]",
        		importedSuccessfully, funds.size() - importedSuccessfully);
        return importedFunds;
    }

    private int createShareClassTags(ResourceResolver resolver, Resource fundResource,
    		Collection<? extends ShareClassImport> shareClasses, boolean isUcits) {
        int fundsImportedSuccessfully = 0;
        int fundsImportFailed = 0;

        for (ShareClassImport shareClass : shareClasses) {
        	boolean success = false;
            String id = getNormalizedId(shareClass);
            LOG.debug("Importing share class '{}'", id);

            String shareClassId = shareClass.getShareClassId();
            if (fundResource != null) {
	            if (BooleanUtils.isFalse(shareClass.isPublished())) {
	            	String fundResourcePath = fundResource.getPath();

	                Resource childFundClass = fundResource.getChild(id);
	                if (childFundClass != null && !ResourceUtil.isNonExistingResource(childFundClass)) {
		            	// Closed share class
		                LOG.debug("Share class with id: [{}] is closed, deleting path {}",
		                		shareClassId, fundResourcePath);		                
	                	deleteResource(childFundClass);
                        success = true;
	                } else {
	                	LOG.error("Could not find resource to delete share class with id {} and fund path {}, "
	                			+ "expected child {} but only found these children of the fund: {}",
	                			new Object[] {
	                					shareClassId, fundResourcePath, fundResourcePath, id,
	                					IteratorUtils.toList(fundResource.listChildren()).stream()
	                						.map(Resource::getName)
	                						.collect(Collectors.toList())});
	                }
	
	            } else {
	            	if (validator.validate(shareClass, isUcits)) {
	                    try {
	                        Map<String, Object> shareClassProps = mapClssProperties(shareClass, isUcits);
							createModifyTag(fundResource, id, shareClassProps);

							// Ensure deactivated funds are replicated
							if (BooleanUtils.isFalse((Boolean)shareClassProps.get(JhiConstants.ACTIVE))) {
								replicationService.activateTree(fundResource.getPath());
							}
	                        success = true;
	                    } catch (FundTagImportException e) {
	                        LOG.error("Could not create or modify share class {} tag at fund path {}, child {}",
	                        		new Object[] {shareClassId, fundResource.getPath(), id, e});
	                    }
	            	} else {
                        LOG.error("Error validating share class, could not create or modify share class {} tag at fund path {}, child {}",
                        		new Object[] {shareClassId, fundResource.getPath(), id});
	            	}
	            }
            } else {
                LOG.error("No fund resource found for: [{}]", shareClassId);
            }

            if (success) {
            	fundsImportedSuccessfully++;
            } else {
            	fundsImportFailed++;
            }
        }

        LOG.info("Share class imported successfully: [{}], {}/{} imported successfully ({} errors)",
        		new Object [] {fundsImportedSuccessfully, shareClasses.size(), fundsImportFailed});
        return fundsImportFailed;
    }

    @Override
    public void deleteRemovedFromKurtosysTags(ResourceResolver resolver) {
        LocalDateTime now = LocalDateTime.now(ZoneId.systemDefault());
        String formattedQuery = String.format(Locale.ENGLISH, REMOVED_FUNDS_FROM_FEED_QUERY,
                QUERY_DATE_FORMATTER.format(now.minusDays(1).minusMinutes(1)));
        resolver.findResources(formattedQuery, Query.JCR_SQL2)
                .forEachRemaining(this::deleteResource);
    }

    private String getNormalizedId(ShareClassImport clss) {
        String shareClass = clss.getClassCode();
        String currency = StringUtils.isNotBlank(clss.getIsIn()) && StringUtils.isNotBlank(clss.getCurrencyCode()) ?
        		clss.getCurrencyCode() : StringUtils.EMPTY;
        return normalizeId(shareClass + currency);
    }

    private void deleteResource(Resource resource) {
        try {
            replicationService.deactivateTree(resource.getPath());
            LOG.debug("Deleting closed share class under path: {}", resource.getPath());
            ResourceResolver resolver = resource.getResourceResolver();
            resolver.delete(resource);
            resolver.commit();
        } catch (PersistenceException e) {
            LOG.warn("Couldn't delete resource: {}", resource.getPath());
            LOG.warn("PersistenceException: {}", e.getMessage());
        }
    }

    private Resource createFundTagHierarchy(ResourceResolver resolver, Resource rootFundResource,
    		FundImport<?> fund, boolean isUcits) {
    	LOG.debug("Importing fund '{}' (product type={}, category type={}, is UCITS={})",
    			new Object[] {fund.getFundId(), fund.getProductType(), fund.getAssetClass(), isUcits});

    	try {
    		Resource categoryParentResource;
    		
    		if (!isUcits) {
	            String productTypeValue = fund.getProductType();
	            Resource productType = createModifyTag(rootFundResource, normalizeId(productTypeValue),
	                    getCommonTagProperties(productTypeValue));
	            categoryParentResource = productType;
    		} else {
    			// For UCITS funds don't create a product type folder in the hierarchy
    			categoryParentResource = rootFundResource;
    		}

            String categoryTypeValue = fund.getAssetClass();
            Resource categoryType = createModifyTag(categoryParentResource, normalizeId(categoryTypeValue),
                    getCommonTagProperties(categoryTypeValue));

            String displayNameValue = fund.getName();
            Map<String, Object> fundProps = mapFundProperties(fund, isUcits);
			Resource fundTagResource = createModifyTag(categoryType, normalizeId(displayNameValue), fundProps);

			// Ensure deactivated funds are replicated
			if (BooleanUtils.isFalse((Boolean)fundProps.get(JhiConstants.ACTIVE))) {
				replicationService.activateTree(fundTagResource.getPath());
			}
			
			return fundTagResource;

        } catch (FundTagImportException e) {
            LOG.error(e.getMessage());
        }
        return null;
    }

    @NotNull
    private Resource createModifyTag(Resource rootFundResource, String tagId, Map<String, Object> properties)
            throws FundTagImportException {
        if (rootFundResource == null) {
            LOG.error("Root tag resource is null. Cannot import tag id: [{}]", tagId);
            throw new FundTagImportException("Root tag resource is null. Cannot import tag id: " + tagId);
        }
        Resource child = rootFundResource.getChild(tagId);
        if (child == null) {
            LOG.debug("TAG id [{}] for {} not found. Creating it.", tagId, rootFundResource.getPath());
            return createTag(rootFundResource, tagId, properties);
        }
        LOG.debug("TAG id [{}] for {} found. Modifying it.", tagId, rootFundResource.getPath());
        return modifyTag(child, properties);
    }

    @NotNull
    private Resource getRootResource(ResourceResolver resolver, String fundsPath) throws FundTagImportException {
        return Optional.ofNullable(resolver.getResource(fundsPath))
                .orElseThrow(() -> new FundTagImportException("[" + fundsPath + "] resource doesn't exist."));
    }

    @NotNull
    private Resource createTag(Resource resource, String tagId, Map<String, Object> properties) throws FundTagImportException {
        try {
            ResourceResolver resolver = resource.getResourceResolver();
            Resource tag = resolver.create(resource, tagId, properties);
            resolver.commit();
            return tag;
        } catch (PersistenceException e) {
            LOG.error("Couldn't create tag with id: [{}]. Exception: [{}]", tagId, e.getMessage());
            throw new FundTagImportException("Couldn't create tag with id: [" + tagId + "]. Exception: " + e.getMessage());
        }
    }

    @NotNull
    private Resource modifyTag(Resource resource, Map<String, Object> properties) throws FundTagImportException {
        ModifiableValueMap modifiableValueMap = resource.adaptTo(ModifiableValueMap.class);
        if (modifiableValueMap != null) {
            modifiableValueMap.putAll(properties);
            try {
                resource.getResourceResolver().commit();
            } catch (PersistenceException e) {
                LOG.error("Couldn't modify tag. Exception: " + e.getMessage());
                throw new FundTagImportException("Couldn't modify tag. Exception: " + e.getMessage());
            }
            return resource;
        }
        LOG.error("Couldn't adapt resource: [{}] to ModifiableValueMap.", resource.getPath());
        throw new FundTagImportException("Couldn't adapt resource [" + resource.getPath() + "] to ModifiableValueMap.");
    }

    private Map<String, Object> getCommonTagProperties(String title) {
        Map<String, Object> properties = new HashMap<>();
        properties.put(ResourceResolver.PROPERTY_RESOURCE_TYPE, "cq/tagging/components/tag");
        properties.put(JcrConstants.JCR_PRIMARYTYPE, TagConstants.NT_TAG);
        properties.put(JcrConstants.JCR_TITLE, title);
        properties.put(JcrConstants.JCR_LASTMODIFIED, Calendar.getInstance());
        return properties;
    }

    private Map<String, Object> mapClssProperties(final ShareClassImport clss, final boolean isUcits) {
        Map<String, Object> properties = getCommonTagProperties(clss.getName());
        addNotEmptyStringProperty(properties, JhiConstants.SHARE_CLASS_CODE, clss.getClassCode());
        boolean isPublished = BooleanUtils.isTrue(clss.isPublished());
        properties.put(JhiConstants.PUBLISHED, isPublished);

        // Make sure that unpublished funds are inactive so they cannot be viewed on the publishers
        if (!isPublished) {
        	properties.put(JhiConstants.ACTIVE, false);
        }

        addNotEmptyStringProperty(properties, JhiConstants.TICKER_ID, clss.getSymbol());
        addNotEmptyStringProperty(properties, JhiConstants.CUSIP, clss.getCusip());
        addNotEmptyStringProperty(properties, JhiConstants.ISIN, clss.getIsIn());
        addNotEmptyStringProperty(properties, JhiConstants.CURRENCY, clss.getCurrencyCode());
        addNotEmptyStringProperty(properties, JhiConstants.INCEPTION_DATE, clss.getDateInception());

        if (clss.getMorningStarData() != null) {
	        addNotEmptyStringProperty(properties, JhiConstants.MORNING_STAR_CATEGORY, clss.getMorningStarData().getCategory());
	        if (clss.getMorningStarData().getOverallRating() != null) {
	        	properties.put(JhiConstants.MORNING_STAR_RATING, clss.getMorningStarData().getOverallRating());
	        }
        } else {
        	LOG.debug("No MorningStar data found for share class {}", clss.getShareClassId());
        }

        addNotEmptyStringProperty(properties, JhiConstants.SHARE_CLASS, clss.getShareClassId());
        properties.put(JhiConstants.IS_SHARE_CLASS, true);
        
        if (isUcits) {
        	UcitsShareClassImport ucitsImport = (UcitsShareClassImport)clss;

        	if (ucitsImport.getCountries() != null) {
        		LOG.debug("Country codes found for {}: {}", ucitsImport.getShareClassId(), ucitsImport.getCountries());
	        	Set<String> countryCodes = ucitsImport.getCountries().stream()
	        		.map(UcitsCountry::getCountryCode)
	        		.collect(Collectors.toSet());
	        	properties.put(JhiConstants.UCITS_COUNTRIES, countryCodes.toArray(ArrayUtils.EMPTY_STRING_ARRAY));
        	} else {
        		LOG.debug("No countries found for {}", ucitsImport.getShareClassId());
        	}
        }

        // Set UCITS property
        properties.put(JhiConstants.IS_UCITS_PROPERTY, isUcits);

        return properties;
    }
    
    private void addNotEmptyStringProperty(Map<String,Object> map, String key, String value) {
    	if (StringUtils.isNotBlank(value)) {
    		map.put(key, value);
    	}
    }

    private Map<String, Object> mapFundProperties(FundImport<?> fund, boolean isUcits) {
        Map<String, Object> map = getCommonTagProperties(fund.getName());
        map.put(JhiConstants.IS_UCITS_PROPERTY, isUcits);
        map.put(JhiConstants.FUND_ID, fund.getFundId());
        boolean isPublished = BooleanUtils.isTrue(fund.getPublished());
        map.put(JhiConstants.PUBLISHED, isPublished);
        if (!isPublished) {
        	// Make sure that unpublished funds are inactive so they cannot be viewed on the publishers
        	map.put(JhiConstants.ACTIVE, false);
        }
        map.put(JhiConstants.IS_FUND, true);
        map.put(JhiConstants.USE_FOR, fund.getOverviewData() == null ? 
        		StringUtils.EMPTY : StringUtils.defaultIfEmpty(fund.getOverviewData().getUseFor(), StringUtils.EMPTY));
        return map;
    }

    private String normalizeId(String str) {
    	String returnStr = StringUtils.trim(str);
    	returnStr = StringUtils.lowerCase(returnStr);
    	returnStr = StringUtils.replace(returnStr, ".", StringUtils.EMPTY);
    	returnStr = StringUtils.replacePattern(returnStr, "([^a-zA-Z0-9])+", "-");
    	return StringUtils.defaultString(StringUtils.stripEnd(returnStr, "-"), StringUtils.EMPTY);
    }
 
}
