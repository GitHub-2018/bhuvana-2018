package com.jhi.aem.website.v1.core.external.services.funds;

import java.util.Collection;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.jhi.aem.website.v1.core.external.models.funds.maestro.NormalFundImport;
import com.jhi.aem.website.v1.core.external.models.funds.maestro.UcitsFundImport;

public interface FundTagImportService {

	Map<String, Resource> createUcitsFundTags(ResourceResolver resolver, Collection<UcitsFundImport> funds)
    		throws FundTagImportException;

	Map<String, Resource> createFundTags(final ResourceResolver resolver, final Collection<NormalFundImport> funds) 
    		throws FundTagImportException;

    void deleteRemovedFromKurtosysTags(ResourceResolver resolver);
}
