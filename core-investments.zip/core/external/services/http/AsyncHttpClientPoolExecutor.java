package com.jhi.aem.website.v1.core.external.services.http;

import java.io.Closeable;
import java.io.IOException;
import java.util.concurrent.Future;

import org.apache.http.HttpResponse;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;

public class AsyncHttpClientPoolExecutor implements Closeable {

	private static RequestConfig standardRequestConfig = RequestConfig.custom()
            .setCookieSpec(CookieSpecs.STANDARD)
            .setRedirectsEnabled(true)
            .build();

	private AsyncHttpClientPoolService asyncHttpClientPoolService;
	private RequestConfig requestConfig;
	private CloseableHttpAsyncClient httpClient;
	private FutureCallback<HttpResponse> executeCallback;

	public AsyncHttpClientPoolExecutor(AsyncHttpClientPoolService asyncHttpClientPoolService) {
		this.asyncHttpClientPoolService = asyncHttpClientPoolService;
	}
	
	public AsyncHttpClientPoolExecutor withRequestConfig(RequestConfig requestConfig) {
		this.requestConfig = requestConfig;
		return this;
	}
	
	public AsyncHttpClientPoolExecutor withStandardRequestConfig() {
		this.requestConfig = standardRequestConfig;
		return this;
	}
	
	public AsyncHttpClientPoolExecutor withFutureCallback(FutureCallback<HttpResponse> executeCallback) {
		this.executeCallback = executeCallback;
		return this;
	}

	public Future<HttpResponse> execute(HttpRequestBase requestBase) {
		HttpClientContext httpClientContext = HttpClientContext.create();
		if (requestConfig != null) {
			httpClientContext.setRequestConfig(requestConfig);
		}

		httpClient = asyncHttpClientPoolService.getClient();
		return httpClient.execute(requestBase, httpClientContext, executeCallback);
	}

	public Future<HttpResponse> execute(HttpRequestBase requestBase, HttpClientContext httpClientContext) {
		if (requestConfig != null) {
			httpClientContext.setRequestConfig(requestConfig);
		}

		httpClient = asyncHttpClientPoolService.getClient();
		return httpClient.execute(requestBase, httpClientContext, executeCallback);
	}

	@Override
	public void close() throws IOException {
		if (httpClient == null) {
			throw new IllegalStateException("The request hasn't been executed yet or the client has already been closed");
		}

		httpClient.close();
		httpClient = null;
	}

}
