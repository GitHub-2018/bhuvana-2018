package com.jhi.aem.website.v1.core.external.services.http;

import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;

public interface AsyncHttpClientPoolService {

	/**
	 * Returns a HTTP client
	 * @return 
	 */
	CloseableHttpAsyncClient getClient();

//	HttpResponse executeAsyncRequest(HttpRequestBase httpRequest, HttpClientContext localContext, int requestTimeoutMs)
//			throws IOException, InterruptedException, ExecutionException, TimeoutException;

}