package com.jhi.aem.website.v1.core.external.services.http;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.Header;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.MessageConstraints;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.DnsResolver;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.DefaultHttpResponseFactory;
import org.apache.http.impl.conn.SystemDefaultDnsResolver;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.impl.nio.codecs.DefaultHttpRequestWriterFactory;
import org.apache.http.impl.nio.codecs.DefaultHttpResponseParser;
import org.apache.http.impl.nio.codecs.DefaultHttpResponseParserFactory;
import org.apache.http.impl.nio.conn.ManagedNHttpClientConnectionFactory;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicLineParser;
import org.apache.http.message.LineParser;
import org.apache.http.nio.NHttpMessageParser;
import org.apache.http.nio.NHttpMessageParserFactory;
import org.apache.http.nio.NHttpMessageWriterFactory;
import org.apache.http.nio.conn.ManagedNHttpClientConnection;
import org.apache.http.nio.conn.NHttpConnectionFactory;
import org.apache.http.nio.conn.NoopIOSessionStrategy;
import org.apache.http.nio.conn.SchemeIOSessionStrategy;
import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
import org.apache.http.nio.reactor.ConnectingIOReactor;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.http.nio.reactor.SessionInputBuffer;
import org.apache.http.nio.util.HeapByteBufferAllocator;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.CharArrayBuffer;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Option;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Maintains a pool of HTTP client connections
 */
@Component(
		name = "AsyncHttpClientPoolService - JHI Website",
		service= AsyncHttpClientPoolService.class,
		immediate = true,
		configurationPid="com.jhi.aem.website.v1.core.external.services.http.AsyncHttpClientPoolServiceImpl",
		configurationPolicy=ConfigurationPolicy.OPTIONAL	
		)

@Designate(ocd=AsyncHttpClientPoolServiceImpl.Config.class)
public class AsyncHttpClientPoolServiceImpl implements AsyncHttpClientPoolService {
	private static final Logger logger = LoggerFactory.getLogger(AsyncHttpClientPoolServiceImpl.class);

	private static final int DEFAULT_MAX_CONNECTIONS = 200;
	private static final int DEFAULT_CONNECTION_TIMEOUT_MS = 30000;
	private static final int DEFAULT_SO_TIMEOUT_MS = 30000;
	private static final int DEFAULT_IO_THREAD_COUNT = 4;
	private static final boolean DEFAULT_REDIRECTS_ENABLED = true;
	private static final String DEFAULT_COOKIE_SPEC = CookieSpecs.STANDARD;
	
	@ObjectClassDefinition(name="AsyncHttpClient Pool Service configuration for JHI Website", description="Configuration properties for AsyncHttpClient Pool Service Implementations")
	public @interface Config{
		@AttributeDefinition(name = "Max Connection",type=AttributeType.INTEGER,
				description = "Max number of outgoing HTTP connections")
	    int maxConnections() default DEFAULT_MAX_CONNECTIONS;
		
		@AttributeDefinition(name = "Connection Timeout (ms)", type = AttributeType.INTEGER ,
				description = "The number of milliseconds before a connection attempt times out")
	    int connectionTimeout() default DEFAULT_CONNECTION_TIMEOUT_MS;
		
		@AttributeDefinition(name = "Socket Connection Timeout (ms)", type =AttributeType.INTEGER ,
				description = "The number of milliseconds before a socket connection attempt times out")
	    int soTimeout() default DEFAULT_SO_TIMEOUT_MS;
		
		@AttributeDefinition(name = "I/O Thread Count", type = AttributeType.INTEGER,
				description = "The number of threads to use for async I/O")
	    int ioThreadCount() default DEFAULT_IO_THREAD_COUNT;
	    
	    
		@AttributeDefinition(name = "Redirects enabled", type = AttributeType.BOOLEAN,
				description = "Are redirects possible through HTTP calls?")
	    boolean redirectsEnabled() default DEFAULT_REDIRECTS_ENABLED;
	    
	    
		
		@AttributeDefinition(name = "Cookie Spec", description = "Cookie specification to use",
				options = {
					@Option(label = CookieSpecs.STANDARD, value = CookieSpecs.STANDARD),
					@Option(label = CookieSpecs.DEFAULT, value = CookieSpecs.DEFAULT),
					@Option(label = CookieSpecs.IGNORE_COOKIES, value = CookieSpecs.IGNORE_COOKIES),
					@Option(label = CookieSpecs.NETSCAPE, value = CookieSpecs.NETSCAPE),
					@Option(label = CookieSpecs.STANDARD, value = CookieSpecs.STANDARD),
					@Option(label = CookieSpecs.STANDARD_STRICT, value = CookieSpecs.STANDARD_STRICT),
				})
	    String cookieSpec() default DEFAULT_COOKIE_SPEC;
	}
	
    private int maxConnections;

	
	
    private int connectionTimeout;


	
    private int soTimeout;

    private int ioThreadCount;
    private boolean redirectsEnabled;
	
    private String cookieSpec;
    
    private PoolingNHttpClientConnectionManager connectionManager;
	private RequestConfig globalConfig;
	private ConnectingIOReactor ioReactor;

	private CloseableHttpAsyncClient dummySharedClient;

    @Activate
    @Modified
    protected void activate(final Config config) throws IOReactorException {
        configure(config);
    }
    
  
    
    public void configure(final Config config) throws IOReactorException {
    	maxConnections = config.maxConnections();
    	connectionTimeout = config.connectionTimeout();
    	soTimeout = config.soTimeout();
    	cookieSpec = config.cookieSpec();
    	redirectsEnabled = config.redirectsEnabled();
    	ioThreadCount = PropertiesUtil.toInteger(
    			config.ioThreadCount(), Runtime.getRuntime().availableProcessors());

        // Use custom message parser / writer to customize the way HTTP
        // messages are parsed from and written out to the data stream.
        NHttpMessageParserFactory<HttpResponse> responseParserFactory = new DefaultHttpResponseParserFactory() {

            @Override
            public NHttpMessageParser<HttpResponse> create(
                    final SessionInputBuffer buffer,
                    final MessageConstraints constraints) {
                LineParser lineParser = new BasicLineParser() {

                    @Override
                    public Header parseHeader(final CharArrayBuffer buffer) {
                        try {
                            return super.parseHeader(buffer);
                        } catch (ParseException ex) {
                            return new BasicHeader(buffer.toString(), null);
                        }
                    }

                };
                return new DefaultHttpResponseParser(
                        buffer, lineParser, DefaultHttpResponseFactory.INSTANCE, constraints);
            }

        };
        NHttpMessageWriterFactory<HttpRequest> requestWriterFactory = new DefaultHttpRequestWriterFactory();

        // Use a custom connection factory to customize the process of
        // initialization of outgoing HTTP connections. Beside standard connection
        // configuration parameters HTTP connection factory can define message
        // parser / writer routines to be employed by individual connections.
        NHttpConnectionFactory<ManagedNHttpClientConnection> connFactory =
        	new ManagedNHttpClientConnectionFactory(
                requestWriterFactory, responseParserFactory, HeapByteBufferAllocator.INSTANCE);

        // Client HTTP connection objects when fully initialized can be bound to
        // an arbitrary network socket. The process of network socket initialization,
        // its connection to a remote address and binding to a local one is controlled
        // by a connection socket factory.

        // SSL context for secure connections can be created either based on
        // system or application specific properties.
        TrustStrategy acceptingTrustStrategy = TrustSelfSignedStrategy.INSTANCE;
        SSLContext sslContext;
		try {
			sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
			logger.error("Could not build SSL context", e);
			throw new RuntimeException("Could not build SSL context");
		}

        // Use custom hostname verifier to customize SSL hostname verification.
        HostnameVerifier hostnameVerifier = new DefaultHostnameVerifier();

        // Create a registry of custom connection session strategies for supported
        // protocol schemes.
        Registry<SchemeIOSessionStrategy> sessionStrategyRegistry = RegistryBuilder.<SchemeIOSessionStrategy>create()
            .register("http", NoopIOSessionStrategy.INSTANCE)
            .register("https", new SSLIOSessionStrategy(sslContext, hostnameVerifier))
            .build();

        // Use custom DNS resolver to override the system DNS resolution.
        DnsResolver dnsResolver = new SystemDefaultDnsResolver() {

            @Override
            public InetAddress[] resolve(final String host) throws UnknownHostException {
                if (host.equalsIgnoreCase("localhost")) {
                    return new InetAddress[] { InetAddress.getByAddress(new byte[] {127, 0, 0, 1}) };
                } else {
                    return super.resolve(host);
                }
            }

        };

        // Create I/O reactor configuration
        IOReactorConfig ioReactorConfig = IOReactorConfig.custom()
                .setIoThreadCount(ioThreadCount)
                .setConnectTimeout(connectionTimeout)
                .setSoTimeout(soTimeout)
                .build();

        // Create a custom I/O reactor
        ioReactor = new DefaultConnectingIOReactor(ioReactorConfig);

        Object[] logMsgArray = new Object[] {maxConnections, connectionTimeout, soTimeout,
        		cookieSpec, redirectsEnabled, ioThreadCount};
		logger.info("Starting Async HTTP client pool with: max connections={}, connection timeout={}ms, "
				+ "socket timeout={}ms, cookieSpec={}, redirects enabled={}, ioThreadCount={}...", logMsgArray);
		connectionManager = new PoolingNHttpClientConnectionManager(
                ioReactor, connFactory, sessionStrategyRegistry, dnsResolver);
		connectionManager.setMaxTotal(maxConnections);
		connectionManager.setDefaultMaxPerRoute(maxConnections);

		globalConfig = RequestConfig.custom()
		        .setCookieSpec(cookieSpec)
		        .setRedirectsEnabled(redirectsEnabled)
		        .build();

		logger.info("Started Async HTTP client pool with: max connections={}, connection timeout={}ms, "
				+ "socket timeout={}ms, cookieSpec={}, redirects enabled={}, ioThreadCount={}", logMsgArray);

		// Own the connection manager
		dummySharedClient = getClient(false);
		dummySharedClient.start();
	}
	
    @Deactivate
    protected void deactivate(final Map<String, Object> config) {
    	if (dummySharedClient != null) {
	    	logger.info("Closing down Async HTTP client pool dummy shared client connection");

	    	try {
				dummySharedClient.close();
		    	logger.info("Closed down Async HTTP client pool dummy shared client connection");
			} catch (IOException e) {
				logger.error("Could not close down Async HTTP client pool dummy shared client connection", e);
			}
	    	
	    	dummySharedClient = null;
    	}

    	if (connectionManager != null) {
	    	logger.info("Closing down Async HTTP client pool connection manager");
			try {
				connectionManager.shutdown();
		    	logger.info("Closed down Async HTTP client pool connection manager");
			} catch (IOException e) {
				logger.error("Could not close down Async HTTP client pool connection manager", e);
			}
	    	connectionManager = null;
    	}
    	
    	if (ioReactor != null) {
    		logger.info("Shutting down Async HTTP client I/O reactor");
    		try {
				ioReactor.shutdown();
		    	logger.info("Closed down Async HTTP client pool I/O reactor");
			} catch (IOException e) {
				logger.error("Coould not initiate I/O reactor shutdown", e);
			}
    		
    		ioReactor = null;
    	}    	
	}

	@Override
	public CloseableHttpAsyncClient getClient() {
		return getClient(true);
	}
	
	private CloseableHttpAsyncClient getClient(boolean sharedConnectionManager) {
		CloseableHttpAsyncClient client =
			HttpAsyncClients.custom()
		        .setConnectionManager(connectionManager)
		        .setConnectionManagerShared(sharedConnectionManager)
		        .setDefaultRequestConfig(globalConfig)
		        .build();
		client.start();
		return client;
	}

}
