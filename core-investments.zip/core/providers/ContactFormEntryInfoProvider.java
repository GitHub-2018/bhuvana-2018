package com.jhi.aem.website.v1.core.providers;


import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.annotations.Component;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageInfoProvider;
import com.jhi.aem.website.v1.core.models.contact.ContactFormEntryModel;
import com.jhi.aem.website.v1.core.servlets.contactform.ContactFormServlet;

@Component(
		name="Contact Form Entry Infor Provider",
		service=PageInfoProvider.class,
		immediate = true,
		property= {
				"pageInfoProviderType=sites.listView.info.provider." + ContactFormEntryInfoProvider.PROVIDER_TYPE
				
		})

public class ContactFormEntryInfoProvider implements PageInfoProvider {

    public static final String PROVIDER_TYPE = "contactform";

    public void updatePageInfo(SlingHttpServletRequest request, JSONObject info, Resource resource)
            throws JSONException {
        // just to get rid of log messages
        info.put(PROVIDER_TYPE, new JSONObject());
        
        
        final Page page = resource.adaptTo(Page.class);
        if (page == null) {
            return;
        }

        final Resource contentResource = page.getContentResource();
        if (contentResource == null) {
            return;
        }

        final Resource componentResource = contentResource.getChild(ContactFormServlet.CONTACT_FORM_RESOURCE_NAME);
        if (componentResource == null) {
            return;
        }

        final ContactFormEntryModel componentModel = componentResource.adaptTo(ContactFormEntryModel.class);

        JSONObject contactFormInfo = new JSONObject();
        contactFormInfo.put("timestamp", componentModel.getFormattedTimestamp());
        contactFormInfo.put("firstname", componentModel.getFirstName());
        contactFormInfo.put("lastname", componentModel.getLastName());
        contactFormInfo.put("topic", componentModel.getTopic());

        info.put(PROVIDER_TYPE, contactFormInfo);
    }
}
