package com.jhi.aem.website.v1.core.constants;

public final class ComponentConstants {
	
	public static final String IMAGE_COMPONENT = "jhi-website-v1/components/content/image";
	public static final String VIDEO_COMPONENT = "jhi-website-v1/components/content/video";
	
	private ComponentConstants() {
	}

}
