package com.jhi.aem.website.v1.core.constants;

public final class ResourcesConstants {

    public static final String HOME_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/home";
    public static final String SEARCH_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/search";
    public static final String VIEWPOINTS_SEARCH_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsSearch";
    public static final String LOGIN_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/loginPage";
    public static final String REGISTRATION_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/registrationPage";
    public static final String DASHBOARD_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/dashboard";
    public static final String REDIRECT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/redirect";
    public static final String REDIRECT_PAGE_TEMPLATE = "/apps/jhi-website-v1/templates/redirect";
    public static final String ABOUT_US_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/aboutUs";
    public static final String HOMEPAGE_HERO_RESOURCE_TYPE = "jhi-website-v1/components/structure/homepageHero";

    public static final String DASHBOARD_CONTENT_RESOURCE_TYPE = "jhi-website-v1/components/structure/dashboardContent";
    public static final String DASHBOARD_TABS_RESOURCE_TYPE = "jhi-website-v1/components/structure/dashboardTabs";

    public static final String CART_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/cart";
    public static final String CHECKOUT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/checkout";
    public static final String CHECKOUT_CONFIRMATION_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/checkoutConfirmation";

    public static final String REGISTER_EMPLOYEE_RESOURCE_TYPE = "jhi-website-v1/components/structure/registration/registerEmployeeComplete";
    public static final String REGISTER_UNVERIFIED_RESOURCE_TYPE = "jhi-website-v1/components/structure/registration/registerUnverifiedUserComplete";
    public static final String REGISTER_VERIFIED_RESOURCE_TYPE = "jhi-website-v1/components/structure/registration/registerVerifiedUserComplete";
    public static final String REGISTRATION_START_RESOURCE_TYPE = "jhi-website-v1/components/structure/registration/registrationStart";
    public static final String GENERATE_FORGOT_PASSWORD_RESOURCE_TYPE = "jhi-website-v1/components/structure/forgotPasswordSection";
    public static final String RESET_PASSWORD_RESOURCE_TYPE = "jhi-website-v1/components/structure/resetPasswordSection";
    public static final String CHANGE_PASSWORD_RESOURCE_TYPE = "jhi-website-v1/components/structure/changePasswordSection";

    public static final String CART_RESOURCE_TYPE = "jhi-website-v1/components/structure/cart";
    public static final String CHECKOUT_RESOURCE_TYPE = "jhi-website-v1/components/structure/checkout";

    public static final String VIEWPOINT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpoint";
    public static final String VIEWPOINT_ARTICLE_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpoint_article";
    public static final String VIEWPOINT_AUDIO_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpoint_audio";
    public static final String VIEWPOINT_DOCUMENT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpoint_document";
    public static final String VIEWPOINT_VIDEO_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpoint_video";
    public static final String VIEWPOINT_WHITEPAPER_RESOURCE_TYPE = "jhi-website-v1/pages/viewpoint_whitepaper";
    public static final String VIEWPOINT_LIST_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsList";
    public static final String VIEWPOINTS_MAIN_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpoints";

    public static final String VIEWPOINT_DOCUMENT_RESOURCE_TYPE = "jhi-website-v1/components/content/viewpointDocument";

    public static final String VIEWPOINTS_ASSET_MANAGERS_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsAssetManagersRoot";
    public static final String VIEWPOINTS_ASSET_MANAGER_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsAssetManager";
    public static final String VIEWPOINTS_AUTHORS_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsAuthorsRoot";
    public static final String VIEWPOINTS_AUTHOR_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsAuthor";
    public static final String VIEWPOINTS_TAGS_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsTagsRoot";
    public static final String VIEWPOINTS_TAG_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsTag";
    public static final String VIEWPOINTS_TOPICS_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsTopicsRoot";
    public static final String VIEWPOINTS_TOPIC_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsTopic";
    public static final String VIEWPOINTS_LIST_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/viewpointsList";

    public static final String LATEST_VIEWPOINTS_RESOURCE_TYPE = "jhi-website-v1/components/content/latestViewpoints";

    public static final String RESOURCES_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/resources";
    public static final String RESOURCES_LIST_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/resourcesList";
    public static final String RESOURCES_AUDIENCE_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/resourcesAudience";
    public static final String RESOURCES_TOPIC_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/resourcesTopic";
    public static final String RESOURCE_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/resource";
    public static final String RESOURCE_SUITE_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/resource_suite";
    public static final String RESOURCE_DOCUMENT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/resource_document";

    public static final String SUITE_DOCUMENTS_RESOURCE_TYPE = "jhi-website-v1/components/content/suiteDocuments";
    public static final String SUITE_DOCUMENT_RESOURCE_TYPE = "jhi-website-v1/components/content/suiteDocument";
    public static final String RESOURCE_DOCUMENT_RESOURCE_TYPE = "jhi-website-v1/components/structure/resourceDocument";

    public static final String ASSET_MANAGER_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/assetManager";
    public static final String ASSET_MANAGER_CONFIG_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/assetManagerConfig";
    public static final String ASSET_MANAGERS_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/assetManagersRoot";
    public static final String ASSET_MANAGERS_CONFIG_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/assetManagerConfigsRoot";
    public static final String PERSON_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/person";
    public static final String PEOPLE_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/peopleRoot";
    public static final String PRESS_RELEASE_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/pressRelease";
    public static final String PRESS_RELEASES_ROOT_RESOURCE_TYPE = "jhi-website-v1/pages/pressReleasesRoot";

    public static final String INVESTMENTS_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/investments";

    public static final String TOOLS_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/tools";
    public static final String TOOLS_PORTFOLIO_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/toolsPortfolio";

    public static final String FUNDS_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/fundsRoot";
    public static final String FUND_CLASS_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/fundClass";
    public static final String FUND_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/fund";
    public static final String FUND_DETAILS_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/fundDetails";
    public static final String FUND_COMPARISON_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/fundComparison";

    public static final String CONTACT_FORM_RESOURCE_TYPE = "jhi-website-v1/components/structure/contactForm";
    public static final String CONTACT_FORM_ENTRY_RESOURCE_TYPE = "jhi-website-v1/components/structure/contactFormEntry";
    public static final String CONTACT_ENTRIES_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/contactEntriesRoot";
    public static final String CONTACT_ENTRY_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/contactEntry";
    public static final String CONTACT_ENTRY_PAGE_TEMPLATE = "jhi-website-v1/templates/contactEntry";

    public static final String SUBNAV_MARKER_RESOURCE_TYPE = "jhi-website-v1/components/content/micrositeSubnavMarker";

    public static final String HEADER_RESOURCE_TYPE = "jhi-website-v1/components/structure/header";

    public static final String ISAM_LOGIN_FORM_RESOURCE_TYPE = "jhi-website-v1/components/structure/isamLogin";
    public static final String LOGIN_SECTION_RESOURCE_TYPE = "jhi-website-v1/components/structure/loginSection";

    public static final String PIP_DOWNLOADS_ROOT_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/pipDownloadsRoot";
    public static final String PIP_DOWNLOAD_ENTRY_PAGE_RESOURCE_TYPE = "jhi-website-v1/pages/pipDownloadEntry";
    public static final String PIP_DOWNLOAD_ENTRY_PAGE_TEMPLATE = "jhi-website-v1/templates/pipDownloadEntry";
    
    public static final String PRODUCT_IMAGE_RESOURCE_TYPE = "commerce/components/product/image";

    public static final String PERSONAL_BIOGRAPHY_RESOURCE_TYPE = "jhi-website-v1/components/structure/personalBiography";

    public static final String SUMMARY_RESOURCE_TYPE = "jhi-website-v1/components/content/summary";

    public static final String LATEST_TWEETS_RESOURCE_TYPE = "jhi-website-v1/components/content/latestTweets";

    public static final String ADMIN_COMPONENT_RESOURCE_TYPE = "jhi-website-v1/components/structure/admin/home";
    public static final String RESOURCE_TYPE_WCM_PARSYS = "wcm/foundation/components/parsys";
    public static final String RESOURCE_TWO_COLUMNS = "jhi-website-v1/components/content/twoColumns";

    public static final String EMAIL_VALIDATION_VERIFIED_PROFESSIONAL_COMPONENT_REGISTRATION_RESOURCE_TYPE =
            "jhi-website-v1/components/structure/registration/registerVerifiedUserComplete";
    public static final String EMAIL_VALIDATION_UNVERIFIED_PROFESSIONAL_COMPONENT_REGISTRATION_RESOURCE_TYPE =
            "jhi-website-v1/components/structure/registration/registerUnverifiedUserComplete";
    public static final String EMAIL_VALIDATION_INVESTOR_COMPONENT_REGISTRATION_RESOURCE_TYPE =
            "jhi-website-v1/components/structure/registration/registerInvestorComplete";
    public static final String EMAIL_VALIDATION_EMPLOYEE_REGISTRATION_COMPONENT_RESOURCE_TYPE =
            "jhi-website-v1/components/structure/registration/registerEmployeeComplete";

    public static final String RESET_PASSWORD_COMPLETE_COMPONENT_RESOURCE_TYPE =
            "jhi-website-v1/components/structure/forgotPasswordComplete";

    private ResourcesConstants() {
    }
}
