package com.jhi.aem.website.v1.core.constants;

public class IsamUserProfileConstants {
	public static final String CHANGE_PWD_SERVLET_LABEL = "Change Password Servlet";
	public static final String CHANGE_PWD_SERVLET_COMPNAME = "com.jhi.aem.website.v1.core.servlets.user.IsamLoginTestServlet";
	public static final String CHANGE_PWD_PAGE_PROP_LABEL = "Change password page path";
	public static final String CHANGE_PWD_PAGE_PROP_NAME = "changepwdpagepath";
	public static final String CHANGE_PWD_PAGE_SERVLET_PATH = "/bin/jhi-website/changepwd";
	public static final String GENERATE_FORGOT_PWD_SERVLET_PATH = "/bin/jhi-website/forgotpwd";
	public static final String RESET_PWD_SERVLET_PATH = "/bin/jhi-website/resetpwd";
	public static final String JSON_EXTN = "json";
	public static final String UNAME = "username";
	public static final String PWD = "pwd";
	public static final String SLASH = "/";
	public static final String FIRSTNAME = "givenName";
	public static final String PROFILE_NODE_NAME = "profile";
	public static final String EMPTY_STRING = "";
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure ";
	public static final String CHANGE_PASSWORD_SELECTOR = "changePassword";
	public static final String RESET_PASSWORD_SELECTOR = "resetPassword";
	public static final String VALIDATE_PASSWORD_SELECTOR = "validatePassword";
	public static final String VALIDATE_PASSWORD_SUCCESS_MESSAGE = "VALIDATE_PASSWORD_SUCCESS_MESSAGE";
	public static final String VALIDATE_PASSWORD_FAILURE_MESSAGE = "VALIDATE_PASSWORD_FAILURE_MESSAGE";
	public static final String NO_PASSWORD_SUPPLIED_MESSAGE = "No password value supplied";
	public static final String CHANGE_PASSWORD_SUCCESS_MESSAGE = "CHANGE_PASSWORD_SUCCESS_MESSAGE";
	public static final String FORGOT_PASSWORD_SUCCESS_MESSAGE = "FORGOT_PASSWORD_SUCCESS_MESSAGE";
	public static final String RESET_PASSWORD_SUCCESS_MESSAGE = "RESET_PASSWORD_SUCCESS_MESSAGE";
	public static final String CHANGE_PASSWORD_FAILURE_MESSAGE = "CHANGE_PASSWORD_FAILURE_MESSAGE";
	public static final String FORGOT_PASSWORD_FAILURE_MESSAGE = "FORGOT_PASSWORD_FAILURE_MESSAGE";
	public static final String RESET_PASSWORD_FAILURE_MESSAGE = "RESET_PASSWORD_FAILURE_MESSAGE";
	public static final String  CHANGE_PASSWORD_SUCCESS_RESPONSE = "Password reset successfully";
	public static final String  SUCCESS_TRUE = "TRUE";
	public static final String  PASSWORD_RESET_SUCCESS_RESPONSE ="Password Changed Successfully";
}