package com.jhi.aem.website.v1.core.constants;

import java.nio.charset.Charset;

import org.apache.commons.lang.ArrayUtils;
import org.apache.jackrabbit.core.fs.FileSystem;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.search.Predicate;
import com.day.cq.search.eval.JcrPropertyPredicateEvaluator;
import com.day.cq.search.eval.RangePropertyPredicateEvaluator;

public final class JhiConstants {
    public static final String HASH = "#";
    public static final String QUESTION_MARK = "?";
    public static final String SLASH = "/";
    public static final String DOT = ".";
    public static final String UNDERSCORE = "_";
    public static final String ASTERISK = "*";
    public static final String DASH = "-";
    public static final String AT = "@";
    public static final String COLON = ":";

    public static final String SERVICE_VENDOR = "JHI";
    public static final String RRD_COMMERCE_PROVIDER = "jhi-rrd";
    public static final String PRODUCTS_ROOT = "/var/commerce/products";
    public static final String RRD_PRODUCTS_ROOT = PRODUCTS_ROOT + SLASH + RRD_COMMERCE_PROVIDER;

    public static final String JHI_ADMIN_SERVICE_USER = "jhi-admin";
    public static final String JHI_CRYPTO_SERVICE_USER = "jhi-crypto";
    public static final String JHI_USER_MANAGEMENT_SERVICE_USER = "jhi-usermgmt";

    public static final String USER_REP_AUTHORIZABLE_ID = "rep:authorizableId";

    public static final String CONTENT_ROOT = "/content";
    public static final String JHI_WEBSITE_ROOT = CONTENT_ROOT + "/jhi-website";

    public static final String PLACEHOLDER_START = "${";

    public static final String VIEWPOINTS_AUTHOR_PAGE = "viewpoints/author";
    public static final String VIEWPOINTS_ASSET_MANAGER_PAGE = "viewpoints/asset-manager";
    public static final String PEOPLE_ROOT = "hidden/people";
    public static final String ASSET_MANAGERS_ROOT = "asset-managers";
    public static final String TOOLS_PAGE = "tools";
    public static final String HIDDEN_FUND_DETAILS_ROOT = "hidden/fund-details";

    // TODO: Move tag paths to external config
    public static final String FUNDS_TAG_PREFIX = "jhi-website:funds";
    public static final String FUNDS_TAG_PATH = "/content/cq:tags/jhi-website/funds";
    public static final String UCITS_FUND = "ucits";
    public static final String UCITS_FUNDS_TAG_PREFIX = "jhi-website:funds" + SLASH + UCITS_FUND;
    public static final String UCITS_FUNDS_TAG_PATH = "/content/cq:tags/jhi-website/funds" + SLASH + UCITS_FUND;
	public static final String UCITS_COUNTRY_PARAMETER = "country";

    public static final String PEOPLE_TAG_PREFIX = "jhi-website:people";
    public static final String ASSET_MANAGER_TAG_PREFIX = "jhi-website:asset-managers";
    public static final String ASSET_CLASSES_TAG_PREFIX = "jhi-website:asset-classes";
    public static final String TOPIC_TAG_PREFIX = "jhi-website:viewpoints/section-tag";
    public static final String ARTICLE_TAG_PREFIX = "jhi-website:viewpoints/article-tag";

    public static final int SITE_ROOT_LEVEL = 1;
    public static final int HOME_PAGE_LEVEL = 2;

    public static final String URL_HTML_EXTENSION = ".html";
    public static final String HTML_EXTENSION = "html";
    public static final String JSON_EXTENSION = "json";
    public static final String XML_EXTENSION = "xml";
    public static final String ZIP_EXTENSION = "zip";

    public static final String DEFAULT_CHARSET_NAME = "UTF-8";
    public static final Charset DEFAULT_CHARSET = Charset.forName(DEFAULT_CHARSET_NAME);

    public static final String APPLICATION_JSON_RESPONSE = "application/json";
    public static final String TEXT_XML = "text/xml";
    public static final String TEXT_PLAIN = "text/plain";

    public static final String ADD_SELECTOR = "add";
    public static final String DELETE_SELECTOR = "delete";
    public static final String MODIFY_SELECTOR = "modify";
    public static final String SUBMIT_SELECTOR = "submit";
    public static final String DOWNLOAD_SELECTOR = "download";
    public static final String VIEW_SELECTOR = "view";
    public static final String SHARE_SELECTOR = "share";
    public static final String CLEAR_SELECTOR = "clear";
    public static final String NO_CACHE_SELECTOR = "nocache";
    public static final String RELATED_VIEWPOINTS_SELECTOR = "relatedViewpoints";
    public static final String TOOLS_SELECTOR = "tools";
    public static final String REPORT_SELECTOR = "report";
    public static final String ACCOUNTS_PAGE_SELECTOR_PART = "accounts";

    public static final String FUND_PAGE_FUND_TAGS_PROPERTY = "fundTag";
    public static final String PAGE_CONTENT_FUND_PAGE_FUND_TAGS_PROPERTY = JcrConstants.JCR_CONTENT
            + FileSystem.SEPARATOR + FUND_PAGE_FUND_TAGS_PROPERTY;
    public static final String FUND_MANAGER_COMPONENT_FUND_TAGS_PROPERTY = "fund";
    public static final String FUND_MANAGER_COMPONENT_FUND_RESOURCE_TYPE = "jhi-website-v1/components/structure/fundManagerFund";

    public static final String PERSONAL_BIOGRAPHY_RESOURCE_NAME = "personalBiography";
    public static final String PEOPLE_PAGE_PERSONAL_BIOGRAPHY_PATH_SUFFIX = SLASH + JcrConstants.JCR_CONTENT + SLASH
            + PERSONAL_BIOGRAPHY_RESOURCE_NAME;
    public static final String PEOPLE_PAGE_PERSONAL_BIOGRAPHY_FUND_MANAGER_FUND_FUND_PROPERTY =
            "jcr:content/fundManagerFunds/fundsParagraph/fundmanagerfund/" + FUND_MANAGER_COMPONENT_FUND_TAGS_PROPERTY;

    public static final String VIEWPOINTS_AUTHOR_REFERENCE_PROPERTY = "authorReference";
    public static final String VIEWPOINTS_TAGS_PROPERTY = "viewpointTags";
    public static final String INVESTMENT_TAGS_PROPERTY = "investmentTags";
    public static final String JCR_CONTENT_INVESTMENT_TAG = JcrConstants.JCR_CONTENT
            + SLASH + INVESTMENT_TAGS_PROPERTY;
    public static final String PAGE_CONTENT_VIEWPOINTS_TAGS_PROPERTY = JcrConstants.JCR_CONTENT + SLASH
            + JhiConstants.VIEWPOINTS_TAGS_PROPERTY;
    public static final String PAGE_CONTENT_INVESTMENT_TAGS_PROPERTY = JcrConstants.JCR_CONTENT + SLASH
            + JhiConstants.INVESTMENT_TAGS_PROPERTY;
    public static final String PAGE_RESOURCE_TYPE_PROPERTY = JcrConstants.JCR_CONTENT + SLASH
            + JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY;
    public static final String PROPERTY_VALUE_PARAMETER = JcrPropertyPredicateEvaluator.PROPERTY + "."
            + JcrPropertyPredicateEvaluator.VALUE;
    public static final String PROPERTY_OPERATION_PARAMETER = JcrPropertyPredicateEvaluator.PROPERTY + "."
            + JcrPropertyPredicateEvaluator.OPERATION;
    public static final String TAG_PROPERTY = "tag";
    public static final String PAGE_CONTENT_PERSON_TAGS_PROPERTY = JcrConstants.JCR_CONTENT + SLASH
            + PERSONAL_BIOGRAPHY_RESOURCE_NAME + SLASH + TAG_PROPERTY;
    public static final String ASSET_MANAGER_PROPERTY = "assetManager";
    public static final String PAGE_CONTENT_ASSET_MANAGER_PROPERTY = JcrConstants.JCR_CONTENT + SLASH
            + PERSONAL_BIOGRAPHY_RESOURCE_NAME + SLASH + ASSET_MANAGER_PROPERTY;
    public static final String TAG_ID_PROPERTY = "tagid.property";
    public static final String TAG_ID = "tagid";

    public static final String ORDER_BY_SORT_PROPERTY = Predicate.ORDER_BY + "." + Predicate.PARAM_SORT;

    public static final String PUBLICATION_DATE_PROPERTY = "publicationDate";
    public static final String DATE_PROPERTY_NAME = "jcr:content/" + PUBLICATION_DATE_PROPERTY;
    public static final String TITLE_PROPERTY_NAME = "jcr:content/jcr:title";
    public static final String DOCUMENT_PROPERTY_NAME = "jcr:title";

    public static final String TEXT_PROPERTY = "text";
    public static final String VALUE_PROPERTY = "value";

    public static final String RUN_MODE_AUTHOR = "author";
    public static final String RUN_MODE_PUBLISH = "publish";

    public static final String RUN_MODE_LOCAL = "local";
    public static final String RUN_MODE_AWS = "aws";
    public static final String RUN_MODE_DEV = "dev";
    public static final String RUN_MODE_STG = "staging";
    public static final String RUN_MODE_PRD = "prod";

    public static final String PAGE_VIEWS_PATH = "pageViews";
    public static final String VIEWS_PROPERTY = "views";
    public static final String PAGE_VIEWS_PROPERTY = PAGE_VIEWS_PATH + SLASH + VIEWS_PROPERTY;

    public static final String VAR_JHI_PATH = "/var/jhi";
    public static final String VAR_PAGE_VIEWS_PATH = VAR_JHI_PATH + SLASH + PAGE_VIEWS_PATH;

    public static final String CONTACT_ENTRIES_ROOT = "contactEntries";
    public static final String CONTACT_ENTRIES_PATH = VAR_JHI_PATH + SLASH + CONTACT_ENTRIES_ROOT;

    public static final String PIP_DOWNLOADS_ROOT = "pipDownloads";
    public static final String PIP_DOWNLOADS_PATH = VAR_JHI_PATH + SLASH + PIP_DOWNLOADS_ROOT;
    public static final String PIP_DOWNLOADS_JOB_PID = "com.jhi.aem.website.v1.core.service.pipdownloads.PipDownloadsReportJobExecutor";

    public static final String VALUES_SEPARATOR = ";";
    public static final String MULTIPLE_VALUES_SEPARATOR = ",";

    public static final String DATERANGE_LOWER_BOUND = "daterange." + RangePropertyPredicateEvaluator.LOWER_BOUND;
    public static final String DATERANGE_PROPERTY = "daterange." + RangePropertyPredicateEvaluator.PROPERTY;

    public static final String DECIMAL_PATTERNS = "#,##0.00;-#,##0.00";
    public static final String CURRENCY_PATTERNS = "$#,##0.00;-$#,##0.00";
    public static final String CURRENCY_DECIMAL_PATTERNS = "$#,##0;-$#,##0";

    public static final int MIN_TEXT_QUERY_LENGTH = 3;

    public static final String ASSET_REQUEST_STATUS_PATH = "aisRars";
    public static final String VAR_ASSET_REQUEST_STATUS_PATH = VAR_JHI_PATH + SLASH + ASSET_REQUEST_STATUS_PATH;

    public static final String ALLOWED_AMERIPRISE_FINANCIAL_VALUE = "ameriprisefinancial";
    public static final String ALLOWED_EDWARD_JONES_VALUE = "edwardjones";
    public static final String ALLOWED_JHI = "jhi";
    public static final String ALLOWED_MERRILL_LYNCH_VALUE = "merrilllynch";
    public static final String ALLOWED_MORGAN_STANLEY_VALUE = "morganstanley";
    public static final String ALLOWED_UBS_VALUE = "ubs";
    public static final String ALLOWED_WELLS_FARGO_VALUE = "wellsfargo";
    public static final String ALLOWED_AXA_VALUE = "axa";
    public static final String ALLOWED_COMMONWEALTH_VALUE = "commonwealth";
    public static final String ALLOWED_LPL_VALUE = "lpl";
    public static final String ALLOWED_RAYMOND_JAMES_VALUE = "raymondjames";
    public static final String ALLOWED_NORTHWEST_MUTUAL_VALUE = "northwestmutual";

    public static final String[] RRD_FIRM_IDS = {ALLOWED_AMERIPRISE_FINANCIAL_VALUE, ALLOWED_EDWARD_JONES_VALUE, ALLOWED_JHI,
            ALLOWED_MERRILL_LYNCH_VALUE, ALLOWED_MORGAN_STANLEY_VALUE, ALLOWED_UBS_VALUE};

    public static final String[] WEB_ONLY_FIRM_IDS = {ALLOWED_WELLS_FARGO_VALUE, ALLOWED_AXA_VALUE, ALLOWED_COMMONWEALTH_VALUE,
            ALLOWED_LPL_VALUE, ALLOWED_RAYMOND_JAMES_VALUE, ALLOWED_NORTHWEST_MUTUAL_VALUE};

    public static final String[] FIRM_IDS = (String[]) ArrayUtils.addAll(RRD_FIRM_IDS, WEB_ONLY_FIRM_IDS);

    public static final String ACCESS_PUBLIC = "public";
    public static final String ACCESS_ADVISOR = "advisor";
    public static final String ACCESS_EXCLUSIVE = "exclusive";
    public static final String ACCESS_RESTRICTED = "restricted";
    public static final String ACCESS_INTERNAL = "internal";
    public static final String ACCESS_UFPADVISOR = "ufp";
    public static final String ACCESS_INVESTOR = "investor";

    public static final String[] ACCESS_IDS = {ACCESS_PUBLIC, ACCESS_UFPADVISOR, ACCESS_ADVISOR, ACCESS_EXCLUSIVE, ACCESS_RESTRICTED,
            ACCESS_INTERNAL, ACCESS_INVESTOR};

    public static final String ACCESS_PROPERTY = "access";
    public static final String ALLOWED_FIRMS_PROPERTY = "allowedFirms";

    public static final String ACCESS_SELECTOR_PLACEHOLDER = "${accessSelector}";

    public static final String FIRM_PROPERTY = "firm";

    public static final String QUERY_FIRST_ITEM_PREFIX = "1_";
    public static final String QUERY_SECOND_ITEM_PREFIX = "2_";
    public static final String QUERY_THIRD_ITEM_PREFIX = "3_";
    public static final String QUERY_FOURTH_ITEM_PREFIX = "4_";
    public static final String QUERY_FIFTH_ITEM_PREFIX = "5_";
    public static final String QUERY_SIXTH_ITEM_PREFIX = "6_";

    public static final String WEBSITE_LOGIN_PATH = "/content/jhi-website";
    public static final String SLING_SECURITY_CHECK_PATH = "/j_security_check";
    public static final String WEBSITE_LOGIN_POST_PATH = WEBSITE_LOGIN_PATH + SLING_SECURITY_CHECK_PATH;
    public static final String WEBSITE_AUTH_TYPE = "isam-auth";
    public static final String ISAM_AUTH_INFO_USER_TOKEN = "isam-external-login-token";

    public static final String EMAIL_VALIDATION_QUERY_STRING_TOKEN_PARAMETER = "token";
    public static final String RESET_PASSWORD_QUERY_STRING_TOKEN_PARAMETER = "resetToken";

    public static final String PAGE_CONTENT_TYPE = "cq:PageContent";

    public static final String CSRF_SERVLET_PATH = "/libs/granite/csrf";

    public static final String LOGOUT_PATH = "/logout";
    public static final String TICKER_ID = "tickerId";
    public static final String IS_FUND = "isFund";
    public static final String IS_SHARE_CLASS = "isShareClass";
    public static final String FUND_ID = "fundId";
    public static final String PUBLISHED = "published";
    public static final String SHARE_CLASS = "shareClass";
    public static final String CUSIP = "cusip";
    public static final String ISIN = "isin";
    public static final String DASHBOARD_FUNDS = "dashboardFunds";
    public static final String INCEPTION_DATE = "inceptionDate";
    public static final String UCITS_COUNTRIES = "ucitsCountries";

    public static final String ADMIN_CONFIG_PID = "com.jhi.aem.website.v1.core.config.Admin";

    public static final String ADMIN_SEARCH_SELECTOR = "jhiadmin.search";
    public static final String ADMIN_SEARCH_OPTIONS_SELECTOR = "jhiadmin.options";
    public static final String ADMIN_EMAIL_SELECTOR = "email";
    public static final String ADMIN_GROUP_JSON_SELECTOR = "isamGroup";
    public static final String ADMIN_STATUS_JSON_SELECTOR = "userStatus";
    public static final String ADMIN_STATUS_MESSAGE_JSON_SELECTOR = "userStatusChangeReason";
    public static final String ADMIN_EXCEPTION_REPORT_SELECTOR = "jhiadmin.report";
    public static final String ADMIN_GROUP_SELECTOR = "jhiadmin.group";
    public static final String ADMIN_STATUS_SELECTOR = "jhiadmin.status";
    public static final String ADMIN_SEED_USER_SELECTOR = "jhiadmin.seeduser";
    public static final String ADMIN_SEED_USER_PASSCODE_CONFIG = "seeduser.passcode";
    public static final String ADMIN_SEED_USER_EMAIL_CONFIG = "seeduser.email";
    public static final String ADMIN_SEED_USER_EMAIL = "admin@jhancock.com";
    public static final String ADMIN_SECRET_PASSCODE = "passcode";
    public static final String MORNING_STAR_CATEGORY = "morningStarCategory";
    public static final String MORNING_STAR_RATING = "morningStarRating";

    public static final String PROPERTY_REGISTRATION_DATE = "emailValidationTokenCreated";
    public static final String PROPERTY_DATAHUB = "marsRepId";
    public static final String PROFILE_NODE_NAME = "profile";
    public static final String TEXT_CSV_RESPONSE = "text/csv";

    public static final String USER_ACTIVE = "Active";
    public static final String USER_INACTIVE = "Inactive";
    public static final String ISAM_ACTIVE = "Yes";
    public static final String ISAM_INACTIVE = "No";
    public static final String AEM_ACTIVE = "Active";
    public static final String AEM_INACTIVE = "Inactive";
    public static final String USE_FOR = "useFor";

    public static final String CUG_ENABLED_PAGE_PROPERTY = "cq:cugEnabled";
    public static final String CUG_LOGIN_PATH_PROPERTY = "cq:cugLoginPage";
    public static final String NO_CACHE = ".no-cache.";
    public static final String LOGIN_REDIRECTOR_URL_PARAM = "url";
    public static final String CURRENCY = "currency";
    public static final String SHARE_CLASS_CODE = "shareClassCode";
    public static final String ACTIVE = "active";
    public static final String IS_UCITS_PROPERTY = "isUcits";

    //DAM File Upload Constants
    public static final String DAM_FILE_UPLOAD_CONFIG_PID = "com.jhi.aem.website.v1.core.schedulers.DAMFilesUploader";
    public static final String BSKT_TIMESTAMP_PROPERTY = "bskt.timeStamp";
    public static final String TDH_TIMESTAMP_PROPERTY = "tdh.timeStamp";
    public static final String BSKT_FILE_CONFIG_PROPERTY = "bsktUploadFile";
    public static final String TDH_FILE_CONFIG_PROPERTY = "tdhUploadFile";
    public static final String HOLIDAYS_PROPERTY = "nonWorkingDays";
    public static final String EMAIL_TEMPLATE_PATH_PROPERTY = "emailTemplatePath";
    public static final String EMAIL_TO_LIST_PROPERTY = "distributionList";
    public static final String REMOTE_DIRECTORY_PROPERTY = "jhiwebsite.damconfig.remotedir";
    public static final String MORNING_GREETING = "Good morning";
    public static final String EVENING_GREETING = "Good evening";

    public static final String LOCKED_RESOURCES_IMAGE = "/etc.clientlibs/jhi-website-v1/clientlibs/clientlib-site/resources/logo.svg";
    public static final String OAUTH_CONFIG_PID = "com.jhi.aem.website.v1.core.config.Oauth";
    public static final String SECRET_PROP_LABEL = "secret";
    public static final String ID_PROP_LABEL = "id";
    public static final String ISSUER_PROP_LABEL = "issuer";
    public static final String SUBJECT_PROP_LABEL = "subject";
    public static final String TTL_PROP_LABEL = "ttl";
    public static final String PARAM_USER = "username";
    public static final String PARAM_PASS = "pass";
    public static final String AGENT_PROP_LABEL = "userdetails-agent";
    public static final String AUTH_HEADER_LABEL = "authorization";

    public static final String X_STATUS_HEADER = "X-Status";
    public static final String DISPATCHER_CONFIG_PID = "com.jhi.aem.website.v1.core.common.DispatcherConfig";
    public static final String CONFIG_INVALIDATE_SERVER_URL = "invalidate.server.url";
    public static final String FUNDS_PAGE_PATH = "/content/jhi-website/en_US/investments/fund-details";
	public static final String CONFIG_INVALIDATE_PATHS = "invalidate.paths";
	
	public static final long DEFAULT_FUND_CACHE_VALUE = 300000;

    private JhiConstants() {
    }

}
