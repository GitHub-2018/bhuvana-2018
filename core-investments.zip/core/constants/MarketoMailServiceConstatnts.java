package com.jhi.aem.website.v1.core.constants;

public class MarketoMailServiceConstatnts {


	//public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
	public static final String API_KEY_HEADER_NAME = "Authorization";
	public static final String CONTENT_TYPE_HDR_KEY = "Content-Type";
	public static final String APPLICATION_JSON = "application/json";
	public static final long DEFAULT_TIMEOUT_MS = 120000;
	public static final String TOKEN_SUCCESS = "success";
	public static final String TOKEN_SUCCESS_TRUE = "true";
	public static final String TOKEN_KEY = "token";
	public static final String CC_EMAIL = "ccemail";
	public static final String CC_EMAIL_LABEL = "CC Email";
	public static final String CONSTANT_BERR = "bearer";
	public static final String CREATED = "created";
	public static final String SKIPPED = "skipped";
	public static final String ERROR_INVALID_CLI = "invalid_client";
	public static final String STATUS_CODE_500 = "500";
	public static final String STATUS_CODE_400 = "400";
	public static final String STATUS_CODE_403 = "403";
	public static final String STATUS_CODE_200 = "200";
	public static final String STATUS_CODE_401 = "401";
	public static final String ACTION_CREATE_ONLY = "createOnly";
	public static final String ACTION_CREATE_OR_UPDATAE = "createOrUpdate";
	public static final String UTF_ENCODING = "UTF-8";

}
