$(function() { 
$('.panel-title > a[data-toggle="collapse"]').click(function(e){
      $( "div.wrapper" ).scrollTop( 300 );
      $(".caret").removeClass("caret-up");
      $(this).css("text-decoration", "none"); 
      $(this).children().addClass("caret-up");
	  target = $(this).attr('href')
	  if ($(target).hasClass('in')) {

         e.preventDefault();
 		 e.stopPropagation();
 			 return false;
	  }
	});

}); 