$(function() { 
$('a#brightCoveVideo').click(function(){
    getattributesrc = $(this).attr("src");
    console.log(getattributesrc)
    window.open(getattributesrc,'','width=720, height=404');
    return false;
  });

}); 