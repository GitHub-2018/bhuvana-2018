$( document ).ready(function() {
/*Code to make the tab component*/
$(".perspective-para").hide();
$('.tab-para-content').find('div').first().show();
$( ".tab-link " ).on( "click", "p", function() {
    var gettablinkTitle=$(this).attr("title").toLowerCase();
    $(".perspective-para").hide();
    $(".tab-link p").removeClass("active");
    $(this).addClass("active");
    $(".perspective-para").each(function(){
        var getPespectiveparaTitle =$(this).attr("title").toLowerCase();
        if(gettablinkTitle == getPespectiveparaTitle ){
            $(this).show();
            
        }
        
    });
    
});

});
