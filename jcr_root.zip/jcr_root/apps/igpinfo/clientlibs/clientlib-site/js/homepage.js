$(document).ready(function(){
	/*check if the device is mobile*/
	rearrangeforMobile();
	$(window).resize(function(){
	rearrangeforMobile();	
	})
	function rearrangeforMobile(){
		if(window.innerWidth < 768){						
		var getlogodiv = $('.left-side-rail').find(".logo-image").clone();
		var getsearchdiv = $('.left-side-rail').find(".search-wrapper").clone();
		var getsubcribtiondiv = $('.left-side-rail').find(".subscribtion-wrapper").clone();
        var getdetaildiv = $('.left-side-rail').find(".detail-wrapper").clone();
		var getsubmenudiv = $('.left-side-rail').find("ul.submenu-nav").clone();
		var getlogindiv = $('.right-side-rail').find(".login-wrapper").clone();
		
		$(".nav-wrapper").find(".logo-image").remove();
		$("#myNavbar").find("ul.submenu-nav").remove();
		$("#myNavbar").find(".subscribtion-wrapper").remove();
        $("#myNavbar").find(".detail-wrapper").remove();
		$("#myNavbarsearch").find(".search-wrapper").remove();
		$("#myNavbarlogin").find(".login-wrapper").remove();
		
		$(".nav-wrapper").prepend(getlogodiv);
		$("#myNavbar").prepend(getsubcribtiondiv);
        $("#myNavbar").prepend(getdetaildiv);
		$("#myNavbar").prepend(getsubmenudiv);
		$("#myNavbarsearch").prepend(getsearchdiv);
		$("#myNavbarlogin").prepend(getlogindiv);
		}else{
		$(".nav-wrapper").find(".logo-image").remove();
		$("#myNavbar").find(".ul.submenu-nav").remove();
		$("#myNavbar").find(".subscribtion-wrapper").remove();
        $("#myNavbar").find(".detail-wrapper").remove();
		$("#myNavbarsearch").find(".search-wrapper").remove();
		$("#myNavbarlogin").find(".login-wrapper").remove();
			
		}
	}
	/*check if the device is mobile*/
$(document).on('click','button.navbar-toggle',function(e) {    
        if($(".navbar-collapse").hasClass("in")){
			$(".navbar-collapse").removeClass("in");
		}

});
});