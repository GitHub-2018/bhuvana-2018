$(document).on("coral-overlay:open", function () {
$(".coral3-Button").click(function() {
    var field = $(this).parent();
    var size = field.attr("data-fieldlimit");
	//console.log("size"+size);
    if (size) {
        var ui = $(window).adaptTo("foundation-ui");
        var totalLinkCount = $(this).parent().children("coral-multifield-item").length;
        //console.log("totalLinkCount"+totalLinkCount);
        if (totalLinkCount >= size) {
            ui.alert("Warning", "Maximum " + size + " options are allowed!", "notice");
            return false;
        }
    }
});
});



