function renderHtml(templateSource, targetHtmlSection, context){
                var source   = $(templateSource).html();
                var template = Handlebars.compile(source);
                var html    = template(context);
                $(targetHtmlSection).append(html);
}
//HB Helpers
Handlebars.registerHelper('ifNews', function(channel, options) {
	var channelSelected = false;
	var newsChannels = UserData.content.news;
	for (i = 0; i < newsChannels.length; i++) {
		if (channel === newsChannels[i]) {
			channelSelected = true;
		}
	}
	if(channelSelected) {
		return options.fn(this);
	}	  
});

/*Handlebars.registerHelper('ifCond', function (v1, operator, v2, options) {

	switch (operator) {
	case '==':
		return (v1 == v2) ? options.fn(this) : options.inverse(this);
	case '===':
		return (v1 === v2) ? options.fn(this) : options.inverse(this);
	case '<':
		return (v1 < v2) ? options.fn(this) : options.inverse(this);
	case '<=':
		return (v1 <= v2) ? options.fn(this) : options.inverse(this);
	case '>':
		return (v1 > v2) ? options.fn(this) : options.inverse(this);
	case '>=':
		return (v1 >= v2) ? options.fn(this) : options.inverse(this);
	case '&&':
		return (v1 && v2) ? options.fn(this) : options.inverse(this);
	case '||':
		return (v1 || v2) ? options.fn(this) : options.inverse(this);
	default:
		return options.inverse(this);
	}
});*/ //Repeating code

Handlebars.registerHelper('limit', function (arr, limit) {
	if (arr != null) {
		return arr.slice(0, limit);
	} else {
		return [];
	}
});

Handlebars.registerHelper('if_odd', function (conditional, options) {
    if ((conditional % 2) != 0) {
        return options.fn(this);
    } else {
        return options.inverse(this);
    }
});

Handlebars.registerHelper('ifEndsWith', function (str, suffix, options) {
    str = str.toLowerCase();
    if (str.indexOf(suffix, this.length - suffix.length) !== -1) {
        return options.fn(this);
    }
    return options.inverse(this);
});

Handlebars.registerHelper ("setChecked", function (value, currentValue) {
    if ( value == currentValue ) {
      return "checked"
    } else {
      return "";
    }
  });

Handlebars.registerHelper('if_eq', function(a, b, opts) {
    if(a == b)
        return opts.fn(this);
    else
        return opts.inverse(this);
});

Handlebars.registerHelper('pagination', function(currentPage, totalPage, size, options) {
	  var startPage, endPage, context,previousPage,nextPage;

	  if (arguments.length === 3) {
	    options = size;
	    size = 5;
	  }
	  size = 5;

	  startPage = currentPage - Math.floor(size / 2);
	  endPage = currentPage + Math.floor(size / 2);

	  if (startPage <= 0) {
	    endPage -= (startPage - 1);
	    startPage = 1;
	  }

	  if (endPage > totalPage) {
	    endPage = totalPage;
	    if (endPage - size + 1 > 0) {
	      startPage = endPage - size + 1;
	    } else {
	      startPage = 1;
	    }
	  }
	  previousPage = startPage-1;
	  nextPage= endPage+1;
	  context = {
	    startFromFirstPage: false,
	    pages: [],
	    endAtLastPage: false,
		previousPage : previousPage,
	  	nextPage: nextPage
	  };
	  if (startPage === 1) {
	    context.startFromFirstPage = true;
	  }
	  for (var i = startPage; i <= endPage; i++) {
	    context.pages.push({
	      page: i,
	      isCurrent: i === currentPage,
	    });
	  }
	  if (endPage === totalPage) {
	    context.endAtLastPage = true;
	  }

	  return options.fn(context);
	});


Handlebars.registerHelper('for', function(from, to, incr, block) {
    var accum = '';
    for(var i = from; i <= to; i += incr)
        accum += block.fn(i);
    return accum;
});


Handlebars.registerHelper("inc", function(value, options)
{
    return parseInt(value) + 1;
});
Handlebars.registerHelper('rowStart', function (index, options) {
       if(index%4 == 0){
         return options.fn(this);
      } else {
         return options.inverse(this);
      }

});
 Handlebars.registerHelper('rowEnd', function (index, options) {

      if(index%4 == 3){
           return options.fn(this);
     } else {
         return options.inverse(this);
     }

});

Handlebars.registerHelper('showMore', function (index, options) {

	if(index == 8){
      return options.fn(this);
    } else {
        return options.inverse(this);
    }


});
  Handlebars.registerHelper('listSize', function(context, options) {

       var ret = context.length;
       if(ret > 8){
           return options.fn(this);
        } else {
           return options.inverse(this);
          }
 });
  Handlebars.registerHelper('listSizeMultipleOfFour', function(context, options) {

       var ret = context.length;
       if(ret > 8 && ret%4 != 0){
           return options.fn(this);
        } else {
           return options.inverse(this);
          }
 });