var persDomain = persDomain;
var url = persDomain + "/pers/data/account/";
var urlView = persDomain + "/pers/data/views/";



$CQ.ajax({
		type:'GET',
		url: url,
		async: false,
    	xhrFields: { 
        	withCredentials: true 
         	},
		success:function(data){
			UserData = JSON.parse(data);

		},
		error: function(data){
			console.log("Error path");
            UserData = null;

		}
	});