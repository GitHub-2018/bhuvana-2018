
(function( $ ) {
	/* jQuery Plugin for browser elements inactive */
	jQuery.fn.inactiveAction = function( options ) {
		// default settings:
		var defaults = {
			timeLimit : 5, // in Seconds. default is 5 seconds
			onTimeout: function(){},
			onCountDown: function(seconds){}
		};
		var settings = $.extend( {}, defaults, options );

		return this.each(function() {
			var that = $(this), idleSeconds = 0, inactiveInterval;
			that.on("click keypress mousemove", function(){
				idleSeconds = 0;
			});
			function checkTimeLimit() {
				idleSeconds++;

				settings.onCountDown.call(that, (settings.timeLimit - idleSeconds));
				if (idleSeconds >= settings.timeLimit) {
 					settings.onTimeout.call(that);
					window.clearInterval(inactiveInterval);
				}
			};
			inactiveInterval = window.setInterval(checkTimeLimit, 1000);
		});
	};
}(jQuery));

  /* Get ajax content on field change */
	$(document).on("change", "[data-changerequest=true] [data-change]", function(){
		var container = $(this).closest("[data-changerequest=true]"),
		contentEle = container.find("[data-changecontent=true]").eq(0),
		url = container.attr("data-ajaxurl"),
		params = {}, that = $(this);

		container.children("input:hidden[data-param=true]").add(container.find("[data-change]")).each(function(){
			params[$(this).attr("name")] = $(this).val();
		});

		$.ajaxSetup({ cache: false });
		var jqxhr = $.get(url, params, function(data){
			if(contentEle.attr("[data-templatetarget]") != ""){
				var source = $(contentEle.attr("data-templatetarget")).html();
				var template = Handlebars.compile(source);
				var html = template(data);

				contentEle.html(html);
			}else{
				contentEle.html(data);
			}				
		}).fail(function() {
			// remove loader/ show error message (optional)
		});
	});

	/*Field Validation */
    $(document).on("submit", "[data-validate=true]", function(){
        var $return = true, form = $(this);
        $(this).find(":input[data-required=true]").each(function(i){
            var id = $(this).attr("id") ? $(this).attr("id") : "invalid-"+i;
            id = $(this).attr("data-invalid-id") ? $(this).attr("data-invalid-id") : id;

            $(this).attr("data-invalid-id", id);

            $(this).on("validate change blur keypress", function(){
                if(!$(this).val()){
                    // STEP 1:  if field is empty show errormessage with data-errorfor attribute.
                    var err = $("<span>", {"class":"invalid", text:"This field is required", "data-errorfor":id}),
                        target = $(this).attr("data-invalid-target");
                    form.find("[data-errorfor="+id+"]").remove();

                    if(target){
                        $("[data-id="+ target + "]").after(err);
                    }else{
                        $(this).after(err);
                    }
                    $(this).addClass("error");

                    $return = false;
                }else{
                    // STEP 2: if field is not empty then remove errormessage with the reference of data-errorfor
                    $(this).removeClass("error invalid");
                    form.find("[data-errorfor=" + $(this).attr("data-invalid-id") + "]").remove();
                }
            }).trigger("validate");
        });
        return $return;
    });


});
  var generateTopBar = function(text, linkURI, linkText, linkTarget){

                linkURI    = linkURI || chromePdfUrl;
                    linkText   = linkText || 'Click here for instructions';
                    linkTarget = linkTarget || '_blank';
                    text       = text || 'If you are using Chrome for your browser, certain features may not be available unless  you unblock cookies for this site. ';

                                var out = '';
                    out     += '<div class="topbar-panel">';
                                out     += text;
                    out     += '<a href="'+ linkURI +'" target="'+ linkTarget +'">'+ linkText +'</a>';
                                out     += '</div>';

                                return out;
                
            }


             $(document).ready(function(){
               if(window.chrome && typeof $('#topBar')!==undefined)
               {
                    var topBarHTML = generateTopBar();
                    $('#topBar').html(topBarHTML);
                   $('#topBar').siblings('.white--bar').removeClass('margin__bottom');
                }
            });
$(document).ready(function(){
    if(UserData !=  null){
    var linkout = $(".linkout");
    var wssregistered = UserData.content.wssregistered;
    if(typeof wssregistered !== undefined && typeof wssregistered !== "undefined" && wssregistered !== null){
        if(wssregistered.toUpperCase() === 'FALSE'){
            
            linkout.each(function(index) {
                $(this).attr("data-toggle","modal");
                $(this).attr("data-target","#notRegisteredModal");
            });
            
        }
    }
    }

});
$(function() {	
        if (self == top) {
        document.documentElement.style.display = 'block';
        } else {
        	var selfurl = location
            if(isURL(selfurl))
            {

            	top.location = selfurl;
            } 

        }
    });
function isURL(str) {
     var urlRegex = '^(?!mailto:)(?:(?:http|https|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$';
     var url = new RegExp(urlRegex, 'i');
     return str.length < 2083 && url.test(str);
} 