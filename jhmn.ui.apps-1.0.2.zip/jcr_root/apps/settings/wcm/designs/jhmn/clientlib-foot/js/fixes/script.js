$(function() {

    window.applyTreeview($("#topic"))
    window.applyTreeview($("#product"))
    window.applyTreeview($("#topicltc"))
    window.applyTreeview($("#productltc"))
    //console.log("PAGE LOADED ***");
    $.urlParam = function(name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results == null) {
            return null;
        } else {
            return results[1] || 0;
        }
    }


    $.getQueryParams = function(name) {
        qs = location.search;

        var params = [];
        var tokens;
        var re = /[?&]?([^=]+)=([^&]*)/g;

        while (tokens = re.exec(qs)) {
            if (decodeURIComponent(tokens[1]) == name)
                params.push(decodeURIComponent(tokens[2]));
        }

        return params;
    }


    var topic = decodeURIComponent($.getQueryParams('topic'));
    if (topic != null) {
        var topics = topic.split(',');

        $.each(topics, function(index, value) {
            //console.log(" VALUE: " + $('input[name=topicList]'));
            $('input[name=topic]').each(function() {
                //console.log(this.value);
                if (this.value === value) {
                    // console.log($(this));
                    $(this).prop('checked', true);
                }
            });
        });

        //$(this).prop('checked', true);
        // url = url.replace(value, "");

    }


    var product = decodeURIComponent($.getQueryParams('product'));
    //console.log("PRODUCT***" + product);
    if (product != null) {
        var products = product.split(',');

        $.each(products, function(index, value) {
            //console.log(" VALUE: " + $('input[name=topicList]'));
            $('input[name=product]').each(function() {
                //console.log(this.value);
                if (this.value === value) {
                    // console.log($(this));
                    $(this).click();
                }
            });
        });

        //$(this).prop('checked', true);
        // url = url.replace(value, "");

    }

    var format = decodeURIComponent($.getQueryParams('format'));
    if (format != null) {
        var formats = format.split(',');

        $.each(formats, function(index, value) {
            $('input[name=format]').each(function() {
                if(value != null && value != "" && value !== undefined){
                if ((this.value).indexOf(value)>-1) {
                   if(!this.checked){
                    	$(this).click();
                    }
              	 }
           		 }
            });
        });
        //$(this).prop('checked', true);
        // url = url.replace(value, "");
    }

    var type = decodeURIComponent($.getQueryParams('type'));

    if (type != null) {
        var types = type.split(',');

        $.each(types, function(index, value) {
            $('input[name=type]').each(function() {
                if (this.value === value) {
                    $(this).click();
                }
            });
        });


    }

    var state = decodeURIComponent($.urlParam('state'));
    //console.log("State Value****" + state);
    if (state != null) {
        $('select[name="state"] option').each(function() {
            if (this.value === state) {
                $(this).attr('selected', 'selected');
            }
        });
    }

    var custApproved = decodeURIComponent($.urlParam('custApproved'));
   // console.log("State Value****" + custApproved);
    if (state != null) {
        $('select[name="custApproved"] option').each(function() {
           // console.log("custApproved****" + this.value);
            if (this.value === custApproved) {
                $(this).attr('selected', 'selected');
            }
        });
    }

    var inlineOptions = decodeURIComponent($.urlParam('option'));
   // console.log("inlineOptions**" + inlineOptions);
    if (inlineOptions != null) {
        $('input:radio[name=option]').each(function() {
            //console.log(this.value);
            if (this.value === inlineOptions) {
                // console.log($(this));
                $(this).click();
            }
        });
    }


    /* for all new lTC news LIfe NEws */
    var checked = [];
    //console.log("chewked**" + checked);
    $(".channel").change(function() {
        // this function will get executed every time the #home element is clicked (or tab-spacebar changed)
        if ($(this).is(":checked")) // "this" refers to the element that fired the event
        {
            //console.log("chewked**" + $(this).val());
            checked.push($(this).val());
            //console.log("chewked**" + checked + $("#filter"));
        } else {
            var val = $(this).val();
            if (checked.indexOf(val) > -1) {
               // console.log("matches**" + val);
                checked = $.grep(checked, function(value) {
                    return value != val;
                });
               // console.log("after removal**" + checked);
            }
        }
        $(".channels").each(function() {
            $(this).val(checked);
        });
    });


/*
    $(".parent-checkbox1").click(function() {
       // console.log($(this).parent().html());
        $(this).parent().next("div").find("input[type='checkbox']").attr('checked', this.checked);
        //$(this).parent().next("div").find("input[type='checkbox']").click();
    });*/

    $(".clear-btn1").click(function() {
        $('input:checkbox').each(function() {
            //console.log(this.value);
            if ($(this).is(":checked")) // "this" refers to the element that fired the event
            {
                var val = $(this).val();
                $(this).removeAttr('checked');
                checked = $.grep(checked, function(value) {
                    return value != val;
                });
            }
            $(".channels").each(function() {
                $(this).val(checked);
            });

        });

        //Resetting the dropdowns
        $('select').each(function() {
             $($(this).children()[0]).attr('selected','');
        });
    });

    //console.log("chewked**" + checked);

    /* END*/

});