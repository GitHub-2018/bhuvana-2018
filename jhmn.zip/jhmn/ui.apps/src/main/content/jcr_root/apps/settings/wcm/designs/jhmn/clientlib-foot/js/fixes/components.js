window.applyTreeview = function(el){
    // el.find("ul ul").not("li.open>ul").hide();
    el.find("ul li").each(function(){
        if($(this).children('ul').length>0){
            var toggler = $("<span>", {"class":"nodetoggler"});
            $(this).prepend(toggler);
        }
    }).on("click", function(e){
        e.stopPropagation();
        if($(e.target).is(":checkbox")){
            $(this).find("ul input:checkbox").prop("checked", $(e.target).prop("checked"));
        }else{
            if($(this).children('ul').length>0){
                if(!$(this).hasClass('open')){
                    $(this).children('ul').slideDown("fast");
                }else{
                    $(this).children('ul').slideUp("fast");						
                }
                $(this).toggleClass("open");
            }else{
                $(this).children('input:checkbox').trigger('click');
            }
        }
    });
}

window.applyXSTabView = function(ul_id){
	var ul = $(ul_id), foundActive = false;
    if(ul.length > 0){
		ul_dup = $(ul.attr("x-xs-reference"));
		lis_dup = ul_dup.children("li");
        ul.children("li").each(function(index){
            if(!foundActive){
				lis_dup.eq(index).hide();
            }
            else{
				lis_dup.eq(index).show();
            }
            if($(this).hasClass("active")){
				foundActive = true;
            }
        });
    }
}

$(document).on("click", "[x-tabs-duplicate] li", function(){
	$(this).add($(this).prevAll()).hide();;
});
function blockSpecialChar(e){
        var k;
        document.all ? k = e.keyCode : k = e.which;
        return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }
function printIframe(){
    document.domain="manulifebermuda.com";
    var iFrameDOM = $("iframe");
	var flag = false;
    $(iFrameDOM).each(function() {
      var src = $(this).attr('src');
      if(src != ""){
        flag = true;
        this.contentWindow.focus();
        this.contentWindow.print();
      }
  });

	if(!flag){
        window.print();
	}
}