/*code to fix the iframe related issues*/
$(document).ready(function(){
      $("#iframeid").each(function() {
        var selector= $(this).closest(".tab-content").attr("class");
              if(typeof selector==="undefined")
              {

                  $(this).attr('src', $(this).attr('src1'));

              }

          });


$("div.tabpanel ul.nav li.active a").each(function(){
		   $("#iframeid").attr("src", $("#iframeid").attr("src1"));
      });
count=0;
 $(".panel").on( "click", function() {
     count++;
     if(count==1){
         $(this).siblings().find(".panel-collapse").addClass("hide");
     }
     if(count==2){
         $(this).siblings().find(".panel-collapse").removeClass("hide");
         $(this).siblings().find(".panel-collapse").removeClass("in");
         $(this).find(".panel-collapse").removeClass("hide");
     }

});

});
function resolveIframeIssue (tablink) {
        var src1val = $(tablink+" .iframecomp iframe").attr("src1");
    	$(tablink+" .iframecomp iframe").attr("src", src1val);
    $(".tab-content").removeClass("hidden-xs").removeClass("hidden-sm");

    }
/*Attributes based libs*/
$(function(){
    
    var tab = $(".tabpanel.section");
   // console.log("TAB LENGTH" + tab.length);
    $(tab).each(function() {
        var firstActiveTab = $(this).find("ul li.active").first();
        var aTag = $(firstActiveTab).find("a").first();
        //var firstIframe = $(firstActiveTab).find("iframe").first();
        // $(firstIframe).attr('src', $(firstIframe).attr('src1'));
       // console.log("FIRST ACTIVE TAB ***" + aTag.attr('href'));
        var selector = aTag.attr('href');
        var divId = selector.split("#");
      //  console.log("SELECTOR ***" + divId[1]);
        var iframeTab = $('#'+divId[1]);
        var iframeDiv =  $(iframeTab).find('iframe').first();
        $(iframeDiv).attr('src', $(iframeDiv).attr('src1'));
        

        
    });
});
