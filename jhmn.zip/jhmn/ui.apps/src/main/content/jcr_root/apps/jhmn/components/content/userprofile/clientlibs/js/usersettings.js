// Personalization endpoints
var domain = location.protocol+"//"+location.hostname+":"+location.port;
var persDomain = persDomain;
var url = persDomain + "/pers/data/account/";
var urlView = persDomain + "/pers/data/views/";

var UserData, UserViews;

/*  
	Polyfill - Old versions of IE don't support startsWith. For that case,
			   this adds the startsWith method to String to work around it.
*/
if (!String.prototype.startsWith) {
  String.prototype.startsWith = function(searchString, position) {
    position = position || 0;
    return this.indexOf(searchString, position) === position;
  };
}

/* 
	Init - Synchronous call to load user personalization data before the page is loaded.
		   This call should return before any logged-in page is loaded so 
		   all personalization data is available. 
*/
$CQ.ajax({
            type:'GET',
            async: false,
            url: url,
 			xhrFields: { 
        	withCredentials: true 
         	},

             success:function(data){
                        UserData = JSON.parse(data);
            },
            error: function(data){
                        UserData = null;
            }
});

/* 
	Document initilaizer calls this function to populate the recently
	accessed resources and to load the handlebars templates using the
	personalization data. After the sidepanel data is loaded. Event 
	listeners are bound to appropriate elements.
*/
function loadData() {
	$CQ.ajax({
		type:'GET',
		url: urlView,
        xhrFields: { 
        	withCredentials: true 
         	},
		success:function(data){
			var resp = JSON.parse(data);
			fetchResourceDetails(resp.content);
		},
		error: function(data){
	    	//var resp = {"content":[{"timestamp":"2017-07-20T02:01:48.936","title":"","view":"http://52.45.54.139:4502/content/dam/MNBD/documents/Products/mb-life-5439_product_portfolio.pdf"}],"userProfileId":108761,"userRecentlyVisitedResourcesId":70865};
			//fetchResourceDetails(resp.content);
		}
	});

	refreshSidepanel();
	loadSettingsTemplate("settings-template", "setting-modal");
	loadTemplate("mail-modal-template", "mail-modal");
	loadNewsModal();
	refreshSettings(UserData.content.home, UserData.content.states);
	setupButtons();
    checkFavorites();


	setNewsChannels();
  //  console.log("after setnews channels");
   // debugger;
	$('div#slidepanel').on('click', '[name="favlink"]', function() {
       window.location = $(this).attr("href");
    });
}

/*
	Retrieves the details about each recently accessed resource returned
	from the personalization service. Once data is retrieved, the component
	is populated.
	
	Variables:
	content - Array of resources returned from the recently accessed views servlet
*/
function fetchResourceDetails(content){
	$.ajax({
		type: "post",
        xhrFields: { 
        	withCredentials: true 
         	},
		url: domain + "/bin/sling/JHMNRecentResources",
		data: { size: 4, content: JSON.stringify(content) },
		success: function(data){
			UserViews = data;
			refreshRecentViews();
		}
	});
}

/* 
	Called by the initializer to add listeners to the news panel 
	and favorites pop up dialog. This includes the Select All
	and Delesect All options and the Do not show for 90 days pop up.
*/
function setupButtons() {
	$(".select-btn").each(function(ind) {
		$(this).click(function(evt) {
			var tabId = $(evt.target).closest("[name='newsTab']").attr("id");
			selectAll(tabId);
		});
	});

	$(".clear-btn").each(function(ind) {
		$(this).click(function(evt) {
			var tabId = $(evt.target).closest("[name='newsTab']").attr("id");
			deselectAll(tabId);
		});
	});
	
	$('#noFavTT').change(function() {
  		//console.log("Setting cookie");
  		var exdays = 14;
  		var cname = "nofavtt";
  		var cvalue= "true";
  		if(this.checked) {
  	    	 var d = new Date();
  	    	 d.setTime(d.getTime() + (exdays*24*60*60*1000));
  	    	 var expires = "expires="+d.toUTCString();
  	    	 document.cookie = cname + "=" + cvalue + "; " + expires +";" + "path=/";
  	    } else {
  	    	document.cookie = cname+"=; expires=Thu, 01 Jan 1970 00:00:01 GMT;";
  	    }
  	});
}

/* 
	Populates the channels setting for the all news component to fetch data
	using the default form attached to the filters sidepanel. 
*/
function setNewsChannels() {
    if(UserData.content.hasOwnProperty('news') && UserData.content.news.length > 0){

	        var news = UserData.content.news;
	        var newArr= new Array();

	        if (typeof news !== 'undefined') {
	            news[0].forEach(function(element){    
	                var parts = element.toString().split("|");
                    if(typeof parts!=='undefined' && parts.length == 2){
	                	newArr.push(parts[1]);
	                }
	            });

	            $("[name='channels']").val(newArr.toString());
	        }
	       }

	} 

/*
	Handlebars Loader - Loads a template based on its ID
						and parent element.
		Variables:
		templateId - HTML ID of the handlebars element
		templateElement - HTML ID of the parent element
*/
function loadTemplate(templateId, templateElement) {
	var docEl = document.getElementById(templateId);
	if (docEl == null) {
		return;
	}
	var source = docEl.textContent;
	var template = Handlebars.compile(source);
	var html = template({data: UserData.content});
	document.getElementById(templateElement).innerHTML = html;
	refreshSettings(UserData.content.home, UserData.content.states);
}

/*
	Handlebars Loader - Loads the sidepanel setting template similar to 
						loadTemplate but includes additional validates 
						for special partner specific options.
		Variables:
		templateId - HTML ID of the handlebars element
		templateElement - HTML ID of the parent element
*/
function loadSettingsTemplate(templateId, templateElement) {
                var groupName = typeof UserData.content["iv-groups"] !== "undefined" ? UserData.content["iv-groups"] : ""; 
                groupName = groupName.toUpperCase();

    
                if (typeof groupName !== undefined) {
                                if (groupName.startsWith("UNVERIFIEDPRODUCERS")) {
                                                UserData.content.hideMyBusiness = true;
                                } else if (groupName.startsWith("LIFEPRODUCERS")) {
                                                UserData.content.hideLTC = true;
                                } else if (groupName.startsWith("LTCPRODUCERS") || groupName.startsWith("SFBPRODUCERS")) {
                                                UserData.content.hideLife = true;
                                }
                }
                var views = groupName.split(',');
    var svArr = []; 
    if(views!==null){
        for(var i=0;i<views.length; i++){
            if(views[i] == 'PRODUCERS'){
                svArr.push("Normal");
            }else if(views[i]=='EJPRODUCERS'){
                 svArr.push("EdwardJones");
            }
    }
    }
    var firmindicator = typeof UserData.content["firmindicator"] !== "undefined" ? UserData.content["firmindicator"] : "";
    firmindicator = firmindicator.toUpperCase();
    if(svArr.length >0 && firmindicator === "MGROUP"){
        svArr.push("Mgroup");
        if (typeof UserData.content["business-home"] === 'undefined') {
                                                UserData.content["business-home"] = "MGroup";
        }
    }
                
    if (typeof UserData.content["business-home"] === 'undefined' && svArr.length >1) {
        UserData.content["business-home"] = svArr[0];
    }

    var docEl = document.getElementById(templateId);
    if (docEl == null) {
        return;
    }
if(svArr.length <2){
    svArr=[];
}
    var source = docEl.textContent;
    var template = Handlebars.compile(source);
    var html = template({data: UserData.content, hubs: svArr });
    document.getElementById(templateElement).innerHTML = html;
    refreshSettings(UserData.content.home, UserData.content.states);

    var activeHub =  typeof UserData.content["business-home"] !== "undefined" ? UserData.content["business-home"] : "";
    $("input[name='b-hub'][value='"+activeHub+"']").prop('checked', true);

}

/*
	Handlebars Loader - Loads the news template based on its ID, parent 
						element, and authorable channel options.
		Variables:
		templateId - HTML ID of the handlebars element
		templateElement - HTML ID of the parent element
		tabs - JSON structure for the news tabs info
		titles - Array of titles for the custom news tabs
*/

function loadNewsTemplate(templateId, templateElement, tabs, titles) {
	var docEl = document.getElementById(templateId);
	if (docEl == null) {
		return;
	}
	var source = docEl.textContent;
	var template = Handlebars.compile(source);
	var html = template({data: UserData.content, boxes: tabs, tabs: titles });
	document.getElementById(templateElement).innerHTML = html;
	refreshSettings(UserData.content.home, UserData.content.states);
}

/* 
	Removes the news filter checkboxes from the DOM in the my news component.
	News filters are removed via jQuery to allow caching the full content in
	dispatcher.
	
	Variables:
	tab - The My News tab to apply filters from
*/
function mNewsFilters(tab) {
	$( tab+" input[name='channel']" ).each(function() {
		var ival = $(this).val();
		if ( ival === 'allnews') {
			$(this).click(function() {
				$( "input[name='channel']" ).each(function( ind, el ) {
					var aval = $(el).val();
					if ( aval !== 'allnews') {
						$(el).prop('checked', false);
					}
				});
				$(".parent-checkbox1").prop('checked', false);
			});
		} else {
			$(this).click(function() {
				var hasSelections = false;
				$( "input[name='channel']" ).each(function( ind, el ) {
					var aval = $(el).val();
					if ( aval === 'allnews') {
						$(el).prop('checked', false);
					}
					if ($(el).is(":checked")) {
						hasSelections = true;
					}
				});
				if ($(".parent-checkbox1").is(":checked")) {
					hasSelections = true;
				}

				if (!hasSelections) {
					setNewsChannels();
				}
			});
		}
	});
	$('div.local--nav > input').click(function() {
		if (!$("input[name='channels']").val()) {
			setNewsChannels();
		}
	});
	setNewsChannels();
	$('div.local--nav > input').click();
}

/* 
	Populates the Customize My News dialog with the user's selected channels.
	
	Variables:
	tab - The tab title to populate with user input values
*/
function rNewsFilters(tab) {
	var userNews;
	if (typeof UserData.content.news !== 'undefined' && UserData.content.news.length > 0) {
		userNews = UserData.content.news;
	}

	if (userNews != null) {
		var atab = [];
		if (tab != null && userNews.length > 0) {
			if (tab === '#tab0a') {
				atab.push(userNews[0]);
			} else if (userNews.length > 1){ 
				atab.push(userNews[1]);
			}
		}

		
		$.each(atab, function(ind, tabIt) {
			
			$("ul.menuPad").find("input[name='channel']" ).each(function(inde, newIte) {
				var isValid = false;
				for (i = 0; i < tabIt.length; i++) {
					var parts = tabIt[i].split("|");
					var heading = parts[0];
					var channel = parts[1];
					if ($(newIte).val() === channel && $(newIte).closest("ul.menuPad").prev("h2:contains('"+heading+"')").length > 0 ) {
						isValid= true;
					}
				}
				if (!isValid) {
					$(newIte).closest('li').remove();
				}
			});

			$("ul.menuPad").find(".parent-checkbox1").each(function() {
				var isValid = false;
				for (i = 0; i < tabIt.length; i++) {
					var parts = tabIt[i].split("|");
					var heading = parts[0];
					var channel = parts[1];
					
					if (channel === $(this).val() && $(this).closest("ul.menuPad").prev("h2:contains('"+heading+"')").length > 0) {
						isValid= true;
					}
				}
				if (!isValid) {
					$(this).closest('li').remove();
				}
			});

		});
		$('ul').not(':has(li)').prev('h2').remove();
		$('ul').not(':has(li)').prev('hr').remove();
		$('ul').not(':has(li)').remove();
		$('input').prev('hr').remove();
	}
}

/* 
	Populates the Site Preference radio button with the corresponding 
	personalization selection.
*/
function updateHomePage() {
	var home = {
		"home" : $CQ('input[name="home-page"]:checked').val(),
		"business-home" : $CQ('input[name="b-hub"]:checked').val()
	};
	sendData(home);
}

/* 
	Refresh Sidepanel - Reloads all of the side panel content. This can 
						be called any time to load the latest UserData 
						object values into the sidepanel
*/
function refreshSidepanel() {
	if (typeof UserData !== 'undefined') {
		var docEl = document.getElementById("pullout-template");
		if (docEl == null) {
			return;
		}
		var PulloutSource = docEl.textContent;
		var PulloutTemplate = Handlebars.compile(PulloutSource);
		var PulloutHTML = PulloutTemplate({data: UserData.content});
		document.getElementById("slidepanel-info").innerHTML = PulloutHTML;
	}
}

/* 
	Checks the appropriate filter option checkboxes for the My News 
	component using user selections. 
*/
function refreshNews(news) {
  //  console.log("news"+news);
	if (typeof news !== 'undefined' && news != null) {
		$.each(news, function(i, tabIt) {
			$.each(tabIt, function(index, value) {
				var parts = value.split("|");
               // console.log("parts length"+parts.length);
				if (parts.length === 2) {
					var group = parts[0];
					var item = parts[1];
                   // checkMynewsFilterCheckbox(item);
                   // console.log("item: "+item);
                  //  console.log("tab : "+"#tab"+i+"a");
					var cbox = $("#tab"+i+"a").find('h2:contains("'+group+'")').nextUntil( "h2" )
                    			.find('label').find('[value="'+item+'"]');
					//console.log("cbox"+cbox.val);
					cbox.prop('checked', true);
				}
			});
		}) ;
		countNewsCheckboxes();
	}
}

//function checkMynewsFilterCheckbox(item){
    //("input[name='channel']").each(function(){$(this).prop('checked', true);});

//}

/* 
	Save Data - Saves the users preferences for the Customize My News channels 
				selected in the sidepanel dialog.
*/
function updateNews() {
	var tabNews = [];

	$("div[name='newsTab']").each(function(ind) {
		var newsArr = $(this).find('input[name="news-item"]:checked').map(function(i, val){
			var box = $(val);
			var group = box.closest('div.checkbox').prevAll('h2:first').text();
			if (group === "") {
				group = box.closest('div.sub-group').prevAll('h2:first').text();
			}
			var newsItem = group+"|"+this.value;
			return newsItem;
		}).get();

		tabNews.push(newsArr);
         //console.log("tabnews11::"+tabNews.toString());
       // console.log("tabnews::"+tabNews.length);
	});
	var news = {
		"news" : tabNews
	};
if (navigator.userAgent.indexOf("Firefox") > 0) {
  var url = $(location).attr('href');
 // console.log(url);
  var setUrl = url.split("#");
  var currentUrl= setUrl[0];
  location.replace(currentUrl);
  //  console.log(currentUrl);
   sendData(news);
   //object.reload(forcedReload);
}else{
    sendData(news);
 // location.reload(true);
}

}

/* 
	Helper - Counts the number of options selected for each tab in the 
			 Customize My News panel
*/
function countNewsCheckboxes() {
	var n = $('[name="newsTab"]').length;
	var boxLengths = [];
	for (i = 0; i <n; i++) {
		var $tabBoxes = $('#tab'+i+'a').find('input[name="news-item"]');
		var boxLength = $tabBoxes.find(':checkbox:checked').length;
		boxLengths.push(boxLength);
	}

	var $tabTitles = $('[name="newsTabTitle"] >');
	$.each($tabTitles, function(j, val) {
		$(val).text(function() {
			var oldStr = $(this).text();
			var endIndex = oldStr.indexOf("(");
			var newStr = oldStr.substring(0,endIndex) + "("+boxLengths[j]+ " selected)";
			return newStr;
		});
	});
}

/* 
	Toggle - Selects the appropriate tab of the Customize My News dialog
	
	Variables:
	activeEl - HTML ID of the tab which should be active
	ind - index of the tab to activate
*/
function setActiveTab(activeEl, ind) {
	var $tabTitles = $('[name="newsTabTitle"]');
	$.each($tabTitles, function(i, val) {
		if (ind === i) {
			$(val).removeClass("active").addClass("active");
		} else {
			$(val).removeClass("active");
		}
	});
	$('[name="newsTab"]').removeClass("active in");
	$('#'+activeEl).addClass("active in");
}

/*  
	Selects all options in the currently active tab of Customize My News section
*/
function selectAll(tabId) {
	var $tabBoxes = $('#'+tabId).find('input[name="news-item"]');
	$.each($tabBoxes, function(j, val) {
		$(val).prop('checked', true);
	});
	countBoxes(tabId);
}
/* 
	Deselects all options in the currently active tab of Customize My News section
*/
function deselectAll(tabId) {
	var $tabBoxes = $('#'+tabId).find('input[name="news-item"]');
	$.each($tabBoxes, function(j, val) {
		$(val).prop('checked', false);
	});
	countBoxes(tabId);
}

/* 
	Helper - Function for tabulating total checkboxes selected
*/
function countBoxes(tabId) {
	var tot = 0;
	var $tabBoxes = $('#'+tabId).find('input[name="news-item"]');
	$.each($tabBoxes, function(j, val) {
		if ($(val).is(":checked")) {
			tot++;
		}
	});
	var oT = $('[href="#'+tabId+'"]').text();
	$('a[href="#'+tabId+'"]').text(oT.split("(")[0]+"("+tot+" selected)");
}

/* 
	Listener - Attaches a function to the checkboxes in the Customize My News 
			   dialog to update the number of tabs selected count in the tab
			   heading
	Variables:
	tabId - HTML ID of the tab to count the number of selected checkboxes
*/
function addCountFunc(tabId) {
	var $tabBoxes = $('#tab'+tabId+'a').find('input[name="news-item"]');
	$.each($tabBoxes, function(j, val) {
		$(val).click(function() {
			countBoxes("tab"+tabId+"a");
		});
	});
}

/* 
	Refreshes all sections of the settings panel to the user's selected values
	
	Variables:
	home - Site Preference value
	Deprecated: states - Array of user's states of business  
*/
function refreshSettings(home, states) {
	var $homeEl = $('[name="home-page"]');
	if (home!= null) {
		$homeEl.filter('[value="'+home+'"]').prop('checked', true);
	}


	var $stateEl = $('.checkbox-states > input');
	if (states != null) {
		$.each(states, function(j, val) {
			$stateEl.filter('[value="'+val+'"]').prop('checked', true);
		});
	}

	var imageInputField = document.getElementById('imageInput');
	if (imageInputField != null) {
		imageInputField.addEventListener('change', function(){
			for(i = 0; i<this.files.length; i++){
				var file =  this.files[i];
				var formData = new FormData();
				formData.append("file", file);
				$.ajax({
					type:'POST',
					url: persDomain+'/pers/data/asset/',
					data:formData,
					cache:false,
					contentType: false,
					processData: false,
					success:function(data){
						$('div.profile-border > img').attr("src", UserData.content.photo+"?"+new Date());
					},
					error: function(data){
						alert("Image failed to upload, please try again.");
					}
				});
				break;
			}
		}, false);
	}
}

/* 
	Deprecated - Saves Data - Updates the user's selected states of business.
*/
function updateBusinessStates() {
	var statesArr = $CQ('.checkbox-states > input:checked').map(function(){
		return this.value;
	}).get();

	var states = {
		"states" : statesArr
	};

	sendData(states);
}

/*
	Deprecated - Saves Data - Saves the user's email address
*/
function updateEmail() {
	var email = {
		"email" : "email@email.com"
	};

	sendData(email);
}

/*
	Deprecated - Saves Data - Saves the user's profile image
*/
function updatePhoto() {
	var photo = {
		"photo" : "/path/to/photo.png",
	};

	sendData(photo);
}

/* 
	Save Data - Helper function used to generate the JSON structure 
				for the personalization DB.
	Variables:
	data - JSON object containing the user data
*/
function sendData(data) {
	var requestData = {
		"contentAction" : "set",
		"content" :  data
	};
	$CQ.ajax({
		type: "POST",
		url: url,
        xhrFields: { 
       	withCredentials: true 
       	},
		data: JSON.stringify(requestData),
		contentType: "application/json",
		success: hideLoader,
		failure: failedMsg
	});
	showLoader();
}


/* 
	Deprecated - Allows users to upload avatar photos
*/
function chooseFile() {
	$("#imageInput").click();
}

/* 
	Success Function - Once data is successfully returned from the personalition
					   service, this method is called to display the confirmation
					   message
*/
function hideLoader() {
	$('.updateProfileFeedback').addClass('in');
	setTimeout(function () {
		$('.updateProfileFeedback').removeClass('in');
	}, 3000);
	if ($('#setting-modal').hasClass('in')) {
		$('#setting-modal').find("button[data-dismiss='modal']").click();
	} else if ($('#customize-modal').hasClass('in')) {
		$('#customize-modal').find("button[data-dismiss='modal']").click();
	}
	
	checkFavorites();
	refreshSidepanel();
}

/*) 
	Failure function to determine if an update to the personalization
	preferences did not occur. No changes are persisted in this case.
*/
function failedMsg() {
	alert("Failed to update preferences.");
}

/*
   Deprecated - This is an alternate entry point to perform actions during 
				a user's personalization update action
*/
function showLoader() {}

/* 
	Resets the favorites to user's selection in the sidepanel. 
	This method is called when a user Unfavorites a page. A full
	refresh is performed to keep an always update to date view.

	Inputs:
	linkHref = A URL to remove from the user's favorites
*/
function refreshFavorites(linkHref) {
	var favorites = UserData.content.favorites;
	if (favorites != null) {
		for (k = 0; k < favorites.length; k++) {
			if (cleanUrl(favorites[k].url) === cleanUrl(linkHref)) {
				favorites.splice(k, 1);
				var newFavs = {
					"favorites" : favorites
				};
				sendData(newFavs);
				$('[data-toggle=favoritesTooltip]').removeClass("favorited");
				break;
			}
		}
		UserData.content.favorites = favorites;
	}
	
}

/* 
	Deprecated - Auto adjust image size's based on browser dimensions
	
	Variables:
	id - HTML ID of the image to adjust
*/
function autoResize(id){
    var newheight;
    var newwidth;

    if(document.getElementById){
        newheight = document.getElementById(id).contentWindow.document.body.scrollHeight;
        newwidth = document.getElementById(id).contentWindow.document.body.scrollWidth;
    }

    document.getElementById(id).height = (newheight) + "px";
    document.getElementById(id).width = (newwidth) + "px";
}

/* 
	Tests whether the current pages is selected in the user's favorites,
	updates the favoritesLabel, and adds click listener.
*/
function checkFavorites() {
	if (hasFavorite()) {
		if ($(this).hasClass("favorited") == 0) {
			$('[data-toggle=favoritesTooltip]').toggleClass("favorited");
		}
		$(".favoritesLabel").html("Unfavorite This Page");
	} else {
		$('[data-toggle=favoritesTooltip]').removeClass("favorited");
		$(".favoritesLabel").html("Favorite This Page");
	}
}

/* 
	Adds the favorite based on the page title
	
	Variables:
	title - page title to test 
*/
function addFavorite(title) {
	if (!hasFavorite()) {
		var favorites =UserData.content.favorites;
        if(favorites==null)
        {
			favorites=[];
        }
		var newFav= {
			"title" : title,
			"url" : location.href
		};
		favorites.push(newFav);
		var newFavs = {
			"favorites" : favorites
		};
		sendData(newFavs);
		UserData.content.favorites = favorites;
	}
}

/*
	Helper - Tests if the current page is already a favorite of the user
*/
function hasFavorite() {
	var favorites = UserData.content.favorites;
	if (favorites == null) {
		return false;
	}
	
	var favUrl = cleanUrl(location.href);
	
	for (i = 0; i < favorites.length; i++) {
		var aFav = cleanUrl(favorites[i].url);
		if (aFav === favUrl) {
			return true;
		}
	}
}

/*
	Helper - Strips URL down to path only
*/
function cleanUrl(hrf) {
	return hrf.split('?')[0].split('#')[0];
}

/* 
	Helper - Function to create a cookie
	
	Variables:
	name - Name to set for the cookie
	value - Value to set for cookie
	days - Expiration in days
	
*/
function createCookie(name, value, days) {
	if (getCookie(name) === value) {
		return;
	}
    var expires;

    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    } else {
        expires = "";
    }
    document.cookie = encodeURIComponent(name) + "=" + encodeURIComponent(value) + expires + "; path=/";
}

/* 
	Helper - Function to read cookies
	
	Variables:
	name - Name of the cookie to read
*/
function getCookie(name) {
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1) {
		begin = dc.indexOf(prefix);
		if (begin != 0) return null;
	}
	else
	{
		begin += 2;
		var end = document.cookie.indexOf(";", begin);
		if (end == -1) {
			end = dc.length;
		}
	}
	return unescape(dc.substring(begin + prefix.length, end));
}


/*
	Init - Populates data into the sidepanel view and binds click
		   listeners to the appropriate links and buttons on the page.
*/
$(document).ready(function() {

	if (UserData != null && typeof UserData !== 'undefined') {
		
	$.ajaxSetup({ cache: false });
	
	loadData();
	// submit Current View Details
	//trackCurrentView();

	$('body').on('click', 'a[href$=".pdf"]', function() {
		trackPdfClick(this.href, this.title);
	});
	
	$('[data-toggle=favoritesTooltip]').click(function () {
    	
    	if (!hasFavorite()) {
    		addFavorite(document.title);
    	} else {
    		refreshFavorites(location.href);
    	}
  	});
	}
});

/* 
	Listener - Tracks PDF clicks for the recently accessed resources
			   component. 
*/
function trackPdfClick(link, title){
	var url = persDomain+"/pers/data/views/";
	var currentClick = {
		"view" : link,
		"title" : title
	};

	sendDataToUrl(currentClick, url);
}

/* 
	Listener - Tracks view for the current page. Pages viewed are included
			   as part of the recently accessed resources listings.
*/
function trackCurrentView() {
	var url = persDomain + "/pers/data/views/";

	if ($(viewtrackerTitle).val() === "" || $(viewtrackerFormat).val() === "" || $(viewtrackerType).val() === "") {
		return;
	}
	var currentView = {
		"view": getPathFromUrl($(location).attr('href')),
		"title": $(viewtrackerTitle).val(),
		"format": $(viewtrackerFormat).val(),
		"type": $(viewtrackerType).val()
	};
	sendDataToUrl(currentView, url);
}

/* 
	Helper  - Returns content path without any query string attached
*/
function getPathFromUrl(url) {
	return url.split("?")[0];
}

function sendDataToUrl(data, url) {
	var requestData = {
		"contentAction" : "set",
		"content" :  data
	};
	$CQ.ajax({
		type: "POST",
		url: url,
        xhrFields: { 
       	withCredentials: true 
       	},
		data: JSON.stringify(requestData),
		contentType: "application/json",
		failure: failedMsg
	});
}

/* 
	Resets recent views component to the latest news returned from the
	personalization service
*/
function refreshRecentViews() {
	var ele = document.getElementById("tpl-recentviews");
	if (typeof UserViews !== 'undefined' && typeof ele !== 'undefined' && ele != null) {

		var ViewSource = ele.textContent;
		var ViewTemplate = Handlebars.compile(ViewSource);
		var ViewHTML = ViewTemplate({list: UserViews});
		document.getElementById("view-info").innerHTML = ViewHTML;
	}
}

$(function() {
if(UserData !=null){
	$("li.star-icon").removeClass("inactiveLink");
    }else{
    $("li.star-icon").addClass("inactiveLink");
    }
});