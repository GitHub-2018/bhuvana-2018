var underWriterEmail;
var subjectEmail;
var caseManagerEmail;
$(document).ready(function() {
    if ($('.newbusiness-serach').is(':visible')) {
        //$('#agentSeachBermuda').focus();
    }

    $(".newbusiness-serach").parent().addClass("newbusiness-serach-wrapper");
    $(".newbusiness-serach").parent().addClass("row");
    /*function to not allow user to put alpha or special character*/
    function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
        return true;
    }

    /*function to remove the error on focus*/
    $("#agentSeachBermuda").focus(function() {
        $(".validate_input__valid_agent_bermuda").remove();
        $(".validate_input_agen_Error_code").remove();
    });

    /*function to remove the error on focus*/

    /*For the agent search input field validation*/
    $("#agantsearchSubmitBermuda").on("click", function() {
        if (($("#agentSeachBermuda").val() != "") && ($("#agentSeachBermuda").val().length == 8)) {
            $(".validate_input__valid_agent_bermuda").remove();
        } else {
            if ($('.validate_input__valid_agent_bermuda').length < 1) {
                $("#agantsearchSubmitBermuda").after('<div class="validate_input__valid_agent_bermuda">Please enter an 8-digit policy number</div>');
            }

        }
        if ($('.validate_input__valid_agent_bermuda').length < 1) {
            /*call ajax function here */
            var policyNum = $("#agentSeachBermuda").val();
            retrieveNewBusinessCaseStatus(policyNum);


        }
    });
    /*For the agent search input field validation*/
    $('#backButtonBermuda,#backButtonBermudatop').click(function() {

        $('#agentSeachBermuda').focusin();
        // parent.history.back();
        // location.reload();
        // return false;
        $(window).scrollTop(0);
        $('#agentSeachBermuda').focus();
        $(".newbusiness-serach").show();
        //$(".newbusiness-serach-wrapper").height("300px");
        $(".newbusiness-result").hide();
        $("#agentSeachBermuda").val("");
        $('.result-detail').remove();
        $(".newbusiness-result-detail.Request_status").nextAll(".newbusiness-result-detail").remove();
    });
    /*********************************For Case manager and undeewriter mailto code*****************************************************************/
    $(document).on('click', '#mailToUnderwriter', function(e) {
        $("#underWriterBermidAgree").addClass("Underwiterclick");
        $("#underWriterBermidAgree").removeClass("CaseManagerclick");

    });
    $(document).on('click', '#mailToCaseManager', function(e) {
        $("#underWriterBermidAgree").removeClass("Underwiterclick");
        $("#underWriterBermidAgree").addClass("CaseManagerclick");


    });
    $(document).on('click', '#underWriterBermidAgree', function(e) {
        if ($("#underWriterBermidAgree").hasClass("Underwiterclick")) {
            document.location = "mailto:" + underWriterEmail + "?subject=" + subjectEmail + "&cc=" + caseManagerEmail;
        } else if ($("#underWriterBermidAgree").hasClass("CaseManagerclick")) {
            document.location = "mailto:" + caseManagerEmail + "?subject=" + subjectEmail;
        }
    });


    /**************************************For Case manager and undeewriter mailto code END**********************************************************/


});
/* Get UserData object and pass values accordingly*/

function retrieveNewBusinessCaseStatus(policyNum) {
    var sortBy = "";
    var policyNumber = policyNum;
    var userName = "";
    var userRole = "";
    var appId = "ManulifeBermuda";
    if (typeof UserData != undefined && UserData != null) {
        userName = UserData.content.uid;
        userRole = UserData.content.role;
    }
    if (userRole == "Distributor") {
        userRole = "Producer";
        sortBy = "2";
    }
    $.ajax({

        type: "POST",
        url: "/bin/sling/bermudaNBCS",
        data: {
            sortBy: sortBy,
            policyNumber: policyNumber,
            userName: userName,
            userRole: userRole,
            appId: appId
        },
        beforeSend: function() {
            $(".search-loader").show();
            $("#agantsearchSubmitBermuda").hide();
        },
        success: function(data) {
            $(".search-loader").hide();
            $("#agantsearchSubmitBermuda").show();
            var getJSONdata = JSON.parse(data);
            //var isjson = isJson(data);
            var iserror =isError(getJSONdata);
            if (iserror == true) {
                var errorcode = getJSONdata.Error;
                $(".newbusiness-serach").show();
                $(".newbusiness-result").hide();
                if ($('.validate_input_agen_Error_code').length < 1) {
                    $(".agent-input-wrapper-bermuda").after('<div class="validate_input_agen_Error_code">' + errorcode + '</div>');
                }

            } else {
                $(".newbusiness-serach").hide();
                $(".newbusiness-result").show();
               //var getJSONdata = JSON.parse(data);
                var plotData = getJSONdata.GetPolicyStatus_response;
                underWriterEmail = plotData.underWriterEmailAddress;
                subjectEmail = plotData.emailSubject;
                caseManagerEmail = plotData.caseManagerEmailAddress;
                /*code to change the month  format*/
                 var date_year = function(currentDate) {
                    var getTotalDate = currentDate.split("/");
                    var getYear = getTotalDate[2];
                    var getdate = getTotalDate[1];
                    var getmonth= getTotalDate[0];
                    getmonth= parseInt(getmonth, 10);
                    //console.log(parseInt(getmonth, 10) );
                    var month_name = function(dt) {
                    mlist = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                    //return mlist[dt.getMonth()];
                      return mlist[getmonth-1];
                    };
                    var makeindate = getdate.concat(",");
                    var makedate = makeindate.concat(getYear);
                    var makemonth = month_name(new Date(plotData.hoSetupDate)).concat(" ");
                    var dateformatter = makemonth.concat(makedate);
                    return dateformatter;

                };
            
                var amount_formatter = function(amountshow) {
                    var getamountinshow;
                    var makeamount;
                    var number = Number(amountshow);
                    getamountinshow = number.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
					makeamount = "$"+getamountinshow;
                    /*if (number % 1 != 0){
                    makeamount = "$"+getamountinshow;
                    }
                    else{
                    var getamountshow = getamountinshow.split(".");
                    makeamount = "$"+getamountshow[0];
                    }*/
                    return makeamount;
                };


                /*code to check if it is array or object*/
                function isArray(what) {
  						  return Object.prototype.toString.call(what) === '[object Array]';
				}
                /*code to check if it is array or object END*/

                /*code to change the date formate*/
            
                if(isArray(plotData.sellingAgent)){
                    $(".newbusiness-result-detail").children(".Selling_Agent").after('<span class="col-xs-6 col-sm-9 result-detail newbusiness-result-detail-manager">' + plotData.sellingAgent.join(', ') + '</span>');
                }else{
                    $(".newbusiness-result-detail").children(".Selling_Agent").after('<span class="col-xs-6 col-sm-9 result-detail newbusiness-result-detail-manager">' + plotData.sellingAgent + '</span>');
                }
                
               if(isArray(plotData.gaBGAFirm)){
                   $(".newbusiness-result-detail").children(".Distributor").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.gaBGAFirm.join(', ') + '</span>');
                }else{
                    $(".newbusiness-result-detail").children(".Distributor").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.gaBGAFirm+ '</span>');
                } 
                
                $(".newbusiness-result-detail").children(".Submission_Type").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.submissionType + '</span>');
                $(".newbusiness-result-detail").children(".Case_Status").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.caseStatus + '</span>');
                $(".newbusiness-result-detail").children(".Underwriters").after('<a id="mailToUnderwriter" data-toggle="modal" data-target="#underwriterBermuda"><span class="col-xs-6 col-sm-3 result-detail newbusiness-result-detail-manager" id="Underwriterwrapper">'+plotData.underWriter+'</span></a>');
                $(".newbusiness-result-detail").children(".Case_Manager").after('<a id="mailToCaseManager" data-toggle="modal" data-target="#underwriterBermuda"><span class="col-xs-6 col-sm-3 result-detail newbusiness-result-detail-manager" id="CaseManagerwrapper">'+plotData.caseManager+'</span></a>');
                if (plotData.salesPremiumDate != null) {
                    $(".newbusiness-result-detail").children(".Sales_Premium_Date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + date_year(plotData.salesPremiumDate) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Sales_Premium_Date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.salesPremiumDate + '</span>');
                }
                $(".newbusiness-result-detail").children(".Policy_Number").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.policyNumber + '</span>');
                $(".newbusiness-result-detail").children(".Plan").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.plan + '</span>');
                if (plotData.faceAmount != null) {
                    $(".newbusiness-result-detail").children(".Face_Amount").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + amount_formatter(plotData.faceAmount) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Face_Amount").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.faceAmount + '</span>');
                }
                if (plotData.plannedPremium != null) {
                    $(".newbusiness-result-detail").children(".Planned_Premium").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + amount_formatter(plotData.plannedPremium) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Planned_Premium").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.plannedPremium + '</span>');
                }
                $(".newbusiness-result-detail").children(".Premium_Mode").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.premiumMode + '</span>');
                if (plotData.amountPaid != null) {
                    $(".newbusiness-result-detail").children(".Amount_Paid").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + amount_formatter(plotData.amountPaid) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Amount_Paid").after('<span class="col-xs-6 col-sm-9 result-detail newbusiness-result-detail-manager">' + plotData.amountPaid + '</span>');

                }
                if (plotData.targetPremium != null) {
                    $(".newbusiness-result-detail").children(".Target_Premium").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + amount_formatter(plotData.targetPremium) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Target_Premium").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.targetPremium + '</span>');
                }
                if (plotData.hoSetupDate != null) {
                    $(".newbusiness-result-detail").children(".Set-up_date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + date_year(plotData.hoSetupDate) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Set-up_date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.hoSetupDate + '</span>');
                }
                if (plotData.mailDate != null) {
                    $(".newbusiness-result-detail").children(".Mail_Date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + date_year(plotData.mailDate) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Mail_Date").after('<span class="col-xs-9  result-detail newbusiness-result-detail-manager">' + plotData.mailDate + '</span>');
                }
                if (plotData.expireDate != null) {
                    $(".newbusiness-result-detail").children(".Expire_Date").after('<span class="col-xs-6 col-sm-9 result-detail newbusiness-result-detail-manager">' + date_year(plotData.expireDate) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Expire_Date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.expireDate + '</span>');
                }
                $(".newbusiness-result-detail").children(".Decision_Type").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.decisionType + '</span>');
                $(".newbusiness-result-detail").children(".Decision_Message").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.decisionMessage + '</span>');
                if (plotData.decisionDate != null) {
                    $(".newbusiness-result-detail").children(".Decision_Date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + date_year(plotData.decisionDate) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Decision_Date").after('<span class="col-xs-6 col-sm-9  result-detail newbusiness-result-detail-manager">' + plotData.decisionDate + '</span>');
                }

                 /*For insured data we are coding Here*/
                $(".newbusiness-result-detail").children(".Insured").after('<span class="col-xs-6 col-sm-10 result-detail newbusiness-result-detail-manager">' + plotData.insuredDetails.insured + '</span>');
                if (plotData.insuredDetails.dateOfBirth != null) {
                    $(".newbusiness-result-detail").children(".Birth").after('<span class="col-xs-6 col-sm-10  result-detail newbusiness-result-detail-manager">' + date_year(plotData.insuredDetails.dateOfBirth) + '</span>');
                } else {
                    $(".newbusiness-result-detail").children(".Birth").after('<span class="col-xs-6 col-sm-10  result-detail newbusiness-result-detail-manager">' + plotData.insuredDetails.dateOfBirth + '</span>');
                }
                $(".newbusiness-result-detail").children(".age-Set-Up").after('<span class="col-xs-6 col-sm-10  result-detail newbusiness-result-detail-manager">' + plotData.insuredDetails.ageSetup + ' </span>');

                /*For Last data request  we are coding Here*/

               if(plotData.insuredDetails.hasOwnProperty("requirements") ){
                if(isArray(plotData.insuredDetails.requirements)){
                $.each(plotData.insuredDetails.requirements, function(index, value) {                       
                    if (plotData.insuredDetails.requirements[index].received != null) {
                        var viewrecived = date_year(plotData.insuredDetails.requirements[index].received);
                    } else {
                        var viewrecived = plotData.insuredDetails.requirements[index].received;
                    }
                    if (plotData.insuredDetails.requirements[index].reviewed != null) {
                        var viewreviewed = date_year(plotData.insuredDetails.requirements[index].reviewed);
                    } else {
                        var viewreviewed = plotData.insuredDetails.requirements[index].reviewed;
                    }

                    $(".newbusiness-result-detail.Request_status").after('<div class="row newbusiness-result-detail newbusiness-result-detail-formobile"><span class="col-xs-3 result-detail">' + plotData.insuredDetails.requirements[index].status + '</span><span class="col-xs-3 result-detail newbusiness-result-detail-manager">' + viewrecived + '</span><span class="col-xs-3 result-detail newbusiness-result-detail-manager">' + viewreviewed + '</span><span class="col-xs-3 newbusiness-result-detail-manager"><span class="result-detail result-detail-requirement">' + plotData.insuredDetails.requirements[index].requirementDesc + '</span><span class="result-detail result-detail-name">' + plotData.insuredDetails.requirements[index].requirementName + '</span></span></div>');
			  });

                }
                else{
                    if (plotData.insuredDetails.requirements.received != null) {
                        var viewrecived = date_year(plotData.insuredDetails.requirements.received);
                    } else {
                        var viewrecived = plotData.insuredDetails.requirements.received;
                    }
                    if (plotData.insuredDetails.requirements.reviewed != null) {
                        var viewreviewed = date_year(plotData.insuredDetails.requirements.reviewed);
                    } else {
                        var viewreviewed = plotData.insuredDetails.requirements.reviewed;
                    }

                    $(".newbusiness-result-detail.Request_status").after('<div class="row newbusiness-result-detail newbusiness-result-detail-formobile"><span class="col-xs-3 result-detail">' + plotData.insuredDetails.requirements.status + '</span><span class="col-xs-3 result-detail newbusiness-result-detail-manager">' + viewrecived + '</span><span class="col-xs-3 result-detail newbusiness-result-detail-manager">' + viewreviewed + '</span><span class="col-xs-3 newbusiness-result-detail-manager"><span class="result-detail result-detail-requirement">' + plotData.insuredDetails.requirements.requirementDesc + '</span><span class="result-detail result-detail-name">' + plotData.insuredDetails.requirements.requirementName + '</span></span></div>');


                       }
                }
                /*add bold in the lebels*/
                $(".newbusiness-result-detail").children("span:first-child").css("font-weight", "Bold");
                $(".newbusiness-result-detail.Request_status").nextAll(".newbusiness-result-detail").children("span:first-child").css("font-weight", "200");
                $('.result-detail').each(function() {
                    var text = $(this).text();
                    $(this).text(text.replace('null', ''));

                });
				$('.result-detail').each(function() {
                    var text = $(this).text();
                    $(this).text(text.replace('undefined', ''));

                });
                $('.newbusiness-result-detail-manager').each(function() {
				if($(this).children("span.result-detail-requirement").text() != "" ){
                    $(this).children("span.result-detail-requirement").after('</br>');

                }


                });
				
				
				 /*code to check if email is correctly handles*/
                if($("#Underwriterwrapper").text() == ""){
                    $("#mailToUnderwriter").hide();
                    //console.log("hiii");
                }else{
					 $("#mailToUnderwriter").show();
                }
                 if($("#CaseManagerwrapper").text() == ""){
                    $("#mailToCaseManager").hide();
                    //console.log("hiii");
                }else{
					$("#mailToCaseManager").show();
                }
                 if (plotData.underWriterEmailAddress != null) {
                underWriterEmail = plotData.underWriterEmailAddress;
                }else{
				underWriterEmail = "";
                }               
                subjectEmail = plotData.emailSubject;
                if (plotData.caseManagerEmailAddress != null) {
                caseManagerEmail = plotData.caseManagerEmailAddress;
                }else{
				caseManagerEmail = "";
                }
                /*code to check if email is correctly handles END*/
				
				/*code to check if the email address is not there make link not clickable*/
                if((plotData.underWriterEmailAddress == null) || (plotData.underWriterEmailAddress == "")){
                  $("#mailToUnderwriter").removeAttr('data-target');
                  $("#mailToUnderwriter").removeAttr('data-toggle');
                  $("#mailToUnderwriter").css('cursor', 'default').css('text-decoration', 'none');
                }
                if((plotData.caseManagerEmailAddress == null) || (plotData.caseManagerEmailAddress == "")){
                  $("#mailToCaseManager").removeAttr('data-target');
                  $("#mailToCaseManager").removeAttr('data-toggle');
                  $("#mailToCaseManager").css('cursor', 'default').css('text-decoration', 'none');
                }

                /*code to check if the email address is not there make link not clickable*/



            }
        },

        error: function() {
            //console.log("there is error");
        }
    });
}

function isJson(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}
function isError(data)
{ 
    if(data.hasOwnProperty('Error')){
        return true;
    }
    return false;
}