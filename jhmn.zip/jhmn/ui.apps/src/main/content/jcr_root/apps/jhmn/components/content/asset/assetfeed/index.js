use(function(){
    var index=this.arg;
	var index= index%4;
    return{
        itemIndex: index
    };
});