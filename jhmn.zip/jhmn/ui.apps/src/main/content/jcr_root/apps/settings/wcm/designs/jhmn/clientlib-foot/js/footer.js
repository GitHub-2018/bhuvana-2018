function checkColumnSize(dialog){
	var columns = dialog.findById("columns");
    var columnSizes = columns.getValue();
    var sum = 0;

    if(columnSizes.constructor === Array){
        sum=0;
        for(i=0;i<columnSizes.length;i++){
            sum = sum + parseInt(columnSizes[i]);
        }

    }else{
    	if(columnSizes === ""){
        	return true;
    	}else{
			sum = parseInt(columnSizes);
    	}
    }
    if(sum <= 12){
    	return true;
    }else{
        CQ.Ext.Msg.show({
   			title:'Warning',
  			msg: 'You have entered column sizes whose sum exceeds 12. Please Change the values.',
   			buttons: CQ.Ext.Msg.OK,
   			icon: CQ.Ext.MessageBox.WARNING
		});
        return false;
    }
}
function isNumberKey(evt)
       {
          
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if (charCode != 46 && charCode > 31 
            && (charCode < 48 || charCode > 57))
             return false;

          return true;
       }
