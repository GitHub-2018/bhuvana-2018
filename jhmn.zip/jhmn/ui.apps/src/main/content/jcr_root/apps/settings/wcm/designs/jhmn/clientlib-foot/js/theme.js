
function submitMethod(){
      var qvalue;
      var qlife;
      var q1life;
      var qltc;
      var q1ltc;

    if(document.getElementById("qvalue")!=null)
        {
            qvalue=document.getElementById("qvalue").value;
        }
    if(document.getElementById("qlife")!=null)
        {
            qlife=document.getElementById("qlife").value;
        }
    if(document.getElementById("q1life")!=null)
        {
            q1life=document.getElementById("q1life").value;
        }
    if(document.getElementById("qltc")!=null)
        {
            qltc=document.getElementById("qltc").value;
        }
    if(document.getElementById("q1ltc")!=null)
        {
            q1ltc=document.getElementById("q1ltc").value;
        }


         if((qvalue!=null && qvalue!= "")||(qlife!=null && qlife!= "")||(qltc!=null && qltc!= "")||(q1ltc!=null && q1ltc!= "")||
         (q1life!=null && q1life!= ""))
         {
           document.getElementById("formid").submit();
             return true;
         }
         else
         {
             return false;
         }
  }
function blockSpecialChar(e){
        var k;
        document.all ? k = e.keyCode : k = e.which;
        return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }
function blockEmailSpecialChar(e){
        var k;
        document.all ? k = e.keyCode : k = e.which;
       return ((k >= 64 && k < 91)||(k >= 94 && k <= 96) ||(k > 35 && k < 40)||k == 63|| (k > 96 && k <= 126) || k == 8 || k == 32  || k == 42 || k == 43|| (k >= 45 && k <= 57));
        }

$(".mobile-search").click(function() {
    submitMethod();
 });

(function ($) {
  /**
   * Swap out svg files for PNGs on unsupporting devices. Modrnizr determines
   * what an unsupporting device is by adding the .no-svg class to the html
   * tag.
   */

  function svgToPng() {
    $('.no-svg .js__svg-image').each(function () {
      var src = $(this).attr('src');
      src = src.replace("svg", "png");
      $(this).attr('src', src);
    });
  }

  /**
   * Gives each bootstrap tab a unique URL.
   */
  window.onload = function() {

    /*** initiate mobile menu with utility nav items */
    utilityNavBuilder();

    var hash = window.location.hash;
    var prefix = "tab-";
    if (hash) {
    // Update 8.11.16 -- if there is an encoded hash, decode it
      if(hash.match('%23')) {
        while(hash.match('%23')) {
          hash = hash.replace('%23', '#');
        //  console.log("found encoded hash");
        }
      }
      // if more than 1 hash, split into seperate ones and iterate
      var hashArray = hash.split('#');
      for(var i in hashArray) {
        var h = hashArray[i];
        $('[data-toggle="toggle-group"][data-target="#'+h+'"]').click();

        var regex = new RegExp("^(" + prefix + ")","g");
        $('.nav-tabs a[href="#' + h.replace(regex, "") + '"]').click();
        // console.log(h.replace(regex, ""))
      }
    } else if($('[data-toggle="toggle-group"].active').length) {
      $('[data-toggle="toggle-group"].active').click();
    }
    // Change hash for page-reload
    $('.nav-tabs a').on('shown.bs.tab', function (e) {
      hash = e.target.hash.replace("#", "#" + prefix);  
      appendHashes(hash, prefix);
    });

  }

  // Appends multiple hashes to the URL (good for tabs within tabs)
  //
  function appendHashes(tgt, prefix) {
    var hash = location.hash,
    prefix = prefix || '';
    if(hash) {
      hashArray = hash.match(/#([A-Za-z0-9-_]+)/g);
      if(hash.indexOf(tgt) == -1) {
        if(hash.indexOf(prefix) == -1) {
          if(hashArray.length == 2){
            hash = hashArray[0].replace('#','') + tgt;
          } else {
            // Hash not found, append it
            hash += tgt;
          }
        } else {
          hash = tgt; 
        }
      }
    } else {
      hash = tgt;  
    }
    if (hash.match(/[^a-zA-Z/#0-9-_]/) == null && hash.substring(0, 1) == "#" && hash.match("java") == null) {
      location.hash = hash;
    }
    else {
     // console.log("rejected hash");
      return;
    }
  }

  //launch event on selecting a file and grab file name
  $(document).on('change', ".btn-upload :file", function () {
  var input = $(this),
      numFiles = input.get(0).files ? input.get(0).files.length : 1,
      label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [numFiles, label]);
  });

  function findFileInList(list, filename) {
    for (i=0; i < list.length; i++) {
      if (list[i].name === filename) {
          return i;
      }
      else return false;
    }
  }

  //format time for audio player
  function formatTime(seconds) {
    hours = Math.floor((seconds / 3600));
    hours = (hours >= 10) ? minutes : "0" + hours;
    minutes = Math.floor((seconds - (hours * 3600)) / 60);
    minutes = (minutes >= 10) ? minutes : "0" + minutes;
    seconds = Math.floor(seconds - hours * 3600) - (minutes * 60);
    seconds = (seconds >= 10) ? seconds : "0" + seconds;

    if (duration >= hours) {
      return hours + ":" + minutes + ":" + seconds + "/";
    } else {
      return minutes + ":" + seconds + "/";
    }
  }

  function mobileCollapse() {
    $(".nested-tabs .panel-title a").click(function (e) {
      var _href = $(this).attr("href");
      var currentTab = $(this).parents(".panel").find(_href);

      if (currentTab.hasClass("in")) {
        currentTab.removeClass("in");
        currentTab.removeClass("height-open");
        currentTab.addClass("height-close");
      } else {
        currentTab.addClass("in");
        currentTab.removeClass("height-close");
        currentTab.addClass("height-open");
      }

      return false;
    });
  }

  /**
   * Stuff to run immediately upon page load
   */
  svgToPng();

  /**
   * Stuff to run on resize.
   */
  $(window).resize(function () {
    var width = $(window).width();
  
  //** 8/11/16 -- Jasny Bootstrap patch, 
    //** set header to original position if the offcanvas menu
    //** is hidden.
    if(($(".offcanvas.in").size() == 0)) {
        $(".canvas-slid").css("left", "0");
        $(".canvas-slid").css("right", "0");
        $(".canvas-slid").removeClass("canvas-slid");
        // console.log("ran");
    }

    header__jasnyPatch_resize(width);
    openOrCloseActiveItemsInNav(width);

    waitForFinalEvent(function () {
      // Place functions here
    }, 500, "");
  });

  /**
   * Stuff to run after page load is complete.
   */
  $(document).ready(function () {
    // Place functions here 

    // **** Shell adjustment 3.17.16 -- in the range 768px - 915px, 
    // the utility nav overlaps with the favorites menu.
    // These functions will allow us to adjust margin accordingly for ipads and mobile. 
    // (duplicated in the doc.resize above)
    var width = $(window).width();
    if(width >= 753 && width <= 915 && ($('div.toggler').css("display") == "block")) {
      var rangeSlider = 915 - width;
      var newMargin = rangeSlider*(.5);
      $("ul.list-inline.utility__alt").css("margin-right", newMargin);
    }
    else $("ul.list-inline.utility__alt").css("margin-right", "0px");

    // **** ./ Shell adjustments ****//


    //Doing business Navigation -- initialize plus icon to a plus
    $(".local--nav_db .initializePlus").on("click", function(e) {
      $(this).removeClass("initializePlus");
    });

    //Open the menu if an active state is used. Also, adjust height to smooth out functionality afterwards.
    var activeMenuItem = $(".local--nav_db").find("a.active");
    if (activeMenuItem) {
      var parentDivArray = activeMenuItem.parents("div[aria-expanded]");
      parentDivArray.toggleClass("in");
      parentDivArray.css("height", "auto");
      parentDivArray.prev("li").find("div.plus-icon").removeClass("initializePlus");
      parentDivArray.prev("h4").find("div.plus-icon").removeClass("initializePlus");
    }

  //******** Session Inactivity Timer *********//

  var counter = 300;
  var runcount = true;
  var seconds;
  var minutes;
  var reset = false;
  var timeout = false;
    $('#timerModal').on('show.bs.modal', function () {
      counter = 300;
      runcount = true;
      seconds = 0;
      minutes = 5;
      reset = false;
      $('#timerModal p').html("Your session is about to expire.");
      $('#timerModal .btn.reject').html("Reset");
      $(this).find('#counterSeconds').html("00");
      $(this).find('#counterMinutes').html(minutes);
      $('#timerModal h4').removeClass("invisible");
    });

    $('#timerModal').on('shown.bs.modal', function() {
      counter = 300;
      runcount = true;
      seconds;
      minutes = 5;
       reset = false;
      var secondsHTML = $(this).find('#counterSeconds');
      var minutesHTML = $(this).find('#counterMinutes');




      function count(s, m) {
        seconds = counter%60 

        s.text(setSeconds(seconds));
        counter--;

        if (seconds == 59) {
          minutes--;
          m.text(minutes);
        }
        if (counter == 0) {
          runcount = false;
        }
      }

      function setSeconds(s) {
        var t;
        switch (s) {
          case 0: t = "00";
            break;
          case 1: t = "01";
            break;
          case 2: t = "02";
            break;
          case 3: t = "03"
            break;
          case 4: t = "04";
            break;
          case 5: t = "05";
            break;
          case 6: t = "06";
            break;
          case 7: t = "07";
            break;
          case 8: t = "08";
            break;
          case 9: t = "09";
            break;
          default: t = s.toString();
            break;
        }
        return t;
      }

      function postTimer() {
          reset = false;
          timeout = true;
        $('#timerModal p').html("Your session has expired!");
        $('#timerModal h4').addClass("invisible");
        $('#timerModal .btn.reject').attr('id', 'OK');
        $('#timerModal .btn.reject').html("Ok");

      }

      function timer() {
        setTimeout(function () {
          count(secondsHTML, minutesHTML);
             if(reset && !runcount ){
                return;
            }
          else if(runcount) {timer();
                       }
            else {
              postTimer();
              return
            }
        }, 1000);
      }

      count(secondsHTML, minutesHTML);
      timer();

      $('#counterMinutes').text(minutes);

      $('#timerModal').on('hidden.bs.modal', function () {
        runcount = false;
          if(minutes > 0){
              reset = true;
              location.reload();
          }
          else if(minutes == 0){
              if(seconds > 0){
                  reset = true;
              }
          }
          triggerInactive();
      });
    });

$(document).on("click", "#OK", function(e) {
	e.preventDefault();
     var logout= logoutUrl;
     $(location).attr('href',logout);
});
  //******** ./Session Inactivity Timer *********//

    //******** Producer Support Components (Producer and Support View) **********//
    
    /* Clicking button with class "addSupport" adds row to table id="ProdSupport" with input fields.
    The input fields have ids for backend to use although they will probably change them.
    The button id and classnames are changed after the first click so that the button 
    can be used for an alternate purpose on 2nd click.
    */ 
    $("#addSupport").click(function () {
        this.blur()
        var tableRef = document.getElementById('ProdSupport');

        //run if tableRef. Will be null if the function has been run once already.
        if (tableRef) {
          var newRow = tableRef.insertRow(tableRef.rows.length);
          var cell1 = newRow.insertCell(0);
          var cell2 = newRow.insertCell(1);
          var cell3 = newRow.insertCell(2);
          var cell4 = newRow.insertCell(3);
          cell1.innerHTML = '<td><input id="fnameNew" type="text" class="form-control"></td>';
          cell2.innerHTML = '<td><input id="lnameNew" type="text" class="form-control"></td>';
          cell3.innerHTML = '<td><input id="emailNew" type="text" class="form-control"></td>';
          cell4.innerHTML = '<td></td>';

          this.innerHTML = 'Submit New Personnel';
          $('#addSupport').addClass("support");
          $('#addSupport').removeClass("btn-secondary");

          //change button id after
          $('#addSupport').prop("id", "sendValues");

          //changed table id to avoid adding extra rows.
          document.getElementById('ProdSupport').setAttribute("id", "sendValues");
      }
          else return;
    });

    
    var removedPerson = null;

    //This function is used to remove producer support personel from the Producer Support Table.
    //Each removed table row is captured in the variable removedPerson.
    $(".redClose").on("click", function () {
      removedPerson = $(this).closest("tr");

      var tableContent = removedPerson.find("td");

      for (var i=0; i < tableContent.length; i++) {
        tableContent[i] = tableContent[i].innerHTML;
      }

      // Trigger Modal to confirm change request
      $('#ChangeAlertModal').modal('toggle');
      $('#ChangeAlertModal').find(".tableContentPull").html("<strong>Name: </strong>" + tableContent[0] + " " + tableContent[1] + "<br><strong>Email: </strong>" + tableContent[2]);
    });

    // set the removed person to null if we choose not to delete them
    $(".reject").on("click", function() {
      removedPerson = null;
    });

    //Clicking confirm will remove the support personel from the table.
    $('.confirm').on("click", function () {
      removedPerson.remove();
    });


    //Any table rows with the activeSupport class added on page load will have their checkboxes checked.
    $("tr.activeSupport input:radio").attr("checked", "checked"); 

    // This function is used in the SUPPORT VIEW of the Producer Support section
    // It alters class names to change table styling.
    $('[name="chooseProducerToSupport"]').on("click", function () {
      var thisProducer = $(this);
      var currentClass = thisProducer.closest("tr").attr("class");
      var currentCheckbox = $(this).prop("checked");

      //if a different producer is currently active, store a reference.
      lastActive = $(".activeSupport");

      // Trigger Modal to confirm change request
      $('#ChangeAlertModal').modal('toggle');

      //if producer isn't currently the activeSupport, make them active support.
      //Deactivate the whichever was previously active, if any.
      if (!thisProducer.closest("tr").hasClass("activeSupport")){
        $('[name="chooseProducerToSupport"]').closest("tr").addClass("text-muted");
        $('[name="chooseProducerToSupport"]').closest("tr").removeClass("activeSupport");
        thisProducer.closest("tr").removeClass("text-muted");
        thisProducer.closest("tr").addClass("activeSupport");
      }

      //If producer is currently the activeSupport, deactivate them.
      else {
        thisProducer.closest("tr").removeClass("activeSupport");
        thisProducer.closest("tr").addClass("text-muted");
        thisProducer.find(':radio').prop("checked", false);
      }

      //if user rejects these changes from modal, reset the table.
      $('.reject').on("click", function () {
        thisProducer.closest("tr").attr("class", currentClass);
        thisProducer.prop("checked", currentCheckbox);
        if(lastActive) {
          lastActive.attr("class", "activeSupport");
          lastActive.find(':radio').prop("checked", "checked");
          thisProducer.find(':radio').prop("checked", false);
        }
        if (lastActive.length === 0) {
          thisProducer.attr("checked", false);
        }
      }); 
    });
    //***** End of Producer Support *****//

    //Launch modal when clicking button to change email address
    $('.updateEmail').on("click", function () {
      $('#ChangeEmailModal').modal('toggle');
    });

    //Launch modal when clicking button to change email address
    $('.updateYourInformation').on("click", function () {
      $('#ChangeYourInformationModal').modal('toggle');
    });

    //Launch modal when clicking button to change email address
    $('.changePassword').on("click", function () {
      $('#ChangeYourPasswordModal').modal('toggle');
    });

    //** Launch success alert on changing site preferences within AEM **//
    $('.updateProfile').on("click", function () {
     // console.log($(this).prop("checked"));
      if($(this).attr("checked") == "checked") return;
      $('.alert-success').toggleClass("in");
      window.setTimeout(function () {
        $('.alert-success').toggleClass("in");
      }, 3000);

      /*Toggle modal, if in the settings modal*/
      $(this).closest('#setting-modal').modal('toggle');
      });

    //** On clicking .confirmEmail button, change confirmation status and remove button **//
    $('button.confirmEmail').on("click", function () {
      $('.confirmEmail').removeClass("red").addClass("green").html("Confirmed");
      setTimeout(function () {$('button.confirmEmail').addClass("displayNone")}, 450)
      });
    //*********** /.My Profile **********//


    //***** Upload Documents Functionality *****//

    $(".btn-upload :file").on('fileselect', function(event, numFiles, label) {
      var cancelcell = $(this).closest("tr").find("#removeDoc");
      var input = $(this).parents("td").find(":text"),
          log = numFiles > 1 ? numFiles + 'files selected' : label;
          input.val(log);
          input.addClass("inputReceived");
      cancelcell.html('<a href="javascript:void(0)"><span class="redRemove glyphicon glyphicon-remove"></span></a>');
    //  console.log("on upload, file input is: ", $(this).closest("tr").find(":file"));
           
      // console.log($(this)[0].files);

    });

    $(document).on("click", "span.redRemove", function () {
      var thisTextInput = $(this).closest("tr").find(":text");
      var thisFileInput = $(this).closest("tr").find(":file");
      thisFileInput.val("");
      thisTextInput.val("");
     //   console.log("after click, file input is: ", $(this).closest("tr").find(":file"));
     //   console.log("after click, text input is: ", $(this).closest("tr").find(":text"));
      $(this).closest("#removeDoc").html("");
      thisTextInput.removeClass("inputReceived");
      
      // console.log(thisFileInput[0].files);
    });
    

    //validate upload modal for valid file types
    $(".validate-file").change(function(e) {
      e.preventDefault();
      //these files are not allowed
      if(!TestFileType(this.form.uploadfile.value, ['EXE','EXE', 'exe', 'mps', 'MPS', 'vbs', 'VBS', 'avi', 'AVI', 'mpg', 'MPG', 'mpeg', 'MPEG', 'bat', 'BAT', 'scr', 'SCR', 'asf', 'ASF', 'mp3', 'MP3', 'eml', 'EML', 'pif', 'PIF', 'scp', 'SCP', 'shs', 'SHS', 'swf', 'SWF'])){
        return false;
      }
    });

    function TestFileType( fileName, fileTypes ) {
      if (!fileName) return;

      dots = fileName.split(".")

      //get the part AFTER the LAST period.
      fileType = "." + dots[dots.length-1];

      // chosen extention is not allowed 
      if (fileTypes.join(".").indexOf(fileType) != -1) {
       $("#file-type").addClass('show');
       window.setTimeout(function () {$('#file-type').removeClass('show')}, 3000);
        return false;
      } else {
        //validated
        return true;
      }
    }

    //* Clear everything when user selects Clear instead of Submit. -- Main Page
    $("[type='reset'].uploads").on('click', function() {
      var allFileInputs = $("table.upload :file");
      var allTextInputs = $("table.upload :text");
      var allCancelCells = $("table.upload #removeDoc");
      var allCheckBoxes = $("table.upload :checkbox");

      allFileInputs.val("");
      allTextInputs.val("");
      allTextInputs.removeClass("inputReceived");
      allCancelCells.html("");
      allCheckBoxes.prop("checked", false);
    });
    //************ /.Upload docs modal **************//

    //icon modal code
    $(".gear-icon, .mail-icon, .customize-icon").on("click", function () {
      //$(".offcanvas-menu").offcanvas('hide');
      $(".offcanvas-clone").remove();
    });

    $('#customize-modal').on('shown.bs.modal', function () {
      fakewaffle.checkResize();
    })

    //show locations based on state select menu
    $('.group').hide();
    $('#option1').show();
    $('#locations').change(function () {
      $('.group').hide();
      $('#' + $(this).val()).show();
    })

    //prevent a location hash from bootstrap collapse
    $('[data-parent="#accordion"]').on("click", function (e) {
      e.preventDefault();
    });
  
    // Tab toggles
    $('[data-toggle="toggle-group"]').on('click', function(e) {
      e.preventDefault();
      var tgt = $(this).attr('data-target');
      $('.toggle-group.active').removeClass('active');
      $(tgt).addClass('active');
      $('[data-toggle="toggle-group"].active').removeClass('active');
      $(this).addClass('active');
      var scrollTop = $(window).scrollTop();      
      appendHashes(tgt, 'group')
      $(window).scrollTop(scrollTop);
    });

    //mobile collapse accordian fix
    mobileCollapse();


    //************* Sales Tools and Results Menu: Filter Selecting *************//
    //run on clicking any filter in the ST&R menu
    $(".local--nav__alt input[type='checkbox']").click(function () {

      // Get the data-target value from ancestor div. This is the id of div containing all filters that are 
      // children of $(this) filter.
      var dataTargetStore = $(this).parent().find("div.checkbox").attr("data-target");
      // Get id of div containing this filter.
      var panelContainingThis = $(this).closest("div.panel-collapse").attr("id");

      //Find the checkbox input for parent filter and uncheck.
      $('[data-target="#' + panelContainingThis + '"]').parent().find("input[type='checkbox']").prop("checked", false);

      // use id to uncheck checkboxes that appear as children of this filter in menu.
      $(dataTargetStore).find("input[type='checkbox']").prop('checked', false);
    });

    //clear checkboxes
    $(".clear-btn").click(function () {
      $(this).parent().find("input[type='checkbox']").attr("checked", false);
    });
    //************** ./Sales Tools and Results Menu: Filter Selecting **********//

    //remove padding from filter menu items
    $(".panel-title").parent("li").prev().css("margin-bottom", "0");

    $(".panel-title").parent("li").css("margin-bottom", "0");

    //fixed header resizing
    /*$(window).scroll(function () {
      var scroll = $(window).scrollTop();

      if (scroll >= 100 && !($("body").hasClass("canvas-slid"))) {
        setHeader().addClass('small');
      } else {
        setHeader().removeClass("small");
      }
    });*/

    //custom Audio Player (written in vanilla js because jquery seemed to have issues with HTML Audio)
    if ($("audio").length > 0) {
      var podcast = document.getElementById("audio");
      var ellapsed = document.querySelector(".ellapsed");
      var playhead = document.getElementById("ellapsed-amount");
      var controls = document.getElementById("controls");
      var audioComponents = document.querySelector(".audio-components");
      var duration;

      //HTML5 Audio amount og progress event
      //Used to get the buffer bar (gray bar)
      podcast.addEventListener('progress', function () {
        var bufferedEnd = podcast.buffered.end(podcast.buffered.length - 1);
        duration = podcast.duration;
        if (duration > 0) {
          document.getElementById('buffered-amount').style.width = ((bufferedEnd / duration) * 100) + "%";
        }
      });

      //HTML5 Audio time event
      //Used to get the ellapsed amount of time bar (orange bar)
      podcast.addEventListener('timeupdate', function () {
        duration = podcast.duration;
        if (duration > 0) {
          document.getElementById('ellapsed-amount').style.width = ((podcast.currentTime / duration) * 100) + "%";
        }
        document.getElementById("duration").innerHTML = formatTime(podcast.currentTime);
      });

      //handles the click on the ellapsed bar
      //calls moveMe function and sets current time
      ellapsed.addEventListener('click', function (event) {
        moveMe(event);
        podcast.currentTime = duration * clickPercent(event);
      }, false);

      //Returns the position clicked on the ellapse bar
      //Using the offsetleft of the ellapsed bar, the x of the page, and the width of the ellpased bar
      function clickPercent(e) {
        return (e.pageX - ellapsed.offsetLeft) / ellapsed.offsetWidth;
      }

      //Gathers the new width of the bar based on the click information based in
      //Moves the playhead (ellapsed bar)
      function moveMe(e) {
        var newWidth = e.pageX - ellapsed.offsetLeft;
        if (newWidth >= 0 && newWidth <= ellapsed.offsetWidth) {
          playhead.style.width = newWidth + "px";
        }
      }

      podcast.addEventListener("canplaythrough", function () {
        duration = podcast.duration;
      }, false);

      //Sets up all the controls (play, pause, and volume)
      controls.addEventListener("click", function () {
        if (podcast.paused) {
          podcast.play();
          controls.className = "";
          controls.className = "pause";
          audioComponents.className = "audio-components";
          audioComponents.className = "audio-components visible";
          if (window.innerWidth > 767) {
            document.querySelector(".podcast-play").style.opacity = "0";
            document.querySelector(".podcast-name").style.bottom = "25px";
          }
        } else {
          podcast.pause();
          controls.className = "";
          controls.className = "play";
          audioComponents.className = "audio-components";
          audioComponents.className = "audio-components invisible";
          if (window.innerWidth > 767) {
            document.querySelector(".podcast-play").style.opacity = "1";
            document.querySelector(".podcast-name").style.bottom = "0";
          }
        }
      }, false);

      var volume = document.querySelector(".volume");
      var volSlider = document.getElementById("vol");
      podcast.volume = volSlider.value;

      volSlider.addEventListener("change", function () {
        podcast.volume = volSlider.value;

        if (volSlider.value <= .5 && volSlider.value > 0) {
          volume.className = "volume";
          volume.className = "volume volume-low";
        } else if (volSlider.value > .5) {
          volume.className = "volume";
          volume.className = "volume volume-high";
        } else {
          volume.className = "volume";
          volume.className = "volume volume-mute";
        }


        // gradient for mozilla firefox volume slider (JHAM.html)
        var mozVal = (($(this).val() - $(this).attr('min')) / ($(this).attr('max') - $(this).attr('min')) * 100);

        $(this).css('background-image',
          '-moz-linear-gradient(left, #df6021 ' + mozVal + '%, #ffffff ' + mozVal + '%)'
        );
      }, false);

      //sets the class to toggle the visibility of the volume slider
      volume.addEventListener("mouseover", function () {
        volSlider.className = "visible";
      }, false);

      volume.addEventListener("mouseleave", function () {
        volSlider.className = "invisible";
      }, false);

    }
    /* End of custom HTML 5 Audio Player*/

    //search icon to show search input on xs screens
    $(".mobile-search").click(function () {
      $(".hidden-search").toggleClass("show");
    });

  $('[data-toggle=tooltip]').hover(function(){
        // on mouseenter
        $(this).tooltip('show');
    }, function(){
        // on mouseleave
        $(this).tooltip('hide');
    });

  //****** Favoriting ******//
  //On click, this code reveals a tooltip and changes the text within the .favoritesLabel
  //span element. Also toggles the control's active state via adding the class "favorited"
 $('[data-toggle=favoritesTooltip]').click(function () {
     if ($(this).hasClass("favorited") == 0 && $(".favoritesLabel").text() === 'Favorite This Page') {
      if (getCookie("nofavtt") == null) {
        $(this).attr("data-toggle", 'tooltip');
        $(this).attr("title", '<strong>This page has been added to your favorites!</strong><br><p>You can access favorites by clicking on the “star icon” anchored to the top-right of the page.</p><div class="checkbox"><label><input type="checkbox" id="noFavTT" value="">Dont remind me</label></div>');
          $(this).attr("data-html", true);
          $(this).attr("data-delay", 1000);
          $(this).tooltip('show');
          $(this).on('shown.bs.tooltip', function () {
            $(".favoritesLabel").html("Unfavorite This Page");
            $(this).toggleClass("favorited");
            $('#noFavTT').change(function() {
              //console.log("Setting cookie");
              var exdays = 14;
              var cname = "nofavtt";
              var cvalue= "true";
              if(this.checked) {
                   var d = new Date();
                   d.setTime(d.getTime() + (exdays*24*60*60*1000));
                   var expires = "expires="+d.toUTCString();
                   document.cookie = cname + "=" + cvalue + "; " + expires +";" + "path=/";
                } else {
                  document.cookie = cname+"=; expires=Thu, 01 Jan 1970 00:00:01 GMT;";
                }
            });
          });
          $(this).on('hidden.bs.tooltip', function () {
              $(this).tooltip('destroy');
              this.blur()
          });
      } else {
        $(".favoritesLabel").html("Unfavorite This Page");
          $(this).toggleClass("favorited");
      }
      addFavorite(document.title);

    } else {
    refreshFavorites(location.href.split('?')[0]);
      $(this).attr("data-toggle", "favoritesTooltip");
      $(".favoritesLabel").html("Favorite This Page");
      $(this).toggleClass("favorited");
      this.blur()
    }
  });

//****** Responsive Table  ******//

// Updates data attributes to headers so on mobile fields are more readable
// and avoid the need to scroll horizontally


  var headertext = [],
  headers = document.querySelectorAll("#mastertable th"),
  tablerows = document.querySelectorAll("#mastertable th"),
  tablebody = document.querySelector("#mastertable tbody");

  for(var i = 0; i < headers.length; i++) {
    var current = headers[i];
    headertext.push(current.textContent.replace(/\r?\n|\r/,""));
  }
      if (tablebody !== null) { 
        for (var i = 0, row; row = tablebody.rows[i]; i++) {
          for (var j = 0, col; col = row.cells[j]; j++) {
            col.setAttribute("data-th", headertext[j]);
          } 
        }
  }
  /*if (navigator.userAgent.indexOf('Safari') != -1)  { 
      $("#mastertable > tbody >tr ").find("td:first").addClass("mobile-title");
      $("#mastertable > tbody >tr ").find("td:nth-child(2)").parent("tr").append("<td class='mobile-type' >Type</td>");
      $("#mastertable >tbody >tr ").find("td:nth-child(3)").parent("tr").append("<td class='mobile-format' >Format</td>");
      $("#mastertable >tbody >tr ").find("td:nth-child(4)").parent("tr").append("<td class='mobile-date' >Last </br> Updated</td>");*/



 /* }else{
       if (tablebody !== null) { 
        for (var i = 0, row; row = tablebody.rows[i]; i++) {
          for (var j = 0, col; col = row.cells[j]; j++) {
            col.setAttribute("data-th", headertext[j]);
          } 
        }
  }
  }*/
/*function getMobileOperatingSystem() {
  var userAgent = navigator.userAgent || navigator.vendor || window.opera;

      // Windows Phone must come first because its UA also contains "Android"
    if (/windows phone/i.test(userAgent)) {
        if (tablebody !== null) { 
        for (var i = 0, row; row = tablebody.rows[i]; i++) {
          for (var j = 0, col; col = row.cells[j]; j++) {
            col.setAttribute("data-th", headertext[j]);
          } 
        }
  }

    }

    if (/android/i.test(userAgent)) {
        if (tablebody !== null) { 
        for (var i = 0, row; row = tablebody.rows[i]; i++) {
          for (var j = 0, col; col = row.cells[j]; j++) {
            col.setAttribute("data-th", headertext[j]);
          } 
        }
  }

    }

    // iOS detection from: http://stackoverflow.com/a/9039885/177710
    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      $("#mastertable > tbody >tr ").find("td:first").addClass("mobile-title");
      $("#mastertable > tbody >tr ").find("td:nth-child(2)").parent("tr").append("<td class='mobile-type' >Type</td>");
      $("#mastertable >tbody >tr ").find("td:nth-child(3)").parent("tr").append("<td class='mobile-format' >Format</td>");
      $("#mastertable >tbody >tr ").find("td:nth-child(4)").parent("tr").append("<td class='mobile-date' >Last </br> Updated</td>");

        /*if (tablebody !== null) { 
        for (var i = 0, row; row = tablebody.rows[i]; i++) {
          for (var j = 0, col; col = row.cells[j]; j++) {
            col.setAttribute("data-th", headertext[j]);
          } 
        }
  }


    }


}
 getMobileOperatingSystem();*/

    //datatable master table

    //
    // Removed due to table being rebuilt without plugin
    // 

    // $('#mastertable').dataTable({
    //   "order": [[3, "desc"]]
    // });

  });
  //side out favorites panel
  $(".toggler").click(function () {
    $('#slidepanel').toggleClass('open-panel');
    $('.profile-border').toggleClass('moveleft');
    $('.toggler').toggleClass('moveleft');
  });

  //clear all 
  $(".clear-btn").click(function () {
    $('input:checkbox').removeAttr('checked');
  });
  //update button on my profile layout
  $(".changeInfoLink").click(function () {
     $('.changeInfo__new').addClass('show');
     $('.changeInfo').addClass('hide');
  });


   
//login form validation show alert if empty fields
 $('form[name="register"]').on("submit", function (e) {
        // Find all <form>s with the name "register", and bind a "submit" event handler
        // Find the <input /> element with the name "username"
        var username = $(this).find('input[name="username"]');
        var password = $(this).find('input[name="password"]');
        
        if ($.trim(username.val()) === "" || $.trim(password.val()) === "") {
            // If its value is empty
            e.preventDefault();    // Stop the form from submitting
            $("#UseridPasswordAlert").slideDown(400);    // Show the Alert
        } else {
            return;
        }
    });
    
    $(".alert").find(".close").on("click", function (e) {
        // Find all elements with the "alert" class, get all descendant elements with the class "close", and bind a "click" event handler
        e.stopPropagation();    // Don't allow the click to bubble up the DOM
        e.preventDefault();    // Don't let any default functionality occur (in case it's a link)
        $(this).closest(".alert").slideUp(400);    // Hide this specific Alert
    });

  /**
   * Helper function to delay firing resize events until the user actually
   * stops resizing their browser.
   */
  var waitForFinalEvent = (function () {
    var timers = {};
    return function (callback, ms, uniqueId) {
      if (!uniqueId) {
        uniqueId = "Don't call this twice without a uniqueId";
      }
      if (timers[uniqueId]) {
        clearTimeout(timers[uniqueId]);
      }
      timers[uniqueId] = setTimeout(callback, ms);
    };
  })();
// ******** Form group slideouts 7.1.16  -- 
  //  When a form input with the class .form-group-slideout is focused, a
  //  corresponding "drawer" of content will appear to slideout from underneath the field
  //
  //  ** Purpose of this function: Show extra content necessary for a particular form
  //  
  $(".form-group input.form-slideout-toggle").on("focus blur", function() {
    if($(this).attr("type") != "select") {
      $(this).closest(".form-group").find(".row .form-group-slideout").toggleClass("in");
    }
  });
  $(".form-group select.form-slideout-toggle").on("change", function() {
    var selected = $(this).find(":selected");
    var slideouts = selected.closest(".form-group").find(".row .form-group-slideout");
    slideouts.each(function() {
      if($(this).attr("slideout-content-id") != selected.attr("slideout-content-id")) $(this).removeClass("in");
      if($(this).attr("slideout-content-id") == selected.attr("slideout-content-id")) $(this).toggleClass("in");
    });
  });

              /***                         ***/
              /*** SITE NAVIGATION PATCHES ***/
              /***                         ***/

    //************ Mobile Menu fixes *************//
    /* Requirement: 
    /*    ~ 1.  When a user clicks an item in menu, that page will open.
    /*    ~ 2.  When the user opens the menu again, that page will be active (backend logic) 
    /*          & it's subnav (if it has one), will be open (frontend logic)
    /*          will be displayed.
     */

    //On Mobile, automatically toggle active menu items
    openOrCloseActiveItemsInNav($(window).width())

    //fix mobile menu collapsing
    $(".dropdown").on("click", function (e) {
      e.stopPropagation();
    });

    $(".dropdown li").on("click", function (e) {
      e.stopPropagation();
    });

    $("li.dropdown-submenu").on("click", function (e) {
      e.stopPropagation();
    });

    $(".dropdown-submenu li").on("click", function (e) {
      e.stopPropagation();
    });
    //************** ./Mobile menu fixes ***************//



    // ********* Major Menu Patch 7.8.16 **********
    // **** The menu wasn't working on ipads at all
    // ** 
    // ** designed to allow two clicks, one to open a submenu, second to visit the
    // **** Still isn't functioning on small/xs screens

    if ($(window).width() > 767) {
      $("ul.subnav li.dropdown a.dropdown-toggle").bind("touchend", function(e) {
        e.preventDefault();
        // e.stopPropagation();

        //store the submenu that will be opened or closed
        var thisClickSubMenu = $(this).parent().children(".dropdown-menu"); 
     //   console.log(thisClickSubMenu);
        
        //store all top level menu "channels" for reference
        var MenuChannels = $(this).closest("ul.subnav").find("li.dropdown");

        //store the menu "channel" this touch is inside
        var ActiveChannel = $(this).closest("li.dropdown");

        //Check if desired submenu is already open. 
        //If it is, Redirect user window.location.
        if(!thisClickSubMenu.hasClass("open")) {
          thisClickSubMenu.addClass("open");
        } else window.location.assign($(this).attr("href"));

        //if there is no submenu, then redirect user.
        if(!thisClickSubMenu) window.location.assign($(this).attr("href"));

        //close all menuchannels except for the active one specified by user touch.
        MenuChannels.splice($.inArray(ActiveChannel[0], MenuChannels), 1);
        MenuChannels.find(".dropdown-menu").removeClass("open");
      });

      $(document).bind("touchend", function(e) {
        // e.preventDefault();
          var parentClassName = $(e.target).parent().attr("class");
          if(!(parentClassName == "dropdown" || parentClassName == "dropdown-submenu")) {

          var AllMenuDropdowns = $("li.dropdown").find(".dropdown-menu");
          var AllDropdowns = $(".nav li.dropdown");

          AllMenuDropdowns.removeClass("open");
          AllDropdowns.removeClass("open");
        }
      });

      $("ul.subnav li.dropdown a.dropdown-toggle").on("click", function(e) {
        e.stopPropagation();
      });
    }

    header__jasnyPatch_onload();



              /***                                ***/
              /*** END OF SITE NAVIGATION PATCHES ***/
              /***                                ***/



    //8.15.16 -- Alphabetizing contents of "i" toggles for ST&R results page
    if ($('#mastertable.table-library')) {
      $('#mastertable.table-library .glyphicon-info-sign').each(function() {
        var htmlReference       = $(this);
        var stringToAlphabetize = htmlReference.attr("data-content");
        var results             = [];

        if (typeof(stringToAlphabetize) === "string") {
          
          results         = stringToAlphabetize.match(/([A-Za-z]+)/g);
          results         = results.sort();
          var states      = '';

          // console.log(results);

          //build the string to use in html
          for(i=0; i<results.length; i++) {
            if(i <  (results.length - 2))  states += results[i] + ", ";
            if(i == (results.length - 1))  states += "and " + results[i];
          }

          htmlReference.attr("data-content", states);
        }
      });
    }

    // ******** Form group helpovers (help using popovers) -- 
    //  When a form input with the class .helpover-content is focused, a
    //  corresponding popover of content will appear above (or below if needed for visibility)
    //
    //  ** Purpose of this function: Show extra content necessary for a particular form, alternative to slideouts
    //  
    $(".form-group .form-helpover-toggle").on("focus", function() {
        showHelpover(this);
    });
    $(".form-group .form-helpover-toggle").on("blur", function() {
        hideHelpover(this);
    });
   
    function showHelpover(el) {
      var $el = $(el);
      var formgroup = $el.closest(".form-group");
      var helpovers = formgroup.find(".helpover-content");
     
      if ($el.is("select")) {
        var selected = $el.find(":selected");
        var id = selected.attr("id");

        // If explicit id, match #help-text-id or #id (for legacy compatibility with slideouts), else look for class "default"
        var selector = id? "#help-text-" + id +", #" + id : ".default";
        helpovers = helpovers.filter(selector);
      }

      var helpover = helpovers.first();

      // If no matches, don't display popover
      if (helpover.length == 0) {
        return;
      }

      function getTitle(el) {
        var title = formgroup.find("label").html();
        return title || "";
      }

      var html = "<h3 class='popover-title'>" + getTitle(el) + "</h3>" + (helpover.html() || "");

      $el.popover({
        html: true,
        content: html,
        template: '<div class="helpover popover" role="tooltip"><div class="arrow"></div><div class="popover-content"></div></div>',
        title: getTitle,
        placement: 'auto top',
        trigger: 'manual'
      });
      // $el.data('bs.popover').tip().addClass('helpover');
      $el.popover('show');
    }
   
    function hideHelpover(el) {
      $(el).popover('destroy');
    }
   
    $(".form-group select.form-helpover-toggle").on("change", function() {
      $.data(this, "changing", true); // Provide hint that the helpover is not going away, just being replaced.
      hideHelpover(this);
      showHelpover(this);
      $.data(this, "changing", null);
    });


}(jQuery));


            /***                   ***/
            /*** HELPERS / PATCHES ***/
            /***                   ***/

function header__jasnyPatch_onload() {
  /*
   * 9.12.16 -- Patching the header to work with jasny offcanvas
   * Patching the fixed header. Header can't be fixed with the off-canvas nav inside it...
   * Would have to rebuild the markup otherwise, no clean solution unfortunately.
   * Use jQuery outerHeight() to fetch rendered height of the header at that moment.
   */
  var nav__header = setHeader();
  var nav__header_next = getNext_DisplayBlock(nav__header);
  var bootstrapReference_Display = $(".hidden-xs:not(.hidden-sm)").first().css("display");
  // console.log("nav header next: ",nav__header_next);
  // console.log("nav header: ",nav__header)

  bootstrapBreakRef__patch($(window).width(), bootstrapReference_Display, 
    { show: function() {
      // console.log("* btstrp patch onload: show")
      header__jasnyPatch__setShowStyles(nav__header, nav__header_next);
    }, hide: function() {
      // console.log("* btstrp patch onload: hide")
      header__jasnyPatch__setHiddenStyles(nav__header, nav__header_next);
    }
  });

  // When offcanvas is triggered to show...
  nav__header.on("show.bs.offcanvas", function(event) {
    var nav__header = setHeader();
    $('body, html').addClass('jh-menu-open');

    var nav__header_next = getNext_DisplayBlock(nav__header);
    header__jasnyPatch__setShowStyles(nav__header, nav__header_next)
  })

  // When offcanvas is fully hidden...
  nav__header.on("hidden.bs.offcanvas", function(event) {
    var nav__header = setHeader();
    $('body, html').removeClass('jh-menu-open');

    var nav__header_next = getNext_DisplayBlock(nav__header);
    header__jasnyPatch__setHiddenStyles(nav__header, nav__header_next)
  })

  // fix for user scrolling as well
  $(window).scroll(function() {
    header__jasnyPatch_resize($(window).width())
    if($(window).scrollTop() < 0) nav__header_next.css({ marginTop: "100px" });
  })
}


function header__jasnyPatch_resize(width) {
  /*
   * 9.12.16 -- Continuation of patching the header to work with jasny offcanvas.
   * Patch needs to encompass window resizing events in addition to 
   * the bs.offcanvas events.

   * 9.26.16 -- Patch for odd behavior on firefox/IE. Let the bootstrap breakpoints in 
   * rendered HTML lead responsive behavior in events where width reported to JS is not 
   * rendered in accordance with CSS widths and breakpoints.
   */
 /* var nav__header = setHeader();
  var nav__header_next = getNext_DisplayBlock(nav__header);
  var bootstrapBreakRef_Display = $(".hidden-xs:not(.hidden-sm)").first().css("display");

  bootstrapBreakRef__patch(width, bootstrapBreakRef_Display, 
    { show: function() {
      // console.log("* resize: show")
      header__jasnyPatch__setShowStyles(nav__header, nav__header_next)
    }, hide: function() {
      // console.log("* resize: hide")
      header__jasnyPatch__setHiddenStyles(nav__header, nav__header_next)
    }
  });*/
  
}

// recursive function to find elem based on css display attribute
function getNext_DisplayBlock(elem) {
  var next = elem.next();
  var display = next.css("display");

  if (display == "block") {
    // console.log("getNext_DisplayBlock() returns ", next);
    return next;
  }
  else return getNext_DisplayBlock(next);
}

function header__jasnyPatch__setHiddenStyles(nav__header, nav__header_next) {
  // console.log("set hidden styles")
  var height = nav__header.outerHeight();

  //nav__header.css("position", "fixed");
  nav__header_next.css({marginTop: height + "px"});
}

function header__jasnyPatch__setShowStyles(nav__header, nav__header_next) {
  // console.log("set show styles")
  //nav__header.css("position", "static");  
  nav__header_next.css({marginTop: "0px"});
}




/*** Use this functionality to add items from the utility nav to the mobile nav
 *  ~ The class .util__mobile_item will "choose" which items should be moved from the utility
 *    nav to the mobile navg
 *
 */
function utilityNavBuilder() {
 // console.log("** Running utilityNavBuilder()");

  var mainNav                 = $(".offcanvas.offcanvas-menu.navbar-offcanvas");
  var utilityNav              = $("ul.list-inline.utility__alt ");
  var mobile_utilityNavItems  = utilityNav.find("li a.util__mobile_item");
  var mobile_SubNav           = mainNav.find("ul.mobile-utility-list");
  // utilityNav.clone(true).appendTo("");

  // check if there are items to move
  //console.log("\n Check 1: mobile utility nav items to move: ", mobile_utilityNavItems.size(), mobile_utilityNavItems);
  if (mobile_utilityNavItems.size() > 0) {

    // check if the mobile_SubNav exists within the menu, otherwise build it.
   // console.log("\n Check 2: mobile subnav: ", mobile_SubNav)
    if (mobile_SubNav.size() > 0) {
      //  console.log("mobile_SubNav exists, continuing: ", mobile_SubNav);
        iterateUtilityItems(mobile_utilityNavItems, mobile_subNav);
    }
    else {
    //  console.log("\n mobile_SubNav doesn't exist, building it");
      mobile_subNav = buildUtilitySubNav();
      iterateUtilityItems(mobile_utilityNavItems, mobile_subNav);
    }
  } else {
   // console.log("\n check 1: false, no mobile utility nav items to move \n ****")
    return;
  }


      /**                                      **/
      /** internal utilityNavBuilder functions **/
      /**                                      **/
  function buildUtilitySubNav() {
   // console.log("\n\n** Running buildUtilitySubNav()")
    var nav       = $(".offcanvas.offcanvas-menu.navbar-offcanvas");
    var hr_elem   = '<hr class="hidden-sm hidden-md hidden-lg">';
    var ul_elem   = '<ul class="mobile-utility-list hidden-sm hidden-md hidden-lg"></div>'

    // ul_elem.setAttribute("style", "")

    nav.append(hr_elem);
    nav.append(ul_elem);

    // console.log(nav);

    return nav.find(".mobile-utility-list");
  }


  function iterateUtilityItems(mobile_utilityNavItems, mobile_SubNav){    
    /*
     *  Get the utility ul and add each nav item to it
     */
    //console.log("\n** Running iterateUtilityItems()");

    mobile_utilityNavItems.each(function(i, item) {
      var li        = item.parentNode;
      var nItem     = li.cloneNode(true);

      mobile_SubNav.append(nItem);

      // console.log("\n **** cloned ", nItem, " to ", mobile_SubNav);
    });
    //console.log("\n successfully finished cloning mobile nav items \n****")
  }

}

function setHeader() {
  if ($(".header").size() > 0) return $(".header")
  if ($(".header__tight").size() > 0) return $(".header__tight")
}

/*My Business Life/LTC tabs - clicking menu items will change active states of parent li elements
  $(".inpage--nav__mybusiness").find("a").on("click", function () {
    $(".inpage--nav__mybusiness").find("li").removeClass("active");
    $(this).parent("li").addClass("active");
   $("div.tabpanel ul.list-inline li.active a").each(function(){
  $($("div.tabpanel ul.list-inline li.active a").attr('href')).find("iframe").attr("src", $($(this).attr('href')).find("iframe").attr("src1"));
}); 

  });*/


/*****************************************************************Issue 2183 Fix*********************************************************************************************/   


//Here we hide the backgrounf plus and Minus icon and dynamically attach a plus and minus Icon

  $('.subnav li.dropdown a.dropdown-toggle').css('background-image','none'); 
  $('.subnav li.dropdown a').css('background-image','none');


//Here we append the div with the icon for first level menu

   $('.subnav li.dropdown').after('<div class="Plus-Icon-mobile hidden-lg hidden-md hidden-sm">' +
    '<img class="icon icon-plus icon-show icon-plus-active " src="/etc.clientlibs/settings/wcm/designs/jhmn/clientlib-head/resources/img/plus.png" alt="plus-logo">' +
     '<img class="icon icon-minus icon-minus-active" src="/etc.clientlibs/settings/wcm/designs/jhmn/clientlib-head/resources/img/minus.png" alt="Minus-logo">' +
     '</div>' +
     '<div class="clear hidden-lg hidden-md hidden-sm">' +

     '</div>');

//Here we append the div with the icon for second level menu

      $('ul.dropdown-menu > li.dropdown-submenu').after('<div class="Plus-Icon-mobile hidden-lg hidden-md hidden-sm">' +
     '<img class="icon icon-plus-submenu icon-show " src="/etc.clientlibs/settings/wcm/designs/jhmn/clientlib-head/resources/img/plus.png" alt="Plus-logo">' +
     '<img class="icon icon-minus-submenu icon-minus-active" src="/etc.clientlibs/settings/wcm/designs/jhmn/clientlib-head/resources/img/minus.png" alt="Minus-logo">' +

   '</div>' +
     '<div class="clear hidden-lg hidden-md hidden-sm">' +

     '</div>');

/**********************************On click of plus Icon the sub-menu will open**********************/

  $('div.Plus-Icon-mobile').on('click',function(){



    $(this).prev("li").children('ul.dropdown-menu').toggleClass("open");
  $(this).prev().addClass("check-active-prev");
    $(this).prev("li").siblings("li").children("a.active").parent("li").next().find( ".icon-minus").removeClass("icon-show");
    $(this).prev("li").siblings("li").children("a.active").parent("li").next().find( ".icon-plus").addClass("icon-show");



            if($(this).find(".icon-plus").hasClass("icon-show")){

        $('.check-active-prev').next().find(".icon-plus").addClass("icon-show");
                $('.check-active-prev').next().find( ".icon-minus").removeClass("icon-show");
                $('.check-active-prev').children("a.dropdown-toggle").removeClass("active-icon");
                }

                if($(this).find(".icon-plus").hasClass("icon-show")){

                   $(this).find(".icon-plus").removeClass("icon-show");
                   $(this).find( ".icon-minus").addClass("icon-show");
                   $(this).prev("li").children('ul.dropdown-menu').children("li").children("ul.dropdown-menu.open").addClass("open");

        
                }else{
                   $(this).find(".icon-plus").addClass("icon-show");
                   $(this).find(".icon-minus").removeClass("icon-show");
                   $(this).prev("li").children('ul.dropdown-menu').children("li").children("ul.dropdown-menu.open").removeClass("open");
                }

            if($(this).find(".icon-plus-submenu").hasClass("icon-show")){
        $(this).siblings("li.dropdown-submenu").children("a").removeClass("active-icon");
                   $(this).find(".icon-plus-submenu").removeClass("icon-show");
                   $(this).find( ".icon-minus-submenu").addClass("icon-show");

                }else{
                   $(this).find(".icon-plus-submenu").addClass("icon-show");
                   $(this).find(".icon-minus-submenu").removeClass("icon-show");

                }



//checking for the first level link

       if($(this).siblings("li").children('ul.dropdown-menu').hasClass("open")){

            $(".icon-plus-submenu").addClass("icon-show");
            $(".icon-minus-submenu").removeClass("icon-show");
            $(this).prev("li").siblings("li").children('ul.dropdown-menu').removeClass("open");
            $(this).find(".icon-plus-submenu").removeClass("icon-show");
            $(this).find( ".icon-minus-submenu").addClass("icon-show");
            $(this).find(".icon-plus").removeClass("icon-show");
            $(this).find( ".icon-minus").addClass("icon-show");
        }

});

$(".dropdown").on("click", function (e) {

         e.stopPropagation();

 });



/*******************code to give the mobile patches**********************/


function openOrCloseActiveItemsInNav(width) {
  // 9.26.16 -- Patch for odd behavior on firefox. Let the bootstrap breakpoints in 
  // rendered HTML lead responsive behavior in events where width reported to JS is not 
  // rendered in accordance with CSS widths and breakpoints.
  var bootstrapReference_Display = $(".hidden-xs:not(.hidden-sm)").first().css("display");

  bootstrapBreakRef__patch(width, bootstrapReference_Display, {
    show: function() {
      // console.log("* openOfCloseActiveItems btstrp patch: show")

            //$(".dropdown").removeClass("open");
            //$(".dropdown a").closest(".dropdown-submenu").removeClass("open");
            }, hide: function() {

      // console.log("* openOfCloseActiveItems btstrp patch: hide")

      //Open the top level if it contains an active link element

        //var activeMenuItem2ndLevel = $(".dropdown").find("a.active");
      //activeMenuItem2ndLevel.closest(".dropdown").addClass("open");


      //Open the submenu if it contains an active link element.
      //var activeMenuItem3rdLevel = $(".dropdown-submenu").find("a.active");
      //activeMenuItem3rdLevel.closest(".dropdown-submenu").addClass("open");






        $("ul.dropdown-menu > li > a[href='#']").addClass("product-active");

        $('.product-active').on('click',function(){

              $(this).parent().siblings('li').children("ul.dropdown-menu").removeClass("open");
              $(this).parent().children("ul.dropdown-menu").addClass("open"); 
              $(this).parent().siblings('li').children("a").removeClass("product-active-check");
              $(this).parent("li").siblings().children("ul.dropdown-menu").children("li").children("a").addClass("product-active-check");
              $(this).parent("li").children("ul.dropdown-menu").children("li").children("a").addClass("product-active-check");

            if($(this).parent().next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").hasClass("icon-show")){

              $(this).parent().next("div.Plus-Icon-mobile").find("img.icon-minus-submenu").addClass("icon-show");
              $(this).parent().next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").removeClass("icon-show");
              $(this).parent().siblings().next("div.Plus-Icon-mobile").find("img.icon-minus-submenu").removeClass("icon-show");
              $(this).parent().siblings().next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").addClass("icon-show");
              $(this).parent().children("ul.dropdown-menu").addClass("open"); 
            }
            else{

              $(this).parent().next("div.Plus-Icon-mobile").find("img.icon-minus-submenu").removeClass("icon-show");
              $(this).parent().next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").addClass("icon-show");
              $(this).parent().children("ul.dropdown-menu").removeClass("open"); 

            }



        }); 



            }

  });



}

/**************************************************************Mobile Patches End*******************************************************************/

//to open the submenu on click of link





function menuMobileDevice(){

  var isMobile = window.matchMedia("only screen and (max-width: 760px)");



    if (isMobile.matches) {



        $(".subnav li.dropdown").children("a.active").parent("li").children("ul.dropdown-menu").addClass("open");
    $(".subnav li.dropdown").children("a.active").parent("li").next("div.Plus-Icon-mobile").find("img.icon-plus").removeClass("icon-show");
    $(".subnav li.dropdown").children("a.active").parent("li").next("div.Plus-Icon-mobile").find("img.icon-minus").addClass("icon-show");
    //$(".subnav li.dropdown").children("a.active").parent("li").children("ul.dropdown-menu").children("li.dropdown-submenu").children("a.active").parent("li.dropdown-submenu").children("ul").children("li").children("a.active").parent("li").parent("ul").parent("li").parent("ul").addClass("open");
    //console.log($("ul.dropdown-menu").children("li.dropdown-submenu").children("a.active").parent("li.dropdown-submenu").children("ul.dropdown-menu").children("li").children("a.active"));

        $(".subnav li.dropdown").children("a.active").parent("li").children("ul.dropdown-menu").children("li.dropdown-submenu").children("a.active").parent("li.dropdown-submenu").children("ul.dropdown-menu").addClass("open");
        $(".subnav li.dropdown").children("a.active").parent("li").children("ul.dropdown-menu").children("li.dropdown-submenu").children("a.active").parent("li").next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").removeClass("icon-show");
        $(".subnav li.dropdown").children("a.active").parent("li").children("ul.dropdown-menu").children("li.dropdown-submenu").children("a.active").parent("li").next("div.Plus-Icon-mobile").find("img.icon-minus-submenu").addClass("icon-show");


        
        if($("ul.dropdown-menu").children("li").children("a.active").parent("li").parent("ul.dropdown-menu.open").children("li").children("a.active")){
                    $("ul.dropdown-menu").children("li").children("a.active").parent("li").parent("ul.dropdown-menu").addClass("open");
                    $("ul.dropdown-menu").children("li").children("a.active").parent("li").parent("ul.dropdown-menu.open").children("li").children("a.active").parent("li").parent("ul").parent("li").next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").removeClass("icon-show");
                     $("ul.dropdown-menu").children("li").children("a.active").parent("li").parent("ul.dropdown-menu.open").children("li").children("a.active").parent("li").parent("ul").parent("li").next("div.Plus-Icon-mobile").find("img.icon-minus-submenu").addClass("icon-show");
                    //$("ul.dropdown-menu").children("li").children("a.active").parent("li").next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").removeClass("icon-show");
                    $("ul.dropdown-menu.open").next("div.Plus-Icon-mobile").find("img.icon-plus-submenu").removeClass("icon-show");
            
                }


    }




}

function menuDesktop(){

  var isDesktop = window.matchMedia("only screen and (min-width:761px) and (max-width:1366px)");



    if (isDesktop.matches) {

  $(".subnav li.dropdown").children("a.active").parent("li").children("ul.dropdown-menu").removeClass("open");
    if($("ul.dropdown-menu").children("li").children("a.active").parent("li").parent("ul.dropdown-menu.open").children("li").children("a.active")){
        $("ul.dropdown-menu").children("li").children("a.active").parent("li").parent("ul.dropdown-menu").removeClass("open");

    }



    }




}

menuMobileDevice();
menuDesktop();


/*var width = $(window).width();
$(window).resize(function() {
   if($(this).width() != width){
    location.reload();
   }

});*/


/*********************************************************************************************************Top Nav End*********************************************************************************************************************/ 

/*add enter to the click function*/
$("#formid input").keypress(function(e) {
    if(e.which == 13) {
       submitMethod();
    }

});

/* 9.26.16 -- Bootstrap patches for navs
 * callbacks should an object of functions to run. 
 *    ~~ callback.show(): should reference the "show" state, small screens and up
 *    ~~ callback.hide(): should reference the "hidden" state, x-small screens and below
 */
function bootstrapBreakRef__patch(width, bootstrapReference_Display, callbacks) {
  if (width > 767 && bootstrapReference_Display != "none") {
    // console.log("\n\nset show")
    return callbacks.show();
  }
  if (width <= 767 && bootstrapReference_Display == "none") {
    // console.log("\n\nset hide")
    return callbacks.hide();
  }

  // Missmatches of window.width reporting between CSS and JS in browsers.
  // When this becomes a question, follow bootstrap breaks amongst html. 
  if (bootstrapReference_Display != "none") {
    // console.log("Overridden: set show, display = ", bootstrapReference_Display)
    callbacks.show()
  }

  if (bootstrapReference_Display == "none") {
    // console.log("Overridden: set hide, display = ", bootstrapReference_Display)
    callbacks.hide()
  }
}
$(document).ready(function(){     
//console.log("maintenance");
    $('.header .col-md-8.col-md-offset-4').addClass('search-container-wrapper');
    $(".tab-content").removeClass("hidden-xs").removeClass("hidden-sm");
        $.ajax({ url: "/bin/sling/mnbdmaintenanceStatus",
                data: "domain=Bermuda",
                success: function(result){
                    var res = JSON.parse(result);
                    var maintenanceStatus=res.status[0].maintenanceStatus;
                    var message =res.status[0].message;
                    //var home ="logged-in-home";
                    //var homePageLink =window.location.href;
                    //var cleanlink =  homePageLink.split("?");
                    //var parts = cleanlink[0].split("/");
                    //var lastWord = parts[parts.length - 1];
                    //var homePage = lastWord.replace(".html", "");
                    var carousel = ($("#carousel-home") || $()).length;
                    var breadcrumb = ($(".gray--bar") || $()).length;

                    if(carousel && !breadcrumb && maintenanceStatus==true){
                        
                        $("#maintMsg").html(message).css("visibility","visible").css("display","block").css("color","red").css("text-align","center").css("padding","5px").css("background-color","#fff");
                        $('#maintMsg').siblings('.white--bar').removeClass('margin__bottom');

                    }
                    else{
                        $("#maintMsg").html(message).css("display","none");
                    }

                },
                error: function(response){
                console.log("error");       

                }
               });
    if(UserData != null)
    {
        triggerInactive();
    }
    });

function triggerInactive(){
    $(document).inactiveAction({
        timeLimit: 15*60,
        onTimeout: function() {
            $('#timerModal').modal('show');
        },
        onCountDown: function(seconds) {
            if (seconds < 11) {

            }
        }
    });
}



/************************************Sales Tools search Result **********************************/
$(document).ready(function(){
function autoSelectCheckBox (argsArray) {
    $.each(document.location.search.substr(1).split('&'),function(index,querySet){
            var queryParam = querySet.split('=');
            if(argsArray.indexOf(queryParam[0].toString())>=0){
                if(queryParam[0].toString()=="topic"){
                    $("h4.second-level a").removeClass("collapsed");
                    $("#collapseHeader2").addClass("in");
                }

            }
        });
}
autoSelectCheckBox(["format","topic","type"]);
});
if(window.location.href.indexOf("topic=MNBD") > 0) { 

$(function () {


              var data = localStorage.getItem("topic");
              var data_second = localStorage.getItem("topic_second");
              var data_third = localStorage.getItem("topic_third");
          var data_fourth = localStorage.getItem("topic_fourth");

      //for first level of open 
              if (data !== null) {
        var first_level=data;
                  //For first level collapse to open
          $(first_level).addClass("in");
                  $(first_level).prev("h4.second-level").children("a").removeClass("collapsed");

              }

            //for second level of open 
                  if (data_second !== null) {
        var second_level=data_second;
                  //For second level collapse to open
                 $(second_level).addClass("in");
                 $(second_level).prev("h4.panel-title").children("div.checkbox").removeClass("collapsed");
                 $(second_level).prev("h4.panel-title").parent(".panel-collapse").addClass("in");
                 $(second_level).prev("h4.panel-title").parent(".panel-collapse").prev("h4.second-level").children("a").removeClass("collapsed");

              }

            //for third level of open 
                  if (data_third !== null) {
        var third_level=data_third;
                  //For second level collapse to open
                 $(third_level).addClass("in");
                 $(third_level).prev().children().removeClass("collapsed");
                 var store_third_level = $(third_level).parent().parent().parent(".panel-collapse");

                 store_third_level.addClass("in");
                 store_third_level.prev().children().removeClass("collapsed");
                 store_third_level.parent().addClass("in");
                 store_third_level.parent().prev().children().removeClass("collapsed");
                 store_third_level.parent().parent().addClass("in");
                 store_third_level.parent().parent().prev().children().removeClass("collapsed");
                 store_third_level.parent().parent().parent().parent().addClass("in");
                 store_third_level.parent().parent().parent().parent().prev().children().removeClass("collapsed");
                 store_third_level.parent().parent().parent().addClass("in");
                 store_third_level.parent().parent().parent().prev().children().removeClass("collapsed");
                 store_third_level.parent().parent().parent().parent().parent().addClass("in");
                 store_third_level.parent().parent().parent().parent().parent().prev().children().removeClass("collapsed");
                 store_third_level.parent().parent().parent().parent().parent().parent().addClass("in");
                 store_third_level.parent().parent().parent().parent().parent().parent().prev().children().removeClass("collapsed");
           store_third_level.parent().parent().parent().parent().parent().parent().parent().addClass("in");
                 store_third_level.parent().parent().parent().parent().parent().parent().parent().prev().children().removeClass("collapsed");


          }

        //for fourth level of open 
              if (data_fourth !== null) {

        var fourth_level=data_fourth;
                  //For first level collapse to open
          $(fourth_level).addClass("in");
                  $(fourth_level).prev().children().removeClass("collapsed");
                  var store_fourth_level = $(fourth_level).parent().parent().parent(".panel-collapse");
                  store_fourth_level.addClass("in");
                  store_fourth_level.prev().children().removeClass("collapsed");

                  store_fourth_level.parent().addClass("in");
                  store_fourth_level.parent().prev().children().removeClass("collapsed");
                  store_fourth_level.parent().parent().addClass("in");
                  store_fourth_level.parent().parent().prev().children().removeClass("collapsed");
                  store_fourth_level.parent().parent().parent().parent().addClass("in");
                  store_fourth_level.parent().parent().parent().parent().prev().children().removeClass("collapsed");
                  store_fourth_level.parent().parent().parent().addClass("in");
                  store_fourth_level.parent().parent().parent().prev().children().removeClass("collapsed");
                  store_fourth_level.parent().parent().parent().parent().parent().addClass("in");
                  store_fourth_level.parent().parent().parent().parent().parent().prev().children().removeClass("collapsed");
                  store_fourth_level.parent().parent().parent().parent().parent().parent().addClass("in");
                  store_fourth_level.parent().parent().parent().parent().parent().parent().prev().children().removeClass("collapsed");
                  store_fourth_level.parent().parent().parent().parent().parent().parent().parent().addClass("in");
                  store_fourth_level.parent().parent().parent().parent().parent().parent().parent().prev().children().removeClass("collapsed");



              }
});
}
$("input[name='topic']").click(function () {
  var fav, favs = [];favs_second = [];favs_third = [];favs_fourth = [];
  $("input[name='topic']").each(function() { // run through each of the checkboxes

   if ($(this).is(":checked")) {


      var  getIds =  $(this).parent("h4.panel-title").parent().attr("id");
      var getIds_second =  $(this).parent("div.second-level").parent().parent().parent().attr("id");
      var getIds_third = $(this).parent().parent().parent().parent().attr("id");
      var getIds_fourth = $(this).parent().parent().parent().parent().parent().attr("id");
    fav = '#'+getIds;
         console.log(fav);
      fav_second =  '#'+getIds_second;
      fav_third =  '#'+getIds_third;
      fav_fourth =  '#'+getIds_fourth;

      favs.push(fav);
      favs_second.push(fav_second);
      favs_third.push(fav_third);
      favs_fourth.push(fav_fourth);
   }
  });

  if ($("input[name='topic']").is(":checked")) {
  localStorage.setItem("topic_fourth", favs_fourth);
  localStorage.setItem("topic_third", favs_third);
  localStorage.setItem("topic_second", favs_second);
  localStorage.setItem("topic", favs);
  }

});

/************************************Sales Tools search Result Change request end**********************************/


$(document).ready(function(){



       /*  End of Log In /Log out configuration */
  /*to make the last li fly away on left*/
    $("ul.subnav").children("li:nth-of-type(4)").children().find(".dropdown-submenu").addClass("last-nav");
/*Hide the my business link for all the user*/
    $("ul.subnav").children("li:nth-of-type(6)").children().addClass("last-of-type");
    $("ul.subnav").children("li:nth-of-type(6)").css("display","none");
    $("div.footerglobal").find("div.footercolumn").last().children("ul").children("li").first().css("display","none");
    $("ul.subnav").children("li:nth-of-type(5)").children().addClass("last-of-type"); 
    $(".rightrails").children("div.block").children("p:nth-of-type(1)").css("display","none");
    $(".rightrails").children("div.block").children("p:nth-of-type(1)").next("hr").css("display","none");
    $(".rightrails").children("div.block").children("p:nth-of-type(2)").css("display","none");
    $(".rightrails").children("div.block").children("p:nth-of-type(2)").next("hr").css("display","none");
/*Hide the my business link for all the user code end*/

 /*To hide the my business Tab for the general user*/
    if(UserData != null && UserData.content.hasOwnProperty('role')){
  var GetDetail = UserData.content.role;
            if(GetDetail=="Distributor" || GetDetail=="SuperUser_SN"){
        $("ul.subnav").children("li:nth-of-type(6)").css("display","block");
                $("div.footerglobal").find("div.footercolumn").last().children("ul").children("li").first().css("display","block");
                $("ul.subnav").children("li:nth-of-type(5)").children().removeClass("last-of-type");
                $(".rightrails").children("div.block").children("p:nth-of-type(1)").css("display","block");
                $(".rightrails").children("div.block").children("p:nth-of-type(1)").next("hr").css("display","block");
                $(".rightrails").children("div.block").children("p:nth-of-type(2)").css("display","block");
                $(".rightrails").children("div.block").children("p:nth-of-type(2)").next("hr").css("display","block");


              }
    }
/*see more issue fix*/
    $(".see-more").click(function() {
    $(this).children("a").toggleClass("see-less");
        if($(this).children("a").hasClass("see-less")){
      //$(this).children("a").text("See less ");
            $(this).children("a").html('See less <span class="glyphicon glyphicon-menu-up" aria-hidden="true"></span>');


        }
        else{
      $(this).children("a").html('See more <span class="glyphicon glyphicon-menu-down" aria-hidden="true"></span>');

        }
  });


});
/* Log In /Log out configuration */

$(function (){

if(UserData!=null){
  $('.utilityNav ul').each(function(i, items_list){

    $(items_list).find('a').each(function(){
           var loginfo=$(this).html();
            if(loginfo=="Login / Register"){
                $(this).parent().css('display','none');
            }
            if(loginfo=="Log Out"){
                $(this).parent().css('display','inline-block');
            }
        });
  });
     /*To hide the slider*/
    $("#slidepanel").css('display','block');
}else{
   $('.utilityNav ul').each(function(i, items_list){
    $(items_list).find('a').each(function(){
           var loginfo=$(this).html();
           if(loginfo=="Login / Register"){
                $(this).parent().css('display','inline-block');
            }
            if(loginfo=="Log Out"){
                $(this).parent().css('display','none');
            }
        });

  });
	/*To show the slider*/
	$("#slidepanel").css('display','none');

}
});