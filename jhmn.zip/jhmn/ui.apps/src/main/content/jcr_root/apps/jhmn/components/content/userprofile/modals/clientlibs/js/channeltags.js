CQ.Ext.ns("ProfileAEM");
 
ProfileAEM.ChannelTagInput = CQ.Ext.extend(CQ.tagging.TagInputField, {
	
	constructor: function(config) {
        CQ.Util.applyDefaults(config, {
            // TagInputField config
            "tagsBasePath": "/etc/tags",
            "displayTitles": true,
            "showPathInLabels": true,
            "namespaces": [],
            "popupWidth": 500,
            "popupHeight": 300,
            "popupResizeHandles": "sw se", // bottom left and bottom right resize handles only
            "popupAlignTo": "tl-bl",
            "suggestMinChars": 3,

            // inherited config
            "border": false,
            "layout": "fit"
        });
        if (config.readOnly) {
            config.cls = (config.cls ? config.cls + " " : "") + "x-form-disabled";
        }

        // for use of "this" in closures
        var tagInputField = this;
        
        this.autoCompletionProxy = new CQ.Ext.data.MemoryProxy(null);
        
        var textField = new CQ.Ext.form.ComboBox({
            wrapCls: "floating", // special config, see on render handler below
            cls: "invisible-input",
            hidden: config.readOnly,
            hideLabel: true,
            hideTrigger: true,
            resizable: true,
            autoCreate: {tag: "input", type: "text", size: "18", autocomplete: "off"},
            name: CQ.Sling.IGNORE_PARAM, // let sling ignore this field
            displayField: config.displayTitles ? "titlePath" : "tagID",
            minChars: config.suggestMinChars,
            typeAhead: false, // type ahead in combo only works for single value completion
            queryParam: config.displayTitles ? "suggestByTitle" : "suggestByName",
            lazyInit: false,
            store: new CQ.Ext.data.Store({
                proxy: new CQ.Ext.data.HttpProxy({
                    url: config.tagsBasePath + CQ.tagging.TAG_LIST_JSON_SUFFIX,
                    method: "GET"
                }),
                reader: new CQ.Ext.data.JsonReader({
                    root: "tags",
                    fields: [
                        "tagID",
                        {
                            name: "titlePath",
                            mapping: function(o) {
                                return CQ.tagging.getLocalizedTitle(o, tagInputField.locale, "titlePath");
                            }
                        }
                    ]
                }),
                baseParams: {
                    count: "false",
                    "_charset_": "utf-8"
                    // these are the default values for the suggest servlet
                    // ignoreCase: "true",
                    // matchWordStart: "false"
                }
            }),
            title: CQ.I18n.getMessage("Matching tags"),
            listEmptyText: CQ.I18n.getMessage("No matching tag found"),
            listWidth: 500,
            // custom template to highlight typed text in auto-completion list
            tpl: new CQ.Ext.XTemplate(
                '<tpl for="."><div class="x-combo-list-item">{[this.markText(values)]}</div></tpl>',
                {
                    markText: function(values) {
                        var val = values[config.displayTitles ? "titlePath" : "tagID"];
                        // make sure
                        var typed = textField.getRawValue().toLowerCase();
                        var pos = val.toLowerCase().lastIndexOf(typed);
                        if (pos >= 0) {
                            return val.substring(0, pos) + "<b>" + val.substr(pos, typed.length) + "</b>" + val.substring(pos + typed.length);
                        } else {
                            return val;
                        }
                    }
                }
            )
        });
        this.textField = textField;
        
        this.textField.comboBoxOnLoad = this.textField.onLoad;
        // filter out not-allowed namespaces
        this.textField.onLoad = function() {
            if (!tagInputField.allNamespacesAllowed) {
                this.store.filterBy(function(record, id) {
                	var tagPath = record.get("tagID");
                	if (tagPath.indexOf("MNBD:channel") < 0) {
                		return false;
                	}
                    var ns = tagInputField.getNamespaceDefinition(tagPath);
                    var cfg = tagInputField.getNamespaceConfig(ns.name);
                    return cfg !== null && cfg !== undefined;
                });
            }
            this.comboBoxOnLoad();
        };

        this.textField.getErrors = function(value) {
            // CQ:START
            var errors = [ ];
            if (this.evaluateValidatorsFirst) {
                this.executeCustomValidators(value, errors);
            }

            // var errors = CQ.Ext.form.TextField.superclass.getErrors.apply(this, arguments);
            errors = errors.concat(CQ.Ext.form.TextField.superclass.getErrors.apply(this,
                    arguments));
            // CQ:END

            value = CQ.Ext.isDefined(value) ? value : this.processValue(this.getRawValue());

            if (CQ.Ext.isFunction(this.validator)) {
                var msg = this.validator(value);
                if (msg !== true) {
                    errors.push(msg);
                }
            }

            if ((value.length < 1 || value == this.emptyText) && this.previousSibling() == null) {
                if (tagInputField.allowBlank) {
                    //if value is blank and allowBlank is true, there cannot be any additional errors
                    return errors;
                } else {
                    errors.push(this.blankText);
                }
            }

            if (this.vtype) {
                var vt = CQ.Ext.form.VTypes;
                if(!vt[this.vtype](value, this)){
                    errors.push(this.vtypeText || vt[this.vtype +'Text']);
                }
            }

            if (this.regex && !this.regex.test(value)) {
                errors.push(this.regexText);
            }

            return errors;
        }

        this.textField.on('render', function(textField) {
            // add the special config "wrapCls" to wrapper div
            textField.wrap.addClass(textField.wrapCls);

            // add keydown listener to prevent form submission in standard HTML form
            CQ.Ext.EventManager.on(textField.el.dom, "keydown", function(evt) {
                if (evt.keyCode == CQ.Ext.EventObject.ENTER) {
                    if (evt.preventDefault) {
                        // ff
                        evt.preventDefault();
                    } else {
                        // ie
                        evt.returnValue = false;
                    }
                }
            }, this, {"normalized": false});
        });
        
        this.inputDummy = new CQ.Ext.Panel({
            "cls": "dummy-input",
            "border": false
        });
        
        config.items = [
            this.inputDummy
        ];

        this.namespacesTabPanel = new CQ.Ext.TabPanel({
            enableTabScroll: true,
            deferredRender: false, // needed for the tree views inside the non-visible tabs on start to be displayed
            border: false,
            width: config.popupWidth,
            height: config.popupHeight,
            bbar: [{
                    iconCls: "cq-siteadmin-refresh",
                    handler: function() {
                        this.loadTagNamespaces();
                    },
                    scope: this
                },
                "->",
                CQ.tagging.getLocaleSelectCombo(function(locale) {
                    tagInputField.setLocale(locale);
                })
            ]
        });

        CQ.tagging.TagInputField.superclass.constructor.call(this, config);
    },
    
    setupPopupMenu: function() {
        // since the tree is used to add/remove tags by clicks, we disable GUI selections altogher
        var noSelectionsHandler = function(selectionModel, oldSel, newSel) {
            return false;
        };
        
        var tagfield = this;

        var tab = 0;
        // in case of a reload, clear existing tabs
        if (this.namespacesTabPanel && this.namespacesTabPanel.items.getCount() > 0) {
            tab = this.namespacesTabPanel.items.indexOf(this.namespacesTabPanel.getActiveTab());
            this.namespacesTabPanel.removeAll(true);
        }
        
        function getTitle(ns) {
            return (tagfield.displayTitles && ns.title) ?
                CQ.tagging.getLocalizedTitle(ns, tagfield.locale, "title") :
                ns.name;
        }
        
        // sort the namespace tabs
        // need to put them from the hash in an array first to be able to sort them
        var nsArray = [];
        for (var n in this.tagNamespaces) {
            if (this.tagNamespaces.hasOwnProperty(n)) {
                nsArray.push(this.tagNamespaces[n]);
            }
        }
        nsArray.sort(function(a,b) {
            return getTitle(a).localeCompare(getTitle(b));
        });
        
        for (var i = 0; i < nsArray.length; i++) {
            var ns = nsArray[i];
            var cfg = this.getNamespaceConfig(ns.name);
            if (!cfg) {
                continue;
            }
            
            // similar to TagAdmin.js
            var treeLoader = new CQ.tree.SlingTreeLoader({
                // sling tree loader config
                path: "/content/cq:tags/MNBD/channel",
                typeIncludes: ["cq:Tag"],
                filterFn: function(name, o) {
                	//console.log(name);
                    if (o["cq:movedTo"]) {
                        return null;
                    }
                    return o;
                },
                getTitle: function(name, o) {
                    return CQ.shared.XSS.getXSSValue( CQ.tagging.getLocalizedTitle(o, tagfield.locale, "jcr:title", name) );
                },
                getQtip: function(name, o) {
                    return CQ.shared.XSS.getXSSValue( o[this.qtipProperty] );
                },
                // standard tree loader config
                baseAttrs: {
                    singleClickExpand: true
                }
            });
            
            var rootNode = new CQ.Ext.tree.AsyncTreeNode({
                // no leading slash for name of root node, will be added automatically in getPath()
                "name": "etc/tags/MNBD/channel",
                "text": ns.title ? ns.title : ns.name,
                
                listeners: {
                    load: function(node) {
                        var tp = node.treePanel;
                        if (tp.loadMask) {
                            tp.loadMask.hide();
                            tp.loadMask = null;
                        }
                    }
                }
            });
            
            var treePanel = new CQ.Ext.tree.TreePanel({
                "root": rootNode,
                "rootVisible": false,
                "loader": treeLoader,
                "autoScroll": true,
                "containerScroll": true
            });
            rootNode.treePanel = treePanel;
            
            new CQ.Ext.tree.TreeSorter(treePanel, {
                folderSort: true
            });
        
            if (CQ.Ext.menu.Adapter) {
                // up to cq 5.3 and ext 2.x
                treePanel.on("render", function(tp) {
                    tp.loadMask = new CQ.Ext.LoadMask(tp.body, {
                        msg: CQ.I18n.getMessage("Loading..."),
                        removeMask: true
                    });
                
                    function showMask() {
                        if (tp.loadMask) {
                            tp.loadMask.show();
                        }
                    }
                    showMask.defer(100);
                });
            } else {
                // since cq 5.4 and ext 3.x
                treePanel.on("render", function(tp) {
                    tp.loadMask = new CQ.Ext.LoadMask(tp.body, {
                        msg: CQ.I18n.getMessage("Loading..."),
                        removeMask: true
                    });
                });
                
                treePanel.on("afterlayout", function(tp) {
                    if (tp.loadMask) {
                        tp.loadMask.show();
                    }
                });
            }
            
            treePanel.on('click', this.onTagNodeClicked, this);
            treePanel.getSelectionModel().on('beforeselect', noSelectionsHandler);

            this.namespacesTabPanel.add({
                "title": CQ.shared.XSS.getXSSValue( getTitle(ns) ),
                
                "tabTip": CQ.shared.XSS.getXSSValue( CQ.I18n.getMessage("Namespace", [], "Tag Namespace") + ": " + (!this.displayTitles && ns.title ? ns.title : ns.name) ),
                
                // wrap treepanel in a simple panel for fit layout + scrolling
                "xtype": "panel",
                "layout": "fit",
                "border": false,
                "items": treePanel
                
            });
        }
        this.namespacesTabPanel.setActiveTab(tab);
    },
	
	setValue: function(valueArray, partialTags) {
        this.clear();
        
        this.initLocale();
        
        if (valueArray) {
            var tags = null;

            // optimization: in a cq Dialog, we know the content path, and if this
            // is a standard cq:tags property, we can load all tag definitions for
            // the tags referenced by that resource in one go
            if (this.contentPath && (this.name === "cq:tags" || this.name === "./cq:tags") ) {
                // load all tags referenced by this resource from server (faster than many multiple requests per tag below)
                // 2nd argument = cache killer needed for IE7/8 set to automated caching
                var tagJson = this.loadJson(this.contentPath + CQ.tagging.TAG_LIST_JSON_SUFFIX + "?count=false", true);
                if (tagJson && tagJson.tags) {
                    tags = tagJson.tags;
                }

                // reset so that the next, possibly manual setValue() call works based on the passed array only
                this.contentPath = null;
            }
        
            if (!tags || tags.length === 0) {
                tags = [];
                
                // go through values (which are tag ID strings) and load their tag definitions
                for (var i=0, iEnd = valueArray.length; i < iEnd; i++) {
                    var tagID = valueArray[i];
                    var tagInfo = CQ.tagging.parseTagID(tagID);
            
                    // load single tag data from server
                    var tag = this.loadJson(this.tagsBasePath + "/" + tagInfo.namespace + "/" + tagInfo.local + CQ.tagging.TAG_JSON_SUFFIX);
                    tags.push(tag || tagID);
                }
                
                // handle partial values
                if (partialTags) {
                    for (var i=0, iEnd = partialTags.length; i < iEnd; i++) {
                        var tagID = partialTags[i];
                        var tagInfo = CQ.tagging.parseTagID(tagID);
                
                        // load single tag data from server
                        var tag = this.loadJson(this.tagsBasePath + "/" + tagInfo.namespace + "/" + tagInfo.local + CQ.tagging.TAG_JSON_SUFFIX);
                        if (tag) {
                            // only look at existing tags for parital tags
                            tag.partial = true;
                            tags.push(tag);
                        }
                    }
                }
            }
        
            // internally add all tags
            CQ.Ext.each(tags, function(tag) {
                var namespace = CQ.tagging.parseTagID(tag.tagID || tag).namespace;
            
                if (typeof tag === "string" || !this.isAllowedNamespace(namespace) || tag.tagID.indexOf("MNBD:channel") < 0) {
                    // not allowed namespace, keep pure tagID in the background
                    this.hiddenTagIDs.push(tag.tagID || tag);
                } else {
                    // allowed => display
                    if (tag.partial) {
                        delete tag.partial;
                        this.internalAddTag(tag, "partial");
                    } else {
                        this.internalAddTag(tag, "set");
                    }
                }
            }, this);
        }

        // rebuild this.value
        this.getValue();

        this.inputDummy.doLayout();
    },

	getTags: function() {
        var result = [];
        CQ.Ext.each(this.tags, function(tagObj) {
            if (tagObj.type != "partial" && tagObj.tagID.indexOf("MNBD:channel") > -1) {
                result.push(tagObj.tag);
            }
        });
        return result;
    }
});
 
CQ.Ext.reg("mnbdchanneltag", ProfileAEM.ChannelTagInput);