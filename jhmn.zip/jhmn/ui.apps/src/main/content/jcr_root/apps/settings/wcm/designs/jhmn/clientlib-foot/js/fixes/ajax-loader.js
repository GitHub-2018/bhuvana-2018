$(function() {

    function setLoaderParam(el){
        el.each(function() {
            $(this).data("params", {
                "searchtype": [],
                "sortorder": "default",
                "count": 10,
                "setcount": 0,
                "domid": $(this).attr("data-domid")
            });
        });
    }
    setLoaderParam($("[data-ajaxurl][data-searchtype]"));

    function getSearchType(target) {

        var searchTypeElems = $(target.parents("[data-searchtype]").get().reverse());

        var sTypes = [];

        searchTypeElems.each(function(key, value) {
            sTypes.push($(this).attr("data-searchtype"));
        });

        sTypes.push(target.attr("data-searchtype"));

        return sTypes;
        /* 
            return data --> sTypes. 
            It's searchType returned as array. search type level/sublevel will be returned as array 

            [1st level, 2nd level, 3rd level, 4th level, .....] 

        */
    }

    /* 
        the top dom view is : [data-ajaxurl][data-searchtype] 
        there should not be any child element with [data-ajaxurl][data-searchtype] attributes 
    */

    $(document).on("click", "[data-ajaxurl][data-searchtype] [data-loadmoretarget]", function(e) {
        var elem = $(this).closest("[data-ajaxurl][data-searchtype]"),
            target = $($(this).attr("data-loadmoretarget")).eq(0);

        //.attr("data-searchresulttarget", "dom_"+ Date.now()); 

        if (isNaN(parseInt(target.data("setcount")))) {
            target.data("setcount", 0);
        }
        target.data("setcount", target.data("setcount") + 1);
        if ($(this).attr("data-sortorder")) {
            target.data("sortorder", $(this).attr("data-sortorder"));
        }
        target.data("count", $(this).attr("data-count"));

        if (!elem.data("params")) {
            elem.data("params", {});
        }
        elem.data("params").setcount = target.data("setcount");
        elem.data("params").count = target.data("count");
        elem.data("params").searchtype = getSearchType(target);

        var url = elem.attr("data-ajaxurl"),
            params = elem.data("params"),
            el = $(this);

        elem.add(el.closest('[data-paramholder]')).find(":input[data-param=true]").each(function() {
            params[$(this).attr("name")] = $(this).val();
        });

        loaddata(url, params, el);
    });

    $(document).on("click", "[data-templateholder][data-templatetarget]", function(e) {
        var source = $($(this).attr("data-templatetarget")).html();
        var template = Handlebars.compile(source);

        var context = {};
        var html = template(context);
        var tpl_holder = $($(this).attr("data-templateholder"));
        var tpl_clickTarget = $(this).attr("data-clicktarget");
        tpl_holder.html(html).find(tpl_clickTarget).trigger("click");
    });

    $(document).on("click", "[data-activecontainer] [data-active]", function(e) {
        $(this).closest('[data-activecontainer]').find("[data-active]").removeClass('active');
        $(this).addClass('active');
    });

    function loaddata(url, params, el) {
        if (params.setcount > 1) {
            $(".loader-holder").show();
        }
        $.ajaxSetup({
            cache: false
        });
        var jqxhr = $.get(url, params, function(data) {
            var el_content = $(el.attr("data-loadmoretarget")).eq(0);

            if (params.setcount == 1) {
                el_content.empty();
            }

            var source = $(el_content.attr("data-templatetarget")).eq(0).html();
            var template = Handlebars.compile(source);

            var context = data.list;
            var html = template({
                "list": context
            });

            var ignore_elms = el_content.find("[data-clickme-onload=true]");
            el_content.append(html);
            el_content.find("[data-clickme-onload=true]").not(ignore_elms).trigger('click');

            if (!data.enableloadmore) {
                el.hide().attr("disabled", "disabled");
            } else {
                el.show().removeAttr("disabled");
            }
            if (data.domupdate && typeof data.domupdate == "object") {
                try {
                    $.each(data.domupdate, function(key, val) {
                        $(key.toString()).html(val);
                    });
                } catch (ex) {};
            }

            if (el_content.attr("data-callback")) {
                /* Just invoking a callback function without any parameter */

                try {
                    if (typeof window[el_content.attr("data-callback")] == "function") {
                        window[el_content.attr("data-callback")].call(el_content.get(0), el_content);
                    }
                } catch (ex) {};
            }

            $(".loader-holder").hide();
            // console.log( "success" );
        }).fail(function() {
            // console.log( "error" );
            $(".loader-holder").hide();
        });
    }

    /* Ajax content loader on DOCUMENT READY */
    function content_loader(elems){
    	elems.each(function() {
	        var url = $(this).attr("data-content-url"),
	        params = {},
	        that = $(this);

	        $(this).children("input:hidden[data-param=true]").each(function() {
	            params[$(this).attr("name")] = $(this).val();
	        });
	        $.ajaxSetup({
	            cache: false
	        });
	        var jqxhr = $.get(url, params, function(data) {
	            if (that.attr("[data-templatetarget]") != "") {
	                var source = $(that.attr("data-templatetarget")).html();
	                var template = Handlebars.compile(source);
	                var html = template(data);

	                that.html(html);
	            } else {
	                that.html(data);
	            }
	        }).fail(function() {
	            // remove loader/ show error message (optional) 
	        });
	    });
    }
    content_loader($(document).find("[data-content-loader=true]"));

    /* Ajax content loader on click */
    function load_ajax_content(el){
    	var container = el.closest("[data-loadercontainer=true]"),
            url = container.attr("data-ajaxurl"),
            loadTarget = container.attr("data-loadtarget"),
            tplTarget = container.attr("data-templatetarget"),
            scope = container.attr("data-scope"),
            callback = container.attr("data-callback"),
            params = {},
            contentElement = $(),
            paramSelector = "input:hidden[data-param=true]",
			paramHolders = $(container.attr("data-paramtarget")),
            that = el;

        /* Collect the parameters */
		container.find(paramSelector).add(paramHolders.find(":input[data-param=true]")).each(function() {
			if($(this).is("input:checkbox") || $(this).is("input:radio")){
				if(! $(this).is(":checked")){
					return true;
				}
			}

			var name = $(this).attr("name"), val = $(this).val();
			if(params.hasOwnProperty(name)){
				if(!$.isArray(params[name])){
					params[name] = [params[name]];
				}
				params[name].push(val);
			}
			else{
				params[$(this).attr("name")] = $(this).val();
			}
		});

		/* Merge params from data object */
		$.extend( true, params, that.data("params") );

		/* Update prior options */
		url = that.attr("data-ajaxurl") ? that.attr("data-ajaxurl") : url;
		loadTarget = that.attr("data-loadtarget") ? that.attr("data-loadtarget") : loadTarget;
		tplTarget = that.attr("data-templatetarget") ? that.attr("data-templatetarget") : tplTarget;
		scope = that.attr("data-scope") ? that.attr("data-scope") : scope;
		loaderHolder = $(that.attr("data-loaderholder"));
		callback = that.attr("data-callback") ? that.attr("data-callback") : callback;


		if (scope == "false") {
			contentElement = $(document).find(loadTarget).eq(0);
		} else {
			contentElement = container.find(loadTarget);
		}

		loaderHolder = (loaderHolder.length == 1) ? loaderHolder : $(".loader-holder");
		loaderHolder.show();

        $.ajaxSetup({
            cache: false
        });
        if(url){

			$.ajaxSetup({
				cache: false
			});

			var jqxhr = $.ajax({
				url : url, 
				data : params,
				async: true
			})
			.done(function(data) {

				parseTemplate(data);

				setLoaderParam(contentElement.find("[data-ajaxurl][data-searchtype]"));
                contentElement.find("[data-clickme-onload=true]").trigger("click");
                content_loader(contentElement.find("[data-content-loader=true]"));
			})
			.fail(function(data) {
				console.log("error");
			})
			.always(function(data) {
				// console.log("complete");
				loaderHolder.hide();
			});

		}else{
			parseTemplate({});
		}
		function parseTemplate(data){
			if (tplTarget) {
				var source = $(tplTarget).html();
				var template = Handlebars.compile(source);
				var html = template(data);

				contentElement.html(html);
			} else {
				if (params.content_id) {
					var page = $("<div>").html(data);
					page = page.find("#" + params.content_id).html();
					data = page;
				}
				contentElement.html(data);
			}

			/* Setting Active class for the clicked element */
            that.siblings('.active').removeClass('active').end().addClass('active');


			if(callback){
				try{
					eval(callback);
				}catch(ex){};
			}
			
		}
    }
    $(document).on("click", "[data-loadercontainer=true] [data-loadtrigger=true]", function(e) {
    	$(this).find("input[name='pageNo']").attr("data-param", "true");
    	load_ajax_content($(this));
	});
    
	$(document).on("click", "[data-loadercontainer=true] [data-clickme-hash]", function(e) {
		if(! e.hasOwnProperty('originalEvent') ){
			load_ajax_content($(this));
		}
	});
	

	function hashChanged(hash){
		if(hash !== ""){
			$(document).find("[data-clickme-hash='" + hash + "']").trigger("click");
		}
	}
	if ("onhashchange" in window) {
		window.onhashchange = function () {
			hashChanged(window.location.hash);
		}
	}
	/* commented for fority scan fix*/
/*	else {
		var prevHash = window.location.hash;
		window.setInterval(function () {
			if (window.location.hash != prevHash) {
				prevHash = window.location.hash;
				hashChanged(window.location.hash);
			}
		}, 100);
	} */

    /* Keep this lines always at bottom */
    $(document).find("[data-clickme-onload=true]").trigger("click");
    $(document).find("[data-changeme-onload=true]").trigger("change");

	hashChanged(window.location.hash);

});
