(function() {
  //
  // Adding stylesheets depending on window location
  // **** Important ****
  // Hostnames need to be updated to final names
  //

    var site = window.location.hostname;

    // Remove this line - used to determine hostname
    //console.log(site);

    switch (site) {
      // Add Vitality Hostname
      case 'www.johnhancockvitality.com/JohnhancockVitality':
           var head  = document.getElementsByTagName('head')[0];
           var link  = document.createElement('link');           
           link.rel  = 'stylesheet';
           link.type = 'text/css';
           link.href = 'css/vitality-component.css';
           link.media = 'all';
           head.appendChild(link);
          $(document).ready(function () {
          $('.header').find('.nav').addClass('invisible');
          $('.header').find('.navbar').addClass('invisible');
          $('.header').find('.list-inline').addClass('invisible'); 
          $('.header').find('.search').addClass('invisible'); 
          $('.footer').find('.block-icons').addClass('invisible'); 
          $('.footer').find('.col-sm-3').addClass('invisible'); 
          $('.footer').find('.list-inline li:not(:nth-child(n+9))').addClass('invisible'); 
          $('.footer').find('hr').addClass('invisible'); 
          });
        break;
      // Add JHServiceNet Hostname
      case 'jh1.jhlifeinsurance.com/JHServiceNet/':
           var head  = document.getElementsByTagName('head')[0];
           var link  = document.createElement('link');           
           link.rel  = 'stylesheet';
           link.type = 'text/css';
           link.href = 'css/consumer-component.css';
           link.media = 'all';
           head.appendChild(link);

           /** Show the "Go back to ServiceNet" tab on login page **/
           $('.nav #returnFromLogin').show();
           
           /** Use this code to change the text content of the tab **/
           // $('.nav #returnFromLogin').html("new tab content");
        break;
      // Add Manulife Hostname
      case 'www.manulife.com/':
           var head  = document.getElementsByTagName('head')[0];
           var link  = document.createElement('link');           
           link.rel  = 'stylesheet';
           link.type = 'text/css';
           link.href = 'css/manulife-component.css';
           link.media = 'all';
           head.appendChild(link);
        break;        
      default: 
         var head  = document.getElementsByTagName('head')[0];
         var link  = document.createElement('link');           
         link.rel  = 'stylesheet';
         link.type = 'text/css';
         link.href = 'css/component.css';
         link.media = 'all';
         head.appendChild(link);
	}
  })();