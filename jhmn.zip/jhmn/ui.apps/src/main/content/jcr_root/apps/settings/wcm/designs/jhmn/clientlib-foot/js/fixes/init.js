$(function() {
    //listen for the store registration
    CQ_Analytics.ClientContextUtils.onStoreRegistered("userdetails", listen);
    //listen for the store's update event
    function listen() {
    	//console.log("LISTENING TO USERDETAILS STORE");
        var profilestore = CQ_Analytics.ClientContextMgr.getRegisteredStore("userdetails");
       // console.log("FIRST NAME **" + profilestore.data["firstname"]);
      //  console.log("LAST NAME **" + profilestore.data["lastname"]);
       //  console.log("IV-Groups **" + profilestore.data["iv-groups"]);
       // console.log("Email**" + profilestore.data["email"]);
        // console.log("WSSRegistered**" + profilestore.data["WSSREGISTERED"]);
        $("#sidepanel_name").replaceWith("<h4>Welcome, " + profilestore.data["firstname"] + " " + profilestore.data["lastname"] + "</h4>");
    }

    try{
    $(".msg-inactive").hide();
	triggerInactive();
    }catch(error){
        //do nothing
    }



});

function triggerInactive(){
    $(document).inactiveAction({
        timeLimit: 15*60,
        onTimeout: function() {
            $('#timerModal').modal('show');
        },
        onCountDown: function(seconds) {
            if (seconds < 11) {
               
            }
        }
    });
    
}