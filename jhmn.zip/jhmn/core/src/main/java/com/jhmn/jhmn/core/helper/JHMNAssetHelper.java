package com.jhmn.jhmn.core.helper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhmn.jhmn.core.bean.AssetMetaDataBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;


public class JHMNAssetHelper {
	private static Logger LOG = LoggerFactory.getLogger(JHMNAssetHelper.class);
	public static AssetMetaDataBean retrieveAssetBean(String path, ResourceResolver resourceResolver) {
		LOG.debug("Starting of retrieveAssetBean method");
		AssetMetaDataBean assetBean = null;
		Resource resource = resourceResolver.getResource(path);
		LOG.debug("retrieveAssetBean--> RESOURCE PATH --> " + path);
		TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
		try {
			Node assetNode = resource.adaptTo(Node.class);
			Date date = JHMNDateHelper.getLastModified(assetNode);
			LOG.debug("retrieveAssetBean--> PUBLISHED DATE --> " + date);
			Boolean isNew = JHMNDateHelper.checkIsNew(date);
			Asset asset = resource.adaptTo(Asset.class);

			if (asset != null) {
				assetBean = new AssetMetaDataBean();
				Map<String, Object> assetMetaDataMap = asset.getMetadata();
				assetBean.setPath(path);
				assetBean.setDate(getLastModified(assetNode));
				LOG.debug("Asset node property"+assetNode.hasProperty("jcr:created")+"path= "+assetNode.getPath()+ "Expecting date here-- "+date+" Date for fund rates and info date in method"+JHMNDateHelper.getLastModified(assetNode));
				assetBean.setTitle(assetMetaDataMap.containsKey(JHMNConstants.ASSET_TITLE)
						? asset.getMetadataValue(JHMNConstants.ASSET_TITLE) : JHMNConstants.EMPTY_STRING);
				assetBean.setNew(isNew);

				String tags = asset.getMetadataValue(JHMNConstants.CQ_TAGS);
				assetBean.setPriority(JHMNConstants.PRIORITY_LOW);
				if(tags != null){
					String[] tagArray = tags.split(",");
					for (String string : tagArray) {
						LOG.info("Tag value String is "+string);
						Tag tag = tagManager.resolve(string.trim());
						if(tag==null)
						{
							continue;
						}
						String tagID = tag.getLocalTagID();
						LOG.info("tagID value is "+tagID);
						if (tagID.startsWith(JHMNConstants.PARAM_TYPE)) {
							assetBean.setType(tag.getTitle());
						} 


						else if (tagID.startsWith(JHMNConstants.PARAM_FORMAT)) {
							assetBean.setFormat(tag.getTitle());
							String format = tag.getTitle();

							assetBean = setIcon(format, assetBean);
							if (format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_PDF) || format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_IMAGE)) {
								assetBean.setImagePath(asset.getRendition(JHMNConstants.IMAGE_RENDITION_30_42) != null
										? asset.getPath() + ".thumb.32.40.png" : asset.getPath() + ".thumb.48.48.png");
								assetBean.setGlypIcon(JHMNConstants.EMPTY_STRING);
							} else {
								assetBean.setImagePath(JHMNConstants.EMPTY_STRING);
							}
						} else if (tagID.startsWith(JHMNConstants.PARAM_TOPIC)) {
							assetBean.setTopic(tag.getTitle());
						} else if (tagID.startsWith(JHMNConstants.PARAM_CHANNEL)) {
							assetBean.setChannel(tag.getTitle());
						}else if (tagID.startsWith(JHMNConstants.PARAM_PRIORITY)){
							assetBean.setPriority(tag.getTitle());
							LOG.info("Priority:: " +tag.getTitle());
						}
					}

				if(!tags.contains(JHMNConstants.PARAM_FORMAT)){
					String format = "";
					String formatType = asset.getMetadataValue(JHMNConstants.ASSET_FORMAT);
					if(formatType.equalsIgnoreCase(JHMNConstants.PDF_FORMAT)){
						format = JHMNConstants.TAG_FORMAT_PDF;
						assetBean.setFormat(format);
					}else if(formatType.equalsIgnoreCase(JHMNConstants.PPT_FORMAT)|| formatType.equalsIgnoreCase(JHMNConstants.PPT1_FORMAT)){	
						format = JHMNConstants.TAG_FORMAT_PPT;
						assetBean.setFormat(format);
					}else if(formatType.equalsIgnoreCase(JHMNConstants.DOC_FORMAT)||formatType.equalsIgnoreCase(JHMNConstants.DOC1_FORMAT) ){
						format = JHMNConstants.TAG_FORMAT_DOC;
						assetBean.setFormat(format);
					}else if(formatType.equalsIgnoreCase(JHMNConstants.EXCEL_FORMAT) || formatType.equalsIgnoreCase(JHMNConstants.EXCEL1_FORMAT)){
						format	 = JHMNConstants.TAG_FORMAT_EXCEL;
						assetBean.setFormat(format);	
					}else if(formatType.equalsIgnoreCase(JHMNConstants.AUDIO_FORMAT)){
						format	 = JHMNConstants.TAG_FORMAT_AUDIO;
						assetBean.setFormat(format);	
					}else if(formatType.equalsIgnoreCase(JHMNConstants.VIDEO_FORMAT)){
						format	 = JHMNConstants.TAG_FORMAT_VIDEO;
						assetBean.setFormat(format);	
					}else if(formatType.equalsIgnoreCase(JHMNConstants.TOOL_FORMAT)||formatType.equalsIgnoreCase(JHMNConstants.TOOL1_FORMAT)){
						format	 = JHMNConstants.TAG_FORMAT_TOOL;
						assetBean.setFormat(format);
					}else if(formatType.equalsIgnoreCase(JHMNConstants.IMAGE_FORMAT)){
						format	 = JHMNConstants.TAG_FORMAT_IMAGE;
						assetBean.setFormat(format);
					}
					assetBean = setIcon(format, assetBean);
					if (format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_PDF) || format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_IMAGE)) {
						assetBean.setImagePath(asset.getRendition(JHMNConstants.IMAGE_RENDITION_30_42) != null
								? asset.getPath() + ".thumb.32.40.png" : asset.getPath() + ".thumb.48.48.png");
						assetBean.setGlypIcon(JHMNConstants.EMPTY_STRING);
					} else {
						assetBean.setImagePath(JHMNConstants.EMPTY_STRING);
					}
				}  		
			} 
			}
		}catch (Exception e) {
			LOG.error("RepositoryException occured" ,e);
		}
		LOG.debug("End of retrieveAssetBean method");
		return assetBean;
	}


	private static AssetMetaDataBean setIcon(String format, AssetMetaDataBean assetBean) {

		if (format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_DOC)){
			assetBean.setGlypIcon("glyphicon glyphicon-file");
		} else if (format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_PPT)) {
			assetBean.setGlypIcon("glyphicon glyphicon-blackboard");
		}else if(format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_AUDIO)){
			assetBean.setGlypIcon("glyphicon glyphicon-music");
		}else if (format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_VIDEO)) {
			assetBean.setGlypIcon("glyphicon glyphicon-video");
		}else if (format.equalsIgnoreCase(JHMNConstants.TAG_FORMAT_TOOL)) {
			assetBean.setGlypIcon("glyphicon glyphicon-wrench");
		}

		return assetBean;
	}


	/**
	 * Method to extract the last modified date
	 *
	 * @param Jcrnode 
	 * 
	 * @return Date(String Format)
	 * @throws RepositoryException
	 * @throws ParseException
	 * @throws ParseException
	 */

	private static String getLastModified(Node assetNode)
			throws ValueFormatException, PathNotFoundException, RepositoryException, ParseException {
		LOG.debug("Starting of getLastModified method");
		Date date = null;
		String dateString = null;
		String dt = "";
		LOG.debug("date is " + assetNode);
		if (assetNode.hasNode("jcr:content")) {
			Node jcrNode = assetNode.getNode("jcr:content");
			if (jcrNode != null && jcrNode.hasProperty(JHMNConstants.ASSET_LAST_MODIFIED)) {
				dateString = jcrNode.getProperty(JHMNConstants.ASSET_LAST_MODIFIED).getString();
				LOG.debug("date last Modified " + dateString);
				DateFormat format = new SimpleDateFormat(JHMNConstants.DATE_FORMAT_YYYY_MM_DD);
				date = format.parse(dateString);
				DateFormat fmt = new SimpleDateFormat(JHMNConstants.CUSTOM_DATE_FORMAT);
				dt = fmt.format(date);
				LOG.debug("date is " + dt);
			}
		}
		LOG.debug("End of getLastModified method");
		return dt;
	}
	public static ArrayList<AssetMetaDataBean> sortAssetList(ArrayList<AssetMetaDataBean> beanList) {

		 Collections.sort(beanList, new Comparator<Object>() {
		        public int compare(Object o1, Object o2) {
		            String x1 = ((AssetMetaDataBean) o1).getPriority();
		            String x2 = ((AssetMetaDataBean) o2).getPriority();
		            int sComp = x1.compareTo(x2);
		               return sComp;
		    }});
			
	return beanList;
}
}
