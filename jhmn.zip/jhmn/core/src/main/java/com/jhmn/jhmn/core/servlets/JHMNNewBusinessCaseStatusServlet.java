package com.jhmn.jhmn.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.jhmn.jhmn.core.interfaces.JHMNNewBusinessCaseStatusService;


@SlingServlet( paths = "/bin/sling/bermudaNBCS",metatype=true, methods = HttpConstants.METHOD_POST )
@Properties({ @Property(name = "service.description", value = "Bermuda New Business Case Status"),
	@Property(name = "service.vendor", value = "JHMN")})
public class JHMNNewBusinessCaseStatusServlet extends SlingAllMethodsServlet { 
	@Reference
	JHMNNewBusinessCaseStatusService nbcsService;
	private static final Logger LOG = LoggerFactory.getLogger(JHMNNewBusinessCaseStatusServlet.class);
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException  {
		LOG.info("Start of JHMNNewBusinessCaseStatusServlet");
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String sortBy = xssAPI.filterHTML((String)request.getParameter("sortBy"));
		String policyNumber = xssAPI.filterHTML((String)request.getParameter("policyNumber"));
		String userName = xssAPI.filterHTML((String)request.getParameter("userName"));
		String userRole = xssAPI.filterHTML((String)request.getParameter("userRole"));
		String appId = xssAPI.filterHTML((String)request.getParameter("appId"));
		String finalResponse = nbcsService.getNewBusinessCaseStatus(sortBy,policyNumber,userName,userRole,appId);
		LOG.debug("NBCS final response"+finalResponse);
		PrintWriter out = response.getWriter();
		out.write(xssAPI.getValidJSON(finalResponse, null));
		out.flush();
		out.close();
		LOG.info("End of JHMNNewBusinessCaseStatusServlet");		
	}

}
