package com.jhmn.jhmn.core.bean;

import java.util.ArrayList;

public class TagBean {
	private String tagID;
	private String name;
	private String title;
	private String level;
	private int count;
	private boolean hasChild;
	private ArrayList<TagBean> tagBeans;

	public String getTagID() {
		return tagID;
	}
	public void setTagID(String tagID) {
		this.tagID = tagID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public boolean isHasChild() {
		return hasChild;
	}
	public void setHasChild(boolean hasChild) {
		this.hasChild = hasChild;
	}

	public ArrayList<TagBean> getTagBeans() {
		return tagBeans;
	}
	public void setTagBeans(ArrayList<TagBean> tagBeans) {
		this.tagBeans = tagBeans;
	}
}
