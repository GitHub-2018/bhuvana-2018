package com.jhmn.jhmn.core.interfaces;

public interface NBCSConfigService {

	public String getProperty(final String property);
}
