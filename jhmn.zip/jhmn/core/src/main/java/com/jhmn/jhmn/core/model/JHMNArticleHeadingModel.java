package com.jhmn.jhmn.core.model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.helper.JHMNDateHelper;

@Model(adaptables =SlingHttpServletRequest.class)
public class JHMNArticleHeadingModel {
	private static Logger LOG = LoggerFactory.getLogger(JHMNArticleHeadingModel.class);


	@Inject
	private String pagePath;

	@Inject
	private SlingHttpServletRequest request;

	private String pageTitle;
	private String date;
	private String channel;


	@PostConstruct
	protected void init() throws PathNotFoundException, RepositoryException, ParseException
	{	
		pageTitle=null;
		Resource resource=request.getResourceResolver().getResource(pagePath);
		if(resource!=null){
			Page currentPage =resource.adaptTo(Page.class);
			if(currentPage!=null)
			{
				if(currentPage.getTitle()!=null){
				pageTitle=currentPage.getTitle();
				}
				channel= getChannelTitle(currentPage); 
			}
			date=getDate(resource);
			}
		}		
	/**
	 * Method to retrieve date jcr:created/cq:lastReplicated of currentPage
	 * @param resource
	 * @return
	 */

	private String getDate(Resource resource) throws PathNotFoundException, RepositoryException, ParseException {
		date=null;
		String dt=null;
		Node rootNode=resource.adaptTo(Node.class);
		if(rootNode!=null &&rootNode.hasNode(JHMNConstants.JCR_CONTENT))
		{
			Node jcrNode=rootNode.getNode(JHMNConstants.JCR_CONTENT);
			if(jcrNode!=null){
				if(jcrNode.hasProperty(JHMNConstants.PAGE_LAST_MODIFIED)){
					date=jcrNode.getProperty(JHMNConstants.PAGE_LAST_MODIFIED).getValue().getString();
				}
				if(jcrNode.hasProperty(JHMNConstants.ASSET_LAST_REPLICATED)){
					date=jcrNode.getProperty(JHMNConstants.ASSET_LAST_REPLICATED).getValue().getString();
				}
				
				if(date!=null){
					DateFormat format = new SimpleDateFormat(JHMNConstants.DATE_FORMAT_YYYY_MM_DD);
					Date pdate = format.parse(date);	
					dt=JHMNDateHelper.convertDateToString(pdate,JHMNConstants.DATE_FORMAT);
				}
			}

		}
		

		return dt;
	}

	/**
	 * Method to fetch the channel title for page
	 * @param currentPage
	 * @return channel
	 */
	private String getChannelTitle(Page currentPage) {
		channel = null;

		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHMNConstants.PARAM_CHANNEL)) {
				channel = tag.getTitle();
			}
		}
		return channel;
	}

	public String getPageTitle() {
		return pageTitle;
	}
	public String getDate() {
		return date;
	}
	public String getChannel() {
		return channel;
	}




}
