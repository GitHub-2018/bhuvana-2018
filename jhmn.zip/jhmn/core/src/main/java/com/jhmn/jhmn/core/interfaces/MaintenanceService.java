package com.jhmn.jhmn.core.interfaces;

import javax.jcr.Node;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONObject;

public interface MaintenanceService {

	public boolean getStatus(Node maintenanceNode);
	public String getMessage(Node maintenanceNode);
	public JSONObject getJsonResponse(String domain, boolean status, String message);
}
