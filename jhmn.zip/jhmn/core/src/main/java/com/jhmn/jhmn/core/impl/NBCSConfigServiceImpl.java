package com.jhmn.jhmn.core.impl;

import java.io.IOException;
import java.util.Dictionary;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhmn.jhmn.core.interfaces.NBCSConfigService;


@Service
@Component(immediate = true, metatype = true, name = "NBCSConfigServiceImpl", description = "Programatically get  properties of OSGi configurations.")
public class NBCSConfigServiceImpl implements NBCSConfigService {

	private static final Logger LOG = LoggerFactory.getLogger(NBCSConfigServiceImpl.class);
	public static final String NBCS_CONFIG_PID= "com.jhmn.jhmn.core.impl.NBCSConfigServiceImpl";
	public static final String UNCHECKED="unchecked";
	
	@Reference
	private ConfigurationAdmin configAdmin;
	
	public String getProperty(final String property) {
		String propertyValue ="" ;
		try {
			Configuration conf = configAdmin.getConfiguration(NBCS_CONFIG_PID);
			@SuppressWarnings(UNCHECKED)
			Dictionary<String, Object> properties = conf.getProperties();
			if (properties != null && !properties.isEmpty()) {
					if (properties.get(property) != null) {
						propertyValue = properties.get(property).toString();
					}
			}
		} catch (IOException e) {
			LOG.error("IOException",e);
		}
		return propertyValue;
		
	}
}
