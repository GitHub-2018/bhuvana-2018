package com.jhmn.jhmn.core.impl;

import java.text.ParseException;
import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhmn.jhmn.core.constants.JHMNNewsConstants;
import com.jhmn.jhmn.core.helper.JHMNArticleHelper;
import com.jhmn.jhmn.core.interfaces.JHMNBusinessService;

public class JHMNNewsBusinessServiceImpl implements JHMNBusinessService{
	
	private static final Logger LOG = LoggerFactory.getLogger(JHMNNewsBusinessServiceImpl.class);
	
	@Override
	public JSONObject getJSONResponse(Map<String, Object> mapObj)
			throws RepositoryException, JSONException, ParseException {
		
		JSONObject jsonObject = new JSONObject();
		String function = mapObj.get(JHMNNewsConstants.PARAM_FUNCTIONALITY).toString();
		Map<String, Object> resultMap = null;
			
		if(function.equalsIgnoreCase(JHMNNewsConstants.ALL_NEWS)){
			LOG.debug("Functionality = ALL_NEWS");	
			resultMap = JHMNArticleHelper.getAllNews(mapObj);
			LOG.debug("returnObj::::::::::::::::::::::"+resultMap.size());
			jsonObject = JHMNArticleHelper.transferNewsDetailstoJSONobj(resultMap);
		}
		if(function.equalsIgnoreCase(JHMNNewsConstants.MY_NEWS)){
			LOG.debug("Functionality = MY_NEWS");	
			resultMap = JHMNArticleHelper.getAllNews(mapObj);
			jsonObject = JHMNArticleHelper.transferNewsDetailstoJSONobj(resultMap);
		}
		return jsonObject;
	}

}
