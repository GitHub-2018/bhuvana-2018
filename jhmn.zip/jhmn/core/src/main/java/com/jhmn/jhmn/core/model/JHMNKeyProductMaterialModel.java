package com.jhmn.jhmn.core.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhmn.jhmn.core.bean.AssetMetaDataBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.helper.JHMNAssetHelper;
import com.jhmn.jhmn.core.helper.JHMNMTMultiCompositeFieldHelper;

@Model(adaptables = SlingHttpServletRequest.class)
public class JHMNKeyProductMaterialModel {
	private static Logger LOG = LoggerFactory.getLogger(JHMNKeyProductMaterialModel.class);

	@Inject
	private String nodePath;
	@Inject
	private String nodeName;

	@Inject
	private SlingHttpServletRequest request;

	private ArrayList<HashMap<String, String>> multivalues;

	@PostConstruct
	protected void init() throws RepositoryException
	{	
		ResourceResolver resourceResolver=request.getResourceResolver();
		Resource resource=resourceResolver.getResource(nodePath);
		Node node=resource.adaptTo(Node.class);
		String[] listValue={"type","link"};
		multivalues=JHMNMTMultiCompositeFieldHelper.getMultiCompositeValuesArrayList(node.getPath(),nodeName,listValue,request);	
	}

	public ArrayList<HashMap<String, String>> getMultivalues() {
		return multivalues;
	}


}

