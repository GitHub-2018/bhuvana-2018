package com.jhmn.jhmn.core.search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.facets.Bucket;
import com.day.cq.search.facets.Facet;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.ResultPage;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhmn.jhmn.core.bean.PageInfoBean;
import com.jhmn.jhmn.core.bean.SearchParameter;
import com.jhmn.jhmn.core.bean.SearchResultTO;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.constants.JHMNSearchConstants;
import com.jhmn.jhmn.core.helper.JHMNSearchHelper;
import com.jhmn.jhmn.core.interfaces.JHMNFormatType;


public class SiteSearchService {

	private static final Logger LOG = LoggerFactory.getLogger(SiteSearchService.class);
	private int queryCount;
	private int groupValue;
	private String resultsPerPage;
	private String queryParam2 = "";
	private long page = 1;
	private long offset;
	private Map<String, Map<String, SearchParameter>> formatAndTypes = new HashMap<String, Map<String, SearchParameter>>();
	private Map<String, String> tagList = new HashMap<String, String>();
	private String query = "";

	public SiteSearchService(SlingHttpServletRequest request) {
		this.queryCount = 0;
		this.groupValue = 0;
		
		String query = request.getParameter(JHMNSearchConstants.QUERY_PARAM_NAME) != null
				? request.getParameter(JHMNSearchConstants.QUERY_PARAM_NAME)
				: request.getParameter(JHMNSearchConstants.QUERY2_PARAM_NAME);
		String query1 = request.getParameter(JHMNSearchConstants.QUERY1_PARAM_NAME) != null
				? request.getParameter(JHMNSearchConstants.QUERY1_PARAM_NAME)
				: request.getParameter(JHMNSearchConstants.QUERY21_PARAM_NAME);
		String option = request.getParameter(JHMNSearchConstants.OPTION_PARAM_NAME);

		if (request.getParameter(JHMNSearchConstants.CHARSET_PARAM_NAME) != null) {
			request.getParameter(JHMNSearchConstants.CHARSET_PARAM_NAME);
		}

		if (query != null) {
			if ("option1".equals(option)) {
				setQuery(query);
				LOG.debug("option1:::::"+getQuery());
			} else if ("option2".equals(option) && (query1 != null)) {
				setQuery(query);
				this.queryParam2 = query1;
				LOG.debug("option2:::::"+getQuery());
				LOG.debug("option2 queryparam::::"+this.queryParam2);
			}
		}
		if (request.getParameter(JHMNSearchConstants.PAGE_PARAM_NAME) != null) {

			this.page = Long.parseLong(request.getParameter(JHMNSearchConstants.PAGE_PARAM_NAME));

		}
		
		if (request.getAttribute("limit") != null) {
			this.resultsPerPage = (String) request.getAttribute("limit");
		}
		
		
		this.tagList = JHMNSearchHelper.setTagList(request, tagList);

	}

	/**
	 * Sets a new fulltext query that will be executed.
	 *
	 * @param query
	 *            the fulltext query.
	 */
	public void setQuery(String query) {
		this.query = query;
		
	}

	public String getQuery() {
		return query;
	}

	public SearchResultTO getResult(SlingHttpServletRequest request) {
		ArrayList<PageInfoBean> pageInfos = new ArrayList<PageInfoBean>();
		SearchResultTO searchResultTO = new SearchResultTO();
		long current;
		if (!query.isEmpty()) {
			final Query query = retrieveQuery(request);
			SearchResult searchRes = query.getResult();
			setFormatAndResourceType(searchRes, request);
			double totalResults = searchRes.getTotalMatches();
			long numberOfPages = (long) (totalResults / Integer.parseInt(resultsPerPage));
			if(totalResults % Integer.parseInt(resultsPerPage) > 0){
				numberOfPages += 1 ;
			}
			current = (offset / Long.parseLong(resultsPerPage)) + 1;
			
			long end = current + 2;
			if (end > numberOfPages) {
				end = (long) numberOfPages;
			}
			
			long endResult = offset + Integer.parseInt(resultsPerPage);
			if (endResult > totalResults) {
				endResult = (long) totalResults;
			}
			searchResultTO.setEnd(end);
			searchResultTO.setStart(current);
			searchResultTO.setEndResult(endResult);
			searchResultTO.setStartResult(offset + 1);
			searchResultTO.setCount(totalResults);
			searchResultTO.setNumberOfPages(numberOfPages);
			searchResultTO.setCurrentIndex(current);
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					try {
						String queryPath = hit.getPath();
						PageInfoBean pageInfo = JHMNSearchHelper.retrivePageInfoBean(queryPath, request.getResourceResolver());
						pageInfos.add(pageInfo);
					} catch (PathNotFoundException e) {
						LOG.error("Path not found for the Hit in Site Search ", e);
					} catch (RepositoryException e) {
						LOG.error("Repository Exception in Site Search ", e);
					}

				}
			}
			searchResultTO = JHMNSearchHelper.getPagination(searchResultTO, numberOfPages, page, request);
			searchResultTO.setPageInfo(pageInfos);
		}
		return searchResultTO;

	}

	

	private Query retrieveQuery(SlingHttpServletRequest request) {
		QueryBuilder queryBuilder = request.getResourceResolver().adaptTo(QueryBuilder.class);
		Map<String, String> map = new HashMap<String, String>();
		this.offset = Long.parseLong(resultsPerPage) * (page - 1);
		
		addTopicToMap(map);
		map.put("path", "/content");
		map.put("1_group.p.or", "true");
		map.put("2_fulltext", query);
		if (!queryParam2.isEmpty()) {
			map.put("3_fulltext", queryParam2);
		}
		map.put("p.offset", Long.toString(offset));
		queryCount = 3;
		if (tagList != null && !tagList.isEmpty()) {
			addFilterToMap(map, tagList);
		}
		map.put("p.limit", resultsPerPage);
		LOG.info("Site Search Service Map for query" + map);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), request.getResourceResolver().adaptTo(Session.class));
		return query;
	}

	private void addTopicToMap(Map<String, String> map) {
		
		map.put("1_group.1_property.value", "MNBD:topic/"+ "%");
        map.put("1_group.1_property", "jcr:content/cq:tags"); 
        map.put("1_group.1_property.operation", "like"); 
        map.put("1_group.2_property.value", "MNBD:topic/"+ "%");
        map.put("1_group.2_property", "jcr:content/metadata/cq:tags"); 
        map.put("1_group.2_property.operation", "like");
        map.put("1_group.3_property", "jcr:content/metadata/dc:format");
        map.put("1_group.3_property.value","*");
       

	}

	public void setFormatAndResourceType(SearchResult searchRes, SlingHttpServletRequest request) {
		
		try {
			BundleContext bundleContext = FrameworkUtil.getBundle(JHMNFormatType.class).getBundleContext();
			ServiceReference serviceReference = (ServiceReference)bundleContext.getServiceReference(JHMNFormatType.class.getName());
			JHMNFormatType formatType = (JHMNFormatType)bundleContext.getService(serviceReference);
			Map<String, String> formatTypeMap = formatType.getConfigProperty(JHMNConstants.FORMAT_TYPE);
			
			Map<String, Facet> facetsmap = searchRes.getFacets();
		
			Map<String, SearchParameter> mapFormat = new HashMap<String, SearchParameter>();
			Map<String, SearchParameter> mapResourceType = new HashMap<String, SearchParameter>();
		
		
			for (Map.Entry<String, Facet> entry : facetsmap.entrySet()) {
			
				String key = entry.getKey();
				Facet facet = facetsmap.get(key);
			
				if (facet.getContainsHit()) {
					TagManager tagManager = request.getResourceResolver().adaptTo(TagManager.class);
				
					for (Bucket bucket : facet.getBuckets()) {
						String value = bucket.getValue();
						double count = bucket.getCount();
					
						Tag tag = tagManager.resolve(value);
						 
						if (key.equalsIgnoreCase("1_group.3_property")) {
							SearchParameter searchParameter = new SearchParameter();
							// get the lable name corresponding to the dc:format ie. get PDF from application/PDF
							if(formatTypeMap.containsKey(value)){
								LOG.info("key from formattype"+value);
								String labelName = formatTypeMap.get(value);
								LOG.info("labelName from formattype"+value);
								searchParameter.setCategoryCount(count);
								searchParameter.setCategoryValue(value);
								searchParameter.setCategoryKey(labelName);
								if(mapFormat.containsKey(labelName)){
									LOG.info("already present in map "+labelName);
									SearchParameter srchParameter = mapFormat.get(labelName);
									srchParameter.setCategoryCount(srchParameter.getCategoryCount()+count);
									srchParameter.setCategoryValue(srchParameter.getCategoryValue()+","+value);
									mapFormat.put(srchParameter.getCategoryKey(), srchParameter);
								}else{
									mapFormat.put(searchParameter.getCategoryKey(), searchParameter);
								}
							}
						} else if (value.startsWith("MNBD:type") && (key.equalsIgnoreCase("1_group.1_property")||key.equalsIgnoreCase("1_group.2_property") )) {
							SearchParameter searchParameter = new SearchParameter();
							if(tag!=null){
							searchParameter.setCategoryKey(tag.getTitle());
							
							searchParameter.setCategoryCount(count);
							searchParameter.setCategoryValue(value);
							if(mapResourceType.get(value)!=null){
								SearchParameter srchParameter = mapResourceType.get(value);
								srchParameter.setCategoryCount(srchParameter.getCategoryCount()+count);
								mapResourceType.put(value, srchParameter);
							}else{
								mapResourceType.put(value, searchParameter);
							}
							}
						} 
					}
					
				}
			}
			//JHSearchHelper.setFormatMapZero(mapFormat, request);
			/*
			 * commenting this line since the resourcetype is a large list , so
			 * displaying only the list with count
			 */
		 JHMNSearchHelper.setResourceTypeMapZero(mapResourceType, request);
			this.formatAndTypes.put("format", mapFormat);
			this.formatAndTypes.put("type", mapResourceType);

		} catch (RepositoryException e) {
			LOG.error("Repository Exception" , e);
		}

	}
	

	public void addFilterToMap(Map<String, String> map, Map<String, String> tagList, int tempCount) {
		queryCount = tempCount;
		addFilterToMap(map, tagList);
	}

	public void addFilterToMap(Map<String, String> map, Map<String, String> tagList) {

		for (Map.Entry<String, String> entry : tagList.entrySet()) {
			String tagName = entry.getKey();
			String tagValue = entry.getValue();
			String[] tagValueArray = tagValue.split(",");
			 if ("format".equalsIgnoreCase(tagName)) {
				if(tagValueArray.length>0){
					addFormatsToQuery(map,tagValueArray);
				}
				else{
				queryCount++;
				map.put(queryCount + "_property.value", tagValue);
				map.put(queryCount + "_property", "@jcr:content/metadata/dc:format");
				}
			}else if (tagValueArray.length > 0) {
				addTagsToQuery(map, tagValueArray);
			} else {
				addTagsToQuery(map, tagValue);
			}

		}

	}

	private Map<String, String> addFormatsToQuery(Map<String, String> map, String[] tagValueArray) {
		groupValue = 0;
		queryCount++;
		for (String format : tagValueArray) {
			map.put(queryCount + "_group." + ++groupValue + "_property.value", format);
			map.put(queryCount + "_group." + groupValue + "_property", "jcr:content/metadata/dc:format");
		}
		map.put(queryCount + "_group.p.or", "true");
		return map;
	}
	
	private Map<String, String> addTagsToQuery(Map<String, String> queryMap, String tagValue) {
		groupValue = 0;
		queryCount++;
		queryMap.put(queryCount + "_group." + ++groupValue + "_property.value", tagValue);
		queryMap.put(queryCount + "_group." + groupValue + "_property", "jcr:content/cq:tags");
		queryMap.put(queryCount + "_group." + ++groupValue + "_property.value", tagValue);
		queryMap.put(queryCount + "_group." + groupValue + "_property", "jcr:content/metadata/cq:tags");

		queryMap.put(queryCount + "_group.p.or", "true");
		return queryMap;
	}

	private Map<String, String> addTagsToQuery(Map<String, String> queryMap, String[] tagValueArray) {
		groupValue = 0;
		queryCount++;
		for (String tag : tagValueArray) {

			queryMap.put(queryCount + "_group." + ++groupValue + "_property.value", tag);
			queryMap.put(queryCount + "_group." + groupValue + "_property", "jcr:content/cq:tags");
			queryMap.put(queryCount + "_group." + ++groupValue + "_property.value", tag);
			queryMap.put(queryCount + "_group." + groupValue + "_property", "jcr:content/metadata/cq:tags");

		}
		queryMap.put(queryCount + "_group.p.or", "true");
		return queryMap;
	}

	public boolean getPreviousPage(SearchResult result) throws RepositoryException {
		ResultPage previous = result.getPreviousPage();
		if (previous != null) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	/**
	 * @param result
	 * @return the page, which contains the information about the next page.
	 *         Returns <code>null</code> if there is no next page (i.e. the
	 *         current page is the last page).
	 * @throws RepositoryException
	 *             if an error occurs while reading from the query result.
	 */
	public boolean getNextPage(SearchResult result) throws RepositoryException {
		ResultPage next = result.getNextPage();

		if (next != null) {
			next.getStart();
			return true;
		} else {
			return false;
		}
	}

	public Map<String, Map<String, SearchParameter>> getFormatAndResourceType() {
		return formatAndTypes;
	}

}
