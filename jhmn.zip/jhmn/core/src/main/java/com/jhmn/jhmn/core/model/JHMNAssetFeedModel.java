package com.jhmn.jhmn.core.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.Resource;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhmn.jhmn.core.bean.AssetMetaDataBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.helper.JHMNAssetHelper;


@Model(adaptables = Resource.class)
public class JHMNAssetFeedModel {
	private static Logger LOG = LoggerFactory.getLogger(JHMNAssetFeedModel.class);

	@Inject
	private String product;

	@Inject
	private String productType;

	@Inject
	private ResourceResolver resourceResolver;
	
	private static Session session = null;
	private ArrayList<AssetMetaDataBean> assetBeanList;
	private boolean displaySeeMore=false;

	

	@PostConstruct
	protected void init()
	{	
		TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
		Tag productTag = tagManager.resolve(product);
		Tag typeTag = tagManager.resolve(productType);
		assetBeanList = new ArrayList<AssetMetaDataBean>();
		AssetMetaDataBean assetbean=null;
		try {
			QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
			session = resourceResolver.adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_property",JHMNConstants.CQ_TAGS_METADATA_PROPERTYNAME);
			map.put("1_property.value", productTag.getTagID());
			map.put("2_property",JHMNConstants.CQ_TAGS_METADATA_PROPERTYNAME);
			map.put("2_property.value", typeTag.getTagID());
			map.put("p.limit", "-1");
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			if(searchRes!=null){
				if(searchRes.getHits().size()>8)
				{
					displaySeeMore=true;
				}
				if (!searchRes.getHits().isEmpty()) {
					for (Hit hit : searchRes.getHits()) {
						String queryPath = hit.getPath();
						assetbean = JHMNAssetHelper.retrieveAssetBean(queryPath,resourceResolver);
						assetBeanList.add(assetbean);
						assetBeanList=JHMNAssetHelper.sortAssetList(assetBeanList);
						LOG.debug("Final reach size is *********************************** "+assetBeanList.size());
					}	
				}	
				
			}
		}
		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e);
		}
		LOG.info("produt selected is "+product);

	}

	public ArrayList<AssetMetaDataBean> getAssetBeanList() {
		return assetBeanList;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}
	public boolean isDisplaySeeMore() {
		return displaySeeMore;
	}


}
