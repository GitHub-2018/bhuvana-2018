package com.jhmn.jhmn.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.constants.JHMNNewsConstants;
import com.jhmn.jhmn.core.impl.JHMNNewsBusinessServiceImpl;
import com.jhmn.jhmn.core.interfaces.JHMNBusinessService;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JHMN AJAX Servlet"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/JHMNAJAX" }),
		@Property(name = "service.vendor", value = "JHMN"),
		@Property(name = "sling.servlet.methods", value = "POST", propertyPrivate = true) })
public class JHMNAjaxServlet extends SlingSafeMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(JHMNAjaxServlet.class);

	private static final long serialVersionUID = 1L;
	
	 @Override
	    protected void doGet(final SlingHttpServletRequest request,
	            final SlingHttpServletResponse response) throws ServletException, IOException {
		 this.doPost(request, response);
	    }

	 protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) {
			try {
				response.setContentType(JHMNNewsConstants.CONTENT_TYPE);
				String type = request.getParameter(JHMNNewsConstants.PARAM_TYPE); //type of request coming in ; whether Asset or News
				String currentPath=request.getParameter(JHMNNewsConstants.CURRENTPAGE);
		
				Map<String, Object> mapObj = new HashMap<String, Object>();
				
				if (request.getParameter(JHMNNewsConstants.PARAM_CHANNEL) != null) {
					mapObj.put(JHMNNewsConstants.PARAM_CHANNEL,
							URLDecoder.decode(request.getParameter(JHMNNewsConstants.PARAM_CHANNEL), "UTF-8"));
				}
				if (request.getParameter(JHMNNewsConstants.PARAM_CHANNELS) != null) {
					mapObj.put(JHMNNewsConstants.PARAM_CHANNELS,
							URLDecoder.decode(request.getParameter(JHMNNewsConstants.PARAM_CHANNELS), "UTF-8"));
				}
				if (request.getParameter(JHMNNewsConstants.PARAM_FUNCTIONALITY) != null) {
					mapObj.put(JHMNNewsConstants.PARAM_FUNCTIONALITY,
							URLDecoder.decode(request.getParameter(JHMNNewsConstants.PARAM_FUNCTIONALITY), "UTF-8"));
				}
				if (request.getParameter(JHMNNewsConstants.PARAM_LIMIT) != null) {
					mapObj.put(JHMNNewsConstants.PARAM_LIMIT,
							URLDecoder.decode(request.getParameter(JHMNNewsConstants.PARAM_LIMIT), "UTF-8"));
				}
				if (request.getParameter(JHMNNewsConstants.PARAM_PAGE_NO) != null) {
					mapObj.put(JHMNNewsConstants.PARAM_PAGE_NO, URLDecoder.decode(request.getParameter(JHMNNewsConstants.PARAM_PAGE_NO),"UTF-8"));
				}
				mapObj.put(JHMNConstants.SLING_REQUEST, request);
				
				JSONObject json = new JSONObject();

				if (type.equals(JHMNConstants.NEWS_TYPE)) {

					JHMNBusinessService serviceImpl = new JHMNNewsBusinessServiceImpl();
					try {
						json = serviceImpl.getJSONResponse(mapObj);
					} catch (JSONException e) {
						LOG.error("Exception in JHMNAjaxServlet for news type" , e);
					} catch (ParseException e) {
						LOG.error("Exception in JHMNAjaxServlet for news type" , e);
					}
				}
				PrintWriter out = response.getWriter();
				out.println(json);
				out.flush();
			}catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			} catch (RepositoryException e) {
				LOG.error("Repoistory Exception in JHMNAjaxServlet" , e);
			}
	}
}
