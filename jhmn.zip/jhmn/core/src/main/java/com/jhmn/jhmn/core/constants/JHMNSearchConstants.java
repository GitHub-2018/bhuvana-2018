package com.jhmn.jhmn.core.constants;

public class JHMNSearchConstants {
	public static final String CQ_TEMPLATE="@jcr:content/cq:template";
	public static final String ARTICLE_TEMPLATE = "/apps/jhmn/templates/jhmnarticletemplate";
	public static final String LAST_REPLICATED = "@jcr:content/cq:lastReplicated";
	public static final String DAM_PATH = "/content/dam/MNBD";
	public static final String NEWS_PAGES_PATH = "/content/MNBD";
	public static final String PARAM_RESOURCE_TYPE = "format";
	public static final String PARAM_DESCRIPTION = "description";
	public static final String CHARSET_PARAM_NAME = "_charset_";
	public static final String QUERY_PARAM_NAME = "q";
	public static final String START_PARAM_NAME = "start";
	public static final String PAGE_PARAM_NAME = "page";
	public static final String OPTION_PARAM_NAME = "option";
	public static final String QUERY1_PARAM_NAME = "q1";
	public static final String QUERY2_PARAM_NAME = "q2";
	public static final String QUERY21_PARAM_NAME = "q21";
	
}
