package com.jhmn.jhmn.core.bean;

public class PageInfoBean {
	private String pageTitle = "";
	private String pageDesc = "";
	private String pageURL = "";
	private String pageResourceType = "";

	public String getPageTitle() {
		return pageTitle;
	}
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	public String getPageDesc() {
		return pageDesc;
	}
	public void setPageDesc(String pageDesc) {
		this.pageDesc = pageDesc;
	}
	public String getPageURL() {
		return pageURL;
	}
	public void setPageURL(String pageURL) {
		this.pageURL = pageURL;
	}
	public String getPageResourceType() {
		return pageResourceType;
	}
	public void setPageResourceType(String pageResourceType) {
		this.pageResourceType = pageResourceType;
	}


}
