package com.jhmn.jhmn.core.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.interfaces.JHMNNewBusinessCaseStatusService;
import com.jhmn.jhmn.core.interfaces.NBCSConfigService;

@Component
@Service

public class JHMNNewBusinessCaseStatusServiceImpl implements JHMNNewBusinessCaseStatusService {
	@Reference
	private NBCSConfigService configService;
	
	@Reference
	private ResourceResolverFactory resolverFactory;
	
	private static final Logger LOG = LoggerFactory.getLogger(JHMNNewBusinessCaseStatusServiceImpl.class);
	public String getNewBusinessCaseStatus(String sortBy,String policyNumber,String userName,String userRole,String appId)
	{
		String responseData=null;
		String policyID=null;
		String result =null;
		JSONObject jsonObject = new JSONObject();
		JSONObject resJsonObj = new JSONObject();
		try {
			if(!userRole.isEmpty() && userRole.equalsIgnoreCase(JHMNConstants.PRODUCER))
			{
				jsonObject.put(JHMNConstants.SORT_BY, sortBy);
				jsonObject.put(JHMNConstants.POLICY_NUMBER, policyNumber);
				jsonObject.put(JHMNConstants.USER_NAME, userName);
				jsonObject.put(JHMNConstants.USER_ROLE, userRole);
				jsonObject.put(JHMNConstants.APP_ID, appId);
			}
			else{
				jsonObject.put(JHMNConstants.POLICY_NUMBER, policyNumber);
				jsonObject.put(JHMNConstants.USER_ROLE, userRole);
				jsonObject.put(JHMNConstants.APP_ID, appId);
			}
			StringEntity input = new StringEntity(jsonObject.toString());
			LOG.debug("input JSON"+jsonObject.toString());
			result = getPolicyID(input,userRole,userName,appId);

			LOG.debug("response obtained is ********** "+result);
		}
		catch (JSONException e) {
			LOG.error("JSONException", e);
		} catch (UnsupportedEncodingException e) {			
			LOG.error("UnsupportedEncodingException", e);
		} catch (IOException e) {			
			LOG.error("IOException", e);
		}
		return result;
	}
	private String getPolicyID(StringEntity input,String userRole,String userName,String appId) {
		String responseData = null;
		String policyID= null;
		String insuredLastName = null;
		String policyNumber = null;
		String emailSubject = null;
		int statusCode;
		JSONObject policySearchJobject = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();		
		try {
			String policySearchURL=configService.getProperty(JHMNConstants.POLICY_SEARCH_URL);
			HttpPost postRequest = new HttpPost(policySearchURL);		
			postRequest.setEntity(input);
			postRequest.addHeader(JHMNConstants.CONTENT_TYPE, JHMNConstants.APPLICATION_JSON);
			postRequest.addHeader(JHMNConstants.APPLICATION, JHMNConstants.BUSINESS_POLICY);
			CloseableHttpResponse response = httpClient.execute(postRequest);								
			statusCode=response.getStatusLine().getStatusCode();
			LOG.debug("Tibco policy search service status code"+statusCode);
			if(statusCode==200){
				responseData = EntityUtils.toString(response.getEntity(), JHMNConstants.CHARSET);
				policySearchJobject= new JSONObject(responseData);
				LOG.debug("Tibco policy search success response"+responseData);
				if(policySearchJobject.has("PolicySearch_response") && policySearchJobject.getJSONObject("PolicySearch_response").has("newBusinessCaseList")){
					policyID =policySearchJobject.getJSONObject("PolicySearch_response").getJSONObject("newBusinessCaseList").getString("policyId");
					insuredLastName =policySearchJobject.getJSONObject("PolicySearch_response").getJSONObject("newBusinessCaseList").getString("insuredLastName");
					policyNumber =policySearchJobject.getJSONObject("PolicySearch_response").getJSONObject("newBusinessCaseList").getString("policyNumber");
					policyNumber="XXXX"+policyNumber.substring(4,8);
					emailSubject=insuredLastName+"-"+policyNumber;
					responseData=getPolicyStatus(policyID,userRole,userName,emailSubject,appId);					
				}
				else{
					statusCode=policySearchJobject.getJSONObject("PolicySearch_response").getInt("StatusCode");
					responseData=getErrorMessage(statusCode);
				}
			}
			else
			{					
				//statusCode=response.getStatusLine().getStatusCode();				
				LOG.info("status code is "+statusCode);
				if(statusCode >= 400 && statusCode <= 499 ){
					LOG.debug("Tibco policy search service app response"+EntityUtils.toString(response.getEntity(), JHMNConstants.CHARSET));
				}else{
					LOG.info("Tibco policy search service response"+EntityUtils.toString(response.getEntity(), JHMNConstants.CHARSET));
				}
				responseData=getErrorMessage(statusCode);
				LOG.info("Tibco policy search service final error response:"+responseData.toString());
			}
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}		
		return responseData;
	}
	
	private String getPolicyStatus(String policyID, String userRole,String userName,String emailSubject,String appId) {
		JSONObject policyStatusJobject = new JSONObject();
		String statusResponseData = null;
		JSONObject jObject = null;
		int statusCode;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			if(userRole.equalsIgnoreCase("Producer"))
			{
				policyStatusJobject.put(JHMNConstants.POLICY_ID,policyID);
				policyStatusJobject.put(JHMNConstants.USER_ROLE,userRole);
				policyStatusJobject.put(JHMNConstants.USER_NAME,userName);
				policyStatusJobject.put(JHMNConstants.APP_ID,appId);
			}
			else
			{
				policyStatusJobject.put(JHMNConstants.POLICY_ID,policyID);
				policyStatusJobject.put(JHMNConstants.USER_ROLE,userRole);
			}
			LOG.debug("input json for policy status is "+policyStatusJobject);
			StringEntity input = new StringEntity(policyStatusJobject.toString());
			String policyStatusURL=configService.getProperty(JHMNConstants.POLICY_STATUS_URL);
			HttpPost postRequest = new HttpPost(policyStatusURL);		
			postRequest.setEntity(input);
			postRequest.addHeader(JHMNConstants.CONTENT_TYPE, JHMNConstants.APPLICATION_JSON);
			postRequest.addHeader(JHMNConstants.APPLICATION, JHMNConstants.BUSINESS_POLICY);
			CloseableHttpResponse response = httpClient.execute(postRequest);			
			statusCode=response.getStatusLine().getStatusCode();
			LOG.debug("Tibco getPolicyStatus service status code"+statusCode);
			if(statusCode==200){				
				statusResponseData = EntityUtils.toString(response.getEntity(), JHMNConstants.CHARSET);	
				LOG.debug("Tibco getPolicyStatus service success response "+statusResponseData);
				jObject=new JSONObject(statusResponseData);			
				if(jObject.has("GetPolicyStatus_response") && jObject.getJSONObject("GetPolicyStatus_response").has("insuredDetails")){
					jObject.getJSONObject("GetPolicyStatus_response").put("emailSubject",emailSubject);
					statusResponseData =jObject.toString();
				}
				else{
					statusCode=jObject.getJSONObject("GetPolicyStatus_response").getInt("StatusCode");
					statusResponseData=getErrorMessage(statusCode);
				}
			}
			else{
				if(statusCode >= 400 && statusCode <= 499 ){
					LOG.debug("Tibco getPolicyStatus service app response"+EntityUtils.toString(response.getEntity(), JHMNConstants.CHARSET));
				}else{
					LOG.info("Tibco getPolicyStatus service response"+EntityUtils.toString(response.getEntity(), JHMNConstants.CHARSET));
				}
				statusResponseData=getErrorMessage(statusCode);
				LOG.info("Tibco getPolicyStatus service final error response:"+statusResponseData.toString());
			}
		} catch (JSONException e) {		
			LOG.error("JSONException", e);
		} catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException", e);
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		}
		return statusResponseData;
	}
	private String getErrorMessage(int statusCode) {
		Page pagePath;
		JSONObject jObject=new JSONObject();
		PageManager pageManager = getServiceResolver().adaptTo(PageManager.class);		
		pagePath = pageManager.getPage(JHMNConstants.BERMUDA_NBCS_ERRORLIST_PATH);
		String message = null;
		GenericList list = pagePath.adaptTo(GenericList.class);
		if(statusCode==0)
		{
			message=list.lookupTitle("0");
		}
		else if(statusCode==1)
		{
			message=list.lookupTitle("1");
		}
		else if(statusCode==2)
		{
			message=list.lookupTitle("2");
		}
		else{
			message = list.lookupTitle(JHMNConstants.DEFAULT);			
		}
		try {
			jObject.put("Error", message);
		} catch (JSONException e) {			
			LOG.error("JSONException", e);
		}
		message=jObject.toString();
		LOG.info("Custom Error message response:: "+message);
		return message;
	}
	private ResourceResolver getServiceResolver(){
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(ResourceResolverFactory.SUBSERVICE,JHMNConstants.JHMN_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			//resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
		} catch (LoginException e) {
			LOG.error("LoginException:", e);
		}
		return resourceResolver;
	}
}
