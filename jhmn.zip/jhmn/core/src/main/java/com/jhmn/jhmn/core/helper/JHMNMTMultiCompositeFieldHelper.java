package com.jhmn.jhmn.core.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *  Helper class for MTMultiCompositeField 
 * 
 * @version 1.0 09 May 2013
 * @author Cognizant Technology solutions
 * @since JDK 1.6.45
 */

public class JHMNMTMultiCompositeFieldHelper {

	private static final Logger LOG = LoggerFactory
			.getLogger(JHMNMTMultiCompositeFieldHelper.class);

	/**
	 * @param path
	 * @param nodename
	 * @param propertyNames
	 * @return
	 * @return
	 */
	public String[] getMultiCompositeFieldValues(String path, String nodename,
			String[] propertyNames, SlingHttpServletRequest slingRequest) {
		if (null != path && null != nodename && null != propertyNames) {
			try {
				String[] multiCompositeFieldValues;
				final ArrayList<String> fieldList = new ArrayList<String>();
				final Resource resource = slingRequest.getResourceResolver()
						.getResource(path+"/"+nodename);
				if(null!=resource && null!=resource.listChildren()){
					Iterator<Resource> iter= resource.listChildren();
					while(iter.hasNext()){
						final StringBuffer childNodeProprties = new StringBuffer();
						Resource res = (Resource)iter.next();
						ValueMap properties = res.getValueMap();
						for (final String propertyName : propertyNames) {
							if(properties.get(propertyName)!=null){
								childNodeProprties.append(properties.get(propertyName,String.class));
							}else {
								childNodeProprties.append(" ");
							}
							childNodeProprties.append(",");
						}
						fieldList.add(childNodeProprties.toString());
					}
					multiCompositeFieldValues = fieldList
							.toArray(new String[fieldList.size()]);
					return multiCompositeFieldValues;
				}else {
					LOG.error(nodename + " is not available in the path" + path);
					return null;
				}			
			} catch (final Exception e) {
				LOG.error("exception occured while retreiving compositevalues"
						, e);
				return null;
			}
		}
		return propertyNames;

	}
	
	/**
	 * @param path
	 * @param delimiter
	 * @param nodename
	 * @param propertyNames
	 * @return
	 * @return
	 */
	public String[] getMultiCompositeFieldValues(String path, String nodename,
			String[] propertyNames, SlingHttpServletRequest slingRequest, String delimiter) {
		String localDelim = ",";
		if (null != delimiter && delimiter.length() == 1){
			localDelim = delimiter;
		}
		if (null != path && null != nodename && null != propertyNames) {
			try {
				String[] multiCompositeFieldValues;
				final ArrayList<String> fieldList = new ArrayList<String>();
				final Resource resource = slingRequest.getResourceResolver()
						.getResource(path+"/"+nodename);
				if(null!=resource && null!=resource.listChildren()){
					Iterator<Resource> childResources = resource.listChildren();
					while(childResources.hasNext()){
						final StringBuffer childNodeProprties = new StringBuffer();
						Resource res= (Resource)childResources.next();
						ValueMap properties= res.getValueMap();
						for (final String propertyName : propertyNames) {
							if(properties.get(propertyName)!=null){
								childNodeProprties.append(properties.get(propertyName,String.class));
							}else {
								childNodeProprties.append(" ");
							}
							childNodeProprties.append(localDelim);
						}
						fieldList.add(childNodeProprties.toString());
					}
					multiCompositeFieldValues = fieldList
							.toArray(new String[fieldList.size()]);
					return multiCompositeFieldValues;
				} else {
					LOG.error(nodename + " is not available in the path" + path);
					return null;
				}
				

			} catch (final Exception e) {
				LOG.error("exception occured while retreiving compositevalues"
						, e);
				return null;
			}
		}
		return propertyNames;

	}
	
	public static ArrayList< HashMap<String, String>> getMultiCompositeValuesArrayList(String path, String nodename,
			String[] propertyNames, SlingHttpServletRequest slingRequest){
		 if (null != path && null != nodename && null != propertyNames) {
				try {
					
					final ArrayList<HashMap<String, String>> fieldList = new ArrayList<HashMap<String, String>>();
					final Resource resource = slingRequest.getResourceResolver()
							.getResource(path+"/"+nodename);
					if(null!=resource && null!=resource.listChildren()){
						Iterator<Resource> iter = resource.listChildren();
						while(iter.hasNext()){
							Resource childResource = (Resource)iter.next();
							ValueMap properties = childResource.getValueMap();
							
							HashMap<String, String> map = new HashMap<String, String>();

							for (final String propertyName : propertyNames) {
								if (null!=properties.get(propertyName)) {
									map.put(propertyName, properties.get(propertyName,String.class));
								} 
							}
							fieldList.add(map);
						}				
						return fieldList;
					}else {
						LOG.error(nodename + " is not available in the path" + path);
						return null;
					}

				} catch (final Exception e) {
					LOG.error("exception occured while retreiving compositevalues"
							, e);
					return null;
				}
			}
		return null;
		 		
		
	}
	


}
