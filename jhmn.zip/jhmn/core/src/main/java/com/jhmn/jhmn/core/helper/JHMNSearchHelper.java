package com.jhmn.jhmn.core.helper;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.ListIterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Value;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhmn.jhmn.core.bean.PageInfoBean;
import com.jhmn.jhmn.core.bean.SearchParameter;
import com.jhmn.jhmn.core.bean.SearchResultTO;
import com.jhmn.jhmn.core.bean.TagBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;


public class JHMNSearchHelper {

	private static final Logger LOG = LoggerFactory.getLogger(JHMNSearchHelper.class);
	static int count = 0;
	private static String[] levelString = { "zero", "first", "second", "third", "fourth", "fifth" }; // Support
	// five
	// levels
	// of
	// tag

	public static PageInfoBean retrivePageInfoBean(String queryPath, ResourceResolver resourceResolver)
			throws PathNotFoundException, RepositoryException {
		Resource resource = resourceResolver.getResource(queryPath);
		PageInfoBean pageInfoBean = new PageInfoBean();
		if (resource != null) {
			Page page = resource.adaptTo(Page.class);
			if (page != null) {
				pageInfoBean = setPageDetailsToBean(queryPath, page);
			} else {
				if (queryPath.startsWith("/content/dam/MNBD/")) {
					TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
					pageInfoBean = setAssetDetailsToBean(resource, queryPath, tagManager);

				}
			}

		}
		return pageInfoBean;
	}

	private static PageInfoBean setAssetDetailsToBean(Resource resource, String queryPath, TagManager tagManager) {

		Asset asset = resource.adaptTo(Asset.class);
		PageInfoBean pageInfoBean = new PageInfoBean();
		Map<String, Object> assetMetaDataMap = asset.getMetadata();
		pageInfoBean.setPageTitle(assetMetaDataMap.containsKey(JHMNConstants.ASSET_TITLE)
				? asset.getMetadataValue(JHMNConstants.ASSET_TITLE) : JHMNConstants.EMPTY_STRING);
		pageInfoBean.setPageURL(queryPath);
		pageInfoBean.setPageDesc(assetMetaDataMap.containsKey(JHMNConstants.ASSET_DESC)
				? asset.getMetadataValue(JHMNConstants.ASSET_DESC) : JHMNConstants.EMPTY_STRING);
		String tags = asset.getMetadataValue("cq:tags");
		if(tags != null){
			String[] tagArray = tags.split(",");
			for (String string : tagArray) {
				Tag tag = tagManager.resolve(string.trim());
				if(tag != null){
					String tagID = tag.getLocalTagID();
					if (tagID.startsWith(JHMNConstants.PARAM_FORMAT)) {
						pageInfoBean.setPageResourceType("(" + tag.getTitle() + ")");
					}
				}
			}
		}
		return pageInfoBean;

	}

	private static PageInfoBean setPageDetailsToBean(String queryPath, Page page) {
		PageInfoBean pageInfoBean = new PageInfoBean();
		pageInfoBean.setPageURL(queryPath + ".html");
		pageInfoBean.setPageTitle(page.getTitle());
		Tag[] tags = page.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID(); // returns the tagid
			// with out
			// namespace
			if (tagID.startsWith(JHMNConstants.PARAM_FORMAT)) {
				pageInfoBean.setPageResourceType("(" + tag.getTitle() + ")");
			}

		}
		pageInfoBean.setPageDesc(page.getDescription() != null ? page.getDescription() : JHMNConstants.EMPTY_STRING);
		return pageInfoBean;
	}

	public static JSONObject transferPageDetailstoJSONobj(ArrayList<PageInfoBean> pageInfos) throws JSONException {
		LOG.info("inside transferPageDetailstoJSONobj");
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		ListIterator<PageInfoBean> listItr = pageInfos.listIterator();
		while (listItr.hasNext()) {
			PageInfoBean bean = (PageInfoBean) listItr.next();
			if (bean != null) {
				json = new JSONObject();
				json.put("title", bean.getPageTitle());
				json.put("url", bean.getPageURL());
				if (bean.getPageResourceType() != null) {
					json.put("resourcetype", bean.getPageResourceType());
				} else {
					json.put("resourcetype", "");
				}
				if (bean.getPageDesc() != null) {
					json.put("desc", bean.getPageDesc());
				} else {
					json.put("desc", "");
				}
			}
			jsonArray.put(json);

		}

		mainObj.put("list", jsonArray);
		LOG.info("JSONObject::::::::::::::::::" + mainObj);
		return mainObj;
	}

	public static JSONObject getTagDetails(String path, SlingHttpServletRequest slingRequest) throws JSONException {
		JSONObject jsonChild = null;
		JSONObject mainJSON = new JSONObject();
		JSONArray jsonChildList = new JSONArray();
		ResourceResolver resourceResolver = slingRequest.getResourceResolver();
		Resource resource = resourceResolver.getResource(path);
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		if (resource != null) {
			Node node = resource.adaptTo(Node.class);
			try {
				if (node.hasNodes()) {
					NodeIterator iter = node.getNodes();
					while (iter.hasNext()) {
						Node childNode = iter.nextNode();
						Tag tag = tagManager.resolve(childNode.getPath());
						jsonChild = getTagNode(tag, 1);
						jsonChildList.put(jsonChild);
					}
				}
			} catch (RepositoryException e) {
				LOG.error("Repository Exception" , e);
			}
		}
		count = 0;
		mainJSON.put("nodes", jsonChildList);
		LOG.info("json created is ###" + mainJSON);
		return mainJSON;
	}

	/**
	 * Tags of the given path is populated to a bean and an arraylist of the
	 * <TagBean> is returned
	 * 
	 * @param path
	 *            Path of the tags eg:- etc/tags/MNBD/topic
	 * @param slingRequest
	 *            SlingHttpServletRequest object
	 * @return <ArrayList><TagBean>
	 * @throws JSONException
	 */
	public static ArrayList<TagBean> getTagBeanDetails(String path, SlingHttpServletRequest slingRequest)
			throws JSONException {
		ArrayList<TagBean> tagNodesBeans = new ArrayList<TagBean>();
		ResourceResolver resourceResolver = slingRequest.getResourceResolver();
		Resource resource = resourceResolver.getResource(path);
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		if (resource != null) {
			Node node = resource.adaptTo(Node.class);
			try {
				if (node.hasNodes()) {
					NodeIterator iter = node.getNodes();
					while (iter.hasNext()) {
						TagBean tagBean = new TagBean();
						Node childNode = iter.nextNode();
						Tag tag = tagManager.resolve(childNode.getPath());
						if(null!=tag){
						LOG.info("TAG BEAN DETAILS***" + tag.getTagID());
						tagBean = getTagBeanNode(tag, 1);
						LOG.info("TAG BEAN RETURNED " + tagBean);
						
						tagNodesBeans.add(tagBean);
						}
					}
				}
			} catch (RepositoryException e) {
				LOG.error("Repository Exception" , e);
			}
		}
		count = 0;
		return tagNodesBeans;
	}
	public static ArrayList<TagBean> getTagBeanDetails(String path, SlingHttpServletRequest slingRequest,String currentNodePath)
			throws JSONException {
		boolean flag=false;
		Value[] values =null;
		ArrayList<TagBean> tagNodesBeans = new ArrayList<TagBean>();
		ResourceResolver resourceResolver = slingRequest.getResourceResolver();
		Resource resource = resourceResolver.getResource(path);
		Resource resource1 = resourceResolver.getResource(currentNodePath);
		try{
			if(resource1!= null)
			{		
				Node node1 = resource1.adaptTo(Node.class);
				if(node1.hasProperty("cq:tags"))
				{
					Property propertyValue=node1.getProperty("cq:tags");
					values = propertyValue.getValues();
				}
				else
				{
					return getTagBeanDetails(path,slingRequest);	
				}
			}
			TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node.hasNodes()) {
					NodeIterator iter = node.getNodes();
					while (iter.hasNext()) {
						TagBean tagBean = new TagBean();
						Node childNode = iter.nextNode();
						Tag tag = tagManager.resolve(childNode.getPath());
						if(tag!=null){
							LOG.info("TAG BEAN DETAILS***" + tag.getTagID());
							String tagID=tag.getTagID();
							if(values!=null){
								for(Value value:values)
								{
									if(tagID.equals(value.toString()))
									{
										flag=true;
										LOG.info("tags selected by author = "+ value);
										break;
									}
								}
							}

							if(flag==false && values!=null)
							{
								tagBean = getTagBeanNode(tag, 1,values);
								LOG.info("TAG BEAN RETURNED " + tagBean);

								tagNodesBeans.add(tagBean);
							}

							flag=false;
						}
					}
				}
			} 
		}

		catch (RepositoryException e) {
			LOG.error("Repository Exception" , e);
		}
		count = 0;
		return tagNodesBeans;
	}
	private static TagBean getTagBeanNode(Tag tag, int level) {
		TagBean tagBean = createTagBean(tag, level, count++);

		return tagBean;
	}
	private static TagBean getTagBeanNode(Tag tag, int level,Value[] values) {
		TagBean tagBean = createTagBean(tag, level, count++,values);

		return tagBean;
	}
	private static TagBean createTagBean(Tag tag, int level, int i) {
		TagBean tagBean = new TagBean();
		tagBean.setTagID(tag.getTagID());
		tagBean.setName(tag.getName());
		tagBean.setTitle(tag.getTitle());
		tagBean.setLevel(levelString[level]);
		tagBean.setCount(count);
		LOG.info("Tag Name=" + tag.getName() + "  tag Title=" + tag.getTitle() + "  tag ID=" + tag.getTagID()
		+ "  level=" + level + "  count=" + count);
		if (tag.listChildren().hasNext()) {

			tagBean.setHasChild(true);

			Iterator<Tag> tagIter = tag.listChildren();

			level++;
			ArrayList<TagBean> tagBeans = new ArrayList<TagBean>();
			// NodeIterator iter = node.getNodes();
			while (tagIter.hasNext()) {
				TagBean tagBean2 = new TagBean();
				Tag childTag = tagIter.next();
				tagBean2 = getTagBeanNode(childTag, level);
				tagBeans.add(tagBean2);
			}
			tagBean.setTagBeans(tagBeans);

		}

		return tagBean;
	}

	private static TagBean createTagBean(Tag tag, int level, int i, Value[] values) {
		if(values==null){
			return null;
		}
		else{
			boolean flag=false;
			TagBean tagBean = new TagBean();
			tagBean.setTagID(tag.getTagID());
			tagBean.setName(tag.getName());
			tagBean.setTitle(tag.getTitle());
			tagBean.setLevel(levelString[level]);
			tagBean.setCount(count);
			LOG.info("Tag Name=" + tag.getName() + "  tag Title=" + tag.getTitle() + "  tag ID=" + tag.getTagID()
			+ "  level=" + level + "  count=" + count);
			if (tag.listChildren().hasNext()) {

				tagBean.setHasChild(true);

				Iterator<Tag> tagIter = tag.listChildren();

				level++;
				ArrayList<TagBean> tagBeans = new ArrayList<TagBean>();
				// NodeIterator iter = node.getNodes();
				while (tagIter.hasNext()) {
					TagBean tagBean2 = new TagBean();
					Tag childTag = tagIter.next();
					String childTagID=childTag.getTagID();
					for(Value value:values)
					{
						if(childTagID.equals(value.toString()))
						{
							flag=true;
							LOG.info("tags selected by author = "+ value);
							break;
						}
					}
					if(flag==false && values!=null)
					{
						tagBean2 = getTagBeanNode(childTag, level,values);
						tagBeans.add(tagBean2);
					}
					flag=false;
				}
				tagBean.setTagBeans(tagBeans);

			}

			return tagBean;
		}
	}

	private static JSONObject getTagNode(Tag tag, int level) {
		JSONObject json = createBean(tag, level, count++);
		JSONArray jsonChildlist = new JSONArray();
		JSONObject child = null;
		// LOG.info("count value is ####################"+count);
		Iterator<Tag> tagIter = tag.listChildren();

		level++;
		// NodeIterator iter = node.getNodes();
		while (tagIter.hasNext()) {

			Tag childTag = tagIter.next();
			child = getTagNode(childTag, level);
			jsonChildlist.put(child);
		}
		try {
			json.put("nodes", jsonChildlist);
		} catch (JSONException e) {
			LOG.error("Repository Exception" , e);
		}

		return json;
	}

	private static JSONObject createBean(Tag tag, int level, int count) {
		JSONObject json = new JSONObject();
		// SearchFilterBean searchFilterBean =new SearchFilterBean();
		try {
			json.put("tagID", tag.getTagID());
			json.put("name", tag.getName());
			json.put("title", tag.getTitle());
			json.put("level", level);
			json.put("count", count);
			LOG.info("Tag Name=" + tag.getName() + "  tag Title=" + tag.getTitle() + "  tag ID=" + tag.getTagID()
			+ "  level=" + level + "  count=" + count);
			if (tag.listChildren().hasNext()) {

				json.put("hasChild", true);

			}
		} catch (JSONException e) {
			LOG.error("Repository Exception" , e);
		}

		return json;
	}


	public static Map<String, String> setTagList(SlingHttpServletRequest request, Map<String, String> tagList) {
		try {
			if ((request.getParameter("format") != null) && (!request.getParameter("format").isEmpty())) {
				String[] formats = request.getParameterValues("format");
				String format = stringArrayToString(formats, ',');
				tagList.put("format", URLDecoder.decode(format, "UTF-8"));
			}
			if ((request.getParameter("type") != null) && (!request.getParameter("type").isEmpty())) {
				String[] types = request.getParameterValues("type");
				String type = stringArrayToString(types, ',');
				tagList.put("type", URLDecoder.decode(type, "UTF-8"));
			}
			if ((request.getParameter("topic") != null) && (!request.getParameter("topic").isEmpty())) {
				String[] topics = request.getParameterValues("topic");
				String topic = stringArrayToString(topics, ',');
				tagList.put("topic", URLDecoder.decode(topic, "UTF-8"));
			}
			if ((request.getParameter("product") != null) && (!request.getParameter("product").isEmpty())) {
				String[] products = request.getParameterValues("product");
				String product = stringArrayToString(products, ',');
				tagList.put("product", URLDecoder.decode(product, "UTF-8"));
			}
		} catch (UnsupportedEncodingException e) {
			LOG.error("UnSupported Encoding Exception ", e);
		}
		return tagList;
	}

	/**
	 * converts a String Array to a String using the character as delimiter
	 * 
	 * @param stringArray
	 *            the array to be converted
	 * @param character
	 *            the character to be used as delimiter
	 * @return
	 */
	public static String stringArrayToString(String[] stringArray, char character) {
		String string = "";
		for (String string1 : stringArray) {
			LOG.debug("STRING CONCATINATING ***" + string1);
			try {
				string1 = URLDecoder.decode(string1 , "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				LOG.error("UnsupportedEncodingException"+e.getMessage());
				e.printStackTrace();
			}
			string = string.concat(string1).concat(Character.toString(character));
			LOG.debug("STRING CONCATINATING ***" + string);
		}
		string = string.substring(0, string.lastIndexOf(character));
		LOG.debug("RETUIRNING STRING CONCATINATING ***" + string);
		return string;

	}

	public static void setFormatMapZero(Map<String, SearchParameter> mapFormat, SlingHttpServletRequest request) {
		TagManager tagManager = request.getResourceResolver().adaptTo(TagManager.class);
		ResourceResolver resourceResolver = request.getResourceResolver();
		Resource resource = resourceResolver.getResource("/content/cq:tags/MNBD/format");
		if (resource != null) {
			Node formatNode = resource.adaptTo(Node.class);
			try {
				if (formatNode.hasNodes()) {
					NodeIterator formatChildIter = formatNode.getNodes();
					while (formatChildIter.hasNext()) {
						Node formatChild = formatChildIter.nextNode();
						Tag tag = tagManager.resolve(formatChild.getPath());
						LOG.error("TAG ID " + tag.getTagID());
						String tagId = tag.getTagID();
						if (!mapFormat.containsKey(tag.getTagID())) {
							SearchParameter searchParameter = new SearchParameter();
							searchParameter.setCategoryKey((tagId.substring(tagId.lastIndexOf("/") + 1)).toUpperCase());
							searchParameter.setCategoryCount(0);
							searchParameter.setCategoryValue(tagId);
							mapFormat.put(tagId, searchParameter);
						}
					}

				}
			} catch (RepositoryException e) {
				LOG.error("Repository Exception" , e);
			}
		}

		// return mapFormat;
	}

	public static void setResourceTypeMapZero(Map<String, SearchParameter> mapResourceType,
			SlingHttpServletRequest request) {
		TagManager tagManager = request.getResourceResolver().adaptTo(TagManager.class);
		ResourceResolver resourceResolver = request.getResourceResolver();
		Resource resource = resourceResolver.getResource("/content/cq:tags/MNBD/type");
		if (resource != null) {
			Node formatNode = resource.adaptTo(Node.class);
			try {
				if (formatNode.hasNodes()) {
					NodeIterator typeChildIter = formatNode.getNodes();
					while (typeChildIter.hasNext()) {
						Node typeChild = typeChildIter.nextNode();
						Tag tag = tagManager.resolve(typeChild.getPath());
						LOG.error("TAG ID " + tag.getTagID());
						String tagId = tag.getTagID();
						if (!mapResourceType.containsKey(tag.getTagID())) {
							SearchParameter searchParameter = new SearchParameter();
							searchParameter.setCategoryKey(tag.getTitle());
							searchParameter.setCategoryCount(0);
							searchParameter.setCategoryValue(tagId);
							mapResourceType.put(tagId, searchParameter);
						}
					}
				}
			} catch (RepositoryException e) {
				LOG.error("Repository Exception" , e);
			}
		}

		// return mapResourceType;
	}

	/**
	 * Appends &page= with valid <index> for search
	 * 
	 * @param request
	 * @param index
	 * @return
	 */
	public static StringBuffer getURL(SlingHttpServletRequest request, Integer index) {
		StringBuffer url = new StringBuffer();
		url.append(request.getRequestURI());
		String pattern = "&page(=[^&]*)?|^page(=[^&]*)?&?";
		String replacedURL = findReplaceQueryParams(request.getQueryString(), pattern, "");
		// clearing the url stringbuffer and appending the new url
		url.append("?").append(replacedURL);
		url.append("&").append(JHMNConstants.PAGE_PARAM_NAME);
		url.append("=").append(encodeURL(Integer.toString(index)));
		return url;
	}

	/**
	 * finds the <code>patternString</code> in the given <code>string</code> and
	 * replace the matches with the given <code>replace</code> String
	 * 
	 * @param string
	 * @param patternString
	 * @param replace
	 * @return
	 */
	public static String findReplaceQueryParams(String string, String patternString, String replace) {
		String replacedString = string;
		Pattern pattern = Pattern.compile(patternString);
		Matcher matcher = pattern.matcher(replacedString);
		if (matcher.find()) {

			replacedString = matcher.replaceAll(replace);
		}
		return replacedString;
	}

	/**
	 * Encodes the given <code>url</code> using
	 * {@link URLEncoder#encode(String, String)} with a <code>UTF-8</code>
	 * encoding.
	 *
	 * @param url
	 *            the url to encode.
	 * @return the encoded url.
	 */
	private static String encodeURL(String url) {
		try {
			return URLEncoder.encode(url, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// will never happen
			return url;
		}
	}

	/**
	 * Check if there is previous page
	 * @param page
	 * @return
	 * @throws RepositoryException
	 */
	public static boolean hasPrevious(int page) throws RepositoryException {
		//ResultPage previous = result.getPreviousPage();
		return (page - 1) > 0 ? true : false ;	

	}

	/**
	 * Check if there is next page
	 * @param numberOfPages
	 * @param page
	 * @return
	 */
	public static boolean hasNext(long numberOfPages, long page) {
		return ((int)page + 1) < numberOfPages ? true : false ;	
	}

	/**
	 * Get the pagination logic for search
	 * @param searchResultTO
	 * @param numberOfPages
	 * @param page
	 * @param request
	 * @return
	 */
	public static SearchResultTO getPagination(SearchResultTO searchResultTO, long numberOfPages, long page,
			SlingHttpServletRequest request) {
		boolean hasPrevious;
		try {
			hasPrevious = hasPrevious((int) page);
			LOG.info("Pagination has Previous page****" + hasPrevious);
			boolean hasNext = hasNext(numberOfPages, page);
			LOG.info("Pagination has Next page****" + hasNext);
			if (numberOfPages > 4) {
				if (hasPrevious && hasNext) {
					if ((int) page - 2 >= 1) {
						searchResultTO.setPrevious(hasPrevious);
						searchResultTO.setNext(hasNext);
						searchResultTO.setEnd(page + 1);
						searchResultTO.setStart(page - 1);
						searchResultTO.setFirstURL(JHMNSearchHelper.getURL(request, 1));
						searchResultTO.setPreviousURL(JHMNSearchHelper.getURL(request, (int) page - 2));
						searchResultTO.setNextURL(JHMNSearchHelper.getURL(request, (int) page + 2));
						searchResultTO.setLastURL(JHMNSearchHelper.getURL(request, (int) numberOfPages));
					} else if ((int) page - 1 == 1) {
						searchResultTO.setEnd(4);
						searchResultTO.setStart(1);
						searchResultTO.setNext(hasNext);
						searchResultTO.setNextURL(JHMNSearchHelper.getURL(request, 5));
						searchResultTO.setLastURL(JHMNSearchHelper.getURL(request, (int) numberOfPages));
					}
				} else if (!hasPrevious && hasNext) {
					if (((int) page - 1) == 0) {
						searchResultTO.setEnd(4);
						searchResultTO.setStart(1);
						searchResultTO.setNext(hasNext);
						searchResultTO.setNextURL(JHMNSearchHelper.getURL(request, 5));
						searchResultTO.setLastURL(JHMNSearchHelper.getURL(request, (int) numberOfPages));
					}
				} else if (!hasNext && hasPrevious) {
					searchResultTO.setEnd(numberOfPages);
					searchResultTO.setStart(numberOfPages - 3);
					searchResultTO.setPrevious(hasPrevious);
					searchResultTO.setPreviousURL(JHMNSearchHelper.getURL(request, (int) numberOfPages - 3));
					searchResultTO.setFirstURL(JHMNSearchHelper.getURL(request, 1));
				}
			}
			else{
				searchResultTO.setEnd(numberOfPages);
				searchResultTO.setStart(1);
				searchResultTO.setPrevious(false);
				searchResultTO.setNext(false);
			}
		} catch (RepositoryException e) {
			LOG.error("Repository Exception ", e);
		}

		return searchResultTO;
	}


}
