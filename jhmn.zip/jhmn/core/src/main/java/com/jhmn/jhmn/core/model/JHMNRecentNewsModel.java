package com.jhmn.jhmn.core.model;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jhmn.jhmn.core.bean.JHMNArticleBean;
import com.jhmn.jhmn.core.constants.JHMNNewsConstants;
import com.jhmn.jhmn.core.helper.JHMNArticleHelper;

@Model(adaptables = Resource.class)
public class JHMNRecentNewsModel {
	private static final Logger LOG = LoggerFactory.getLogger(JHMNRecentNewsModel.class);

	@Inject
	private String limit;
	
	@Inject
	private String path;

	private static Session session = null;

	@Inject
	private ResourceResolver resourceResolver;

	ArrayList<JHMNArticleBean> articleBeanList;
	
	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public ArrayList<JHMNArticleBean> getArticleBeanList() {
		return articleBeanList;
	}

	public void setArticleBeanList(ArrayList<JHMNArticleBean> articleBeanList) {
		this.articleBeanList = articleBeanList;
	}

	@PostConstruct
	protected void init(){
		LOG.info("JHMNRecentNewsModel ::::::::::");
		articleBeanList = new ArrayList<JHMNArticleBean>();
		JHMNArticleBean articleBean = new JHMNArticleBean();
		QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
		session = resourceResolver.adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("path", path);
		map.put("1_property", JHMNNewsConstants.CQ_TEMPLATE);
		map.put("1_property.value", JHMNNewsConstants.ARTICLE_TEMPLATE);
		map.put("orderby", JHMNNewsConstants.ORDER_BY);
		map.put("orderby.sort", JHMNNewsConstants.ODERBY_SORT);
		map.put("p.limit", limit);
		// start of changes for user role
		//getFilterForUserRole(map, userTo);
		// end of changes for user role
		LOG.info("Query :::"+map.toString());
		//JHMNPageHelper.logMap(map);
		try {
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (!searchRes.getHits().isEmpty()) {
			LOG.debug("searchRes.getHits() is not empty");
			for (Hit hit : searchRes.getHits()) {
				String queryPath;
				queryPath = hit.getPath();
				articleBean = JHMNArticleHelper.retriveArticleBean(queryPath, resourceResolver);
				articleBeanList.add(articleBean);
				
			}
			LOG.info("Recent News ArticlesBean list size:::::"+articleBeanList.size());
		}
		}catch (ParseException e) {
			LOG.error("ParseException occured" ,e);
		}catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e);
		}
	}
}


