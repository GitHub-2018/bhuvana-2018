package com.jhmn.jhmn.core.helper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jhmn.jhmn.core.bean.JHMNArticleBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.constants.JHMNNewsConstants;

public class JHMNArticleHelper {
	
	private static final Logger LOG = LoggerFactory.getLogger(JHMNArticleHelper.class);
	
	private static Session session;
	/**
	 * Method to fetch the values from the bean
	 *
	 * @param path
	 * @param resolver
	 * 
	 *
	 * @return ArticleBean
	 * @throws PathNotFoundException
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public static JHMNArticleBean retriveArticleBean(String path, ResourceResolver resourceResolver)
			throws PathNotFoundException, RepositoryException, ParseException {
		Resource resource = resourceResolver.getResource(path);
		JHMNArticleBean articleBean = new JHMNArticleBean();
		String newPath=null;
		if (null != resource) {
			Page page = resource.adaptTo(Page.class);
			if (null != page) {
				ValueMap imageProperties = page.getProperties(JHMNNewsConstants.IMAGE_NODE_PATH);
				if(null!=imageProperties){
					articleBean.setImagePath(imageProperties.get(JHMNNewsConstants.IMAGE_REFERENCE,String.class));
				}
				ValueMap properties = page.getProperties();
				if(null!=properties){
					articleBean.setDate(JHMNDateHelper.getLastModified(properties));
				}
				path=path+".html";
				newPath=resourceResolver.map(path);
				newPath=newPath.replace(".html","");
				articleBean.setPath(newPath);
				articleBean.setTitle(page.getTitle());
				Tag[] tags = page.getTags();
				for (Tag tag : tags) {
					String tagID = tag.getLocalTagID(); 
					if (tagID.startsWith(JHMNNewsConstants.PARAM_TYPE)) {
						articleBean.setType(tag.getTitle());
					} else if (tagID.startsWith(JHMNNewsConstants.PARAM_TOPIC)) {
						articleBean.setTopic(tag.getTitle());
					} else if (tagID.startsWith(JHMNNewsConstants.PARAM_STATE)) {
						articleBean.setState(tag.getTitle());
					} else if (tagID.startsWith(JHMNNewsConstants.PARAM_CHANNEL)) {
						articleBean.setChannel(tag.getTitle());
					}else if(tagID.startsWith(JHMNNewsConstants.PARAM_PRODUCT)){
						articleBean.setProduct(tag.getTitle());
					}					
				}
				articleBean.setDescription(
						page.getDescription() != null ? page.getDescription() : JHMNConstants.EMPTY_STRING);
			}
		}
		LOG.debug("End of retriveArticleBean method");
		return articleBean;
	}
	
	/**
	 * Returns the all news search result
	 * 
	 * @param slingRequest
	 * @param limit
	 * @param channels
	 * @param userTo
	 * @param pageNo
	 * @param topic
	 * @return
	 */
	public static Map<String, Object> getAllNews(Map<String, Object> mapObj) {
		String limit = mapObj.get(JHMNNewsConstants.PARAM_LIMIT).toString();
		String[] channels = getChannels(mapObj);
		String pageNo = mapObj.get(JHMNNewsConstants.PARAM_PAGE_NO) != null
				? mapObj.get(JHMNNewsConstants.PARAM_PAGE_NO).toString() : JHMNNewsConstants.PAGE_NO_ONE;
				SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(JHMNConstants.SLING_REQUEST);

				
		ArrayList<JHMNArticleBean> articlebeans = new ArrayList<JHMNArticleBean>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		JHMNArticleBean articleBean = null;

		int pagenumber = Integer.parseInt(pageNo);
		int startIndex = (Integer.parseInt(limit)) * (pagenumber - 1);

		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);

		Map<String, String> map = new HashMap<String, String>();
		map.put("type", JHMNNewsConstants.PAGE_TYPE);
		map.put("1_group.1_property", JHMNNewsConstants.CQ_TEMPLATE);
		map.put("1_group.1_property.value", JHMNNewsConstants.ARTICLE_TEMPLATE);
		map.put("orderby", JHMNNewsConstants.ORDER_BY);
		map.put("orderby.sort", JHMNNewsConstants.ODERBY_SORT);
		map.put("p.limit", limit);
		LOG.debug("*****END**********");
		if (channels != null && channels.length > 0) {
			addChannelsFilter(map, 2, channels, slingRequest);
		}
		LOG.debug("MAP in All News" + map);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		query.setStart(startIndex);
		SearchResult searchRes = query.getResult();
		resultMap = getPaginationDetails(searchRes.getStartIndex(), searchRes.getTotalMatches(),
				Integer.parseInt(limit), 10, Integer.parseInt(pageNo), slingRequest);
		try {
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					String queryPath = hit.getPath();
					articleBean = new JHMNArticleBean();
					articleBean = retriveArticleBean(queryPath, slingRequest.getResourceResolver());
					articlebeans.add(articleBean);
				}
				LOG.debug("articlebeans list size ::::::::::::"+articlebeans.size());
			} else {
				LOG.info("No results for the selected channel");
			}
		} catch (RepositoryException e) {
			LOG.error("Repository Exception" , e);
		} catch (ParseException e) {
			LOG.error("Parse Exception" , e);
		}
		resultMap.put(JHMNNewsConstants.PARAM_RESULT_BEAN_LIST, articlebeans);
		LOG.debug("resultMap:::::::"+resultMap);
		return resultMap;
	}
	
	public static JSONObject transferNewsDetailstoJSONobj(List<JHMNArticleBean> articleBeans) throws JSONException {

		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		ListIterator<JHMNArticleBean> litr = articleBeans.listIterator();
		while (litr.hasNext()) {
			JHMNArticleBean bean = (JHMNArticleBean) litr.next();
			if (bean != null) {
				json = new JSONObject();
				json.put(JHMNNewsConstants.PARAM_CHANNEL, bean.getChannel());
				json.put(JHMNNewsConstants.PARAM_DATE, bean.getDate());
				json.put(JHMNNewsConstants.METADATA_FIRM, bean.getFirm());
				json.put(JHMNNewsConstants.PARAM_IMG_PATH, bean.getImagePath());
				json.put(JHMNNewsConstants.PARAM_PATH, bean.getPath());
				json.put(JHMNNewsConstants.PARAM_PRODUCT, bean.getProduct());
				json.put(JHMNNewsConstants.PARAM_STATE, bean.getState());
				json.put(JHMNNewsConstants.PARAM_TITLE, bean.getTitle());
				json.put(JHMNNewsConstants.PARAM_TOPIC, bean.getTopic());
				json.put(JHMNNewsConstants.PARAM_TYPE, bean.getType());
				json.put(JHMNNewsConstants.PARAM_DESCRIPTION, bean.getDescription());
			}
			jsonArray.put(json);

		}

		mainObj.put("list", jsonArray);
		return mainObj;

	}
	/**
	 * Converts the news datails tojson format. The json will have the news list
	 * as a json array. Apart from this, it also includes the currentPage,
	 * pageCount, size and displaing string.
	 * 
	 * @param resultMap
	 * @return
	 * @throws JSONException
	 */
	@SuppressWarnings("unchecked")
	public static JSONObject transferNewsDetailstoJSONobj(Map<String, Object> resultMap) throws JSONException {
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		ArrayList<JHMNArticleBean> articleBeans = (ArrayList<JHMNArticleBean>) resultMap.get(JHMNNewsConstants.PARAM_RESULT_BEAN_LIST);

		ListIterator<JHMNArticleBean> litr = articleBeans.listIterator();

		while (litr.hasNext()) {
			JHMNArticleBean bean = (JHMNArticleBean) litr.next();
			if (bean != null) {
				json = new JSONObject();
				json.put(JHMNNewsConstants.PARAM_CHANNEL, bean.getChannel());
				json.put(JHMNNewsConstants.PARAM_DATE, bean.getDate());
				json.put(JHMNNewsConstants.METADATA_FIRM, bean.getFirm());
				json.put(JHMNNewsConstants.PARAM_IMG_PATH, bean.getImagePath());
				json.put(JHMNNewsConstants.PARAM_PATH, bean.getPath());
				json.put(JHMNNewsConstants.PARAM_PRODUCT, bean.getProduct());
				json.put(JHMNNewsConstants.PARAM_STATE, bean.getState());
				json.put(JHMNNewsConstants.PARAM_TITLE, bean.getTitle());
				json.put(JHMNNewsConstants.PARAM_TOPIC, bean.getTopic());
				json.put(JHMNNewsConstants.PARAM_TYPE, bean.getType());
				json.put(JHMNNewsConstants.PARAM_DESCRIPTION, bean.getDescription());
			}
			jsonArray.put(json);

		}
		mainObj.put(JHMNNewsConstants.STRING_LIST, jsonArray);
		mainObj.put(JHMNNewsConstants.STRING_DISPLAYING, resultMap.get(JHMNNewsConstants.STRING_DISPLAYING));
		mainObj.put(JHMNNewsConstants.STRING_CURRENTPAGE, resultMap.get(JHMNNewsConstants.STRING_CURRENTPAGE));
		mainObj.put(JHMNNewsConstants.STRING_PAGECOUNT, resultMap.get(JHMNNewsConstants.STRING_PAGECOUNT));
		mainObj.put(JHMNNewsConstants.STRING_SIZE, resultMap.get(JHMNNewsConstants.STRING_SIZE));
		mainObj.put(JHMNNewsConstants.START, resultMap.get(JHMNNewsConstants.START));
		mainObj.put(JHMNNewsConstants.HASNEXT, resultMap.get(JHMNNewsConstants.HASNEXT));
		mainObj.put(JHMNNewsConstants.LASTURL, resultMap.get(JHMNNewsConstants.LASTURL));
		mainObj.put(JHMNNewsConstants.END, resultMap.get(JHMNNewsConstants.END));
		mainObj.put(JHMNNewsConstants.NEXT, resultMap.get(JHMNNewsConstants.NEXT));
		mainObj.put(JHMNNewsConstants.FIRST_URL, resultMap.get(JHMNNewsConstants.FIRST_URL));
		mainObj.put(JHMNNewsConstants.PREVIOUS, resultMap.get(JHMNNewsConstants.PREVIOUS));
		mainObj.put(JHMNNewsConstants.HAS_PREVIOUS,resultMap.get(JHMNNewsConstants.HAS_PREVIOUS));


		LOG.debug("Final JSON generated is" + mainObj);

		return mainObj;

	}

		private static String[] getChannels(Map<String, Object> mapObj) {
			Object channelObject = mapObj.get(JHMNNewsConstants.PARAM_CHANNELS);
			String[] channels = null;
			if (channelObject != null) {
				String channel = (String) mapObj.get(JHMNNewsConstants.PARAM_CHANNELS);
				channels = channel.split(",");
			}
			return channels;
		}
		
		private static void addChannelsFilter(Map<String, String> map, int i, String[] channels,
				SlingHttpServletRequest slingRequest) {
			int j = 0;
			boolean flag = false;
			TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
			for (String channel : channels) {
				if (!channel.trim().isEmpty()) {
					flag = true;
					Tag channelTag = tagManager.resolve(channel);
					if (channelTag != null) {
						j++;
						map.put(i + "_group." + j + "_property", "@jcr:content/cq:tags");
						map.put(i + "_group." + j + "_property.value", channelTag.getTagID());
					}
				}
			}
			if (flag) {
				map.put(i + "_group.p.or", "true");
			}

		}
		
	
	/**
	 * Returns the pagination details like currentPage, pageCount, size and
	 * displaying x of y string in a map object
	 * 
	 * @param startIndex
	 * @param totalCnt
	 * @param paginationSize
	 * @param bucketCnt
	 * @param currentPageNo
	 * @param slingRequest 
	 * @return
	 */
	private static Map<String, Object> getPaginationDetails(long startIndex, long totalCnt, int paginationSize,
			int bucketCnt, int currentPageNo, SlingHttpServletRequest slingRequest) {

		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		long displayEnd = startIndex + paginationSize > totalCnt ? totalCnt : startIndex + paginationSize;
		long totalPages = 0;

		StringBuilder sb = new StringBuilder();
		sb.append(startIndex + 1);
		sb.append(JHMNNewsConstants.SYMBOL_HYPHEN);
		sb.append(displayEnd);
		sb.append(JHMNNewsConstants.STRING_OF);
		sb.append(totalCnt);

		if (totalCnt % (paginationSize) > 0) {
			totalPages = (totalCnt / (paginationSize)) + 1;
		} else {
			totalPages = totalCnt / (paginationSize);
		}
		resultMap = getPagination(resultMap, totalPages, currentPageNo, slingRequest );

		resultMap.put(JHMNNewsConstants.STRING_DISPLAYING, sb.toString());
		resultMap.put(JHMNNewsConstants.STRING_CURRENTPAGE, currentPageNo);
		resultMap.put(JHMNNewsConstants.STRING_PAGECOUNT, totalPages);
		resultMap.put(JHMNNewsConstants.STRING_SIZE, bucketCnt);

		return resultMap;

	}
	
	public static HashMap<String, Object> getPagination(HashMap<String, Object> resultMap, long numberOfPages, long page,
			SlingHttpServletRequest request) {
		boolean hasPrevious;
		try {
			hasPrevious = hasPrevious((int) page);

			boolean hasNext = hasNext(numberOfPages, page);
			if (numberOfPages > 4) {
				if (hasPrevious && hasNext) {
					if ((int) page - 2 >= 1) {
						resultMap.put("hasPrevious", hasPrevious);
						resultMap.put("hasNext", hasNext);
						resultMap.put("end", page + 1);
						resultMap.put("start", page - 1);
						resultMap.put("firstURL", 1);
						resultMap.put("previous", (int) page - 2);
						resultMap.put("next", (int) page + 2);
						resultMap.put("lastURL", (int) numberOfPages);
					} else if ((int) page - 1 == 1) {
						resultMap.put("end", 4);
						resultMap.put("start", 1);
						resultMap.put("hasNext", hasNext);
						resultMap.put("next", 5);
						resultMap.put("lastURL", (int) numberOfPages);
					}
				} else if (!hasPrevious && hasNext) {
					if (((int) page - 1) == 0) {
						resultMap.put("end", 4);
						resultMap.put("start", 1);
						resultMap.put("hasNext", hasNext);
						resultMap.put("next", 5);
						resultMap.put("lastURL", (int) numberOfPages);
					}
				} else if (!hasNext && hasPrevious) {
					resultMap.put("end", numberOfPages);
					resultMap.put("start", numberOfPages - 2);
					resultMap.put("hasPrevious", hasPrevious);
					resultMap.put("previous", (int) numberOfPages - 3);
					resultMap.put("firstURL", 1);
				}
			}else{
				resultMap.put("end", numberOfPages);
				resultMap.put("start", 1);
				resultMap.put("hasPrevious",false);
				resultMap.put("hasNext",false);
			}
		} catch (RepositoryException e) {
			LOG.error("Repository Exception ", e);
		}
		return resultMap;
	}
	/**
	 * Check if there is previous page
	 * @param page
	 * @return
	 * @throws RepositoryException
	 */
	public static boolean hasPrevious(int page) throws RepositoryException {

		return (page - 1) > 0 ? true : false ;	

	}

	/**
	 * Check if there is next page
	 * @param numberOfPages
	 * @param page
	 * @return
	 */
	public static boolean hasNext(long numberOfPages, long page) {
		return ((int)page + 1) <= numberOfPages ? true : false ;	
	}

	
	public static Map<String, String> retrieveChannels(String tagPath, SlingHttpServletRequest slingRequest){
		String tagName = null;
		String tagID = null;
		String eachTagPath=null;
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		ResourceResolver resourceResolver = slingRequest.getResourceResolver();
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		if (resourceResolver != null) {
			Node node = resourceResolver.getResource(tagPath).adaptTo(Node.class);
			if (node != null) {
				try {
					if (node.hasNodes()) {
						NodeIterator nodeIterator = node.getNodes();
						while (nodeIterator.hasNext()) {
							Node childNode = nodeIterator.nextNode();
							if (childNode.hasProperty(JHMNConstants.JCR_TITLE)) {
								tagName=childNode.getProperty(JHMNConstants.JCR_TITLE).getString();
								eachTagPath=childNode.getPath();
								Tag tag = tagmanager.resolve(eachTagPath);
								tagID= tag.getTagID();
							}

							sortedMap.put(tagName, tagID);
						}

					}
				}
				catch (RepositoryException e) {
					LOG.error("Repository Exception" , e);
				}
			}
		}
		return sortedMap;
	}	
}
