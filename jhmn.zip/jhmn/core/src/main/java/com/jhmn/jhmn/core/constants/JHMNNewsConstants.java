package com.jhmn.jhmn.core.constants;

public class JHMNNewsConstants {

	public static final String CQ_TEMPLATE="@jcr:content/cq:template";
	public static final String ARTICLE_TEMPLATE = "/apps/jhmn/templates/jhmnarticletemplate";
	public static final String ORDER_BY="@jcr:content/jcr:created";
	public static final String ODERBY_SORT="desc";
	public static final String IMAGE_NODE_PATH="par_leftcolumn/image";
	public static final String IMAGE_REFERENCE="fileReference";
	public static final String PARAM_TYPE = "type";
	public static final String PARAM_TOPIC = "topic";
	public static final String PARAM_CHANNEL = "channel";
	public static final String PARAM_PRODUCT = "product";
	public static final String CURRENTPAGE="currentPage";
	public static final String CONTENT_TYPE="application/json; charset=UTF-8";
	public static final String PARAM_CHANNELS = "channels";
	public static final String PARAM_FUNCTIONALITY = "functionality";
	public static final String PARAM_LIMIT = "limit";
	public static final String PARAM_PAGE_NO="pageNo";
	public static final String PAGE_NO_ONE = "1";
	public static final String ALL_NEWS = "allnews";
    public static final String MY_NEWS = "mynews";
    public static final String PARAM_STATE = "state";
    public static final String PARAM_RESULT_BEAN_LIST="beanList";
    public static final String PAGE_TYPE = "cq:Page";
	public static final String SYMBOL_HYPHEN = " - ";
	public static final String STRING_OF = " of ";
	public static final String STRING_DISPLAYING = "displaying";
	public static final String STRING_CURRENTPAGE = "currentPage";
	public static final String STRING_PAGECOUNT = "pageCount";
	public static final String STRING_SIZE = "size";
	public static final String PARAM_DATE = "date";
	public static final String PARAM_IMG_PATH="imgPath";
	public static final String PARAM_TITLE="title";
	public static final String PARAM_DESCRIPTION = "description";
	public static final String PARAM_TOTAL_CNT="totalCount";
	public static final String PARAM_PATH = "path";
	public static final String METADATA_FIRM="@jcr:content/metadata/firm";
	
	public static final String START = "start";
	public static final String HASNEXT = "hasNext";
	public static final String LASTURL = "lastURL";
	public static final String END = "end";
	public static final String NEXT = "next";
	public static final String FIRST_URL = "firstURL";
	public static final String PREVIOUS = "previous";
	public static final String HAS_PREVIOUS = "hasPrevious";
	public static final String STRING_LIST = "list";
	
	
	
	
}
