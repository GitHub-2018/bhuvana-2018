package com.jhmn.jhmn.core.bean;

public class SearchParameter {
	private String categoryKey;
	private String categoryValue;
	private double categoryCount;

	public String getCategoryKey() {
		return categoryKey;
	}
	public void setCategoryKey(String categoryKey) {
		this.categoryKey = categoryKey;
	}
	public String getCategoryValue() {
		return categoryValue;
	}
	public void setCategoryValue(String categoryValue) {
		this.categoryValue = categoryValue;
	}
	public double getCategoryCount() {
		return categoryCount;
	}
	public void setCategoryCount(double count) {
		this.categoryCount = count;
	}

}
