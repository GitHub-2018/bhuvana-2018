package com.jhmn.jhmn.core.servlets;

import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhmn.jhmn.core.bean.AssetMetaDataBean;
import com.jhmn.jhmn.core.helper.JHMNAssetHelper;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

@Component(immediate = true, metatype = true) @Service(Servlet.class) @Properties({
	@Property(name = "service.description", value = "MNBD Recently Accessed Resources Servlet"),
	@Property(name = "sling.servlet.paths", value = {"/bin/sling/JHMNRecentResources"}),
	@Property(name = "service.vendor", value = "MNBD"),
	@Property(name = "sling.servlet.methods", value = "POST", propertyPrivate = true)})

public class JHMNRecentResourcesServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(JHMNRecentResourcesServlet.class);

	private static final long serialVersionUID = 1L;

	/**
	 * doGet
	 */
	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);

	}

	/**
	 * doPost process the recently access resources - to find more asset meta bean details.
	 * IF PDF, retrieve the Asset Meta Data Bean Details
	 * Else
	 * treat it as an HTML Page
	 */
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		LOG.info("MNBDRecentResourcesServlet doPost");

		// set another default locale
		Locale.setDefault(Locale.ENGLISH);

		try {
			Integer size = Integer.valueOf(request.getParameter("size"));

			String content = request.getParameter("content"); // It should be JSONArray

			LOG.info("size: {} and the content: {}", size, content);

			if (StringUtils.isEmpty(content)) {
				return;
			}

			JSONArray jsonArray = null;
			Map<String, AssetMetaDataBean> map = new LinkedHashMap<String, AssetMetaDataBean>(size);
			if (StringUtils.isEmpty(content)) {
				LOG.debug("No content data received by the servlet");
			} else {
				try {
					jsonArray = new JSONArray(content);
					AssetMetaDataBean assetMetaDataBean = null;

					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject object = jsonArray.getJSONObject(i);
						String view = object.has("view") ? object.getString("view") : "";
						view = getURIPath(view);
						if (StringUtils.isBlank(view)) {
							continue;
						}

						if (view.toUpperCase().endsWith("PDF")) {
							LOG.debug("retrieveAssetBean for view {} ", view);
							assetMetaDataBean =
									JHMNAssetHelper.retrieveAssetBean(view, request.getResourceResolver());

							LOG.debug("retrieved AssetBean assetMetaDataBean is {} ",
									assetMetaDataBean);

						} else if (view.toUpperCase().endsWith("HTML")) {
							LOG.debug("view HTML: {}", view);
							assetMetaDataBean = new AssetMetaDataBean();

							String title = object.has("title") ? object.getString("title") : "";
							String format = object.has("format") ? object.getString("format") : "";
							String type = object.has("type") ? object.getString("type") : "";

							assetMetaDataBean.setPath(view);
							assetMetaDataBean.setTitle(title);
							assetMetaDataBean.setFormat(format);
							assetMetaDataBean.setType(type);

						} else {
							//Nothing
						}
						//Add the assetBean only if the following are present:
						// 1. FORMAT 2. TYPE
						if (assetMetaDataBean == null ||
								StringUtils.isEmpty(assetMetaDataBean.getFormat()) ||
								StringUtils.isEmpty(assetMetaDataBean.getType())) {
							LOG.debug("assetMetaDataBean: is null or missing the related tags");
						} else {
							LOG.debug("assetMetaDataBean: render with view {}", view);
							map.put(view, assetMetaDataBean);
						}

						//Exit Loop condition
						if (map.size() >= size) {
							LOG.debug("Map size: {} reached, now exit", map.size());
							break;
						}
					}
				} catch (JSONException e1) {
					e1.printStackTrace();
				}
			}

			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");

			PrintWriter out = response.getWriter();
			Gson gson = new Gson();
			LOG.debug("Map size: {}", map.size());
			out.println(gson.toJson(map.values()));
			out.flush();
		} catch (Exception e) {
			LOG.error("JHINS Recently Accessed Resources Servlet", e);
		}

	}

	private String getURIPath(String view) {

		URI uri;
		try {
			view.replaceAll(" ", "%20"); // replace space if any
			uri = new URI(view.toString());
			if (uri != null) {
				return URLDecoder.decode(uri.getPath(), "UTF-8");
			}

		} catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException Occured!!! for view '{}'", view);
			return "";
		} catch (URISyntaxException e) {
			LOG.error("URISyntax Exception!!! for view '{}'", view);
			return "";
		}

		return "";
	}
}
