package com.jhmn.jhmn.core.interfaces;

public interface JHMNNewBusinessCaseStatusService {

	
	public abstract String getNewBusinessCaseStatus(String sortBy,String policyNumber,String userName,String userRole,String appId);
	
}
