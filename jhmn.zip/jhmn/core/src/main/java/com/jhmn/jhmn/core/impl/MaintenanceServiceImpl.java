package com.jhmn.jhmn.core.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.interfaces.MaintenanceService;



public class MaintenanceServiceImpl implements MaintenanceService {

	private static final Logger LOG = LoggerFactory.getLogger(MaintenanceServiceImpl.class);

	public boolean getStatus(Node maintenanceNode) {
		// TODO Auto-generated method stub
		boolean status = false;

		try {
			if(null !=maintenanceNode){
				Node timingsNode = maintenanceNode.getNode(JHMNConstants.TIMINGS_NODE);
				NodeIterator nodeIterator = timingsNode.getNodes();
				Node timeNode = null;
				while(nodeIterator.hasNext()) {
					timeNode = nodeIterator.nextNode();
					String starttime = timeNode.getProperty(JHMNConstants.START_TIME).getValue().toString();
					String endtime = timeNode.getProperty(JHMNConstants.END_TIME).getValue().toString();
					String currentTime = getCurrentTime(); 

					SimpleDateFormat sdf = new SimpleDateFormat(JHMNConstants.TIME_FORMAT);
					Date start = sdf.parse(starttime);
					Date end = sdf.parse(endtime);
					Date current = sdf.parse(currentTime);
					if (start.compareTo(current) < 0 && end.compareTo(current) > 0 ) {
						status = true;
						break;

					} 
				}
			} 
		}catch (PathNotFoundException e) {
			LOG.error("PathNotFoundException ",e);
		} catch (RepositoryException e) {
			LOG.error("RepositoryException",e);
		} catch (ParseException e) {
			LOG.error("Date format ParseException occured",e);
		}
		return status;
	}


	public String getMessage(Node maintenanceNode) {
		String message = StringUtils.EMPTY;
		try {
			message = maintenanceNode.getProperty(JHMNConstants.MESSAGE).getValue().toString();	
		} catch (PathNotFoundException e) {
			LOG.error("PathNotFoundException occured",e);
		} catch (RepositoryException e) {
			LOG.error("RepositoryException occured",e);
		} 
		return message;
	}

	public JSONObject getJsonResponse(String domain, boolean status, String message) {
		// TODO Auto-generated method stub
		JSONObject json = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		JSONObject returnObj = new JSONObject();
		try {
			json.put(JHMNConstants.DOMAIN, domain);
			json.put(JHMNConstants.MAINTENANCE_STATUS, status);
			json.put(JHMNConstants.MESSAGE, message);

			jsonArray.put(json);
			returnObj.put("status", jsonArray);
		} catch (JSONException e) {
			LOG.error("JSONException while creating json response",e);
		}
		return returnObj;
	}

	private static String getCurrentTime() {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(JHMNConstants.TIME_FORMAT);
		return sdf.format(cal.getTime());
	}	
}
