package com.jh.jhins.search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.jh.jhins.bean.AssetMetaDataBean;

public class SearchResultTO {
	private ArrayList<PageInfo> pageInfo;
	private ArrayList<AssetMetaDataBean> assetBeans;
	private double count;
	private long numberOfPages;
	
	private boolean next;
	private boolean previous;
	private StringBuffer nextURL;
	private StringBuffer previousURL;
	private StringBuffer firstURL;
	private StringBuffer lastURL;
	private long currentIndex;
	private long end;
	private long start;
	private long endResult;
	private long startResult;
	private Map<String, SearchParameter> resourceType=new HashMap<String, SearchParameter>();
	private Map<String, SearchParameter> format=new HashMap<String, SearchParameter>();
	
	public ArrayList<PageInfo> getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(ArrayList<PageInfo> pageInfo) {
		this.pageInfo = pageInfo;
	}
	public ArrayList<AssetMetaDataBean> getAssetBeans() {
		return assetBeans;
	}
	public void setAssetBeans(ArrayList<AssetMetaDataBean> assetBeans) {
		this.assetBeans = assetBeans;
	}
	public double getCount() {
		return count;
	}
	public void setCount(double count) {
		this.count = count;
	}	
	public Map<String, SearchParameter> getResourceType() {
		return resourceType;
	}
	public void setResourceType(Map<String, SearchParameter> mapResourceType) {
		this.resourceType = mapResourceType;
	}
	public Map<String, SearchParameter> getFormat() {
		return format;
	}
	public void setFormat(Map<String, SearchParameter> mapFormat) {
		this.format = mapFormat;
	}
	public long getNumberOfPages() {
		return numberOfPages;
	}
	public void setNumberOfPages(long numberOfPages) {
		this.numberOfPages = numberOfPages;
	}
	public boolean isNext(){
		return next;
	}
	public void setNext(boolean next) {
		this.next = next;
	}
	public boolean isPrevious() {
		return previous;
	}
	public void setPrevious(boolean previous) {
		this.previous = previous;
	}
	public long getStart() {
		return start;
	}
	public void setStart(long start) {
		this.start = start;
	}
	public long getEnd() {
		return end;
	}
	public void setEnd(long l) {
		this.end = l;
	}
	public long getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(long currentIndex) {
		this.currentIndex = currentIndex;
	}
	public StringBuffer getNextURL() {
		return nextURL;
	}
	public void setNextURL(StringBuffer nextURL) {
		this.nextURL = nextURL;
	}
	public StringBuffer getPreviousURL() {
		return previousURL;
	}
	public void setPreviousURL(StringBuffer previousURL) {
		this.previousURL = previousURL;
	}
	public StringBuffer getFirstURL() {
		return firstURL;
	}
	public void setFirstURL(StringBuffer firstURL) {
		this.firstURL = firstURL;
	}
	public StringBuffer getLastURL() {
		return lastURL;
	}
	public void setLastURL(StringBuffer lastURL) {
		this.lastURL = lastURL;
	}
	public long getEndResult() {
		return endResult;
	}
	public void setEndResult(long endResult) {
		this.endResult = endResult;
	}
	public long getStartResult() {
		return startResult;
	}
	public void setStartResult(long startResult) {
		this.startResult = startResult;
	}
	
}
