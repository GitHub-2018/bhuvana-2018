package com.jh.jhins.interfaces;

import org.apache.sling.commons.json.JSONObject;

public interface DailyUnitValuesService {
	
	public JSONObject dialyUnitValues(String productCode, String companyCode, String mProductFlag);
}
