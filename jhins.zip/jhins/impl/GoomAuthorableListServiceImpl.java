package com.jh.jhins.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jh.jhins.interfaces.GoomAuthorableListService;

@Service
@Component(immediate = true, metatype = true, name = "GoomErrorListServiceImpl")
public class GoomAuthorableListServiceImpl implements GoomAuthorableListService {
	private static final Logger LOG = LoggerFactory.getLogger(GoomAuthorableListServiceImpl.class);
	public static final String PRODUCERTNC_ERRORLIST_PATH = "/etc/acs-commons/lists/producertnc_errorcode_config";
	public static final String PRODUCERTERMS_AND_CONDITION = "producertermsandcondition";
	public static final String APPOINTMENT_STATUS = "appointmentstatus";
	public static final String APPOINTMENTSTATUS_ERRORLIST_PATH = "/etc/acs-commons/lists/appointment_errorcode_config";
	public static final String APPOINTMENT_COMMENTS_CONFIG = "/etc/acs-commons/lists/appointment_status_comments_config";
	public static final String DEFAULT = "Default";
	public static final String FIRM_SUPPORT = "FirmSupport"; 
	public static final String SUPERUSER = "SuperUser_SN";
	public static final String NAME = "Name";
	public static final String ID_TYPE = "IDType";
	public static final String ID = "ID";
	public static final String NAME_NOT_FOUND = "Name Not Found";
	public static final String CODE = "Code";
	public static final String STATUS_CODE = "StatusCode";
	public static final String DETAILS = "Details";
	public static final String REQUEST_ID = "RequestId";
	public static final String COMMENTS = "Comments";
	public static final String CUSTOM_COMMENT_CODE = "4004";
	public static final String TERMS_AND_CONDITION = "TermsAndConditionsStatus";
	public static final String NA = "N/A";
	public static final String AML_TRAINING_COMPLETION_DATE = "AmlTrainingCompletionDate";
	public static final String COMPANY = "Company";
	public static final String STATETERRITORY = "StateTerritory";
	public static final String PRODUCT_TYPE = "ProductType";
	public static final String EFFECTIVE_DATE = "EffectiveDate";
	public static final String COMMENTCODE = "CommentCode";
	public static final String APPOINTMENTS = "Appointments";
	public static final String REPRESENTATIVE = "Representative";
	public static final String REPRESENTATIVES = "Representatives";
	public static final String MESSAGE = "Message";
	public static final String NOTFOUND = "404";
	public static final String BADREQUEST = "400";
	public static final String SERVERERROR = "500";
	public static final String UNAVAILABLE = "403";
	public static final String CUSTOM_ERRORCODE_NOTFOUND = "6001";
	public static final String CUSTOM_ERRORCODE_SERVERERROR = "7001";
	public static final String CUSTOM_ERRORCODE_UNAVAILABLE = "6003";
	public static final String CUSTOM_DEFAULT_ERRORCODE_UNAVAILABLE = "8001";
	public static final String LIST_NODE = "jcr:content/list";
	public static final String JCR_TITLE = "jcr:title";
	public static final String VALUE = "value";
	public static final String JHINS_SERVICE = "JHINSService";
	
	
	@Reference
	private ResourceResolverFactory resolverFactory;

	Page pagePath;
	
	public String finalJsonData(String responseString, String page, int statusCode, String role) {
		String finalResponse = null;
		String code = null;
		String requestID = null;
		try {
			JSONObject commentsJson = commentsJson();
			Boolean errorCode = isErrorCode(statusCode);
			LOG.debug("json in Data::;" + responseString);
			if (errorCode && statusCode != 403) {
				//Code for HTTPSStatus Error Codes except 403 with JSON response
				if (null != responseString && responseString.length() != 0) {
					JSONObject jObject = new JSONObject(responseString);
					if (jObject.has("Code")) {
						code = jObject.getString(CODE);
					}
					if (jObject.has(DETAILS)) {
						requestID = jObject.getJSONObject(DETAILS).getString(REQUEST_ID);
					}
				}
				finalResponse = getErrorResponse(statusCode, code, requestID, page, role);
				if (APPOINTMENT_STATUS.equalsIgnoreCase(page)) {
					JSONObject responseObject = new JSONObject(finalResponse);
					responseObject.put(COMMENTS, commentsJson);
					finalResponse = responseObject.toString();
				}
				LOG.debug("final Error Response::::::::" + finalResponse);
			}else{
				//Code for HTTPStatus Error code 403 with HTML Response
				finalResponse = getErrorResponse(statusCode, code, requestID, page, role);
			}
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}
		return finalResponse;
	}

	private ResourceResolver getServiceResolver(){
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(ResourceResolverFactory.SUBSERVICE, JHINS_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			} catch (LoginException e) {
				LOG.error("LoginException:", e);
			}
		return resourceResolver;
	}
	private String getErrorResponse(int statusCode, String code, String requestID, String page, String role){

		String message = null;
		JSONObject jsonObj = new JSONObject();
		try {
			//ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			PageManager pageManager = getServiceResolver().adaptTo(PageManager.class);
			//PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
			if (PRODUCERTERMS_AND_CONDITION.equalsIgnoreCase(page)) {
				pagePath = pageManager.getPage(PRODUCERTNC_ERRORLIST_PATH);
			} else if (APPOINTMENT_STATUS.equalsIgnoreCase(page)) {
				pagePath = pageManager.getPage(APPOINTMENTSTATUS_ERRORLIST_PATH);
			}
			GenericList list = pagePath.adaptTo(GenericList.class);
			// List errorList = list.getItems();
			String statusCodeVal = Integer.toString(statusCode);
			if (StringUtils.isBlank(statusCodeVal)) {
				statusCodeVal = DEFAULT;
			}
			message = list.lookupTitle(statusCodeVal);
			if(StringUtils.isBlank(message)){
				message = list.lookupTitle(DEFAULT);
			}
			LOG.debug("Error message:::::::::::::::::::" + message);
			JSONObject details = new JSONObject();
			// Code for Name Not Found Scenario Azure return HTTP Status code 404 
			if(StringUtils.isNotBlank(requestID)){
				if (statusCodeVal.equalsIgnoreCase(NOTFOUND)) {
					JSONArray representativearray = new JSONArray();
					JSONObject representative = new JSONObject();
					representative.put(NAME, NAME_NOT_FOUND);
					representative.put(TERMS_AND_CONDITION, NA);
					representative.put(AML_TRAINING_COMPLETION_DATE, "");
					//Appointment Status additional parameters for json response
					if (APPOINTMENT_STATUS.equalsIgnoreCase(page)) {
						// Appointment Status : FirmSupport user role JSON Response additional parameters
						if(FIRM_SUPPORT.equalsIgnoreCase(role) || SUPERUSER.equalsIgnoreCase(role)){
							representative.put(ID_TYPE, "");
							representative.put(ID, "");
						}
						JSONArray appointmentarray = new JSONArray();
						JSONObject appointmentObject=new JSONObject();
						appointmentObject.put(COMPANY, "");
						appointmentObject.put(STATETERRITORY, "");
						appointmentObject.put(PRODUCT_TYPE, "");
						appointmentObject.put(EFFECTIVE_DATE, "");
						appointmentObject.put(COMMENTCODE, CUSTOM_COMMENT_CODE);
						appointmentarray.put(appointmentObject);
						representative.put(APPOINTMENTS,appointmentarray);
					}
					
					details.put(REQUEST_ID, requestID);
					//Appointment Status: FirmSupport/SuperUser role JSON Response additional parameters 
					if(APPOINTMENT_STATUS.equalsIgnoreCase(page) && (FIRM_SUPPORT.equalsIgnoreCase(role) || SUPERUSER.equalsIgnoreCase(role))){
						representativearray.put(representative);
						details.put(REPRESENTATIVES, representativearray);
					}else{
						details.put(REPRESENTATIVE, representative);
					}
					//jsonObj.put("Message", message);
				} else {
					details.put(REQUEST_ID, requestID);
					jsonObj.put(MESSAGE, message);
				}
				jsonObj.put(CODE, code);
				jsonObj.put(STATUS_CODE, statusCodeVal);
				jsonObj.put(DETAILS, details);
			}else{
				//Code for Server HTTPStatus Error codes 404, 500, 403 Response Json. 
				if(statusCodeVal.equalsIgnoreCase(NOTFOUND)){
					jsonObj.put(CODE, CUSTOM_ERRORCODE_NOTFOUND);	
				}else if(statusCodeVal.equalsIgnoreCase(SERVERERROR)){
					jsonObj.put(CODE, CUSTOM_ERRORCODE_SERVERERROR);
				}else if(statusCodeVal.equalsIgnoreCase(UNAVAILABLE)){
					jsonObj.put(CODE, CUSTOM_ERRORCODE_UNAVAILABLE);
				}else{
					jsonObj.put(CODE, CUSTOM_DEFAULT_ERRORCODE_UNAVAILABLE);
				}
				jsonObj.put(STATUS_CODE, statusCodeVal);
				jsonObj.put(MESSAGE, message);
			}
			
		} catch (JSONException e) {
			LOG.error("JSONException:", e);
		} /*catch (LoginException e) {
			LOG.error("LoginException ",e);
		}*/
		return jsonObj.toString();
	}

	private Boolean isErrorCode(int code) {
		boolean errorFlag = false;
		if (400 <= code && code < 600) {
			errorFlag = true;
		}
		return errorFlag;
	}
	
	//Generic List Comments JSON response for Appointment status
	public JSONObject commentsJson() {
		JSONObject jobject=new JSONObject();
		try{
			//ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null); 
			Resource resource = getServiceResolver().getResource(APPOINTMENT_COMMENTS_CONFIG);
			//Resource resource = resourceResolver.getResource(APPOINTMENT_COMMENTS_CONFIG);
	        if(null != resource) {
	        	Resource listres = resource.getChild(LIST_NODE);
	        	Iterator<Resource> listItems = listres.listChildren();
	            while (listItems.hasNext()) {
	                Resource listItem = listItems.next();
	                String title = listItem.adaptTo(ValueMap.class).get(JCR_TITLE, String.class);
	                String value = listItem.adaptTo(ValueMap.class).get(VALUE, "");
	                if (title != null) {
	                    jobject.put(value, title);
	                }
	            }
	        }
	        LOG.debug("comments List::::::::::"+jobject.toString());
        }catch (JSONException e) {
			LOG.error("JSONException ",e);
		} /*catch (LoginException e) {
			LOG.error("LoginException ",e);
		}*/
		 return jobject; 
	}
	
}
