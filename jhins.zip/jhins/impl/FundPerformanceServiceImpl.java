package com.jh.jhins.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import javax.jcr.RepositoryException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhins.bean.FundDetailsBean;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.helper.DateHelper;
import com.jh.jhins.helper.FundDetails;
import com.jh.jhins.interfaces.FundPerformanceService;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;
@Component
@Service

public class FundPerformanceServiceImpl implements FundPerformanceService{

	@Reference
	private GOOMConfigService configService;
	@Reference
	private ResourceResolverFactory resolverFactory;

	FundDetails fundetails =new FundDetails();

	private static final Logger LOG = LoggerFactory.getLogger(FundPerformanceServiceImpl.class);


	public String getJsonData(String procode, String comcode,ResourceResolver resourceResolver, String result,String footNote, String firmId) {	

		String respContent = null;
		String productcode =procode;
		String companycode = comcode;
		String endPointUrl=null;
		CryptoBase64 decryptPassword = new CryptoBase64();
		String key = configService.getProperty(GOOMConstants.PRODUCER_HEADER_KEY);		
		String authKey;

		try {
			authKey = String.valueOf(decryptPassword.decrypt(configService.getProperty(GOOMConstants.MONTHLY_PERFORMANCE_BYSERIES_VALUE)))
					.trim();
			if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_MONTHLY_PERFORMANCE)){
				endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_MONTHLY_PERFORMANCE_URL);
			}
			else if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_QUATERLY_PERFORMANCE))
			{
				endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_QUATERLY_PERFORMANCE_URL);
			}
			else if (result.equalsIgnoreCase(GOOMConstants.BY_SERIES_MONTHLY_PERFORMANCE))
			{
				endPointUrl = configService.getProperty(GOOMConstants.JHVITMONTHLY_PERFORMANCE_URL);
			}
			else if (result.equalsIgnoreCase(GOOMConstants.BY_SERIES_QUATERLY_PERFORMANCE))
			{
				endPointUrl = configService.getProperty(GOOMConstants.JHVITQUARTERLY_PERFORMANCE_URL);
			}

			JSONObject jsonObj = new JSONObject();
			try {
				jsonObj.put(GOOMConstants.PRODUCTCODE, productcode);
				jsonObj.put(GOOMConstants.COMPANYCODE, companycode);
				LOG.debug("input Json:::::::::::::::::" + jsonObj.toString());
				StringEntity input = new StringEntity(jsonObj.toString());
				respContent = getJsonResponse(input,endPointUrl,resourceResolver,key,authKey,footNote, firmId);
			} catch (JSONException e) {
				LOG.error("JSONException", e);
			} catch (ParseException e) {
				LOG.error("ParseException", e);
			} catch (UnsupportedEncodingException e) {
				LOG.error("UnsupportedEncodingException", e);
			} catch (RepositoryException e) {
				LOG.error("RepositoryException", e);
			} catch (java.text.ParseException e) {
				LOG.error("java.text.ParseException", e);
			}
		} catch (CryptoException e) {
			LOG.error("CryptoException", e);
		}
		LOG.debug("BY Product Fund Performance final json data for "+result+" ==" + respContent);
		return respContent;
	}
	private String getJsonResponse(StringEntity input, String url,ResourceResolver resourceResolver,String key,String value,String footNote, String firmId) throws JSONException, RepositoryException, java.text.ParseException {
		String responseData = null;
		String code = null;
		JSONObject jObject = null;
		DefaultHttpClient httpClient = new DefaultHttpClient();
		try {

			HttpPost postRequest = new HttpPost(url);		
			postRequest.setEntity(input);
			postRequest.addHeader(key,value);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);			
			HttpResponse response = httpClient.execute(postRequest);	
			responseData = EntityUtils.toString(response.getEntity(), GOOMConstants.CHARSET);
	
			if(response.getStatusLine().getStatusCode() != 200){
				int statusCode=response.getStatusLine().getStatusCode();
				if(statusCode==403)
				{
				jObject = getUnavailableErrorJsonData(statusCode);
				}
				else
				{
				jObject = new JSONObject(responseData);
				jObject = getErrorJsonData(statusCode,jObject);
				}
			}else{
				jObject = new JSONObject(responseData);
				jObject=finalJsonData(jObject,resourceResolver,footNote, firmId);
			}	
			responseData=jObject.toString();

		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		}finally{
			httpClient.getConnectionManager().shutdown();
		}

		return responseData;
	}

	
	private JSONObject finalJsonData(JSONObject jObject,ResourceResolver resourceResolver,String footNote, String firmId) throws RepositoryException, java.text.ParseException {
		JSONArray performanceDataArr;
		JSONArray fundArray = new JSONArray();
		JSONArray footNoteArray = new JSONArray();
		TreeSet<Integer> listedFootNotes= new TreeSet<Integer>();
		String asOfDate=null;
		String quarter=null;
		String pagePath= null;
		if(firmId.equalsIgnoreCase(GOOMConstants.PRD)){
			pagePath = configService.getProperty(GOOMConstants.PRD_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.EDJ)){
			pagePath = configService.getProperty(GOOMConstants.EDJ_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.MGP)){
			pagePath = configService.getProperty(GOOMConstants.MGP_FUNDPROFILE_PATH);
		}else{
			pagePath = configService.getProperty(GOOMConstants.FUND_PROFILES_URL);
		}
		//LOG.debug("page Path:::::"+pagePath);
		LOG.debug("footNote value is "+footNote);
		if(!footNote.isEmpty()){
			String[] footNotes = footNote.split(",");
			for (String items : footNotes) {
				int footNoteNum = Integer.parseInt(items);			
				listedFootNotes.add(footNoteNum);
			}
		}
		HashMap<String,String> riskDetails= fundetails.getRiskDetails(GOOMConstants.RISK_DETAILS_URL,resourceResolver);
		try {
			performanceDataArr=jObject.getJSONObject("Details").getJSONArray("FundPerformanceData");
			asOfDate=jObject.getJSONObject("Details").getString("AsOfDate");
			quarter=DateHelper.getQuarter(asOfDate);
			asOfDate=DateHelper.formatDates(asOfDate,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);

			for(int i=0;i<performanceDataArr.length();i++){
				JSONObject jsonIteration=performanceDataArr.getJSONObject(i);
				String fundCode=jsonIteration.getString("FundCode");
				Boolean isFundExist = fundCheck(fundCode , pagePath,resourceResolver);
				if(isFundExist){
					String date=jsonIteration.getString("IncepDate");
					String incepDate=DateHelper.formatDates(date,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);
					FundDetailsBean fundDetail=fundetails.getFundDetails(pagePath,fundCode,resourceResolver);
					if(null!=fundDetail.getNumberedFootNotes() && !fundDetail.getNumberedFootNotes().isEmpty())
					{
						String[] numFootNotes=fundDetail.getNumberedFootNotes().toString().split(",");
						for (String items : numFootNotes) {
							int footNoteNumber = Integer.parseInt(items);			
							listedFootNotes.add(footNoteNumber);						
						}
					}				
					String riskColorCode=riskDetails.get(fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK, fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK_ORDER, fundDetail.getRiskOrder());				
					jsonIteration.put(GOOMConstants.MORNING_STAR_PATH,fundDetail.getMorningStarPath());
					jsonIteration.put(GOOMConstants.MANAGEMENT_FEE,fundDetail.getManagementFee());
					jsonIteration.put(GOOMConstants.INCEPTION_DATE,incepDate);
					jsonIteration.put(GOOMConstants.FUND_TITLE, fundDetail.getFundTitle());
					jsonIteration.put(GOOMConstants.FUND_MANAGER, fundDetail.getFundManager());
					jsonIteration.put(GOOMConstants.RISK_COLOR_CODE, riskColorCode);
					jsonIteration.put(GOOMConstants.NUMBERED_FOOT_NOTE, fundDetail.getNumberedFootNotes());
					jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, fundDetail.getFootNote());
					fundArray.put(jsonIteration);				
				}
	
				fundArray = fundetails.sortJson(fundArray);
				jObject.put("FundArray",fundArray);	
				if(!listedFootNotes.isEmpty()){
					footNoteArray=fundetails.getFootNoteDetails(listedFootNotes,resourceResolver);
					jObject.put("FootNotesArray", footNoteArray);
				}			
				jObject.put("date",asOfDate);
				jObject.put("quarter",quarter);
			}
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}
		return jObject;
	}

	private Boolean fundCheck(String fundCode, String pagePath, ResourceResolver resourceResolver) {
		Boolean flagVal = false;
		Resource resource =resourceResolver.getResource(pagePath+"/"+fundCode);
		if(null != resource){
			String resourceName = resource.getName();
			if(fundCode.equalsIgnoreCase(resourceName)){
				flagVal = true;
			}
		}else{
			flagVal = false;
		}
		LOG.debug("Fund Exist :::"+flagVal);
		return flagVal;
	}
	public String getDailyUnitJsonData(String procode, String comcode,ResourceResolver resourceResolver, String result, String date,String footNote, String firmId) {		
		String respContent = null;
		String productcode =procode;
		String companycode = comcode;
		String endPointUrl=null;
		String formatedDate = date;
		if(!formatedDate.isEmpty()){
			try {
				formatedDate=DateHelper.formatDates(date,GOOMConstants.INPUT_DATE_FORMAT_DAILY_UNIT,GOOMConstants.OUTPUT_DATE_FORMAT_DAILY_UNIT);
			} catch (java.text.ParseException e) {
				LOG.error("java.text.ParseException"+e);
			}
		}
		CryptoBase64 decryptPassword = new CryptoBase64();
		String key = configService.getProperty(GOOMConstants.PRODUCER_HEADER_KEY);		
		String value;
		try {
			value = String.valueOf(decryptPassword.decrypt(configService.getProperty(GOOMConstants.MONTHLY_PERFORMANCE_BYSERIES_VALUE)))
					.trim();
			if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_DAILYUNIT_VALUE)){
				endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_DAILYUNIT_VALUE_URL);
			}
			else if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE)){
				endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE_URL);		
			}
			LOG.debug("endpoint is ***"+endPointUrl);			
			JSONObject jsonObj = new JSONObject();
			try {
				jsonObj.put(GOOMConstants.PRODUCTCODE, productcode);
				jsonObj.put(GOOMConstants.COMPANYCODE, companycode);
				jsonObj.put(GOOMConstants.AS_OF_DATE,formatedDate);
				LOG.debug("input Json:::::::::::::::::" + jsonObj.toString());
				StringEntity input = new StringEntity(jsonObj.toString());
				respContent = getDailyUnitJsonResponse(input,endPointUrl,resourceResolver,key,value,footNote, firmId);
			} catch (JSONException e) {
				LOG.error("JSONException", e);
			} catch (ParseException e) {
				LOG.error("ParseException", e);
			} catch (UnsupportedEncodingException e) {
				LOG.error("UnsupportedEncodingException", e);
			}
		} catch (CryptoException e) {
			LOG.error("CryptoException", e);
		}
		LOG.debug("BY Product Daily Unit Values final json data for "+result+" ==" + respContent);
		return respContent;
	}
	private String getDailyUnitJsonResponse(StringEntity input, String url, ResourceResolver resourceResolver,
			String key, String value,String footNote, String firmId) {
		String responseData = null;
		String code = null;
		JSONObject jObject = null;
		DefaultHttpClient httpClient = null;
		try {
			httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(url);
			postRequest.setEntity(input);
			postRequest.addHeader(key,value);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);
			HttpResponse response = httpClient.execute(postRequest);
			responseData = EntityUtils.toString(response.getEntity(), GOOMConstants.CHARSET);						
			if(response.getStatusLine().getStatusCode() != 200){
				int statusCode=response.getStatusLine().getStatusCode();
				if(statusCode==403)
				{				
				jObject = getUnavailableErrorJsonData(statusCode);
				}
				else
				{
				jObject = new JSONObject(responseData);
				jObject = getErrorJsonData(statusCode,jObject);
				}
			}
			else{
				jObject = new JSONObject(responseData);
				jObject=finalDailyUintJsonData(jObject,resourceResolver,footNote, firmId);
			}
			responseData=jObject.toString();

		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		} catch (RepositoryException e) {
			LOG.error("IOExRepositoryExceptionception", e);
		} catch (java.text.ParseException e) {
			LOG.error("ParseException", e);
		}finally{
			httpClient.getConnectionManager().shutdown();
		}

		return responseData;
	}
	
	private JSONObject finalDailyUintJsonData(JSONObject jObject,ResourceResolver resourceResolver,String footNote, String firmId) throws RepositoryException, java.text.ParseException {

		JSONArray newjson;
		JSONArray fundArray = new JSONArray();
		String asOfDate=null;
		JSONArray footNoteArray = new JSONArray();
		TreeSet<Integer> listedFootNotes= new TreeSet<Integer>();
		String pagePath= null;
		if(firmId.equalsIgnoreCase(GOOMConstants.PRD)){
			pagePath = configService.getProperty(GOOMConstants.PRD_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.EDJ)){
			pagePath = configService.getProperty(GOOMConstants.EDJ_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.MGP)){
			pagePath = configService.getProperty(GOOMConstants.MGP_FUNDPROFILE_PATH);
		}else{
			pagePath = configService.getProperty(GOOMConstants.FUND_PROFILES_URL);
		}		
		HashMap<String,String> riskDetails= fundetails.getRiskDetails(GOOMConstants.RISK_DETAILS_URL,resourceResolver);
		if(!footNote.isEmpty()){
			String[] footNotes = footNote.split(",");
			for (String items : footNotes) {
				int footNoteNum = Integer.parseInt(items);			
				listedFootNotes.add(footNoteNum);
			}
		}
		try {
			newjson=jObject.getJSONObject("Details").getJSONArray("DailyUnitValue");
			asOfDate=jObject.getJSONObject("Details").getString("AsOfDate");
			asOfDate=DateHelper.formatDates(asOfDate,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);			
			for(int i=0;i<newjson.length();i++){
				JSONObject jsonIteration=newjson.getJSONObject(i);
				String fundCode=jsonIteration.getString("FundCode");
				Boolean isFundExist = fundCheck(fundCode , pagePath,resourceResolver);
				if(isFundExist){
					double netChangeValue =Double.parseDouble(jsonIteration.getString("NetChange"));
					String netChange= GOOMConstants.NET_CHARGE_POSITIVE;
					String color="green";
					if(netChangeValue<0)
					{
						netChange=GOOMConstants.NET_CHARGE_NEGATIVE;
						color="red";
					}
					else if(netChangeValue==0)
					{
						netChange=GOOMConstants.NET_CHARGE_ZERO;
						color="blue";
					}
					FundDetailsBean fundDetail=fundetails.getFundDetails(pagePath,fundCode,resourceResolver);
					if(null!=fundDetail.getNumberedFootNotes() && !fundDetail.getNumberedFootNotes().isEmpty())
					{
						String[] numFootNotes=fundDetail.getNumberedFootNotes().toString().split(",");
						for (String items : numFootNotes) {
							int footNoteNumber = Integer.parseInt(items);			
							listedFootNotes.add(footNoteNumber);						
						}
					}	
					String riskColorCode=riskDetails.get(fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK, fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK_ORDER, fundDetail.getRiskOrder());				
					jsonIteration.put(GOOMConstants.MORNING_STAR_PATH,fundDetail.getMorningStarPath());
					jsonIteration.put(GOOMConstants.MANAGEMENT_FEE,fundDetail.getManagementFee());
					jsonIteration.put(GOOMConstants.FUND_TITLE, fundDetail.getFundTitle());
					jsonIteration.put(GOOMConstants.FUND_MANAGER, fundDetail.getFundManager());
					jsonIteration.put(GOOMConstants.RISK_COLOR_CODE, riskColorCode);
					jsonIteration.put(GOOMConstants.NET_CHNAGE, netChange);
					jsonIteration.put(GOOMConstants.COLOR,color);
					jsonIteration.put(GOOMConstants.NUMBERED_FOOT_NOTE, fundDetail.getNumberedFootNotes());
					jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, fundDetail.getFootNote());
					fundArray.put(jsonIteration);				
				}
				fundArray = fundetails.sortJson(fundArray);
				jObject.put("FundArray",fundArray);
				if(!listedFootNotes.isEmpty()){
					footNoteArray=fundetails.getFootNoteDetails(listedFootNotes,resourceResolver);				
					jObject.put("FootNotesArray", footNoteArray);
				}
				jObject.put("date",asOfDate);
			}
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}
		return jObject;
	}	
	private JSONObject getErrorJsonData(int statusCode,JSONObject reseponseJson) {
		
		Page pagePath;
		JSONObject jObject=new JSONObject();
		Boolean errorCode = isErrorCode(statusCode);
		
		PageManager pageManager = getServiceResolver().adaptTo(PageManager.class);		
		pagePath = pageManager.getPage(GOOMConstants.FUND_PERFORMANCE_ERRORLIST_PATH);
		String message = null;
		GenericList list = pagePath.adaptTo(GenericList.class);
		String statusCodeVal = Integer.toString(statusCode);
		if (StringUtils.isBlank(statusCodeVal)) {
			statusCodeVal = GOOMConstants.DEFAULT;
		}
		message = list.lookupTitle(statusCodeVal);
		if(StringUtils.isBlank(message)){
			message = list.lookupTitle(GOOMConstants.DEFAULT);
		}
		String code = null;
		try {
			if (errorCode) {
				if (null != reseponseJson && reseponseJson.length() != 0) {
					if (reseponseJson.has("Code")) {				
						jObject.put(GOOMConstants.CODE, reseponseJson.getString(GOOMConstants.CODE));
						jObject.put(GOOMConstants.MESSAGE, message);
						jObject.put("StatusCode", statusCodeVal);
					}else{
						if(statusCodeVal.equalsIgnoreCase(GOOMConstants.NOTFOUND)){
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_NOTFOUND);	
						}else if(statusCodeVal.equalsIgnoreCase(GOOMConstants.SERVERERROR)){
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_SERVERERROR);
						}else if(statusCodeVal.equalsIgnoreCase(GOOMConstants.UNAVAILABLE)){
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_UNAVAILABLE);
						}else{
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_DEFAULT_ERRORCODE_UNAVAILABLE);
						}						
						jObject.put(GOOMConstants.MESSAGE, message);
						jObject.put("StatusCode", statusCodeVal);
					}
				}				
			}
		} catch (JSONException e) {
			LOG.error("JSONException:", e);
		}
		return jObject;
	}
	private ResourceResolver getServiceResolver(){
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(ResourceResolverFactory.SUBSERVICE, GOOMConstants.JHINS_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			//resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
		} catch (LoginException e) {
			LOG.error("LoginException:", e);
		}
		return resourceResolver;
	}
	private Boolean isErrorCode(int code) {
		boolean errorFlag = false;
		if (400 <= code && code < 600) {
			errorFlag = true;
		}
		return errorFlag;
	}
	private JSONObject getUnavailableErrorJsonData(int statusCode) {
		Page pagePath;
		JSONObject jObject=new JSONObject();
		Boolean errorCode = isErrorCode(statusCode);

		PageManager pageManager = getServiceResolver().adaptTo(PageManager.class);		
		pagePath = pageManager.getPage(GOOMConstants.FUND_PERFORMANCE_ERRORLIST_PATH);
		String message = null;
		GenericList list = pagePath.adaptTo(GenericList.class);
		String statusCodeVal = Integer.toString(statusCode);
		if (StringUtils.isBlank(statusCodeVal)) {
			statusCodeVal = GOOMConstants.DEFAULT;
		}
		message = list.lookupTitle(statusCodeVal);
		if(StringUtils.isBlank(message)){
			message = list.lookupTitle(GOOMConstants.DEFAULT);
		}
		try {
			jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_UNAVAILABLE);		
			jObject.put(GOOMConstants.MESSAGE, message);
			jObject.put("StatusCode", GOOMConstants.UNAVAILABLE);
		}catch (JSONException e) {			
			e.printStackTrace();
		}
		return jObject;
	}
}