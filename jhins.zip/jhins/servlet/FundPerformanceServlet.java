package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.interfaces.FundPerformanceService;

@SlingServlet( paths = "/bin/sling/fundperformance",metatype=true, methods = HttpConstants.METHOD_POST )
@Properties({ @Property(name = "service.description", value = "Fund Performance Servlet"),
	@Property(name = "service.vendor", value = "JHINS")})
public class FundPerformanceServlet extends SlingAllMethodsServlet { 
	private static final Logger LOG = LoggerFactory.getLogger(FundPerformanceServlet.class);

	@Reference
	FundPerformanceService fundPerformanceService;
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException  {
		LOG.info("Start Fund Performance doPost method");

		String jsonResponse = null;
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String functionality = xssAPI.filterHTML((String)request.getParameter(GOOMConstants.FUNCTIONALITY));
		String productcode = xssAPI.filterHTML((String)request.getParameter(GOOMConstants.PRODUCTCODE));
		String companycode = xssAPI.filterHTML((String)request.getParameter(GOOMConstants.COMPANYCODE));
		String footNote =xssAPI.filterHTML((String)request.getParameter(GOOMConstants.FOOT_NOTE));
		String resultType = xssAPI.filterHTML((String)request.getParameter(GOOMConstants.BY_RESULT_TYPE));
		String date = xssAPI.filterHTML((String)request.getParameter(GOOMConstants.DATE));
		String firmId = xssAPI.filterHTML((String)request.getParameter(GOOMConstants.FIRM_ID));
		ResourceResolver resourceResolver = request.getResourceResolver();								
		LOG.debug("functionality is "+functionality+"product code ="+productcode+"Company code= "+companycode+" resultType is "+resultType +"Date is ="+date+"Firm Id::"+firmId);

		try {				
			if(resultType.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_MONTHLY_PERFORMANCE)||resultType.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_QUATERLY_PERFORMANCE) ||resultType.equalsIgnoreCase(GOOMConstants.BY_SERIES_MONTHLY_PERFORMANCE) ||resultType.equalsIgnoreCase(GOOMConstants.BY_SERIES_QUATERLY_PERFORMANCE)){
				jsonResponse = fundPerformanceService.getJsonData(productcode,companycode,resourceResolver,resultType,footNote, firmId);
			}
			else if(resultType.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_DAILYUNIT_VALUE )|| resultType.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE)){
				jsonResponse = fundPerformanceService.getDailyUnitJsonData(productcode,companycode,resourceResolver,resultType,date,footNote, firmId);

			}
		} catch (ParseException e) {
			LOG.error("ParseException", e);
		}	

		response.setContentType(GOOMConstants.APPLICATION_JSON);
		response.setCharacterEncoding(GOOMConstants.CHARSET);
		PrintWriter out = response.getWriter();

		if(null != jsonResponse && "" != jsonResponse){
			out.write(xssAPI.getValidJSON(jsonResponse, null));
		}

		out.flush();
		out.close();
		LOG.info("End Fund Performance doPost method");
	}
}