package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.jh.jhins.bean.EServiceBean;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;

@SlingServlet( paths = "/bin/sling/eservice",metatype=true, methods = HttpConstants.METHOD_POST )
@Properties({ @Property(name = "service.description", value = "E-Service"),
	@Property(name = "service.vendor", value = "JHINS")})
public class EServiceServlet extends SlingAllMethodsServlet{

	private static final Logger LOG = LoggerFactory.getLogger(EServiceServlet.class);

	@Reference
	private GOOMConfigService configService;

	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException  {
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String inputData = xssAPI.getValidJSON(request.getParameter("formData"), null);
		Gson gson = new Gson();
		EServiceBean eServiceBean = gson.fromJson(inputData, EServiceBean.class);
		String inputJson = gson.toJson(eServiceBean);
		String responseJson = postFormData(inputJson);
		response.setContentType(GOOMConstants.APPLICATION_JSON);
		response.setCharacterEncoding(GOOMConstants.CHARSET);
		PrintWriter out = response.getWriter();
		out.write(xssAPI.getValidJSON(responseJson, null));
		out.flush();
		out.close();

	}

	private String postFormData(String inputJSON) {
		String responseData= "";
		CryptoBase64 decryptPassword = new CryptoBase64();
		try {
			String value = String.valueOf(decryptPassword.decrypt(configService.getProperty(GOOMConstants.MONTHLY_PERFORMANCE_BYSERIES_VALUE)))
					.trim();
			String key = configService.getProperty(GOOMConstants.PRODUCER_HEADER_KEY);	
			String endPointUrl = configService.getProperty(GOOMConstants.ESERVICE_URL);					
			StringEntity input = new StringEntity(inputJSON.toString());
			LOG.debug("inputJson::::::::::"+inputJSON.toString());
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(endPointUrl);			
			postRequest.setEntity(input);
			postRequest.addHeader(key,value);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);			
			HttpResponse response = httpClient.execute(postRequest);
			if(response.getStatusLine().getStatusCode() != 200){
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("Message", "Your E-Service email Subscription Succesfull");
				responseData = jsonObj.toString();
			}else{
				int code = response.getStatusLine().getStatusCode();
				JSONObject errorObj = new JSONObject();
				errorObj.put("Code", code);
				errorObj.put("Message", "E-Service email Subscription service not available, Please try again later");
				responseData = errorObj.toString();
			}
			LOG.debug("response::::::::::"+response.getStatusLine().getStatusCode());

		} catch (CryptoException e) {
			LOG.error("CryptoException",e);
		}  catch (JSONException e) {
			LOG.error("JSONException",e);
		}catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException",e);
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException",e);
		} catch (IOException e) {
			LOG.error("IOException",e);
		}	
		return responseData;
	}
}
