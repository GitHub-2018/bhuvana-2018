package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.interfaces.DailyUnitValuesService;
@SlingServlet(paths="/bin/sling/dailyUnitValues",metatype=true, methods = HttpConstants.METHOD_GET )
public class DialyUnitValuesServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(DialyUnitValuesServlet.class);
	
	@Reference
	DailyUnitValuesService dailyUnitValuesService;
	
	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
	        throws ServletException, IOException {
	        this.doPost(request, response);

	    }
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
	        throws ServletException, IOException {
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String productCode = xssAPI.encodeForHTML(request.getParameter("productCode"));
		String companyCode = xssAPI.encodeForHTML(request.getParameter("companyCode"));
		String mProductFlag = xssAPI.encodeForHTML(request.getParameter("mproduct"));
		JSONObject dialyUnitResponse = dailyUnitValuesService.dialyUnitValues(productCode,companyCode,mProductFlag);
		try {
			int statusCode = Integer.parseInt(dialyUnitResponse.getString("statusCode"));
			response.setContentType(GOOMConstants.APPLICATION_JSON);
	        response.setCharacterEncoding(GOOMConstants.CHARSET);
	        if(statusCode == 200){
	        	dialyUnitResponse.remove("statusCode");
	        	dialyUnitResponse.put("Code", statusCode);
	        	response.setStatus(HttpServletResponse.SC_OK);
	        }else if(statusCode == 400){
	        	dialyUnitResponse.remove("statusCode");
	        	dialyUnitResponse.put("Code", statusCode);
	        	response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	        }else if (statusCode == 403){
	        	dialyUnitResponse.remove("statusCode");
	        	dialyUnitResponse.put("Code", statusCode);
	        	response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
	        }else if( statusCode == 404){
	        	dialyUnitResponse.remove("statusCode");
	        	dialyUnitResponse.put("Code", statusCode);
	        	response.setStatus(HttpServletResponse.SC_NOT_FOUND);
	        }else if(statusCode == 500){
	        	dialyUnitResponse.remove("statusCode");
	        	dialyUnitResponse.put("Code", statusCode);
	        	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	        }
	        PrintWriter out = response.getWriter();
	        out.write(xssAPI.getValidJSON(dialyUnitResponse.toString(), null));
			out.flush();
			out.close();
		} catch (NumberFormatException e) {
			LOG.error("NumberFormatException::::",e );
		} catch (JSONException e) {
			LOG.error("JSONException::::",e );
		}
	}
}
