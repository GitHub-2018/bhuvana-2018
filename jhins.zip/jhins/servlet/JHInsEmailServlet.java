package com.jh.jhins.servlet;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.xss.XSSAPI;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.email.EmailService;
import com.jh.jhins.email.EmailServiceConstants;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JHINS Email Us Servlet"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/JHINSEmail" }),
		@Property(name = "admin.email.id", value = "aaroor@jhancock.com"),
		@Property(name = "admin.email.id.life", value = "sravanthi.mandoori@cognizant.com"),
		@Property(name = "admin.email.id.ltc", value = "smandoori@jhancock.com"),
		@Property(name = "admin.email.id.feedback", value = "smandoori@jhancock.com"),
		@Property(name = "service.vendor", value = "JHINS"),
		@Property(name = "sling.servlet.methods", value = "POST", propertyPrivate = true) })

/**
 * Email Servlet for the sending the email with all parameters
 *
 *
 */
public class JHInsEmailServlet extends SlingAllMethodsServlet {

	private static Logger log = LoggerFactory.getLogger(JHInsEmailServlet.class);

	private static final long serialVersionUID = 1L;

	@Reference
	EmailService emailService;

	/**
	 * Method to fetch the sling properties
	 *
	 */

	private static Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		properties = context.getProperties();
	}

	/**
	 * doGet method
	 */

	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);

	}

	/**
	 * doPost uses the request and response and send Email to the user
	 */
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException {

		try {
			response.setContentType(NewsConstants.CONTENT_TYPE);
			request.setCharacterEncoding("UTF-8");
			XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
			String redirectPath = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.REDIRECT_PATH));
			if (redirectPath != null && redirectPath.startsWith("/content")) {
				// do nothing
			} else {
				redirectPath = "/content/PRDJHINS/en_US/logged-in/errors/404";
			}
			String firstN = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.FIRST_NAME));
			String date = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.DATE));
			String emailAddress = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.EMAIL_ADDRESS));
			String insuredN = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.INSURED_NAME));
			String firmN = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.FIRM_NAME));
			String comments = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.COMMENTS));
			String phone1 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_1));
			String phone2 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_2));
			String phone3 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_3));
			String phone4 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_4));
			String telePhone = null;
			if (phone4 != null && !phone4.isEmpty()) {
				telePhone = phone1 + "-" + phone2 + "-" + phone3 + "-" + phone4;
			} else {
				telePhone = phone1 + "-" + phone2 + "-" + phone3;
			}

			String iamASelected = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.IAM_A));
			String categorySelected = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.CATEGORY));
			String subject = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.SUBJECT));
			String formType = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.FORM_TYPE));
			String domain = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.DOMAIN));

			// Specify the template file to use (this is an absolute path in the
			// JCR)
			String templatePath = EmailServiceConstants.EMAIL_TEMPLATE_PATH;
			if (formType.equalsIgnoreCase(EmailServiceConstants.EMAIL_US_FORM)) {
				templatePath = EmailServiceConstants.EMAIL_TEMPLATE_PATH;
			} else {
				templatePath = EmailServiceConstants.FEED_BACK_FORM_TEMPLATE_PATH;
			}

			// Set the dynamic variables of your email template
			Map<String, String> emailParams = new HashMap<String, String>();
			emailParams.put("ccrecipient", emailAddress);
			emailParams.put("First_Name", firstN == null ? " " : firstN);
			emailParams.put("Insured_Name", insuredN == null ? " " : insuredN);
			emailParams.put("Firm_Name", firmN == null ? " " : firmN);
			emailParams.put("Requestor", iamASelected);

			emailParams.put("Email_Address", emailAddress);
			emailParams.put("Comments", comments);
			emailParams.put("Date", date);
			emailParams.put("Telephone", telePhone);

			List<File> uploadedFiles = saveUploadedFiles(request);

			ResourceResolver resourceResolver = request.getResourceResolver();
			String[] recipients = new String[1];
			synchronized (recipients) {
				if (EmailServiceConstants.EMAIL_US_FORM.equalsIgnoreCase(formType)) {
					emailParams.put("Category", categorySelected);
					if (domain != null) {
						if (domain.equalsIgnoreCase("life")) {
							recipients[0] = properties.get("admin.email.id.life");
						} else if (domain.equalsIgnoreCase("ltc")) {
							recipients[0] = properties.get("admin.email.id.ltc");
						} else {
							recipients[0] = properties.get("admin.email.id");
						}
					}
				}
				if (EmailServiceConstants.FEED_BACK_FORM.equalsIgnoreCase(formType) && subject != null) {
					emailParams.put("Subject", subject);
					recipients[0] = properties.get("admin.email.id.feedback");

				}
			}
			// emailService.sendEmail(..) returns a list of all the recipients
			// that could not be sent the email
			// An empty list indicates 100% success
			List<String> failureList = emailService.sendEmail(templatePath, emailParams, uploadedFiles, recipients);
			if (failureList.isEmpty()) {
				log.debug("||JHInsEmaiUslServlet || doPost ||Success ");
				String finalURL = resourceResolver.map(redirectPath) + ".html?" + "date=" + date + "&first_Name="
						+ firstN + "&email=" + emailAddress + "&insured_name=" + insuredN + "&category="
						+ categorySelected + "&form=" + formType + "&phone_num=" + telePhone + "&am_a_selected="
						+ iamASelected + "&subject=" + subject + "&firm=" + firmN + "&comments=" + comments;
				// String validURL = validateURL(finalURL, request);
				// if(!"".equalsIgnoreCase(validURL)){
				response.sendRedirect(finalURL);
				// }
				deleteFiles(uploadedFiles);
				return;
			} else {
				log.error("||JHInsEmaiUslServlet || doPost ||Failed ");
				response.sendRedirect(redirectPath + ".html");
				return;

			}

		} catch (IOException e) {
			log.error("Exception was throwed in Servlet" + e);
		}

	}

	private void deleteFiles(List<File> uploadedFiles) {
		// TODO Auto-generated method stub
		for (File aFile : uploadedFiles) {
			aFile.delete();
		}
	}

	/**
	 * Saves files uploaded from the client and return a list of these files
	 * which will be attached to the e-mail message.
	 * 
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private List<File> saveUploadedFiles(HttpServletRequest request)
			throws IllegalStateException, ServletException, FileNotFoundException, IOException {
		List<File> listFiles = new ArrayList<File>();
		byte[] buffer = new byte[4096];
		int bytesRead = -1;
		Collection<Part> multiparts;
		FileOutputStream outputStream = null;
		File saveFile = null;
		InputStream inputStream = null;
		try {
			multiparts = request.getParts();

			log.error("Collection size with parts ***" + multiparts.size());
			if (multiparts.size() > 0) {
				for (Part part : request.getParts()) {
					log.error("PART ***" + part.getName());
					// creates a file to be saved
					String fileName = extractFileName(part);
					if (fileName == null || fileName.equals("")) {
						// not attachment part, continue
						continue;
					}
					saveFile = new File(fileName);
					log.error("saveFile: " + saveFile.getAbsolutePath());
					outputStream = new FileOutputStream(saveFile);

					// saves uploaded file
					inputStream = part.getInputStream();
					while ((bytesRead = inputStream.read(buffer)) != -1) {
						outputStream.write(buffer, 0, bytesRead);
					}
					listFiles.add(saveFile);
					outputStream.close();
					inputStream.close();
					
				}
			}
		} finally {
			if (null != outputStream) {
				closeOutputStream(outputStream);
			}
			if (null != inputStream) {
				closeInputStream(inputStream);
			}
		}

		log.error("RETURNING FILE LIST SIZE******" + listFiles.size());
		return listFiles;
	}

	/**
	 * Close InputStream file
	 */
	public static void closeInputStream(InputStream inputStream) {
		if (null != inputStream) {
			try {
				inputStream.close();
			} catch (IOException e) {
				log.error("IOException in JHINSEmailServlet", e);
			}
		}
	}

	/**
	 * Close OutputStream file
	 */
	public static void closeOutputStream(FileOutputStream outputStream) {
		if (null != outputStream) {
			try {
				outputStream.close();
			} catch (IOException e) {
				log.error("IOException in JHINSEmailServlet", e);
			}
		}
	}

	/**
	 * Retrieves file name of a upload part from its HTTP header
	 */
	private String extractFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return null;
	}
}
