package com.jh.jhins.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ContactInfoDAO {
	private static final Logger LOG = LoggerFactory.getLogger(ContactInfoDAO.class);
	/**
	 * @receives mapObj
	 * 		Retrieves user selected state from database	
	 * @return array list of states
	 */

	public ArrayList<String> getStates(Map<String, Object> mapObj)
	{
		ArrayList<String> userStates=new ArrayList<String>();
		userStates.add("tx");
		userStates.add("nv");
		userStates.add("id");
		userStates.add("la");
		Collections.sort(userStates);

		return userStates;

	}
}


