package com.jh.jhins.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jh.jhins.bean.ArticleBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.helper.ArticleHelper;
import com.jh.jhins.helper.JHPageHelper;

public class NewsInfoDAO {
	private static Session session;
	private static final Logger LOG = LoggerFactory.getLogger(NewsInfoDAO.class);

	/**
	 * Receives map with user login details Sets bean with article details
	 * 
	 * @param mapObj
	 * 
	 *            returns list of articlebeans
	 * @throws RepositoryException
	 * @throws ParseException
	 * 
	 */
	public ArrayList<ArticleBean> getMyNewsUpdates(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {
		LOG.debug("Starting of getMyNewsUpdates method");
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		ArticleBean articleBean = new ArticleBean();
		Query query = createSearchQuery(mapObj);
		SearchResult searchRes = executeQuery(query);
		SlingHttpServletRequest slingRequest = null;
		ResourceResolver resourceResolver = null;
		if (!searchRes.getHits().isEmpty()) {
			LOG.debug("searchRes.getHits() is not empty");
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
				resourceResolver = slingRequest.getResourceResolver();
				articleBean = new ArticleBean();
				articleBean = ArticleHelper.retriveArticleBean(queryPath, resourceResolver);
				articlebeans.add(articleBean);				
			}
		}
		LOG.debug("End of getMyNewsUpdates method");
		return articlebeans;
	}

	/**
	 * Query for fetching the recent articles based on firm
	 * 
	 * @param mapObj
	 * 
	 *            returns Query result
	 */

	private Query createSearchQuery(Map<String, Object> mapObj) {
		LOG.debug("Starting of createSearchQuery method");
		Query query = null;
		UserTO userTO = new UserTO();
		if (mapObj.get(NewsConstants.USERTO) != null) {
			userTO = (UserTO) mapObj.get(NewsConstants.USERTO);
			String firm = userTO.getFirmID();
			String limit = mapObj.get(NewsConstants.PARAM_LIMIT).toString();
			LOG.debug("User belongs to firm : "+firm);
			SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", NewsConstants.PAGE_TYPE);
			map.put("2_property", NewsConstants.CQ_TAGS__PROPERTYNAME);
			map.put("2_property.value", firm);
			map.put("1_property", NewsConstants.CQ_TEMPLATE);
			map.put("1_property.value", NewsConstants.ARTICLE_TEMPLATE);
			map.put("orderby", NewsConstants.ORDER_BY);
			map.put("orderby.sort", NewsConstants.ODERBY_SORT);
			map.put("p.limit", limit);
			ArticleHelper.getFilterForUserRole(map, userTO);
			query = queryBuilder.createQuery(PredicateGroup.create(map), session);	
		}
		LOG.debug("End of createSearchQuery method");
		return query;
	}

	/**
	 * Query for calling the querystring
	 * 
	 * @param querystring
	 * 
	 *            returns Search result
	 */
	private SearchResult executeQuery(Query queryString) {
		LOG.debug("Starting of executeQuery method");
		SearchResult searchRes = queryString.getResult();
		LOG.debug("End of executeQuery method");
		return searchRes;

	}

	/**
	 * Method for fetching related Articles
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public ArrayList<ArticleBean> getRelatedArticles(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {
		LOG.debug("Strating of getRelatedArticles method");
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		String path = mapObj.get(NewsConstants.PARAM_PATH).toString();
		String topic = mapObj.get(NewsConstants.PARAM_TOPIC).toString();
		String limit = mapObj.get(NewsConstants.PARAM_LIMIT).toString();
		LOG.debug("path = "+path+"  topic = "+topic+"  limit = "+limit);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
		// start of changes for user role
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		// end of changes for user role
		articlebeans = ArticleHelper.retriveRelatedArticlesByTopic(slingRequest, path, topic, limit, userTo);
		LOG.debug("End of getRelatedArticles method");
		return articlebeans;
	}

	/**
	 * Method for fetching channel news
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */
	public ArrayList<ArticleBean> getChannelNews(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {
		LOG.debug("Starting of getChannelNews method");
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		String path = mapObj.get(NewsConstants.PARAM_PATH).toString();
		String channel = mapObj.get(NewsConstants.PARAM_CHANNEL).toString();
		String limit = mapObj.get(NewsConstants.PARAM_LIMIT).toString();
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
		// start of changes for user role
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		// end of changes for user rol
		articlebeans = ArticleHelper.retriveRelatedArticlesByChannel(slingRequest, path, channel, limit, userTo);
		LOG.debug("End of getChannelNews method");

		return articlebeans;
	}

	/**
	 * Gets the news item based on channel. This method supports pagination
	 * 
	 * @param mapObj
	 * @return
	 * @throws RepositoryException
	 * @throws ParseException
	 */
	public Map<String, Object> getChannelNewsCentralIntelligence(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {

		Map<String, Object> resultMap = null;
		String path = mapObj.get(NewsConstants.PARAM_PATH).toString();
		String channel = mapObj.get(NewsConstants.PARAM_CHANNEL).toString();
		String limit = mapObj.get(NewsConstants.PARAM_LIMIT).toString();

		String pageNo = mapObj.get(NewsConstants.PARAM_PAGE_NO) != null
				? mapObj.get(NewsConstants.PARAM_PAGE_NO).toString() : NewsConstants.PAGE_NO_ONE;

				SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
				// start of changes for user role
				UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
				// end of changes for user rol
				resultMap = ArticleHelper.retriveRelatedArticlesByChannel(slingRequest, path, channel, limit, pageNo, userTo);

				return resultMap;
	}

	/**
	 * Method for fetching channel and Product news
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public ArrayList<ArticleBean> getChannelAndProductNews(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {
		LOG.debug("Starting of getChannelAndProductNews method");
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		String path = mapObj.get(NewsConstants.PARAM_PATH).toString();
		String channel = mapObj.get(NewsConstants.PARAM_CHANNEL).toString();
		String product = mapObj.get(NewsConstants.PARAM_PRODUCT).toString();
		String limit = mapObj.get(NewsConstants.PARAM_LIMIT).toString();
		LOG.debug("path = "+path+" channel = "+channel+" product = "+product+" limit = "+limit);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		// start of changes for user role
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		// end of changes for user rol
		articlebeans = ArticleHelper.retriveRelatedArticlesByChannelAndProduct(slingRequest, path, channel, product,
				limit, userTo);
		LOG.debug("End of getChannelAndProductNews method");
		return articlebeans;
	}

	/**
	 * receives HashMap Calls retrieveRecentNews returns ArrayList<ArticleBean>
	 * 
	 */
	public ArrayList<ArticleBean> getRecentNews(Map<String, Object> mapObj) throws RepositoryException, ParseException {
		LOG.debug("Starting of getRecentNews method");
		
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		articlebeans = ArticleHelper.retrieveRecentNews(mapObj);
		LOG.debug("My News and Updates articlebean" + articlebeans);
		LOG.debug("End of getRecentNews method");

		return articlebeans;
	}

	/**
	 * Method for fetching related pages
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */
	public ArrayList<ArticleBean> getRelatedPages(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		articlebeans = JHPageHelper.retriveRelatedPagesByTopic(mapObj,userTo);
		LOG.debug("Get related pages articlebean: " + articlebeans);

		return articlebeans;
	}


	public Map<String, Object> retrieveLifeLtcAllNews(Map<String, Object> mapObj, String topic) {
		String limit = mapObj.get(NewsConstants.PARAM_LIMIT).toString();
		String[] channels = null;
		if (topic != null) {
			//LOG.error("CHANNELS IN RETRIVE***" + channels);
			channels = getChannels(mapObj);
		} else if ("".equals(topic)) {
			//  LOG.error("CHANNELS IN RETRIVE***" + channels);
			channels = getChannels(mapObj);
			topic = null;
		}
		String pageNo = mapObj.get(NewsConstants.PARAM_PAGE_NO) != null
				? mapObj.get(NewsConstants.PARAM_PAGE_NO).toString() : NewsConstants.PAGE_NO_ONE;
				SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);

				UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);

				return ArticleHelper.getTopicNews(slingRequest, limit, channels, userTo, pageNo, topic);

	}

	private String[] getChannels(Map<String, Object> mapObj) {
		Object channelObject = mapObj.get(JHINSConstants.PARAM_CHANNELS);
		String[] channels = null;
		if (channelObject != null) {
			String channel = (String) mapObj.get(JHINSConstants.PARAM_CHANNELS);
			channels = channel.split(",");
		}
		return channels;
	}

}
