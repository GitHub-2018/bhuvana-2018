package com.jh.jhins.bean;

import java.util.List;

public class ContactDetailsBean {
	private String state = "";
	private String title = "";
	private String address = "";
	private String phone = "";
	private String fax = "";
	private String tollfree = "";
	private String stateName = "";
	private List<PersonalContactBean> personalBean;

	/**
	 * returns the State
	 * 
	 * @return
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the state
	 * 
	 * @param state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * returns the title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Set the title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * returns the address
	 * 
	 * @return
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * sets the address
	 * 
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Returns the phone number
	 * 
	 * @return
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Sets the phone number
	 *
	 * @param phone
	 */

	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Returns the Fax number
	 * 
	 * @return
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * Sets the fax
	 * 
	 * @param fax
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * returns the tollfree number
	 * 
	 * @return
	 */
	public String getTollfree() {
		return tollfree;
	}

	/**
	 * sets the tollfree number
	 * 
	 * @param tollfree
	 */
	public void setTollfree(String tollfree) {
		this.tollfree = tollfree;
	}

	/**
	 * Returns the Personal Contacts for the state
	 * 
	 * @return
	 */
	public List<PersonalContactBean> getPersonalBean() {
		return personalBean;
	}

	/**
	 * Sets the personal contacts for the state
	 * 
	 * @param personalBean
	 */
	public void setPersonalBean(List<PersonalContactBean> personalBean) {
		this.personalBean = personalBean;
	}

	/**
	 * returns the name of the state
	 * 
	 * @return
	 */
	public String getStateName() {
		return stateName;
	}

	/**
	 * sets the name of the state
	 * 
	 * @param stateName
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
}
