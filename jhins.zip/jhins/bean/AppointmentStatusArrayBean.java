package com.jh.jhins.bean;

import java.util.List;

public class AppointmentStatusArrayBean {
	
	private List<SearchRequests> searchRequests;
	private String userRole;


	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public List<SearchRequests> getSearchRequests() {
		return searchRequests;
	}

	public void setSearchRequests(List<SearchRequests> searchRequests) {
		this.searchRequests = searchRequests;
	}

	
}
