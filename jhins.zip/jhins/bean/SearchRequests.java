package com.jh.jhins.bean;

import java.util.List;

public class SearchRequests {
	
	
	private String lastName;
	private String lastFourSSN;
	private String npn;
	private String tin;
	private String payrollNumber;
	private String agentCode;
	private String requestType;
	private List<String> productTypes;
	private List<String> statesTerritories;

	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getLastFourSSN() {
		return lastFourSSN;
	}
	public void setLastFourSSN(String lastFourSSN) {
		this.lastFourSSN = lastFourSSN;
	}
	public String getNpn() {
		return npn;
	}
	public void setNpn(String npn) {
		this.npn = npn;
	}
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	public String getPayrollNumber() {
		return payrollNumber;
	}
	public void setPayrollNumber(String payrollNumber) {
		this.payrollNumber = payrollNumber;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public List<String> getProductTypes() {
		return productTypes;
	}
	public void setProductTypes(List<String> productTypes) {
		this.productTypes = productTypes;
	}
	public List<String> getStatesTerritories() {
		return statesTerritories;
	}
	public void setStatesTerritories(List<String> statesTerritories) {
		this.statesTerritories = statesTerritories;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	

}
