package com.jh.jhins.workflow;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.ComponentContext;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.jh.jhins.email.EmailService;

@Component(immediate = true)
@Service
@Properties({ @Property(name = WorkflowConstants.SERVICE_DESCRIPTION, value = "Process for Jh content Owner Selection"),
	@Property(name = WorkflowConstants.SERVICE_VENDOR, value = "JHINS"),
	@Property(name = WorkflowConstants.PROCESS_LABEL, value = "JHINS Content Owner Selection"),
	@Property(name = WorkflowConstants.HOST_ID, value = "localhost:4502") })
public class ContentOwnerSelectionProcess implements WorkflowProcess {
	@Reference
	ResourceResolverFactory resolverFactory;

	// Reference for email service
	@Reference
	EmailService emailService;

	// Reference for activating the sling property
	private Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		properties = context.getProperties();
	}

	private static final Logger LOG = LoggerFactory.getLogger(ContentOwnerSelectionProcess.class);

	/**
	 * Workflow Execute Method to send the mail for the given details (users)in
	 * dialog
	 * 
	 */
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
			throws WorkflowException {
		ResourceResolver resourceResolver = null;
		try {
			String prinicipalParticipiant = "";
			Node jcrNode = null;
			WorkflowData workflowData = workItem.getWorkflowData();
			String payloadPath = workflowData.getPayload().toString();

			resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);

			if (workflowData.getPayloadType().equals(WorkflowConstants.TYPE_JCR_PATH)) {
				Session jcrSession = workflowSession.adaptTo(Session.class);
				Node node = jcrSession.getNode(payloadPath);

				if (node != null && node.hasNode(WorkflowConstants.JCR_CONTENT)) {
					jcrNode = node.getNode(WorkflowConstants.JCR_CONTENT);
					if (jcrNode != null && jcrNode.hasProperty(WorkflowConstants.PROPERTY_SELECT)) {
						prinicipalParticipiant = jcrNode.getProperty(WorkflowConstants.PROPERTY_SELECT).getValue()
								.toString();
					}
				}

				String templatePath = getProcessArgValues(WorkflowConstants.TEMPLATE_PATH, metaDataMap);
				String ccRecipient = getProcessArgValues(WorkflowConstants.EMAIL_CC_RECIPIENT, metaDataMap);
				String[] emailRecipients = getEmailAddrsFromUserPath(resourceResolver, prinicipalParticipiant);
				Map<String, String> emailParams = new HashMap<String, String>();
				emailParams.put(WorkflowConstants.EMAIL_CC_RECIPIENT, ccRecipient);
				String hostId = properties.get(WorkflowConstants.HOST_ID);
				String pageUrl = WorkflowConstants.HTTP + "://" + hostId + payloadPath + "." + WorkflowConstants.HTML;
				emailParams.put(WorkflowConstants.EMAIL_PAGE_URL, pageUrl);
				List<String> failureList = emailService.sendEmail(templatePath, emailParams, emailRecipients);
				if (failureList.isEmpty()) {
					LOG.debug("Email Sending Success ");
				} else {
					LOG.debug("Email Sending Failure ");
				}
			}

		} catch (RepositoryException e) {
			LOG.error("RepositoryException occurred in service ", e);
		} catch (LoginException e) {
			LOG.error("LoginException occurred in service", e);
		} finally {
			if (resourceResolver != null) {
				resourceResolver.close();
			}
		}

	}

	/**
	 * Method to get the processargs values
	 * 
	 * @param key
	 * @param metadatamap
	 * @return String
	 */
	private String getProcessArgValues(String key, MetaDataMap metaDataMap) {
		String processArguments[];
		String argumentValue = " ";
		String processArgs = metaDataMap.get(WorkflowConstants.PROCESS_ARGS, String.class);
		if (processArgs != null && !processArgs.equals("")) {
			processArguments = processArgs.split(",");

			for (int i = 0; i < processArguments.length; i++) {
				String trimmedStr = processArguments[i].trim();
				if (trimmedStr.startsWith(key + ":")) {
					argumentValue = trimmedStr.substring((key + ":").length());
					break;
				}
			}
		}

		return argumentValue;
	}

	/**
	 * Method to get the email address from the cq user id path values
	 * 
	 * @param resourceResolver
	 * @param principlePath
	 * @return String[]
	 */
	private static String[] getEmailAddrsFromUserPath(ResourceResolver resourceResolver, String principlePath) {
		List<String> emailList = new ArrayList<String>();

		try {
			Resource authRes = resourceResolver.getResource(principlePath);
			if (authRes != null) {
				Authorizable authorizable = authRes.adaptTo(Authorizable.class);
				if (authorizable != null) {
					// check if it is a group
					if (authorizable.isGroup()) {
						Group authGroup = authRes.adaptTo(Group.class);

						// iterate over members of the group and add emails
						Iterator<Authorizable> memberIt = authGroup.getMembers();
						while (memberIt.hasNext()) {
							String currEmail = getAuthorizableEmail(memberIt.next());
							if (currEmail != null)
								emailList.add(currEmail);
						}
					} else {
						// otherwise is an individual user
						String authEmail = getAuthorizableEmail(authorizable);
						if (authEmail != null)
							emailList.add(authEmail);
					}
				}
			}
		} catch (RepositoryException e) {
			LOG.error("Could not get list of email(s) for users. {}", e);
		}
		String[] emailReturn = new String[emailList.size()];
		return emailList.toArray(emailReturn);
	}

	/**
	 * Method to get the authorzable user email address from the cq user id path
	 * values
	 * 
	 * @param authorizable
	 * @return String
	 */
	private static String getAuthorizableEmail(Authorizable authorizable) throws RepositoryException {
		if (authorizable.hasProperty(WorkflowConstants.PROFILE_EMAIL)) {
			Value[] emailVal = authorizable.getProperty(WorkflowConstants.PROFILE_EMAIL);
			return emailVal[0].getString();
		}
		return "admin";
	}

}
