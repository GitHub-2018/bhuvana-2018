package com.jh.jhins.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Model(adaptables = Resource.class, defaultInjectionStrategy=DefaultInjectionStrategy.OPTIONAL)
public class EserviceModel {

	private static final Logger LOG = LoggerFactory.getLogger(EserviceModel.class);
	
	@Inject
	@Optional
	private List<String> individualProducts;
	@Inject
	@Optional
	private List<String> corporateProducts;
	@Inject
	@Optional
	private List<String> mproprietoryProducts;
	 
	@Inject
	private ResourceResolver resourceResolver;
	 
	private Map<String,String> individualProductsMap;
	 
	private Map<String,String> corporateProductsMap;
	
	private Map<String,String> mproprietoryProductsMap;
	
	private TreeMap<String, String> individiualProductsSubMap1;
	private TreeMap<String, String> individiualProductsSubMap2;
	private TreeMap<String,String> corporateProductsSubMap1;
	private TreeMap<String,String> corporateProductsSubMap2;
	private TreeMap<String,String> mproprietoryProductsSubMap1;
	private TreeMap<String,String> mproprietoryProductsSubMap2;
	
	@PostConstruct
	protected void init()
	{
		individualProductsMap = getProductsMap(individualProducts);
		corporateProductsMap = getProductsMap(corporateProducts);
		mproprietoryProductsMap = getProductsMap(mproprietoryProducts);
			
		setIndividiualProductsSubMap1(getFirstColumnData(individualProductsMap)); 
		setIndividiualProductsSubMap2(getSecondColumnData(individualProductsMap)); 
		setCorporateProductsSubMap1(getFirstColumnData(corporateProductsMap)); 
		setCorporateProductsSubMap2(getSecondColumnData(corporateProductsMap));
		setMproprietoryProductsSubMap1(getFirstColumnData(mproprietoryProductsMap)); 
		setMproprietoryProductsSubMap2(getSecondColumnData(mproprietoryProductsMap));
		        
	}

	private TreeMap<String, String> getSecondColumnData(Map<String, String> productsMap) {
			int parsedSize = 0;
			int splitSize = productsMap.size()/2;
		TreeMap<String, String> tempMap = new TreeMap<String, String>();
        for(Map.Entry<String, String> entry : productsMap.entrySet()){
            parsedSize ++;
            
             if(parsedSize > splitSize && parsedSize <= productsMap.size()){
            	 tempMap.put(entry.getKey(), entry.getValue());
            }
        }
        LOG.debug("getSecondColumnData::"+tempMap.toString());
        return tempMap;
	}

	private TreeMap<String, String> getFirstColumnData(Map<String, String> productsMap) {
		int parsedSize = 0;
        int splitSize = productsMap.size()/2;
		TreeMap<String, String> tempMap = new TreeMap<String, String>();
        for(Map.Entry<String, String> entry : productsMap.entrySet()){
            parsedSize ++;
            
            if(parsedSize <= splitSize){
            	tempMap.put(entry.getKey(), entry.getValue());
            	
            }
        }
        LOG.debug("getFirstColumnData::"+tempMap.toString());
        return tempMap;
	}
    
    public Map<String, String> getIndividualProductsMap() {
		return individualProductsMap;
	}

	public Map<String, String> getCorporateProductsMap() {
		return corporateProductsMap;
	}

	public Map<String, String> getMproprietoryProductsMap() {
		return mproprietoryProductsMap;
	}
	public TreeMap<String, String> getIndividiualProductsSubMap1() {
		return individiualProductsSubMap1;
	}

	public void setIndividiualProductsSubMap1(TreeMap<String, String> individiualProductsSubMap1) {
		this.individiualProductsSubMap1 = individiualProductsSubMap1;
	}

	public TreeMap<String, String> getIndividiualProductsSubMap2() {
		return individiualProductsSubMap2;
	}

	public void setIndividiualProductsSubMap2(TreeMap<String, String> individiualProductsSubMap2) {
		this.individiualProductsSubMap2 = individiualProductsSubMap2;
	}

	public TreeMap<String, String> getCorporateProductsSubMap1() {
		return corporateProductsSubMap1;
	}

	public void setCorporateProductsSubMap1(TreeMap<String, String> corporateProductsSubMap1) {
		this.corporateProductsSubMap1 = corporateProductsSubMap1;
	}

	public TreeMap<String, String> getCorporateProductsSubMap2() {
		return corporateProductsSubMap2;
	}

	public void setCorporateProductsSubMap2(TreeMap<String, String> corporateProductsSubMap2) {
		this.corporateProductsSubMap2 = corporateProductsSubMap2;
	}

	public TreeMap<String, String> getMproprietoryProductsSubMap1() {
		return mproprietoryProductsSubMap1;
	}

	public void setMproprietoryProductsSubMap1(TreeMap<String, String> mproprietoryProductsSubMap1) {
		this.mproprietoryProductsSubMap1 = mproprietoryProductsSubMap1;
	}

	public TreeMap<String, String> getMproprietoryProductsSubMap2() {
		return mproprietoryProductsSubMap2;
	}

	public void setMproprietoryProductsSubMap2(TreeMap<String, String> mproprietoryProductsSubMap2) {
		this.mproprietoryProductsSubMap2 = mproprietoryProductsSubMap2;
	}

	private Map<String, String> getProductsMap(List<String> productsList) {
		Map<String,String> productsMap=new HashMap<String,String>();
		if(null != productsList && !productsList.isEmpty() ){
			for(String path :productsList ){
				Resource resource = resourceResolver.getResource(path);
				LOG.info("resource:::::"+resource.getName());
				Resource pageResource =resource.getResourceResolver().getResource(resource.getPath()+"/jcr:content/par/productprofilecomp");
		  		  if( null != pageResource){
			    		  ValueMap resourceValMap =pageResource.getValueMap();
			    		  String productCode = resourceValMap.get("productCode").toString();
			    		  String productName = resourceValMap.get("name").toString();
			    		  productsMap.put(productName,productCode);
		  		  }
			}
		}
		TreeMap<String, String> treeMap = new TreeMap<String, String>(productsMap);
		return treeMap;
	}

}
