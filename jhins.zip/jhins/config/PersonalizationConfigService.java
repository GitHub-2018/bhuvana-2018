package com.jh.jhins.config;

public interface PersonalizationConfigService {
	public static final String IFRAME_SOURCE_NAME = "iframe.source.name";
	
	public String getIframeSource();
}
