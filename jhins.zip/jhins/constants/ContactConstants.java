package com.jh.jhins.constants;

public class ContactConstants {
	public static final String NAME = "name";
	public static final String DESIGNATION = "designation";
	public static final String EMAIL = "email";
	public static final String EXTENSION = "extension";
	public static final String STATE = "state";
	public static final String STATE_NAME="stateName";
	public static final String TITLE = "title";
	public static final String ADDRESS = "address";
	public static final String FAX = "fax";
	public static final String PHONE = "phone";
	public static final String NODE = "personalContacts";
	public static final String TOLLFREE ="tollfree";
	public static final String PARAM_TABTYPE="tabType";
	public static final String CONTACT_INFORMATION="contactInformation";
	public static final String SALES_SUPPORT="salesSupport";
	public static final String PARAM_TAGPATH="tagPath";
	public static final String PARAM_FUNCTIONALITY = "functionality";
	public static final String PARAM_PATH="path";
	
	public static final String NT_UNSTRUCTURED="nt:unstructured";
	public static final String SLING_RESOURCETYPE="sling:resourceType";
	public static final String SLING_RESOURCETYPE_VALUE="JHINS/components/content/contact";
	public static final String SLING_REQUEST="slingRequest";
	public static final String JCR_TITLE="jcr:title";
	public static final String JCR_CONTENT_PAR="/jcr:content/par";
	
	
	

}
