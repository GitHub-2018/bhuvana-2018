/*For verified and unverified user*/
$(function (){
var userRole;
    if(typeof UserData != undefined){
	 	 userRole = UserData.content['iv-groups'];
    } 
if(userRole != undefined && userRole =='UnverifiedProducers'){
 $(".textwithpersonalization" ).each( function( index, element ){
     var group = $(this).attr("group");
		if(group=='unverified'){
           $(this).show();
        }
    else{
        if(group=='verified'){
             $(this).hide();
        }
    }
});
}else if(userRole != undefined && userRole !=='UnverifiedProducers'){
 $(".textwithpersonalization" ).each( function( index, element ){
     var group = $(this).attr("group");
		if(group=='verified'){
           $(this).show();
        }
    else{
        if(group=='unverified'){
             $(this).hide();
        }
    }
});
  }
});

