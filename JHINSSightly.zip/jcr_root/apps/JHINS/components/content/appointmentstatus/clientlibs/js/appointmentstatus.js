
 $(document).ready(function(){

			var userRole ="Producer"; //x  FirmSupport  ProducerSupport
            var profileIdVal="234407"; //234407  244887
    		var formData ;

    	 // ajax call for Producer and ProducerSupport Role
         if(userRole == "Producer" || userRole == "ProducerSupport"){
         }

        //Form POST Ajax call for FirmSupport and Super user Role
     	$("#submitRequestAgent").on("click", function(event){

		if (validate()) {
			console.log(newStates);
        	$("#appointmentStatusInput").hide();
			$("#appointmentStatusProgress").show();

        	var obj = new Object();
   			obj.profileId = "234407";
  			obj.userRole = "Producer";
   			obj.states= newStates;
   			obj.products= ["Life","Variable Life"];
			formData = JSON.stringify(obj);
			console.log(formData);
			callAjax(formData);
        	}
        event.preventDefault();
     });

     	//
     	function callAjax(formData){

     	     		$.ajax({  
     	                type: "POST",  
     	                url: "/bin/sling/appointmentstatus",  
                        data: {formData: formData},
     	                dataType: 'json',
     	                cache: false,
     	                beforeSend: function(){
     	                	$(".loader_img").show();
     	                  },
     					complete: function(){
     	                    $(".loader_img").hide();
     	                },
     	                success: function(resp){  
     	                    console.log(resp);

     	                 }, 
     	                 error: function(e){  
     	                    console.log("error"+e);
     	                       event.preventDefault();
     	                 } 

     	         	});
     	}


   });


