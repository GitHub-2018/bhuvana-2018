var expanded = false;

var states = [];
var newStates = [];
var newStates1 = [];
var selectcheckboxValue = [];
var getcheckboxId = [];

function showCheckboxes() {
	var checkboxes = document.getElementById("checkboxes");
	if (!expanded) {
		checkboxes.style.display = "block";
		expanded = true;
	} else {
		checkboxes.style.display = "none";
		expanded = false;
	}
}

function updateProductType(val) {
	var ind = product.indexOf(val);

		if (ind == -1) {
			product.push(val);
		} else {
			product.splice(ind, 1);
		}
		productType = product;
		console.log(productType);
	
	} 

function updateSelection(val) {
	    if($("#checkboxes input[type='checkbox'].states_value" ).is(':checked')){
			var ind = states.indexOf(val);
			
			if (ind == -1) {
			states.push(val);
			} else {
			states.splice(ind, 1);
			}
			newStates1 = states;
			newStates1.sort();
			newStates1 = newStates1.join(", ");
				if (states.length > 2) {
					newStates1 = states.slice(0, 2);
					newStates1 = newStates1.join(", ");
					newStates1 = newStates1 + " ..."
				}

	document.getElementById("selectedStates").value = states.join();
	document.getElementsByClassName("overSelect")[0].innerHTML = newStates1; 
				
	}

}
/***************************for select all checkbox***********************************************/
var selectAllValue = [];
function updateSelectionSelectAll(val) {
	if($(".selectall").is(':checked')){
			$("#checkboxes input[type='checkbox'].states_value" ).each(function() {
			    var getId = []; 
			    getId.push($(this).attr( "id" ));
			    selectAllValue.push(getId);
			});
			if (selectAllValue.length > 2) {
			newStates = selectAllValue.slice(0, 2);
			newStates = newStates.join(", ");
			newStates = newStates + " ..."
			}
		document.getElementsByClassName("overSelect")[0].innerHTML = newStates;		
	}
	else{
		$("#checkboxes input[type='checkbox']:checked").each(function() {
			    var getId = []; 
			    getId.push($(this).attr( "id" ));
			    selectAllValue.push(getId);
			    console.log();
			});
			if (selectAllValue.length > 2) {
			newStates = selectAllValue.slice(0, 2);
			newStates = newStates.join(", ");
			newStates = newStates + " ..."
			}
		document.getElementsByClassName("overSelect")[0].innerHTML = newStates;	
	}

}
/***************************for select all checkbox end here***********************************************/
$(document).ready(function () {

	function validate() {
		var states = $("#selectedStates").val();
		var productType = "";

		$("input[name=productType]:checked").each(function () {
			if (productType == "") {
				productType = productType + this.value;
			}
			else {
				productType = productType + "," + this.value;
			}
		});
		if ((states.length == 0) && (productType == 0)) {
			//alert("At least one state must be selected.");
			$("#stateError").show();
			$("#productError").show();
			return false;
		}
		if (states == "") {
			//alert("At least one state must be selected.");
			$("#stateError").show();
			return false;
		}
		if (productType == "") {
			//alert("At least one product must be selected.");
			$("#productError").show();
			return false;
		}
		return true;
	}

/*	$("#submitRequestAgent").click(function () {
			if (validate()) {
				
        		$("#appointmentStatusInput").hide();
				$("#appointmentStatusProgress").show();
			
		}
	}); */

	$("#clearRequestAgent").click(function () {
		$('input[name="productType"]').attr('checked', false);
		$('input[name="statesCheck"]').attr('checked', false);
		states = [];
		document.getElementById("selectedStates").value = states.join();
		//document.getElementsByClassName("overSelect")[0].innerHTML = states.length + " States selected";
		document.getElementsByClassName("overSelect")[0].innerHTML = "";
		$("#stateError").hide();
		$("#productError").hide();
		//$("#submitRequestAgent").show();
		//$(".loading_icon").hide();
	});

	$("#cancel").click(function () {
		$("#appointmentStatusInput").show();
		$("#appointmentStatusProgress").hide();
		//$("#submitRequestAgent").show();
		//$(".loading_icon").hide();
	});

	$("#success").click(function () {

		$("#appointmentStatusProgress").hide();
		$(".overlay").show();
		setTimeout(function(){ 
			$(".overlay").hide(); 
		}, 3000);	    
		$("#appointmentStatusResults").show();
	});

	$("#unavailable").click(function () {
		$("#appointmentStatusProgress").hide();
		$("#appointmentStatusUnavailable").show();
		//$("#submitRequestAgent").show();
		//$(".loading_icon").hide();
	});

	$("#newSearch1, #newSearch2").click(function () {		
		states = [];
		newStates = [];
		$('input[name="productType"]').attr('checked', false);
		$('input[name="statesCheck"]').attr('checked', false);
		document.getElementsByClassName("overSelect")[0].innerHTML = "";
		$("#appointmentStatusResults").hide();
		$("#appointmentStatusInput").show();
		$("#submitRequestAgent").show();
		$(".loading_icon").hide();
	});
	$("#refineSearch1, #refineSearch2").click(function () {
		$("#appointmentStatusResults").hide();
		$("#appointmentStatusInput").show();
		$("#submitRequestAgent").show();
		$(".loading_icon").hide();
	});
	
	$('input[name="productType"]').click(function () {
		$("#checkboxes").hide();
		$("#productError").hide();
	});
	$('input[name="statesCheck"]').click(function () {
		$("#stateError").hide();
	});
	$(document).mouseup(function(e) {
    var container = $("#checkboxes");
    console.log(container);

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) {
       $("#checkboxes").hide();
    }
});

/***************************to export table contentin csv *************************************/
$('#exportResult').click(function() {
  var titles = [];
  var data = [];

  /*
   * Get the table headers, this will be CSV headers
   * The count of headers will be CSV string separator
   */
  $('.dataTable th').each(function() {
    titles.push($(this).text());
  });

  /*
   * Get the actual data, this will contain all the data, in 1 array
   */
  $('.dataTable td').each(function() {
    data.push($(this).text());
  });
  
  /*
   * Convert our data to CSV string
   */
   var CSVString = prepCSVRow(titles, titles.length, '');
  CSVString = prepCSVRow(data, titles.length, CSVString);

  /*
   * Make CSV downloadable
   */
  if (navigator.msSaveBlob)  // For IE 10+
  {
  var downloadLink = document.createElement("a");
  var blob = new Blob([CSVString], {
	"type": "text/csv;charset=utf8;"});
  navigator.msSaveBlob(blob,"data.csv");
  }
  else{
  var downloadLink = document.createElement("a");
  var blob = new Blob(["\ufeff", CSVString]);
  var url = URL.createObjectURL(blob);
  downloadLink.href = url;
  downloadLink.download = "data.csv";
  /*
   * Actually download CSV
   */
 document.body.appendChild(downloadLink);
 downloadLink.click();
 document.body.removeChild(downloadLink);}

});

   /*
* Convert data array to CSV string
* @param arr {Array} - the actual data
* @param columnCount {Number} - the amount to split the data into columns
* @param initial {String} - initial string to append to CSV string
* return {String} - ready CSV string
*/
function prepCSVRow(arr, columnCount, initial) {
  var row = ''; // this will hold data
  var delimeter = ','; // data slice separator, in excel it's `;`, in usual CSv it's `,`
  var newLine = '\r\n'; // newline separator for CSV row

  /*
   * Convert [1,2,3,4] into [[1,2], [3,4]] while count is 2
   * @param _arr {Array} - the actual array to split
   * @param _count {Number} - the amount to split
   * return {Array} - splitted array
   */
  function splitArray(_arr, _count) {
    var splitted = [];
    var result = [];
    _arr.forEach(function(item, idx) {
      if ((idx + 1) % _count === 0) {
        splitted.push(item);
        result.push(splitted);
        splitted = [];
      } else {
        splitted.push(item);
      }
    });
    return result;
  }
  var plainArr = splitArray(arr, columnCount);
  // don't know how to explain this
  // you just have to like follow the code
  // and you understand, it's pretty simple
  // it converts `['a', 'b', 'c']` to `a,b,c` string
  plainArr.forEach(function(arrItem) {
    arrItem.forEach(function(item, idx) {
      row += item + ((idx + 1) === arrItem.length ? '' : delimeter);
    });
    row += newLine;
  });
  return initial + row;
}
/***************************to export table contentin csv end here*************************************/

/*select all thecheckbox on click of select all and vice versa****************/
$('.selectall').click(function() {
    if ($(this).is(':checked')) {
        $('#checkboxes input:checkbox').prop('checked', true);
        
    } else {
        $('#checkboxes input:checkbox').prop('checked', false);
        
    }
});

$("#checkboxes input[type='checkbox'].states_value").change(function(){
    var a = $("#checkboxes input[type='checkbox'].states_value");
    if(a.length == a.filter(":checked").length){
        $(".selectall").prop('checked', true);
    }
    else {
        $(".selectall").prop('checked', false);
    }
});
/*select all thecheckbox on click of select all and vice  versa code end here****************/

/********************Upgrade the select box in alphabetical order****************/


/*************Upgrade the select box in alphabetical order code end here****************/
	
});