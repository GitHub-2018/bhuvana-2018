$(document).ready(function(){

    //Form POST Ajax call for Fund Information
    $("#fundinformation").on("click", function(){     
        var productCode =$(".selection").val();
        var companyCode	="94";
        var formData;
        console.log("selected value is  "+productCode);
        if(null !== productCode && null !== companyCode){
            formData={productCode:productCode,companyCode:companyCode};
        }
        callAjax(formData);
        function callAjax(formData){
            $.ajax({  
                type: "POST",  
                url: "/bin/sling/fundperformance",  
                data: formData,
                dataType: 'json',
                cache: false,
                success: function(response){
                    var data=response.Details.Data;
                    var resultable = document.getElementById("resultable");
                    // IE7 only supports appending rows to tbody
                    var tbody = document.createElement("tbody");
                    if($("#monthlyperformanceResult").is(':hidden')){
                        console.log("hidden");
                    // for each outer array row
                    for (var i = 0 ; i < data.length; i++) {
                        console.log("data first row is "+data[i]);
                        var firstelem=data[i][0];
                        var totalFee="$0";
                        if(firstelem=="EMKTD"){
                            data[i][0]="Emerging Markets Value";
                        }
                         else if(firstelem=="FIND"){
                            data[i][0]="Financial Industries";
                        }
                         else if(firstelem=="AGGR"){
                            data[i][0]="American Global Growth";
                        }
                        else{
                            data[i][0]="Blue Chip Growth";
                        }
                        data[i].splice(1, 0, "$0");
                        console.log("first of ofrst"+firstelem);
                        var tr = document.createElement("tr");

                        // for each inner array cell
                        // create td then text, append
                        for (var j = 0; j < data[i].length; j++) {
                            var td = document.createElement("td");
                            var txt = document.createTextNode(data[i][j]);
                            td.appendChild(txt);
                            tr.appendChild(td);
                        }
                        
                        // append row to table
                        // IE7 requires append row to tbody, append tbody to table
                        tbody.appendChild(tr);
                        resultable.appendChild(tbody);
                    }
                    }
                    //console.log("data is "+data);
                    $("#monthlyperformanceResult").show();
                },
                error: function(e){
                    console.log("error");       

                }

            });
        }


    });

});

