$( function() {

	var cookieVal = document.cookie;

	$("#getWebsealInfo").click(function() {
		$.ajax({

			type: 'POST',
            data:{Cookie:cookieVal},
            url:'/bin/sling/GetWebSealService',
			dataType: 'json',
			success: function(response){
                //console.log("response"+response.content);
                //console.log(typeof response);
				$("#jsonResponse").html(JSON.stringify(response.content));
			},
			error:function(error)
			{
				console.log("Webseal failed!");
				$("#jsonResponse").html(error);

			}
		});
	});


	$("#clearJsonResponse").click(function() {
		$("#jsonResponse").empty();
	});


    $("#getPolicyInfo").click(function() {
        console.log("inside calling function");

        $.ajax({
			type: 'GET',
			url:'/dispatcher/api/policy/getpolicy',
			dataType: 'json',
			success: function(data){
				$("#jsonData").html(JSON.stringify(data));
			},
			error:function(error)
			{
				console.log("personalization failed!");
				$("#jsonData").append("Service Timedout");

			},
            timeout:120000
		});
	});

	$("#clearData").click(function() {
		$("#jsonData").empty();
	});

});
