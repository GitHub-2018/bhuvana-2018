package com.jh.jhins;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.junit.Test;

import com.day.cq.wcm.api.Page;
import com.jh.jhins.bean.ArticleBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.helper.JHPageHelper;
import com.jh.jhins.mock.MockPage;
import com.jh.jhins.mock.MockSlingRequest;

public class JHPageHelperTest {

	@Test
	public void testRetriveRelatedPagesByTopic() {
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put(NewsConstants.PARAM_LIMIT, 3);
		map.put(NewsConstants.PARAM_PATH, "/content/JHINS/en/news");
		UserTO userto= new UserTO();
		map.put(JHINSConstants.USERTO, userto);
		map.put(JHINSConstants.PARAM_TOPIC, "/ect/tags/JHINS/topic/life");
		map.put(NewsConstants.SLING_REQUEST, new MockSlingRequest().slingRequest);
		try {
			List<ArticleBean> articleBeans = JHPageHelper.retriveRelatedPagesByTopic(map,userto);
			assertNotNull(articleBeans);
			assertEquals(articleBeans.isEmpty(), false);
			assertEquals(articleBeans.size(), 3);
			ArticleBean artBean = articleBeans.get(0);
			assertEquals("Test title", artBean.getTitle());
			assertEquals("This is the test description", artBean.getDescription());
			assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", artBean.getPath());

		} catch (RepositoryException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testRetrieveHeaderId() {
	//	fail("Not yet implemented");
	}

	@Test
	public void testRetrievePageChannel() {
		Page page = new MockPage().page;
		try {
			ArrayList<String> channel = JHPageHelper.retrieveChannels(page);
			assertNotNull(channel);
			assertEquals("/content/cq:tags/JHINS/channel/product_announcements", channel.get(0));
		} catch (PathNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ValueFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testRetrieveTopics() {
		Page page = new MockPage().page;
		try {
			ArrayList<String> channel = JHPageHelper.retrieveTopics(page);
			assertNotNull(channel);
			assertEquals("JHINS:topic/Life",  channel.get(0));
		} catch (PathNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ValueFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testRetrieveProducts() {
		Page page = new MockPage().page;
		try {
			ArrayList<String> channel = JHPageHelper.retrieveProducts(page);
			assertNotNull(channel);
			assertEquals("/content/cq:tags/JHINS/product/asg", channel.get(0));
		} catch (PathNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ValueFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testRetrieveChannels() {
		Page page = new MockPage().page;
		try {
			ArrayList<String> channel = JHPageHelper.retrieveChannels(page);
			assertNotNull(channel);
			//System.out.println("val"+channel);
			assertEquals("/content/cq:tags/JHINS/channel/product_announcements", channel.get(0));
		} catch (PathNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ValueFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
