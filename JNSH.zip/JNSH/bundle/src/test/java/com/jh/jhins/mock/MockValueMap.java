package com.jh.jhins.mock;

import static org.mockito.Matchers.anyString;

import java.util.HashMap;

import org.apache.sling.api.resource.ValueMap;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import static org.mockito.Mockito.when;

import com.jh.jhins.constants.ContactConstants;

@RunWith(PowerMockRunner.class)
public class MockValueMap {

	@Mock
	public ValueMap valueMap;
	
	HashMap<String, Object> mockProperties = new HashMap<String, Object>();
	
	public MockValueMap(){
		valueMap = Mockito.mock(ValueMap.class);
		mockProperties.put(ContactConstants.STATE, "AL");
		mockProperties.put(ContactConstants.TITLE, "Testing Contacts");
		mockProperties.put(ContactConstants.ADDRESS, "10, ABC street, dze");
		mockProperties.put(ContactConstants.FAX, "425475524");
		mockProperties.put(ContactConstants.PHONE, "425475524234234");
		mockProperties.put(ContactConstants.TOLLFREE, "25775222221");
		mockProperties.put(ContactConstants.TOLLFREE, "25775222221");
		
		
		mockProperties.put(ContactConstants.NAME, "TestName");
		mockProperties.put(ContactConstants.DESIGNATION, "Producer");
		mockProperties.put(ContactConstants.EMAIL, "abc@jhancock.com");
		mockProperties.put(ContactConstants.EXTENSION, "3453");
	//	PowerMockito.when(valueMap.get(ContactConstants.TITLE,String.class)).thenReturn("AL");
		when(valueMap.get(anyString(),anyString())).thenAnswer(new Answer<String>() {
			public String answer(InvocationOnMock invocation) {
				System.out.println("invoked changed");
		         Object[] args = invocation.getArguments();
		         if(null!=args)
		         System.out.println("args not null");
		         else
		        	 System.out.println("args null");
		         String value = null;
		 //        		         System.out.println("args[0]"+args[0]);
		 //        System.out.println("args[1]"+args[1]);
		       //  if(args[1]==String.class){
		        	 value =  (String)mockProperties.get(args[0]);
		       //  }
		         return value;
		     }
		 });
		
	}
}
