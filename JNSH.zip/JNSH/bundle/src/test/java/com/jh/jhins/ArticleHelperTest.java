package com.jh.jhins;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.text.ParseException;
import java.util.HashMap;
import java.util.*;
import java.util.Map;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.ArticleBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.helper.ArticleHelper;
import com.jh.jhins.mock.MockResourceResolver;
import com.jh.jhins.mock.MockSlingRequest;

public class ArticleHelperTest {
	
	private static final Logger LOG = LoggerFactory.getLogger(ArticleHelper.class);
	@Test
	public void testretrieveRecentNews(){
		
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put(NewsConstants.PARAM_LIMIT, 3);
		map.put(NewsConstants.PARAM_PATH, "/content/JHINS/en/news");
		map.put(NewsConstants.PARAM_TOPIC, "life");
		UserTO userto= new UserTO();
		map.put(JHINSConstants.USERTO, userto);
		map.put(NewsConstants.SLING_REQUEST, new MockSlingRequest().slingRequest);
		try {
			List<ArticleBean> articleBeans = ArticleHelper.retrieveRecentNews(map);
			assertNotNull(articleBeans);
			assertEquals(articleBeans.isEmpty(), false);
			assertEquals(articleBeans.size(), 3);
			ArticleBean artBean = articleBeans.get(0);
			assertEquals("Test title", artBean.getTitle());
			assertEquals("This is the test description", artBean.getDescription());
			assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", artBean.getPath());

		} catch (RepositoryException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testretriveRelatedArticlesByTopic(){
		String path="/content/JHINs/en/news/test";
		String topic = "JHINS:Topic/Life";
		String items = String.valueOf(3);
		UserTO userTo = null;
		SlingHttpServletRequest slingRequest =  new MockSlingRequest().slingRequest;
		try {
			List<ArticleBean> articleBeans = ArticleHelper.retriveRelatedArticlesByTopic(slingRequest,path,topic,items,userTo);
			assertNotNull(articleBeans);
			assertEquals(articleBeans.isEmpty(), false);
			assertEquals(articleBeans.size(), 3);
			ArticleBean artBean = articleBeans.get(0);
			assertEquals("Test title", artBean.getTitle());
			assertEquals("This is the test description", artBean.getDescription());
			assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", artBean.getPath());
			
		} catch (RepositoryException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void testretriveRelatedArticlesByChannel(){
		String path="/content/JHINs/en/news/test";
		String channel = "JHINS:Channel/announcements";
		String items = String.valueOf(3);
		UserTO userTo = null;
		SlingHttpServletRequest slingRequest =  new MockSlingRequest().slingRequest;
		try {
			List<ArticleBean> articleBeans = ArticleHelper.retriveRelatedArticlesByChannel(slingRequest,path,channel,items,userTo);
			assertNotNull(articleBeans);
			assertEquals(articleBeans.isEmpty(), false);
			assertEquals(articleBeans.size(), 3);
			ArticleBean artBean = articleBeans.get(0);
			assertEquals("Test title", artBean.getTitle());
			assertEquals("This is the test description", artBean.getDescription());
			assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", artBean.getPath());
			
		} catch (RepositoryException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void testRetriveRelatedArticlesByChannel(){
		String path="/content/JHINs/en/news/test";
		String channel = "/content/cq:tags/JHINS/channel/system_updates";
		String items = String.valueOf(3);
		String pageNo = String.valueOf(1);
		UserTO userTo = null;
		SlingHttpServletRequest slingRequest =  new MockSlingRequest().slingRequest;
		try {
			Map<String, Object> map = ArticleHelper.retriveRelatedArticlesByChannel(slingRequest,path,channel,items,pageNo,userTo);
			
			assertNotNull(map);
			ArrayList<ArticleBean> articleBeans = (ArrayList<ArticleBean>)map.get(NewsConstants.PARAM_RESULT_BEAN_LIST);
			String displaying = (String)map.get(NewsConstants.STRING_DISPLAYING);
			int currPage = (Integer)map.get(NewsConstants.STRING_CURRENTPAGE);
			long pagecNt = (Long)map.get(NewsConstants.STRING_PAGECOUNT);
			int size = (Integer)map.get(NewsConstants.STRING_SIZE);
			assertNotNull(articleBeans);
			assertEquals(displaying,"1 - 3 of 50");
			assertEquals(currPage,1);
			assertEquals(pagecNt,17l);
			assertEquals(size,5);
			assertEquals(articleBeans.isEmpty(), false);
			assertEquals(articleBeans.size(), 3);
			ArticleBean artBean = articleBeans.get(0);
			assertEquals("Test title", artBean.getTitle());
			assertEquals("This is the test description", artBean.getDescription());
			assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", artBean.getPath());
			
		} catch (RepositoryException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
	}
	
	
	@Test
	public void testRetriveRelatedArticlesByChannelAndProduct(){
		String path="/content/JHINs/en/news/test";
		String channel = "/content/cq:tags/JHINS/channel/system_updates";
		String product = "/content/cq:tags/JHINS/product/asg";
		String items = String.valueOf(3);
		UserTO userTo = null;
		SlingHttpServletRequest slingRequest =  new MockSlingRequest().slingRequest;
		try {
			ArrayList<ArticleBean> articleBeans= ArticleHelper.retriveRelatedArticlesByChannelAndProduct(slingRequest,path,channel,product,items,userTo);
			assertNotNull(articleBeans);
			assertEquals(articleBeans.isEmpty(), false);
			assertEquals(articleBeans.size(), 3);
			ArticleBean artBean = articleBeans.get(0);
			assertEquals("Test title", artBean.getTitle());
			assertEquals("This is the test description", artBean.getDescription());
			assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", artBean.getPath());
			
		} catch (RepositoryException e) {			
			e.printStackTrace();
		} catch (ParseException e) {			
			e.printStackTrace();
		}		
	}

	@Test
	public void testRetriveArticleBean(){
		String path="/content/JHINS/en_US/logged-in/logged-in-home/life-insurance/news/john-hancock-journal";
		ArticleBean articleBean = null;
		
		try {
			articleBean = ArticleHelper.retriveArticleBean(path, new MockResourceResolver().resourceResolver);
			assertNotNull(articleBean);
			assertEquals("Test title", articleBean.getTitle());
			assertEquals("This is the test description", articleBean.getDescription());
			assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", articleBean.getPath());
			
		} catch (PathNotFoundException e) {
			fail();
		} catch (RepositoryException e) {
			
			e.printStackTrace();
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	@Test
	public void testTransferNewsDetailsToJSONObject(){
		ArrayList<ArticleBean> list = new ArrayList<ArticleBean>();
		ArticleBean artBean = new ArticleBean();
		artBean.setTitle("Testing json transfer");
		artBean.setDescription("Testing json object description");
		artBean.setDate("05-Oct-15");
		artBean.setPath("/content/JHINS/en/news/news");
		artBean.setChannel("Product Announcements");
		
		ArticleBean artBean1 = new ArticleBean();
		artBean1.setTitle("Testing json transfer1");
		artBean1.setDescription("Testing json object description1");
		artBean1.setDate("05-Oct-16");
		artBean1.setPath("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal");
		artBean1.setChannel("Product Announcements1");
		
		list.add(artBean);
		list.add(artBean1);
		
		try {
			JSONObject json = ArticleHelper.transferNewsDetailstoJSONobj(list);
			assertNotNull(json);
			JSONArray array = (JSONArray)json.get("list");
			assertNotNull(array);
			JSONObject json1 = (JSONObject)array.get(0);
			assertNotNull(json1);
			String channel = (String)json1.get(NewsConstants.PARAM_CHANNEL);
			String description = (String)json1.get(NewsConstants.PARAM_DESCRIPTION);
			String date = (String)json1.get(NewsConstants.PARAM_DATE);
			String title = (String)json1.get(NewsConstants.PARAM_TITLE);
			assertEquals("Product Announcements", channel);
			assertEquals("Testing json object description", description);
			assertEquals("Testing json transfer", title);
			assertEquals("05-Oct-15", date);
			

			
		} catch (JSONException e) {
			
			e.printStackTrace();
		}
	}
		
		@Test
		public void testTransferNewsDetailsToJSONObjectPagination(){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put(NewsConstants.STRING_DISPLAYING, "1 - 3 of 50");
			map.put(NewsConstants.STRING_CURRENTPAGE, "1");
			map.put(NewsConstants.STRING_PAGECOUNT, "17");
			map.put(NewsConstants.STRING_SIZE, "50");
			
			
			ArrayList<ArticleBean> list = new ArrayList<ArticleBean>();
			ArticleBean artBean = new ArticleBean();
			artBean.setTitle("Testing json transfer");
			artBean.setDescription("Testing json object description");
			artBean.setDate("05-Oct-15");
			artBean.setPath("/content/JHINS/en/news/news");
			artBean.setChannel("Product Announcements");
			
			ArticleBean artBean1 = new ArticleBean();
			artBean1.setTitle("Testing json transfer1");
			artBean1.setDescription("Testing json object description1");
			artBean1.setDate("05-Oct-16");
			artBean1.setPath("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal");
			artBean1.setChannel("Product Announcements1");
			
			list.add(artBean);
			list.add(artBean1);
			map.put(NewsConstants.PARAM_RESULT_BEAN_LIST, list);
			
			try {
				JSONObject json = ArticleHelper.transferNewsDetailstoJSONobj(map);
				assertNotNull(json);
				JSONArray array = (JSONArray)json.get("list");
				
				
				String displaying = (String)json.get(NewsConstants.STRING_DISPLAYING);
				String currPage = (String)json.get(NewsConstants.STRING_CURRENTPAGE);
				String pageCount = (String)json.get(NewsConstants.STRING_PAGECOUNT);
				String size = (String)json.get(NewsConstants.STRING_SIZE);
				
				assertEquals("1 - 3 of 50",displaying);
				assertEquals("1",currPage);
				assertEquals("17",pageCount);
				assertEquals("50",size);
				assertNotNull(array);
				JSONObject json1 = (JSONObject)array.get(0);
				assertNotNull(json1);
				String channel = (String)json1.get(NewsConstants.PARAM_CHANNEL);
				String description = (String)json1.get(NewsConstants.PARAM_DESCRIPTION);
				String date = (String)json1.get(NewsConstants.PARAM_DATE);
				String title = (String)json1.get(NewsConstants.PARAM_TITLE);
				assertEquals("Product Announcements", channel);
				assertEquals("Testing json object description", description);
				assertEquals("Testing json transfer", title);
				assertEquals("05-Oct-15", date);
				

				
			} catch (JSONException e) {
				
				e.printStackTrace();
			}
	}
	
	@Test
	public void testGetTopicNews(){
		String[] channel = {"/content/cq:tags/JHINS/channel/system_updates","/content/cq:tags/JHINS/channel/advanced_markets"};
		String pageNo = String.valueOf(1);
		String limit = String.valueOf(3);
		String topic = "/content/cq:tags/JHINS/topic/life";
		UserTO userTo = null;
		SlingHttpServletRequest slingRequest =  new MockSlingRequest().slingRequest;

		Map<String,Object> map= ArticleHelper.getTopicNews(slingRequest,limit,channel,userTo,pageNo, topic);
		
		
		assertNotNull(map);
		ArrayList<ArticleBean> articleBeans = (ArrayList<ArticleBean>)map.get(NewsConstants.PARAM_RESULT_BEAN_LIST);
		String displaying = (String)map.get(NewsConstants.STRING_DISPLAYING);
		int currPage = (Integer)map.get(NewsConstants.STRING_CURRENTPAGE);
		long pagecNt = (Long)map.get(NewsConstants.STRING_PAGECOUNT);
		int size = (Integer)map.get(NewsConstants.STRING_SIZE);
		assertNotNull(articleBeans);
		assertEquals("1 - 3 of 50",displaying);
		assertEquals(1,currPage);
		assertEquals(17l,pagecNt);
		assertEquals(10,size);
		assertEquals(false,articleBeans.isEmpty());
		assertEquals(3,articleBeans.size());
		ArticleBean artBean = articleBeans.get(0);
		assertEquals("Test title", artBean.getTitle());
		assertEquals("This is the test description", artBean.getDescription());
		assertEquals("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal", artBean.getPath());

		
	}
	
	@Test
	public void testGetFilterForUserRole(){
		
		Map<String,String> map = new HashMap<String,String>();
		UserTO userTo = new UserTO();
		userTo.setFirmID(JHINSConstants.FIRM_TAG_MGROUP);
		map = ArticleHelper.getFilterForUserRole(map, userTo);
		assertNotNull(map);
		String proper10 = map.get("10_group.1_property");
		String proper10Value = map.get("10_group.1_property.value");
		assertNotNull(proper10Value);
		assertNotNull(proper10);
		assertEquals(NewsConstants.CQ_TAGS__PROPERTYNAME, proper10);
		assertEquals(JHINSConstants.FIRM_TAG_MGROUP,proper10Value);
		
		
		map.clear();
		userTo.setFirmID(JHINSConstants.FIRM_TAG_EDJONES);
		map = ArticleHelper.getFilterForUserRole(map, userTo);
		assertNotNull(map);
		proper10 = map.get("10_group.1_property");
		proper10Value = map.get("10_group.1_property.value");
		assertNotNull(proper10Value);
		assertNotNull(proper10);
		assertEquals(NewsConstants.CQ_TAGS__PROPERTYNAME, proper10);
		assertEquals(JHINSConstants.FIRM_TAG_EDJONES,proper10Value);
		
		
	}


}
