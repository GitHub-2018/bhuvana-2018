package com.jh.jhins.mock;

import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Matchers.any;
import java.util.*;
import static org.mockito.Mockito.when;

import com.day.cq.search.PredicateGroup;

public class MockPredicateGroup {
	@Mock
	public PredicateGroup predicateGroup;
	
	public MockPredicateGroup(){
		predicateGroup = Mockito.mock(PredicateGroup.class);
		when(PredicateGroup.create(any(Map.class))).thenReturn(predicateGroup);
	}
}
