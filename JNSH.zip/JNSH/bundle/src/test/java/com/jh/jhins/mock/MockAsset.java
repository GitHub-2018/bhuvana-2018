package com.jh.jhins.mock;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.day.cq.dam.api.Asset;


public class MockAsset {
	
	@Mock
	public Asset asset;
	
	HashMap<String,Object> mockProperties;

	
	public MockAsset(){

		String tags = "/content/cq:tags/JHINS/topic/life,/content/cq:tags/JHINS/type/flyer,/content/cq:tags/JHINS/format/doc";
		
		mockProperties = new HashMap<String, Object>();
		mockProperties.put("dc:title", "Testing");
		mockProperties.put("jcr:description", "This is the test description");
		mockProperties.put("jcr:lastReplicated", "2015-08-13T06:01:48.632-04:00");
		mockProperties.put("jcr:lastModified", "2015-08-13T06:01:48.632-04:00");
		mockProperties.put("cq:tags",tags);
		
		
		asset = Mockito.mock(Asset.class);

		when(asset.getMetadata()).thenReturn(mockProperties);
		when(asset.getMetadataValue(anyString())).thenAnswer(new Answer<Object>() {
		     public Object answer(InvocationOnMock invocation) {
		         Object[] args = invocation.getArguments();
		         return mockProperties.get(args[0]);
		     }
		 });
	}

}
