package com.jh.jhins.mock;

import org.mockito.Mock;
import org.mockito.Mockito;
import java.util.*;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import static org.mockito.Mockito.when;

public class MockSearchResult {	
	@Mock
	public SearchResult searchResult;
	
	public MockSearchResult(){
		searchResult = Mockito.mock(SearchResult.class);
		
		List<Hit> hits = new ArrayList<Hit>();
		Hit hit1 = new MockHit().hit;
		Hit hit2 = new MockHit().hit;
		Hit hit3 = new MockHit().hit;
		hits.add(hit1);
		hits.add(hit2);
		hits.add(hit3);
		when(searchResult.getHits()).thenReturn(hits);
		//when(searchResult.getHits().isEmpty()).thenReturn(false);
		when(searchResult.getStartIndex()).thenReturn(0l);
		when(searchResult.getTotalMatches()).thenReturn(50l);
		
	}}
