/**
 * 
 */
package com.jh.jhins;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.junit.Test;

import com.jh.jhins.bean.AssetMetaDataBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.AssetConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.helper.AssetHelper;
import com.jh.jhins.mock.MockResourceResolver;
import com.jh.jhins.mock.MockSlingRequest;

/**
 * @author mahesma
 *
 */
public class AssetHelperTest {
	
	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#relatedItemsQueryResult(java.lang.String, java.lang.String, java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	
	@Test

	public void testRelatedItemsQueryResult() {
		String product = "JHINS:Product/ASG";
		String topic = "JHINS:Topic/Life";
		String type = "JHINS:Type/Flyer";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.relatedItemsQueryResult(product, topic, type, slingRequest, userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
			
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#consumerMaterialResults(java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	
	@Test
	public void testConsumerMaterialResults() {
		String product = "JHINS:Product/ASG";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.consumerMaterialResults(product, slingRequest, userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getProducerMaterialAssets(java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testGetProducerMaterialAssets() {
		String product = "JHINS:Product/ASG";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.getProducerMaterialAssets(product, slingRequest, userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getSalesFlyerslAssets(java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testGetSalesFlyerslAssets() {
		String product = "JHINS:Product/ASG";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.getSalesFlyerslAssets(product, slingRequest, userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getInvestmentInfoAssets(java.lang.String, java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testGetInvestmentInfoAssets() {
		String product = "JHINS:Product/ASG";
		String product1 = "JHINS:Product/USL";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.getInvestmentInfoAssets(product,product1, slingRequest, userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#retrieveAssetBean(java.lang.String[], org.apache.sling.api.resource.ResourceResolver)}.
	 */

	@Test
	public void testRetrieveAssetBeanStringArrayResourceResolver() {
		String[] paths = {"/content/dam/JHINS/products/asg/abc.doc","/content/dam/JHINS/products/asg/def.doc"};
		ResourceResolver resourceResolver = new MockResourceResolver().resourceResolver;
		try {
			AssetHelper.retrieveAssetBean(paths,resourceResolver);
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#retrieveAssetBean(java.lang.String, org.apache.sling.api.resource.ResourceResolver)}.
	 */
	
	@Test
	public void testRetrieveAssetBeanStringResourceResolver() {
		String path = "/conetnt/DAM/JHINS/newdoc.doc";
		ResourceResolver resourceResolver = new MockResourceResolver().resourceResolver;
		AssetMetaDataBean assetBean = AssetHelper.retrieveAssetBean(path, resourceResolver);
		assertNotNull(assetBean);
		assertEquals("Testing", assetBean.getTitle());
		assertEquals("DOC", assetBean.getFormat());
		assertEquals(path, assetBean.getPath());
		assertEquals("August 13,2015", assetBean.getDate());
		assertEquals("Flyer", assetBean.getType());
		assertEquals(JHINSConstants.TAG_COLOR_RED, assetBean.getColorCode());
		assertEquals("glyphicon glyphicon-file",assetBean.getGlypIcon());
		assertEquals("", assetBean.getClientApproved());
		
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#relatedResourcesByTopic(org.apache.sling.api.SlingHttpServletRequest, java.lang.String, java.lang.String, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testRelatedResourcesByTopic() {
		String topic = "JHINS:Topic/Life";
		String limit = String.valueOf(3);
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.relatedResourcesByTopic(slingRequest, topic, limit, userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#relatedItemsResources(org.apache.sling.api.SlingHttpServletRequest, java.lang.String, java.lang.String, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testRelatedItemsResources() {
		String topic = "JHINS:Topic/Life";
		String limit = String.valueOf(3);
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.relatedItemsResources(slingRequest, topic, limit, userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#transferAssetDetailstoJSONobj(java.util.ArrayList)}.
	 */
	@Test
	public void testTransferAssetDetailstoJSONobj() {
		ArrayList<AssetMetaDataBean> list = new ArrayList<AssetMetaDataBean>();
		AssetMetaDataBean assetBean = new AssetMetaDataBean();
		assetBean.setTitle("Testing");
		assetBean.setDate("Thu Aug 13 06:01:48 EDT 2015");
		assetBean.setPath("/content/dam/JHINS/product/asg/abc.doc");
		assetBean.setChannel("Product Announcements");
		assetBean.setFormat("DOC");
		assetBean.setColorCode(JHINSConstants.TAG_COLOR_RED);
		assetBean.setGlypIcon("glyphicon glyphicon-file");
		
		AssetMetaDataBean assetBean1 = new AssetMetaDataBean();
		assetBean1.setTitle("Testing1");
		assetBean1.setDate("Thu Aug 13 06:01:49 EDT 2015");
		assetBean1.setPath("/content/dam/JHINS/product/asg/abc.doc");
		assetBean1.setChannel("Product Announcements");
		assetBean1.setFormat("PDF");
		assetBean1.setColorCode(JHINSConstants.TAG_COLOR_RED);
		assetBean1.setGlypIcon("glyphicon glyphicon-file");
		
		list.add(assetBean);
		list.add(assetBean1);
		
		try {
			JSONObject json = AssetHelper.transferAssetDetailstoJSONobj(list);
			assertNotNull(json);
			JSONArray array = (JSONArray)json.get("list");
			assertNotNull(array);
			JSONObject json1 = (JSONObject)array.get(0);
			assertNotNull(json1);
			String channel = (String)json1.get(NewsConstants.PARAM_CHANNEL);
			String date = (String)json1.get(NewsConstants.PARAM_DATE);
			String title = (String)json1.get(NewsConstants.PARAM_TITLE);
			String format = (String)json1.get(JHINSConstants.PARAM_FORMAT);
			String colorCode = (String)json1.get(JHINSConstants.PARAM_COLOR_CODE);
			String glypIcon = (String)json1.get(JHINSConstants.PARAM_GLYP_ICON);
			assertEquals("Product Announcements", channel);
			assertEquals("Testing", title);
			assertEquals("Thu Aug 13 06:01:48 EDT 2015", date);
			assertEquals("DOC", format);
			assertEquals(JHINSConstants.TAG_COLOR_RED, colorCode);
			assertEquals("glyphicon glyphicon-file", glypIcon);
			

			
		} catch (JSONException e) {
			
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getRelatedTopic(java.lang.String, java.lang.String, java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testGetRelatedTopic() {
		String product = "/content/cq:tags/JHINS/product/asg";
		String topic = "/content/cq:tags/JHINS/topic/life";
		String type = "/content/cq:tags/JHINS/type/flyer";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.getRelatedTopic(product,type, topic,slingRequest,  userTo);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#retrieveProduct(com.day.cq.wcm.api.Page)}.
	 */
	@Test
	public void testRetrieveProduct() {
		//fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getRelatedResources(java.util.Map)}.
	 */
	@Test
	public void testGetRelatedResources() {
		String topic = "/content/cq:tags/JHINS/topic/life";
		String limit = String.valueOf(3);
		AssetHelper assetHelper = new AssetHelper();
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		Map<String,Object> map = new HashMap<String,Object>();
		map.put(NewsConstants.PARAM_TOPIC, topic);
		map.put(NewsConstants.PARAM_LIMIT, limit);
		map.put(NewsConstants.SLING_REQUEST, slingRequest);
		map.put(JHINSConstants.USERTO, userTo);
		try {
			ArrayList<AssetMetaDataBean> assets = assetHelper.getRelatedResources(map);
			assertNotNull(assets);
			assertEquals(assets.size(), 3);
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getKeyProductMaterials(java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testGetKeyProductMaterials() {
		String product = "/content/cq:tags/JHINS/product/asg";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.getKeyProductMaterials(product,slingRequest,userTo);
			assertNotNull(assets);
			assertEquals(4, assets.size());
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getProspectusAssets(java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testGetProspectusAssets() {
		String product = "/content/cq:tags/JHINS/product/asg";
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = null;
		try {
			ArrayList<AssetMetaDataBean> assets = AssetHelper.getProspectusAssets(product,slingRequest,userTo);
			assertNotNull(assets);
			assertEquals(3, assets.size());
			AssetMetaDataBean asset = assets.get(0);
			assertNotNull(asset);
			assertEquals("Testing", asset.getTitle());
			assertEquals("DOC", asset.getFormat());
			assertEquals("August 13,2015", asset.getDate());
			assertEquals("Flyer", asset.getType());
			assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
			assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
			assertEquals("", asset.getClientApproved());
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#getFilterForUserRole(java.util.Map, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testGetFilterForUserRole() {
		
		Map<String,String> map = new HashMap<String,String>();
		UserTO userTo = new UserTO();
		userTo.setFirmID(JHINSConstants.FIRM_TAG_EDJONES);
		map = AssetHelper.getFilterForUserRole(map, userTo);
		assertNotNull(map);
		String proper10 = map.get("10_group.2_property");
		String proper10Value = map.get("10_group.2_property.value");
		assertNotNull(proper10Value);
		assertNotNull(proper10);
		assertEquals(AssetConstants.CQ_TAGS__PROPERTYNAME, proper10);
		assertEquals(JHINSConstants.FIRM_TAG_EDJONES,proper10Value);
		
		map.clear();
		userTo.setFirmID(JHINSConstants.FIRM_TAG_MGROUP);
		map = AssetHelper.getFilterForUserRole(map, userTo);
		assertNotNull(map);
		proper10 = map.get("10_group.2_property");
		proper10Value = map.get("10_group.2_property.value");
		assertNotNull(proper10Value);
		assertNotNull(proper10);
		assertEquals(AssetConstants.CQ_TAGS__PROPERTYNAME, proper10);
		assertEquals(JHINSConstants.FIRM_TAG_MGROUP,proper10Value);
		
	}

	/**
	 * Test method for {@link com.jh.jhins.helper.AssetHelper#retrieveProspectusesAssets(java.lang.String, java.lang.String, java.lang.String, org.apache.sling.api.SlingHttpServletRequest, com.jh.jhins.bean.UserTO)}.
	 */
	@Test
	public void testRetrieveProspectusesAssets() {
		String prospectusType = "prosType";
		String prospectusTitle = "Test";
		String limit = String.valueOf(3);
		SlingHttpServletRequest slingRequest = new MockSlingRequest().slingRequest;
		UserTO userTo = new UserTO();
		
		ArrayList<AssetMetaDataBean> assets = AssetHelper.retrieveProspectusesAssets(prospectusType, prospectusTitle, limit, slingRequest, userTo);
		assertNotNull(assets);
		assertEquals(3, assets.size());
		AssetMetaDataBean asset = assets.get(0);
		assertNotNull(asset);
		assertEquals("Testing", asset.getTitle());
		assertEquals("DOC", asset.getFormat());
		assertEquals("August 13,2015", asset.getDate());
		assertEquals("Flyer", asset.getType());
		assertEquals(JHINSConstants.TAG_COLOR_RED, asset.getColorCode());
		assertEquals("glyphicon glyphicon-file",asset.getGlypIcon());
		assertEquals("", asset.getClientApproved());
	}
}
