package com.jh.jhins.mock;

import static org.mockito.Mockito.when;

import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.mockito.Mock;
import org.mockito.Mockito;

public class MockValue {
	
	@Mock
	public Value value;

	public MockValue(){
		String date = "2015-08-13T06:01:48.632-04:00";
		value = Mockito.mock(Value.class);
		try {
			when(value.getString()).thenReturn(date);
		} catch (ValueFormatException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (RepositoryException e) {
			e.printStackTrace();
		}
		
	}
}
