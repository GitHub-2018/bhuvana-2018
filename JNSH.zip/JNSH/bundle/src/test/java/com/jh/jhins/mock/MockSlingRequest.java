package com.jh.jhins.mock;

import static org.mockito.Mockito.when;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.mockito.Mock;
import org.mockito.Mockito;

public class MockSlingRequest {
	@Mock
	public SlingHttpServletRequest slingRequest;
	
	public MockSlingRequest(){
		slingRequest = Mockito.mock(SlingHttpServletRequest.class);
		ResourceResolver resourceResovler = new MockResourceResolver().resourceResolver;
		when(slingRequest.getResourceResolver()).thenReturn(resourceResovler);
	}
}
