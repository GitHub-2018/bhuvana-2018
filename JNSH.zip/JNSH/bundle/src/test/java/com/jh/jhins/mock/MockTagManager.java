package com.jh.jhins.mock;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;

import static org.mockito.Matchers.anyString;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import org.mockito.stubbing.Answer;

import static org.mockito.Mockito.when;

public class MockTagManager {
	@Mock
	public TagManager tagManager;
	
	public MockTagManager(){
		tagManager = Mockito.mock(TagManager.class);
		when(tagManager.resolve(anyString())).then(new Answer<Object>() {
		     public Object answer(InvocationOnMock invocation) {
		         Object[] args = invocation.getArguments();
		         Tag tag = new MockTag().tag;
		         if(args!=null && args[0]!=null){
		        	 String tagName = (String)args[0];		        	 
		        	 
		        	 if(tagName.startsWith("/content/cq:tags/JHINS/channel")){
		        		 when(tag.getTagID()).thenReturn("/content/cq:tags/JHINS/channel/system_updates","/content/cq:tags/JHINS/channel/advanced_markets");
		        		 when(tag.getLocalTagID()).thenReturn("JHINS:channel/system_updates","JHINS:channel/advanced_markets");
		        		 when(tag.getPath()).thenReturn("/content/cq:tags/JHINS/channel/system_updates","/content/cq:tags/JHINS/channel/advanced_markets");
		        		 when(tag.getTitle()).thenReturn("Advanced Markets");
		        	 }
		        	 
		        	 if(tagName.startsWith("/content/cq:tags/JHINS/product")){
		        		 when(tag.getTagID()).thenReturn("/content/cq:tags/JHINS/product/asg");
		        		 when(tag.getLocalTagID()).thenReturn("product/ASG");
		        		 when(tag.getPath()).thenReturn("/content/cq:tags/JHINS/product/asg");
		        		 when(tag.getTitle()).thenReturn("ASG");
		        	 }
		        	 
		        	 if(tagName.startsWith("/content/cq:tags/JHINS/topic")){
		        		 when(tag.getTagID()).thenReturn("/content/cq:tags/JHINS/topic/life");
		        		 when(tag.getLocalTagID()).thenReturn("topic/life");
		        		 when(tag.getPath()).thenReturn("/content/cq:tags/JHINS/topic/life");
		        		 when(tag.getTitle()).thenReturn("Life");
		        	 }
		        	 
		        	 if(tagName.startsWith("/content/cq:tags/JHINS/format")){
		        		 when(tag.getTagID()).thenReturn("/content/cq:tags/JHINS/format/doc");
		        		 when(tag.getLocalTagID()).thenReturn("format/DOC");
		        		 when(tag.getPath()).thenReturn("/content/cq:tags/JHINS/format/doc");
		        		 when(tag.getTitle()).thenReturn("DOC");
		        	 }
		        	 if(tagName.startsWith("/content/cq:tags/JHINS/type")){
		        		 when(tag.getTagID()).thenReturn("/content/cq:tags/JHINS/type/flyer");
		        		 when(tag.getLocalTagID()).thenReturn("type/Flyer");
		        		 when(tag.getPath()).thenReturn("/content/cq:tags/JHINS/type/flyer");
		        		 when(tag.getTitle()).thenReturn("Flyer");
		        	 }
		         }
		         return tag;
		     }
		});
	}
}
