package com.jh.jhins.mock;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

public class MockProperty {
	
	@Mock
	public Property property;

	public MockProperty(){
		property = Mockito.mock(Property.class);
		Value value = new MockValue().value;
		
		try {
			String val = value.getString();
			when(property.getValue()).thenReturn(value);
			when(property.getString()).thenReturn(val);
		} catch (ValueFormatException e) {
			e.printStackTrace();
		} catch (RepositoryException e) {
			e.printStackTrace();
		}
	}
}
