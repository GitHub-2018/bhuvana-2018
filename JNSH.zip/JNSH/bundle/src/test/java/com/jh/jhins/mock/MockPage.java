package com.jh.jhins.mock;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import static org.mockito.Mockito.when;

import java.util.HashMap;

import static org.mockito.Matchers.anyString;

import org.apache.sling.api.resource.ValueMap;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;



public class MockPage {
	
	@Mock
	public Page page;
	
	@Mock
	ValueMap properties;
	
	@Mock 
	Tag tag;
	
	@Mock 
	Tag tag1;
	
	
	HashMap<String,Object> mockProperties;
	
	public MockPage(){
		page = Mockito.mock(Page.class);		
		
		properties = Mockito.mock(ValueMap.class);
		
		Tag tag = new MockTag().tag;
		Tag tag1 = new MockTag().tag;
		Tag tag2 = new MockTag().tag;
		when(tag.getLocalTagID()).thenReturn("topic");
		when(tag.getTitle()).thenReturn("Life");
		when(tag.getPath()).thenReturn("/content/cq:tags/JHINS/topic/life");
		when(tag.getTagID()).thenReturn("JHINS:topic/Life");
		
		when(tag1.getLocalTagID()).thenReturn("products");
		when(tag1.getTitle()).thenReturn("ASG");
		when(tag1.getPath()).thenReturn("/content/cq:tags/JHINS/product/asg");
		when(tag1.getTagID()).thenReturn("JHINS:product/ASG");
		
		when(tag2.getLocalTagID()).thenReturn("channel/product_announcements");
		when(tag2.getTitle()).thenReturn("Product Annoucements");
		when(tag2.getPath()).thenReturn("/content/cq:tags/JHINS/channel/product_announcements");
		when(tag2.getTagID()).thenReturn("JHINS:channel/Product Announcements");
		Tag[] tags = {tag,tag1,tag2};
		
		
		mockProperties = new HashMap<String, Object>();
		mockProperties.put("jcr:title", "Testing");
		mockProperties.put("jcr:description", "This is the test description");
		mockProperties.put("cq:lastReplicated", "2015-08-13T06:01:48.632-04:00");
		mockProperties.put("cq:lastModified", "2015-08-13T06:01:48.632-04:00");
		mockProperties.put("cq:tags",tags);
		
		when(page.getProperties()).thenReturn(properties);
		when(page.getPath()).thenReturn("/content/JHINs/en/news/tes");
		when(page.getProperties(anyString())).thenReturn(properties);
		when(page.getPageTitle()).thenReturn("Test page title");
		when(page.getTitle()).thenReturn("Test title");
		when(page.getDescription()).thenReturn(mockProperties.get("jcr:description").toString());
		when(properties.get(anyString())).thenAnswer(new Answer<Object>() {
		     public Object answer(InvocationOnMock invocation) {
		         Object[] args = invocation.getArguments();
		        // Object mock = invocation.getMock();	
		         
		         return mockProperties.get(args[0]);
		     }
		 });
		when(properties.get(anyString(), anyString())).thenAnswer(new Answer<String>() {
			public String answer(InvocationOnMock invocation) {
	         Object[] args = invocation.getArguments();
	        // Object mock = invocation.getMock();
	         String value = null;
	         if(args[1]==String.class){
	        	 value =  (String)mockProperties.get(args[0]);
	         }
	         return value;
	     }
	 });
		when(page.getTags()).thenReturn(tags);
		
		
	}
	


}
