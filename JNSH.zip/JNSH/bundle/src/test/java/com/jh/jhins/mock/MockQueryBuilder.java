package com.jh.jhins.mock;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import javax.jcr.Session;

import org.mockito.Mock;
import org.mockito.Mockito;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;

public class MockQueryBuilder {
	@Mock
	public QueryBuilder queryBuilder;
	
	public MockQueryBuilder(){
		queryBuilder = Mockito.mock(QueryBuilder.class);
		Query query = new MockQuery().query;
		when(queryBuilder.createQuery(any(PredicateGroup.class),any(Session.class))).thenReturn(query);
		when(queryBuilder.createQuery(any(Session.class))).thenReturn(query);

	}
}
