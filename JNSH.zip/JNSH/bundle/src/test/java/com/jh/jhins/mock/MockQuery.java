package com.jh.jhins.mock;

import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;

import com.day.cq.search.Query;
import com.day.cq.search.result.SearchResult;

public class MockQuery {
	@Mock
	public Query query;
	
	public MockQuery(){
		query = Mockito.mock(Query.class);
		SearchResult searchResult = new MockSearchResult().searchResult;
		when(query.getResult()).thenReturn(searchResult);
	}
}
