package com.jh.jhins.mock;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import com.day.cq.search.QueryBuilder;
import com.day.cq.tagging.TagManager;

import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;

import javax.jcr.Session;

import static org.mockito.Matchers.anyString;

public class MockResourceResolver {

	@Mock
	public ResourceResolver resourceResolver;
	
	public MockResourceResolver(){
		resourceResolver = Mockito.mock(ResourceResolver.class);
		Resource resource = new MockResource().resource;
		QueryBuilder queryBuilder = new MockQueryBuilder().queryBuilder;
		TagManager tagManager = new MockTagManager().tagManager;
		
		when(resourceResolver.getResource(anyString())).thenReturn(resource);
		when(resourceResolver.adaptTo(Session.class)).thenReturn(new MockSession().session);		
		when(resourceResolver.adaptTo(QueryBuilder.class)).thenReturn(queryBuilder);
		when(resourceResolver.adaptTo(TagManager.class)).thenReturn(tagManager);
		when(resourceResolver.map(anyString())).thenReturn("https://johnhancock-dev.adobecqms.net/financial-professionals/life-insurance/news/john-hancock-journal");
	}
}
