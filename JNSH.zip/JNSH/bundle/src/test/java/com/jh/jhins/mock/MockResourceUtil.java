package com.jh.jhins.mock;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)

public class MockResourceUtil {	
	
    @PrepareForTest({ ResourceUtil.class })
    @Test
    public void getValueMap(Resource resource){
    	PowerMockito.mockStatic(ResourceUtil.class);
    	ValueMap valueMap = new MockValueMap().valueMap;
    	PowerMockito.when(ResourceUtil.getValueMap(resource)).thenReturn(valueMap);
    	System.out.println("resource util called");
    }



}
