package com.jh.jhins.mock;

import org.mockito.Mock;
import org.mockito.Mockito;

import com.day.cq.tagging.Tag;

public class MockTag {
	@Mock
	public Tag tag;
	
	public MockTag(){
		tag = Mockito.mock(Tag.class);

	}
}
