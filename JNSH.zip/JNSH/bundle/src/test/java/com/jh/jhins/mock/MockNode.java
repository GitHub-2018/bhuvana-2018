package com.jh.jhins.mock;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;

import org.mockito.Mock;
import org.mockito.Mockito;

import com.jh.jhins.constants.AssetConstants;

import static org.mockito.Mockito.when;


public class MockNode {

	@Mock
	public Node node;
	
	public MockNode(){
		node = Mockito.mock(Node.class);
		Node node1 = Mockito.mock(Node.class);
		
		try {
			Property prop = new MockProperty().property;
			when(node.hasNode("jcr:content")).thenReturn(true);
			when(node.getNode("jcr:content")).thenReturn(node1);
			when(node.hasProperty(AssetConstants.ASSET_LAST_MODIFIED)).thenReturn(true);
			when(node.getProperty(AssetConstants.ASSET_LAST_MODIFIED)).thenReturn(prop);
			when(node1.hasProperty(AssetConstants.ASSET_LAST_MODIFIED)).thenReturn(true);
			when(node1.getProperty(AssetConstants.ASSET_LAST_MODIFIED)).thenReturn(prop);	
		} catch (RepositoryException e) {
			e.printStackTrace();
		}
		
	}
}
