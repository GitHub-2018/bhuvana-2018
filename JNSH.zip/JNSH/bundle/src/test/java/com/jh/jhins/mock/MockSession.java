package com.jh.jhins.mock;

import javax.jcr.Session;

import org.mockito.Mock;
import org.mockito.Mockito;

public class MockSession {
	@Mock
	public Session session;
	
	public MockSession(){
		session = Mockito.mock(Session.class);

	}
}
