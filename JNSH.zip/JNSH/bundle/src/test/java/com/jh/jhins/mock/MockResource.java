package com.jh.jhins.mock;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Iterator;

import javax.jcr.Node;

import org.apache.sling.api.resource.Resource;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;

import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;

@RunWith(PowerMockRunner.class)
public class MockResource {

	@Mock
	public Resource resource;
	
	public MockResource(){
		resource = Mockito.mock(Resource.class);
		Resource childResource = Mockito.mock(Resource.class);
		Page page = new MockPage().page;
		Node node = new MockNode().node;
		Asset asset = new MockAsset().asset;
		

		Iterator<Resource> iter = new Iterator<Resource>() {
			private int currentIndex = 0;
			Resource resource1 = Mockito.mock(Resource.class);
			Resource resource2 = Mockito.mock(Resource.class);
			Resource resource3 = Mockito.mock(Resource.class);
			Resource[] resources = {resource1,resource2,resource3};
			
			public boolean hasNext() {

				 return currentIndex < resources.length && resources[currentIndex] != null;
			}

			public Resource next() {
				
				return resources[currentIndex++];
			}

			public void remove() {
				throw new UnsupportedOperationException();
				
			}
		};
		when(resource.adaptTo(Page.class)).thenReturn(page);
		when(resource.adaptTo(Node.class)).thenReturn(node);
		when(resource.adaptTo(Asset.class)).thenReturn(asset);
		when(resource.getChild(anyString())).thenReturn(childResource);
		when(childResource.listChildren()).thenReturn(iter);
	}
}
