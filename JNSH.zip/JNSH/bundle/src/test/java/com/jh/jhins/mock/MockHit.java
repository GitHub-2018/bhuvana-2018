package com.jh.jhins.mock;

import org.mockito.Mock;
import org.mockito.Mockito;

import com.day.cq.search.result.Hit;
import static org.mockito.Mockito.when;

import javax.jcr.RepositoryException;

public class MockHit {
	@Mock
	public Hit hit;
	
	public MockHit(){
		hit = Mockito.mock(Hit.class);
		try {
			when(hit.getPath()).thenReturn("/content/JHINS/en_US/logged-in/logged-in-home/life-insurance/news/john-hancock-journal","/content/JHINS/en/news/news2","/content/JHINS/en/news/news3");
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
