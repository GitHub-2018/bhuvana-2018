package com.jh.jhins;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.junit.Test;

import com.jh.jhins.helper.DateHelper;
import com.jh.jhins.mock.MockNode;

public class DateHelperTest {

	@Test
	public void testConvertDateToString() {
		Calendar cal= Calendar.getInstance();
		cal.set(Calendar.DATE, 15);
		cal.set(Calendar.MONTH, Calendar.OCTOBER);
		cal.set(Calendar.YEAR, 2015);
		Date date = cal.getTime();
		try {
			String str = DateHelper.convertDateToString(date, "MMMM dd, yyyy");
			String str1 = DateHelper.convertDateToString(date, "MMM dd, yyyy");
			String str2 = DateHelper.convertDateToString(date, "MMMM dd, yy");
			String str3 = DateHelper.convertDateToString(date, "MM/dd/yy");
			assertEquals("October 15, 2015",str);
			assertEquals("Oct 15, 2015",str1);
			assertEquals("October 15, 15",str2);
			assertEquals("10/15/15",str3);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testFormatDate(){
		
	}
	
	@Test
	public void testGetLastModified(){
		Node node = new MockNode().node;
		try {
			assertNotNull(node.getNode("jcr:content"));
		} catch (PathNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Date date = DateHelper.getLastModified(node);
		assertNotNull(date);
	}

}
