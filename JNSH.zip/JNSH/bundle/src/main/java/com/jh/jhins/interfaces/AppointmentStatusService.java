package com.jh.jhins.interfaces;

import com.jh.jhins.bean.AppointmentStatusArrayBean;
import com.jh.jhins.bean.AppointmentStatusBean;

public interface AppointmentStatusService {
	
	public abstract String getProducerData(AppointmentStatusBean statusBean);
	public abstract String getFirmSupporMultiSearchData(AppointmentStatusArrayBean statusArrayBean);
	
}
