package com.jh.jhins.security;

/**
 * The crypto exception indicates a problem with the encryption or
 * decryption process.
 */
public class CryptoException extends Exception
{
	private static final long serialVersionUID = -6047859046814496478L;

	/**
     * Construct
     * @param a_message
     */
    public CryptoException(String a_message)
    {
        super(a_message);
    }
    
    /**
     * Contruct
     * @param a_message
     * @param a_exception
     */
    public CryptoException(String a_message, Exception a_exception)
    {
        super(a_message, a_exception);
    }
}
