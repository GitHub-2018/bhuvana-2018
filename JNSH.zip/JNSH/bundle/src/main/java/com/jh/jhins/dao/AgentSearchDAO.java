package com.jh.jhins.dao;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth.ContentType;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.day.cq.replication.AgentNotFoundException;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhins.bean.AgentSearchBean;
import com.jh.jhins.bean.EmailBean;
import com.jh.jhins.bean.HeaderBean;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.impl.AgentSearchServiceImpl;
import com.sun.mail.iap.Response;

public class AgentSearchDAO {

	private static final Logger LOG = LoggerFactory.getLogger(AgentSearchDAO.class);
	public static final String JHINS_AGENTSEARCH_ERRORLIST_PATH = "/apps/settings/wcm/designs/lists/jhins-agent-search-error-configuration";
	public String getServiceUrl() {								

		return null;
	}
	public String agentCodeValidation(String vitalityUrl,AgentSearchBean agentSearchBean) {
		String agentStatus= null;
		String serviceUrl = vitalityUrl+agentSearchBean.getUserId()+"/"+agentSearchBean.getAgentCode();
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(serviceUrl);
		try {
			CloseableHttpResponse response = httpclient.execute(httpGet); 
			int statusCode = response.getStatusLine().getStatusCode();
			LOG.debug("agentCodeValidation service response :::::"+statusCode);
			if(statusCode == 200){
				agentStatus = EntityUtils.toString(response.getEntity(), GOOMConstants.CHARSET);
				LOG.debug(" success response String:::::"+ agentStatus);
			}else{
				agentStatus = Integer.toString(statusCode);
				LOG.debug(" failure response String:::::"+ agentStatus);
			}
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		}finally{
			if(null != httpclient){
				try {
					httpclient.close();
				} catch (IOException e) {
					LOG.error("IOException", e);
				}
			}
		}
		return agentStatus;
	}

	public String getAuthToken(String clientId,String secretCode,String oAuthPath) throws OAuthSystemException, OAuthProblemException {
		OAuthClient client = new OAuthClient(new URLConnectionClient());
		//CryptoBase64 decryptClientSecret = new CryptoBase64();
		String token="";
		OAuthClientRequest request = OAuthClientRequest
				.tokenLocation(oAuthPath)
				.setGrantType(GrantType.CLIENT_CREDENTIALS)
				.setClientId(clientId)
				.setClientSecret(secretCode)				
				.buildBodyMessage();
		request.addHeader("ContentType", ContentType.JSON);
		token = client.accessToken(request, OAuthJSONAccessTokenResponse.class).getAccessToken();
		return token;

	}

	public String getJWTToken(AgentSearchBean agentSearchBean,String jwtURL,String oAuthToken,String targetUrl,String ssoURL,String jwtAuthorizationValue, ResourceResolver resourceresolver) {
		String jwtValidationURL="";
		String responseData = null;
		String jwtResponseCode = "";
		CloseableHttpClient httpClient = HttpClients.createDefault();
		JSONObject jsonObj = new JSONObject();
		JSONObject jwtJSON = new JSONObject();

		try {
			jsonObj.put("userId",agentSearchBean.getUserId());		
			jsonObj.put("policynumber",agentSearchBean.getPolicynumber());			
			jsonObj.put("agentnumber",agentSearchBean.getAgentCode());
			jsonObj.put("plcnumber",agentSearchBean.getPlcnumber());
			jsonObj.put("userRole",agentSearchBean.getUserRole());
			jsonObj.put("hostsystem",agentSearchBean.getHostsystem());
			jsonObj.put("emailaddress",agentSearchBean.getEmailaddress());
			jsonObj.put("target",targetUrl);
			LOG.debug("input Json:::::::::::::::::" + jsonObj.toString());
			StringEntity input = new StringEntity(jsonObj.toString());

			HttpPost postRequest = new HttpPost(jwtURL);		
			postRequest.setEntity(input);
			postRequest.addHeader("Authorization", "Bearer " + oAuthToken);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);
			CloseableHttpResponse response = httpClient.execute(postRequest);
			jwtResponseCode= Integer.toString(response.getStatusLine().getStatusCode());
			LOG.debug("JWTToken Serice response::::"+jwtResponseCode);
			if(jwtResponseCode.equalsIgnoreCase("200")){
				responseData = EntityUtils.toString(response.getEntity(), GOOMConstants.CHARSET);
				LOG.debug("JWTToken Serice response data:::::"+responseData);
				jwtJSON= new JSONObject(responseData);
				if(jwtJSON.has("details")){
					jwtValidationURL = ssoURL.trim()+jwtJSON.getString("details").toString()+"&authorization="+jwtAuthorizationValue;
				}
				else{
					jwtValidationURL=getErrorMessage("JWTERR",resourceresolver);
				}
			}
			else
			{
				jwtValidationURL=getErrorMessage("JWTERR",resourceresolver);
			}
			LOG.debug("jwtValidationURL :::::"+jwtValidationURL);
		} catch (JSONException e) {			
			LOG.error("JSONException",e);
		} catch (ParseException e) {
			LOG.error("ParseException",e);			
		} catch (IOException e) {
			LOG.error("IOException",e);			
		}finally{
			if(null != httpClient){
				try {
					httpClient.close();
				} catch (IOException e) {
					LOG.error("IOException", e);
				}
			}
		}
		return jwtValidationURL;	
	}
	public void triggerErrorMail(String agentStatus,AgentSearchBean agentSearchBean,EmailBean emailBean) {
		if(agentStatus.equals("101") ||agentStatus.equals("300")){
			HeaderBean headerBean = new HeaderBean();
			JSONObject jsonObj = new JSONObject();
			String subject="An error code was detected";

			/**Setting from and to mail address to JSON**/
			try {
				JSONObject fromMails = new JSONObject();
				fromMails.put("name","admin");
				fromMails.put(JHINSConstants.EMAIL,emailBean.getFromEmailAdd());
				JSONObject toMails = new JSONObject();
				JSONArray toMailsArray = new JSONArray();
				toMails.put("name","admin");
				toMails.put(JHINSConstants.EMAIL,emailBean.getToEmailAdd());
				toMailsArray.put(toMails);
				LOG.info("toMails::::" + toMails);


				/** Setting Header Values **/
				headerBean.setKey(emailBean.getKey());
				headerBean.setValue(emailBean.getValue());
				headerBean.setUrl(emailBean.getEmailAPIUrl());



				/** Adding Email Params to JSON array**/
				JSONArray SubstitutionsArr = new JSONArray();
				JSONObject jsonAgentStatus = new JSONObject();
				jsonAgentStatus.put("Name","errorCode");
				jsonAgentStatus.put("Value",agentStatus);
				JSONObject jsonUserName = new JSONObject();
				jsonUserName.put("Name","userName");
				jsonUserName.put("Value",agentSearchBean.getUserName());
				JSONObject jsonUserRole = new JSONObject();
				jsonUserRole.put("Name","userRole");
				jsonUserRole.put("Value",agentSearchBean.getUserRole());
				SubstitutionsArr.put(jsonAgentStatus);
				SubstitutionsArr.put(jsonUserName);
				SubstitutionsArr.put(jsonUserRole);

				LOG.info("SubstitutionsArr::::" + SubstitutionsArr);			

				/**Adding Params to JSON Object**/

				jsonObj.put(emailBean.getAppId(), emailBean.getAppIdValue());
				jsonObj.put(JHINSConstants.TEMPLATEID,emailBean.getAgentSearchtempID());
				jsonObj.put(JHINSConstants.FROM, fromMails);
				jsonObj.put(JHINSConstants.TO, toMailsArray);
				jsonObj.put(JHINSConstants.SUBJECT, subject);
				jsonObj.put(JHINSConstants.SUBSTITUTIONS, SubstitutionsArr);
			} catch (JSONException e) {
				LOG.error("Error sending mail::::", e);
			}

			getJsonResponse(headerBean,jsonObj);

		}
	}
	public String getJsonResponse(HeaderBean headerBean, JSONObject jsonObj) {
		String responseData = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			StringEntity input = new StringEntity(jsonObj.toString());
			input.setContentType(JHINSConstants.APPLICATION_JSON);
			HttpPost postRequest = new HttpPost(headerBean.getUrl());
			postRequest.setEntity(input);
			postRequest.addHeader(headerBean.getKey(), headerBean.getValue());
			postRequest.addHeader(JHINSConstants.CONTENT_TYPE, JHINSConstants.APPLICATION_JSON);
			CloseableHttpResponse httpResponse = httpClient.execute(postRequest);
			LOG.debug("httpResponse code::::" + httpResponse);
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				int statusCode = httpResponse.getStatusLine().getStatusCode();
				LOG.debug("Email Sending failed with response Code::::" + statusCode);
			} else {
				LOG.debug("Email Sending Success::::" + httpResponse);
			}           
		}  catch (Exception ex) {
			LOG.error("Error sending mail::::", ex);
		}
		if(null != httpClient){
			try {
				httpClient.close();
			} catch (IOException e) {
				LOG.error("IOException", e);
			}
		}

		return responseData;
	}
	public static String getErrorMessage(String statusCode,ResourceResolver resourceresolver) {
		Page pagePath;
		JSONObject jObject=new JSONObject();
		PageManager pageManager = resourceresolver.adaptTo(PageManager.class);		
		pagePath = pageManager.getPage(JHINS_AGENTSEARCH_ERRORLIST_PATH);
		String message = null;
		GenericList list = pagePath.adaptTo(GenericList.class);
		message = list.lookupTitle(statusCode);
		return message;
	}
}
