package com.jh.jhins.model.sling;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * This is the base model for all Sling model objects.
 * @author yadanku
 *
 */
public class BaseModel  implements Serializable{

 	private static final long serialVersionUID = -7871451999843825065L;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    @Optional
    protected String displayAs;

    private StylingTab styling;
    
    @Self
    @Via("resource")
    protected Resource resource;

    @Inject
    protected SlingHttpServletRequest request;
    
    @PostConstruct
    public void activate() {
        styling = StylingTab.createSingleModel(resource.getChild("styling"), StylingTab.class);
    }
      
    /**
     * @return the displayAs
     */
    public String getDisplayAs() {
        return displayAs;
    }

    public StylingTab getStyling() {
        return styling;
    }
    
}