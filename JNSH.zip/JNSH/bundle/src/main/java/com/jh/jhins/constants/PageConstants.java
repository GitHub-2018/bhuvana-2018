package com.jh.jhins.constants;

public class PageConstants {

	public static final Object PARAM_LIMIT = "limit";
	public static final String PARAM_PATH = "path";
	public static final Object PARAM_TOPIC = "topic";

}
