package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.ServerException;
import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
@SlingServlet(resourceTypes = "/apps/JHINS/components/page/contentpage-white", selectors = "data", extensions = "json", methods = "GET", metatype =true)
public class ProductInfoServlet extends SlingSafeMethodsServlet{
	private static final Logger LOG = LoggerFactory.getLogger(ProductInfoServlet.class);

	@Reference
	private ResourceResolverFactory resolverFactory;
	
	 @Override
     protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
        
		 try
	      {
	    	  Resource resource = request.getResource();
	    	  Resource parent = resource.getParent();
	    	 // Page currentPage= pageManager.getContainingPage(parent.getPath());
	    	  String path=null;
	    	  String name= null;
	    	  Iterator<Resource> itr = parent.listChildren();
	    	  JSONArray productArray = new JSONArray(); 
	    	  while(itr.hasNext()){
	    		  Resource childResource = itr.next();
	    		//  LOG.info("childResource::::::::::::"+childResource.getName());
	    		  Resource pageResource =childResource.getResourceResolver().getResource(childResource.getPath()+"/jcr:content/par/productprofilecomp");
	    		  if(pageResource != null){
		    		  ValueMap resourceValMap =pageResource.getValueMap();
		    		  Node node = pageResource.adaptTo(Node.class);
		    		  createMissingProperty(node);
		    		  JSONObject productObj = new JSONObject(); 
		    		if(resourceValMap.containsKey("productCategory")){

		    			String productcategory = resourceValMap.get("productCategory").toString();
		    		  if(productcategory.contains(",")){  
		    			 // JSONObject splitObj = null;
		    			  String[] tokens= productcategory.split("\\,");
		    			  for(String category: tokens) { 
		    				  //splitObj = new JSONObject();
		    				  JSONObject splitObj = getNodeAsJSONObject(resourceValMap); 
				    		  splitObj.put("productCategory", category);
				    		  LOG.info("splitted ojbect"+splitObj);
				    		  productArray.put(splitObj);
		    			  }
			    		  
		    		}else{
		    			 JSONObject productObject = getNodeAsJSONObject(resourceValMap); 
			    		  productArray.put(productObject);
		    		}
		    		}
		    		  
	    		  }
	    	  }
	    	 response.getWriter().println(productArray.toString());
	    	  
      }catch (Exception e) {
    	  LOG.error(e.getMessage(),e);
	 } 
    }

	private JSONObject getNodeAsJSONObject(ValueMap resourceValMap) {
		JSONObject productObj = new JSONObject();
		try{
		 if(resourceValMap.containsKey("name")){
			  productObj.put("name", resourceValMap.get("name").toString());
		  }
		  
		  if(resourceValMap.containsKey("productCategory")){
			  productObj.put("productCategory", resourceValMap.get("productCategory").toString());
		  }
		  if(resourceValMap.containsKey("productCode")){
			  productObj.put("productCode", resourceValMap.get("productCode").toString());
		  }
		  
		  if(resourceValMap.containsKey("shortCode")){
			  productObj.put("shortCode", resourceValMap.get("shortCode").toString());
		  }
		  if(resourceValMap.containsKey("rider")){
			  productObj.put("rider", resourceValMap.get("rider").toString());
		  }
		  if(resourceValMap.containsKey("series")){
			  productObj.put("series", resourceValMap.get("series").toString());
		  }
		  
		  if(resourceValMap.containsKey("companyCode")){
			  productObj.put("companyCode", resourceValMap.get("companyCode").toString());
		  }
		  
		  if(resourceValMap.containsKey("version")){
			  productObj.put("version", resourceValMap.get("version").toString());
		  }
		  if(resourceValMap.containsKey("footNotes")){
			  productObj.put("footNotes", resourceValMap.get("footNotes").toString());
		  }
		}catch (JSONException e) {
			LOG.error("JSONException",e);
		}
		return productObj;
	}

	private void createMissingProperty(Node node) {

		try {
			if(!node.hasProperty("name")){
				node.setProperty("name", "");
			}
			if(!node.hasProperty("productCategory")){
				node.setProperty("productCategory", "");
			}
			if(!node.hasProperty("productCode")){
				node.setProperty("productCode", "");
			}
			if(!node.hasProperty("shortCode")){
				node.setProperty("shortCode", "");
			}
			if(!node.hasProperty("rider")){
				node.setProperty("rider", "");
			}
			if(!node.hasProperty("series")){
				node.setProperty("series", "");
			}
			if(!node.hasProperty("companyCode")){
				node.setProperty("companyCode", "");
			}
			if(!node.hasProperty("version")){
				node.setProperty("version", "");
			}
			if(!node.hasProperty("footNotes")){
				node.setProperty("footNotes", "");
			}
		} catch (ValueFormatException e) {
			LOG.error("ValueFormatException",e);
		} catch (VersionException e) {
			LOG.error("VersionException",e);
		} catch (LockException e) {
			LOG.error("LockException",e);
		} catch (ConstraintViolationException e) {
			LOG.error("ConstraintViolationException",e);
		} catch (RepositoryException e) {
			LOG.error("RepositoryException",e);
		}
	}
}
