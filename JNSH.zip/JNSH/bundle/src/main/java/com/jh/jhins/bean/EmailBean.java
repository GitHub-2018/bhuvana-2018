package com.jh.jhins.bean;

public class EmailBean {

	private String key;
	private String value;
	private String emailAPIUrl;
	private String appId;
	private String appIdValue;
	private String toEmailAdd;
	private String fromEmailAdd;
	private String agentSearchtempID;

	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getAppIdValue() {
		return appIdValue;
	}
	public void setAppIdValue(String appIdValue) {
		this.appIdValue = appIdValue;
	}
	public String getToEmailAdd() {
		return toEmailAdd;
	}
	public void setToEmailAdd(String toEmailAdd) {
		this.toEmailAdd = toEmailAdd;
	}
	public String getFromEmailAdd() {
		return fromEmailAdd;
	}
	public void setFromEmailAdd(String fromEmailAdd) {
		this.fromEmailAdd = fromEmailAdd;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getEmailAPIUrl() {
		return emailAPIUrl;
	}
	public void setEmailAPIUrl(String emailAPIUrl) {
		this.emailAPIUrl = emailAPIUrl;
	}

	public String getAgentSearchtempID() {
		return agentSearchtempID;
	}
	public void setAgentSearchtempID(String agentSearchtempID) {
		this.agentSearchtempID = agentSearchtempID;
	}
}
