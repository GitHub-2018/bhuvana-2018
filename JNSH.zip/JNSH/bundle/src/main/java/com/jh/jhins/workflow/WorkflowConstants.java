package com.jh.jhins.workflow;

public class WorkflowConstants{

	public static final String SERVICE_DESCRIPTION = "service.description";	
	public static final String SERVICE_VENDOR = "service.vendor";	
	public static final String PROCESS_LABEL = "process.label";	
	public static final String CHOOSER_LABEL = "chooser.label";	
	public static final String TYPE_JCR_PATH  = "JCR_PATH";	
	public static final String JCR_CONTENT = "jcr:content";	
	public static final String PROPERTY_SELECT = "select";
	public static final String EMAIL_CC_RECIPIENT = "ccrecipient";
	public static final String TEMPLATE_ID= "templateID";
	public static final String EMAIL_BODY="body";
	public static final String EMAIL_MESSAGE="message";
	public static final String EMAIL_RECIPIENT_NAME="recipientName";
	public static final String PROFILE_NAME="profile/givenname";
	public static final String PROFILE_EMAIL="profile/email";
	public static final String SENDTO="sendTo";
	public static final String EMAIL_TEMPLATE="emailTemplate";
	public static final String EMAIL_REJECTION="emailRejection";
	public static final String PROCESS_ARGS="PROCESS_ARGS";
	public static final String ADMIN="admin";
	public static final String HOST_ID="sling.host.id";
	public static final String EMAIL_PAGE_URL="page_url";
	public static final String HTTP="http";
	public static final String HTML="html";
	public static final String WORKFLOW_COMMENTS="comment";
	
			
			
	
}
