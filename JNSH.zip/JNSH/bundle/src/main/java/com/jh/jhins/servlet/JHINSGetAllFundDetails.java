package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.interfaces.JHINSGetAllFundDetailsService;
@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({
		@Property(name = "service.description", value = "JHINS Service to Get All Fund Details"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/getAllFundDetails" }),
		@Property(name = "service.vendor", value = "JHINS"),
		@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true) })


public class JHINSGetAllFundDetails extends SlingAllMethodsServlet {
	
	@Reference
	JHINSGetAllFundDetailsService jhinsGetAllFundDetailsService;

	Logger logger = LoggerFactory.getLogger(this.getClass());

	private static final long serialVersionUID = 1L;

	ResourceResolver resourceResolver;
	JSONObject json = null;

	@Override
	public void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		
		try {
		
			resourceResolver = request.getResourceResolver();			
			json = jhinsGetAllFundDetailsService.getAllFundDetails(resourceResolver);	
			
			logger.debug("json data:::::::::::::::::::::"+json.toString());
			PrintWriter out = response.getWriter();
			out.println(json);
			out.flush();
			out.close();
			
		} catch (Exception e) {
			response.getWriter().println(
					"Can't display the Fund Names. An error occured !");
			logger.error(e.getMessage());
		}
		response.getWriter().close();
	}

}
