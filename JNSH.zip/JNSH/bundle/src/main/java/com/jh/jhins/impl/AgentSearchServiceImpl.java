package com.jh.jhins.impl;
import java.io.IOException;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.day.cq.replication.AgentNotFoundException;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhins.bean.AgentSearchBean;
import com.jh.jhins.bean.EmailBean;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.dao.AgentSearchDAO;
import com.jh.jhins.interfaces.AgentSearchService;

@Service
@Component(immediate=true, metatype=true, label="Agent Service")
public class AgentSearchServiceImpl implements AgentSearchService {
	private static final Logger LOG = LoggerFactory.getLogger(AgentSearchServiceImpl.class);
	public static final String AGENT_CONFIG_PID= "com.jh.jhins.impl.AgentSearchServiceImpl";
	public static final String UNCHECKED="unchecked";
	public static final String EMAIL_CONFIG_NODE_PATH="com.jh.jhins.servlet.JHInsAPIEmailServlet" ;


	@Reference
	private ConfigurationAdmin configAdmin;

	@Reference
	private ResourceResolverFactory resolverFactory;


	AgentSearchDAO agentSearchDAO = new AgentSearchDAO();
	public String agentSearch(AgentSearchBean agentSearchBean) {

		AgentSearchDAO 	agentSearchDAO = new AgentSearchDAO();
		EmailBean mailBean = new EmailBean();
		String vitalityUrl = getProperty("vitality.search.url",AGENT_CONFIG_PID);
		String finalResponse = null;
		String clientId = getProperty(GOOMConstants.OAUTH_CLIENT_ID,AGENT_CONFIG_PID);
		String secretCode = getProperty(GOOMConstants.OAUTH_CLIENT_SECRET_ID,AGENT_CONFIG_PID);
		String oAuthPath = getProperty(GOOMConstants.OAUTH_TOKEN_PATH,AGENT_CONFIG_PID);
		String appId = getProperty(GOOMConstants.APP_ID,AGENT_CONFIG_PID);
		String targetUrl = getProperty(GOOMConstants.JWT_TARGET_URL,AGENT_CONFIG_PID);
		String jwtServiceUrl = getProperty(GOOMConstants.JWT_SERVICE_URL,AGENT_CONFIG_PID);
		String jwtURL = jwtServiceUrl+appId;
		String ssoURL =getProperty(GOOMConstants.DSTO_SSO_CONN_URL,AGENT_CONFIG_PID);
		String jwtAuthorizationValue = getProperty(GOOMConstants.JWT_AUTHORIZATION_VALUE,AGENT_CONFIG_PID);

		/** Fill bean with error mail retalted values **/
		mailBean.setKey(getProperty("jhins.header.key",EMAIL_CONFIG_NODE_PATH));
		mailBean.setValue(getProperty("jhins.header.value", EMAIL_CONFIG_NODE_PATH));
		mailBean.setEmailAPIUrl(getProperty("jhins.email.api.url",EMAIL_CONFIG_NODE_PATH));
		mailBean.setAppId(getProperty("jhins.header.appid", EMAIL_CONFIG_NODE_PATH));
		mailBean.setAppIdValue(getProperty("jhins.header.appid.value", EMAIL_CONFIG_NODE_PATH));
		mailBean.setToEmailAdd(getProperty("error.toemail.address",AGENT_CONFIG_PID));
		mailBean.setFromEmailAdd(getProperty("error.fromemail.address", AGENT_CONFIG_PID));
		mailBean.setAgentSearchtempID(getProperty("error.mail.templateId", AGENT_CONFIG_PID));


		String userRole = agentSearchBean.getUserRole();
		LOG.debug("UserRole is = "+userRole);
		/**logic when userRole is Producer or ProducerSupport and FirmSupport **/
		if(userRole.equalsIgnoreCase(GOOMConstants.PRODUCER_ROLE) ||userRole.equalsIgnoreCase(GOOMConstants.PRODUCER_SUPPORT_ROLE) || userRole.equalsIgnoreCase(GOOMConstants.FIRM_SUPPORT_ROLE)){
			String agentStatus = agentSearchDAO.agentCodeValidation(vitalityUrl,agentSearchBean);
			if(agentStatus.equalsIgnoreCase(GOOMConstants.SUCCESS)){
				try {
					String oAuthToken = agentSearchDAO.getAuthToken(clientId,secretCode,oAuthPath);
					LOG.debug("oAuth token generated is "+oAuthToken);
					finalResponse = agentSearchDAO.getJWTToken(agentSearchBean,jwtURL,oAuthToken,targetUrl,ssoURL,jwtAuthorizationValue,getServiceResolver());					
				} catch (OAuthSystemException e) {

					LOG.error("OAuthSystemException",e);
				} catch (OAuthProblemException e) {

					LOG.error("OAuthProblemException",e);
				}
			}else{
				LOG.debug("agent Status is "+agentStatus);
				agentSearchDAO.triggerErrorMail(agentStatus,agentSearchBean,mailBean);
				finalResponse=AgentSearchDAO.getErrorMessage(agentStatus,getServiceResolver());				
			}
		}
		/** logic when userRole is SuperUser **/
		if(userRole.equalsIgnoreCase(GOOMConstants.SUPERUSER_ROLE)){
			try {
				String oAuthToken = agentSearchDAO.getAuthToken(clientId,secretCode,oAuthPath);
				LOG.debug("oAuth token generated is "+oAuthToken);
				finalResponse = agentSearchDAO.getJWTToken(agentSearchBean,jwtURL,oAuthToken,targetUrl,ssoURL,jwtAuthorizationValue,getServiceResolver());					
			} catch (OAuthSystemException e) {

				LOG.error("OAuthSystemException",e);
			} catch (OAuthProblemException e) {

				LOG.error("OAuthProblemException",e);
			}
		}
		LOG.debug("Agent search final response:::"+finalResponse);
		return finalResponse;
	}

	/** pam propertyname and config nodename,return propertyvalue **/
	public String getProperty(final String property,String configNodePath) {
		String propertyValue ="" ;
		try {
			Configuration conf = configAdmin.getConfiguration(configNodePath);
			@SuppressWarnings(UNCHECKED)
			Dictionary<String, Object> properties = conf.getProperties();
			if (properties != null && !properties.isEmpty()) {
				if (properties.get(property) != null) {
					propertyValue = properties.get(property).toString();
				}
			}
		} catch (IOException e) {
			LOG.error("IOException",e);
		}
		return propertyValue;

	}

	private ResourceResolver getServiceResolver(){
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(ResourceResolverFactory.SUBSERVICE,GOOMConstants.JHINS_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			//resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
		} catch (LoginException e) {
			LOG.error("LoginException:", e);
		}
		return resourceResolver;
	}

}
