package com.jh.jhins.helper;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jh.jhins.bean.AssetMetaDataBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.AssetConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;

public class AssetHelper {	
	private static final Logger LOG = LoggerFactory.getLogger(AssetHelper.class);
	private static Session session = null;

	/**
	 * Method will return List of AssertMetaDataBean according to
	 * PRODCUT,TOPIC,TYPE
	 * 
	 * @param product
	 * @param topic
	 * @param type
	 * @param slingRequest
	 * @return
	 * @throws RepositoryException
	 */
	public static ArrayList<AssetMetaDataBean> relatedItemsQueryResult(String product, String topic, String type,
			SlingHttpServletRequest slingRequest, UserTO userTo) throws RepositoryException {
		String[] paths = null;
		try {
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("path", JHINSConstants.DAM_PATH);
			map.put("1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_property.value", product);

			map.put("2_property", JHINSConstants.TOPIC_PROP_NAME);
			map.put("2_property.value", topic);
			map.put("3_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("3_property.value", type);
			map.put("p.limit", "3");
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			//end of changes for user role
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
				}
			}
			return retrieveAssetBean(paths, slingRequest.getResourceResolver());
		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		return null;
		

	}

	/**
	 * Method will return List of AssertMetaDataBean according to PRODCUT
	 * 
	 * @param product
	 * @param slingRequest
	 * @return
	 * @throws RepositoryException
	 */
	public static ArrayList<AssetMetaDataBean> consumerMaterialResults(String product1,
			SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {

		String[] paths = null;
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag product1Tag = tagManager.resolve(product1);
		Tag prospectusTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS);
		Tag prospectusSupplementTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS_SUPPLEMENT);
		Tag priorityTag = tagManager.resolve(JHINSConstants.JH_PRIORITY);
		try {
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_group.1_property.value", product1Tag.getTagID());
			map.put("1_group.2_property", JHINSConstants.PARAM_CLIENT_APPROVED);
			map.put("1_group.2_property.value", "yes");
			LOG.debug("************ consumer approval value is");
			map.put("2_group.p.not", "true");
			map.put("2_group.p.or", "true");
			map.put("2_group.1_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.1_property.value", prospectusTag.getTagID());
			map.put("2_group.2_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.2_property.value", prospectusSupplementTag.getTagID());
			//map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
			//map.put("orderby.sort", "desc");
			map.put("p.limit", "-1");
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			//end of changes for user role
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			LOG.debug("************ searchResults***" + searchRes.getTotalMatches());
			LOG.info("************ searchResults***" + searchRes.getTotalMatches());
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
					LOG.info("hit.getPath():::::::"+hit.getPath());
				}
			}
			
			ArrayList<AssetMetaDataBean> beanList = retrieveAssetBean(paths, slingRequest.getResourceResolver());
			return sortAssetList(beanList);
		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		return null;
		

	}

	/**
	 * Method will return List of AssertMetaDataBean according to PRODCUT
	 * 
	 * @param product
	 * @param slingRequest
	 * @return
	 * @throws RepositoryException
	 */
public static ArrayList<AssetMetaDataBean> getProducerMaterialAssets(String product1,
			SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {

		String[] paths = null;
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(product1);
		Tag tagArticle = tagmanager.resolve(JHINSConstants.JH_TYPE_ARTICLE);
		Tag tagBrochure = tagmanager.resolve(JHINSConstants.JH_TYPE_BROUCHURE);
		Tag tagFlyer = tagmanager.resolve(JHINSConstants.JH_TYPE_FLYER);
		try {
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_group.1_property.value", tag.getTagID());
			LOG.info("1_group.1_property.value::::::::::"+tag.getTagID());
			map.put("1_group.2_property", JHINSConstants.PARAM_CLIENT_APPROVED);
			map.put("1_group.2_property.value", "no");
			
			LOG.debug("************ consumer approval value is");
			
			map.put("2_group.p.not", "true");
			map.put("2_group.p.or", "true");
			map.put("2_group.1_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.1_property.value", tagArticle.getTagID());
			map.put("2_group.2_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.2_property.value", tagBrochure.getTagID());
			map.put("2_group.3_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.3_property.value", tagFlyer.getTagID());
			//ap.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
			//map.put("orderby.sort", "desc");
			map.put("p.limit", "-1");
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			//end of changes for user role
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			LOG.debug("************ searchResults***" + searchRes.getTotalMatches());
			LOG.info("************ producer searchResults***" + searchRes.getTotalMatches());
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
				}
			}
			
			ArrayList<AssetMetaDataBean> beanList = retrieveAssetBean(paths, slingRequest.getResourceResolver());
			return sortAssetList(beanList);
		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		return null;
		

	}

	/**
	 * Method will return List of AssertMetaDataBean according to PRODCUT
	 * 
	 * @param product
	 * @param slingRequest
	 * @return
	 * @throws RepositoryException
	 */
	public static ArrayList<AssetMetaDataBean> getSalesFlyerslAssets(String product1,
			SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {
		LOG.debug("Starting of getSalesFlyerslAssets method");
		String[] paths = null;
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(product1);
		Tag flyerTag = tagmanager.resolve(JHINSConstants.JH_TYPE_FLYER);
		LOG.debug("Product1 = "+tag+" Flyer = "+flyerTag);
		try {
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_group.1_property.value", tag.getTagID());
			map.put("1_group.2_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("1_group.2_property.value", flyerTag.getTagID());
			//map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
			//map.put("orderby.sort", "desc");
			map.put("p.limit", "-1");
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			//end of changes for user role
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			LOG.debug("************ searchResults***" + searchRes.getTotalMatches());
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
				}
			}
			ArrayList<AssetMetaDataBean> beanList = retrieveAssetBean(paths, slingRequest.getResourceResolver()); 
			return sortAssetList(beanList);
		
		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		LOG.debug("End of getSalesFlyerslAssets method");
		return null;
		

	}

	/**
	 * Method will return List of AssertMetaDataBean according to PRODCUT
	 * 
	 * @param product
	 * @param slingRequest
	 * @return
	 * @throws RepositoryException
	 */

	public static ArrayList<AssetMetaDataBean> getInvestmentInfoAssets(String product1, String product2,
			SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {
		String[] paths = null;
		//String[] priority2Paths = null;
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		String[] priority1Paths = getInvestmentInfoPriority1(queryBuilder, product1, product2, slingRequest,userTo);
		LOG.debug("INVESTMENT INFO--> PRIORITY 1 paths--> " + priority1Paths.toString());
		/*int count = priority1Paths.length;
		if (count < 8) {
			LOG.debug("INVESTMENT INFO--> PRIORITY 2--> ");
			priority2Paths = getInvestmentInfoPriority2(queryBuilder, product2, (8 - count),slingRequest,userTo);
			LOG.debug("INVESTMENT INFO--> PRIORITY 2 paths--> " + priority2Paths);
		}*/
		//paths = (String[]) ArrayUtils.addAll(priority1Paths, priority2Paths);
		
		ArrayList<AssetMetaDataBean> beanList = retrieveAssetBean(priority1Paths, slingRequest.getResourceResolver());
		return sortAssetList(beanList);
	}

	private static String[] getInvestmentInfoPriority1(QueryBuilder queryBuilder, String product1, String product2, SlingHttpServletRequest slingRequest,UserTO userTo) {
		String[] paths = null;
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag produc1Tag = tagManager.resolve(product1);
		Tag produc2Tag = tagManager.resolve(product2);
		Tag prosepctusTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS);
		Tag prosepctusSupplementTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS_SUPPLEMENT);
		queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", "dam:Asset");
		map.put("1_group.p.or", "true");
		map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
		map.put("1_group.1_property.value", produc1Tag.getTagID());
		map.put("1_group.2_property", JHINSConstants.PRODUCT_PROP_NAME);
		map.put("1_group.2_property.value", produc2Tag.getTagID());
		map.put("2_group.p.or", "true");
		map.put("2_group.1_property", JHINSConstants.TYPE_PROP_NAME);
		map.put("2_group.1_property.value", prosepctusTag.getTagID());
		map.put("2_group.2_property", JHINSConstants.TYPE_PROP_NAME);
		map.put("2_group.2_property.value", prosepctusSupplementTag.getTagID());
		//map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
		//map.put("orderby.sort", "desc");
		map.put("p.limit", "-1");
		LOG.debug("INVESTMENT INFO--> PRIORITY 1 MAP BEFORE--> " + map);
		//start of changes for user role
		getFilterForUserRole(map, userTo);
		//end of changes for user role
		LOG.debug("INVESTMENT INFO--> PRIORITY 1 MAP AFTER--> " + map);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		LOG.debug("INVESTMENT INFO--> PRIORITY 1 --> searchResults***" + searchRes.getTotalMatches());
		paths = new String[searchRes.getHits().size()];
		int i = 0;
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				try {
					paths[i++] = hit.getPath();
					
				
				} catch (RepositoryException e1) {
					
					LOG.error("Repository Exception in getInvestmentInfoPriority1 ", e1.getMessage());
				}
			}
		}
		return paths;
		
	}

	private static String[] getInvestmentInfoPriority2(QueryBuilder queryBuilder, String product2, int limit,
			SlingHttpServletRequest slingRequest, UserTO userTo) {
		
		String[] paths = null;
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag produc2Tag = tagManager.resolve(product2);
		Tag prosepctusTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS);
		Tag prosepctusSupplementTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS_SUPPLEMENT);
		queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", "dam:Asset");
		map.put("1_group.p.or", "true");
		map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
		map.put("1_group.1_property.value", produc2Tag.getTagID());
		map.put("2_group.p.or", "true");
		map.put("2_group.p.not", "true");
		map.put("2_group.1_property", JHINSConstants.TYPE_PROP_NAME);
		map.put("2_group.1_property.value", prosepctusTag.getTagID());
		map.put("2_group.2_property", JHINSConstants.TYPE_PROP_NAME);
		map.put("2_group.2_property.value", prosepctusSupplementTag.getTagID());
		//map.put("orderby", AssetConstants.ORDER_BY);
		//map.put("orderby.sort", "desc");
		map.put("p.limit", "-1");
		LOG.debug("INVESTMENT INFO--> PRIORITY 2 MAP BEFORE--> " + map);
		// start of changes for user role
		getFilterForUserRole(map, userTo);
		// end of changes for user role
		LOG.debug("INVESTMENT INFO--> PRIORITY 2 MAP BEFORE--> " + map);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		LOG.debug("INVESTMENT INFO--> PRIORITY 2--> SEARCH RESULTS --> " + searchRes.getTotalMatches());
		LOG.debug("************ searchResults***" + searchRes.getTotalMatches());
		paths = new String[searchRes.getHits().size()];
		int i = 0;
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				try {
					paths[i++] = hit.getPath();
				} catch (RepositoryException e1) {

					LOG.error("Repository Exception in getInvestmentInfoPriority1 ", e1.getMessage());
				}
			}
		}
		return paths;
	}

	/**
	 * Method will take assetpath <String> array as argument and will return
	 * AssetMetaDataBean List
	 * 
	 * @param paths
	 * @param resourceResolver
	 * @return
	 */
	public static ArrayList<AssetMetaDataBean> retrieveAssetBean(String[] paths, ResourceResolver resourceResolver)
			throws RepositoryException {
		LOG.debug("Starting of retrieveAssetBean method");
		ArrayList<AssetMetaDataBean> assetMetaDataBeans = new ArrayList<AssetMetaDataBean>();
		try {
			for (String path : paths) {
				if(path!=null && !"".equals(path)){
					assetMetaDataBeans.add(retrieveAssetBean(path, resourceResolver));
				}
			}

		} catch (Exception e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		LOG.debug("End of retrieveAssetBean method");
		LOG.info("assetMetaDataBeans length::::"+assetMetaDataBeans.size());
		return assetMetaDataBeans;
	}

	/**
	 * Method will take assetpath as argument and will return AssetMetaDataBean
	 * 
	 * @param path
	 * @param resourceResolver
	 * @return
	 * @throws RepositoryException
	 */
	public static AssetMetaDataBean retrieveAssetBean(String path, ResourceResolver resourceResolver) {
		LOG.debug("Starting of retrieveAssetBean method");
		AssetMetaDataBean assetBean = null;
		ArrayList<String> states= new ArrayList<String>();
		Resource resource = resourceResolver.getResource(path);
		LOG.debug("retrieveAssetBean--> RESOURCE PATH --> " + path);
		TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
			try {
				Node assetNode = resource.adaptTo(Node.class);
				//Date date = DateHelper.getLastModified(assetNode);
				Date date = DateHelper.getPublishedDate(assetNode);
				LOG.debug("retrieveAssetBean--> PUBLISHED DATE --> " + date);
				Boolean isNew = DateHelper.checkIsNew(date);
				Asset asset = resource.adaptTo(Asset.class);
			
				if (asset != null) {
					assetBean = new AssetMetaDataBean();
					Map<String, Object> assetMetaDataMap = asset.getMetadata();
					assetBean.setPath(path);
					assetBean.setDate(getLastModified(assetNode));
					//assetBean.setDate(DateHelper.getLastModified(assetNode).toString());
					LOG.debug("Asset node property"+assetNode.hasProperty("jcr:created")+"path= "+assetNode.getPath()+ "Expecting date here-- "+date+" Date for fund rates and info date in method"+DateHelper.getLastModified(assetNode));
					assetBean.setTitle(assetMetaDataMap.containsKey(JHINSConstants.ASSET_TITLE)
							? asset.getMetadataValue(JHINSConstants.ASSET_TITLE) : JHINSConstants.EMPTY_STRING);
					assetBean.setNew(isNew);
					
					String tags = asset.getMetadataValue(JHINSConstants.CQ_TAGS);
					assetBean.setPriority(JHINSConstants.PRIORITY_LOW);
					if(tags != null){
					String[] tagArray = tags.split(",");
					for (String string : tagArray) {
						LOG.info("Tag value String is "+string);
						Tag tag = tagManager.resolve(string.trim());
						if(tag==null)
						{
							continue;
						}
						String tagID = tag.getLocalTagID();
						LOG.info("tagID value is "+tagID);
						if (tagID.startsWith(JHINSConstants.PARAM_TYPE)) {
							assetBean.setType(tag.getTitle());
	} 
						
						
						else if (tagID.startsWith(JHINSConstants.PARAM_FORMAT)) {
							assetBean.setFormat(tag.getTitle());
							String format = tag.getTitle();
							
							assetBean = setColorCode(format, assetBean);
							assetBean = setIcon(format, assetBean);
							if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_PDF) || format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_IMAGE)) {
								//assetBean.setImagePath(asset.getRendition(JHINSConstants.IMAGE_RENDITION_30_42) != null
								//	? asset.getRendition(JHINSConstants.IMAGE_RENDITION_30_42).getPath()
									//: asset.getRendition(JHINSConstants.IMAGE_RENDITION_48_48).getPath());
							
							assetBean.setImagePath(asset.getRendition(JHINSConstants.IMAGE_RENDITION_30_42) != null
									? asset.getPath() + ".thumb.32.40.png" : asset.getPath() + ".thumb.48.48.png");
								assetBean.setGlypIcon(JHINSConstants.EMPTY_STRING);
							} else {
								assetBean.setImagePath(JHINSConstants.EMPTY_STRING);
							}

						} else if (tagID.startsWith(JHINSConstants.PARAM_TOPIC)) {
							assetBean.setTopic(tag.getTitle());
						} else if (tagID.startsWith(JHINSConstants.PARAM_STATE)) {
							assetBean.setState(tag.getTitle());
							states.add(tag.getTitle());
							
						} else if (tagID.startsWith(JHINSConstants.PARAM_CHANNEL)) {
							assetBean.setChannel(tag.getTitle());
						} else if (tagID.startsWith(JHINSConstants.PARAM_PRIORITY)){
							assetBean.setPriority(tag.getTitle());
							LOG.info("Priority:: " +tag.getTitle());
						}
					}
                        
					assetBean.setStates(states);
					assetBean.setStatesList(StringUtils.join(states,','));
					String result= assetBean.getStatesList().replaceAll(",", ", ");
					assetBean.setStatesList(result);
					assetBean.setClientApproved(asset.getMetadata().containsKey(JHINSConstants.TAGID_CLIENT_APPROVED)
							? asset.getMetadataValue(JHINSConstants.TAGID_CLIENT_APPROVED)
							: JHINSConstants.EMPTY_STRING);
					assetBean.setPath(asset.getMetadata().containsKey(JHINSConstants.TOOL_URL)
							? asset.getMetadataValue(JHINSConstants.TOOL_URL)
							: path);
				}
					if(!tags.contains(JHINSConstants.PARAM_FORMAT)){
						String format = "";
						String formatType = asset.getMetadataValue(JHINSConstants.ASSET_FORMAT);
						if(formatType.equalsIgnoreCase(JHINSConstants.PDF_FORMAT)){
							format = JHINSConstants.TAG_FORMAT_PDF;
							assetBean.setFormat(format);
						}else if(formatType.equalsIgnoreCase(JHINSConstants.PPT_FORMAT)|| formatType.equalsIgnoreCase(JHINSConstants.PPT1_FORMAT)){	
							format = JHINSConstants.TAG_FORMAT_PPT;
							assetBean.setFormat(format);
						}else if(formatType.equalsIgnoreCase(JHINSConstants.DOC_FORMAT)||formatType.equalsIgnoreCase(JHINSConstants.DOC1_FORMAT) ){
							format = JHINSConstants.TAG_FORMAT_DOC;
							assetBean.setFormat(format);
						}else if(formatType.equalsIgnoreCase(JHINSConstants.EXCEL_FORMAT) || formatType.equalsIgnoreCase(JHINSConstants.EXCEL1_FORMAT)){
							format	 = JHINSConstants.TAG_FORMAT_EXCEL;
							assetBean.setFormat(format);	
						}else if(formatType.equalsIgnoreCase(JHINSConstants.AUDIO_FORMAT)){
							format	 = JHINSConstants.TAG_FORMAT_AUDIO;
							assetBean.setFormat(format);	
						}else if(formatType.equalsIgnoreCase(JHINSConstants.VIDEO_FORMAT)){
							format	 = JHINSConstants.TAG_FORMAT_VIDEO;
							assetBean.setFormat(format);	
						}else if(formatType.equalsIgnoreCase(JHINSConstants.TOOL_FORMAT)||formatType.equalsIgnoreCase(JHINSConstants.TOOL1_FORMAT)){
							format	 = JHINSConstants.TAG_FORMAT_TOOL;
							assetBean.setFormat(format);
						}else if(formatType.equalsIgnoreCase(JHINSConstants.IMAGE_FORMAT)){
							format	 = JHINSConstants.TAG_FORMAT_IMAGE;
							assetBean.setFormat(format);
						}
						assetBean = setColorCode(format, assetBean);
						assetBean = setIcon(format, assetBean);
						if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_PDF) || format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_IMAGE)) {
						assetBean.setImagePath(asset.getRendition(JHINSConstants.IMAGE_RENDITION_30_42) != null
								? asset.getPath() + ".thumb.32.40.png" : asset.getPath() + ".thumb.48.48.png");
							assetBean.setGlypIcon(JHINSConstants.EMPTY_STRING);
						} else {
							assetBean.setImagePath(JHINSConstants.EMPTY_STRING);
						}
					}  		
			} 
			}catch (Exception e) {
			LOG.error("RepositoryException occured" ,e);
		}
			LOG.debug("End of retrieveAssetBean method");
		return assetBean;
	}

	private static AssetMetaDataBean setColorCode(String format, AssetMetaDataBean assetBean) {
		/* Assigning the color code depending on format */
		if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_PPT)
				|| format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_PDF)
				|| format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_DOC)) {
			assetBean.setColorCode(JHINSConstants.TAG_COLOR_RED);
		} else if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_AUDIO)
				|| format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_VIDEO)) {
			assetBean.setColorCode(JHINSConstants.TAG_COLOR_BLUE);
		}
		else {
			assetBean.setColorCode(JHINSConstants.TAG_COLOR_GREEN);
		}
		return assetBean;
	}

	private static AssetMetaDataBean setIcon(String format, AssetMetaDataBean assetBean) {
		
		if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_DOC)){
			assetBean.setGlypIcon("glyphicon glyphicon-file");
		} else if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_PPT)) {
			assetBean.setGlypIcon("glyphicon glyphicon-blackboard");
		}else if(format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_AUDIO)){
			assetBean.setGlypIcon("glyphicon glyphicon-music");
		}else if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_VIDEO)) {
			assetBean.setGlypIcon("glyphicon glyphicon-video");
		}else if (format.equalsIgnoreCase(JHINSConstants.TAG_FORMAT_TOOL)) {
			assetBean.setGlypIcon("glyphicon glyphicon-wrench");
		}
		
		return assetBean;
	}
	
	
	/**
	 * Method to extract the last modified date
	 *
	 * @param Jcrnode 
	 * 
	 * @return Date(String Format)
	 * @throws RepositoryException
	 * @throws ParseException
	 * @throws ParseException
	 */
	
	private static String getLastModified(Node assetNode)
			throws ValueFormatException, PathNotFoundException, RepositoryException, ParseException {
		LOG.debug("Starting of getLastModified method");
		Date date = null;
		String dateString = null;
		String dt = "";
		LOG.debug("date is " + assetNode);
		if (assetNode.hasNode("jcr:content")) {
			Node jcrNode = assetNode.getNode("jcr:content");
			if (jcrNode != null && jcrNode.hasProperty(AssetConstants.ASSET_LAST_MODIFIED)) {
				dateString = jcrNode.getProperty(AssetConstants.ASSET_LAST_MODIFIED).getString();
				LOG.debug("date last Modified " + dateString);
				DateFormat format = new SimpleDateFormat(JHINSConstants.DATE_FORMAT_YYYY_MM_DD);
				date = format.parse(dateString);
				DateFormat fmt = new SimpleDateFormat(AssetConstants.CUSTOM_DATE_FORMAT);
				dt = fmt.format(date);
				LOG.debug("date is " + dt);
			}
		}
		LOG.debug("End of getLastModified method");
		return dt;
	}
	

	/**
	 * Method to get the assets based on topic. It will retrieve child topic resources
	 * 
	 * @param slingRequest
	 * @param topic
	 * @param limit
	 * @return arrayList
	 * @throws RepositoryException
	 */
	public static ArrayList<AssetMetaDataBean> relatedResourcesByTopic(SlingHttpServletRequest slingRequest,
			String topic, String limit,UserTO userTo) throws RepositoryException {
		// String[] paths = null;
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		AssetMetaDataBean assetbean = null;

		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", JHINSConstants.DAM_ASSET);
		map.put("tagid", topic);
		map.put("tagid.property", JHINSConstants.CQ_TAGS_METADATA_PROPERTYNAME);//check whether this has ot be modified
		map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
		map.put("orderby.sort", "desc");
		map.put("p.limit", limit);
		//start of changes for user role
		getFilterForUserRole(map, userTo);
		//end of changes for user role
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		// paths = new String[searchRes.getHits().size()];
		// int i = 0;
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				assetbean = new AssetMetaDataBean();
				assetbean = retrieveAssetBean(queryPath, slingRequest.getResourceResolver());
				assetbeans.add(assetbean);
				LOG.debug("Final reach size is *********************************** "+assetbeans.size());
			}
		}

		return assetbeans;
	}
	
	/**
	 * Method to get the assets based on topic. It won't retrieve child topic
	 * resources
	 * 
	 * @param slingRequest
	 * @param topic
	 * @param limit
	 * @return arrayList
	 * @throws RepositoryException
	 */

	public static ArrayList<AssetMetaDataBean> relatedItemsResources(SlingHttpServletRequest slingRequest, String topic,
			String limit, UserTO userTo) throws RepositoryException {
		LOG.debug("Starting of relatedItemsResources method");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		AssetMetaDataBean assetbean = null;
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(topic);
		LOG.debug("Topic = "+tag);
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", JHINSConstants.DAM_ASSET);
		map.put("1_property", JHINSConstants.TYPE_PROP_NAME);
		map.put("1_property.value", tag.getTagID());
		map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
		map.put("orderby.sort", AssetConstants.ODERBY_SORT);
		map.put("p.limit", limit);
		// start of changes for user role
		getFilterForUserRole(map, userTo);
		// end of changes for user role
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				assetbean = new AssetMetaDataBean();
				assetbean = retrieveAssetBean(queryPath, slingRequest.getResourceResolver());
				assetbeans.add(assetbean);
			}
		}
		LOG.debug("End of relatedItemsResources method");
		return assetbeans;
	}

	

	/**
	 * Method to transfer details from list to jsonobj
	 *
	 * @param list
	 * 
	 *
	 * @return JsonObject
	 * @throws JSONException
	 */

	public static JSONObject transferAssetDetailstoJSONobj(ArrayList<AssetMetaDataBean> assetBeans)
			throws JSONException {
		LOG.debug("Starting of transferAssetDetailstoJSONobj method");
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		boolean hasConsumerMaterial = false;
		boolean hasProducerMaterial = false;
		ListIterator<AssetMetaDataBean> litr = assetBeans.listIterator();
		while (litr.hasNext()) {
			AssetMetaDataBean bean = (AssetMetaDataBean) litr.next();
			if (bean != null) {
				json = new JSONObject();
				json.put(JHINSConstants.PARAM_PATH, bean.getPath());
				json.put(JHINSConstants.PARAM_DATE, bean.getDate());
				
				json.put(JHINSConstants.PARAM_FORMAT, bean.getFormat());
				json.put(JHINSConstants.PARAM_TITLE, bean.getTitle());
				json.put(JHINSConstants.PARAM_TYPE, bean.getType());
				json.put(JHINSConstants.PARAM_CHANNEL,bean.getChannel());
				json.put(JHINSConstants.PARAM_COLOR_CODE,bean.getColorCode());
				json.put(JHINSConstants.PARAM_IMAGE_PATH,bean.getImagePath());
				json.put(JHINSConstants.PARAM_TOPIC, bean.getTopic());
				json.put(JHINSConstants.PARAM_IS_NEW, bean.getIsNew());
				json.put(JHINSConstants.PARAM_GLYP_ICON, bean.getGlypIcon());
				if(bean.getType()!=null)
				{
					if(bean.getType().equalsIgnoreCase("Consumer Guide") ||
							bean.getType().equalsIgnoreCase(JHINSConstants.SAMPLE_CONTRACT))
					{
						hasConsumerMaterial=true;
						
					}
					else if (bean.getType().equalsIgnoreCase(JHINSConstants.PRODUCER_GUIDE) ||
							bean.getType().equalsIgnoreCase(JHINSConstants.SELLERS_GUIDE))
					{
						hasProducerMaterial=true;
					}
					
				}
				mainObj.put(JHINSConstants.PRODUCER_MATERAILS,hasProducerMaterial);
				mainObj.put(JHINSConstants.CONSUMER_MATERIALS,hasConsumerMaterial);		
				
			}
			jsonArray.put(json);
		}
		mainObj.put("list", jsonArray);
		LOG.debug("Final JSON generated is" + mainObj);
		LOG.debug("End of transferAssetDetailstoJSONobj method");
		return mainObj;
	}
	public static JSONObject transferAssetDetailstoJSONobj(ArrayList<AssetMetaDataBean> assetBeans,Map<String, Object> mapObj)
			throws JSONException {
		LOG.debug("Starting of transferAssetDetailstoJSONobj method");
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		boolean hasConsumerMaterial = false;
		boolean hasProducerMaterial = false;
		ListIterator<AssetMetaDataBean> litr = assetBeans.listIterator();
		while (litr.hasNext()) {
			AssetMetaDataBean bean = (AssetMetaDataBean) litr.next();
			if (bean != null) {
				json = new JSONObject();
				json.put(JHINSConstants.PARAM_PATH, bean.getPath());
				json.put(JHINSConstants.PARAM_DATE, bean.getDate());
				
				json.put(JHINSConstants.PARAM_FORMAT, bean.getFormat());
				json.put(JHINSConstants.PARAM_TITLE, bean.getTitle());
				json.put(JHINSConstants.PARAM_TYPE, bean.getType());
				json.put(JHINSConstants.PARAM_CHANNEL,bean.getChannel());
				json.put(JHINSConstants.PARAM_COLOR_CODE,bean.getColorCode());
				json.put(JHINSConstants.PARAM_IMAGE_PATH,bean.getImagePath());
				json.put(JHINSConstants.PARAM_TOPIC, bean.getTopic());
				json.put(JHINSConstants.PARAM_IS_NEW, bean.getIsNew());
				json.put(JHINSConstants.PARAM_GLYP_ICON, bean.getGlypIcon());
				LOG.info("bean.getPriority()"+bean.getPriority());
				if(bean.getType()!=null)
				{
					if(bean.getType().equalsIgnoreCase("Consumer Guide") ||
							bean.getType().equalsIgnoreCase(JHINSConstants.SAMPLE_CONTRACT))
					{
						hasConsumerMaterial=true;
						
					}
					else if (bean.getType().equalsIgnoreCase(JHINSConstants.PRODUCER_GUIDE) ||
							bean.getType().equalsIgnoreCase(JHINSConstants.TECHINICAL_GUIDE))
					{
						hasProducerMaterial=true;
					}
					
				}
				mainObj.put(JHINSConstants.PRODUCER_MATERAILS,hasProducerMaterial);
				mainObj.put(JHINSConstants.CONSUMER_MATERIALS,hasConsumerMaterial);		
				
			}
			jsonArray.put(json);
		}
		mainObj.put("list", jsonArray);
		if(AssetConstants.SEEMORELABEL !=null && AssetConstants.SEEMORELINK!=null){
		mainObj.put("linkPath", (String) mapObj.get(AssetConstants.SEEMORELINK));
		mainObj.put("linklabel", (String) mapObj.get(AssetConstants.SEEMORELABEL));
		}
		LOG.debug("Final JSON generated is" + mainObj);
		LOG.debug("End of transferAssetDetailstoJSONobj method");
		return mainObj;
	}

	public static ArrayList<AssetMetaDataBean> getRelatedTopic(String product, String assetType, String topic,
			SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {
		LOG.debug("Starting of getRelatedTopic method");
		String[] paths = null;
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag productTag = tagmanager.resolve(product);
		Tag topicTag = tagmanager.resolve(topic);
		Tag assetTypeTag = tagmanager.resolve(assetType);
		LOG.debug("Product = "+productTag+" Topic = "+topicTag+" Type = "+assetTypeTag);

		try {
			
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_group.1_property.value", productTag.getTagID());
			map.put("1_group.2_property", JHINSConstants.PRODUCT_PROP_NAME);//check if this has to be changed
			map.put("1_group.2_property.value", topicTag.getTagID());
			map.put("1_group.3_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("1_group.3_property.value", assetTypeTag.getTagID());
			LOG.debug("************************ AssetType found" + assetType);
			map.put("p.limit", "4");
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			//end of changes for user role
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
		
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
				}
			}

		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		LOG.debug("GET RELATED TOPIC****END******* RETURNING + " + retrieveAssetBean(paths, slingRequest.getResourceResolver()));
		LOG.debug("End of getRelatedTopic method");
		return retrieveAssetBean(paths, slingRequest.getResourceResolver());
	}

	
	


	/**
	 * Method  for  fetching related resources
	 * @param  map
	 * 
	 * returns arrayList 
	 * @throws RepositoryException
	 */
	public ArrayList<AssetMetaDataBean> getRelatedResources(Map<String, Object> mapObj) throws RepositoryException {
		Map<String, Object> mapValues = mapObj;
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		if((mapValues.get(NewsConstants.PARAM_TOPIC)!=null) &&(mapValues.get(NewsConstants.PARAM_LIMIT)!=null)){
		String topic = mapValues.get(NewsConstants.PARAM_TOPIC).toString();
		String limit = mapValues.get(NewsConstants.PARAM_LIMIT).toString();
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
		assetbeans=AssetHelper.relatedResourcesByTopic(slingRequest, topic,limit,(UserTO)mapObj.get(JHINSConstants.USERTO));
		}
		return assetbeans;
	}

	public static ArrayList<AssetMetaDataBean> getKeyProductMaterials(String product,
			SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {
		
		LOG.debug("Starting of getKeyProductMaterials method");
		String[] paths = new String[4];
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		String[] types = { AssetConstants.CONSUMER_GUIDE, AssetConstants.SELLERS_GUIDE,
				AssetConstants.SAMPLE_CONTRACT, AssetConstants.PRODUCER_GUIDE };
		int i = 0;
		for (String type : types) {
			String path = getEachMaterial(product, type, queryBuilder, slingRequest, userTo);
		
			if (path != null && !("".equals(path))) {
				paths[i++] = path;				
			}
		}
		LOG.debug("End of getKeyProductMaterials method");
		return retrieveAssetBean(paths, slingRequest.getResourceResolver());
	}

	
	
	private static String getEachMaterial(String product, String type, QueryBuilder queryBuilder,SlingHttpServletRequest slingRequest,UserTO userTo) {
		LOG.debug("Starting of getEachMaterial method");
		String path = null;
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag productTag = tagManager.resolve(product);
		Tag typeTag = tagManager.resolve(type);
		LOG.debug("Product = "+productTag+" Type = "+typeTag);
		queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);//this has tobe changed
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", "dam:Asset");
		map.put("1_property", JHINSConstants.PRODUCT_PROP_NAME);
		map.put("1_property.value", productTag.getTagID());
		map.put("2_property", JHINSConstants.PRODUCT_PROP_NAME);
		map.put("2_property.value",typeTag.getTagID());
		map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
		map.put("orderby.sort", "desc");
		map.put("p.limit", "1");
		//start of changes for user role
		getFilterForUserRole(map, userTo);
		//end of changes for user role
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		LOG.debug("************ searchResults***" + searchRes.getTotalMatches());
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				try {
					path = hit.getPath();
					LOG.debug("************ searchResults***"+path);
				} catch (RepositoryException e) {
					LOG.error("Repository Exception in getInvestmentInfoPriority1 ", e);
				}
			}
		}
		LOG.debug("End of getEachMaterial method");
		return path;
		
	}
	
	
	

	public static ArrayList<AssetMetaDataBean> getProspectusAssets(String product, SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {
		LOG.debug("Staring of getProspectusAssets method");
		String[] paths = null;
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag productTag = tagManager.resolve(product);
		Tag prosepectusTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS);
		Tag prosepecSupplmentTag = tagManager.resolve(JHINSConstants.JH_TYPE_PROSPECTUS_SUPPLEMENT);
		LOG.debug("product = "+productTag);
		try {
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);// this has tobe changed
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_group.p.or", "true");
			map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_group.1_property.value", productTag.getTagID());
			
			map.put("2_group.p.or", "true");
			map.put("2_group.1_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.1_property.value", prosepectusTag.getTagID());
			map.put("2_group.2_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.2_property.value", prosepecSupplmentTag.getTagID());
			map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
			map.put("orderby.sort", "desc");
			map.put("p.limit", "4");
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			//end of changes for user role
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
				}
			}
			return retrieveAssetBean(paths, slingRequest.getResourceResolver());
		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		LOG.debug("Staring of getProspectusAssets method");
		return null;
	}

	public static Map<String, String> getFilterForUserRole(Map<String, String> map, UserTO userTo){
		LOG.debug("Starting of getFilterForUserRole method");
		if (null != userTo && null!=userTo.getFirmID()) {
					map.put("10_group.2_property", AssetConstants.CQ_TAGS__PROPERTYNAME);
					map.put("10_group.2_property.value", userTo.getFirmID());

		}
		LOG.debug("End of getFilterForUserRole method");
		return map;
	}
	/**
	 * Method  for  fetching fund prospectus resources
	 * @param  prospectusestype
	 * @param title 
	 * @param request
	 * 
	 * returns arrayList 
	 * @throws RepositoryException
	 */
	public static ArrayList<AssetMetaDataBean> retrieveProspectusesAssets(String prospectusType, String prospectusTitle,String limit,
			SlingHttpServletRequest slingRequest,UserTO userTo) {
		String[] paths = null;
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag prosepectusTag = tagmanager.resolve(prospectusType);
		try {
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_group.1_property.value", prosepectusTag.getTagID());
			map.put("2_group.1_property", JHINSConstants.PROSPECTUS_TITLE_PROP);
			map.put("2_group.1_property.value", prospectusTitle);
			map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
			map.put("orderby.sort", "desc");
			map.put("p.limit", limit);
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
				}
			}
			return retrieveAssetBean(paths, slingRequest.getResourceResolver());
			

		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		
		return null;

	}
	// Custom sort based on Priority 
	@SuppressWarnings("unchecked")
	private static ArrayList<AssetMetaDataBean> sortAssetList(ArrayList<AssetMetaDataBean> beanList) {

			 Collections.sort(beanList, new Comparator() {
			        public int compare(Object o1, Object o2) {
			            String x1 = ((AssetMetaDataBean) o1).getPriority();
			            String x2 = ((AssetMetaDataBean) o2).getPriority();
			            int sComp = x1.compareTo(x2);
			               return sComp;
			    }});
				
		return beanList;
	}
	/**
	 * Method will return List of AssertMetaDataBean according to salesflyers
	 * 
	 * @param product
	 * @param slingRequest
	 * @return
	 * @throws RepositoryException
	 */
	public static ArrayList<AssetMetaDataBean> getSalesFlyers(String product1,
			SlingHttpServletRequest slingRequest,UserTO userTo) throws RepositoryException {
		LOG.debug("Starting of getSalesFlyerslAssets method");
		String[] paths = null;
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(product1);
		Tag flyerTag = tagmanager.resolve(JHINSConstants.JH_TYPE_FLYER);
		Tag priorityTag = tagmanager.resolve(JHINSConstants.JH_TYPE_PRIORITY);
		LOG.debug("Product1 = "+tag+" Flyer = "+flyerTag);
		try {
			QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
			session = slingRequest.getResourceResolver().adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", "dam:Asset");
			map.put("1_group.1_property", JHINSConstants.PRODUCT_PROP_NAME);
			map.put("1_group.1_property.value", tag.getTagID());
			map.put("1_group.2_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("1_group.2_property.value", flyerTag.getTagID());
			map.put("2_group.1_property", JHINSConstants.TYPE_PROP_NAME);
			map.put("2_group.1_property.value", priorityTag.getTagID());
			//map.put("orderby", AssetConstants.ORDER_BY_MODIFIED);
			//map.put("orderby.sort", "desc");
			map.put("p.limit", "-1");
			//start of changes for user role
			getFilterForUserRole(map, userTo);
			//end of changes for user role
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
			LOG.debug("************ searchResults***" + searchRes.getTotalMatches());
			paths = new String[searchRes.getHits().size()];
			int i = 0;
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					paths[i++] = hit.getPath();
				}
			}
			ArrayList<AssetMetaDataBean> beanList = retrieveAssetBean(paths, slingRequest.getResourceResolver()); 
			return beanList;
		
		}

		catch (RepositoryException e) {
			LOG.error("RepositoryException occured" ,e.getMessage());
		}
		LOG.debug("End of getSalesFlyers method");
		return null;
	}
	
	}

	


