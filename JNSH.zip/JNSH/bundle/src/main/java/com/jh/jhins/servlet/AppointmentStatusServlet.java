package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.jh.jhins.bean.AppointmentStatusArrayBean;
import com.jh.jhins.bean.AppointmentStatusBean;
import com.jh.jhins.bean.SearchRequests;
import com.jh.jhins.interfaces.AppointmentStatusService;

@SlingServlet(paths = "/bin/sling/appointmentstatus", metatype = true, methods = HttpConstants.METHOD_POST)
@Properties({ @Property(name = "service.description", value = "Appintment Status Servlet"),
		@Property(name = "service.vendor", value = "JHINS") })
public class AppointmentStatusServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(AppointmentStatusServlet.class);
	public static final String APPLICATION_JSON = "application/json";
	public static final String CHARSET = "UTF-8";
	public static final String PRODUCER = "Producer";
	public static final String PRODUCER_SUPPORT = "ProducerSupport";
	public static final String FIRM_SUPPORT = "FirmSupport";
	public static final String SUPERUSER = "SuperUser_SN";

	
	 @Reference 
	 AppointmentStatusService appointmentService;
	 
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		LOG.info("Start Appointment Status doPost method");
		String jsonResponse = null;
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
			String inputData = xssAPI.getValidJSON(request.getParameter("formData"), null);
			String formDataArray = xssAPI.getValidJSON(request.getParameter("formDataArray"), null);
			Gson gson = new Gson();
			if(!inputData.isEmpty()){
				AppointmentStatusBean statusBean = gson.fromJson(inputData, AppointmentStatusBean.class);
				jsonResponse = appointmentService.getProducerData(statusBean);
			}
			if(!formDataArray.isEmpty()){
				AppointmentStatusArrayBean searchDataBean = gson.fromJson(formDataArray, AppointmentStatusArrayBean.class);
				jsonResponse = appointmentService.getFirmSupporMultiSearchData(searchDataBean);
			}
		response.setContentType(APPLICATION_JSON);
        response.setCharacterEncoding(CHARSET);
        PrintWriter out = response.getWriter();
        out.write(xssAPI.getValidJSON(jsonResponse, null));
		out.flush();
		out.close();
	}
	
}
