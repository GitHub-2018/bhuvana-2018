package com.jh.jhins.util;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.ConfigurationPolicy;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(configurationFactory = true, policy = ConfigurationPolicy.REQUIRE, metatype = true, immediate = true, label="Ipipeline Configurations Factory ", description="ipipeline configurations")
public class IpipelineConfigurationUtil{
	
	private static final Logger LOG = LoggerFactory
			.getLogger(IpipelineConfigurationUtil.class);
	

	@Property(description="Label Ipiepline Config service")
	private static final String NAME = "label";
			
  private static final String DEFAULT_TARGET_URL="";
  @Property (description="adress of the SMTP server including port",value=DEFAULT_TARGET_URL)
  private static final String TARGETURL = "targeturl";
  private String targeturl;
  
  private static final String DEFAULT_USERNAME="";
  @Property(description="username to login to the SMTP server",value=DEFAULT_USERNAME)
  private static final String USERNAME = "username";
  private String username;

  private static final String DEFAULT_PASS="null";
  @Property(description= "password to login to the SMTP server",value=DEFAULT_PASS)
  private static final String PASS = "pass";
  private String pass;
  
  private static final String DEFAULT_COMPANY_ID = "";
  @Property(description = "company Name ", value = DEFAULT_COMPANY_ID)
  private static final String COMPANY_ID = "companyid";
  private String companyid;
  

  @Activate
  protected void activate (ComponentContext ctx) {
	targeturl = PropertiesUtil.toString(ctx.getProperties().get(TARGETURL),DEFAULT_TARGET_URL);
    username = PropertiesUtil.toString(ctx.getProperties().get(USERNAME),DEFAULT_USERNAME);
    pass = PropertiesUtil.toString(ctx.getProperties().get(PASS),DEFAULT_PASS);
    companyid = PropertiesUtil.toString(ctx.getProperties().get(COMPANY_ID), DEFAULT_COMPANY_ID);
  }

}