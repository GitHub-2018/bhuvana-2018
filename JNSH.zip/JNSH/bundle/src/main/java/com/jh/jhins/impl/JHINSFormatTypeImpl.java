package com.jh.jhins.impl;

import java.io.IOException;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.interfaces.JHINSFormatType;

@Service
@Component(immediate=true, metatype=true, name= "JHINSFormatTypeImpl", label="Read Format Types")
public class JHINSFormatTypeImpl implements JHINSFormatType {

	private static final Logger LOG = LoggerFactory.getLogger(JHINSFormatTypeImpl.class);

	@Reference
	private ConfigurationAdmin configAdmin;
	Map<String, String> formatTypeMap = new HashMap<String, String>();
	
	
    @Property(unbounded=PropertyUnbounded.ARRAY, label = "Multi String", description = "DAM content format types", name="formatType")
    private String[] formatType;

	public Map<String,String> getConfigProperty(final String property) {
		Map<String,String> resultMap = new HashMap<String, String>();
		String[] arrProperty =null;
		try {
			Configuration conf = configAdmin.getConfiguration(JHINSConstants.FORMATCONFIG_PID);
			@SuppressWarnings(JHINSConstants.UNCHECKED)
			Dictionary<String, Object> properties = conf.getProperties();
			
			arrProperty = PropertiesUtil.toStringArray(properties.get(property));
			if(arrProperty!=null){
				for(int i=0; i<arrProperty.length; i++){
					String prop = arrProperty[i];
					String[] arr = prop.split(":");
					if(arr!=null && arr.length==2){
						resultMap.put(arr[0], arr[1]);
					}
				}
			}

		} catch (IOException e) {
			LOG.error("IOException",e);
		}
		return resultMap;	
	}	
}
