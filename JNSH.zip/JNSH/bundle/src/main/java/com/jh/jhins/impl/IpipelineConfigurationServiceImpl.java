package com.jh.jhins.impl;

import java.util.Dictionary;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.IpipelineBean;
import com.jh.jhins.interfaces.IpipelineConfigurationService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.util.IpipelineConfigurationUtil;

//import com.nateyolles.sling.publick.services.OsgiConfigurationService;

/**
 * Service to interact with OSGi configurations.
 */
@Service(value = IpipelineConfigurationService.class)
@Component(name = "Ipipeline OSGi Configuration Service",
           description = "Programatically get Ipipeline properties of OSGi configurations.")
public class IpipelineConfigurationServiceImpl implements IpipelineConfigurationService {

	private static final Logger log = LoggerFactory.getLogger(IpipelineConfigurationServiceImpl.class);
	
	
	@Reference
	private ConfigurationAdmin configAdmin;
	
	IpipelineBean ipipelineBean = new IpipelineBean();
	
	String formType = "";
	String groupName = "";
	public void setConfiguration(String formtype, String groupname) {

		formType = formtype;
		groupName = groupname;
		
		log.debug("formType##"+formType);
		log.debug("groupName##"+groupName);
		// TODO Auto-generated method stub
		CryptoBase64 decryptVal = new CryptoBase64();
		BundleContext bundleContext = FrameworkUtil.getBundle(IpipelineConfigurationUtil.class).getBundleContext();
	    ServiceReference configurationAdminReference = bundleContext.getServiceReference(ConfigurationAdmin.class.getName());
	    if (configurationAdminReference != null) {
	       ConfigurationAdmin confAdmin = (ConfigurationAdmin) bundleContext.getService(configurationAdminReference);
	       try {
	           Configuration conf[] = confAdmin.listConfigurations("("+ConfigurationAdmin.SERVICE_FACTORYPID+"="+IpipelineConfigurationUtil.class.getName()+")");
	           for (Configuration c : conf){
	              Dictionary<String,Object> props = c.getProperties();
	            
	           ipipelineBean.setLabel(props.get("label").toString());
	           log.debug("label@@"+ipipelineBean.getLabel());
	        
	            if(groupName.equalsIgnoreCase(ipipelineBean.getLabel())){
	            	ipipelineBean.setUsername(props.get("username").toString()); 
	            	ipipelineBean.setPassword(String.valueOf(decryptVal.decrypt(props.get("pass").toString().trim()))); 
	            	ipipelineBean.setTargeturl(props.get("targeturl").toString()); 
	            	ipipelineBean.setCompanyid(props.get("companyid").toString()); 	
	            } else if("JHEdwardJones".equalsIgnoreCase(groupName)){
	            	log.debug("inside else if 2");
	            	log.debug("groupName@@"+groupName);
	            	log.debug("formType@@"+formType);
	            	if("JHEdwardJonesCF".equalsIgnoreCase(ipipelineBean.getLabel()) && formType.equalsIgnoreCase("cF")){
	            		ipipelineBean.setUsername(props.get("username").toString()); 
		            	ipipelineBean.setPassword(String.valueOf(decryptVal.decrypt(props.get("pass").toString().trim()))); 
		            	ipipelineBean.setTargeturl(props.get("targeturl").toString()); 
		            	ipipelineBean.setCompanyid(props.get("companyid").toString()); 	
	            	}else if("JHEdwardJonesNF".equalsIgnoreCase(ipipelineBean.getLabel()) && formType.equalsIgnoreCase("nF")){
	            		ipipelineBean.setUsername(props.get("username").toString()); 
		            	ipipelineBean.setPassword(String.valueOf(decryptVal.decrypt(props.get("pass").toString().trim()))); 
		            	ipipelineBean.setTargeturl(props.get("targeturl").toString()); 
		            	ipipelineBean.setCompanyid(props.get("companyid").toString()); 	
	            	} 
	            }
	            else if("LeadGenerationForm".equalsIgnoreCase(groupName)){
	            	log.debug("inside else if");
	            	log.debug("groupName@@"+groupName);
	            	log.debug("formType@@"+formType);
            		  if("ClientOffer".equalsIgnoreCase(ipipelineBean.getLabel()) && formType.equalsIgnoreCase("clientoffer")){
            			ipipelineBean.setUsername(props.get("username").toString()); 
  		            	ipipelineBean.setPassword(props.get("pass").toString().trim()); 
  		            	ipipelineBean.setTargeturl(props.get("targeturl").toString()); 
  		            	ipipelineBean.setCompanyid(props.get("companyid").toString()); 		
            		  }
            		else if("ProducerOffer".equalsIgnoreCase(ipipelineBean.getLabel()) && formType.equalsIgnoreCase("produceroffer")){
            			ipipelineBean.setUsername(props.get("username").toString()); 
  		            	ipipelineBean.setPassword(props.get("pass").toString().trim()); 
  		            	ipipelineBean.setTargeturl(props.get("targeturl").toString()); 
  		            	ipipelineBean.setCompanyid(props.get("companyid").toString()); 	
            		}
            		else if("LeadGeneration".equalsIgnoreCase(ipipelineBean.getLabel()) && formType.equalsIgnoreCase("LeadGenerationForms")){
            			ipipelineBean.setUsername(props.get("username").toString()); 
  		            	ipipelineBean.setPassword(props.get("pass").toString().trim()); 
  		            	ipipelineBean.setTargeturl(props.get("targeturl").toString()); 
  		            	ipipelineBean.setCompanyid(props.get("companyid").toString()); 	
            		}
	           }
	        }
	             
	        } catch (Exception e) {
	           log.error("Error getting Web Service URL", e);
	       }
	       
	    }
	}
	
	public String getXML(){
		StringBuilder applicationData = new StringBuilder();
		
		applicationData.append("<?xml version='1.0' ?><iPipelineApplicationData xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'><GeneralInformation><ApplicationIdentifier/><RedirectURL>");
  		applicationData.append(ipipelineBean.getTargeturl());
  		applicationData.append("</RedirectURL><CompanyUserName>");
  		applicationData.append(ipipelineBean.getUsername());
  		applicationData.append("</CompanyUserName><CompanyPassword>");
  		applicationData.append(ipipelineBean.getPassword());	
  		applicationData.append("</CompanyPassword></GeneralInformation><CompanyIdentifier>");
  		applicationData.append(ipipelineBean.getCompanyid());	
  		applicationData.append("</CompanyIdentifier></iPipelineApplicationData>");
  		//log.info("applicationData:::::::::::::::::::::"+applicationData);
		
		return applicationData.toString();
		
	}
	
	@Activate
	     public void activate() throws Exception {    
		
			setConfiguration(formType, groupName);
	}	
}



	