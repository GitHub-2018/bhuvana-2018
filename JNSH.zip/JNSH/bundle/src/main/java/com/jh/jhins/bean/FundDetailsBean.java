package com.jh.jhins.bean;


public class FundDetailsBean {

	private String risk;
	private int riskOrder;	
	private String morningStarPath;
	private String managementFee;
	private String incepDate;
	private String fundTitle;
	private String fundManager;
	private String footNote;
	private String numberedFootNotes;

	
	
	public String getFootNote() {
		return footNote;
	}
	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}
	public String getRisk() {
		return risk;
	}
	public void setRisk(String risk) {
		this.risk = risk;
	}
	public int getRiskOrder() {
		return riskOrder;
	}
	public void setRiskOrder(int riskOrder) {
		this.riskOrder = riskOrder;
	}	
	public String getMorningStarPath() {
		return morningStarPath;
	}
	public void setMorningStarPath(String morningStarPath) {
		this.morningStarPath = morningStarPath;
	}
	public String getManagementFee() {
		return managementFee;
	}
	public void setManagementFee(String managementFee) {
		this.managementFee = managementFee;
	}
	public String getIncepDate() {
		return incepDate;
	}
	public void setIncepDate(String incepDate) {
		this.incepDate = incepDate;
	}
	public String getFundTitle() {
		return fundTitle;
	}
	public void setFundTitle(String fundTitle) {
		this.fundTitle = fundTitle;
	}
	public String getFundManager() {
		return fundManager;
	}
	public void setFundManager(String fundManager) {
		this.fundManager = fundManager;
	}
	public String getNumberedFootNotes() {
		return numberedFootNotes;
	}
	public void setNumberedFootNotes(String numberedFootNotes) {
		this.numberedFootNotes = numberedFootNotes;
	}
	
}
