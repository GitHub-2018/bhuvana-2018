package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.jh.jhins.bean.ProducerTermsandConditionBean;
import com.jh.jhins.interfaces.JHINSFirmSupportTNCService;
import com.jh.jhins.interfaces.JHINSProducerTNCService;

@SlingServlet( paths = "/bin/sling/producertermsandcondition",metatype=true, methods = HttpConstants.METHOD_POST )
@Properties({ @Property(name = "service.description", value = "Producer Terms and condition Servlet"),
	@Property(name = "service.vendor", value = "JHINS")})
public class ProducerTermsandConditionServlet extends SlingAllMethodsServlet {
	
	private static final Logger LOG = LoggerFactory.getLogger(ProducerTermsandConditionServlet.class);
	public static final String USER_ROLE = "userRole";
	public static final String PRODUCER = "Producer";
	public static final String PRODUCER_SUPPORT = "ProducerSupport";
	public static final String FIRM_SUPPORT = "FirmSupport";
	public static final String SUPERUSER = "SuperUser_SN";
	public static final String INPUT_PROFILE_ID = "profileId";
	public static final String INPUT_LASTNAME="lastname";
	public static final String INPUT_SSN_NO="ssnNo";
	public static final String INPUT_NPN_NO="npnNo";
	public static final String APPLICATION_JSON="application/json";
	public static final String CHARSET="UTF-8";
	
	@Reference
	JHINSProducerTNCService producerService;
	
	@Reference
	JHINSFirmSupportTNCService firmSupportService;
	
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException  {
		LOG.info("Start Producer terms and condition doPost method");
		String jsonResponse = null;
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String inputData = xssAPI.getValidJSON(request.getParameter("formData"), null);
		LOG.debug("Producer Terms and condition InputData:::::::::::::"+inputData);
		Gson gson = new Gson();
		ProducerTermsandConditionBean bean = gson.fromJson(inputData, ProducerTermsandConditionBean.class);
		String role = bean.getUserRole();
		if(PRODUCER.equalsIgnoreCase(role) || PRODUCER_SUPPORT.equalsIgnoreCase(role)){
			String profileId = bean.getProfileId();
			jsonResponse = producerService.getJsonData(profileId, role);
		}else if(FIRM_SUPPORT.equalsIgnoreCase(role) || SUPERUSER.equalsIgnoreCase(role)){
			String lastName = bean.getLastName();
			String ssnNO = bean.getSsnNo();
			String npnNO = bean.getNpnNo();
			jsonResponse = firmSupportService.getJsonData(lastName, ssnNO, npnNO, role);
		}
		response.setContentType(APPLICATION_JSON);
        response.setCharacterEncoding(CHARSET);
        PrintWriter out = response.getWriter();
        if(null != jsonResponse && "" != jsonResponse){
        	out.write(xssAPI.getValidJSON(jsonResponse, null));
        }
		out.flush();
		out.close();
        LOG.info("End Producer terms and condition doPost method");
	}
}
