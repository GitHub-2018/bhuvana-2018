package com.jh.jhins.model.sling;

import java.io.Serializable;

import javax.inject.Inject;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

/**
 * This class represents Design Tab component data.
 * 
 * @author yadanku
 *
 */

@Model(adaptables=Resource.class)
public class DesignTab implements Serializable {

	private static final long serialVersionUID = -7952385786231703389L;
	@Inject
    @Optional
    private String compact;

	public static DesignTab createModel(Resource resource) {
        DesignTab design = null;

        if(resource != null) {
            design = resource.adaptTo(DesignTab.class);
        }

        return design;
    }

	/**
	 * @return the compact
	 */
	public String getCompact() {
		return compact;
	}

	/**
     * Returns a string representation of this {@code DesignTab}.
     *
     * @return String
     * @see ReflectionToStringBuilder#reflectionToString(Object)
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.reflectionToString(this);
    }
	
	
	
}
