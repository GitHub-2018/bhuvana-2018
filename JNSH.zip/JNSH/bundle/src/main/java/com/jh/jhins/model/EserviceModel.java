package com.jh.jhins.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Model(adaptables = Resource.class)
public class EserviceModel {

	private static final Logger LOG = LoggerFactory.getLogger(EserviceModel.class);
	@Inject
	private List<String> individualProducts;
	@Inject 
	private List<String> corporateProducts;
	@Inject 
	private List<String> mproprietoryProducts;
	 
	@Inject
	private ResourceResolver resourceResolver;
	 
	private Map<String,String> individualProductsMap;
	 
	private Map<String,String> corporateProductsMap;
	
	private Map<String,String> mproprietoryProductsMap;
	
	public Map<String, String> getIndividualProductsMap() {
		return individualProductsMap;
	}

	public Map<String, String> getCorporateProductsMap() {
		return corporateProductsMap;
	}

	public Map<String, String> getMproprietoryProductsMap() {
		return mproprietoryProductsMap;
	}

	
	@PostConstruct
	protected void init()
	{
		individualProductsMap = getProductsMap(individualProducts);
		corporateProductsMap = getProductsMap(corporateProducts);
		mproprietoryProductsMap = getProductsMap(mproprietoryProducts);
		
		LOG.debug("individualProductsMap:::::"+individualProductsMap.toString());
		LOG.debug("corporateProductsMap:::::"+corporateProductsMap.toString());
		LOG.debug("mproprietoryProductsMap:::::"+mproprietoryProductsMap.toString());
		//setProducts(finalList.toString());
	}
	
	private Map<String,String> getProductsMap(List<String> proudctsList) {
		Map<String,String> productsMap=new HashMap<String,String>();
		for(String path :proudctsList ){
			Resource resource = resourceResolver.getResource(path);
			LOG.info("resource:::::"+resource.getName());
			Resource pageResource =resource.getResourceResolver().getResource(resource.getPath()+"/jcr:content/par/productprofilecomp");
	  		  if(pageResource != null){
		    		  ValueMap resourceValMap =pageResource.getValueMap();
		    		  String productCode = resourceValMap.get("productCode").toString();
		    		  String productName = resourceValMap.get("name").toString();
		    		  productsMap.put(productName,productCode);
	  		  }
		}	
		Map<String, String> treeMap = new TreeMap<String, String>(productsMap);
		return treeMap;
	}
	
}
