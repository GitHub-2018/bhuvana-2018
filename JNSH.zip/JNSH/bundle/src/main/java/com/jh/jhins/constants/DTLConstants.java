package com.jh.jhins.constants;

/**
 * Class for DTLConstants values 
 *
 */
public class DTLConstants {
	public static final String PAGE_NAME="jhsaleshub";
	public static final String UNCHECKED="unchecked";
	public static final String CONFIG_CONTACTUS_PATH= "contactus.path";
	public static final String CONFIG_PID="";
	public static final String EMPTY_STRING = " ";
	public static final String PAGE_TYPE = "pagetype";
	public static final String PARAM_CONFIG_PROPERTY="configProperty";
}
