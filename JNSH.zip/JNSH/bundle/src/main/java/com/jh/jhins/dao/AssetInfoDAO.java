package com.jh.jhins.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.AssetMetaDataBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.AssetConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.helper.AssetHelper;

public class AssetInfoDAO {

	private static final Logger LOG = LoggerFactory.getLogger(AssetInfoDAO.class);

	/**
	 * Method for fetching consumer material asset
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public ArrayList<AssetMetaDataBean> getConsumermaterialAssets(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {
		LOG.debug("Starting of getConsumermaterialAssets method");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String product1 = (String) mapObj.get(AssetConstants.PARAM_PRODUCT1);
		LOG.debug("product1 value = "+product1);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.consumerMaterialResults(product1, slingRequest, userTo);
		LOG.debug("End of getConsumermaterialAssets method");
		return assetbeans;

	}

	/**
	 * Method for fetching producer material asset
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public ArrayList<AssetMetaDataBean> getProducerMaterialAssets(Map<String, Object> mapObj)
			throws RepositoryException {
		LOG.debug("Starting of getProducerMaterialAssets method");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String product1 = (String) mapObj.get(AssetConstants.PARAM_PRODUCT1);
		LOG.debug("product1 value = "+product1);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.getProducerMaterialAssets(product1, slingRequest, userTo);
		LOG.debug("End of getProducerMaterialAssets method");
		return assetbeans;
	}

	/**
	 * Method for fetching Sales Flyer material asset
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public ArrayList<AssetMetaDataBean> getSalesFlyerslAssets(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("Starting of getSalesFlyerslAssets mthod");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String product1 = (String) mapObj.get(AssetConstants.PARAM_PRODUCT1);
		LOG.debug("product1 value = "+product1);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.getSalesFlyerslAssets(product1, slingRequest, userTo);
		LOG.debug("End of getSalesFlyerslAssets method");
		return assetbeans;
	}

	
	/**
	 * Method for fetching Investment Information asset
	 * @param mapObj
	 * @return
	 * @throws RepositoryException
	 */
	public ArrayList<AssetMetaDataBean> getInvestmentInfoAssets(Map<String, Object> mapObj) throws RepositoryException {
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		LOG.debug("Starting of getInvestmentInfoAssets method");
		String product1 = (String) mapObj.get(AssetConstants.PARAM_PRODUCT1);
		String product2 = (String) mapObj.get(AssetConstants.PARAM_PRODUCT2);
		LOG.debug("product1 value = "+product1+" product2 value ="+product2);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.getInvestmentInfoAssets(product1, product2, slingRequest, userTo);
		LOG.debug("End of getInvestmentInfoAssets method");
		return assetbeans;
	}

	
	/**
	 * Method for fetching Related Topic asset
	 * @param mapObj
	 * @return
	 * @throws RepositoryException
	 */
	public ArrayList<AssetMetaDataBean> getRelatedTopic(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("starting of getRelatedTopic method");
		Map<String, Object> mapValues = mapObj;
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String product = mapValues.get(AssetConstants.PARAM_PRODUCT).toString();
		String assetType = mapValues.get(AssetConstants.PARAM_TYPE).toString();
		String topic = mapValues.get(AssetConstants.PARAM_TOPIC).toString();
		LOG.debug("product value = "+product+" type value ="+assetType+" topic value = "+topic);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.getRelatedTopic(product, assetType, topic, slingRequest, userTo);
		LOG.debug("End of getRelatedTopic method");
		return assetbeans;

	}

	/**
	 * Method for fetching Key-Product material asset
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */
	public ArrayList<AssetMetaDataBean> getKeyProductMaterials(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("Starting of getKeyProductMaterials method");
		String product = mapObj.get(AssetConstants.PARAM_PRODUCT).toString();
		LOG.debug("product value = "+product);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		LOG.debug("End of getKeyProductMaterials method");
		return AssetHelper.getKeyProductMaterials(product, slingRequest, userTo);
	}

	public ArrayList<AssetMetaDataBean> getProspectusAssets(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("Starting of getProspectusAssets method");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String product = mapObj.get(AssetConstants.PARAM_PRODUCT).toString();
		LOG.debug("product value = "+product);
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		assetbeans = AssetHelper.getProspectusAssets(product, slingRequest, userTo);
		LOG.debug("End of getProspectusAssets method");
		return assetbeans;
	}
	/**
	 * Method for retrieving fundprospectuses
	 * 
	 * @param map
	 * 
	 *            returns ArrayList<AssetMetaDataBean>
	 * @throws RepositoryException
	 */
	public ArrayList<AssetMetaDataBean> getFundProspectusAssets(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("Starting of getFundProspectusAssets method");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String prospectusType = mapObj.get(AssetConstants.PROSPECTUSES_TYPE).toString();
		String prospectusTitle = mapObj.get(AssetConstants.PROSPECTUSES_TITLE).toString();
		String limit = mapObj.get(AssetConstants.PARAM_LIMIT).toString();
		LOG.debug("prospectusType = "+prospectusType+" prospectusTitle = "+prospectusTitle+" limit = "+limit);
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		assetbeans = AssetHelper.retrieveProspectusesAssets(prospectusType, prospectusTitle,limit,slingRequest,userTo);
		LOG.debug("End of getFundProspectusAssets method");
		return assetbeans;

	}

	/**
	 * Method for retrieving related resources based on topic of current page. 
	 * 
	 * @param map
	 * 
	 *            returns ArrayList<AssetMetaDataBean>
	 * @throws RepositoryException
	 */
	public ArrayList<AssetMetaDataBean> relatedResourcesByTopic(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("Starting of relatedResourcesByTopic method");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String topic = mapObj.get(AssetConstants.PARAM_TOPIC).toString();
		String items = mapObj.get(AssetConstants.PARAM_LIMIT).toString();
		LOG.debug("topic = "+topic+" limit = "+items);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(AssetConstants.SLING_REQUEST);
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.relatedResourcesByTopic(slingRequest, topic, items, userTo);
		LOG.debug("End of relatedResourcesByTopic method");
		return assetbeans;
	}
	
	/**
	 * Method for retrieving related resources based on topic of current page. It won't  retrieve child topic resources
	 * 
	 * @param map
	 * 
	 *            returns ArrayList<AssetMetaDataBean>
	 * @throws RepositoryException
	 */
	public ArrayList<AssetMetaDataBean> relatedItemsResources(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("Starting of relatedItemsResources method");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String topic = mapObj.get(AssetConstants.PARAM_TOPIC).toString();
		String items = mapObj.get(AssetConstants.PARAM_LIMIT).toString();
		LOG.debug("topic = "+topic+" limit = "+items);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(AssetConstants.SLING_REQUEST);
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.relatedItemsResources(slingRequest, topic, items, userTo);
		LOG.debug("End of relatedItemsResources method");
		return assetbeans;
	}
	
	/**
	 * Method for fetching Sales Flyer component asset
	 * 
	 * @param map
	 * 
	 *            returns arrayList
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public ArrayList<AssetMetaDataBean> getSalesFlyers(Map<String, Object> mapObj) throws RepositoryException {
		LOG.debug("Starting of getSalesFlyerslAssets mthod");
		ArrayList<AssetMetaDataBean> assetbeans = new ArrayList<AssetMetaDataBean>();
		String product1 = (String) mapObj.get(AssetConstants.PARAM_PRODUCT1);
		LOG.debug("product1 value = "+product1);
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get("slingRequest");
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		assetbeans = AssetHelper.getSalesFlyers(product1, slingRequest, userTo);
		LOG.debug("End of getSalesFlyerslAssets method");
		return assetbeans;
	}

}