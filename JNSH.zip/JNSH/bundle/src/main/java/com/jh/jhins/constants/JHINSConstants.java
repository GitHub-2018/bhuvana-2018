package com.jh.jhins.constants;

public class JHINSConstants {
	public static final String DAM_PATH = "/content/dam/JHINS";
	public static final String PRODUCT_PROP_NAME="@jcr:content/metadata/cq:tags";
	public static final String PROSPECTUS_TITLE_PROP="jcr:content/metadata/./dc:title";
	public static final String TOPIC_PROP_NAME="@jcr:content/metadata/./dc:title";
	public static final String TYPE_PROP_NAME="@jcr:content/metadata/cq:tags";
	public static final String PARAM_DATE = "date";
	public static final String ARTICLE_TEMPLATE = "/apps/JHINS/templates/articletemplate";
	public static final String SLING_RESOURCETYPE="@jcr:content/sling:resourceType";
	public static final String CQ_TEMPLATE="@jcr:content/cq:template";
	public static final String JH_TYPE= "/content/cq:tags/JHINS/type";
	public static final String JH_TYPE_PROSPECTUS= "/content/cq:tags/JHINS/type/prospectus";
	public static final String JH_TYPE_PROSPECTUS_SUPPLEMENT= "/content/cq:tags/JHINS/type/prospectus_supplement";
	
	public static final String PARAM_FUNCTIONALITY = "functionality";
	public static final String JH_TYPE_FLYER="/content/cq:tags/JHINS/type/flyer";
	public static final String JH_TYPE_PRIORITY="/content/cq:tags/JHINS/priority/high";
	public static final String JH_TYPE_ARTICLE="/content/cq:tags/JHINS/type/article";
	public static final String JH_TYPE_BROUCHURE="/content/cq:tags/JHINS/type/brochure";
	public static final String PARAM_USERID = "userId";
	public static final String PARAM_FIRMID = "firmId";
	public static final String PARAM_LIMIT = "limit";
	public static final String PARAM_TOPIC = "topic";
	public static final String PARAM_TYPE = "type";
	public static final String PARAM_PATH = "path";
	public static final String PARAM_STATE = "state";
	public static final String PARAM_PRODUCT = "product";
	public static final String PARAM_CHANNEL = "channel";
	public static final String PARAM_FORMAT = "format";
	public static final String PARAM_TITLE = "title";
	public static final String JCR_TITLE="jcr:title";
	public static final String PAGE_PAR="page_par";
	public static final String CONTENT_STREAM_TYPE="contentstreamtype";
	public static final String IDENTITY_SOURCE="identitySource";
	public static final String CONTENT_TYPE="contentType";
	public static final String EQUAL="=";
	public static final String AMPERSAND="&";
	public static final String COMMA=",";
	public static final String APPLICATION_JSON="application/json";
	public static final String CHARSET="UTF-8";
	public static final String TEXT="text";
	public static final String VALUE="value";
	public static final String SERVICE_DESCRIPTION = "service.description";	
	public static final String SERVICE_VENDOR = "service.vendor";	
	public static final String SLING_SERVLET_SELECTORS = "sling.servlet.selectors";	
	public static final String SLING_SERVLET_PATH = "sling.servlet.paths";
	public static final String SLING_SERVLET_METHOD ="sling.servlet.methods";
	public static final String FIRM_ID_TEXT ="firm.id.text";
	public static final String FIRM_ID_VALUE ="firm.id.value";
	public static final String IDENTITYSOURCE_ID_TEXT ="identitySource.id.text";
	public static final String IDENTITYSOURCE_ID_VALUE ="identitySource.id.value";
	public static final String CQ_TEMPLATE_LABEL="cq:template";
	public static final String BASE_PAGE_TEMPLATE="/apps/JHINS/templates/basepagetemplate";
	
	
	

	
	public static final String IMAGE_RENDITION_30_42 = "cq5dam.thumbnail.30.42.png";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
	public static final String EMPTY_STRING = "";
	public static final String TAGID_CHANNEL = "JHINS:channel";
	
	public static final String ASSET_TITLE = "dc:title";
	public static final String ASSET_FORMAT="dc:format";
	public static final String ASSET_TYPE="asset";
	public static final String NEWS_TYPE="news";
	public static final String PARAM_CLIENT_APPROVED = "@jcr:content/metadata/jh:consumerapproved";
	public static final String IMAGE_RENDITION_48_48 = "cq5dam.thumbnail.48.48.png";
	public static final String TAGID_TOPIC = "jhins:topic";
	public static final String CQ_TAGS_METADATA_PROPERTYNAME = "@jcr:content/metadata/cq:tags";
	public static final String CQ_TAGS__PROPERTYNAME = "@jcr:content/cq:tags";
	public static final String TAGID_CLIENT_APPROVED = "jh:consumer_approved";
	public static final String TOOL_URL = "jh:url";
	public static final String PARAM_FIRM = "firm";
	public static final String PARAM_DEFAULT = "default";
	public static final String CONTACT="contact";
	public static final String CQ_TAGS="cq:tags";
	public static final String DAM_ASSET="dam:Asset";
	
	public static final String ASSET_DESC="dc:description";

	public static final String TAG_FORMAT_DOC = "DOC";
	public static final String TAG_FORMAT_PDF = "PDF";
	public static final String TAG_FORMAT_PPT = "PPT";
	public static final String TAG_FORMAT_TOOL = "Tool";
	public static final String TAG_FORMAT_HTML = "HTML";
	public static final String TAG_FORMAT_AUDIO = "Audio";
	public static final String TAG_FORMAT_VIDEO = "Video";
	public static final String TAG_FORMAT_EXCEL = "XLS";
	public static final String TAG_FORMAT_IMAGE = "Image";
	public static final String TAG_COLOR_RED = "red";
	public static final String TAG_COLOR_GREEN= "green";
	public static final String TAG_COLOR_BLUE = "blue";
	public static final String USERTO="UserTO";
	public static final String SLING_REQUEST="slingRequest";
	public static final String PARAM_COLOR_CODE = "colorCode";
	public static final String PARAM_IMAGE_PATH = "imagePath";
	public static final String PARAM_IS_NEW = "isNew";
	public static final String PARAM_ASSET_TYPE = "assetType";
	public static final String PARAM_GLYP_ICON = "glypIcon";
	public static final String SORT_DESC = "desc";
	public static final String ORDER_BY = "@jcr:content/cq:lastReplicated";
	
	public static final String PRODUCER_GUIDE = "Producer Guide";
	public static final String CONSUMER_GUIDE = "Consumer Guide ";
	public static final String TECHINICAL_GUIDE = "Technical Guide";
	public static final String SELLERS_GUIDE = "Seller's Guide";
	public static final String SAMPLE_CONTRACT = "Sample Contract";
	public static final String PRODUCER_MATERAILS = "ProducerMaterials";
	public static final String CONSUMER_MATERIALS = "ConsumerMaterials";
	
	public static final String HEADER_IV_USER = "iv-user";
	public static final String HEADER_IV_GROUPS = "iv-groups";
	public static final String HEADER_FIRM_INDICATOR = "firmindicator";
	public static final String HEADER_GROUP_EDJONES = "\"EJProducers\"";
	public static final String HEADER_GROUP_PRODUCERS= "Producers";
	public static final String HEADER_FIRMINDICATOR_MGROUP = "MGroup";
	public static final String FIRM_EDJONES = "/content/cq:tags/JHINS/firm/edjones";
	public static final String FIRM_MGROUP = "/content/cq:tags/JHINS/firm/mgroup";
	public static final String FIRM_TAG_EDJONES = "JHINS:firm/edjones";
	public static final String FIRM_TAG_MGROUP = "JHINS:firm/mgroup";
	public static final String PARAM_CHANNELS = "channels";
	public static final String HEADER_GROUP_EJPRODUCERS="\"EJProducers\"";
	public static final String HEADER_GROUP_PRODUCERS_NEW="\"Producers\"";
	public static final String JHINS_FIRM="JHINS:firm";
	
	public static final String ETC_HEADERS_NODE_PATH = "/apps/settings/wcm/lists/headers/";
	public static final String ETC_LIST_ITEM_PATH = "/jcr:content/list/item";
	public static final String ETC_VIEWS_NODE_PATH = "/apps/settings/wcm/lists/views/jcr:content/list";
	public static final String COOKIE_USER_VIEW = "user_view";
	public static final String VIEW_PROPERTY = "value";
	public static final String UNCHECKED="unchecked";
	public static final String CONFIG_PID="com.jh.jhins.impl.JHINSConfigServiceImpl";
	
	public static final String JHINSPRIORITY = "JHINS:priority/";
	public static final String CQ_TAGS_PROPERTYNAME = "@jcr:content/cq:tags";
	public static final String JH_PRIORITY = "/content/cq:tags/JHINS/priority/high";
	public static final String PARAM_PRIORITY= "priority";
	public static final String PRIORITY_LOW = "low";
	
	public static final String PDF_FORMAT = "application/pdf";
	public static final String PPT_FORMAT = "application/vnd.ms-powerpoint";
	public static final String DOC_FORMAT = "application/msword";
	public static final String EXCEL_FORMAT = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static final String AUDIO_FORMAT = "audio/mpeg";
	public static final String VIDEO_FORMAT = "video/x-ms-wmv";
	public static final String TOOL_FORMAT = "application/x-msdownload";
	public static final String IMAGE_FORMAT = "image/jpeg";
	public static final String PPT1_FORMAT = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
	public static final String TOOL1_FORMAT = "application/zip";
	public static final String EXCEL1_FORMAT = "application/vnd.ms-excel";
	public static final String DOC1_FORMAT = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
	
	public static final String FORMATCONFIG_PID = "com.jh.jhins.impl.JHINSFormatTypeImpl";
	public static final String FORMAT_TYPE = "formatType";
	
	public static final String VITALITY_PAGEPATH = "/content/JHINS/en_US/NLI/maintenance/vitality-maintenance";
	public static final String SALESHUB_PAGEPATH = "/content/JHINS/en_US/NLI/maintenance/saleshub-maintenance";
	public static final String SALESHUB = "saleshub";
	public static final String VITALITY = "vitality";
	public static final String JCR_CONTENT ="jcr:content";
	public static final String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	
	public static final String PRODUCER_HEADER_KEY = "producer.header.key";
	public static final String PRODUCER_HEADER_VALUE = "producer.header.value";
	public static final String PRODUCER_URL="producer.url";
	
	public static final String PRODUCER_SUPPORT_HEADER_KEY = "producerSupport.header.key";
	public static final String PRODUCER_SUPPORT_HEADER_VALUE = "producerSupport.header.value";
	public static final String PRODUCER_SUPPORT_URL="producerSupport.url";
	
	public static final String PRODUCER_CONFIG_PID="com.jh.jhins.impl.JHINSProducerTNCServiceImpl";
	public static final String PROFILE_ID = "profileId";
	public static final String USER_ROLE = "userRole";
	public static final String PRODUCER = "Producer";
	public static final String PRODUCER_SUPPORT = "ProducerSupport";
	
	public static final String DATA_SOURCE = "datasource";
	public static final String ADD_NONE= "addNone";
	public static final String AUTHORIZATION = "Authorization";
	public static final String JSON_BODY_TYPE = "application/json";
	public static final String UTF_CHARSET = "UTF-8";
	
}
