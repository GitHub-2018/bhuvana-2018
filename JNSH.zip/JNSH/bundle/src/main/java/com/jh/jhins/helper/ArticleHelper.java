package com.jh.jhins.helper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jh.jhins.bean.ArticleBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;

public class ArticleHelper {
	private static final Logger LOG = LoggerFactory.getLogger(ArticleHelper.class);
	private static Session session;

	/**
	 * Method to fetch the recent news
	 *
	 * @param map
	 * 
	 * @return arraylist
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public static ArrayList<ArticleBean> retrieveRecentNews(Map<String, Object> mapObj)
			throws RepositoryException, ParseException {
		ArrayList<ArticleBean> articleBeans = new ArrayList<ArticleBean>();

		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);

		ResourceResolver resourceResolver = slingRequest.getResourceResolver();
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		LOG.debug("session value is " + session);
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		String limit = mapObj.get(NewsConstants.PARAM_LIMIT).toString();
		String path = mapObj.get(NewsConstants.PARAM_PATH).toString();
		String topic = mapObj.get(NewsConstants.PARAM_TOPIC).toString();
	
		// start of changes for user role
		UserTO userTo = (UserTO) mapObj.get(JHINSConstants.USERTO);
		// end of changes for user role
		Map<String, String> map = new HashMap<String, String>();
		map.put(NewsConstants.PARAM_PATH, path);
		map.put("1_property", NewsConstants.CQ_TEMPLATE);
		map.put("1_property.value", NewsConstants.ARTICLE_TEMPLATE);
		if (topic != null) {
			map.put("2_property", NewsConstants.JCR_TOPICS);
			map.put("2_property.value", NewsConstants.JHINSTOPIC+topic + "%");
			map.put("2_property.operation", "like");
		}
		map.put("orderby", NewsConstants.ORDER_BY);
		map.put("orderby.sort", NewsConstants.ODERBY_SORT);
		map.put("p.limit", limit);
		// start of changes for user role
		getFilterForUserRole(map, userTo);
		// end of changes for user role

		LOG.debug("*****MAP FOR RECENT NEWS ****");
		JHPageHelper.logMap(map);
		LOG.debug("*****END**********");

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();

		if (!searchRes.getHits().isEmpty()) {

			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				LOG.debug("queryPath on each iteration" + queryPath);
				ArticleBean articleBean = new ArticleBean();
				// sending query results to retrieve the bean values
				articleBean = retriveArticleBean(queryPath, resourceResolver);
				articleBeans.add(articleBean);

			}
		}

		return articleBeans;

	}

	/**
	 * Method to extract the last modified date
	 *
	 * @param Jcrnode
	 * 
	 * @return Date(String Format)
	 * @throws RepositoryException
	 * @throws ParseException
	 * @throws ParseException
	 */

	@SuppressWarnings("unused")
	private static String getLastModified(Node jcrNode)
			throws ValueFormatException, PathNotFoundException, RepositoryException, ParseException {
		Date date = null;
		String dt = "";
		if (jcrNode.hasProperty(NewsConstants.PAGE_LAST_REPLICATED)) {
			String dateString = jcrNode.getProperty(NewsConstants.PAGE_LAST_REPLICATED).getString();

			DateFormat format = new SimpleDateFormat(JHINSConstants.DATE_FORMAT_YYYY_MM_DD);
			date = format.parse(dateString);
			DateFormat fmt = new SimpleDateFormat(NewsConstants.CUSTOM_DATE_FORMAT);
			dt = fmt.format(date);
			LOG.debug("date is " + dt);
		}
		return dt;

	}

	/**
	 * Method to fetch the recent articles based on Topic
	 * 
	 * @param slingRequest
	 * @param path
	 * @param topic
	 * @param items
	 * @return
	 * @throws RepositoryException
	 * @throws ParseException
	 */
	public static ArrayList<ArticleBean> retriveRelatedArticlesByTopic(SlingHttpServletRequest slingRequest,
			String path, String topic, String items, UserTO userTo) throws RepositoryException, ParseException {
		LOG.debug("Starting of retriveRelatedArticlesByTopic method");
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		ArticleBean articleBean = null;

		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("path", path);
		map.put("1_property", NewsConstants.CQ_TEMPLATE);
		map.put("1_property.value", NewsConstants.ARTICLE_TEMPLATE);
		map.put("type", NewsConstants.PAGE_TYPE);
		map.put("tagid", topic);
		// dont change this here. Here the requirement is to search tag value as well as its child tags.
		map.put("tagid.property", JHINSConstants.CQ_TAGS_PROPERTYNAME);
		map.put("orderby", NewsConstants.ORDER_BY);
		map.put("orderby.sort", NewsConstants.ODERBY_SORT);
		map.put("p.limit", items);
		// start of changes for user role
		getFilterForUserRole(map, userTo);
		// end of changes for user role

		JHPageHelper.logMap(map);

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (!searchRes.getHits().isEmpty()) {
			LOG.debug("searchRes.getHits() is not empty");
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				articleBean = new ArticleBean();
				articleBean = retriveArticleBean(queryPath, slingRequest.getResourceResolver());
				articlebeans.add(articleBean);
			}
		}
		LOG.debug("End of retriveRelatedArticlesByTopic method");
		return articlebeans;
	}

	/**
	 * Method to fetch the recent articles based on channel
	 *
	 * @param request
	 * @param path
	 * @param channel
	 * @param items
	 * 
	 *
	 * @return arraylist
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public static ArrayList<ArticleBean> retriveRelatedArticlesByChannel(SlingHttpServletRequest slingRequest,
			String path, String channel, String items, UserTO userTo) throws RepositoryException, ParseException {
		LOG.debug("Starting of retriveRelatedArticlesByChannel method");
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		LOG.debug("cHANNEL: " + channel);
		ArticleBean articleBean = null;
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(channel);
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);

		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", NewsConstants.PAGE_TYPE);
		map.put("path", path);
		map.put("1_property", NewsConstants.CQ_TEMPLATE);
		map.put("1_property.value", NewsConstants.ARTICLE_TEMPLATE);
		map.put("2_property", JHINSConstants.CQ_TAGS_PROPERTYNAME);
		map.put("2_property.value", tag.getTagID());
		/*
		 * map.put("tagid.property",JHINSConstants.CQ_TAGS_PROPERTYNAME);
		 * map.put("tagid", channel);
		 */
		map.put("orderby", NewsConstants.ORDER_BY);
		map.put("orderby.sort", NewsConstants.ODERBY_SORT);
		map.put("p.limit", items);
		// start of changes for user role
		getFilterForUserRole(map, userTo);
		// end of changes for user role

		LOG.debug("*****MAP FOR RELATED ARTICLE BY CHANNEL ****");
		JHPageHelper.logMap(map);
		LOG.debug("*****END**********");

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				articleBean = new ArticleBean();
				articleBean = retriveArticleBean(queryPath, slingRequest.getResourceResolver());
				articlebeans.add(articleBean);

			}
		}
		else {
			LOG.debug("No results for the selected channel" + channel);
		}
		LOG.debug("End of retriveRelatedArticlesByChannel method");
		return articlebeans;
	}

	/**
	 * This method retrieves the article bean list for a particular channel with
	 * pagination and Count per page.
	 * 
	 * @param slingRequest
	 * @param path
	 * @param channel
	 * @param items
	 * @param pageNo
	 * @return
	 * @throws RepositoryException
	 * @throws ParseException
	 */
	public static Map<String, Object> retriveRelatedArticlesByChannel(SlingHttpServletRequest slingRequest, String path,
			String channel, String items, String pageNo, UserTO userTo) throws RepositoryException, ParseException {

		LOG.debug("Start of method retriveRelatedArticlesByChannel");
		LOG.debug("Channel: " + channel);
		LOG.debug("path: " + path);
		LOG.debug("items count: " + items);
		LOG.debug("pageNo: " + pageNo);

		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(channel);
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		ArticleBean articleBean = null;

		int pagenumber = Integer.parseInt(pageNo);
		int startIndex = (Integer.parseInt(items)) * (pagenumber - 1);

		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", NewsConstants.PAGE_TYPE);
		map.put("path", path);
		map.put("1_property", NewsConstants.CQ_TEMPLATE);
		map.put("1_property.value", NewsConstants.ARTICLE_TEMPLATE);
		map.put("2_property", JHINSConstants.CQ_TAGS_PROPERTYNAME);
		map.put("2_property.value", tag.getTagID());
		// map.put("tagid.property",JHINSConstants.CQ_TAGS_PROPERTYNAME);
		// map.put("tagid", channel);
		map.put("orderby", NewsConstants.ORDER_BY);
		map.put("orderby.sort", NewsConstants.ODERBY_SORT);
		map.put("p.limit", items);
		// start of changes for user role
		getFilterForUserRole(map, userTo);
		// end of changes for user role

		LOG.debug("*****MAP FOR RELATED ARTICLE BY CHANNELS ****");
		JHPageHelper.logMap(map);
		LOG.debug("*****END**********");

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		query.setStart(startIndex);
		SearchResult searchRes = query.getResult();

		resultMap = getPaginationDetails(searchRes.getStartIndex(), searchRes.getTotalMatches(),
				Integer.parseInt(items), 5, Integer.parseInt(pageNo),slingRequest);
		LOG.debug("MAP ** Central Intellgence *** " + map );
		LOG.error("RESULT MAP **** " + resultMap);
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				articleBean = new ArticleBean();
				articleBean = retriveArticleBean(queryPath, slingRequest.getResourceResolver());
				articlebeans.add(articleBean);
			}
		} else {
			LOG.debug("No results for the selected channel" + channel);
		}
		resultMap.put(NewsConstants.PARAM_RESULT_BEAN_LIST, articlebeans);
		return resultMap;
	}

	/**
	 * Returns the pagination details like currentPage, pageCount, size and
	 * displaying x of y string in a map object
	 * 
	 * @param startIndex
	 * @param totalCnt
	 * @param paginationSize
	 * @param bucketCnt
	 * @param currentPageNo
	 * @param slingRequest 
	 * @return
	 */
	private static Map<String, Object> getPaginationDetails(long startIndex, long totalCnt, int paginationSize,
			int bucketCnt, int currentPageNo, SlingHttpServletRequest slingRequest) {

		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		long displayEnd = startIndex + paginationSize > totalCnt ? totalCnt : startIndex + paginationSize;
		long totalPages = 0;

		StringBuilder sb = new StringBuilder();
		sb.append(startIndex + 1);
		sb.append(NewsConstants.SYMBOL_HYPHEN);
		sb.append(displayEnd);
		sb.append(NewsConstants.STRING_OF);
		sb.append(totalCnt);

		if (totalCnt % (paginationSize) > 0) {
			totalPages = (totalCnt / (paginationSize)) + 1;
		} else {
			totalPages = totalCnt / (paginationSize);
		}
		resultMap = getPagination(resultMap, totalPages, currentPageNo, slingRequest );

		resultMap.put(NewsConstants.STRING_DISPLAYING, sb.toString());
		resultMap.put(NewsConstants.STRING_CURRENTPAGE, currentPageNo);
		resultMap.put(NewsConstants.STRING_PAGECOUNT, totalPages);
		resultMap.put(NewsConstants.STRING_SIZE, bucketCnt);

		return resultMap;

	}

	/**
	 * Method to fetch the recent articles based on channel and product
	 *
	 * @param request
	 * @param path
	 * @param channel
	 * @param items
	 * 
	 *
	 * @return arraylist
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public static ArrayList<ArticleBean> retriveRelatedArticlesByChannelAndProduct(SlingHttpServletRequest slingRequest,
			String path, String channel, String product, String items, UserTO userTo)
					throws RepositoryException, ParseException {
		LOG.debug("Starting of retriveRelatedArticlesByChannelAndProduct method");
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();

		ArticleBean articleBean = null;
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag channelTag = tagManager.resolve(channel);
		Tag productTag = tagManager.resolve(product);
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", NewsConstants.PAGE_TYPE);
		map.put("path", path);
		map.put("1_property", JHINSConstants.CQ_TAGS_PROPERTYNAME);
		map.put("1_property.value", channelTag.getTagID());
		map.put("2_property", JHINSConstants.CQ_TAGS_PROPERTYNAME);
		map.put("2_property.value", productTag.getTagID());
		/*
		 * map.put("1_tagid.property",JHINSConstants.CQ_TAGS_PROPERTYNAME);
		 * map.put("1_tagid", channel);
		 * map.put("2_tagid.property",JHINSConstants.CQ_TAGS_PROPERTYNAME);
		 * map.put("2_tagid", product);
		 */
		map.put("orderby", NewsConstants.ORDER_BY);
		map.put("orderby.sort", "desc");
		map.put("p.limit", items);
		// start of changes for user role
		getFilterForUserRole(map, userTo);
		// end of changes for user role

		LOG.debug("*****MAP FORRELATED ARTC CHANNEL AND PRODUCTS ****");
		JHPageHelper.logMap(map);
		LOG.debug("*****END**********");

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				articleBean = new ArticleBean();
				articleBean = retriveArticleBean(queryPath, slingRequest.getResourceResolver());
				articlebeans.add(articleBean);
			}
		}
		LOG.debug("End of retriveRelatedArticlesByChannelAndProduct method");
		return articlebeans;
	}

	/**
	 * Method to transfer details from list to json
	 *
	 * @param list
	 * 
	 * 
	 * 
	 *
	 * @return JsonObject
	 * @throws JSONException
	 */

	public static JSONObject transferNewsDetailstoJSONobj(List<ArticleBean> articleBeans) throws JSONException {
		LOG.debug("Starting of transferNewsDetailstoJSONobj method");

		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		ListIterator<ArticleBean> litr = articleBeans.listIterator();
		while (litr.hasNext()) {
			ArticleBean bean = (ArticleBean) litr.next();
			if (bean != null) {
				json = new JSONObject();
				json.put(NewsConstants.PARAM_CHANNEL, bean.getChannel());
				json.put(NewsConstants.PARAM_DATE, bean.getDate());
				json.put(NewsConstants.METADATA_FIRM, bean.getFirm());
				json.put(NewsConstants.PARAM_IMG_PATH, bean.getImagePath());
				json.put(NewsConstants.PARAM_PATH, bean.getPath());
				json.put(NewsConstants.PARAM_PRODUCT, bean.getProduct());
				json.put(NewsConstants.PARAM_STATE, bean.getState());
				json.put(NewsConstants.PARAM_TITLE, bean.getTitle());
				json.put(NewsConstants.PARAM_TOPIC, bean.getTopic());
				json.put(NewsConstants.PARAM_TYPE, bean.getType());
				json.put(NewsConstants.PARAM_DESCRIPTION, bean.getDescription());
			}
			jsonArray.put(json);

		}

		mainObj.put("list", jsonArray);
		LOG.debug("Final JSON generated is" + mainObj);
		LOG.debug("End of transferNewsDetailstoJSONobj method");
		return mainObj;

	}

	/**
	 * Converts the news datails tojson format. The json will have the news list
	 * as a json array. Apart from this, it also includes the currentPage,
	 * pageCount, size and displaing string.
	 * 
	 * @param resultMap
	 * @return
	 * @throws JSONException
	 */
	@SuppressWarnings("unchecked")
	public static JSONObject transferNewsDetailstoJSONobj(Map<String, Object> resultMap) throws JSONException {

		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject mainObj = new JSONObject();

		ArrayList<ArticleBean> articleBeans = (ArrayList<ArticleBean>) resultMap
				.get(NewsConstants.PARAM_RESULT_BEAN_LIST);

		ListIterator<ArticleBean> litr = articleBeans.listIterator();

		while (litr.hasNext()) {
			ArticleBean bean = (ArticleBean) litr.next();
			if (bean != null) {
				json = new JSONObject();
				json.put(NewsConstants.PARAM_CHANNEL, bean.getChannel());
				json.put(NewsConstants.PARAM_DATE, bean.getDate());
				json.put(NewsConstants.METADATA_FIRM, bean.getFirm());
				json.put(NewsConstants.PARAM_IMG_PATH, bean.getImagePath());
				json.put(NewsConstants.PARAM_PATH, bean.getPath());
				json.put(NewsConstants.PARAM_PRODUCT, bean.getProduct());
				json.put(NewsConstants.PARAM_STATE, bean.getState());
				json.put(NewsConstants.PARAM_TITLE, bean.getTitle());
				json.put(NewsConstants.PARAM_TOPIC, bean.getTopic());
				json.put(NewsConstants.PARAM_TYPE, bean.getType());
				json.put(NewsConstants.PARAM_DESCRIPTION, bean.getDescription());
			}
			jsonArray.put(json);

		}
		mainObj.put(NewsConstants.STRING_LIST, jsonArray);
		mainObj.put(NewsConstants.STRING_DISPLAYING, resultMap.get(NewsConstants.STRING_DISPLAYING));
		mainObj.put(NewsConstants.STRING_CURRENTPAGE, resultMap.get(NewsConstants.STRING_CURRENTPAGE));
		mainObj.put(NewsConstants.STRING_PAGECOUNT, resultMap.get(NewsConstants.STRING_PAGECOUNT));
		mainObj.put(NewsConstants.STRING_SIZE, resultMap.get(NewsConstants.STRING_SIZE));
		mainObj.put(NewsConstants.START, resultMap.get(NewsConstants.START));
		mainObj.put(NewsConstants.HASNEXT, resultMap.get(NewsConstants.HASNEXT));
		mainObj.put(NewsConstants.LASTURL, resultMap.get(NewsConstants.LASTURL));
		mainObj.put(NewsConstants.END, resultMap.get(NewsConstants.END));
		mainObj.put(NewsConstants.NEXT, resultMap.get(NewsConstants.NEXT));
		mainObj.put(NewsConstants.FIRST_URL, resultMap.get(NewsConstants.FIRST_URL));
		mainObj.put(NewsConstants.PREVIOUS, resultMap.get(NewsConstants.PREVIOUS));
		mainObj.put(NewsConstants.HAS_PREVIOUS,resultMap.get(NewsConstants.HAS_PREVIOUS));


		LOG.debug("Final JSON generated is" + mainObj);

		return mainObj;

	}

	/**
	 * Method to fetch the values from the bean
	 *
	 * @param path
	 * @param resolver
	 * 
	 *
	 * @return ArticleBean
	 * @throws PathNotFoundException
	 * @throws RepositoryException
	 * @throws ParseException
	 */

	public static ArticleBean retriveArticleBean(String path, ResourceResolver resourceResolver)
			throws PathNotFoundException, RepositoryException, ParseException {
		LOG.debug("Starting of retriveArticleBean method");
		Resource resource = resourceResolver.getResource(path);
		ArticleBean articleBean = new ArticleBean();

		if (resource != null) {
			Page page = resource.adaptTo(Page.class);


			if (page != null) {
				ValueMap imageProperties = page.getProperties(NewsConstants.IMAGE_NODE_PATH);
				if(null!=imageProperties){
					articleBean.setImagePath(imageProperties.get(NewsConstants.IMAGE_REFERENCE,String.class));
				}
				ValueMap properties = page.getProperties();
				if(null!=properties){
					articleBean.setDate(DateHelper.getLastModified(properties));
				}
				articleBean.setPath(resourceResolver.map(path));

				articleBean.setTitle(page.getTitle());
				Tag[] tags = page.getTags();
				for (Tag tag : tags) {
					String tagID = tag.getLocalTagID(); 
					// returns the tagid with out namespace
					if (tagID.startsWith(NewsConstants.PARAM_TYPE)) {
						articleBean.setType(tag.getTitle());
					} else if (tagID.startsWith(NewsConstants.PARAM_TOPIC)) {
						articleBean.setTopic(tag.getTitle());
					} else if (tagID.startsWith(NewsConstants.PARAM_STATE)) {
						articleBean.setState(tag.getTitle());
					} else if (tagID.startsWith(NewsConstants.PARAM_CHANNEL)) {
						articleBean.setChannel(tag.getTitle());
					}else if(tagID.startsWith(NewsConstants.PARAM_FIRM)){
						articleBean.setFirm(tag.getTitle());
					}else if(tagID.startsWith(NewsConstants.PARAM_PRODUCT)){
						articleBean.setProduct(tag.getTitle());
					}					

				}
				articleBean.setDescription(
						page.getDescription() != null ? page.getDescription() : JHINSConstants.EMPTY_STRING);
			}
		}
		LOG.debug("End of retriveArticleBean method");
		return articleBean;
	}

	public static Map<String, String> getFilterForUserRole(Map<String, String> map, UserTO userTo) {
		LOG.debug("Starting of getFilterForUserRole method");
		
		if (null != userTo && null!=userTo.getFirmID()) {
			

			map.put("10_group.1_property", NewsConstants.CQ_TAGS__PROPERTYNAME);
			map.put("10_group.1_property.value",userTo.getFirmID());			

		}
		LOG.debug("End of getFilterForUserRole method");
		return map;
	}

	private static void addChannelsFilter(Map<String, String> map, int i, String[] channels,
			SlingHttpServletRequest slingRequest) {
		int j = 0;
		boolean flag = false;
		TagManager tagManager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		for (String channel : channels) {
			if (!channel.trim().isEmpty()) {
				flag = true;
				Tag channelTag = tagManager.resolve(channel);
				if (channelTag != null) {
					j++;
					map.put(i + "_group." + j + "_property", "@jcr:content/cq:tags");
					map.put(i + "_group." + j + "_property.value", channelTag.getTagID());
				}
			}
		}
		if (flag) {
			map.put(i + "_group.p.or", "true");
		}

	}

	/**
	 * Returns the search result for the topic searching
	 * 
	 * @param slingRequest
	 * @param limit
	 * @param channels
	 * @param userTo
	 * @param pageNo
	 * @param topic
	 * @return
	 */
	public static Map<String, Object> getTopicNews(SlingHttpServletRequest slingRequest, String limit,
			String[] channels, UserTO userTo, String pageNo, String topic) {

		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		ArticleBean articleBean = null;

		int pagenumber = Integer.parseInt(pageNo);
		int startIndex = (Integer.parseInt(limit)) * (pagenumber - 1);
		// String firm=userTo.getFirmID().toString();

		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);

		Map<String, String> map = new HashMap<String, String>();
		map.put("type", NewsConstants.PAGE_TYPE);
		map.put("1_group.1_property", NewsConstants.CQ_TEMPLATE);
		map.put("1_group.1_property.value", NewsConstants.ARTICLE_TEMPLATE);
		if (topic != null) {
			map.put("1_group.2_property", NewsConstants.JCR_TOPIC);
			map.put("1_group.2_property.value", topic + "%");
			map.put("1_group.2_property.operation", "like");
		}
		map.put("orderby", NewsConstants.ORDER_BY);
		map.put("orderby.sort", NewsConstants.ODERBY_SORT);
		map.put("p.limit", limit);
		// start of changes for user role
		getFilterForUserRole(map, userTo); 
		// end of changes for user role

		LOG.debug("*****MAP FOR "+ topic +" NEWS ****");
		JHPageHelper.logMap(map);
		LOG.debug("*****END**********");

		if (channels != null && channels.length > 0) {
			addChannelsFilter(map, 2, channels, slingRequest);
		}
		LOG.debug("MAP in All News/ Life News/ LTC News" + map);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		query.setStart(startIndex);
		SearchResult searchRes = query.getResult();
		resultMap = getPaginationDetails(searchRes.getStartIndex(), searchRes.getTotalMatches(),
				Integer.parseInt(limit), 10, Integer.parseInt(pageNo), slingRequest);
		try {
			if (!searchRes.getHits().isEmpty()) {
				for (Hit hit : searchRes.getHits()) {
					String queryPath = hit.getPath();
					articleBean = new ArticleBean();
					articleBean = retriveArticleBean(queryPath, slingRequest.getResourceResolver());
					articlebeans.add(articleBean);
				}

			} else {
				LOG.info("No results for the selected channel");
			}
		} catch (RepositoryException e) {
			LOG.error("Repository Exception" , e);
		} catch (ParseException e) {
			LOG.error("Parse Exception" , e);
		}
		resultMap.put(NewsConstants.PARAM_RESULT_BEAN_LIST, articlebeans);
		return resultMap;
	}

	public static HashMap<String, Object> getPagination(HashMap<String, Object> resultMap, long numberOfPages, long page,
			SlingHttpServletRequest request) {
		boolean hasPrevious;
		try {
			hasPrevious = hasPrevious((int) page);

			boolean hasNext = hasNext(numberOfPages, page);
			if (numberOfPages > 4) {
				if (hasPrevious && hasNext) {
					if ((int) page - 2 >= 1) {
						resultMap.put("hasPrevious", hasPrevious);
						resultMap.put("hasNext", hasNext);
						resultMap.put("end", page + 1);
						resultMap.put("start", page - 1);
						resultMap.put("firstURL", 1);
						resultMap.put("previous", (int) page - 2);
						resultMap.put("next", (int) page + 2);
						resultMap.put("lastURL", (int) numberOfPages);
					} else if ((int) page - 1 == 1) {
						resultMap.put("end", 4);
						resultMap.put("start", 1);
						resultMap.put("hasNext", hasNext);
						resultMap.put("next", 5);
						resultMap.put("lastURL", (int) numberOfPages);
					}
				} else if (!hasPrevious && hasNext) {
					if (((int) page - 1) == 0) {
						resultMap.put("end", 4);
						resultMap.put("start", 1);
						resultMap.put("hasNext", hasNext);
						resultMap.put("next", 5);
						resultMap.put("lastURL", (int) numberOfPages);
					}
				} else if (!hasNext && hasPrevious) {
					resultMap.put("end", numberOfPages);
					resultMap.put("start", numberOfPages - 2);
					resultMap.put("hasPrevious", hasPrevious);
					resultMap.put("previous", (int) numberOfPages - 3);
					resultMap.put("firstURL", 1);
				}
			}else{
				resultMap.put("end", numberOfPages);
				resultMap.put("start", 1);
				resultMap.put("hasPrevious",false);
				resultMap.put("hasNext",false);
			}
		} catch (RepositoryException e) {
			LOG.error("Repository Exception ", e);
		}
		return resultMap;
	}


	/**
	 * Check if there is previous page
	 * @param page
	 * @return
	 * @throws RepositoryException
	 */
	public static boolean hasPrevious(int page) throws RepositoryException {
		//ResultPage previous = result.getPreviousPage();
		return (page - 1) > 0 ? true : false ;	

	}

	/**
	 * Check if there is next page
	 * @param numberOfPages
	 * @param page
	 * @return
	 */
	public static boolean hasNext(long numberOfPages, long page) {
		return ((int)page + 1) < numberOfPages ? true : false ;	
	}


}
