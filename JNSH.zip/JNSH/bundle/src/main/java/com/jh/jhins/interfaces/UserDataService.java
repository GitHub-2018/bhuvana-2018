package com.jh.jhins.interfaces;

public interface UserDataService {
	public String getProperty(final String property);
}
