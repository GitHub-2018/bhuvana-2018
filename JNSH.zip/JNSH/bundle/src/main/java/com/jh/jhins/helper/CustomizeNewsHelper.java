package com.jh.jhins.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomizeNewsHelper {

	private static final Logger LOG = LoggerFactory.getLogger(CustomizeNewsHelper.class);
	ArrayList<HashMap<String, String>> lifeArrayList;
	ArrayList<HashMap<String, String>> ltcArrayList;
	JSONObject finalJSONObj;
	JSONArray jsonArray;
	JSONObject finalJson;
	JSONArray finalJsonArr;

	/**
	 * Method to get the custiomize news popup dialog values
	 *
	 * @param slingRequest
	 * @param String
	 * 
	 * @return JSONArray
	 */

	public JSONArray getCustomizeNewsJSON(String currentStylePath, SlingHttpServletRequest slingRequest) {
		String[] lifevalues = { "lifecategory", "lifegroupHeading" };
		String[] ltcvalues = { "ltccategory", "ltcgroupHeading" };
		JSONObject lifeJSONObj = new JSONObject();
		JSONObject ltcJSONObj = new JSONObject();
		try {

			// get the life tab values
			lifeArrayList = getMultiCompositeValuesArrayList(currentStylePath, "lifecustomvals", lifevalues,
					slingRequest);
			JSONArray lifeJsonArr = insertListsToJSONArray(lifeArrayList);
			lifeJSONObj.put("tabHeading", "life");
			lifeJSONObj.put("group", lifeJsonArr);

			// get the ltc tab values
			ltcArrayList = getMultiCompositeValuesArrayList(currentStylePath, "ltccustomvals", ltcvalues, slingRequest);
			JSONArray ltcJsonArr = insertListsToJSONArray(ltcArrayList);
			ltcJSONObj.put("tabHeading", "ltc");
			ltcJSONObj.put("group", ltcJsonArr);

			finalJsonArr = new JSONArray();
			finalJsonArr.put(lifeJSONObj);
			finalJsonArr.put(ltcJSONObj);

			LOG.info(" FinalJsonArr " + finalJsonArr);

		} catch (JSONException e) {
			LOG.error("Exception occured " + e);
		}
		return finalJsonArr;
	}

	// Inserting list of dialog values in to the JSON array
	private JSONArray insertListsToJSONArray(ArrayList<HashMap<String, String>> valArrayList) {
		JSONObject jsonObj = null;
		if (valArrayList != null) {
			ListIterator<HashMap<String, String>> litr = valArrayList.listIterator();
			jsonArray = new JSONArray();
			while (litr.hasNext()) {
				jsonObj = new JSONObject();
				HashMap<String, String> map = litr.next();
				for (Map.Entry<String, String> entry : map.entrySet()) {
					try {
						if (entry.getValue() != null || entry.getKey() != null) {
							String keyVal = entry.getKey().toString();
							String valvalue = entry.getValue().toString();
							jsonObj.put(keyVal, valvalue);
						}
					} catch (JSONException e) {
						LOG.error("Exception occured " + e);
					}
				}
				jsonArray.put(jsonObj);
			}
		} else {
			LOG.info("valArrayList is null");
		}

		LOG.info("final jsonArray" + jsonArray);
		return jsonArray;
	}

	/**Getting the multicomposite values
	 *
	 * @param path
	 * @param nodename
	 * @param propertyNames
	 * @param slingRequest
	 * @return
	 */
	public ArrayList<HashMap<String, String>> getMultiCompositeValuesArrayList(String path, String nodename,
			String[] propertyNames, SlingHttpServletRequest slingRequest) {
		if (null != path && null != nodename && null != propertyNames) {
			try {
				final ArrayList<HashMap<String, String>> fieldList = new ArrayList<HashMap<String, String>>();
				final Resource resource = slingRequest.getResourceResolver().getResource(path + "/" + nodename);
				if (null != resource && null != resource.listChildren()) {
					Iterator<Resource> iter = resource.listChildren();
					while (iter.hasNext()) {
						Resource childResource = (Resource) iter.next();
						ValueMap properties = ResourceUtil.getValueMap(childResource);
						HashMap<String, String> map = new HashMap<String, String>();
						for (final String propertyName : propertyNames) {
							if (properties.get(propertyName) != null) {
								if (propertyName.equalsIgnoreCase("lifecategory")
										|| propertyName.equalsIgnoreCase("ltccategory")) {
									String[] tagIDArrays = (String[]) properties.get(propertyName);
									LOG.info("categories>>>>" + tagIDArrays);

									/**String[] tagIDArrays = new
											String[categories.length]; for (int i =
											0; i <categories.length; i++) { String
												categoryPath = categories[i]; String
												LOG.info(" categoryID" +
														categoryID); 
												tagIDArrays[i] = categoryID;
											}
											**/
									LOG.info(" categoryID" + tagIDArrays);
											StringBuilder builder = new StringBuilder(); 
											for (int i=0;i<tagIDArrays.length; i++) {
												builder.append(tagIDArrays[i]);
												if(i<tagIDArrays.length-1){
													builder.append(","); 
													} }
											String tagArray= builder.toString(); 
											LOG.info("tagArray"
													+ tagArray);

											map.put("category", tagArray);
								} 
								else {
									LOG.info("Inside else Loop" + propertyName);
									map.put("groupHeading", properties.get(propertyName, String.class));
								}
							}

						}

						fieldList.add(map);
						LOG.info("fieldList"+fieldList);
					}
					return fieldList;
				} else {
					LOG.error(nodename + " is not available in the path" + path);
					return null;
				}
			} catch (final Exception e) {
				LOG.error("exception occured while retreiving compositevalues", e);
				return null;
			}
		}
		return null;
	}

}
