package com.jh.jhins.bean;

public class AgentSearchBean {

	private String agentCode;
	private String userId;
	private String policynumber;
	private String plcnumber;
	private String userRole;
	private String hostsystem;
	private String emailaddress;
	private String userName;
	
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPolicynumber() {
		return policynumber;
	}
	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getPlcnumber() {
		return plcnumber;
	}
	public void setPlcnumber(String plcnumber) {
		this.plcnumber = plcnumber;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getHostsystem() {
		return hostsystem;
	}
	public void setHostsystem(String hostsystem) {
		this.hostsystem = hostsystem;
	}
	public String getEmailaddress() {
		return emailaddress;
	}
	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	

}
