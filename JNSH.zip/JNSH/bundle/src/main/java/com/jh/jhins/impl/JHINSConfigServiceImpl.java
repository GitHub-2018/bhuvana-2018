package com.jh.jhins.impl;

import java.io.IOException;
import java.util.Dictionary;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.interfaces.JHINSConfigService;

import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

@Service
@Component(immediate = true, metatype = true, name = "JHINSConfigServiceImpl", description = "Programatically get  properties of OSGi configurations.")
public class JHINSConfigServiceImpl implements JHINSConfigService {

	/** The service to get OSGi configs */
	@Reference
	private ConfigurationAdmin configAdmin;

	private static final Logger LOG = LoggerFactory
			.getLogger(JHINSConfigServiceImpl.class);
	
	/**
     * Get the value of an OSGi configuration string property for a given PID.
     *
     *
     * @param property The property of the config to retrieve    
     * @return The property value
     */

	public String getConfigProperty(final String property) {
		String propertyValue ="" ;
		try {
			Configuration conf = configAdmin.getConfiguration(JHINSConstants.CONFIG_PID);
			@SuppressWarnings(JHINSConstants.UNCHECKED)
			Dictionary<String, Object> properties = conf.getProperties();
			if (properties != null) {
				if (!properties.isEmpty()) {
					if (properties.get(property) != null) {
						propertyValue = properties.get(property).toString();
					}
				}
				
			}
		} catch (IOException e) {
			LOG.error("IOException",e);
		}
		return propertyValue;
		
	}

}
