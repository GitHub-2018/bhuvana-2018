package com.jh.jhins.impl;

import javax.jcr.Node;
import javax.jcr.NodeIterator;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolver;

import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.interfaces.JHINSGetAllFundDetailsService;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Service
public class JHINSGetAllFundDetailsServiceImpl implements JHINSGetAllFundDetailsService {

	public JSONObject getAllFundDetails(ResourceResolver resourceResolver) {
		
			final Logger logger = LoggerFactory
			.getLogger(JHINSGetAllFundDetailsServiceImpl.class);		
			
			JSONArray jsonArray= new JSONArray();
			JSONObject fundArrayObj= new JSONObject();
		try {			
		
			Node parentNode = resourceResolver.getResource(GOOMConstants.FUND_PROFILE_BASE_PATH)
					.adaptTo(Node.class);
			NodeIterator nodeIterator = parentNode.getNodes();
			while (nodeIterator.hasNext()) {
				JSONObject fundObj= new JSONObject();
				String fundCode="";
				String fundTitle="";
				Node node = nodeIterator.nextNode();
				
				logger.info("Node Name-->" + node.getName());
				
				if(!node.getName().equalsIgnoreCase(JHINSConstants.JCR_CONTENT)){

					String fundDetailsPath = node.getPath()
							+ "/jcr:content/par/fundprofilecomp";

					logger.info("Fund Details Path-->" + fundDetailsPath);

					Node fundDetailsNode = resourceResolver.getResource(
							fundDetailsPath).adaptTo(Node.class);

					if (fundDetailsNode != null) {

						fundCode=fundDetailsNode.getProperty(GOOMConstants.FUND_CODE).getValue().toString();
						logger.info("fundCode is-->" + fundCode);					
						fundTitle=fundDetailsNode.getProperty(GOOMConstants.FUND_TITLE).getValue().toString();
						logger.info("fundTitle is-->" + fundTitle);							
						fundObj.put("FundCode", fundCode);
						fundObj.put("FundName", fundTitle);						
						jsonArray.put(fundObj);
						

					}
				}

			}

			fundArrayObj.put("Funds", jsonArray);
		} catch (Exception e) {
			logger.info(
					"Can't display the Fund Names. An error occured !");
			logger.error(e.getMessage());
		}
		return fundArrayObj;
	}


}
