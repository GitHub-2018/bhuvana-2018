package com.jh.jhins.servlet;

import java.io.IOException;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.*;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.granite.ui.components.Config;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.EmptyDataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.tagging.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import java.text.Collator;



@SlingServlet( paths = "/bin/sling/dynamicdropdown",metatype=true, methods = HttpConstants.METHOD_GET )
@Properties({ @Property(name = "service.description", value = "Dynamic DropDown Servlet"),
@Property(name = "service.vendor", value = "JHINS")})
public class DynamicDropdown extends SlingAllMethodsServlet { 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(DynamicDropdown.class);
	
	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException  {
		LOG.info("Start Dynamic DropDown doGet method");
		
		final ResourceResolver resourceResolver = request.getResourceResolver();
		Config dsCfg = new Config(request.getResource().getChild("datasource"));
		String path = dsCfg.get("path");
		String dialogVal = dsCfg.get("value");
		LOG.info("dialogVal"+dialogVal);
	    Resource listResult = resourceResolver.getResource(path);
	    
	    
	    if (ResourceUtil.isNonExistingResource(listResult)) {
	        request.setAttribute(DataSource.class.getName(), EmptyDataSource.instance());
	        return;
	    }

	    List<KeyValue> list = new ArrayList<KeyValue>();
	    
	    if (dsCfg.get("addNone", false)) {
	    	list.add(new KeyValue("", ""));
	    }

	    for (Iterator<Resource> it = listResult.listChildren(); it.hasNext();) {
	        Resource resource = it.next();
	        ValueMap vm = ResourceUtil.getValueMap(resource);
	        
	        String key = vm.get("jcr:title", resource.getName());
	        String value;
	        TagManager tagManager = request.getResourceResolver().adaptTo(TagManager.class);
	        if(dialogVal.equalsIgnoreCase("name")){
	        value = resource.getName();
	        list.add(new KeyValue(key, value));
	        }
	        else if(dialogVal.equalsIgnoreCase("path")){
	        LOG.info("inside path***");
	        value = resource.getPath();
	        list.add(new KeyValue(key, value));
	        if (tagManager != null) {
				Tag tag = tagManager.resolve(resource.getPath());
				LOG.info("TAG BEAN DETAILS***" + tag.getTagID() + tag.getName());
				if(tag.listChildren().hasNext()) {
					Iterator<Tag> tagIter = tag.listChildren();
					while (tagIter.hasNext()) {
						Tag childTag = tagIter.next();
						LOG.info("value" + childTag.getPath());
						list.add(new KeyValue(childTag.getTitle(), childTag.getPath()));
						LOG.info("childlist" + list);
					}
				}
			}
	        }
	        else{
	        	value = vm.get("jcr:title", resource.getName());
	        	LOG.info("inside else $$"+value);
	        	list.add(new KeyValue(key, value));
	        	if (tagManager != null) {
					Tag tag = tagManager.resolve(resource.getPath());
					LOG.info("TAG BEAN DETAILS***" + tag.getTagID() + tag.getName());
					if(tag.listChildren().hasNext()) {
						Iterator<Tag> tagIter = tag.listChildren();
						while (tagIter.hasNext()) {
							Tag childTag = tagIter.next();
							list.add(new KeyValue(childTag.getTitle(), childTag.getTitle()));
							LOG.info("childlist" + list);
						}
					}
				}
	        	
	        }
	        //LOG.info("value$$"+value);
	        
	        //list.add(new KeyValue(key, value));
	    }
	    
	    final Collator collator = Collator.getInstance(request.getLocale());

	    Collections.sort(list, new Comparator<KeyValue>() {
	        public int compare(KeyValue o1, KeyValue o2) {
	            return collator.compare(o1.value, o2.value);
	        }
	    });

	    @SuppressWarnings("unchecked")
	    DataSource ds = new SimpleDataSource(new TransformIterator(list.iterator(), new Transformer() {
			
			public Object transform(Object input) {
				try {
	                KeyValue keyValue = (KeyValue) input;

	                ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
	                vm.put("text", keyValue.key);
	                vm.put("value", keyValue.value);

	                return new ValueMapResource(resourceResolver, new ResourceMetadata(), "nt:unstructured", vm);
	            } catch (Exception e) {
	                throw new RuntimeException(e);
	            }
			}
		}));
	    request.setAttribute(DataSource.class.getName(), ds);
	}
}
 class KeyValue {
    String key;
    String value;
    
    public KeyValue(String key, String value) {
        this.key = key;
        this.value = value;
    }
}''