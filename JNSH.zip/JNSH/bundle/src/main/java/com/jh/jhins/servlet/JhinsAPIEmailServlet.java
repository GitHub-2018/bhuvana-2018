package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Dictionary;
import java.util.Enumeration;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.xss.XSSAPI;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.jh.jhins.bean.HeaderBean;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.constants.EmailServiceConstants;
import com.jh.jhins.constants.JHINSConstants;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JHINS Email Us Servlet"),
		@Property(name = "sling.servlet.paths", value = {"/bin/sling/JHINSAPIEmail"}),
		@Property(name = "service.vendor", value = "JHINS"),
		@Property(name = "admin.email.id", value = "admin@manulife.com"),
		@Property(name = "admin.email.id.life", value = "admin@manulife.com"),
		@Property(name = "admin.email.id.ltc", value = "JHSSLTCE-Commerce@jhancock.com"),
		@Property(name = "admin.email.id.feedback", value = "Feedback@jhancock.com"),
		@Property(name = "jhins.email.api.url", value = "https://jhtestdigitalapi.azure-api.net/notification/api/Mail"),
		@Property(name = "jhins.header.key", value = "Ocp-Apim-Subscription-Key"),
		@Property(name = "jhins.header.value", value = "d3d058e659f0453aafb78ad22b8512cd"),
		@Property(name = "jhins.header.appid", value = "AppId"),
		@Property(name = "jhins.header.appid.value", value = "27096000"),
		@Property(name = "emailus.form.templateid", value = "f3833f37-18be-470c-b324-575ec4303e0d"),
		@Property(name = "feedback.form.templateid", value = "872eefa3-9861-4598-ad9a-fca60af5e830"),
		@Property(name = "sling.servlet.methods", value = "POST", propertyPrivate = true)})

public class JhinsAPIEmailServlet extends SlingAllMethodsServlet {
	
	private static Logger LOG = LoggerFactory.getLogger(JhinsAPIEmailServlet.class);
	private static final long serialVersionUID = 1L;
	
	
	/* Method to fetch the sling properties
	 *
	 */

	private static Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		properties = context.getProperties();
	}
	
	/**
	 * doGet method
	 */

	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * doPost uses the request and response and send Email to the user
	 */
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException {
		try {
			
			LOG.info("doPost::::");
			response.setContentType(NewsConstants.CONTENT_TYPE);
			request.setCharacterEncoding("UTF-8");
			XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
			String redirectPath = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.REDIRECT_PATH));
			if (redirectPath != null && redirectPath.startsWith("/content")) {
				// do nothing
			} else {
				redirectPath = "/content/PRDJHINS/en_US/logged-in/errors/404";
			}
			String firstN = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.FIRST_NAME));
			String date = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.DATE));
			String toEmailAddress = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.EMAIL_ADDRESS));
			String insuredN = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.INSURED_NAME));
			String firmN = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.FIRM_NAME));
			String comments = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.COMMENTS));
			String phone1 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_1));
			String phone2 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_2));
			String phone3 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_3));
			String phone4 = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.PHONE_4));
			String telePhone = null;
			if (phone4 != null && !phone4.isEmpty()) {
				telePhone = phone1 + "-" + phone2 + "-" + phone3 + "-" + phone4;
			} else {
				telePhone = phone1 + "-" + phone2 + "-" + phone3;
			}

			String iamASelected = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.IAM_A));
			String categorySelected = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.CATEGORY));
			String subject = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.SUBJECT));
			String formType = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.FORM_TYPE));
			String domain = xssAPI.filterHTML(request.getParameter(EmailServiceConstants.DOMAIN));
			
			/** Setting template IDs**/
			String templateId = properties.get("emailus.form.templateid");
			if (formType.equalsIgnoreCase(EmailServiceConstants.EMAIL_US_FORM)) {
				templateId = properties.get("emailus.form.templateid");
			} else {
				templateId = properties.get("feedback.form.templateid");
			}
			LOG.info("templateId::::" + templateId);
			
			
			/** Setting From  Email Address**/
			String fromAddress = properties.get(JHINSConstants.ADMIN_EMAIL_ID);
			if (EmailServiceConstants.EMAIL_US_FORM.equalsIgnoreCase(formType)) {
				subject="Email Us";
				if (domain != null) {
					if (domain.equalsIgnoreCase("life")) {
						fromAddress = properties.get(JHINSConstants.LIFE_EMAIL_ID);
					} else if (domain.equalsIgnoreCase("ltc")) {
						fromAddress = properties.get(JHINSConstants.LTC_EMAIL_ID);
					} else {
						fromAddress = properties.get(JHINSConstants.ADMIN_EMAIL_ID);
					}
				}
			}
			
			/** Setting From  Email Subject**/
			if (EmailServiceConstants.FEED_BACK_FORM.equalsIgnoreCase(formType) && subject != null) {
				fromAddress = properties.get(JHINSConstants.FEEDBACK_EMAIL_ID);
			}
			LOG.info("fromAddress::::" + fromAddress);
			/**Setting from and to mail address to JSON**/
			JSONObject fromMails = new JSONObject();
			fromMails.put("name","admin");
			fromMails.put(JHINSConstants.EMAIL,fromAddress);
			JSONObject toMails = new JSONObject();
			JSONArray toMailsArray = new JSONArray();
			toMails.put("name",firstN);
			toMails.put(JHINSConstants.EMAIL,toEmailAddress);
			toMailsArray.put(toMails);
			LOG.info("toMails::::" + toMails);

			
			/** Setting Header Values **/
			HeaderBean headerBean = new HeaderBean();
			headerBean.setKey(properties.get(JHINSConstants.HEADER_KEY));
			headerBean.setValue(properties.get(JHINSConstants.HEADER_VALUE));
			headerBean.setUrl(properties.get(JHINSConstants.EMAIL_API_URL));
			LOG.info("headerBean::::" + headerBean);
			
			
			/**Adding Email Params to JSON array**/
			JSONArray SubstitutionsArr = new JSONArray();
			Enumeration<String> params = request.getParameterNames();
			while (params.hasMoreElements()) {
				JSONObject jsonObject = new JSONObject();
				String param = params.nextElement();
				String value = xssAPI.filterHTML(request.getParameter(param));
				jsonObject.put("name", param);
				jsonObject.put(JHINSConstants.VALUE, value);
				SubstitutionsArr.put(jsonObject);
			}
			JSONObject phnObj = new JSONObject();
			phnObj.put("Name", "Telephone");
			phnObj.put("Value", telePhone);
			SubstitutionsArr.put(phnObj);
			LOG.info("SubstitutionsArr::::" + SubstitutionsArr);
			
			
			/**Adding Params to JSON Object**/
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(properties.get(JHINSConstants.HEADER_APPID), properties.get(JHINSConstants.HEADER_APPID_VALUE));
			jsonObj.put(JHINSConstants.TEMPLATEID,templateId);
			jsonObj.put(JHINSConstants.FROM, fromMails);
			jsonObj.put(JHINSConstants.TO, toMailsArray);
			jsonObj.put(JHINSConstants.SUBJECT, subject);
			jsonObj.put(JHINSConstants.SUBSTITUTIONS, SubstitutionsArr);
			LOG.info("JSONOBJ::::" + jsonObj);
			
			StringEntity input = new StringEntity(jsonObj.toString());
			input.setContentType(JHINSConstants.APPLICATION_JSON);
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(headerBean.getUrl());
			
			
			postRequest.setEntity(input);
			postRequest.addHeader(headerBean.getKey(), headerBean.getValue());
			postRequest.addHeader(JHINSConstants.CONTENT_TYPE,JHINSConstants.APPLICATION_JSON);

			CloseableHttpResponse httpResponse = httpClient.execute(postRequest);
			LOG.debug("httpResponse code::::" + httpResponse);
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				int statusCode = httpResponse.getStatusLine().getStatusCode();
				LOG.debug("Response code::::" + statusCode);
				response.sendRedirect(redirectPath + ".html");
			} else {
				String finalURL = request.getResourceResolver().map(redirectPath) + ".html?" + "date=" + date
						+ "&first_Name=" + firstN + "&email=" + toEmailAddress + "&insured_name=" + insuredN
						+ "&category=" + categorySelected + "&form=" + formType + "&phone_num=" + telePhone
						+ "&am_a_selected=" + iamASelected + "&subject=" + subject + "&firm=" + firmN + "&comments="
						+ comments;
				response.sendRedirect(finalURL);
			}
			httpClient.getConnectionManager().shutdown();
		} catch (JSONException e) {
			LOG.info("JSONException::::" + e);
		} catch (UnsupportedEncodingException e) {
			LOG.info("UnsupportedEncodingException::::" + e);
		} catch (Exception ex) {
			LOG.error("Error sending mail::::", ex);
		}
	}
}