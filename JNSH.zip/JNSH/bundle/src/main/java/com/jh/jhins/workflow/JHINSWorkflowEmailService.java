package com.jh.jhins.workflow;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.HistoryItem;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.jh.jhins.bean.HeaderBean;
import com.jh.jhins.constants.JHINSConstants;


@Component(immediate = true)
@Service
@Properties({ @Property(name = WorkflowConstants.SERVICE_DESCRIPTION, value = "Process for Jh Workflow EmailService"),
	@Property(name = WorkflowConstants.SERVICE_VENDOR, value = "JHINS"),
	@Property(name = WorkflowConstants.HOST_ID, value = "localhost:4504"),
	@Property(name = WorkflowConstants.PROCESS_LABEL, value = "JHINS Workflow Email Service") })

public class JHINSWorkflowEmailService implements WorkflowProcess {
	@Reference
	ResourceResolverFactory resolverFactory;

	// Reference for activating the sling property
	private Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		properties = context.getProperties();
	}

	private static final Logger LOG = LoggerFactory.getLogger(JHINSWorkflowEmailService.class);

	/**
	 * Workflow Execute Method to send the mail for the given details in process
	 * arguments
	 * 
	 */
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
			throws WorkflowException {
		WorkflowEmailHelper workflowEmailHelper = new WorkflowEmailHelper();
		ResourceResolver resourceResolver = null;
		try {

			WorkflowData workflowData = workItem.getWorkflowData();
			String payloadPath = workflowData.getPayload().toString();

			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "JHINSService");
			resourceResolver = resolverFactory.getServiceResourceResolver(param);

			// resourceResolver =
			// resolverFactory.getAdministrativeResourceResolver(null);
			LOG.debug("Resource Resolver " + resourceResolver);
			if (workflowData.getPayloadType().equals(WorkflowConstants.TYPE_JCR_PATH)) {
				String previousComment = "";
				List<HistoryItem> history = workflowSession.getHistory(workItem.getWorkflow());
				if (history != null && history.get(history.size() - 1).getWorkItem().getMetaDataMap()
						.get(WorkflowConstants.WORKFLOW_COMMENTS) != null) {
					previousComment = history.get(history.size() - 1).getWorkItem().getMetaDataMap()
							.get(WorkflowConstants.WORKFLOW_COMMENTS).toString();
				}
				String templateID = workflowEmailHelper.getProcessArgValues(WorkflowConstants.TEMPLATE_ID, metaDataMap);
				String principalParticipiant = workflowEmailHelper.getProcessArgValues(WorkflowConstants.SENDTO,
						metaDataMap);
				String ccRecipient = workflowEmailHelper.getProcessArgValues(WorkflowConstants.EMAIL_CC_RECIPIENT,
						metaDataMap);
				Map<String, String> emailRecipients = workflowEmailHelper.getEmailAddrsFromUserPath(resourceResolver,
						principalParticipiant);
				LOG.info("emailRecipients :::::::" + emailRecipients);
				String hostId = properties.get(WorkflowConstants.HOST_ID);
				String pageUrl = WorkflowConstants.HTTP + "://" + hostId + payloadPath + "." + WorkflowConstants.HTML;
				Map<String, String> emailParams = new HashMap<String, String>();
				emailParams.put(WorkflowConstants.EMAIL_CC_RECIPIENT, ccRecipient);
				emailParams.put(WorkflowConstants.EMAIL_MESSAGE, payloadPath);
				emailParams.put(WorkflowConstants.WORKFLOW_COMMENTS, previousComment);
				emailParams.put(WorkflowConstants.EMAIL_PAGE_URL, pageUrl);
				LOG.info("emailTemplate:::::::" + templateID);
				emailParams.put(WorkflowConstants.EMAIL_PAGE_URL, pageUrl);
				sendEmail(templateID, emailRecipients, pageUrl,previousComment);
			}

		} catch (LoginException e) {
			LOG.error("LoginException occurred in service", e);
		} finally {
			if (resourceResolver != null) {
				resourceResolver.close();
			}
		}
	}

	/** Send Email Method **/
	public String sendEmail(String TemplateID, Map<String, String> emailRecipients, String pageUrl,
			String comments) {
		WorkflowEmailHelper workflowEmailHelper = new WorkflowEmailHelper();
		/** Setting From Email Address **/
		String fromAddress = properties.get("admin.email.id");
		try {
			/** Setting from and to mail address to JSON **/
			JSONObject fromMails = new JSONObject();
			fromMails.put("name", "admin");
			fromMails.put(JHINSConstants.EMAIL, fromAddress);
			JSONArray toMailsArray = new JSONArray();
			Iterator<Map.Entry<String, String>> itr = emailRecipients.entrySet().iterator();
			while (itr.hasNext()) {
				Map.Entry<String, String> entry = itr.next();
				JSONObject emailJSON = new JSONObject();
				LOG.info("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				emailJSON.put("name", entry.getKey());
				emailJSON.put(JHINSConstants.EMAIL, entry.getValue());
				toMailsArray.put(emailJSON);
				LOG.info("toMailsArray::::" + toMailsArray);
			}
			LOG.info("toMailsFinal Array:" + toMailsArray);

			/** Setting Header Values **/
			HeaderBean headerBean = new HeaderBean();
			headerBean.setKey(properties.get(JHINSConstants.HEADER_KEY));
			headerBean.setValue(properties.get(JHINSConstants.HEADER_VALUE));
			headerBean.setUrl(properties.get(JHINSConstants.EMAIL_API_URL));
			

			/** Adding Email Params to JSON array **/
			JSONArray SubstitutionsArr = new JSONArray();
			JSONObject pageURLObj = new JSONObject();
			pageURLObj.put("Name", "page_url");
			pageURLObj.put("Value", pageUrl);
			SubstitutionsArr.put(pageURLObj);
			LOG.info("SubstitutionsArr::::" + SubstitutionsArr);

			/** Adding Params to JSON Object **/
			JSONObject jsonObj = new JSONObject();
			
			JSONObject commentsJsonObj = new JSONObject();

			jsonObj.put(properties.get(JHINSConstants.HEADER_APPID), properties.get(JHINSConstants.HEADER_APPID_VALUE));

			jsonObj.put(JHINSConstants.TEMPLATEID, TemplateID);
			jsonObj.put(JHINSConstants.FROM, fromMails);
			jsonObj.put(JHINSConstants.TO, toMailsArray);
			String subject = " Workflow Email";
			if (TemplateID.equalsIgnoreCase("3779faae-05de-49a5-b418-1afc3d61e749")) {
				subject = "AEM content rejection";
				commentsJsonObj.put("Name", "comment");
				commentsJsonObj.put("Value", comments);
				SubstitutionsArr.put(commentsJsonObj);			
			} else if (TemplateID.equalsIgnoreCase("637a4caa-090f-4be4-af80-675bfe4f0be5")) {
				subject = "Content page has been approved";			
			} else {
				subject = "Reassign AEM task to another user";				
			}
			jsonObj.put(JHINSConstants.SUBJECT, subject);
			jsonObj.put(JHINSConstants.SUBSTITUTIONS, SubstitutionsArr);
			LOG.info("JSONOBJ::::" + jsonObj);
			workflowEmailHelper.getJsonResponse(headerBean, jsonObj);
		} catch (JSONException e) {
			LOG.error("JSONException::::" + e);
		}
		return fromAddress;
	}
}
