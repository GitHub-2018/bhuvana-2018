package com.jh.jhins.servlet;

import java.io.IOException;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JHINS Users List Servlet"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/UsersList" }),
		@Property(name = "service.vendor", value = "JHINS"),
		@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)})
public class JHINSUserListServlet extends SlingAllMethodsServlet{
	
	private static final Logger LOG = LoggerFactory
			.getLogger(JHINSUserListServlet.class);

	private static final long serialVersionUID = 1L;

	@Reference
    private ConfigurationAdmin configAdmin;
	
	private static Dictionary<String, String> properties;
	
	private static final String GROUP_PID = "com.jh.jhins.servlet.JHINSUserListServlet";
	private static final String CONTENTOWNERS = "contentowners";
	
	protected final void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException, IOException {
			
			LOG.info("inside JHINSUserListServlet ");
		    	
                Configuration config = configAdmin.getConfiguration(GROUP_PID);
                synchronized (config) {
                properties = config.getProperties();
            }
			Map<String,String> jsonMap= new HashMap<String,String>(); 
			java.util.Iterator<Authorizable> users = null, groups ;
			Object obj = null; 
			User user = null;
			String id = null;
			String path= null;
            JSONArray optionsArray = new JSONArray(); 
            String[] groupNames = PropertiesUtil.toStringArray(properties.get(CONTENTOWNERS));
            LOG.debug("groups length "+groupNames.length);
			//String[] groupNames={"aem-jhins-qa-prodmarketing","aem-jhins-qa-marcom"};
			ResourceResolver resourceResolver = request.getResourceResolver();
			    UserManager userManager = resourceResolver.adaptTo(UserManager.class);
			    Group groupd = null;
			     
				try {
					for(String groupName: groupNames){
						LOG.debug("group Name ::::"+groupName);
					groupd = (Group) userManager.getAuthorizable(groupName);
					users = groupd.getMembers();
			           while(users.hasNext()){
			              obj = users.next();
			                 if(!(obj instanceof User)){
			                   continue;
			                 }
			                 user = (User)obj;
							 id = user.getID();
							 path= user.getPath();
					         jsonMap.put("title",id);
					         jsonMap.put("path",path);
					         optionsArray.put(jsonMap);
			             }
					}
			           JSONObject finalJsonResponse = new JSONObject();
			           finalJsonResponse.put("hits", optionsArray);
			 
			            response.getWriter().println(finalJsonResponse.toString());
			            LOG.debug("final Json :::: "+finalJsonResponse.toString());
				} catch (RepositoryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}		
}
