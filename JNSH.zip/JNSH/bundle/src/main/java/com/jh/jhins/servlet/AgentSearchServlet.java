package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.AgentSearchBean;
import com.jh.jhins.interfaces.AgentSearchService;

@SlingServlet(paths="/bin/sling/agentSearch",metatype=true, methods = HttpConstants.METHOD_POST )
public class AgentSearchServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(AgentSearchServlet.class);
	@Reference
	AgentSearchService searchService;

	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		LOG.debug("Start of agentSearch Servlet");

		AgentSearchBean agentSearchBean = new AgentSearchBean();
		agentSearchBean.setAgentCode(request.getParameter("agentCode"));
		agentSearchBean.setUserId(request.getParameter("userId"));
		agentSearchBean.setPolicynumber(request.getParameter("policynumber"));
		agentSearchBean.setPlcnumber(request.getParameter("policynumber"));
		agentSearchBean.setUserRole(request.getParameter("userRole"));
		agentSearchBean.setHostsystem(request.getParameter("hostsystem"));
		agentSearchBean.setEmailaddress(request.getParameter("emailaddress"));
		agentSearchBean.setUserName(request.getParameter("userName"));

		String finalResponse = searchService.agentSearch(agentSearchBean);		

		PrintWriter out = response.getWriter();
		out.write(finalResponse);
		out.flush();
		out.close();
		LOG.debug("End of agentSearch Servlet");
	}	
}
