package com.jh.jhins.workflow;

import com.jh.jhins.workflow.WorkflowEmailHelper;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.ComponentContext;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.mailer.MessageGatewayService;
import com.jh.jhins.bean.HeaderBean;
import com.jh.jhins.constants.JHINSConstants;

@Component(immediate = true)
@Service
@Properties({ @Property(name = WorkflowConstants.SERVICE_DESCRIPTION, value = "Process for Jh content Owner Selection"),
	@Property(name = WorkflowConstants.SERVICE_VENDOR, value = "JHINS"),
	@Property(name = WorkflowConstants.PROCESS_LABEL, value = "JHINS Content Owner Selection"),
	@Property(name = WorkflowConstants.HOST_ID, value = "localhost:4504") })

public class ContentOwnerSelectionProcess implements WorkflowProcess {

	@Reference
	ResourceResolverFactory resolverFactory;
	@Reference
	private MessageGatewayService msgGatewayService;

	// Reference for activating the sling property
	private Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		properties = context.getProperties();
	}

	private static final Logger LOG = LoggerFactory.getLogger(ContentOwnerSelectionProcess.class);

	/**
	 * Workflow Execute Method to send the mail for the given details (users)in
	 * dialog
	 * 
	 */
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
			throws WorkflowException {
		ResourceResolver resourceResolver = null;
		try {
			WorkflowEmailHelper workflowEmailHelper = new WorkflowEmailHelper();
			String prinicipalParticipiant = "";
			Node jcrNode = null;
			WorkflowData workflowData = workItem.getWorkflowData();
			String payloadPath = workflowData.getPayload().toString();

			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "JHINSService");
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			if (workflowData.getPayloadType().equals(WorkflowConstants.TYPE_JCR_PATH)) {
				Session jcrSession = workflowSession.adaptTo(Session.class);
				Node node = jcrSession.getNode(payloadPath);

				if (node != null && node.hasNode(WorkflowConstants.JCR_CONTENT)) {
					jcrNode = node.getNode(WorkflowConstants.JCR_CONTENT);
					if (jcrNode != null && jcrNode.hasProperty(WorkflowConstants.PROPERTY_SELECT)) {
						prinicipalParticipiant = jcrNode.getProperty(WorkflowConstants.PROPERTY_SELECT).getValue()
								.toString();
					}
				}

				String templateID = workflowEmailHelper.getProcessArgValues(WorkflowConstants.TEMPLATE_ID, metaDataMap);
				String ccRecipient = workflowEmailHelper.getProcessArgValues(WorkflowConstants.EMAIL_CC_RECIPIENT,
						metaDataMap);
				Map<String, String> emailRecipients = workflowEmailHelper.getEmailAddrsFromUserPath(resourceResolver,
						prinicipalParticipiant);
				Map<String, String> emailParams = new HashMap<String, String>();
				emailParams.put(WorkflowConstants.EMAIL_CC_RECIPIENT, ccRecipient);
				String hostId = properties.get(WorkflowConstants.HOST_ID);
				LOG.debug("templateID" + templateID);
				String pageUrl = WorkflowConstants.HTTP + "://" + hostId + payloadPath + "." + WorkflowConstants.HTML;
				emailParams.put(WorkflowConstants.EMAIL_PAGE_URL, pageUrl);
				sendEmail(templateID, emailRecipients, pageUrl);
				
			}
		} catch (RepositoryException e) {
			LOG.error("RepositoryException occurred in service ", e);
		} catch (LoginException e) {
			LOG.error("LoginException occurred in service", e);
		} finally {
			if (resourceResolver != null) {
				resourceResolver.close();
			}
		}

	}
/**
	 * Method to send the Email through API
	 * 
	 * @param TemplateID
	 * @param emailRecipients
	 * @param page_url
	 * param comments
	 * @return String
	 */
	public String sendEmail(String TemplateID, Map<String, String> emailRecipients, String pageUrl) {
		WorkflowEmailHelper workflowEmailHelper = new WorkflowEmailHelper();
		
		
		/** Setting From Email Address **/
		String fromAddress = properties.get("admin.email.id");
		try {
			JSONObject fromMails = new JSONObject();
			fromMails.put("name", "admin");
			fromMails.put(JHINSConstants.EMAIL, fromAddress);

			JSONObject toMails = new JSONObject();
			JSONArray toMailsArray = new JSONArray();
			Iterator<Map.Entry<String, String>> itr = emailRecipients.entrySet().iterator();
			while (itr.hasNext()) {
				Map.Entry<String, String> entry = itr.next();
				toMails.put("name", entry.getKey());
				toMails.put(JHINSConstants.EMAIL, entry.getValue());
				toMailsArray.put(toMails);
			}
			LOG.info("toMails::::" + toMails);

			/** Setting Header Values **/
			HeaderBean headerBean = new HeaderBean();
			headerBean.setKey(properties.get(JHINSConstants.HEADER_KEY));
			headerBean.setValue(properties.get(JHINSConstants.HEADER_VALUE));
			headerBean.setUrl(properties.get(JHINSConstants.EMAIL_API_URL));
			

			/** Adding Email Params to JSON array **/
			JSONArray SubstitutionsArr = new JSONArray();
			JSONObject pageURLObj = new JSONObject();
			pageURLObj.put("Name", "page_url");
			pageURLObj.put("Value", pageUrl);
			SubstitutionsArr.put(pageURLObj);
			LOG.info("SubstitutionsArr::::" + SubstitutionsArr);

			/** Adding Params to JSON Object **/
			JSONObject jsonObj = new JSONObject();

			jsonObj.put(properties.get(JHINSConstants.HEADER_APPID), properties.get(JHINSConstants.HEADER_APPID_VALUE));

			jsonObj.put(JHINSConstants.TEMPLATEID, TemplateID);
			jsonObj.put(JHINSConstants.FROM, fromMails);
			jsonObj.put(JHINSConstants.TO, toMailsArray);
			jsonObj.put(JHINSConstants.SUBJECT, "Request for Approval");
			jsonObj.put(JHINSConstants.SUBSTITUTIONS, SubstitutionsArr);
			LOG.info("JSONOBJ::::" + jsonObj);

			workflowEmailHelper.getJsonResponse(headerBean, jsonObj);

		} catch (JSONException e) {
			LOG.error("JSONException::::" + e);
		}
		return fromAddress;
	}

}
