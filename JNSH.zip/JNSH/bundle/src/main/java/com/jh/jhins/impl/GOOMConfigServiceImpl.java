package com.jh.jhins.impl;

import java.io.IOException;
import java.util.Dictionary;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.interfaces.GOOMConfigService;

@Service
@Component(immediate = true, metatype = true, name = "GOOMConfigServiceImpl", description = "Programatically get  properties of OSGi configurations.")
public class GOOMConfigServiceImpl implements GOOMConfigService {

	private static final Logger LOG = LoggerFactory.getLogger(GOOMConfigServiceImpl.class);
	public static final String GOOM_CONFIG_PID= "com.jh.jhins.impl.GOOMConfigServiceImpl";
	public static final String UNCHECKED="unchecked";
	
	@Reference
	private ConfigurationAdmin configAdmin;
	
	public String getProperty(final String property) {
		String propertyValue ="" ;
		try {
			Configuration conf = configAdmin.getConfiguration(GOOM_CONFIG_PID);
			@SuppressWarnings(UNCHECKED)
			Dictionary<String, Object> properties = conf.getProperties();
			if (properties != null && !properties.isEmpty()) {
					if (properties.get(property) != null) {
						propertyValue = properties.get(property).toString();
					}
			}
		} catch (IOException e) {
			LOG.error("IOException",e);
		}
		return propertyValue;
		
	}
}
