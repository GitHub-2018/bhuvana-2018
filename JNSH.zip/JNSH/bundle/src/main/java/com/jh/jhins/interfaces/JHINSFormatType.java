package com.jh.jhins.interfaces;

import java.util.Map;

public interface JHINSFormatType {
	
	public Map<String, String> getConfigProperty(final String property);

}
