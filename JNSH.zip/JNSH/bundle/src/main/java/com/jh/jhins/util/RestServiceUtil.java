package com.jh.jhins.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth.ContentType;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.GOOMConstants;

public class RestServiceUtil {
	
	private static final Logger LOG = LoggerFactory.getLogger(RestServiceUtil.class);
	
	public static String oAuthTokenValue(String clientSecret,String clientId, String tokenLocation ) throws OAuthSystemException, OAuthProblemException {
		OAuthClient client = new OAuthClient(new URLConnectionClient());
		String token="";
		OAuthClientRequest request = OAuthClientRequest
				.tokenLocation(tokenLocation)
				.setGrantType(GrantType.CLIENT_CREDENTIALS)
				.setClientId(clientId)
				.setClientSecret(clientSecret)				
				.buildBodyMessage();
		request.addHeader("ContentType", ContentType.JSON);
		token = client.accessToken(request, OAuthJSONAccessTokenResponse.class).getAccessToken();
		return token;
	}

	public static ResourceResolver getServiceResolver(ResourceResolver resolver, ResourceResolverFactory resolverFactory){
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(ResourceResolverFactory.SUBSERVICE, GOOMConstants.JHINS_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			//resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
		} catch (LoginException e) {
			LOG.error("LoginException:", e);
		}
		return resourceResolver;
	}

}
