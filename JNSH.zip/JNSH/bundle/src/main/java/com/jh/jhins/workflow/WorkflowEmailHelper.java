package com.jh.jhins.workflow;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Value;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.jh.jhins.bean.HeaderBean;
import com.jh.jhins.constants.JHINSConstants;

public class WorkflowEmailHelper {

	private static final Logger LOG = LoggerFactory.getLogger(WorkflowEmailHelper.class);

	/**
	 * Method to get the process args values
	 * 
	 * @param key
	 * @param metadatamap
	 * @return String
	 */
	public String getProcessArgValues(String key, MetaDataMap metaDataMap) {
		String processArguments[];
		String argumentValue = " ";
		String processArgs = metaDataMap.get(WorkflowConstants.PROCESS_ARGS, String.class);
		if (processArgs != null && !processArgs.equals("")) {
			processArguments = processArgs.split(",");

			for (int i = 0; i < processArguments.length; i++) {
				String trimmedStr = processArguments[i].trim();
				if (trimmedStr.startsWith(key + ":")) {
					argumentValue = trimmedStr.substring((key + ":").length());
					break;
				}
			}
		}

		return argumentValue;
	}

	/**
	 * Method to get the email address from the cq user id path values
	 * 
	 * @param resourceResolver
	 * @param principlePath
	 * @return String[]
	 */
	public Map<String, String> getEmailAddrsFromUserPath(ResourceResolver resourceResolver, String principlePath) {
		Map<String, String> emailRecipients = new HashMap<String, String>();

		try {
			Resource authRes = resourceResolver.getResource(principlePath);
			if (authRes != null) {
				Authorizable authorizable = authRes.adaptTo(Authorizable.class);
				if (authorizable != null) {
					// check if it is a group
					if (authorizable.isGroup()) {
						Group authGroup = authRes.adaptTo(Group.class);
						LOG.info("authorizable.isGroup()" + authGroup);
						// iterate over members of the group and add emails
						Iterator<Authorizable> memberIt = authGroup.getMembers();
						while (memberIt.hasNext()) {
							String currEmail = getAuthorizableEmail(memberIt.next());
							String currName=getAuthorizableName(memberIt.next());
							LOG.info("emailRecipients name" + currEmail + currName);
							if (currEmail != null && currName!=null && currEmail.contains("@")){
								emailRecipients.put(currName, currEmail);
							}
						}
						} else {
							// otherwise is an individual user
							String authEmail = getAuthorizableEmail(authorizable);
							String authName=getAuthorizableName(authorizable);
							LOG.info("authEmail :::: " + authEmail+authName);
							if (authEmail != null && authEmail != null && authEmail.contains("@"))
								emailRecipients.put(authName, authEmail);
						}
					}
				}
			} catch (RepositoryException e) {
				LOG.error("Could not get list of email(s) for users. {}", e);
			}
			LOG.info("emailRecipients emailRecipients " + emailRecipients);
			// String[] emailReturn = new String[emailList.size()];
			return emailRecipients;
		}

		/**
		 * Method to get the authorzable user email address from the cq user id path
		 * values
		 * 
		 * @param authorizable
		 * @return String
		 */
		public String getAuthorizableEmail(Authorizable authorizable) throws RepositoryException {
			LOG.debug("getAuthorizableEmail Method::::" + authorizable);
			if (authorizable.hasProperty(WorkflowConstants.PROFILE_EMAIL)) {
				Value[] emailVal = authorizable.getProperty(WorkflowConstants.PROFILE_EMAIL);
				LOG.debug("emailVal::::" + emailVal.toString());
				return emailVal[0].getString();
			}
			return "admin";
		}

		/**
		 * Method to get the authorzable user email address from the cq user id path
		 * values
		 * 
		 * @param authorizable
		 * @return String
		 */
		public String getAuthorizableName(Authorizable authorizable) throws RepositoryException {
			LOG.debug("getAuthorizableName Method::::" + authorizable);
			if (authorizable.getPrincipal().getName() != null) {
				String nameVal =authorizable .getPrincipal().getName();
				LOG.info("getting nameVal adresss " + nameVal + authorizable.getPrincipal().getName());
				return nameVal;
			}
			return "admin";
		}

		public String getJsonResponse(HeaderBean headerBean, JSONObject jsonObj) {
			String responseData = null;
			try {
				StringEntity input = new StringEntity(jsonObj.toString());
				input.setContentType(JHINSConstants.APPLICATION_JSON);
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpPost postRequest = new HttpPost(headerBean.getUrl());
				postRequest.setEntity(input);
				postRequest.addHeader(headerBean.getKey(), headerBean.getValue());
				postRequest.addHeader(JHINSConstants.CONTENT_TYPE, JHINSConstants.APPLICATION_JSON);
				CloseableHttpResponse httpResponse = httpClient.execute(postRequest);
				LOG.debug("httpResponse code::::" + httpResponse);
				if (httpResponse.getStatusLine().getStatusCode() != 200) {
					int statusCode = httpResponse.getStatusLine().getStatusCode();
					LOG.debug("Email Sending failed with response Code::::" + statusCode);
				} else {
					LOG.debug("Email Sending Success::::" + httpResponse);
				}
				httpClient.getConnectionManager().shutdown();
			} catch (UnsupportedEncodingException e) {
				LOG.info("UnsupportedEncodingException::::" + e);
			} catch (Exception ex) {
				LOG.error("Error sending mail::::", ex);
			}
			return responseData;
		}
	}
