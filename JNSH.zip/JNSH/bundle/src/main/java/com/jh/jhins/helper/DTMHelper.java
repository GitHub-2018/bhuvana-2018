package com.jh.jhins.helper;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;

import org.apache.commons.io.IOUtils; 
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.jh.jhins.constants.DTLConstants;

public class DTMHelper {
	private static String pageName;
	private static String pagepath;
	private static String primaryCategory;
	private static String subCategory1;
	private static String subCategory2;
	private static String subCategory3;
	private static String prefixedPagepath;
	private static String page;
	private static String modifiedPagePath;
	private static String finalPagePath;
	private static String shortname;
	
	private static final Logger LOG = LoggerFactory.getLogger(DTMHelper.class);
	
	public static String getAnalyticsDataLayer(Page currentPage, SlingHttpServletRequest request){
		
		JSONObject pageNameJSON = new JSONObject();
		JSONObject pageInfoJSON = new JSONObject();
		JSONObject pageJSON = new JSONObject();
		pageName = currentPage.getName();
		pagepath = currentPage.getPath();
		prefixedPagepath = DTLConstants.PAGE_NAME.concat(currentPage.getPath());
		modifiedPagePath = prefixedPagepath.replaceAll("/", ":");
		String jsonFilePath = "/content/dam/sample.json";
		Resource jsonRes = request.getResourceResolver().getResource(jsonFilePath);
		
		if(jsonRes != null){
			// Convert the resource to an Asset for convenience
			Asset optionsFile = jsonRes.adaptTo(Asset.class);
			InputStream inputStream = optionsFile.getOriginal().getStream();
			String jsonString,pagevalue;
			JSONObject json;
			Node pageJcrNode = null;
			try {
				jsonString = IOUtils.toString(inputStream, "UTF-8");
				json = new JSONObject(jsonString);
				String[] pagePaths = pagepath.split("/");
				Iterator<String> keys = json.keys();
				//finalPagePath = modifiedPagePath;
				while (keys.hasNext()) {
					String key = (String) keys.next();
					for(String s : pagePaths){
						if(s.equals(key)){
							pagevalue = json.getString(key);
							if(modifiedPagePath.contains(s)){
								modifiedPagePath = modifiedPagePath.replace(s, pagevalue);
								if(pageJcrNode!=null){
									pageJcrNode = currentPage.getContentResource().adaptTo(Node.class);
									pageJcrNode.setProperty("shortname", pagevalue);
									pageJcrNode.getSession().save();
								}
								pageNameJSON.put("pageName",modifiedPagePath);
								LOG.info("pagename---"+modifiedPagePath);
								pageInfoJSON.put("pageInfo", pageNameJSON);
								LOG.info("pageInfoJSON---"+pageNameJSON);
								pageJSON.put("page", pageInfoJSON);
								LOG.info("pageJSON---"+pageJSON);
							}/*else{
								finalPagePath = modifiedPagePath;
								LOG.info("Else ----finalPagePath-----"+finalPagePath);
							}
							*/
						}
					}
						
				}
			} catch (JSONException e) {
				LOG.error("JSON Exception---->",e);
			}
			catch (IOException e1) {
				LOG.error("IO Exception---->",e1);
			} catch (ValueFormatException e) {
				e.printStackTrace();
			} catch (VersionException e) {
				e.printStackTrace();
			} catch (LockException e) {
				e.printStackTrace();
			} catch (ConstraintViolationException e) {
				e.printStackTrace();
			} catch (RepositoryException e) {
				e.printStackTrace();
			}
		}
		String pagedata = pageNameJSON.toString();
		//LOG.info("data-----"+pagedata);
		return pagedata;
	}
}