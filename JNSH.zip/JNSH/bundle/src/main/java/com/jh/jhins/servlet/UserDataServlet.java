package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.jh.jhins.interfaces.UserDataService;

@SlingServlet( paths = "/bin/sling/userdata",metatype=true, methods = HttpConstants.METHOD_GET )
@Properties({ @Property(name = "service.description", value = "Mock userData object for Context Hub"),
	@Property(name = "service.vendor", value = "JHINS")})
public class UserDataServlet extends SlingAllMethodsServlet {
	private static final Logger LOG = LoggerFactory.getLogger(UserDataServlet.class);
	public static final String APPLICATION_JSON="application/json";
	public static final String CHARSET="UTF-8";
	
	@Reference
	UserDataService userDataService;
	
	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException  {
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String userData = userDataService.getProperty("userdata");
		LOG.info("userData:::::::::"+userData.toString());
		response.setContentType(APPLICATION_JSON);
        response.setCharacterEncoding(CHARSET);
        PrintWriter out = response.getWriter();
        if(null != userData && "" != userData){
        	out.write(xssAPI.getValidJSON(userData, null));
        }
		out.flush();
		out.close();
	}
}
