package com.jh.jhins.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.TreeMap;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jh.jhins.bean.ContactDetailsBean;
import com.jh.jhins.bean.PersonalContactBean;
import com.jh.jhins.constants.ContactConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.dao.NewsInfoDAO;

public class ContactDetailsHelper {
	private static final Logger LOG = LoggerFactory.getLogger(NewsInfoDAO.class);

	private static Session session;

	/**
	 * @receives array of user selected states and map 
	 * 	Queries for user selected state
	 * 	Calls retriveContactBean for each query result to fill bean on state information
	 * @return ArrayList of beans
	 * @param slingRequest
	 * @param queryBuilder
	 */

	public static ArrayList<ContactDetailsBean> queryContactInfo(ArrayList<String> statesList, Map<String, Object> mapObj)
			throws RepositoryException {
		int i=0;
		ArrayList<ContactDetailsBean> contactBeans = new ArrayList<ContactDetailsBean>();
		ContactDetailsBean contactDetailsBean = null;
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(ContactConstants.SLING_REQUEST);
		ResourceResolver resourceResolver = slingRequest.getResourceResolver();

		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);

		String path = mapObj.get(ContactConstants.PARAM_PATH).toString();
		String tagPath = mapObj.get(ContactConstants.PARAM_TAGPATH).toString();
		LOG.debug("path obtained from jsp is "+path);

		Map<String, String> map = new HashMap<String, String>();
		map.put(ContactConstants.PARAM_PATH, path);
		map.put("type",ContactConstants.NT_UNSTRUCTURED);
		map.put("1_property", ContactConstants.SLING_RESOURCETYPE);
		map.put("1_property.value",ContactConstants.SLING_RESOURCETYPE_VALUE);
		for(String state : statesList) {
			i++;
			map.put("0_group." + i + 1 + "_property",ContactConstants.STATE);
			map.put("0_group." + i + 1 + "_property.value",state);
		}
		map.put("0_group.p.or", "true");
		map.put("p.limit", "5");

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();

		if (searchRes !=null && searchRes.getHits().size()>0) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				contactDetailsBean = new ContactDetailsBean();
				contactDetailsBean = retriveContactBean(queryPath,tagPath, resourceResolver);
				contactBeans.add(contactDetailsBean);
			}
			Collections.sort( contactBeans, new Comparator<ContactDetailsBean>() {
				public int compare(ContactDetailsBean o1, ContactDetailsBean o2) {
					if (o1.getState() == null || o2.getState() == null)
						return 0;
					return (o1.getState()).compareTo(o2.getState());
				}
			});

		}
		return contactBeans;
	}
	/**
	 * 
	 * @receives queryPath and resourceResolver form queryContactInfo
	 * 	set bean with state information
	 * @return bean
	 * @throws ValueFormatException
	 * @throws PathNotFoundException
	 * @throws RepositoryException
	 */

	private static ContactDetailsBean retriveContactBean(String queryPath, String tagPath,
			ResourceResolver resourceResolver) throws ValueFormatException, PathNotFoundException, RepositoryException {
		LOG.debug("queryPath:"+queryPath);
		LOG.debug("tagPath:"+tagPath);
		ContactDetailsBean contactDetailsBean = null;
		PersonalContactBean personalContactBean= null;
		List<PersonalContactBean> personalContactBeanList=new ArrayList<PersonalContactBean>();
		Resource resource = resourceResolver.getResource(queryPath);
		if (resource != null) {
			ValueMap contactProperties = ResourceUtil.getValueMap(resource);
			contactDetailsBean=new ContactDetailsBean();	
			
			contactDetailsBean.setState(contactProperties.get(ContactConstants.STATE,String.class));
			String stateName=retrieveStateName(contactProperties.get(ContactConstants.STATE,String.class),tagPath,resourceResolver);
			contactDetailsBean.setStateName(stateName);
			
			contactDetailsBean.setTitle(contactProperties.get(ContactConstants.TITLE,String.class));
			contactDetailsBean.setAddress(contactProperties.get(ContactConstants.ADDRESS,String.class));
			contactDetailsBean.setFax(contactProperties.get(ContactConstants.FAX,String.class));
			contactDetailsBean.setPhone(contactProperties.get(ContactConstants.PHONE,String.class));
			contactDetailsBean.setTollfree(contactProperties.get(ContactConstants.TOLLFREE,String.class));
			Resource childResource = resource.getChild(ContactConstants.NODE);
			if(null!=childResource){
				Iterator<Resource> resourceIter = childResource.listChildren();
				while(resourceIter.hasNext()){
					Resource res = resourceIter.next();
					ValueMap properties = ResourceUtil.getValueMap(res);
					personalContactBean= new PersonalContactBean();
					if(null!=properties){
						personalContactBean.setName(properties.get(ContactConstants.NAME,String.class));
						personalContactBean.setDesign(properties.get(ContactConstants.DESIGNATION,String.class));
						personalContactBean.setEmail(properties.get(ContactConstants.EMAIL,String.class));
						personalContactBean.setExtn(properties.get(ContactConstants.EXTENSION,String.class));
						personalContactBeanList.add(personalContactBean);
					}
					contactDetailsBean.setPersonalBean(personalContactBeanList);
				}
			}
		}
		return contactDetailsBean;
	}
	/**
	 * 
	 * @receives contactBeans
	 * 	Converts list of bean to JSON object
	 * @return JSON Object
	 * @throws JSONException
	 */
	public static JSONObject transferContactDetailstoJSONobj(ArrayList<ContactDetailsBean> contactBeans) throws JSONException {
		// TODO Auto-generated method stub

		JSONObject contact = null;
		JSONObject personal=null;
		JSONArray personaljsonArray = new JSONArray();
		JSONArray contactArray = new JSONArray();
		JSONObject mainJson=new JSONObject();
		ListIterator<ContactDetailsBean> litr = contactBeans.listIterator();
		while (litr.hasNext()) {
			ContactDetailsBean bean = (ContactDetailsBean) litr.next();
			if (bean != null) {
				contact = new JSONObject();
				personaljsonArray=new JSONArray();
				ArrayList<PersonalContactBean> personalBean=(ArrayList<PersonalContactBean>) bean.getPersonalBean();	
				contact.put(ContactConstants.STATE,bean.getState());
				contact.put(ContactConstants.STATE_NAME, bean.getStateName());
				contact.put(ContactConstants.TITLE,bean.getTitle());
				contact.put(ContactConstants.ADDRESS,bean.getAddress());
				contact.put(ContactConstants.FAX,bean.getFax());
				contact.put(ContactConstants.PHONE,bean.getPhone());
				contact.put(ContactConstants.TOLLFREE,bean.getTollfree());
				if(personalBean!=null)
				{
					ListIterator<PersonalContactBean> personalIitr = personalBean.listIterator();
					while(personalIitr.hasNext()){
						PersonalContactBean perbean=personalIitr.next();
						if(perbean!=null)
						{
							personal=new JSONObject();
							personal.put(ContactConstants.NAME, perbean.getName());
							personal.put(ContactConstants.DESIGNATION, perbean.getDesign());
							personal.put(ContactConstants.EMAIL, perbean.getEmail());
							personal.put(ContactConstants.EXTENSION, perbean.getExtn());	
						}	
						personaljsonArray.put(personal);

					}			
				}
				contact.put("personal", personaljsonArray);
				contactArray.put(contact);	
			}
		}

		mainJson.put("list", contactArray);	
		return mainJson;

	}
	/**
	 * 
	 * @receives path
	 *Retrieves state code 
	 * @return
	 * @throws ValueFormatException
	 * @throws PathNotFoundException
	 * @throws RepositoryException
	 */
	public static Map<String,String> retrieveStates(String path,String tagPath,SlingHttpServletRequest slingRequest) throws ValueFormatException, PathNotFoundException, RepositoryException
	{
		LOG.debug("path"+path);
		LOG.debug("tagPath"+tagPath);
		String stateCode=null;
		String stateName=null;

		Map<String,String> stateMap=new LinkedHashMap<String, String>();
		TreeMap<String,String> sortedMap = new TreeMap<String,String>();
		ResourceResolver resourceResolver = slingRequest.getResourceResolver();

		if(resourceResolver!=null)	{
			Resource resource=resourceResolver.getResource(path+ContactConstants.JCR_CONTENT_PAR);
			if(null!=resource && null!=resource.listChildren()){
				Iterator<Resource> iter = resource.listChildren();
				while(iter.hasNext()){
					Resource contact = (Resource)iter.next();
					ValueMap properties = ResourceUtil.getValueMap(contact);
					stateCode=properties.get(ContactConstants.STATE,String.class);
					stateName=retrieveStateName(stateCode,tagPath,resourceResolver);
					stateMap.put(stateCode, stateName);
				}
				sortedMap.putAll(stateMap);
			}

		}

		return sortedMap;

	}
	/**
	 * 
	 * @receives stateCode,tag path and resourceResolver
	 *	Retrieves stateName for stateCode passed.
	 * @return stateName
	 * @throws PathNotFoundException
	 * @throws RepositoryException
	 */
	public static String retrieveStateName(String stateCode,String tagPath,ResourceResolver resourceResolver) throws PathNotFoundException, RepositoryException
	{
		String stateName=null;
		Resource resource = resourceResolver.getResource(tagPath);
		if(resource!=null)
		{
			Node node=resource.adaptTo(Node.class);
			if(node!=null){
				if(node.hasNode(stateCode))
				{
					Node stateNode=node.getNode(stateCode);	
					if(stateNode.hasProperty(ContactConstants.JCR_TITLE)){
						stateName=stateNode.getProperty(ContactConstants.JCR_TITLE).getString();
					}
				}
			}
		}

		return stateName;
	}

	/**
	 * @receives array of user selected states and map 
	 * 	Queries for selected state
	 * 	Calls retriveContactBean for query result to fill bean on state information
	 * @return ArrayList of beans
	 * @param slingRequest
	 * @param queryBuilder
	 */


	public static ArrayList<ContactDetailsBean> queryStateInfo(Map<String, Object> mapObj) throws RepositoryException {

		ContactDetailsBean contactDetailsBean = null;
		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
		ArrayList<ContactDetailsBean> contactBeans = new ArrayList<ContactDetailsBean>();
		ResourceResolver resourceResolver = slingRequest.getResourceResolver();

		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);

		String path = mapObj.get(ContactConstants.PARAM_PATH).toString();
		String state = mapObj.get(ContactConstants.STATE).toString();
		String tagPath = mapObj.get(ContactConstants.PARAM_TAGPATH).toString();

		LOG.debug("path obtained from jsp is"+path);
		Map<String, String> map = new HashMap<String, String>();
		map.put(ContactConstants.PARAM_PATH, path);
		map.put("type", ContactConstants.NT_UNSTRUCTURED);
		map.put("1_property", ContactConstants.SLING_RESOURCETYPE);
		map.put("1_property.value", ContactConstants.SLING_RESOURCETYPE_VALUE);
		map.put("2_property", ContactConstants.STATE);
		map.put("2_property.value",state);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (searchRes !=null && searchRes.getHits().size()>0) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				contactDetailsBean = new ContactDetailsBean();
				contactDetailsBean = retriveContactBean(queryPath,tagPath,resourceResolver);
				contactBeans.add(contactDetailsBean);
			}
		}
		return contactBeans;
	}



public static JSONObject queryAllContactInfo(String path,String TagPath,SlingHttpServletRequest request)
		throws RepositoryException, JSONException {
	JSONObject jsonObject = new JSONObject();
	ArrayList<ContactDetailsBean> contactBeans = new ArrayList<ContactDetailsBean>();
	ContactDetailsBean contactDetailsBean = null;
	ResourceResolver resourceResolver = request.getResourceResolver();

	session = request.getResourceResolver().adaptTo(Session.class);
	QueryBuilder queryBuilder = request.getResourceResolver().adaptTo(QueryBuilder.class);

	LOG.debug("path obtained from jsp is "+path);

	Map<String, String> map = new HashMap<String, String>();
	map.put(ContactConstants.PARAM_PATH, path);
	map.put("type",ContactConstants.NT_UNSTRUCTURED);
	map.put("1_property", ContactConstants.SLING_RESOURCETYPE);
	map.put("1_property.value",ContactConstants.SLING_RESOURCETYPE_VALUE);
    map.put("p.limit", "-1");

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();

		if (searchRes !=null && searchRes.getHits().size()>0) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				contactDetailsBean = new ContactDetailsBean();
				contactDetailsBean = retriveContactBean(queryPath,TagPath, resourceResolver);
				contactBeans.add(contactDetailsBean);
			}
			Collections.sort( contactBeans, new Comparator<ContactDetailsBean>() {
				public int compare(ContactDetailsBean o1, ContactDetailsBean o2) {
					if (o1.getState() == null || o2.getState() == null)
						return 0;
					return (o1.getState()).compareTo(o2.getState());
				}
			});

		}
		jsonObject=transferContactDetailstoJSONobj(contactBeans);
		return jsonObject;
	}
}