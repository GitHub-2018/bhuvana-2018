package com.jh.jhins.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jh.jhins.bean.FundDetailsBean;
import com.jh.jhins.constants.GOOMConstants;

public class FundDetails {
	private static final Logger LOG = LoggerFactory.getLogger(FundDetails.class);
	public FundDetailsBean getFundDetails(String pagePath, String fundCode,ResourceResolver resolver) throws RepositoryException {		
		String fund=fundCode;
		//TagManager tagmanager = resolver.adaptTo(TagManager.class);
		Resource resource =resolver.getResource(pagePath+"/"+fund+"/jcr:content/par/fundprofilecomp");
		FundDetailsBean fundDetail = new FundDetailsBean();
		String risk=null;
		if(null != resource)
		{
			ValueMap resVal=resource.getValueMap();
			risk=resVal.get("risk").toString();
			//Tag tag = tagmanager.resolve(risk);
			String riskTag=risk;			
			fundDetail.setRisk(riskTag);
			fundDetail.setRiskOrder(Integer.parseInt(resVal.get("riskorder").toString()));
			if(resVal.containsKey("morningStar") && null!=resVal.get("morningStar")){
				fundDetail.setMorningStarPath(resVal.get("morningStar").toString());
			}
			else
			{
				fundDetail.setMorningStarPath("");	
			}
			fundDetail.setManagementFee(resVal.get("managementfee").toString());
			fundDetail.setFundTitle(resVal.get("fundName").toString());
			fundDetail.setFundManager(resVal.get("fundManager").toString());
			fundDetail.setFundCode(resVal.get("fundCode").toString());
			if(resVal.containsKey("footnotes") && null!=resVal.get("footnotes")){
				fundDetail.setFootNote(resVal.get("footnotes").toString());
			}
			if(resVal.containsKey("nFootNotes") && null!=resVal.get("nFootNotes")){
				fundDetail.setNumberedFootNotes(resVal.get("nFootNotes").toString());
			}
			else
			{
				fundDetail.setNumberedFootNotes("");
			}
		}
		return fundDetail;
	}
	public HashMap<String,String> getRiskDetails(String pagePath,ResourceResolver resolver) {	

		HashMap<String, String> riskDetails= new HashMap<String,String>();
		TagManager tagmanager = resolver.adaptTo(TagManager.class);
		Resource resource =resolver.getResource(pagePath);
		
		if(resource!=null){	
			Iterator<Resource> riskNodes=resource.listChildren();
			while(riskNodes.hasNext())
			{
				Resource riskNode = riskNodes.next();
				ValueMap resVal=riskNode.getValueMap();
				String riskTitle =resVal.get(GOOMConstants.RISK_TITLE).toString();
				/*Tag tag = tagmanager.resolve(riskTitle);					
				riskTitle=tag.getTitle().toString();*/
				riskDetails.put(riskTitle, resVal.get(GOOMConstants.RISK_COLOR_CODE).toString());					
			}
		}
		return riskDetails;
	}
	public JSONArray getFootNoteDetails(TreeSet<Integer> listedFootNotes,ResourceResolver resolver) {
		String path="/content/JHINS/en_US/config/foot-note-details/jcr:content/par";
		Resource resource =resolver.getResource(path);
		JSONArray footNoteArray = new JSONArray();
		if(resource!=null){	
			Iterator<Resource> footNodes=resource.listChildren();
			while(footNodes.hasNext())
			{
				Resource footNoteNode = footNodes.next();
				ValueMap resVal=footNoteNode.getValueMap();
				for (Integer footNoteNum : listedFootNotes) {
					if(null!=resVal.get(GOOMConstants.FOOT_NOTE_NUMBER)){
						int footNote=Integer.parseInt((String) resVal.get(GOOMConstants.FOOT_NOTE_NUMBER));
						if(footNote==footNoteNum){
							JSONObject jsonIteration = new JSONObject();
							try {
								String footNoteNo=resVal.get(GOOMConstants.FOOT_NOTE_NUMBER).toString();
								String description= resVal.get(GOOMConstants.DESCRIPTION).toString();						
								jsonIteration.put(footNoteNo, description);
							} catch (JSONException e) {							
								e.printStackTrace();
							}
							footNoteArray.put(jsonIteration);
						}
					}
				}			
			}
		}
		return footNoteArray;
	}

	public JSONArray sortJson(JSONArray jsonArr) throws JSONException {
		List<JSONObject> jsonValues = new ArrayList<JSONObject>();
		JSONArray sortedJsonArray = new JSONArray();
		for (int i = 0; i < jsonArr.length(); i++) {
			jsonValues.add(jsonArr.getJSONObject(i));
		}
		Collections.sort( jsonValues, new Comparator<JSONObject>() { 
			private static final String KEY_NAME = "riskOrder";

			@Override			
			public int compare(JSONObject a, JSONObject b) {
				Integer valA=0;
				Integer valB=0;
				try {
					valA = (Integer) a.get(KEY_NAME);
					valB = (Integer) b.get(KEY_NAME);
				} 
				catch (JSONException e) {
					LOG.error("JSONException", e);
				}
				return valA.compareTo(valB);
			}
		});

		for (int i = 0; i < jsonArr.length(); i++) {
			sortedJsonArray.put(jsonValues.get(i));
		}
		return sortedJsonArray;
	}

}
