package com.jh.jhins.helper;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.jh.jhins.bean.ArticleBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.constants.PageConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import com.jh.jhins.helper.ArticleHelper;
import com.day.cq.commons.jcr.JcrUtil;

public class JHPageHelper {

	private static Session session;
	private static final Logger LOG = LoggerFactory.getLogger(JHPageHelper.class);

	/**
	 * Method to fetch the related pages except article pages based on Topic
	 * 
	 * @param mapObj
	 * @return articlebeans
	 * @throws RepositoryException
	 * @throws ParseException
	 */
	public static ArrayList<ArticleBean> retriveRelatedPagesByTopic(Map<String, Object> mapObj,UserTO userTo)
			throws ParseException, RepositoryException {
		ArrayList<ArticleBean> articlebeans = new ArrayList<ArticleBean>();
		ArticleBean articlebean = null;

		SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
		String limit = mapObj.get(PageConstants.PARAM_LIMIT).toString();
		String path = mapObj.get(PageConstants.PARAM_PATH).toString();
		String topic = mapObj.get(PageConstants.PARAM_TOPIC).toString();
		QueryBuilder queryBuilder = slingRequest.getResourceResolver().adaptTo(QueryBuilder.class);
		session = slingRequest.getResourceResolver().adaptTo(Session.class);
		TagManager tagmanager = slingRequest.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(topic);
		Map<String, String> map = new HashMap<String, String>();
		map.put("path", path);

		map.put("1_property", JHINSConstants.CQ_TEMPLATE);
		map.put("1_property.operation", "unequals");
		map.put("1_property.value", JHINSConstants.ARTICLE_TEMPLATE);

		/*
		 * map.put("tagid", topic); map.put("tagid.property",
		 * JHINSConstants.CQ_TAGS_PROPERTYNAME);
		 */
		map.put("2_property", JHINSConstants.CQ_TAGS_PROPERTYNAME);
		map.put("2_property.value", tag.getTagID());
		map.put("orderby", JHINSConstants.ORDER_BY);
		map.put("orderby.sort", JHINSConstants.SORT_DESC);
		map.put("p.limit", limit);
		ArticleHelper.getFilterForUserRole(map, userTo);

		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				articlebean = new ArticleBean();
				articlebean = ArticleHelper.retriveArticleBean(queryPath, slingRequest.getResourceResolver());
				articlebeans.add(articlebean);
			}
		}

		return articlebeans;
	}

	/**
	 * Method to getting the headers
	 * 
	 * @param slingRequest
	 *
	 * @return String
	 */
	@SuppressWarnings("rawtypes")
	public static String retrieveHeaderId(SlingHttpServletRequest request) {
		String headerValue = "";
		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			if (key.equalsIgnoreCase(JHINSConstants.HEADER_IV_USER)) {
				headerValue = request.getHeader(key);
				break;
			}
		}
		return headerValue;

	}



	/**
	 * Method to fetch the retrieve topic for page
	 *
	 * @param currentPage
	 * 
	 *
	 * @return String
	 * @throws RepositoryException
	 * @throws ValueFormatException
	 * @throws PathNotFoundException
	 */

	public static String retrieveTopic(Page currentPage)
			throws RepositoryException, PathNotFoundException, ValueFormatException {

		String topic = "";

		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_TOPIC)) {
				topic = tag.getTagID();
			}
		}
		return topic;
	}

	/**
	 * Method retrives topics from current Page
	 * 
	 * @param currentPage
	 * @return
	 */
	public static ArrayList<String> retrieveTopics(Page currentPage)
			throws RepositoryException, PathNotFoundException, ValueFormatException {
		ArrayList<String> topics = new ArrayList<String>();
		String topic = "";

		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_TOPIC)) {
				topic = tag.getTagID();
				topics.add(topic);
			}
		}
		return topics;
	}

	/**
	 * Method to fetch the retrieve product from page
	 *
	 * @param currentPage
	 * 
	 *
	 * @return String List
	 * @throws RepositoryException
	 * @throws ValueFormatException
	 * @throws PathNotFoundException
	 */

	public static String retrieveProduct(Page currentPage)
			throws RepositoryException, PathNotFoundException, ValueFormatException {

		String product = "";

		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_PRODUCT)) {
				product = tag.getPath();
			}
		}
		return product;
	}

	/**
	 * Method to fetch the retrieves products from page
	 * 
	 * @param currentPage
	 * @return
	 * @throws RepositoryException
	 * @throws PathNotFoundException
	 * @throws ValueFormatException
	 */
	public static ArrayList<String> retrieveProducts(Page currentPage)
			throws RepositoryException, PathNotFoundException, ValueFormatException {

		ArrayList<String> products = new ArrayList<String>();
		String product = "";
		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_PRODUCT)) {
				product = tag.getPath();
				products.add(product);

			}

		}
		return products;
	}

	/**
	 * Method to fetch the retrieve channel for page
	 *
	 * @param currentPage
	 * 
	 *
	 * @return String
	 * @throws RepositoryException
	 * @throws ValueFormatException
	 * @throws PathNotFoundException
	 */

	public static String retrieveChannel(Page currentPage)
			throws RepositoryException, PathNotFoundException, ValueFormatException {

		String channel = "";

		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_CHANNEL)) {
				channel = tag.getPath();
			}
		}
		return channel;
	}

	/**
	 * Method to fetch the  channels for page
	 *
	 * @param currentPage
	 * 
	 *
	 * @return String
	 * @throws RepositoryException
	 * @throws ValueFormatException
	 * @throws PathNotFoundException
	 */

	public static ArrayList<String> retrieveChannels(Page currentPage)
			throws RepositoryException, PathNotFoundException, ValueFormatException {
		ArrayList<String> channels = new ArrayList<String>();
		String channel = "";

		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_CHANNEL)) {
				channel = tag.getPath();
				channels.add(channel);
			}
		}
		return channels;
	}

	/**
	 * Method to fetch the channel title for page
	 * @param currentPage
	 * @return
	 */
	public static String retrieveChannelTitle(Page currentPage) {
		String channel = "";

		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_CHANNEL)) {
				channel = tag.getTitle();
			}
		}
		return channel;
	}

	/**
	 * Method to fetch the Format for page
	 *
	 * @param currentPage
	 * @return
	 */
	public static String retrieveFormat(Page currentPage) {
		String format = "";

		LOG.info("retrieveFormat {}", currentPage.getPath());
		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_FORMAT)) {
				format = tag.getTitle();
			}
		}
		LOG.info("returning format {}", format);
		return format;

	}

	/**
	 * Method to fetch the Type for page
	 *
	 * @param currentPage
	 * @return
	 */
	public static String retrieveType(Page currentPage) {
		String type = "";

		LOG.info("retrieveType {}", currentPage.getPath());
		Tag[] tags = currentPage.getTags();
		for (Tag tag : tags) {
			String tagID = tag.getLocalTagID();
			if (tagID.startsWith(JHINSConstants.PARAM_TYPE)) {
				type = tag.getTitle();
			}
		}

		LOG.info("returning Type {}", type);
		return type;

	}
	/**
	 * Method to fetch the ContentStream nodes
	 *
	 * @param contentPath
	 * @param queryString
	 * @param resourceResolver
	 * @return Node
	 * @throws RepositoryException
	 */

	public String retrieveContentStreamPath(String contentPath,String queryString, ResourceResolver resourceResolver)
	{

		String firmValue="";
		String identitySrcValue="";
		String contentTypeValue="";
		String  resultNodePath=null;	
		// getting the attributes from the query String 
		if(queryString!=null){
			String[] attributes = queryString.split(JHINSConstants.AMPERSAND);
			for (int i = 0; i < attributes.length; i++) {
				String trimmedStr = attributes[i].trim();
				if (trimmedStr.startsWith(JHINSConstants.PARAM_FIRM +JHINSConstants.EQUAL)) {
					firmValue = trimmedStr.substring((JHINSConstants.PARAM_FIRM  + JHINSConstants.EQUAL).length());
				}
				if (trimmedStr.startsWith(JHINSConstants.IDENTITY_SOURCE +JHINSConstants.EQUAL)) {
					identitySrcValue = trimmedStr.substring((JHINSConstants.IDENTITY_SOURCE +JHINSConstants.EQUAL).length());
				}
				if (trimmedStr.startsWith(JHINSConstants.CONTENT_TYPE + JHINSConstants.EQUAL)) {
					contentTypeValue = trimmedStr.substring((JHINSConstants.CONTENT_TYPE + JHINSConstants.EQUAL).length());           	
				}
			}
		}




		//getting the nodes having particular firm  or identitySource and  contentType
		Resource resource = resourceResolver.getResource(contentPath);
		try{
			Node contextNode=resource.adaptTo(Node.class);
			NodeIterator nodeIterator = contextNode.getNodes();
			while(nodeIterator.hasNext()) {
				Node childNode = nodeIterator.nextNode();
				NodeIterator childlItemNodeIterator = childNode.getNodes();
				while(childlItemNodeIterator.hasNext()){
					Node childItemNode=childlItemNodeIterator.nextNode(); 
					if(childItemNode.hasProperty(JHINSConstants.JCR_TITLE))
					{
						String jcrtitle =childItemNode.getProperty(JHINSConstants.JCR_TITLE).getString();  					
						if(jcrtitle.equalsIgnoreCase(contentTypeValue))
						{
							if(childItemNode.hasNode(JHINSConstants.PAGE_PAR))
							{
								Node page_parNode = childItemNode.getNode(JHINSConstants.PAGE_PAR);
								if(page_parNode.hasNodes()){
									NodeIterator streamNodeIterator = page_parNode.getNodes();
									while(streamNodeIterator.hasNext()){
										{
											Node childStreamNode=streamNodeIterator.nextNode();
											if(childStreamNode.hasProperty(JHINSConstants.CONTENT_STREAM_TYPE))
											{
												String idType =childStreamNode.getProperty(JHINSConstants.CONTENT_STREAM_TYPE).getString();
												if(idType.equalsIgnoreCase(JHINSConstants.IDENTITY_SOURCE))
												{
													if(childStreamNode.hasProperty(JHINSConstants.IDENTITY_SOURCE))
													{
														String identitysrc =childStreamNode.getProperty(JHINSConstants.IDENTITY_SOURCE).getString();											
														if(identitySrcValue.equalsIgnoreCase(identitysrc))
														{										
															resultNodePath= childStreamNode.getPath();
															break;
														}

													}}
												else if(childStreamNode.hasProperty(JHINSConstants.PARAM_FIRM ))
												{
													String firm =childStreamNode.getProperty(JHINSConstants.PARAM_FIRM).getString();  					
													if(firmValue.equalsIgnoreCase(firm))
													{
														resultNodePath= childStreamNode.getPath();
														break;
													}
												}
												else if (childStreamNode.hasProperty(JHINSConstants.PARAM_DEFAULT ))
												{
													resultNodePath= childStreamNode.getPath();
													break;

												}

											}

										}	
									}
								}
							}

						}
					}
				}
			}		
		}
		catch(RepositoryException e)
		{
			LOG.error("RepositoryException");
		}
		return resultNodePath;		
	}

	public static void logMap(Map<String, String> map) {
		LOG.debug("Starting of logMap method");
		if(map != null){
			Iterator<Entry<String, String>> it = map.entrySet().iterator();
			while(it.hasNext()){
				Map.Entry<String,String> mapItem = (Map.Entry<String, String>) it.next();
				LOG.debug(mapItem.getKey()+"="+mapItem.getValue());
			}

		}
		LOG.debug("END of logMap method");
	}
		/**
		 * Method to currentnode identifier
		 *
		 * @param currentnode
		 * @return String
		 * @throws RepositoryException
		 */
		public String retrieveIdentifier(Node currentnode)
		{
			String path;
			String name=null;
			String[] paths;
			try {
			 path = currentnode.getIdentifier();						
			 paths = path.split("/");
			 name = JcrUtil.createValidName(paths[0]);
			} 
			catch (RepositoryException e) {
				LOG.error("RepositoryException",e);
			}
			return name;
			
		}
}
