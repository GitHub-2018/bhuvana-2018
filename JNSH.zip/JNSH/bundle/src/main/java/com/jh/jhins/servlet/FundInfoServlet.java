package com.jh.jhins.servlet;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SlingServlet(resourceTypes = "/apps/JHINS/components/page/contentpage-white", selectors = "list", extensions = "json", methods = "GET", metatype =true)
public class FundInfoServlet extends SlingSafeMethodsServlet{
	private static final Logger LOG = LoggerFactory.getLogger(FundInfoServlet.class);

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {


		try
		{
			String path=null;	
			JSONArray productArray =null;
			JSONObject finalJSON=new JSONObject();
			Resource resource = request.getResource();
			Resource parent = resource.getParent();	
			String parentNodeName=resource.getParent().getName();
			if(parentNodeName.equals("fundprofileinformation"))
			{
				path= "/jcr:content/par/fundprofilecomp";
				productArray=getFundJSON(parent,path);
				finalJSON.put("Funds", productArray);
			}
			else if(parentNodeName.equals("productsinformation"))
			{
				path="/jcr:content/par/productprofilecomp";
				productArray=getProductJSON(parent,path);
				finalJSON.put("Products", productArray);			
			}			
			response.getWriter().println(finalJSON.toString());

		}catch (Exception e) {
			LOG.error(e.getMessage(),e);
		} 
	}



	private JSONArray getProductJSON(Resource parent, String path) {

		JSONArray productArray = new JSONArray();
		Iterator<Resource> itr = parent.listChildren();

		try {

			while(itr.hasNext()){
				Resource childResource = itr.next();
				//  LOG.info("childResource::::::::::::"+childResource.getName());
				Resource pageResource =childResource.getResourceResolver().getResource(childResource.getPath()+path);
				if(pageResource != null){
					ValueMap resourceValMap =pageResource.getValueMap();
					Node node = pageResource.adaptTo(Node.class);
					createMissingProductProperty(node);
					if(resourceValMap.containsKey("productCategory")){
						String productcategory = resourceValMap.get("productCategory").toString();
						if(productcategory.contains(",")){  
							String[] tokens= productcategory.split("\\,");
							for(String category: tokens) { 
								JSONObject splitObj = getProductNodeAsJSONObject(resourceValMap); 
								splitObj.put("productCategory", category);
								LOG.info("splitted ojbect"+splitObj);
								productArray.put(splitObj);
							}
						}else{
							JSONObject productObject = getProductNodeAsJSONObject(resourceValMap); 
							productArray.put(productObject);
						}
					}
				}
			}
		}
		catch (JSONException e) {
			e.printStackTrace();
		}

		return productArray;
	}

	private void createMissingProductProperty(Node node) {

		try {
			if(!node.hasProperty("name")){
				node.setProperty("name", "");
			}			
			if(!node.hasProperty("productCode")){
				node.setProperty("productCode", "");
			}		
		} catch (ValueFormatException e) {
			LOG.error("ValueFormatException",e);
		} catch (VersionException e) {
			LOG.error("VersionException",e);
		} catch (LockException e) {
			LOG.error("LockException",e);
		} catch (ConstraintViolationException e) {
			LOG.error("ConstraintViolationException",e);
		} catch (RepositoryException e) {
			LOG.error("RepositoryException",e);
		}
	}


	private JSONObject getProductNodeAsJSONObject(ValueMap resourceValMap) {
		JSONObject productObj = new JSONObject();
		try{
			if(resourceValMap.containsKey("name")){
				productObj.put("productName", resourceValMap.get("name").toString());
			}		  
			if(resourceValMap.containsKey("productCode")){
				productObj.put("productCode", resourceValMap.get("productCode").toString());
			}			  
		}catch (JSONException e) {
			LOG.error("JSONException",e);
		}
		return productObj;
	}


	private JSONArray getFundJSON(Resource parent, String path) {
		JSONArray productArray = new JSONArray(); 
		Iterator<Resource> itr = parent.listChildren();
		while(itr.hasNext()){
			Resource childResource = itr.next();
			LOG.info("childResource::::::::::::"+childResource.getName());
			Resource pageResource =childResource.getResourceResolver().getResource(childResource.getPath()+path);
			LOG.info("pageResource:::"+pageResource);
			if(pageResource != null){
				ValueMap resourceValMap =pageResource.getValueMap();
				Node node = pageResource.adaptTo(Node.class);
				createMissingProperty(node);					
				JSONObject productObject = getNodeAsJSONObject(resourceValMap); 
				productArray.put(productObject);
			}
		}
		return productArray;

	}

	private JSONObject getNodeAsJSONObject(ValueMap resourceValMap) {
		JSONObject productObj = new JSONObject();
		try{
			if(resourceValMap.containsKey("fundCode")){
				productObj.put("fundCode", resourceValMap.get("fundCode").toString());
			}
			if(resourceValMap.containsKey("fundName")){
				productObj.put("fundName", resourceValMap.get("fundName").toString());
			}			
		}catch (JSONException e) {
			LOG.error("JSONException",e);
		}
		return productObj;
	}

	private void createMissingProperty(Node node) {

		try {
			if(!node.hasProperty("fundCode")){
				node.setProperty("fundCode", "");
			}
			if(!node.hasProperty("fundName")){
				node.setProperty("fundName", "");
			}
		} catch (ValueFormatException e) {
			LOG.error("ValueFormatException",e);
		} catch (VersionException e) {
			LOG.error("VersionException",e);
		} catch (LockException e) {
			LOG.error("LockException",e);
		} catch (ConstraintViolationException e) {
			LOG.error("ConstraintViolationException",e);
		} catch (RepositoryException e) {
			LOG.error("RepositoryException",e);
		}
	}

}
