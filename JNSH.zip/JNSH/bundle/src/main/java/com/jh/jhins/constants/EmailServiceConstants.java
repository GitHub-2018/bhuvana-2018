/*
 * #%L
 * ACS AEM Commons Bundle
 * %%
 * Copyright (C) 2013 Adobe
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */
package com.jh.jhins.constants;

import aQute.bnd.annotation.ProviderType;

/**
 * Defines special keys for the replacement variable map
 * passed to EmailService.sendEmail().
 */
@ProviderType
public final class EmailServiceConstants {

  
    /**
     * Sender Email Address variable passed in the input parameter
     * map to the sendEmail() function.
     */
    public static final String SENDER_EMAIL_ADDRESS = "senderEmailAddress";

    /**
     * Sender Name variable passed in the input parameter
     * map to the sendEmail() function.
     */
    public static final String SENDER_NAME = "senderName";
    public static final String FIRST_NAME = "First_Name";
    public static final String EMAIL_ADDRESS = "Email_Address";
    public static final String PHONE_1= "Phone_1";
    public static final String PHONE_2= "Phone_2";
    public static final String PHONE_3= "Phone_3";
    public static final String PHONE_4= "Phone_4";
    public static final String ADDRESS = "Address";
    public static final String EMAIL_CONFIRMATION = "emailconf";
    public static final String DATE = "Date";
    public static final String POLICY_NUMBER = "Policy_Number";
    public static final String FIRM_NAME = "Firm_Name";
    public static final String INSURED_NAME = "Insured_Name";
    public static final String CATEGORY = "Category_Selected";
    public static final String COMMENTS = "Comments";
    public static final String TEMPLATE_PATH="/apps/settings/notification-templates/email/JHINS/email/en.txt";
    public static final String TOPIC="Topic_Selected";
    public static final String IAM_A="Iam_a_Selected";
    public static final String SUBJECT="Subject";
    public static final String FORM_TYPE="form_type";
    public static final String EMAIL_US_FORM="Email_Us_Form";
    public static final String FEED_BACK_FORM="Feed_Back_Form";
    public static final String EMAIL_TEMPLATE_PATH="/apps/settings/notification-templates/email/JHINS/email/emailus.html";
    public static final String FEED_BACK_FORM_TEMPLATE_PATH="/apps/settings/notification-templates/email/JHINS/email/feedback.txt";
    public static final String REDIRECT_PATH="redirect_path";
    public static final String DOMAIN="domain";
    
}
