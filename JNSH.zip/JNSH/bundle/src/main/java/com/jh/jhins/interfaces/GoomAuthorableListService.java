package com.jh.jhins.interfaces;

import org.apache.sling.commons.json.JSONObject;

public interface GoomAuthorableListService {
	public String finalJsonData(String jsonResponse, String page, int statusCode, String role);
	public JSONObject commentsJson();

}
