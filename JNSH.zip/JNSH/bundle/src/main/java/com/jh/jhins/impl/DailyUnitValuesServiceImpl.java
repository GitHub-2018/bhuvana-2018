package com.jh.jhins.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth.ContentType;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhins.bean.FundDetailsBean;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.helper.FundDetails;
import com.jh.jhins.interfaces.DailyUnitValuesService;
import com.jh.jhins.interfaces.FundPerformanceService;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;
@Component
@Service
public class DailyUnitValuesServiceImpl implements DailyUnitValuesService {

	private static final Logger LOG = LoggerFactory.getLogger(DailyUnitValuesServiceImpl.class);
	
	@Reference
	private GOOMConfigService configService;
	
	@Reference
	private ResourceResolverFactory resolverFactory;
	
	@Reference
	FundPerformanceService fundservice;
	
	FundDetails fundetails =new FundDetails();
	
	public JSONObject dialyUnitValues(String productCode, String companyCode, String mProductFlag, String shortCode) {
		
		JSONObject jObject = new JSONObject();
		CloseableHttpClient httpClient =HttpClients.createDefault();
		try {
			String url = configService.getProperty(GOOMConstants.BY_PRODUCT_DAILYUNIT_VALUE_URL);
			JSONObject jsonObj = new JSONObject();
			if(null != productCode && !productCode.isEmpty()){
				jsonObj.put(GOOMConstants.PRODUCTCODE, productCode);
				jsonObj.put(GOOMConstants.COMPANYCODE, companyCode);
			}else{
				String product = getProductDetails(shortCode, companyCode);
				jsonObj.put(GOOMConstants.PRODUCTCODE, product);
				jsonObj.put(GOOMConstants.COMPANYCODE, companyCode);
			}
			LOG.debug(" Input jsonObj::::::"+jsonObj.toString());
			StringEntity input = new StringEntity(jsonObj.toString());
			String token = getOauthToken();
			HttpPost postRequest = new HttpPost(url);
			postRequest.setEntity(input);
			postRequest.addHeader("Authorization", "Bearer " + token);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);
			CloseableHttpResponse response = httpClient.execute(postRequest);
			String restServiceResponse = EntityUtils.toString(response.getEntity(), GOOMConstants.CHARSET);
			LOG.debug("Rest API Response::::"+restServiceResponse);	
			int statusCode=response.getStatusLine().getStatusCode();
			if(response.getStatusLine().getStatusCode() != 200){
				if(statusCode==403)
				{
					jObject = getUnavailableErrorJsonData(statusCode);
					//jObject.put("statusCode", statusCode);
				}
				else
				{
					jObject = new JSONObject(restServiceResponse);
					jObject.put("statusCode", statusCode);
				}
			}else{
				JSONObject responseJson = new JSONObject(restServiceResponse);
				String code= responseJson.getString(GOOMConstants.CODE);
				String message = responseJson.getString(GOOMConstants.MESSAGE);
				JSONArray fundArray = fundDetailsJSON(responseJson, mProductFlag);
				JSONObject productJsonObj = productsDetailsJSON(productCode, companyCode);
				productJsonObj.put(GOOMConstants.FUNDS, fundArray);
				jObject.put(GOOMConstants.CODE, code);
				jObject.put(GOOMConstants.STATUS_CODE, statusCode);
				jObject.put(GOOMConstants.MESSAGE, message );
				jObject.put(GOOMConstants.CONTENT, productJsonObj);
				LOG.debug("final jObject:::::::::"+jObject.toString());
			}
			httpClient.close();
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException", e);
		}catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		}catch (IOException e) {
			LOG.error("IOException", e);
		} catch (OAuthSystemException e) {
			LOG.error("IOException", e);
		} catch (OAuthProblemException e) {
			LOG.error("IOException", e);
		}finally{
			if(null != httpClient){
				try {
					httpClient.close();
				} catch (IOException e) {
					LOG.error("IOException", e);
				}
			}
		}
		return jObject;
	}
	//method input product short code and company code to get product code.
	private String getProductDetails(String shortCode, String companyCode) {
		String productCodeVal = null;
		String[] shortCodeVal = shortCode.split("-");
		LOG.debug("Product shortCodeVal::::::::::::::"+shortCodeVal[0]);
		Resource resource = getServiceResolver().getResource("/content/JHINS/en_US/config/productsinformation");
	   	Iterator<Resource> itr = resource.listChildren();
	   	while(itr.hasNext()){
	   	 Boolean flag = false;
	   	  Resource childResource = itr.next();
	   	  Resource pageResource =childResource.getResourceResolver().getResource(childResource.getPath()+"/jcr:content/par/productprofilecomp");
	   	  if(null != pageResource ){
	   		 // LOG.debug("pageResource:::::::"+pageResource.getName());
	   		  ValueMap resourceValMap =pageResource.getValueMap();
	   		  String productShortcode = resourceValMap.get(GOOMConstants.SHORTCODE).toString();
	   		  if(StringUtils.containsIgnoreCase(productShortcode, shortCodeVal[0]) && companyCode.equalsIgnoreCase(resourceValMap.get(GOOMConstants.COMPANYCODE).toString())){
	   			 productCodeVal = resourceValMap.get(GOOMConstants.PRODUCTCODE).toString();
	   			LOG.debug("productCodeVal::::::"+productCodeVal);
	   			flag = true;
	   		  }
	   	  }
	   	if(flag == true){
	   		  break;
	   	  }
	   	}
		
		return productCodeVal;
	}

	private JSONObject productsDetailsJSON(String productCode, String companyCode) {
		String path=null;
		String name= null;
		Resource resource = getServiceResolver().getResource("/content/JHINS/en_US/config/productsinformation");
	   	Iterator<Resource> itr = resource.listChildren();
	   	JSONObject productObj = new JSONObject();
	   	while(itr.hasNext()){
	   	  Boolean flag = false;
	   	  Resource childResource = itr.next();
	   	  Resource pageResource =childResource.getResourceResolver().getResource(childResource.getPath()+"/jcr:content/par/productprofilecomp");
	   	  if(null != pageResource ){
	   		  ValueMap resourceValMap =pageResource.getValueMap();
	   		  if(productCode.equalsIgnoreCase(resourceValMap.get(GOOMConstants.PRODUCTCODE).toString()) && companyCode.equalsIgnoreCase(resourceValMap.get(GOOMConstants.COMPANYCODE).toString())){
	   			 String productName =  resourceValMap.get(GOOMConstants.NAME).toString();
	   			 try {
					productObj.put(GOOMConstants.PRODUCT_NAME, productName);
					productObj.put(GOOMConstants.PRODUCTCODE, productCode);
					if("JHUSA".equalsIgnoreCase(companyCode)){
						productObj.put(GOOMConstants.COMPANYCODE, "0");
					}else if("JHNY".equalsIgnoreCase(companyCode)){
						productObj.put(GOOMConstants.COMPANYCODE, "94");
					}else{
						productObj.put(GOOMConstants.COMPANYCODE, "");
					}
					flag = true;
				} catch (JSONException e) {
					LOG.error("JSONException::::::",e);
				}
	   		  }
	   	  }
	   	  if(flag == true){
	   		  break;
	   	  }
	   }
		return productObj;
	}

	private JSONArray fundDetailsJSON(JSONObject jObject, String mProductFlag) {
		JSONArray newjson;
		String asOfDate=null;
		//JSONObject fundObj = new JSONObject();
		JSONArray fundObj = new JSONArray();
		List<FundDetailsBean> fundDetailsList = new ArrayList<FundDetailsBean>();
		
		String pagePath = null;
		if("Y".equalsIgnoreCase(mProductFlag)){
			pagePath =configService.getProperty(GOOMConstants.MGP_FUNDPROFILE_PATH);
		}else{
			pagePath =configService.getProperty(GOOMConstants.PRD_FUNDPROFILE_PATH);
		}
		try{
			newjson=jObject.getJSONObject(GOOMConstants.DETAILS).getJSONArray(GOOMConstants.DAILY_UNIT_VALUE);
	/*		asOfDate=jObject.getJSONObject("Details").getString("AsOfDate");
				asOfDate=DateHelper.formatDates(asOfDate,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);*/
			ResourceResolver resourceResolver = getServiceResolver();
			HashMap<String,String> riskDetails= fundetails.getRiskDetails(GOOMConstants.RISK_DETAILS_URL,resourceResolver);
			for(int i=0;i<newjson.length();i++){
				JSONObject tempObj = new JSONObject();
				JSONObject jsonIteration=newjson.getJSONObject(i);
				String fundCode=jsonIteration.getString(GOOMConstants.FUNDCODE);
				Boolean isFundExist = fundCheck(fundCode , pagePath, resourceResolver);
					if(isFundExist){
						FundDetailsBean fundDetail=fundetails.getFundDetails(pagePath,fundCode,resourceResolver);
						String riskCategory = fundDetail.getRisk();
						tempObj.put(GOOMConstants.FUND_NAME, fundDetail.getFundTitle());
						tempObj.put(GOOMConstants.FUND_CODE, fundDetail.getFundCode());
						tempObj.put(GOOMConstants.FUND_SHEET, fundDetail.getMorningStarPath());
						tempObj.put(GOOMConstants.RISK_CATEGORY, riskCategory);
						tempObj.put(GOOMConstants.RISK_ORDER, fundDetail.getRiskOrder());
						tempObj.put(GOOMConstants.RISK_COLOR_CODE, riskDetails.get(riskCategory));
						LOG.debug("tempObj:::::"+fundObj.toString());
						fundObj.put(tempObj);
					}
				}
			
			LOG.debug("fundArray:::::"+fundObj.toString());
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}catch (RepositoryException e) {
			LOG.error("RepositoryException", e);
		}
		return fundObj;
	}

	private ResourceResolver getServiceResolver(){
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(ResourceResolverFactory.SUBSERVICE, GOOMConstants.JHINS_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			//resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			} catch (LoginException e) {
				LOG.error("LoginException:", e);
			}
		return resourceResolver;
	}
	
	private Boolean fundCheck(String fundCode, String pagePath, ResourceResolver resourceResolver) {
		Boolean flagVal = false;
		Resource resource =resourceResolver.getResource(pagePath+"/"+fundCode);
		if(null != resource){
			String resourceName = resource.getName();
			if(fundCode.equalsIgnoreCase(resourceName)){
				flagVal = true;
			}
		}else{
			flagVal = false;
		}
		LOG.debug("Fund Exist :::"+flagVal);
		return flagVal;
	}
	
	private Boolean isErrorCode(int code) {
		boolean errorFlag = false;
		if (400 <= code && code < 600) {
			errorFlag = true;
		}
		return errorFlag;
	}
	
	private JSONObject getUnavailableErrorJsonData(int statusCode) {
		Page pagePath;
		JSONObject jObject=new JSONObject();
		Boolean errorCode = isErrorCode(statusCode);

		PageManager pageManager = getServiceResolver().adaptTo(PageManager.class);		
		pagePath = pageManager.getPage(GOOMConstants.FUND_PERFORMANCE_ERRORLIST_PATH);
		String message = null;
		GenericList list = pagePath.adaptTo(GenericList.class);
		String statusCodeVal = Integer.toString(statusCode);
		if (StringUtils.isBlank(statusCodeVal)) {
			statusCodeVal = GOOMConstants.DEFAULT;
		}
		message = list.lookupTitle(statusCodeVal);
		if(StringUtils.isBlank(message)){
			message = list.lookupTitle(GOOMConstants.DEFAULT);
		}
		try {
			jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_UNAVAILABLE);		
			jObject.put(GOOMConstants.MESSAGE, message);
			jObject.put("StatusCode", GOOMConstants.UNAVAILABLE);
		}catch (JSONException e) {			
			e.printStackTrace();
		}
		return jObject;
	}
	public String getOauthToken() throws OAuthSystemException, OAuthProblemException {
		OAuthClient client = new OAuthClient(new URLConnectionClient());
		CryptoBase64 decryptClientSecret = new CryptoBase64();
		String token="";
		try {
			String clientSecret = String.valueOf(decryptClientSecret.decrypt(configService.getProperty(GOOMConstants.OAUTH_CLIENT_SECRET)))
					.trim();

			OAuthClientRequest request = OAuthClientRequest
					.tokenLocation(configService.getProperty(GOOMConstants.OAUTH_TOKENLOCATION_PATH))
					.setGrantType(GrantType.CLIENT_CREDENTIALS)
					.setClientId(configService.getProperty(GOOMConstants.OAUTH_CLIENT_ID))
					.setClientSecret(clientSecret)				
					.buildBodyMessage();
			request.addHeader("ContentType", ContentType.JSON);
			token = client.accessToken(request, OAuthJSONAccessTokenResponse.class).getAccessToken();
		}
		catch (CryptoException e) {
			LOG.error("CryptoException:", e);
		}
		return token;

	}

	public JSONObject getFundDetails(JSONArray fundCodeList,String mProductFlag) {

		JSONArray fundDetailsArray= getFundDetailsJSON(fundCodeList, mProductFlag);
		JSONObject fundList = new  JSONObject();
		try {
			fundList.put("FundDetails", fundDetailsArray);
		} catch (JSONException e) {
			LOG.error("JSONException:", e);
		}
		return fundList;
	}

	private JSONArray getFundDetailsJSON(JSONArray fundCodeList, String mProductFlag) {

		String pagePath = null;
		JSONArray fundDetailsArray = new JSONArray();
		if("Y".equalsIgnoreCase(mProductFlag)){
			pagePath =configService.getProperty(GOOMConstants.MGP_FUNDPROFILE_PATH);
		}else{
			pagePath =configService.getProperty(GOOMConstants.PRD_FUNDPROFILE_PATH);
		}
		try {
			ResourceResolver resourceResolver = getServiceResolver();
			HashMap<String,String> riskDetails= fundetails.getRiskDetails(GOOMConstants.RISK_DETAILS_URL,resourceResolver);
			for(int i=0;i<fundCodeList.length();i++){
				JSONObject tempObj = new JSONObject();
				JSONObject jsonIteration=fundCodeList.getJSONObject(i);
				String fundCode=jsonIteration.getString(GOOMConstants.FUNDCODE);
				Boolean isFundExist = fundCheck(fundCode , pagePath, resourceResolver);
				if(isFundExist){
					FundDetailsBean fundDetail=fundetails.getFundDetails(pagePath,fundCode,resourceResolver);
					String riskCategory = fundDetail.getRisk();
					tempObj.put(GOOMConstants.FUND_NAME, fundDetail.getFundTitle());
					tempObj.put(GOOMConstants.FUND_CODE, fundDetail.getFundCode());					
					tempObj.put(GOOMConstants.FUND_SHEET, fundDetail.getMorningStarPath());										
					fundDetailsArray.put(tempObj);
				}
			}
		}
		catch (JSONException e) {
			LOG.error("JSONException:", e);
		} catch (RepositoryException e) {
			LOG.error("RepositoryException:", e);
		}
		return fundDetailsArray;
	}
	//Method to display IUL product fund details  
	
	public JSONObject getIULProductDetails(String productCode, String companyCode, SlingHttpServletRequest request) {
		
		JSONObject root = new JSONObject();
		JSONObject content = new JSONObject();
		JSONArray fundsArray = new JSONArray();
		try {
		Resource resource = getServiceResolver().getResource(GOOMConstants.IUL_PATH);
		
		QueryBuilder queryBuilder = request.getResourceResolver().adaptTo(QueryBuilder.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put(GOOMConstants.PATH, GOOMConstants.IUL_PATH);
		map.put(GOOMConstants.NODE_NAME, GOOMConstants.FUND_PROFILE_COMP);
		map.put(GOOMConstants.P_LIMIT, "-1");
		HashMap<String,String> riskDetails= fundetails.getRiskDetails(GOOMConstants.RISK_DETAILS_URL,getServiceResolver());
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), request.getResourceResolver().adaptTo(Session.class));
		SearchResult searchRes = query.getResult();
		Iterator<Resource> resources = searchRes.getResources();
	    while (resources.hasNext()) {
	    	JSONObject tempObj = new JSONObject();
	    	Resource childResource = resources.next();
	    	 ValueMap resourceValMap =childResource.getValueMap(); 
	    	 if(resourceValMap.containsKey(GOOMConstants.FUND_CODE)){
				tempObj.put(GOOMConstants.FUND_CODE, resourceValMap.get(GOOMConstants.FUND_CODE).toString());
	    	 }
	    	 if(resourceValMap.containsKey(GOOMConstants.FUND_TITLE)){
	    		 tempObj.put(GOOMConstants.FUND_TITLE, resourceValMap.get(GOOMConstants.FUND_TITLE).toString());
	    	 }
			if(resourceValMap.containsKey(GOOMConstants.RISK)){
				tempObj.put(GOOMConstants.RISK_CATEGORY, resourceValMap.get(GOOMConstants.RISK).toString());    		 
			}
			if(resourceValMap.containsKey("riskorder")){
				tempObj.put(GOOMConstants.RISK_ORDER, resourceValMap.get("riskorder").toString());
			}
			if(resourceValMap.containsKey("morningStar")){
				tempObj.put(GOOMConstants.FUND_SHEET, resourceValMap.get("morningStar").toString());
			}
			if(null != riskDetails.get(GOOMConstants.RISK)){
				tempObj.put(GOOMConstants.RISK_COLOR_CODE, riskDetails.get(resourceValMap.get(GOOMConstants.RISK).toString()));
			}
			fundsArray.put(tempObj);
	    }
	    content.put(GOOMConstants.PRODUCT_NAME, productCode);
	    content.put(GOOMConstants.PRODUCTCODE, productCode);
	    content.put(GOOMConstants.COMPANYCODE, companyCode);
	    content.put(GOOMConstants.FUNDS, fundsArray);
	    root.put(GOOMConstants.CODE, GOOMConstants.SUCCESS);
	    root.put(GOOMConstants.MESSAGE, GOOMConstants.SUCCESS_TXT);
	    root.put(GOOMConstants.CONTENT, content);
		} catch (JSONException e) {
			LOG.error("JSONException::::",e);
		} 
		return root;
	}
	
}
