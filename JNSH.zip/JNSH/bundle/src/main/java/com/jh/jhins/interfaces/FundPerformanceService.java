package com.jh.jhins.interfaces;

import java.text.ParseException;
import java.util.Date;

import org.apache.sling.api.resource.ResourceResolver;

public interface FundPerformanceService{
	public abstract String getJsonData(String productcode, String companycode, ResourceResolver resourceResolver,String resultType,String footNote) throws ParseException;
	public abstract String getDailyUnitJsonData(String productcode, String companycode, ResourceResolver resourceResolver,String resultType, String date,String footNote);
	
}