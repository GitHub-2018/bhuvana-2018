package com.jh.jhins.interfaces;

import com.jh.jhins.bean.AgentSearchBean;

public interface AgentSearchService {

	public abstract String agentSearch(AgentSearchBean agentSearchBean);
}
