package com.jh.jhins.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.interfaces.GoomAuthorableListService;
import com.jh.jhins.interfaces.JHINSFirmSupportTNCService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;

@Component
@Service
public class JHINSFirmSupportTNCServiceImpl implements JHINSFirmSupportTNCService {

	private static final Logger LOG = LoggerFactory.getLogger(JHINSFirmSupportTNCServiceImpl.class);
	public static final String LASTNAME = "LastName";
	public static final String SSN_NO = "LastFourSsn";
	public static final String NPN_NO = "Npn";
	public static final String APPLICATION_JSON = "application/json";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String CHARSET = "UTF-8";
	public static final String PRODUCERTERMS_AND_CONDITION = "producertermsandcondition";
	public static final String PRODUCER_HEADER_KEY = "producer.header.key";
	public static final String PRODUCER_HEADER_VALUE = "producer.header.value";
	public static final String FIRM_SUPPORT_URL = "firmsupport.url";

	@Reference
	private GOOMConfigService configService;

	@Reference
	private GoomAuthorableListService service;

	public String getJsonData(String lastName, String ssoNo, String npnNo, String role) {
		LOG.info("Start getFirmSupport/Superuser getJsonData method ");

		String respContent = null;
		try {
			LOG.info("inside try block");
			CryptoBase64 decryptPassword = new CryptoBase64();
			String key = configService.getProperty(PRODUCER_HEADER_KEY);
			String value = String.valueOf(decryptPassword.decrypt(configService.getProperty(PRODUCER_HEADER_VALUE)))
					.trim();
			String endPointUrl = configService.getProperty(FIRM_SUPPORT_URL);
			LOG.debug("Producer Terms and conditon Rest End POint URL :"+endPointUrl);
			JSONObject jsonObj = new JSONObject();
			try {
				jsonObj.put(LASTNAME, lastName);
				jsonObj.put(SSN_NO, ssoNo);
				jsonObj.put(NPN_NO, npnNo);
				LOG.debug("input Json:::::::::::::::::" + jsonObj.toString());
				StringEntity input = new StringEntity(jsonObj.toString());
				// input.setContentType(JHINSConstants.APPLICATION_JSON);
				respContent = getJsonResponse(input, key, value, endPointUrl, role);
			} catch (JSONException e) {
				LOG.error("JSONException", e);
			} catch (ParseException e) {
				LOG.error("ParseException", e);
			} catch (UnsupportedEncodingException e) {
				LOG.error("UnsupportedEncodingException", e);
			}
			LOG.debug("Firmsupport/Superuser final json data:::::::::::::::::::::" + respContent);

		} catch (CryptoException e) {
			LOG.error("CryptoException", e);
		}

		return respContent;
	}

	public String getJsonResponse(StringEntity input, String key, String value, String url, String role) {
		String responseData = null;
		try {
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(url);
			postRequest.setEntity(input);
			postRequest.addHeader(key, value);
			postRequest.addHeader(CONTENT_TYPE, APPLICATION_JSON);
			HttpResponse response = httpClient.execute(postRequest);
			responseData = EntityUtils.toString(response.getEntity(), CHARSET);
			String resultPage = PRODUCERTERMS_AND_CONDITION;
			if (response.getStatusLine().getStatusCode() != 200) {
				int statusCode = response.getStatusLine().getStatusCode();
				LOG.debug("Response code::::" + statusCode);
				responseData = service.finalJsonData(responseData, resultPage, statusCode, role);
			}
			httpClient.getConnectionManager().shutdown();
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		}

		return responseData;
	}

}
