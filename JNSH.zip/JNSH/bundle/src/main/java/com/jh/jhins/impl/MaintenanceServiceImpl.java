package com.jh.jhins.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Value;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.helper.DateHelper;
import com.jh.jhins.interfaces.MaintenanceService;

public class MaintenanceServiceImpl implements MaintenanceService {

	private static final Logger LOG = LoggerFactory.getLogger(MaintenanceServiceImpl.class);
	
	public boolean getStatus(Node maintenanceNode) {
		// TODO Auto-generated method stub
		boolean status = false;

		try {
				Node timingsNode = maintenanceNode.getNode(JHINSConstants.TIMINGS);
				NodeIterator nodeIterator = timingsNode.getNodes();
				Node timeNode = null;
				while(nodeIterator.hasNext()) {
					timeNode = nodeIterator.nextNode();
					String starttime = timeNode.getProperty(JHINSConstants.START_TIME).getValue().toString();
					String endtime = timeNode.getProperty(JHINSConstants.END_TIME).getValue().toString();
					String currentTime = getCurrentTime(); 
					
					Date start = new SimpleDateFormat(JHINSConstants.TIME_FORMAT, Locale.ENGLISH)
						        .parse(starttime);
					Date end = new SimpleDateFormat(JHINSConstants.TIME_FORMAT, Locale.ENGLISH)
				                .parse(endtime);
					Date current = new SimpleDateFormat(JHINSConstants.TIME_FORMAT, Locale.ENGLISH)
						        .parse(currentTime);
					if (start.compareTo(current) < 0 && end.compareTo(current) > 0 ) {
			           status = true;
			           break;
			        } 
				}
		} catch (PathNotFoundException e) {
			LOG.error("PathNotFoundException ");
		} catch (RepositoryException e) {
			LOG.error("RepositoryException");
		} catch (ParseException e) {
			LOG.error("Date format ParseException occured");
		}
		return status;
	}

	
	public String getMessage(Node maintenanceNode) {
		String message = StringUtils.EMPTY;
		try {
			message = maintenanceNode.getProperty("message").getValue().toString();				
		} catch (PathNotFoundException e) {
			LOG.error("PathNotFoundException occured");
		} catch (RepositoryException e) {
			LOG.error("RepositoryException occured");
		} 
		return message;
	}

	public JSONObject getJsonResponse(String domain, boolean status, String message) {
		// TODO Auto-generated method stub
		JSONObject json = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		JSONObject returnObj = new JSONObject();
		try {
			json.put(JHINSConstants.DOMAIN, domain);
			json.put(JHINSConstants.MAINTENANCE_STATUS, status);
			json.put(JHINSConstants.MESSAGE_TXT, message);
			
			jsonArray.put(json);
			returnObj.put(JHINSConstants.STATUS, jsonArray);
		} catch (JSONException e) {
			LOG.error("JSONException while creating json response");
		}
		return returnObj;
	}
	
	private static String getCurrentTime() {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(JHINSConstants.TIME_FORMAT);
		return sdf.format(cal.getTime());
    }	
}
