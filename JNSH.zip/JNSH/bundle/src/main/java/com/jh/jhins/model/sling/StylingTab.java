package com.jh.jhins.model.sling;

import javax.inject.Inject;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

/**
*
* Represents content item for Styling Tab
*
* @author diego.vilchis
*
*/
@Model(adaptables=Resource.class)
public class StylingTab {
    
    @Inject
    @Optional
    private String id;
    
    @Inject
    @Optional
    private String cssClass;
  

    public static <ModelType extends StylingTab> ModelType createSingleModel(Resource resource, Class<ModelType> clazz) {
        ModelType generalContent = null;
        if(resource != null) {
            generalContent = resource.adaptTo(clazz);
        }
        return generalContent;
    }
	
    public String getId() {
        return id;
    }
    
    public String getCssClass() {
        return cssClass;
    }
    
    /**
     * Returns a string representation of this {@code StylingTab}.
     *
     * @return String
     * @see ReflectionToStringBuilder#reflectionToString(Object)
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.reflectionToString(this);
    }
}