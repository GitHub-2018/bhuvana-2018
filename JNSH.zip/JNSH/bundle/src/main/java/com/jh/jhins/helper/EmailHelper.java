package com.jh.jhins.helper;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.jcr.Node;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jh.jhins.security.Crypto;
import com.jh.jhins.security.CryptoBase64;

public class EmailHelper {
	
private static final Logger LOG = LoggerFactory.getLogger(EmailHelper.class);
private static final Crypto crypto = new CryptoBase64(); 
	
	// Private constructor to avoid object creation
	private EmailHelper(){
		
	}
	
	public static final String getSuffixForInternalPages(final String path){
		return StringUtils.startsWith(path,"/content") ? ".html" : "";
	}
	
	private static Pattern[] patterns = new Pattern[] {
			// Script fragments
			Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
			// src='...'
			Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",
					Pattern.CASE_INSENSITIVE | Pattern.MULTILINE
							| Pattern.DOTALL),
			Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"",
					Pattern.CASE_INSENSITIVE | Pattern.MULTILINE
							| Pattern.DOTALL),
			// lonely script tags
			Pattern.compile("</script>", Pattern.CASE_INSENSITIVE),
			Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL),
			// eval(...)
			Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL),
			// expression(...)
			Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL),
			// javascript:...
			Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
			// vbscript:...
			Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
			// onload(...)=...
			Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL)};
	
	
	public static final String stripXSS(String attributeName, String value) {
		if (value != null) {
			
			//Avoid null characters
			value = value.replaceAll("\0", "");

			// Remove all sections that match a pattern
			for (Pattern scriptPattern : patterns) {
				
				value = scriptPattern.matcher(value).replaceAll("");
			}			
			
			Pattern pattern = Pattern.compile("^[^<>%]*$");
			Matcher matcher = pattern.matcher(value);
			if(!matcher.matches()){
				value = "";
			}
		}
		return value;
	}	
	
	
	public static final char[] encryptText(String textToEncrypt) throws Exception
	{
		return crypto.encrypt(textToEncrypt);
	}

	public static final String decryptText(String encryptedId) throws Exception
	{
		return new String(crypto.decrypt(encryptedId));
	}	
	

	public static boolean isValidHTMLURL(String pUrl) {

        try 
        {
            URL u = new URL(pUrl);
            // to test whether its a valid URL or not
            u.toURI();
            if(!StringUtils.endsWith(u.getPath(), "html")){
            	return false;
            }
        } 
        catch (Exception e) 
        {
            return false;
        }
        return true;
    }
	
	public static boolean isAuthorEnvironment(SlingSettingsService settingsService){
		 final Set<String> runmodes = settingsService.getRunModes();
		 for(String runMode : runmodes){
			 if(StringUtils.equalsIgnoreCase(runMode, "author")){
				 return true;
			 }
		 }
		 return false;
	}
	
	
	public static String addParameterToSearchString(String parameterName,boolean commaFlag){
		StringBuilder queryBuilder = new StringBuilder();
		if(commaFlag){
			queryBuilder.append(",");
		}
		queryBuilder.append("[");
		queryBuilder.append(parameterName);
		queryBuilder.append("]");
		return queryBuilder.toString();
	}	
	
	/**
	 * Converts the argument to lowercase and 
	 * seperate the words with underscore
	 * @param s
	 * @return
	 */
	public static String convertSpacewithUnderscore(String s) {
		// convert the user entered  value to lowercase and space to
		// underscore.
		return StringUtils.lowerCase(s).replaceAll(" ", "_");
	}
	
	/**
	 * Method to send error email
	 * 
	 * @param msgGatewayService
	 * @param session
	 * @param newParam TODO
	 * @param emailTemplatePath
	 * @param emailProps
	 * @param toList
	 * @param ccList
	 * @throws Exception
	 */
	/*public static void sendErrorEmail(MessageGatewayService msgGatewayService, Session session, String toAddress) throws Exception{
		// error email template
		String emailTemplatePath = ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_ERROR_TEMPLATE_PATH);
		// populate the email props map		
		Map<String,String> emailProps = new HashMap<String,String>();
		emailProps.put(EmailConstants.EMAIL_ENVIRONMENT_INFO,  ConfigUtil.INSTANCE.getEnvrionment());
		emailProps.put("message", "Error while sending an email");
		EmailUtil.sendEmail(msgGatewayService, session, emailTemplatePath , emailProps, toAddress);
	}
	
	public static void sendContactUsErrorEmail(MessageGatewayService msgGatewayService, Session session, String toAddress, Map<String,String> contactUsProps) throws Exception{
		String emailTemplatePath = ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_CONTACTUS_ERROR_TEMPLATE_PATH);
		// populate the email props map		
		Map<String,String> emailProps = new HashMap<String,String>();
		emailProps.put(EmailConstants.EMAIL_ENVIRONMENT_INFO,  ConfigUtil.INSTANCE.getEnvrionment());
		emailProps.put("timestamp",contactUsProps.get("date"));
		emailProps.put("option", contactUsProps.get("selectFieldValue"));
		emailProps.put("firstname", contactUsProps.get("firstName"));
		emailProps.put("suffix", contactUsProps.get("suffix"));
		emailProps.put("lastname", contactUsProps.get("lastName"));
		emailProps.put("emailid", contactUsProps.get("emailAddress"));
		// DE270 Fixes
		emailProps.put("accountid", contactUsProps.get("accountNumber"));
		emailProps.put("phoneNumber", contactUsProps.get("phoneNumber"));
		emailProps.put("address", contactUsProps.get("address"));
		emailProps.put("message", contactUsProps.get("contactMessage"));
		emailProps.put("custExperienceId", contactUsProps.get("custExperienceId"));
		EmailUtil.sendEmail(msgGatewayService, session, emailTemplatePath , emailProps, toAddress);
	}*/
	
	
	/**
	 * To exclude fields based on modifier in JSON output
	 * @param modifier - Modifier levels  - Modifier.PUBLIC, Modifier.PROTECTED, Modifier.PRIVATE, Modifier.ABSTRACT, Modifier.STATIC, Modifier.FINAL, Modifier.STRICT
	 * @return
	 */
	public static Gson createGsonObj(){	
		return new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
	}
	
	
	/*public static String getErrorPage(Dictionary<String, String> properties){
		return properties.get(EmailConstants.CONFIG_SITE_DOMAIN_URL) + GlobalConstants.ERROR_PAGE_PATH + ".html";	
	}*/
	
	public static HttpsURLConnection getSecureConnection(ResourceResolver resourceResolver, String apiURL) {
	
		 HttpsURLConnection con = null;
		 InputStream certificateNode=null;
		 
		try {
		    
		    CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
		    Resource dataResource = resourceResolver.getResource("/apps/settings/wcm/designs/JHINS/certificates/jhinvestmentscom.cer"); 
		    Node jcnode = dataResource.adaptTo(Node.class).getNode("jcr:content");
		    certificateNode = jcnode.getProperty("jcr:data").getBinary().getStream();

		    Certificate certificate = certificateFactory.generateCertificate(certificateNode);
		    if(certificateNode!=null){
		    	certificateNode.close();
		    }
		    String keyStoreType = KeyStore.getDefaultType();
		    KeyStore keyStore = KeyStore.getInstance(keyStoreType);
		    try {
				keyStore.load(null, null);
			} catch (Exception e) {
				LOG.error("Error while loading keystore", e);				
			}
		    keyStore.setCertificateEntry("ca", (java.security.cert.Certificate) certificate);

		    String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
		    TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
		    tmf.init(keyStore);

		    SSLContext context = SSLContext.getInstance("TLS");

		    context.init(null, tmf.getTrustManagers(), null);

		    URL obj = new URL(apiURL);
			con = (HttpsURLConnection) obj.openConnection();
			con.setSSLSocketFactory(context.getSocketFactory());
		
			
		} catch (Exception e) {
			if(certificateNode!=null){
		    	try {
					certificateNode.close();
				} catch (IOException e1) {
					LOG.error("IO Exception : ", e1);
				}
		    	certificateNode=null;
		    }
			if(con!=null){
				con.disconnect();
			}
			LOG.error("Error while establishing secure connection", e);				
		}
		return con;
}

	public static HttpsURLConnection getDummySecureConnection(String apiEndPoint) {
		LOG.info("By passing Secure connection using dummy certificates for URL requested ");
		HttpsURLConnection con = null;
		try {
			
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
				public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1) { }
				public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1) { }
			} };
			
			// Install the all-trusting trust manager
			SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
			// Create an ssl socket factory with our all-trusting manager
			SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
			// All set up, we can get a resource through https now:
			
            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);			

			URL obj = new URL(apiEndPoint);
			con = (HttpsURLConnection) obj.openConnection();
			// Tell the url connection object to use our socket factory which bypasses security checks
			con.setSSLSocketFactory(sslSocketFactory);			

			
			LOG.debug("Connection to the URL " + apiEndPoint + " is " + con);
		} catch (Exception e) {
			LOG.error("Error while establishing secure connection", e);
		}
		return con;
	}
}
