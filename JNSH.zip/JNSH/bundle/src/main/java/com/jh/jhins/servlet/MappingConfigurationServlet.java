package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
* @author 221274
*
*/

@SlingServlet(paths = "/bin/sling/jhins/mappingconfiguration", metatype = true, methods = HttpConstants.METHOD_POST)
@Properties({ @Property(name = "service.vendor", value = "JHBA"),
       @Property(name = "service.description", value = "MappingConfigurationServlet") })
public class MappingConfigurationServlet extends SlingAllMethodsServlet {

       private static final long serialVersionUID = 1L;
       private static final Logger LOG = LoggerFactory.getLogger(MappingConfigurationServlet.class);

       protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
                     throws ServletException, IOException {
    	   
    	   		LOG.debug("------MappingConfigurationServlet Start-------");
    	   		String PagePath = request.getParameter("pagePath");
    	   		LOG.debug("Question ID--->" + PagePath);
    	   		String path = PagePath+"/jcr:content/par";            
              
              response.setContentType("application/json");
              PrintWriter out = response.getWriter();
              try {

                     Resource resource = request.getResourceResolver().getResource(path);
                     Node node = resource.adaptTo(Node.class);
                     NodeIterator nodeIterator = node.getNodes();
                     String mappingQID = "";
                     String resourceType;

                     Map JSONmap = new HashMap<String, JSONObject>();
                     JSONObject mappingJSON = new JSONObject();
                     while (nodeIterator.hasNext()) {
                           Node mappingNode = nodeIterator.nextNode();
                           if (mappingNode.hasProperty("sling:resourceType")) {
                                  resourceType = mappingNode.getProperty("sling:resourceType").getString();
                                  if (resourceType.equals("JHINS/components/content/mapping-config")) {
                                         if (mappingNode.hasProperty("questionid")) {
                                                mappingQID = mappingNode.getProperty("questionid").getString();
                                                LOG.debug("mapping qid:" + mappingQID);
                                                // mappingJSON.put("mappingQID", mappingQID);
                                         }
                                         Node multiNode = mappingNode.getNode("multi");
                                         String mappingOpt;
                                         int count = 1;
                                         Map optionsMap = new HashMap<String, String>();
                                         NodeIterator mappingOptIterator = multiNode.getNodes();
                                         JSONObject mappingOptionsJSON = new JSONObject();
                                         while (mappingOptIterator.hasNext()) {
                                                Node mappingOptNode = mappingOptIterator.nextNode();
                                                if (mappingOptNode.hasProperty("mappingconfig")) {
                                                       mappingOpt = mappingOptNode.getProperty("mappingconfig").getString();
                                                       LOG.debug("mapping opt:" + mappingOpt);
                                                       //mappingOptions.put(mappingOpt);
                                                       optionsMap.put("option" + count, mappingOpt);
                                                       LOG.debug("optionsMap:" + optionsMap.toString());

                                                       count++;
                                                }
                                         }
                                         mappingOptionsJSON.put("options", optionsMap);
                                         JSONmap.put(mappingQID, mappingOptionsJSON);
                                  }
                           }
                     }
                     Iterator<String> mappingOptIterator = JSONmap.keySet().iterator();
                     while (mappingOptIterator.hasNext()) {
                           String key = mappingOptIterator.next();
                           mappingJSON.put(key, JSONmap.get(key));
                     }
                     out.write(mappingJSON.toString());
                     out.flush();
              } catch (Exception e) {
                     LOG.debug("Error" + e.getMessage());
              }

       }

       protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
                     throws ServletException, IOException {
              doPost(request, response);

       }

}

