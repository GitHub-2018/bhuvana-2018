
package com.jh.jhins.servlet;

import java.io.IOException;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.*;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.granite.ui.components.Config;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.EmptyDataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jh.jhins.constants.JHINSConstants;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import java.text.Collator;

@SlingServlet(paths = "/bin/sling/channeldropdown", metatype = true, methods = HttpConstants.METHOD_GET)
@Properties({ @Property(name = "service.description", value = "ChannelTags DropDown Servlet"),
	@Property(name = "service.vendor", value = "JHINS") })
/**
 * ChannelDropDownServlet  for getting
 *  the channel dropdown using datasource
 * 
 * 
 * 
 */
public class ChannelDropDownServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(ChannelDropDownServlet.class);
	
	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException  {
		
		final ResourceResolver resourceResolver = request.getResourceResolver();
		Config dsCfg = new Config(request.getResource().getChild(JHINSConstants.DATA_SOURCE));
		String path = dsCfg.get(JHINSConstants.PARAM_PATH);
	    Resource resource = resourceResolver.getResource(path);
	    if (ResourceUtil.isNonExistingResource(resource)) {
	        request.setAttribute(DataSource.class.getName(), EmptyDataSource.instance());
	        return;
	    }
	    List<KeysValues> dropdownList = new ArrayList<KeysValues>();
	    if (dsCfg.get(JHINSConstants.ADD_NONE, false)) {
	    	dropdownList.add(new KeysValues("", ""));
	    }
		LOG.info("ChannelTagsDropDown doGet method");
			try{
			TagManager tagManager = request.getResourceResolver().adaptTo(TagManager.class);
			if (resource != null) {
				Node node = resource.adaptTo(Node.class);
				if (node.hasNodes()) {
					NodeIterator iter = node.getNodes();
					while (iter.hasNext()) {
						Node childNode = iter.nextNode();
						Tag tag = tagManager.resolve(childNode.getPath());
						LOG.info("TAG BEAN DETAILS***" + tag.getTagID() + tag.getName());
						dropdownList.add(new KeysValues(tag.getTagID().toString(), tag.getTagID().toString()));
						if (tag.listChildren().hasNext()) {
							Iterator<Tag> tagIter = tag.listChildren();
							while (tagIter.hasNext()) {
								Tag childTag = tagIter.next();
								dropdownList.add(new KeysValues(childTag.getTagID().toString(), childTag.getTagID().toString()));
								LOG.info("child dropdownList" + dropdownList);
							}
						}
					}
				}
			}
		}

		catch (RepositoryException e) {
			LOG.error("Repository Exception", e);
		}
			 final Collator collator = Collator.getInstance(request.getLocale());
			    Collections.sort(dropdownList, new Comparator<KeysValues>() {
			        public int compare(KeysValues o1, KeysValues o2) {
			            return collator.compare(o1.value, o2.value);
			        }
			    });

			    @SuppressWarnings("unchecked")
			    DataSource ds = new SimpleDataSource(new TransformIterator(dropdownList.iterator(), new Transformer() {
					
					public Object transform(Object input) {
						try {
							KeysValues keyValue = (KeysValues) input;

			                ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
			                vm.put(JHINSConstants.TEXT, keyValue.key);
			                vm.put(JHINSConstants.VALUE, keyValue.value);

			                return new ValueMapResource(resourceResolver, new ResourceMetadata(), "nt:unstructured", vm);
			            } catch (Exception e) {
			                throw new RuntimeException(e);
			            }
					}
				}));
			    request.setAttribute(DataSource.class.getName(), ds);
			}
		}
		 class KeysValues {
		    String key;
		    String value;
		    
		    public KeysValues(String key, String value) {
		        this.key = key;
		        this.value = value;
		    }
		    
		 }		    