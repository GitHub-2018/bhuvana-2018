package com.jh.jhins.helper;

import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Modified;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.util.ConfigUtil;

/**
 * JHINS Email Configuration - sets all Email configurations
 * 
 * @author Cognizant
 *
 */
@Component(immediate = true, metatype = false)
public class JHINSEmailConfigHelper {
	private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	@Reference
	private SlingSettingsService slingSettingsService;	

	@Activate
	public void activate(Map<String, Object> mapCreated) {
		LOG.info("Activating JHINS bundle...");
		// get configuration values
		ConfigUtil.INSTANCE.setConfigProperties(mapCreated);
		
		StringBuilder content = new StringBuilder(); 
		
		for(String runMode : slingSettingsService.getRunModes()){
			content.append("RUN Mode -" + runMode);
			content.append(System.getProperty("line.separator"));
		}
		// get configuration values
		ConfigUtil.INSTANCE.setEnvrionment(content.toString());
		
		LOG.info("JHINS bundle activation complete. ");
	}

	@Modified
	public void modified(Map<String, Object> mapModified) {
		LOG.info("Modifying JHINS bundle...");
		// get configuration values
		ConfigUtil.INSTANCE.setConfigProperties(mapModified);
		LOG.info("JHINS bundle modification complete. ");
	}
}
