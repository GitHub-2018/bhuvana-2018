package com.jh.jhins.model.sling;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.scripting.SlingScriptHelper;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class represents RawHTML component data.
 *
 * @author yadanku
 */
@Model(adaptables=SlingHttpServletRequest.class)
public class RawHtml extends BaseModel {
    
	private static final long serialVersionUID = -8401689391342928936L;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RawHtml.class);

	@Default
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private String html;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private List<String> cssPaths;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private List<String> ieCssPaths;
    
    @ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
    private List<String> jsPaths;
    
    @SlingObject
    private SlingScriptHelper slingScriptHelper;
    
    private DesignTab design;
    
    @Inject
    @Named("log")
    private Logger logger;
     
    @PostConstruct
    public void activate() {
        design = DesignTab.createModel(resource.getChild("design"));
        
    }

    public String getHtml() {
        return html;
    }

    public List<String> getJsPaths() {
        return jsPaths;
    }

    public List<String> getCssPaths() {
        return cssPaths;
    }
    
    public DesignTab getDesign() {
        return design;
    }
    
    /**
     * Returns a string representation of this {@code RawHtml}.
     *
     * @return String
     * @see ReflectionToStringBuilder#reflectionToString(Object)
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.reflectionToString(this);
    }
}