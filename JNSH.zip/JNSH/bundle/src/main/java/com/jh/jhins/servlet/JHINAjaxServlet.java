package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.AssetConstants;
import com.jh.jhins.constants.ContactConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.dao.UserInfoDAO;
import com.jh.jhins.impl.JHINNewsBusinessServiceImpl;
import com.jh.jhins.impl.JHINSAssetBusinessServiceImpl;
import com.jh.jhins.impl.JHINSContactBusinessService;
import com.jh.jhins.interfaces.JHINBusinessService;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JHINS AJAX Servlet"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/JHINSAJAX" }),
		@Property(name = "service.vendor", value = "JHINS"),
		@Property(name = "sling.servlet.methods", value = "POST", propertyPrivate = true) })

public class JHINAjaxServlet extends SlingAllMethodsServlet {

	

	private static final Logger LOG = LoggerFactory.getLogger(JHINAjaxServlet.class);

	private static final long serialVersionUID = 1L;

	/**
	 * doGet
	 */
	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);

	}

	/**
	 * doPost Renders user login details and retrieves news / assets details
	 * based on type Returns JSON object to JSP
	 */
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		try {
			response.setContentType(NewsConstants.CONTENT_TYPE);
			String type = request.getParameter(JHINSConstants.PARAM_TYPE); //type of request coming in ; whether Asset or News
		//	String userId = request.getParameter(NewsConstants.PARAM_USERID);
		//	String firmId = request.getParameter(NewsConstants.PARAM_FIRMID);
			String currentPath=request.getParameter(NewsConstants.CURRENTPAGE);
			
			UserTO userTO = new UserTO();
			UserInfoDAO userInfoDAO = new UserInfoDAO();
			userTO = userInfoDAO.getUserTO(request,currentPath);
			//userTO.setUserID(userId); // this is been already set
			//userTO.setFirmID(firmId);
			
			Map<String, Object> mapObj = new HashMap<String, Object>();
			
			mapObj.put(JHINSConstants.USERTO, userTO);
			if (request.getParameter(JHINSConstants.PARAM_CHANNEL) != null) {
				mapObj.put(JHINSConstants.PARAM_CHANNEL,
						URLDecoder.decode(request.getParameter(JHINSConstants.PARAM_CHANNEL), "UTF-8"));
			}
			if (request.getParameter(JHINSConstants.PARAM_CHANNELS) != null) {
				mapObj.put(JHINSConstants.PARAM_CHANNELS,
						URLDecoder.decode(request.getParameter(JHINSConstants.PARAM_CHANNELS), "UTF-8"));
			}
			if (request.getParameter(JHINSConstants.PARAM_DATE) != null) {
				mapObj.put(JHINSConstants.PARAM_DATE,
						URLDecoder.decode(request.getParameter(JHINSConstants.PARAM_DATE), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_PRODUCT) != null) {
				mapObj.put(AssetConstants.PARAM_PRODUCT,
						URLDecoder.decode(request.getParameter(AssetConstants.PARAM_PRODUCT), "UTF-8"));
				//LOG.error("PARAM_PRODUCT *** "+ URLDecoder.decode(request.getParameter(AssetConstants.PARAM_PRODUCT), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_PRODUCT1) != null) {
				mapObj.put(AssetConstants.PARAM_PRODUCT1,
						URLDecoder.decode(request.getParameter(AssetConstants.PARAM_PRODUCT1), "UTF-8"));
				//LOG.error("PARAM_PRODUCT1 *** "+ URLDecoder.decode(request.getParameter(AssetConstants.PARAM_PRODUCT1), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_PRODUCT2) != null) {
				mapObj.put(AssetConstants.PARAM_PRODUCT2,
						URLDecoder.decode(request.getParameter(AssetConstants.PARAM_PRODUCT2), "UTF-8"));
				//LOG.error("PARAM_PRODUCT 2*** "+ URLDecoder.decode(request.getParameter(AssetConstants.PARAM_PRODUCT2), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_FUNCTIONALITY) != null) {
				mapObj.put(JHINSConstants.PARAM_FUNCTIONALITY,
						URLDecoder.decode(request.getParameter(JHINSConstants.PARAM_FUNCTIONALITY), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_LIMIT) != null) {
				mapObj.put(JHINSConstants.PARAM_LIMIT,
						URLDecoder.decode(request.getParameter(JHINSConstants.PARAM_LIMIT), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_TOPIC) != null) {
				mapObj.put(AssetConstants.PARAM_TOPIC,
						URLDecoder.decode(request.getParameter(AssetConstants.PARAM_TOPIC), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_TYPE) != null) {
				mapObj.put(JHINSConstants.PARAM_ASSET_TYPE,
						URLDecoder.decode(request.getParameter(AssetConstants.PARAM_TYPE), "UTF-8"));
			}
			if (request.getParameter(AssetConstants.PROSPECTUSES_TITLE) != null) {
				mapObj.put(AssetConstants.PROSPECTUSES_TITLE,  URLDecoder.decode(request.getParameter(AssetConstants.PROSPECTUSES_TITLE),"UTF-8"));
			}
			if (request.getParameter(AssetConstants.PROSPECTUSES_TYPE) != null) {
				mapObj.put(AssetConstants.PROSPECTUSES_TYPE,  URLDecoder.decode(request.getParameter(AssetConstants.PROSPECTUSES_TYPE),"UTF-8"));
			}
			if (request.getParameter(AssetConstants.PARAM_PATH) != null) {
				mapObj.put(JHINSConstants.PARAM_PATH,
						URLDecoder.decode(request.getParameter(JHINSConstants.PARAM_PATH), "UTF-8"));
			}
			
			if (request.getParameter(JHINSConstants.PARAM_STATE) != null) {
				mapObj.put(JHINSConstants.PARAM_STATE,  URLDecoder.decode(request.getParameter(JHINSConstants.PARAM_STATE),"UTF-8"));
			}
			
			if (request.getParameter(ContactConstants.PARAM_TAGPATH) != null) {
			mapObj.put(ContactConstants.PARAM_TAGPATH,  URLDecoder.decode(request.getParameter(ContactConstants.PARAM_TAGPATH),"UTF-8"));
			}
			if (request.getParameter(NewsConstants.PARAM_PAGE_NO) != null) {
				mapObj.put(NewsConstants.PARAM_PAGE_NO, URLDecoder.decode(request.getParameter(NewsConstants.PARAM_PAGE_NO),"UTF-8"));
			}
			
			mapObj.put(JHINSConstants.SLING_REQUEST, request);
			
			JSONObject json = new JSONObject();

			if (type.equals(JHINSConstants.NEWS_TYPE)) {

				JHINBusinessService serviceImpl = new JHINNewsBusinessServiceImpl();
				try {
					json = serviceImpl.getJSONResponse(mapObj);
				} catch (JSONException e) {
					LOG.error("Exception in JHINAjaxServlet for news type" , e);
				} catch (ParseException e) {
					LOG.error("Exception in JHINAjaxServlet for news type" , e);
				}

			}
			if(type.equals(JHINSConstants.CONTACT))
			{
				JHINSContactBusinessService contactService=new JHINSContactBusinessService();
				try {
					json=contactService.getJSONResponse(mapObj);
				} catch (JSONException e) {	
					LOG.error("Exception in JHINAjaxServlet for contact type" , e);
				}
			}
			if (type.equals(JHINSConstants.ASSET_TYPE)) {				
				JHINBusinessService assetService = new JHINSAssetBusinessServiceImpl();
				try {
					json = assetService.getJSONResponse(mapObj);
				} catch (JSONException e) {
					LOG.error("Exception in JHINAjaxServlet for asset type" , e);

				} catch (ParseException e) {
					LOG.error("Exception in JHINAjaxServlet for asset type" , e);

				}				
			}

			PrintWriter out = response.getWriter();

			out.println(json);
			out.flush();
		} catch (RepositoryException e) {
			LOG.error("Repoistory Exception in JHINAjaxServlet" , e);
		}

	}
}
