package com.jh.jhins.constants;

public class GOOMConstants {
	

	public static final String CONTENT_TYPE="Content-Type";
	public static final String CHARSET="UTF-8";
	public static final String PRODUCTCODE="productCode";
	public static final String SHORTCODE = "shortCode";
	public static final String COMPANYCODE="companyCode";
	public static final String BY_RESULT_TYPE="resultType";
	public static final String FUNCTIONALITY="functionality";
	public static final String BY_PRODUCT_MONTHLY_PERFORMANCE_URL="byproduct.monthlyperformance.url";
	public static final String BY_PRODUCT_QUATERLY_PERFORMANCE_URL="byproduct.quaterlyperformance.url";
	public static final String BY_PRODUCT_DAILYUNIT_VALUE_URL="byproduct.dailyunitvalue.url";
	public static final String BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE_URL="byproduct.historicaldailyunitvalue.url";
	public static final String JHVITMONTHLY_PERFORMANCE_URL="jhvitmonthlyperformance.url";
	public static final String JHVITQUARTERLY_PERFORMANCE_URL="jhvitquarterlyperformance.url";
	public static final String RISK_DETAILS_URL="/content/JHINS/en_US/config/risk-details/jcr:content/par";
	
	public static final String BY_PRODUCT_MONTHLY_PERFORMANCE="byProductMonthlyPerformance";
	public static final String BY_PRODUCT_QUATERLY_PERFORMANCE="byProductQuaterlyPerformance";
	public static final String BY_PRODUCT_DAILYUNIT_VALUE="byProductDailyUnitValue";
	public static final String BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE="byProductHistoricalDailyUnitValue";
	public static final String BY_SERIES_MONTHLY_PERFORMANCE="bySeriesMonthlyPerformance";
	public static final String BY_SERIES_QUATERLY_PERFORMANCE="bySeriesQuaterlyPerformance";	
	public static final String MONTHLY_PERFORMANCE_BYSERIES_VALUE="montlyperformance.byseries.value";
	
	public static final String APPLICATION_JSON="application/json";
	public static final String SERIES="series";
	public static final String BYPRODUCT="byProduct";
	public static final String BYSERIES="bySeries";
	public static final String PRODUCT_NAME="productName";
	public static final String FOOT_NOTE="footNote";
	public static final String RIDER="rider";
	public static final String PRODUCT_SERIES="productSeries";
	public static final String FUND_PROFILES_URL="fundprofiles.url";
	public static final String PRODUCER_HEADER_KEY = "producer.header.key";
	
	public static final String NET_CHARGE_POSITIVE="&#xe093;";
	public static final String NET_CHARGE_NEGATIVE="&#xe094;";
	public static final String NET_CHARGE_ZERO="&#x2212;";
	
	
	public static final String FUND_PROFILE_BASE_PATH="/content/JHINS/en_US/config/fundprofileinformation";
	public static final String RISK="risk";
	public static final String RISK_ORDER="riskOrder";
	public static final String MORNING_STAR_PATH="morningStarPath";
	public static final String MANAGEMENT_FEE="managementFee";
	public static final String FUND_TITLE="fundTitle";
	public static final String FUND_CODE="fundCode";
	public static final String FUND_MANAGER="fundManager";
	public static final String INCEPTION_DATE="incepDate";
	public static final String RISK_TITLE="riskTitle";
	public static final String RISK_COLOR_CODE="riskColorCode";
	public static final String NET_CHNAGE="netChangeVal";
	public static final String COLOR="color";
	public static final String FUND_IN_TABLE_FOOTNOTE="footnotes";
	
	
	public static final String AS_OF_DATE="AsofDate";
	public static final String DATE="date";
	public static final String INPUT_DATE_FORMAT_INCEPTION_DATE="yyyy-MM-dd";
	public static final String OUTPUT_DATE_FORMAT_INCEPTION_DATE="MMMM dd, yyyy";
	public static final String INPUT_DATE_FORMAT_DAILY_UNIT="mm/dd/yyyy";
	public static final String OUTPUT_DATE_FORMAT_DAILY_UNIT="yyyy-mm-dd";
	
	public static final String FOOT_NOTE_NUMBER="footnoteno";
	public static final String DESCRIPTION="description";
	public static final String NUMBERED_FOOT_NOTE = "numberedFootNotes";
	
	public static final String ESERVICE_URL = "eservice.url";
	public static final String FIRST_NAME = "FirstName";
	public static final String LAST_NAME = "LastName";
	public static final String EAMIL_ID = "EmailID";
	public static final String REQUESTED_PRODUCTS = "RequestedProducts";
	
	public static final String JHINS_SERVICE = "JHINSService";
    public static final String DEFAULT = "Default";
    public static final String CODE = "code";
    public static final String MESSAGE = "message";
    public static final String CONTENT = "Content";
	public static final String FUND_PERFORMANCE_ERRORLIST_PATH= "/apps/settings/wcm/designs/lists/fund-performance-error-configuration";
	public static final String NOTFOUND = "404";
	public static final String BADREQUEST = "400";
	public static final String SERVERERROR = "500";
	public static final String UNAVAILABLE = "403";
	public static final String CUSTOM_ERRORCODE_NOTFOUND = "6001";
	public static final String CUSTOM_ERRORCODE_SERVERERROR = "7001";
	public static final String CUSTOM_ERRORCODE_UNAVAILABLE = "6003";
	public static final String CUSTOM_DEFAULT_ERRORCODE_UNAVAILABLE = "8001";
	public static final String DETAILS = "details";
	
	public static final String NAME = "name";
	public static final String FUND_NAME = "fundName";
	public static final String FUND_SHEET = "fundSheet";
	public static final String FUNDS = "funds";
	public static final String STATUS_CODE = "statusCode";
	public static final String FIRM_ID = "firmId";
	public static final String PRD_FUNDPROFILE_PATH = "prd.fundprofiles.path";
	public static final String MGP_FUNDPROFILE_PATH = "mgp.fundprofiles.path";
	public static final String EDJ_FUNDPROFILE_PATH = "edj.fundprofiles.path";
	public static final String PRD = "PRD";
	public static final String EDJ = "EDJ";
	public static final String MGP = "MGP";
	public static final String DAILY_UNIT_VALUE = "dailyUnitValue";
	public static final String FUNDCODE = "fundCode";
	public static final String RISK_CATEGORY = "riskCategory";
	
	public static final String OAUTH_TOKENLOCATION_PATH="oauth.tokenLocation.path";
	public static final String OAUTH_CLIENT_ID="oauth.clientId";
	public static final String OAUTH_CLIENT_SECRET ="oauth.clientSecret";
	
	//Agent Search constants
	public static final String SUCCESS = "200"; 
	public static final String JWT_SERVICE_URL = "jwtservice.url";
	//public static final String OAUTH_CLIENT_ID = "oauth.clientId";
	public static final String OAUTH_CLIENT_SECRET_ID = "oauth.client.secret.id";
	public static final String OAUTH_TOKEN_PATH = "oauth.token.path";
	public static final String APP_ID = "appId";
	public static final String JWT_TARGET_URL="jwttarget.url";
	public static final String DSTO_SSO_CONN_URL="dsto.sso.conn.url";
	public static final String JWT_AUTHORIZATION_VALUE="jwt.authorization.value"; 
	
	public static final String SUCCESS_TXT = "Success";
	public static final String IUL_PATH = "/content/JHINS/en_US/config/iul";
	public static final String PATH = "path";
	public static final String NODE_NAME = "nodename";
	public static final String P_LIMIT = "p.limit";
	public static final String FUND_PROFILE_COMP = "fundprofilecomp*";
	
	public static final String PRODUCER_ROLE="Producer";
	public static final String PRODUCER_SUPPORT_ROLE="ProducerSupport";
	public static final String FIRM_SUPPORT_ROLE="FirmSupport";
	public static final String SUPERUSER_ROLE="SuperUser_SN";

	public static final String PRODUCERTANDC_OAUTH_CLIENT_ID="producerTandC.clientId";
	public static final String PRODUCERTANDC_OAUTH_CLIENT_SECRET_ID="producerTandC.clientSecret";
	
}
