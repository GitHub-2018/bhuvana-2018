/*
 * #%L
 * ACS AEM Commons Bundle
 * %%
 * Copyright (C) 2013 Adobe
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */
package com.jh.jhins.email.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrLookup;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.mail.SimpleEmail;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.email.EmailService;
import com.jh.jhins.email.EmailServiceConstants;
import com.day.cq.commons.mail.MailTemplate;
import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.jh.jhins.constants.*;
import com.jh.jhins.helper.EmailHelper;
import com.jh.jhins.util.ConfigUtil;
import com.jh.jhins.bean.*;

/**
 * ACS AEM Commons - E-mail Service A Generic Email service that sends an email
 * to a given list of recipients.
 */
@Component
@Service
public final class EmailServiceImpl implements EmailService {

	private static final String USER_AGENT = "Mozilla/5.0";
	private static final String UTF_TYPE = "UTF-8";

	private static final Logger LOG = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Reference
	private MessageGatewayService messageGatewayService;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	public List<String> sendEmail(final String templatePath, final Map<String, String> emailParams,
			final List<File> uploadedFiles, final String... recipients) {
		List<String> failureList = new ArrayList<String>();
		if (recipients == null || recipients.length <= 0) {
			throw new IllegalArgumentException("Invalid Recipients");
		}

		List<InternetAddress> addresses = new ArrayList<InternetAddress>(recipients.length);
		for (String recipient : recipients) {
			try {
				addresses.add(new InternetAddress(recipient));
			} catch (AddressException e) {
				LOG.warn("Invalid email address {} passed to sendEmail(). Skipping.", recipient);
			}
		}
		InternetAddress[] iAddressRecipients = addresses.toArray(new InternetAddress[addresses.size()]);
		List<InternetAddress> failureInternetAddresses = sendEmail(templatePath, emailParams, uploadedFiles,
				iAddressRecipients);

		for (InternetAddress address : failureInternetAddresses) {
			failureList.add(address.toString());
		}

		return failureList;
	}

	public List<InternetAddress> sendEmail(final String templatePath, final Map<String, String> emailParams,
			final List<File> uploadedFiles, final InternetAddress... recipients) {

		List<InternetAddress> failureList = new ArrayList<InternetAddress>();

		if (recipients == null || recipients.length <= 0) {
			throw new IllegalArgumentException("Invalid Recipients");
		}

		if (StringUtils.isBlank(templatePath)) {
			throw new IllegalArgumentException("Template path is null or empty");
		}
		Email email = getEmail(templatePath, emailParams, uploadedFiles);

		if (email == null) {
			throw new IllegalArgumentException("Error while creating template");
		}

		MessageGateway<Email> messageGateway = messageGatewayService.getGateway(email.getClass());
		ArrayList<InternetAddress> list = new ArrayList<InternetAddress>();
		Collections.addAll(list, recipients);
		try {
			email.setTo(list);
			LOG.debug("messageGateway %%" + messageGateway);
			messageGateway.send(email);
		} catch (EmailException e1) {
			// failureList.add(address);
			LOG.error("Exception sending email to ", e1);
		}

		return failureList;
	}

	private Email getEmail(String templatePath, Map<String, String> emailParams, List<File> uploadedFiles) {
		ResourceResolver resourceResolver = null;
		try {
			// resourceResolver =
			// resourceResolverFactory.getAdministrativeResourceResolver(null);

			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "JHINSWorkflowService");
			resourceResolver = resourceResolverFactory.getServiceResourceResolver(param);

			LOG.debug("resource resolver" + resourceResolver);
			final MailTemplate mailTemplate = MailTemplate.create(templatePath,
					resourceResolver.adaptTo(Session.class));

			if (mailTemplate == null) {
				LOG.warn("Email template at {} could not be created.", templatePath);
				return null;
			}

			Class<? extends Email> emailClass = templatePath.endsWith(".html") ? HtmlEmail.class : SimpleEmail.class;

			final Email email = mailTemplate.getEmail(StrLookup.mapLookup(emailParams), emailClass);

			if (emailParams.containsKey(EmailServiceConstants.SENDER_EMAIL_ADDRESS)
					&& emailParams.containsKey(EmailServiceConstants.SENDER_NAME)) {
				email.setFrom(emailParams.get(EmailServiceConstants.SENDER_EMAIL_ADDRESS),
						emailParams.get(EmailServiceConstants.SENDER_NAME));
			} else if (emailParams.containsKey(EmailServiceConstants.SENDER_EMAIL_ADDRESS)) {
				email.setFrom(emailParams.get(EmailServiceConstants.SENDER_EMAIL_ADDRESS));
			}

			try {
				if (emailClass.equals(HtmlEmail.class)) {
					// adds attachments
					if (uploadedFiles != null && uploadedFiles.size() > 0) {
						for (File aFile : uploadedFiles) {
							LOG.info("Attached file path is" + aFile.getPath());
							EmailAttachment emailAttachment = new EmailAttachment();
							emailAttachment.setDisposition(EmailAttachment.ATTACHMENT);
							emailAttachment.setPath(aFile.getPath());
							// emailAttachment.setDescription(""); // optional
							emailAttachment.setName(aFile.getName());
							((HtmlEmail) email).attach(emailAttachment);
						}
					}
				}
			} catch (Exception e) {
				LOG.error("Attachments couldn't battached to the mail ", e);
			}
			return email;

		} catch (Exception e) {
			LOG.error("Unable to construct email from template " + templatePath, e);
		} finally {
			if (resourceResolver != null) {
				resourceResolver.close();
			}
		}

		return null;
	}

	public List<InternetAddress> sendEmail(String templatePath, Map<String, String> emailParams,
			InternetAddress... recipients) {
		return sendEmail(templatePath, emailParams, null, recipients);
	}

	public List<String> sendEmail(String templatePath, Map<String, String> emailParams, String... recipients) {
		return sendEmail(templatePath, emailParams, null, recipients);
	}

	public String getOAUTHToken(String jsonInput, String apiEndPoint, ResourceResolver resourceResolver) {
		if (StringUtils.containsIgnoreCase(apiEndPoint, "https://")) {
			return getOAUTHTokenUsingHttps(jsonInput, apiEndPoint, resourceResolver);
		}
		HttpClient httpClient = null;
		PostMethod httpPostMethod = null;
		try {
			httpClient = new HttpClient();
			StringRequestEntity requestEntity = new StringRequestEntity(jsonInput, JHINSConstants.APPLICATION_JSON,
					JHINSConstants.CHARSET);
			httpPostMethod = new PostMethod(apiEndPoint);
			httpPostMethod.setRequestEntity(requestEntity);
			// Return the response body if the request is successfully executed.
			if (httpClient.executeMethod(httpPostMethod) == HttpStatus.SC_OK) {
				LOG.info("Successfully fetched data from the endpoint.");
				String httpPostResponse = JsonSanitizer.sanitize(httpPostMethod.getResponseBodyAsString());
				TokenResponse tokenResposnse = EmailHelper.createGsonObj().fromJson(httpPostResponse,
						TokenResponse.class);
				if (tokenResposnse.isSuccess()) {
					return tokenResposnse.getToken();
				} else {
					LOG.error(" OAuth Token request failed error message received {} " + tokenResposnse.getMessage()
					+ "<End Message>");
					return null;
				}
			} else {
				LOG.error(" OAuth Token request failed with non 200 status ");
				return null;
			}
		} catch (Exception e) {
			LOG.error("Error while getting authorization token", e);
		} finally {
			if (httpPostMethod != null) {
				httpPostMethod.releaseConnection();
				httpPostMethod = null;
			}
			httpClient = null;
		}
		return null;
	}

	private String getOAUTHTokenUsingHttps(String jsonInput, String apiEndPoint, ResourceResolver resourceResolver) {
		PostMethod post = null;
		int responseCode = -1;
		HttpsURLConnection con = null;
		BufferedReader in = null;
		OutputStream os = null;
		try {
			String isDummyCert = ConfigUtil.INSTANCE.getStringConfiguration(EmailServiceConstants.CONFIG_DUMMY_HTTPS,
					"Y");
			if (StringUtils.equalsIgnoreCase("Y", isDummyCert)) {
				con = EmailHelper.getDummySecureConnection(apiEndPoint);
			} else {
				con = EmailHelper.getSecureConnection(resourceResolver, apiEndPoint);

			}

			// add request header
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);
			con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			StringBuilder inputContent = new StringBuilder(jsonInput);
			// Send post request
			con.setDoOutput(true);

			try {
				os = con.getOutputStream();
				// os.write(inputContent.toString().getBytes());
				os.write(inputContent.toString().getBytes(UTF_TYPE));
			} finally {
				if (os != null) {
					safeClose(os);
				}
			}
			responseCode = con.getResponseCode();
			String inputLine;
			in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			StringBuilder responseContent = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {

				responseContent.append(inputLine);

			}

			// Return the response body if the request is successfully executed.
			if (responseCode == HttpStatus.SC_OK) {
				LOG.info("Successfully fetched data from the endpoint.");
				TokenResponse tokenResposnse = EmailHelper.createGsonObj().fromJson(responseContent.toString(),
						TokenResponse.class);
				if (tokenResposnse.isSuccess()) {
					return tokenResposnse.getToken();
				} else {
					LOG.error(" OAuth Token request failed error message received {} " + tokenResposnse.getMessage()
					+ "<End Message>");
					return null;
				}
			} else {
				LOG.error(" OAuth Token request failed with non 200 status ");
				return null;
			}
		} catch (Exception e) {
			LOG.error("Error while getting authorization token", e);
		} finally {
			if (con != null) {
				con.disconnect();
				con = null;
			}
			if (post != null) {
				post.releaseConnection();
				post = null;
			}
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
					LOG.error("Error while getting authorization token inside finally block", e);
				}
				in = null;
			}
		}
		return null;
	}

	public void safeClose(OutputStream os) {
		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public boolean sendEmail(String jsonEmailInput, String apiURL, String oauth, ResourceResolver resourceResolver) {
		HttpClient httpClient = null;
		PostMethod httpPostMethod = null;
		try {
			httpClient = new HttpClient();
			StringRequestEntity requestEntity = new StringRequestEntity(jsonEmailInput, JHINSConstants.JSON_BODY_TYPE,
					JHINSConstants.UTF_CHARSET);
			httpPostMethod = new PostMethod(apiURL);
			String headerValue = "Bearer " + oauth;
			httpPostMethod.addRequestHeader(JHINSConstants.AUTHORIZATION, headerValue);
			httpPostMethod.setRequestEntity(requestEntity);
			int HTTP_STATUS = httpClient.executeMethod(httpPostMethod);
			LOG.info(" HTTP_STATUS {}", HTTP_STATUS);
			if (HTTP_STATUS == HttpStatus.SC_OK) {
				String response = httpPostMethod.getResponseBodyAsString();
				LOG.info("inside SC OK. response is {}", response);
				TokenResponse tokenResposnse = EmailHelper.createGsonObj().fromJson(response, TokenResponse.class);
				if (tokenResposnse.isSuccess()) {
					return true;
				} else {
					LOG.error(" Email failed error message received {} ", tokenResposnse.getMessage());
					return false;
				}
			} else {
				LOG.error(" Email request failed with non 200 status ");
				return false;
			}
		} catch (Exception e) {
			LOG.error("Error while sending email", e);
		} finally {
			if (httpPostMethod != null) {
				httpPostMethod.releaseConnection();
				httpPostMethod = null;
			}
			httpClient = null;
		}
		return false;
	}

}
