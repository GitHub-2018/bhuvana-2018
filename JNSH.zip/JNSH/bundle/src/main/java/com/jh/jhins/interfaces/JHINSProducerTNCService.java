package com.jh.jhins.interfaces;

public interface JHINSProducerTNCService {

	public abstract String getJsonData(String profileID, String userRole);

}
