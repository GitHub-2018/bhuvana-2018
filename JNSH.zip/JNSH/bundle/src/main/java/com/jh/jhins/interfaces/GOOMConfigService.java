package com.jh.jhins.interfaces;

public interface GOOMConfigService {

	public String getProperty(final String property);
}
