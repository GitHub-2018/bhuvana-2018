package com.jh.jhins.dao;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.http.Cookie;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.request.RequestPathInfo;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.helper.JHPageHelper;

public  class UserInfoDAO  {
	
	/*+getUserDetails(inout userTO : UserTO)
	+getUserNews(inout userTO : UserTO)
	+getUserResource(inout userTO : UserTO)
	+getUserFavourite(inout userTO : UserTO)
	+setUserDetail(in userTO : UserTO)
	+setUserNews(in userTO)
	+serUserResource(in userTO : UserTO)
	+setUserFavourite(in userTO : UserTO)*/

	private static final Logger LOG = LoggerFactory.getLogger(JHPageHelper.class);
	public UserTO getUserTO(SlingHttpServletRequest request){
		LOG.debug("Starting of getUserTO method");
		
		RequestPathInfo requestPathInfo= request.getRequestPathInfo();
		String path= requestPathInfo.getResourcePath();
		LOG.debug("Path obtained from getRequestPathInfo :"+path);
		
		ResourceResolver resolver= request.getResourceResolver();
		PageManager pagemanager=resolver.adaptTo(PageManager.class);
		
		Page currentPath= pagemanager.getContainingPage(resolver.getResource(path));
		LOG.debug("CurrentPage path :"+currentPath);
			UserTO userTo = new UserTO();
			if(null!=currentPath){
				Page parentpage = currentPath.getAbsoluteParent(3);
				LOG.debug("Parent page is :" +parentpage);
				if(null!=parentpage){
					Tag[] tags = parentpage.getTags();
					if(null!= tags){
						for(int i=0; i<tags.length; i++){
							Tag tag = tags[i];
							LOG.debug("tagid:: "+tag);
							if(null!=tag && tag.getTagID().startsWith(JHINSConstants.JHINS_FIRM)){
								userTo.setFirmID(tag.getTagID());
								userTo.setFirmTag(tag);
								break;
							}else{
								continue;
							}
						}
					}
				}
			}
		
/*			UserTO userTo = new UserTO();
			Enumeration<String> headerNames = request.getHeaderNames();
			TagManager tagManager = request.getResourceResolver().adaptTo(TagManager.class);
			String groupNames="";
			String firmIndicator="";
			String group=null;
			String[] groups = null;
			while (headerNames.hasMoreElements()) {
				String key = null;
				try {
					key = URLDecoder.decode((String) headerNames.nextElement(),"UTF-8");
				} catch (UnsupportedEncodingException e) {
					LOG.error("Unsupported Encoding Exception " , e);
				}
				LOG.info("||IN || getUserTO|| Key Value Is||"+key);
				if(key != null){
				if(key.equalsIgnoreCase(JHINSConstants.HEADER_IV_USER))
				{
					userTo.setUserID(request.getHeader(key));
					LOG.info("||IN || getUserTO|| If Key Value equals to HEADER_IV_USER ||"+request.getHeader(key));
				}
				else if(key.equalsIgnoreCase(JHINSConstants.HEADER_IV_GROUPS)){
					LOG.info("||IN || getUserTO|| If Key Value equals to HEADER_IV_GROUPS|| "+request.getHeader(key));
					groupNames = request.getHeader(key);
					if(StringUtils.isNotEmpty(groupNames)){
						if(groupNames.indexOf(",")>0){
							groups = groupNames.split(",");
							if(null!=groups && groups.length>0){
								LOG.info("||IN || getUserTO|| groups.length ||"+groups.length);
								for(int i=0; i<groups.length; i++){
									group =  groups[i];
									LOG.info("||IN || getUserTO|| group value||i value ||"+group+i);
									if(JHINSConstants.HEADER_GROUP_EDJONES.equals(group)){
										LOG.info("||IN || getUserTO|| If Group Value equals to HEADER_GROUP_EDJONES||i value ||"+group+i);
										userTo.setFirmID(JHINSConstants.FIRM_EDJONES);
										userTo.setFirmTag(tagManager.resolve(JHINSConstants.FIRM_EDJONES));									
										break;
									}
								}
							}
						}
						else
			            {
							LOG.info("||IN || getUserTO|| user has only one group||"+groupNames);
							group = groupNames;
							if(JHINSConstants.HEADER_GROUP_EDJONES.equals(group)){
								LOG.info("Edjones group"+group);
								userTo.setFirmID(JHINSConstants.FIRM_EDJONES);
								userTo.setFirmTag(tagManager.resolve(JHINSConstants.FIRM_EDJONES));									
								break;
							}
			            }
					
						
					}
				}
				
				else if(key.equalsIgnoreCase(JHINSConstants.HEADER_FIRM_INDICATOR)){
					firmIndicator = request.getHeader(key);
					LOG.info("||IN || getUserTO|| If Key Value equals to HEADER_FIRM_INDICATOR ||"+request.getHeader(key));
					if(JHINSConstants.HEADER_FIRMINDICATOR_MGROUP.equals(firmIndicator)){
						LOG.info("||IN || getUserTO|| If Group Value equals to HEADER_FIRMINDICATOR_MGROUP||i value ||"+request.getHeader(key));
						userTo.setFirmID(JHINSConstants.FIRM_MGROUP);
						userTo.setFirmTag(tagManager.resolve(JHINSConstants.FIRM_MGROUP));
					}
				}
			}
			}*/
			LOG.debug("End of getUserTO method");
			return userTo;
		}
	
	/**
	 * The user gets currentpage and returns userto
	 * @return
	 */
	
	public UserTO getUserTO(SlingHttpServletRequest request,String currentPath){
		LOG.debug("Inallnews---- overloaded method"+currentPath);
		LOG.debug("CurrentPage path :"+currentPath);
		ResourceResolver resolver= request.getResourceResolver();
		PageManager pagemanager=resolver.adaptTo(PageManager.class);
		Page currentPage= pagemanager.getContainingPage(resolver.getResource(currentPath));
			UserTO userTo = new UserTO();
			if(null!=currentPage){
				Page parentpage = currentPage.getAbsoluteParent(3);
				LOG.debug("Parent page is :" +parentpage);
				if(null!=parentpage){
					Tag[] tags = parentpage.getTags();
					if(null!= tags){
						for(int i=0; i<tags.length; i++){
							Tag tag = tags[i];
							LOG.debug("tagid:: "+tag);
							if(null!=tag && tag.getTagID().startsWith(JHINSConstants.JHINS_FIRM)){
								userTo.setFirmID(tag.getTagID());
								userTo.setFirmTag(tag);
								break;
							}else{
								continue;
							}
						}
					}
				}
			}
			return userTo;
	}
	
	/**
	 * The user preference where he needs to be redirected once he logsin
	 * @return
	 */
	public String getUserPreferenceSetting(SlingHttpServletRequest slingRequest) {
		String userPref = "ltc";
		/*Need to write LOGIC TO FETCH THE VALUES FROM THE DB ONCE THE USER PREF IS SET */
		
		
		/* End*/
		
		return userPref;
		

	}
public ArrayList<String> getUserViews(SlingHttpServletRequest request){
		
		Enumeration<String> headerNames = request.getHeaderNames();
		ResourceResolver resourceResolver = request.getResourceResolver();
		String groupNames="";
		String group=null;
		String[] groups = null;
		ArrayList<String> viewList = new ArrayList<String>();
		ArrayList<String> headerItemsList = new ArrayList<String>();
		//String groupsName = "\"Producers\",\"EJProducers\"";
		headerItemsList.add(JHINSConstants.HEADER_IV_GROUPS);
		//headerItemsList.add("firmindicator");
		headerNames = Collections.enumeration(headerItemsList);
		while (headerNames.hasMoreElements()) {
			String key = null;
			try {
				key = URLDecoder.decode((String) headerNames.nextElement(),"UTF-8");
			} catch (UnsupportedEncodingException e) {
				LOG.error("Exception in URL Decoding",e);
			}
			LOG.debug("||IN || getUserViews|| Key Value Is||"+key);
			if(key != null){
				Resource keyResource = resourceResolver.getResource(JHINSConstants.ETC_HEADERS_NODE_PATH+key);
			if(keyResource!=null){
				LOG.debug("||IN || getUserViews|| Key Resource not null||");
				if(key.equalsIgnoreCase(JHINSConstants.HEADER_IV_GROUPS)){
					groupNames = request.getHeader(key);
					//groupNames =  "\"Producers\",\"EJProducers\"";
					if(StringUtils.isNotEmpty(groupNames)){					
						if(groupNames.indexOf(",")>0){
							groups = groupNames.split(",");
							if(null!=groups && groups.length>0){
								for(int i=0; i<groups.length; i++){
									group =  groups[i];
									group = group.replace("\"", "");
									LOG.debug("||IN || getUserViews|| group value||i value ||"+group+i);
									LOG.debug("||IN || getUserViews||config nodepath ||"+JHINSConstants.ETC_HEADERS_NODE_PATH+key+"/"+group+JHINSConstants.ETC_LIST_ITEM_PATH);
									Resource configNode = resourceResolver.getResource(JHINSConstants.ETC_HEADERS_NODE_PATH+key+"/"+group+JHINSConstants.ETC_LIST_ITEM_PATH);
									if(null!=configNode){
										viewList.add(ResourceUtil.getValueMap(configNode).get(JHINSConstants.VIEW_PROPERTY,String.class));
									}
								}
							}
						}else{
							group = groupNames;
							LOG.debug("||IN || getUserViews|| group value||value ||"+group);
							Resource configNode = resourceResolver.getResource(JHINSConstants.ETC_HEADERS_NODE_PATH+key+"/"+group+JHINSConstants.ETC_LIST_ITEM_PATH);
							if(null!=configNode){
								LOG.info("||IN || getUserViews|| config node not null||");
								viewList.add(ResourceUtil.getValueMap(configNode).get(JHINSConstants.VIEW_PROPERTY,String.class));
							}
						}
					}
				}else{
					group = request.getHeader(key);
					LOG.debug("||IN || getUserViews|| group value||value ||"+group);
					Resource configNode = resourceResolver.getResource(JHINSConstants.ETC_HEADERS_NODE_PATH+key+"/"+group+JHINSConstants.ETC_LIST_ITEM_PATH);
					if(null!=configNode){
						LOG.info("||IN || getUserViews|| config node not null||");
						viewList.add(ResourceUtil.getValueMap(configNode).get(JHINSConstants.VIEW_PROPERTY,String.class));
					}
				}
			}

		}
		}
		return viewList;
	}
public String getPreferredView(SlingHttpServletRequest request){
	
	Cookie[] cookies = request.getCookies();
    String name = null;
    String value = null;
	 
	String defaultView = null;
	String multiView = null;
	if(cookies!=null){
		for (int i = 0; i < cookies.length; i++) {
			  name = cookies[i].getName();
			  LOG.debug("||IN || getPreferredView|| cookie||" + name);
			  if(JHINSConstants.COOKIE_USER_VIEW.equals(name)){
				  value = cookies[i].getValue();
				  return value;
			  }else{
				  continue;
			  }
			 
		}
	}
	
	ArrayList<String> views = getUserViews(request);

	ResourceResolver resourceResolver = request.getResourceResolver();
	
	if(null!=views && views.size()>0){
		LOG.info("||IN || getPreferredView|| size||" + views.size());
		if(views.size()==1){
			defaultView = views.get(0);
			LOG.info("||IN || getPreferredView|| defaultView||" + defaultView);
		}else
		{
			multiView = StringUtils.join(views, ',');
			LOG.info("||IN || getPreferredView|| multiView||" + multiView);
			Resource viewsResource = resourceResolver.getResource(JHINSConstants.ETC_VIEWS_NODE_PATH);
			if(null!=viewsResource){
				LOG.info("||IN || getPreferredView|| viewsResource|| not null||");
				Iterator<Resource> items = viewsResource.listChildren();
				while(items.hasNext()){
					Resource item = (Resource)items.next();
					ValueMap properties = item.adaptTo(ValueMap.class);
					String jcrTitle = properties.get("jcr:title",String.class);
					if(multiView.equals(jcrTitle)){
						defaultView = properties.get(JHINSConstants.VIEW_PROPERTY,String.class);
						LOG.info("||IN ||getPreferredView||  getDefaultView||"+defaultView);
					break;
					}else{
						continue;
					}
				}
			}
			
		}
	}
	return defaultView;
	
}
}



