package com.jh.jhins.servlet;

import java.io.IOException;
import java.util.Dictionary;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.JHINSConstants;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = JHINSConstants.SERVICE_DESCRIPTION, value = "JHInsContentStreamServlet"),
	@Property(name = JHINSConstants.SLING_SERVLET_PATH, value = { "/bin/sling/JHINSContentStream" }),
	@Property(name = JHINSConstants.FIRM_ID_TEXT, value = { "FirmA", "FirmB", "FirmC", "FirmD" }),
	@Property(name = JHINSConstants.FIRM_ID_VALUE, value = { "firma", "firmb", "firmc", "firmd" }),
	@Property(name = JHINSConstants.IDENTITYSOURCE_ID_TEXT, value = { "IdA", "IdB", "IdC", "IdD" }),
	@Property(name = JHINSConstants.IDENTITYSOURCE_ID_VALUE, value = { "idsrca", "idsrcb", "idsrcc", "idd" }),
	@Property(name = JHINSConstants.SERVICE_VENDOR, value = "JHINS"),
	@Property(name = JHINSConstants.SLING_SERVLET_SELECTORS, value = { "firm", "idSrc" }),
	@Property(name = JHINSConstants.SLING_SERVLET_METHOD, value = "GET", propertyPrivate = true) })

/**
 * JHInsContentStreamServlet for the getting the firm ids and identity sources
 *
 *
 */
public class JHInsContentStreamServlet extends SlingAllMethodsServlet {
	private static Logger LOG = LoggerFactory.getLogger(JHInsContentStreamServlet.class);

	private static final long serialVersionUID = 1L;
	/**
	 * Method to fetch the sling properties
	 *
	 */

    private static Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		synchronized (context) {
			properties = context.getProperties();
		}
	}

	/**
	 * doGet method
	 */

	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		Object[] firmobjArr = { properties.get("firm.id.text") };
		Object[] firmValobjArr = { properties.get("firm.id.value") };
		Object[] idSrcobjArr = { properties.get("identitySource.id.text") };
		Object[] idSrcValobjArr = { properties.get("identitySource.id.value") };
		String[] firmIdValues = null;
		String[] firmIdTexts = null;
		String[] identitySourceIDTexts = null;
		String[] identitySourceIDValues = null;

		for (Object firmtxtobj : firmobjArr) {
			if (firmtxtobj instanceof String[]) {
				firmIdTexts = (String[]) firmtxtobj;
			}

		}
		for (Object firmvalobj : firmValobjArr) {
			if (firmvalobj instanceof String[]) {
				firmIdValues = (String[]) firmvalobj;
			}

		}
		for (Object idsrctxtobj : idSrcobjArr) {
			if (idsrctxtobj instanceof String[]) {
				identitySourceIDTexts = (String[]) idsrctxtobj;
			}

		}
		for (Object idsrcValobj : idSrcValobjArr) {
			if (idsrcValobj instanceof String[]) {
				identitySourceIDValues = (String[]) idsrcValobj;
			}

		}
		JSONArray jsonArray = new JSONArray();
		response.setContentType(JHINSConstants.APPLICATION_JSON);
		response.setCharacterEncoding(JHINSConstants.CHARSET);
		String selectorsValue = request.getRequestPathInfo().getSelectorString();
		LOG.debug("selectorsValue" + selectorsValue);

		if (selectorsValue.equalsIgnoreCase(JHINSConstants.PARAM_FIRM)) {
			if (firmIdValues != null && firmIdTexts != null) {
				for (int i = 0; i < firmIdValues.length; i++) {
					JSONObject jsonObject = null;
					try {
						jsonObject = new JSONObject();
						jsonObject.put(JHINSConstants.TEXT, firmIdTexts[i]);
						jsonObject.put(JHINSConstants.VALUE, firmIdValues[i]);
					} catch (JSONException e) {
						LOG.error("JSONException");
					}
					jsonArray.put(jsonObject);
				}

			}


		}
		else {
			if (identitySourceIDValues != null && identitySourceIDTexts != null) {
				for (int i = 0; i < identitySourceIDTexts.length; i++) {
					JSONObject jsonsObject = null;
					try {
						jsonsObject = new JSONObject();
						jsonsObject.put(JHINSConstants.TEXT, identitySourceIDTexts[i]);
						jsonsObject.put(JHINSConstants.VALUE, identitySourceIDValues[i]);
					} catch (JSONException e) {
						LOG.error("JSONException");
					}
					jsonArray.put(jsonsObject);
				}

			}

		}

		response.getWriter().write(jsonArray.toString());
	}

}


	
