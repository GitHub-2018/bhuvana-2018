package com.jh.jhins.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.interfaces.GoomAuthorableListService;
import com.jh.jhins.interfaces.JHINSProducerTNCService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;

@Component
@Service
public class JHINSProducerTNCServiceImpl implements JHINSProducerTNCService {

	private static final Logger LOG = LoggerFactory.getLogger(JHINSProducerTNCServiceImpl.class);
	private static final String CONTENT_TYPE="Content-Type";
	public static final String PRODUCER_URL="producer.url";
	public static final String PRODUCER_SUPPORT_URL="producerSupport.url";
	public static final String PRODUCER = "Producer";
	public static final String PRODUCER_SUPPORT = "ProducerSupport";
	public static final String USER_PROFILE_ID = "UserProfileID";
	public static final String PRODUCER_HEADER_KEY = "producer.header.key";
	public static final String PRODUCER_HEADER_VALUE = "producer.header.value";
	public static final String PRODUCERTERMS_AND_CONDITION = "producertermsandcondition";
	
	@Reference
	private GOOMConfigService configService;
	
	@Reference
	private GoomAuthorableListService service;

	public String getJsonData(String profileId, String userRole) {
	
		LOG.info("Start getProducerJsonData service ");
		String resString = null;
		try {
			LOG.info("inside try block");
			CryptoBase64 decryptPassword = new CryptoBase64();
			String key = configService.getProperty(PRODUCER_HEADER_KEY);
			String value = String.valueOf(decryptPassword.decrypt(configService.getProperty(PRODUCER_HEADER_VALUE))).trim();
			String endPointUrl = getEndPointUrl(userRole);
			String id = profileId;
			if(PRODUCER.equalsIgnoreCase(userRole)){
				resString = getProducerJsonData(key,value, endPointUrl, id, userRole);
			}else if(PRODUCER_SUPPORT.equalsIgnoreCase(userRole)){
				resString = getProducerSupportJsonData(key,value, endPointUrl, id, userRole);
			}
			LOG.debug("final json Response:::::::::::::::::"+resString);
		}catch (CryptoException e) {
				LOG.error("CryptoException", e);
			}
		LOG.info("End getProducerJsonData serivce ");
		return resString;
	}
	

	public String getEndPointUrl(String userRole){
		
		String url= "";
		if(PRODUCER.equalsIgnoreCase(userRole)){
			url = configService.getProperty(PRODUCER_URL);
		}else if(PRODUCER_SUPPORT.equalsIgnoreCase(userRole)){
			url = configService.getProperty(PRODUCER_SUPPORT_URL);
		}
		LOG.debug("Producer Terms and conditon Rest End POint URL :"+url);
		return url;
	}
	
	private String getProducerJsonData(String key, String value, String url, String id, String userRole) {
		String jsonData= null;
		try{
			HttpClient client = new HttpClient();
			LOG.debug("url + id::::::"+ url + id);
			HttpMethod method = new GetMethod(url+id);
			method.addRequestHeader(key, value);
			client.executeMethod(method);
			byte[] responseBody = method.getResponseBody();
			jsonData = new String(responseBody);
			LOG.debug("Rest service response ::::"+jsonData.toString());
			 String resultPage = PRODUCERTERMS_AND_CONDITION;
			 if (method.getStatusCode() != 200) {
					int statusCode = method.getStatusLine().getStatusCode();
					LOG.debug("Response code::::" + method.getStatusLine().getStatusCode());
					jsonData = service.finalJsonData(jsonData, resultPage, statusCode, userRole);
					
				}
			method.releaseConnection();
		}  catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		} 

		return jsonData;
	}
	
	public String getProducerSupportJsonData(String key, String value, String url, String id, String userRole){
		HttpResponse response=null;
		String jsonData=null;
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost postRequest = new HttpPost(url);
        //JSONObject jsonObj = new JSONObject();
        try {
			//jsonObj.put(GOOMConstants.PROFILE_ID, id);
			String myString = new JSONObject().put(USER_PROFILE_ID, id).toString();
			StringEntity input = new StringEntity(myString);
	        //input.setContentType(JHINSConstants.APPLICATION_JSON);
			LOG.debug("InputString:::::"+myString.toString());
	        postRequest.setEntity(input);
	        postRequest.addHeader(key,value);
	        postRequest.addHeader(CONTENT_TYPE,JHINSConstants.APPLICATION_JSON);
	        response = httpClient.execute(postRequest);
	        jsonData = EntityUtils.toString(response.getEntity(),"UTF-8");
	        LOG.debug("Rest service response ::::"+jsonData.toString());
	        String resultPage = PRODUCERTERMS_AND_CONDITION;
	        if (response.getStatusLine().getStatusCode() != 200) {
				int statusCode = response.getStatusLine().getStatusCode();
				LOG.debug("Response code::::" + response.getStatusLine().getStatusCode());
				jsonData = service.finalJsonData(jsonData, resultPage, statusCode, userRole);
			}
			httpClient.getConnectionManager().shutdown();
		} catch (JSONException e) {
			LOG.error("JSONException",e);
		}catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException",e);
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException",e);
		}catch (ParseException e) {
			LOG.error("ParseException",e);
		} catch (IOException e) {
			LOG.error("IOException",e);
		}
        
		return jsonData;
	}
	
}
