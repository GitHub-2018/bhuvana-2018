package com.jh.jhins.interfaces;

public interface JHINSFirmSupportTNCService {
	public abstract String getJsonData(String lastName, String ssoNo, String npnNo, String role);

}
