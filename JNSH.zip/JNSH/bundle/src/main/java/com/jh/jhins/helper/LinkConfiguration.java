package com.jh.jhins.helper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;

public class LinkConfiguration {
	private static final Logger LOG = LoggerFactory
			.getLogger(LinkConfiguration.class);

	public static String linkConfiguration(SlingHttpServletRequest request,
			String path) {

		String redirectionPath = null;
		if (path.startsWith("/content")) {
			ResourceResolver resourceResolver = request.getResourceResolver();
			Resource resource = resourceResolver.getResource(path);
			if (resource != null) {
				Page page = resource.adaptTo(Page.class);
				if (page != null) {
					redirectionPath = path + ".html";
					LOG.info("page not null =" + page);
					LOG.info("redirectionPath adding html =" + redirectionPath);
				}
			}
		} else {
			redirectionPath = path;
		}

		return redirectionPath;

	}
	
	
	public static List<Page> getPromoContent(Page currentPage){
		List<Page> childPages = new ArrayList<Page>();
	
		if (currentPage != null) {
			
			Page child = null;
			Iterator<Page> listChildren = currentPage.listChildren();
			while (listChildren.hasNext()) {
				child = listChildren.next();
				childPages.add(child);
				LOG.info("******************* success pages =" + child.getName());
			}
			
		}
		return childPages;
		
		
	
		
		
		
	}

}
