package com.jh.jhins.bean;

import java.util.ArrayList;

public class AssetMetaDataBean {	
	
	private String type;
	private String format;
	private String topic;
	private String clientApproved;
	private String state;
	private String channel;
	private boolean isNew;
	private String colorCode;
	private String glypIcon;
	private String path;
	private String title;
	private String imagePath;
	private String date;
	private String statesList;
	private ArrayList<String> states;
	private String priority;
	

	
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getClientApproved() {
		return clientApproved;
	}
	public void setClientApproved(String clientApproved) {
		this.clientApproved = clientApproved;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public boolean getIsNew() {
		return isNew;
	}
	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}
	public String getColorCode() {
		return colorCode;
	}
	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getGlypIcon() {
		return glypIcon;
	}
	public void setGlypIcon(String glypIcon) {
		this.glypIcon = glypIcon;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStatesList() {
		return statesList;
	}
	public void setStatesList(String statesList) {
		this.statesList = statesList;
	}
	public ArrayList<String> getStates() {
		return states;
	}
	public void setStates(ArrayList<String> states) {
		this.states = states;
	}
	
	
}
