package com.jh.jhins.helper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.constants.NewsConstants;

public class DateHelper {
	private static final Logger LOG = LoggerFactory.getLogger(DateHelper.class);

	/**
	 * Converts a <Date> to a <String> in the specified format
	 * 
	 * @param date
	 * @param dateformat
	 * @return
	 * @throws ParseException
	 */
	public static String convertDateToString(Date date, String dateformat) throws ParseException {

		DateFormat df = new SimpleDateFormat(dateformat);
		String strDate = df.format(date);
		LOG.debug("formatted date in article page:" + strDate);
		return strDate;

	}

	/**
	 * Formats a date in <String> to the pattern specified eg pattern:-
	 * "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
	 * 
	 * @param dateString
	 * @return <Date> date
	 */
	public static Date formatDate(String dateString, String pattern) {
		Date date = null;
		DateFormat format = new SimpleDateFormat(pattern);
		Calendar calendar = new GregorianCalendar();
		format.setTimeZone(TimeZone.getTimeZone(calendar.getTimeZone().getID()));
		LOG.debug("CALENDAR TIME ZONE" + calendar.getTimeZone());
		try {
			date = format.parse(dateString);
		} catch (ParseException e) {
			LOG.error("Parse Exception", e);
		}
		return date;

	}

	/**
	 * This method will give the no of days difference between two Dates.
	 * 
	 * @param date
	 *            The start date
	 * @param now
	 *            The end date (any date after the start date)
	 * @return days The no of days between both the dates
	 */
	public static long findDifferenceInDays(Date date, Date now) {
		long lStartTime = date.getTime();
		long lEndTime = now.getTime();
		return TimeUnit.MILLISECONDS.toDays(lEndTime - lStartTime);
	}

	/**
	 * Get the Last Modified Date from the jcr:content Node of the Node passed
	 * as argument
	 * 
	 * @param assetJcrNode
	 * @return
	 */
	public static Date getLastModified(Node assetNode) {
		Date date = null;
		try {
			if(assetNode!=null && assetNode.getNode("jcr:content")!=null && assetNode.getNode("jcr:content").hasProperty("jcr:lastModified")){
			String dateString = assetNode.getNode("jcr:content").getProperty("jcr:lastModified").getString();
			date = DateHelper.formatDate(dateString, JHINSConstants.DATE_FORMAT_YYYY_MM_DD);
			}
		} catch (ValueFormatException e) {
			LOG.error("VALUE FORMAT EXCEPTION" , e);
		} catch (PathNotFoundException e) {
			LOG.error("Path Not Found Excpetion" , e);
		} catch (RepositoryException e) {
			LOG.error("Repository Excpetion" , e);
		}
		return date;
	}

	/**
	 * Method to extract the last modified date
	 *
	 * @param properties 
	 * 
	 * @return Date(String Format)
	 * @throws RepositoryException
	 * @throws ParseException
	 * @throws ParseException
	 */
	
	public static String getLastModified(ValueMap properties) throws ParseException {
		LOG.debug("Starting of getLastModified method");
		Date date = null;
		String dt = properties.get(NewsConstants.PAGE_LAST_REPLICATED,String.class)!=null?properties.get(NewsConstants.PAGE_LAST_REPLICATED,String.class):properties.get(NewsConstants.PAGE_LAST_MODIFIED,String.class);
		if (null!=dt) {
		
				DateFormat format = new SimpleDateFormat(JHINSConstants.DATE_FORMAT_YYYY_MM_DD);
				date = format.parse(dt);
				DateFormat fmt = new SimpleDateFormat(NewsConstants.CUSTOM_DATE_FORMAT);
				dt = fmt.format(date);
				LOG.debug("date is " + dt);
		}
		LOG.debug("End of getLastModified method");
		return dt;
	}
	
	/**
	 * Method to get the createdDate from the asetNode
	 * @param assetNode
	 * @return
	 */
	public static Date getCreatedDate(Node assetNode) {
		Date date = null;
		try {
			String dateString = assetNode.getProperty("jcr:created").getString();
			date = DateHelper.formatDate(dateString, JHINSConstants.DATE_FORMAT_YYYY_MM_DD);
		} catch (ValueFormatException e) {
			LOG.error("Value Format Excpetion" , e);
		} catch (PathNotFoundException e) {
			LOG.error("Path Not Found Excpetion" , e);
		} catch (RepositoryException e) {
			LOG.error("Repository Excpetion" , e);
		}
		return date;
	}
	/**
	 * Method to check whether the asset is new or not 
	 * 
	 * @param Date
	 * @return boolean 
	 * @throws RepositoryException
	 */
	public static Boolean checkIsNew(Date date) {
		Boolean isNew = true;
		if(date!=null){
		Date now = currentDate(JHINSConstants.DATE_FORMAT_YYYY_MM_DD);
		LOG.debug("Date Helper --> CheckIsNew--> Now " + now);
		long days = DateHelper.findDifferenceInDays(date, now);
		if (days > 30) {
			isNew = false;
		}
		}
		else
		{
			isNew=false;
		}
		return isNew;
	}
	
	public static Date currentDate(String dateFormat){
		LOG.debug("Date Helper --> Current Date--> Date Format " + dateFormat);
		Date now = new Date();
		DateFormat format = new SimpleDateFormat(dateFormat);
		LOG.debug("Date Helper --> Current Date--> Format " + format);
		Calendar calendar = new GregorianCalendar();
		format.setTimeZone(TimeZone.getTimeZone(calendar.getTimeZone().getID()));
		LOG.debug("Date Helper --> Current Date--> Format TimeZone Set " + format.getTimeZone());
		String currentDate = format.format(now);
		LOG.debug("Date Helper --> Current Date--> current Date " + currentDate);
		try {
			now = format.parse(currentDate);
			LOG.debug("Date Helper --> Current Date--> now " + now);
		} catch (ParseException e) {
			LOG.error(" Parse Excpetion" , e);
		}
		return now;
	}
	//get Published Date value
	public static Date getPublishedDate(Node assetNode) {
		Date date = null;
		try {
			Node metaDataNode = assetNode.getNode("jcr:content/metadata");
			if(metaDataNode!=null && metaDataNode.hasProperty("publisheddate")){
				String dateString = metaDataNode.getProperty("publisheddate").getString();
				date = DateHelper.formatDate(dateString, JHINSConstants.DATE_FORMAT_YYYY_MM_DD);
				LOG.debug("PUBLISHED Date " + dateString.toString());
			}
		} catch (ValueFormatException e) {
			LOG.error("VALUE FORMAT EXCEPTION" +e.getMessage());
		} catch (PathNotFoundException e) {
			LOG.error("Path Not Found Excpetion"+ e.getMessage());
		} catch (RepositoryException e) {
			LOG.error("Repository Excpetion"+ e.getMessage());
		}
		return date;
	}
	public static String formatDates(String date,String inputFormat, String outputFormat) throws java.text.ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat(inputFormat);
		SimpleDateFormat format2 = new SimpleDateFormat(outputFormat);
		Date inputDate = format1.parse(date);	
		String incepDate=format2.format(inputDate).toString();
		return incepDate;
	}
	public static String getQuarter(String asOfDate) throws java.text.ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");		
		Date inputDate = format1.parse(asOfDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(inputDate);
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		String quarter=null;
		if(month==0||month==1 ||month==2)
		{
			quarter="First";
		}
		else if(month==3 ||month==4||month==5)
		{
			quarter="Second";
		}
		else if(month==6 ||month==7 || month==8)
		{
			quarter="Third";	
		}
		else if(month==9 || month==10 || month==11)
		{
			quarter="Fourth";
		}
		quarter = quarter+" Quarter "+year;
		return quarter;
	}
}
