package com.jh.jhins.interfaces;

public interface IpipelineConfigurationService {
	
	public void setConfiguration(String formtype, String groupname);
	
	public String getXML();

	
}
