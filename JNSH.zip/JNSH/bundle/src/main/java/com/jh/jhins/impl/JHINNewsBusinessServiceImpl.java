package com.jh.jhins.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.ArticleBean;
import com.jh.jhins.bean.AssetMetaDataBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.dao.NewsInfoDAO;
import com.jh.jhins.dao.UserInfoDAO;
import com.jh.jhins.helper.ArticleHelper;
import com.jh.jhins.helper.AssetHelper;
import com.jh.jhins.interfaces.JHINBusinessService;

public class JHINNewsBusinessServiceImpl implements JHINBusinessService {
	private static final Logger LOG = LoggerFactory.getLogger(JHINNewsBusinessServiceImpl.class);

	/**
	 * @Receives user login details along with functionality newsInfoDAO beans
	 *           are set with queried result details List of result bean
	 *           converted to JSON object returns JSON
	 * @throws RepositoryException
	 * @throws JSONException
	 * @throws ParseException
	 */
	public JSONObject getJSONResponse(Map<String, Object> mapObj)
			throws RepositoryException, JSONException, ParseException {
			
		JSONObject jsonObject = new JSONObject();
		NewsInfoDAO newsInfoDAO = new NewsInfoDAO();
		AssetHelper assetHelper= new AssetHelper();
		ArrayList<ArticleBean> articleBeans = new ArrayList<ArticleBean>();
		String function = mapObj.get(NewsConstants.PARAM_FUNCTIONALITY).toString();
		Map<String, Object> resultMap = null;
		
		SlingHttpServletRequest requestObject =  (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
		//String currentPath=mapObj.get(NewsConstants.CURRENTPAGE).toString();
		UserTO userTO = null;
		if(mapObj.get(NewsConstants.USERTO)==null)
		{
		UserInfoDAO userInfoDAO = new UserInfoDAO();
		userTO = userInfoDAO.getUserTO(requestObject);
		}
		else
		{
			userTO = (UserTO) mapObj.get(NewsConstants.USERTO);
		}
		mapObj.put(NewsConstants.USERTO, userTO);
		if (function.equalsIgnoreCase(NewsConstants.MY_NEWS_AND_UPDATES)) {
			LOG.debug("Functionality = MY_NEWS_AND_UPDATES");
			articleBeans = newsInfoDAO.getMyNewsUpdates(mapObj);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(articleBeans);
		}
		if (function.equalsIgnoreCase(NewsConstants.RECENT_NEWS)) {
			LOG.debug("Functionality = RECENT NEWS");
			articleBeans = newsInfoDAO.getRecentNews(mapObj);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(articleBeans);
		}
		if (function.equalsIgnoreCase(NewsConstants.RIGHT_RAILS_UPDATES)) {
			LOG.debug("Functionality = RIGHT_RAILS_UPDATES");
			articleBeans = newsInfoDAO.getChannelNews(mapObj);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(articleBeans);
		}

		if (function.equalsIgnoreCase(NewsConstants.RELATED_ARTICLE)) {
			LOG.debug("Functionality = RELATED_ARTICLE");		
			articleBeans = newsInfoDAO.getRelatedArticles(mapObj);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(articleBeans);

		}
		if (function.equalsIgnoreCase(NewsConstants.RECENT_PRODUCT_CHANGE)) {
			LOG.debug("Functionality = RECENT_PRODUCT_CHANGE");	
			articleBeans = newsInfoDAO.getChannelAndProductNews(mapObj);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(articleBeans);

		}
		if(function.equalsIgnoreCase(NewsConstants.RELATED_PAGES)){
			LOG.debug("Functionality = RELATED_PAGES");	
			articleBeans = newsInfoDAO.getRelatedPages(mapObj);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(articleBeans);
		}
		if(function.equalsIgnoreCase(NewsConstants.RELATED_RESOURCES)){
			LOG.debug("Functionality = RELATED_RESOURCES");	
			ArrayList<AssetMetaDataBean> assetBeans = assetHelper.getRelatedResources(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetBeans);
		}
		if(function.equalsIgnoreCase(NewsConstants.CENTRAL_INTELLIGENCE)){
			LOG.debug("Functionality = CENTRAL_INTELLIGENCE");	
			resultMap = newsInfoDAO.getChannelNewsCentralIntelligence(mapObj);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(resultMap);
		}
		if(function.equalsIgnoreCase(NewsConstants.ALL_NEWS)){
			LOG.debug("Functionality = ALL_NEWS");	
			resultMap = newsInfoDAO.retrieveLifeLtcAllNews(mapObj, null);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(resultMap);
		}
		if(function.equalsIgnoreCase(NewsConstants.MY_NEWS)){
			LOG.debug("Functionality = MY_NEWS");	
			resultMap = newsInfoDAO.retrieveLifeLtcAllNews(mapObj, "");
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(resultMap);
		}
		if(function.equalsIgnoreCase(NewsConstants.LIFE_NEWS)){
			LOG.debug("Functionality = LIFE_NEWS)");	
			resultMap = newsInfoDAO.retrieveLifeLtcAllNews(mapObj, NewsConstants.PARAM_LIFE_TOPIC);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(resultMap);
		}
		if(function.equalsIgnoreCase(NewsConstants.LTC_NEWS)){
			LOG.debug("Functionality = LTC_NEWS");	
			resultMap = newsInfoDAO.retrieveLifeLtcAllNews(mapObj, NewsConstants.PARAM_LTC_TOPIC);
			jsonObject = ArticleHelper.transferNewsDetailstoJSONobj(resultMap);
		}
		return jsonObject;
	}
}
