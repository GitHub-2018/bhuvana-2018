package com.jh.jhins.bean;

public class RiskDetailsBean {

	private String riskTitle="";
	private String riskColorCode="";


	public String getRiskTitle() {
		return riskTitle;
	}
	public void setRiskTitle(String riskTitle) {
		this.riskTitle = riskTitle;
	}
	public String getRiskColorCode() {
		return riskColorCode;
	}
	public void setRiskColorCode(String riskColorCode) {
		this.riskColorCode = riskColorCode;
	}
}
