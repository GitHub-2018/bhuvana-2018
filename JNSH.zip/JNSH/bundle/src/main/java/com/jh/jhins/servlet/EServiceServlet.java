package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth.ContentType;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.jh.jhins.bean.EServiceBean;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;

@SlingServlet( paths = "/bin/sling/eservice",metatype=true, methods = HttpConstants.METHOD_POST )
@Properties({ @Property(name = "service.description", value = "E-Service"),
	@Property(name = "service.vendor", value = "JHINS")})
public class EServiceServlet extends SlingAllMethodsServlet{

	private static final Logger LOG = LoggerFactory.getLogger(EServiceServlet.class);

	@Reference
	private GOOMConfigService configService;

	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException  {
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String inputData = xssAPI.getValidJSON(request.getParameter("formData"), null);
		Gson gson = new Gson();
		EServiceBean eServiceBean = gson.fromJson(inputData, EServiceBean.class);
		String inputJson = gson.toJson(eServiceBean);
		String responseJson = postFormData(inputJson);
		response.setContentType(GOOMConstants.APPLICATION_JSON);
		response.setCharacterEncoding(GOOMConstants.CHARSET);
		PrintWriter out = response.getWriter();
		out.write(xssAPI.getValidJSON(responseJson, null));
		out.flush();
		out.close();

	}

	private String postFormData(String inputJSON) {
		String responseData= "";
		CryptoBase64 decryptVal = new CryptoBase64();
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try{
			String token = getOauthToken();
			String endPointUrl = configService.getProperty(GOOMConstants.ESERVICE_URL);					
			StringEntity input = new StringEntity(inputJSON.toString());
			HttpPost postRequest = new HttpPost(endPointUrl);		
			postRequest.setEntity(input);
			postRequest.addHeader("Authorization", "Bearer " + token);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);	
			CloseableHttpResponse response = httpClient.execute(postRequest);
			if(response.getStatusLine().getStatusCode() != 200){
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("Message", "Your E-Service email Subscription Succesfull");
				responseData = jsonObj.toString();
			}else{
				int code = response.getStatusLine().getStatusCode();
				JSONObject errorObj = new JSONObject();
				errorObj.put("Code", code);
				errorObj.put("Message", "E-Service email Subscription service not available, Please try again later");
				responseData = errorObj.toString();
			}
			httpClient.close();
		}catch (JSONException e) {
			LOG.error("JSONException",e);
		}catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException",e);
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException",e);
		} catch (IOException e) {
			LOG.error("IOException",e);
		}catch (OAuthSystemException e) {
			LOG.error("OAuthSystemException",e);
		} catch (OAuthProblemException e) {
			LOG.error("OAuthProblemException",e);
		}finally{
			if(null !=httpClient){
				try {
					httpClient.close();
				} catch (IOException e) {
					LOG.error("IOException",e);
				}
			}
		}
		return responseData;
	}

	private String getOauthToken() throws OAuthSystemException, OAuthProblemException {
		OAuthClient client = new OAuthClient(new URLConnectionClient());
		CryptoBase64 decryptClientSecret = new CryptoBase64();
		String token="";
		try {
			String clientSecret = String.valueOf(decryptClientSecret.decrypt(configService.getProperty(GOOMConstants.OAUTH_CLIENT_SECRET)))
					.trim();

			OAuthClientRequest request = OAuthClientRequest
					.tokenLocation(configService.getProperty(GOOMConstants.OAUTH_TOKENLOCATION_PATH))
					.setGrantType(GrantType.CLIENT_CREDENTIALS)
					.setClientId(configService.getProperty(GOOMConstants.OAUTH_CLIENT_ID))
					.setClientSecret(clientSecret)				
					.buildBodyMessage();
			request.addHeader("ContentType", ContentType.JSON);
			token = client.accessToken(request, OAuthJSONAccessTokenResponse.class).getAccessToken();
		}
		catch (CryptoException e) {
			LOG.error("CryptoException:", e);
		}
		return token;

	}
}
