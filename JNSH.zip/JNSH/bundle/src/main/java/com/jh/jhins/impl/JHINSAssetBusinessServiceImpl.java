package com.jh.jhins.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.AssetMetaDataBean;
import com.jh.jhins.bean.UserTO;
import com.jh.jhins.constants.AssetConstants;
import com.jh.jhins.constants.NewsConstants;
import com.jh.jhins.dao.AssetInfoDAO;
import com.jh.jhins.dao.UserInfoDAO;
import com.jh.jhins.helper.AssetHelper;
import com.jh.jhins.interfaces.JHINBusinessService;

public class JHINSAssetBusinessServiceImpl implements JHINBusinessService {

	
	
	
	private static final Logger LOG = LoggerFactory.getLogger(JHINSAssetBusinessServiceImpl.class);

	/**
	 * @Receives user login details along with functionality newsInfoDAO beans
	 *           are set with queried result details List of result bean
	 *           converted to JSON object returns JSON
	 * @throws RepositoryException
	 * @throws JSONException
	 * @throws ParseException
	 */
	public JSONObject getJSONResponse(Map<String, Object> mapObj)
			throws RepositoryException, JSONException, ParseException {

		JSONObject jsonObject = new JSONObject();
		AssetInfoDAO assetInfoDAO = new AssetInfoDAO();
		ArrayList<AssetMetaDataBean> assetbean = new ArrayList<AssetMetaDataBean>();
		String function = mapObj.get(AssetConstants.PARAM_FUNCTIONALITY).toString();
		
		SlingHttpServletRequest requestObject =  (SlingHttpServletRequest) mapObj.get(NewsConstants.SLING_REQUEST);
		UserTO userTO = new UserTO();
		UserInfoDAO userInfoDAO = new UserInfoDAO();
		userTO = userInfoDAO.getUserTO(requestObject);
		mapObj.put(NewsConstants.USERTO, userTO);

		if (function.equalsIgnoreCase(AssetConstants.CONSUMER_MATERIAL)) {
			LOG.debug("functionality = CONSUMER_MATERIAL");
			assetbean = assetInfoDAO.getConsumermaterialAssets(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean,mapObj);
		}
		
		if (function.equalsIgnoreCase(AssetConstants.PRODUCER_MATERIAL)) {
			LOG.debug("functionality = PRODUCER_MATERIAL");
			assetbean = assetInfoDAO.getProducerMaterialAssets(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean,mapObj);
		}
		if (function.equalsIgnoreCase(AssetConstants.SALES_FLYERS)) {
			LOG.debug("functionality = SALES_FLYERS_AssetFeed");
			assetbean = assetInfoDAO.getSalesFlyerslAssets(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean);
		}
		
		if (function.equalsIgnoreCase(AssetConstants.KEY_PRODUCT_MATERIAL)) {
			LOG.debug("functionality = KEY_PRODUCT_MATERIAL");
			assetbean = assetInfoDAO.getKeyProductMaterials(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean);
		}
		
		if (function.equalsIgnoreCase(AssetConstants.INVESTMENT_INFORMATION)) {
			LOG.debug("functionality =INVESTMENT_INFORMATION");
			assetbean = assetInfoDAO.getInvestmentInfoAssets(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean,mapObj);
		}
		if (function.equalsIgnoreCase(AssetConstants.SALES_FLYER_COMP)) {
			LOG.debug("functionality = SALES_FLYERS");
			assetbean = assetInfoDAO.getSalesFlyers(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean,mapObj);
		
		}
		
		if (function.equalsIgnoreCase(AssetConstants.FUNDS_RATE_AND_INFO)) {
			LOG.debug("functionality = FUNDS_RATE_AND_INFO");
			assetbean = assetInfoDAO.getProspectusAssets(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean);
			
		}
		
		if (function.equalsIgnoreCase(AssetConstants.RELATED_TOPIC)) {
			LOG.debug("functionality = RELATED_TOPIC");
			assetbean = assetInfoDAO.getRelatedTopic(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean);
		}
		if (function.equalsIgnoreCase(AssetConstants.RELATED_DOCUMENTS)) {
			LOG.debug("functionality = RELATED_DOCUMENTS" );
			assetbean = assetInfoDAO.relatedResourcesByTopic(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean);
		}
		if(function.equalsIgnoreCase(AssetConstants.RELATED_RESOURCES)){
			LOG.debug("functionality = RELATED_RESOURCES");
			assetbean = assetInfoDAO.relatedItemsResources(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean);
		}
		if (function.equalsIgnoreCase(AssetConstants.PROSPECTUSES)) {
			LOG.debug("functionality = PROSPECTUSES");
			assetbean = assetInfoDAO.getFundProspectusAssets(mapObj);
			jsonObject = AssetHelper.transferAssetDetailstoJSONobj(assetbean);
		}
		
		
		return jsonObject;
	}
	
}
