package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import org.apache.sling.api.resource.Resource;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.impl.MaintenanceServiceImpl;
import com.jh.jhins.interfaces.MaintenanceService;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JHINS Maintenance Status check"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/maintenanceStatus" }),
		@Property(name = "service.vendor", value = "JHINS"),
		@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)})
public class JHINSMaintenanceServlet extends SlingAllMethodsServlet{

	private static final Logger LOG = LoggerFactory
			.getLogger(JHINSMaintenanceServlet.class);
		
	protected final void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException, IOException {
		MaintenanceService maintenanceService = new MaintenanceServiceImpl();
		JSONObject json = new JSONObject();
		LOG.debug("inside JHINSMaintenanceServlet");
		String domain = request.getParameter(JHINSConstants.DOMAIN);
		boolean maintenanceStatus = false;
		String message = StringUtils.EMPTY;
		Node maintenanceNode = null;
		try {
			Resource resource = request.getResourceResolver().getResource(JHINSConstants.MAINTENANCE_PAGE_PATH+domain.toLowerCase());
			Node jcrNode = resource.adaptTo(Node.class);
			maintenanceNode = jcrNode.getNode(JHINSConstants.MAINTENANCE_NODE);
			} catch (PathNotFoundException e) {
				LOG.error("PathNotFoundException",e );
			} catch (RepositoryException e) {
				LOG.error("RepositoryException", e);
			}
		maintenanceStatus =  maintenanceService.getStatus(maintenanceNode);
		if(maintenanceStatus){
			message = maintenanceService.getMessage(maintenanceNode);
		}else{
			message = JHINSConstants.SITE_ACTIVE;
		}
		json = maintenanceService.getJsonResponse(domain, maintenanceStatus, message);
		LOG.debug("json data:::::::::::::::::::::"+json.toString());
		PrintWriter out = response.getWriter();
		out.println(json);
		out.flush();
		out.close();
	}
}
