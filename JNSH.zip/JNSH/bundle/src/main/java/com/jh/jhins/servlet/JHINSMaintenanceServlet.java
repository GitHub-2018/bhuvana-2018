package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.impl.MaintenanceServiceImpl;
import com.jh.jhins.interfaces.MaintenanceService;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JHINS Maintenance Status check"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/maintenanceStatus" }),
		@Property(name = "service.vendor", value = "JHINS"),
		@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)})
public class JHINSMaintenanceServlet extends SlingAllMethodsServlet{

	private static final Logger LOG = LoggerFactory
			.getLogger(JHINSMaintenanceServlet.class);
		
	protected final void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException, IOException {
		MaintenanceService maintenanceService = new MaintenanceServiceImpl();
		JSONObject json = new JSONObject();
		LOG.debug("inside JHINSMaintenanceServlet");
		String domain = request.getParameter("domain");
		LOG.debug("domain::::::::::::::"+domain);
		boolean maintenanceStatus = false;
		String message = StringUtils.EMPTY;
		Node maintenanceNode = null;
		String vitalityPagePath = JHINSConstants.VITALITY_PAGEPATH;
		String saleshubPagePath = JHINSConstants.SALESHUB_PAGEPATH;
		
		if(JHINSConstants.SALESHUB.equalsIgnoreCase(domain)){
			Resource resource =request.getResourceResolver().getResource(JHINSConstants.SALESHUB_PAGEPATH);
			Page page = resource.adaptTo(Page.class);
			Node node = page.adaptTo(Node.class);
			Node jcrNode;
			try {
				jcrNode = node.getNode("jcr:content");
				Node parNode = jcrNode.getNode("par");
				maintenanceNode = parNode.getNode("maintenance");
			} catch (PathNotFoundException e) {
				LOG.error("PathNotFoundException");
			} catch (RepositoryException e) {
				LOG.error("RepositoryException");
			}
			maintenanceStatus =  maintenanceService.getStatus(maintenanceNode);
			if(maintenanceStatus){
				message = maintenanceService.getMessage(maintenanceNode);
			}else{
				message = "Site in Active State";
			}
			
		} else if(JHINSConstants.VITALITY.equalsIgnoreCase(domain)){
			Resource resource =request.getResourceResolver().getResource(JHINSConstants.VITALITY_PAGEPATH);
			Page page = resource.adaptTo(Page.class);
			Node node = page.adaptTo(Node.class);
			Node jcrNode;
			try {
				jcrNode = node.getNode("jcr:content");
				Node parNode = jcrNode.getNode("par");
				maintenanceNode = parNode.getNode("maintenance");
			} catch (PathNotFoundException e) {
				LOG.error("PathNotFoundException");
			} catch (RepositoryException e) {
				LOG.error("RepositoryException");
			}
			maintenanceStatus =  maintenanceService.getStatus(maintenanceNode);
			if(maintenanceStatus){
				message = maintenanceService.getMessage(maintenanceNode);
			}else{
				message = "Site in Active State";
			}
		}
		
		json = maintenanceService.getJsonResponse(domain, maintenanceStatus, message);
		LOG.debug("json data:::::::::::::::::::::"+json.toString());
		PrintWriter out = response.getWriter();
		out.println(json);
		out.flush();
		out.close();
	}
	
}
