package com.jh.jhins.helper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jh.jhins.bean.NavBean;
import com.jh.jhins.constants.JHINSConstants;

public class JHInsNavigationHelper {
	private static final Logger LOG = LoggerFactory.getLogger(JHInsNavigationHelper.class);

	/**
	 * Method to fetch the local navigation pages
	 *
	 * @param currentpage
	 * @param parentpage
	 * @return list
	 * @throws RepositoryException
	 */

	public List<NavBean> retrieveLocalNavPages(Page currentPage, Page parentPage) throws PathNotFoundException {

		List<NavBean> localPages = new ArrayList<NavBean>();
		NavBean localNavBean = null;
		String pagePath = null;
		String pageTitle = null;

		/*
		 * Getting the direct parent Pages of the currentPage till the
		 * ParentPage
		 */
		if (null != currentPage && null != parentPage) {
			int depth = parentPage.getDepth();
			LOG.debug("currentpage Depth" + currentPage.getDepth());
			;
			int i;
			for (i = currentPage.getDepth() - depth; i >= 0; i--) {
				localNavBean = new NavBean();
				Page parent = currentPage.getParent(i);
				/*
				 * Getting Navigation title as title if navigation title is
				 * empty, fetching pageTitle if its empty fetching Title as
				 * title.
				 * 
				 */
				if (parent.getNavigationTitle() != null) {
					pageTitle = parent.getNavigationTitle();
				} else if (parent.getPageTitle() != null) {
					pageTitle = parent.getPageTitle();
				} else {
					pageTitle = parent.getTitle();
				}
				localNavBean.setPageTitle(parent.getTitle());
				localNavBean.setPagePath(parent.getPath());
				localPages.add(localNavBean);
			}

			/* Getting the one level child Pages of the currentPage */
			Iterator<Page> iterator = currentPage.listChildren();
			while (iterator.hasNext()) {
				Page child = (Page) iterator.next();
				if (!child.isHideInNav()) {
					localNavBean = new NavBean();
					/*
					 * Getting Navigation title as title if navigation title is
					 * empty, fetching pageTitle if its empty fetching Title as
					 * title.
					 * 
					 */
					if (child.getNavigationTitle() != null) {
						pageTitle = child.getNavigationTitle();
					} else if (child.getPageTitle() != null) {
						pageTitle = child.getPageTitle();
					} else {
						pageTitle = child.getTitle();
					}
					pagePath = child.getPath();
					localNavBean.setPageTitle(pageTitle);
					localNavBean.setPagePath(pagePath);
					localPages.add(localNavBean);
				}
			}

		}

		return localPages;
	}

	/**
	 * Method to fetch the First level child pages .
	 * 
	 * @return list
	 */

	public static List<Page> retrieveChildPages(Page currentPage) {
		List<Page> pages = new ArrayList<Page>();
		if (currentPage != null) {
			Page child = null;

			Iterator<Page> childrenPages = currentPage.listChildren();
			while (childrenPages.hasNext()) {

				child = childrenPages.next();
				pages.add(child);

			}

		}
		return pages;

	}

	/**
	 * Method to fetch the navigation pages .
	 *
	 * @param absPage
	 * @return list
	 * @throws PathNotFoundException
	 */

	public List<NavBean> retrieveNavigationPages(Page absParentPage, Tag firmTag) throws PathNotFoundException {
		List<NavBean> navPages = new ArrayList<NavBean>();
		List<NavBean> subNavPages = new ArrayList<NavBean>();
		NavBean navBean = null;
		boolean firmUser = false;
		boolean show = false;
		Tag[] tags = null;
		if (null != firmTag)
			firmUser = true;
		if (null != absParentPage) {
			Iterator<Page> iterator = absParentPage.listChildren();
			while (iterator.hasNext()) {
				Page child = (Page) iterator.next();
				/* Checking Hide In Navigation property */
				LOG.info("childpath:: for show:: "+child.getPath());
				tags = child.getTags();
				show = showPageForFirm(tags, firmUser, firmTag);
				String title = "";
				if (!child.isHideInNav() && show) {
					navBean = new NavBean();
					if (child.getProperties().get(JHINSConstants.CQ_TEMPLATE_LABEL, "") != null) {
						String template = child.getProperties().get(JHINSConstants.CQ_TEMPLATE_LABEL, "").toString();
						if (template.equals(JHINSConstants.BASE_PAGE_TEMPLATE)) {
							navBean.setBasePage(true);
						}
					}
					/*
					 * Getting Navigation title as title if navigation title is
					 * empty, fetching pageTitle if its empty fetching Title as
					 * title.
					 * 
					 */
					if (child.getNavigationTitle() != null) {
						title = child.getNavigationTitle();
					} else if (child.getPageTitle() != null) {
						title = child.getPageTitle();
					} else
						title = child.getTitle();
					navBean.setPageTitle(title);
					if (child.getPath() != null) {
						navBean.setPagePath(child.getPath());
					}
					/*
					 * If has child getting the child pages and setting the
					 * level
					 */
					if (child.listChildren().hasNext()) {
						/*
						 * Calling Recursively the same method if the page has
						 * children
						 */

						subNavPages = retrieveNavigationPages(child, firmTag);
						navBean.setChildPages(subNavPages);
						if (subNavPages != null && subNavPages.size() > 0) {
							navBean.setLevel(1);
						} else {
							navBean.setLevel(0);
						}
					} else {
						navBean.setLevel(0);
					}
					navPages.add(navBean);
				}

			}
		}

		return navPages;
	}

	/**
	 * Overloaded Method to fetch the navigation pages .
	 *
	 * @param absPage
	 * @return list
	 * @throws PathNotFoundException
	 */

	public List<NavBean> retrieveNavigationPages(Page absParentPage) throws PathNotFoundException {
		List<NavBean> navPages = new ArrayList<NavBean>();
		List<NavBean> subNavPages = new ArrayList<NavBean>();
		NavBean navBean = null;
	
		if (null != absParentPage) {
			Iterator<Page> iterator = absParentPage.listChildren();
			while (iterator.hasNext()) {
				Page child = (Page) iterator.next();
				/* Checking Hide In Navigation property */
				LOG.info("childpath:: for show:: "+child.getPath());
				
				String title = "";
				if (!child.isHideInNav()) {
					navBean = new NavBean();
					if (child.getProperties().get(JHINSConstants.CQ_TEMPLATE_LABEL, "") != null) {
						String template = child.getProperties().get(JHINSConstants.CQ_TEMPLATE_LABEL, "").toString();
						if (template.equals(JHINSConstants.BASE_PAGE_TEMPLATE)) {
							navBean.setBasePage(true);
						}
					}
					/*
					 * Getting Navigation title as title if navigation title is
					 * empty, fetching pageTitle if its empty fetching Title as
					 * title.
					 * 
					 */
					if (child.getNavigationTitle() != null) {
						title = child.getNavigationTitle();
					} else if (child.getPageTitle() != null) {
						title = child.getPageTitle();
					} else
						title = child.getTitle();
					navBean.setPageTitle(title);
					if (child.getPath() != null) {
						navBean.setPagePath(child.getPath());
					}
					/*
					 * If has child getting the child pages and setting the
					 * level
					 */
					if (child.listChildren().hasNext()) {
						/*
						 * Calling Recursively the same method if the page has
						 * children
						 */

						subNavPages = retrieveNavigationPages(child);
						navBean.setChildPages(subNavPages);
						if (subNavPages != null && subNavPages.size() > 0) {
							navBean.setLevel(1);
						} else {
							navBean.setLevel(0);
						}
					} else {
						navBean.setLevel(0);
					}
					navPages.add(navBean);
				}

			}
		}

		return navPages;
	}

	private boolean showPageForFirm(Tag[] tags, boolean firmUser, Tag firmTag) {
		boolean show = true;
		LOG.info("FIRMTAG:: "+firmTag);
		LOG.info("FIRMTAG:: "+firmTag);
		for (int i = 0; i < tags.length; i++) {
			Tag tag = tags[i];
			if (tag.getTagID().startsWith("JHINS:firm")) {
				// firm page
				if (!firmUser) {
					LOG.info("inside not firmUser block:: ");
					show = false;
					break;
				} else {
					if (!tag.equals(firmTag)) {
						LOG.info("inside ncurrent tag ne firmtag block: ");
						show = false;
						break;
					} else {
						LOG.info("else block ");
						break;
					}
				}
			}
		}

		return show;
	}

	public String getTagPathForFirm(String firm) {
		if (firm.equals(JHINSConstants.HEADER_GROUP_EDJONES)||firm.equals("EJProducers")) {
			return JHINSConstants.FIRM_EDJONES;
		} else if (firm.equals(JHINSConstants.HEADER_FIRMINDICATOR_MGROUP)) {
			return JHINSConstants.FIRM_MGROUP;
		} else {
			return "";
		}
	}

}