package com.jh.jhins.helper;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

@Model(adaptables = Resource.class)
public class MultifieldModel {


       @Inject
       @Optional
       public Resource columnInfo;

       @Inject
       @Optional
       public Resource multicomposite;

       @Inject
       
       public Resource multi;
       
       @Inject
       @Optional
       public Resource notificationInfo;
       
       
       @Inject
       @Optional
       public Resource latestInfo;

}
