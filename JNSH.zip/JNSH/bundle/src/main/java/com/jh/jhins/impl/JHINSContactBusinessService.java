package com.jh.jhins.impl;

import java.util.ArrayList;
import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.bean.ContactDetailsBean;
import com.jh.jhins.constants.ContactConstants;
import com.jh.jhins.dao.ContactInfoDAO;
import com.jh.jhins.helper.ContactDetailsHelper;

public class JHINSContactBusinessService {

	private static final Logger LOG = LoggerFactory.getLogger(JHINSContactBusinessService.class);
	/**
	 * \
	 * @received mapObj
	 * 		Calls getUserStates for user selected state information
	 * 		Calls queryContactInfo for querying user selected state details
	 * 		Calls transferNewsDetailstoJSONobj to convert list of beans to JSON Object 
	 * @return JSON object
	 * @throws RepositoryException
	 * @throws JSONException
	 */
	public JSONObject getJSONResponse(Map<String, Object> mapObj) throws RepositoryException, JSONException{
		String functionality=mapObj.get(ContactConstants.PARAM_FUNCTIONALITY).toString();
		JSONObject jsonObject = new JSONObject();
		ContactInfoDAO contactInfoDAO=new ContactInfoDAO();
	//	ContactDetailsHelper contactDetailsHelper=new ContactDetailsHelper();
		ArrayList<ContactDetailsBean> contactBeans = new ArrayList<ContactDetailsBean>();

		if(functionality.equals(ContactConstants.CONTACT_INFORMATION)){
			ArrayList<String> statesList = contactInfoDAO.getStates(mapObj);
			LOG.debug("list of states retrieved fron database is "+statesList);
			contactBeans=ContactDetailsHelper.queryContactInfo(statesList, mapObj);
			jsonObject=ContactDetailsHelper.transferContactDetailstoJSONobj(contactBeans);
		}

		if(functionality.equals(ContactConstants.SALES_SUPPORT)){
			contactBeans=ContactDetailsHelper.queryStateInfo(mapObj);
			jsonObject=ContactDetailsHelper.transferContactDetailstoJSONobj(contactBeans);
		}

		return jsonObject;

	}

}
