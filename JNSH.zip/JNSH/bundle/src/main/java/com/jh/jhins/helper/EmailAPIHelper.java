package com.jh.jhins.helper;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.jh.jhins.util.ConfigUtil;
import com.jh.jhins.email.EmailServiceConstants;
import com.jh.jhins.email.impl.EmailServiceImpl;
import com.jh.jhins.helper.EmailHelper;
import com.jh.jhins.bean.EmailAPICredentials;

public class EmailAPIHelper{
	
    private static final Logger LOG = LoggerFactory.getLogger(EmailAPIHelper.class);

public static boolean sendEmail(String emailJSON, ResourceResolver resourceResolver) throws Exception{
		
	    EmailAPICredentials emailAPICredentail = new EmailAPICredentials();
		String username=EmailHelper.stripXSS(EmailServiceConstants.CONFIG_EMAIL_API_USERNAME, ConfigUtil.INSTANCE.getStringConfiguration(EmailServiceConstants.CONFIG_EMAIL_API_USERNAME));
		LOG.info("username@@"+username);
		String password=EmailHelper.stripXSS(EmailServiceConstants.CONFIG_EMAIL_API_PWD, ConfigUtil.INSTANCE.getStringConfiguration(EmailServiceConstants.CONFIG_EMAIL_API_PWD));
		LOG.info("password@@"+password);
		emailAPICredentail.setUsername(EmailHelper.decryptText(username));
		emailAPICredentail.setPwd(EmailHelper.decryptText(password));
		String inputJson =  EmailHelper.createGsonObj().toJson(emailAPICredentail);
		StringBuffer apiTokenURL = new StringBuffer();
		String emailApi=EmailHelper.stripXSS(EmailServiceConstants.CONFIG_EMAIL_API_URL, ConfigUtil.INSTANCE.getStringConfiguration(EmailServiceConstants.CONFIG_EMAIL_API_URL));
		apiTokenURL.append(emailApi);
		apiTokenURL.append(EmailServiceConstants.EMAIL_JHINS_TOKEN_URL);
		// get the authentication token
		EmailServiceImpl emailserviceImpl=new EmailServiceImpl();
		String oauthToken =  emailserviceImpl.getOAUTHToken(inputJson, apiTokenURL.toString(),resourceResolver);
		if(StringUtils.isBlank(oauthToken)){
			LOG.error("Error while receiving OAuth Token");
			return false;
		}
		
		StringBuffer apiEmailURL = new StringBuffer();
		apiEmailURL.append(emailApi);
		apiEmailURL.append(EmailServiceConstants.EMAIL_JHINS_SEND_URL);
		
		return emailserviceImpl.sendEmail(emailJSON, apiEmailURL.toString(), oauthToken, resourceResolver);
}
}
