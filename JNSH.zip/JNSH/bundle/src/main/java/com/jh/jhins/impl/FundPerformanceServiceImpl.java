package com.jh.jhins.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import javax.jcr.RepositoryException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth.ContentType;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhins.bean.FundDetailsBean;
import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.helper.DateHelper;
import com.jh.jhins.helper.FundDetails;
import com.jh.jhins.interfaces.FundPerformanceService;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;
@Component
@Service

public class FundPerformanceServiceImpl implements FundPerformanceService{

	@Reference
	private GOOMConfigService configService;
	@Reference
	private ResourceResolverFactory resolverFactory;

	FundDetails fundetails =new FundDetails();

	private static final Logger LOG = LoggerFactory.getLogger(FundPerformanceServiceImpl.class);


	public String getJsonData(String procode, String comcode,ResourceResolver resourceResolver, String result,String footNote, String firmId) {	

		String respContent = null;
		String productcode =procode;
		String companycode = comcode;
		String endPointUrl=null;	

		if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_MONTHLY_PERFORMANCE)){
			endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_MONTHLY_PERFORMANCE_URL);
		}
		else if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_QUATERLY_PERFORMANCE))
		{
			endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_QUATERLY_PERFORMANCE_URL);
		}
		else if (result.equalsIgnoreCase(GOOMConstants.BY_SERIES_MONTHLY_PERFORMANCE))
		{
			endPointUrl = configService.getProperty(GOOMConstants.JHVITMONTHLY_PERFORMANCE_URL);
		}
		else if (result.equalsIgnoreCase(GOOMConstants.BY_SERIES_QUATERLY_PERFORMANCE))
		{
			endPointUrl = configService.getProperty(GOOMConstants.JHVITQUARTERLY_PERFORMANCE_URL);
		}
		JSONObject jsonObj = new JSONObject();
		try {
			jsonObj.put(GOOMConstants.PRODUCTCODE, productcode);
			jsonObj.put(GOOMConstants.COMPANYCODE, companycode);
			LOG.debug("input Json:::::::::::::::::" + jsonObj.toString());
			StringEntity input = new StringEntity(jsonObj.toString());
			respContent = getJsonResponse(input,endPointUrl,resourceResolver,footNote, firmId, result);
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		} catch (ParseException e) {
			LOG.error("ParseException", e);
		} catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException", e);
		} catch (RepositoryException e) {
			LOG.error("RepositoryException", e);
		} catch (java.text.ParseException e) {
			LOG.error("java.text.ParseException", e);
		}
		LOG.debug("BY Product Fund Performance final json data for "+result+" ==" + respContent);
		return respContent;
	}
	private String getJsonResponse(StringEntity input, String url,ResourceResolver resourceResolver,String footNote, String firmId, String result) throws JSONException, RepositoryException, java.text.ParseException {
		String responseData = null;
		String code = null;
		JSONObject jObject = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {	
			String token = getOauthToken();
			HttpPost postRequest = new HttpPost(url);		
			postRequest.setEntity(input);
			postRequest.addHeader("Authorization", "Bearer " + token);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);			
			CloseableHttpResponse response = httpClient.execute(postRequest);	
			responseData = EntityUtils.toString(response.getEntity(), GOOMConstants.CHARSET);
			int statusCode=response.getStatusLine().getStatusCode();
			LOG.debug("Rest Service status code :::"+statusCode);
			//LOG.debug("Rest Service response ::"+responseData.toString());
			if(statusCode != 200){
				
				if(statusCode==403)
				{
				jObject = getUnavailableErrorJsonData(statusCode);
				}
				else
				{
				jObject = new JSONObject(responseData);
				jObject = getErrorJsonData(statusCode,jObject);
				}
			}else{
				jObject = new JSONObject(responseData);
				jObject=finalJsonData(jObject,resourceResolver,footNote, firmId, result);
			}	
			responseData=jObject.toString();
			httpClient.close();
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		} catch (OAuthSystemException e) {
			LOG.error("OAuthSystemException", e);
		} catch (OAuthProblemException e) {
			LOG.error("OAuthProblemException", e);
		}finally{
			if(null != httpClient){
				try {
					httpClient.close();
				} catch (IOException e) {
					LOG.error("IOException", e);
				}
			}
		}

		return responseData;
	}

	
	private JSONObject finalJsonData(JSONObject jObject,ResourceResolver resourceResolver,String footNote, String firmId, String result) throws RepositoryException, java.text.ParseException {
		JSONArray performanceDataArr;
		JSONArray fundArray = new JSONArray();
		JSONArray footNoteArray = new JSONArray();
		TreeSet<Integer> listedFootNotes= new TreeSet<Integer>();
		String asOfDate=null;
		String quarter=null;
		String pagePath= null;
		String yieldAsOfDate = null;
		String yieldValue = null;
		if(firmId.equalsIgnoreCase(GOOMConstants.PRD)){
			pagePath = configService.getProperty(GOOMConstants.PRD_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.EDJ)){
			pagePath = configService.getProperty(GOOMConstants.EDJ_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.MGP)){
			pagePath = configService.getProperty(GOOMConstants.MGP_FUNDPROFILE_PATH);
		}else{
			pagePath = configService.getProperty(GOOMConstants.FUND_PROFILES_URL);
		}
		//LOG.debug("page Path:::::"+pagePath);
		LOG.debug("footNote value is "+footNote);
		if(!footNote.isEmpty()){
			String[] footNotes = footNote.split(",");
			for (String items : footNotes) {
				int footNoteNum = Integer.parseInt(items);			
				listedFootNotes.add(footNoteNum);
			}
		}
		HashMap<String,String> riskDetails= fundetails.getRiskDetails(GOOMConstants.RISK_DETAILS_URL,resourceResolver);
		try {
			performanceDataArr=jObject.getJSONObject("details").getJSONArray("fundPerformanceData");
			asOfDate=jObject.getJSONObject("details").getString("asOfDate");
			yieldAsOfDate = jObject.getJSONObject("details").getString("yieldValueAsOfDate");
			yieldAsOfDate = DateHelper.formatDates(yieldAsOfDate,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);
			quarter=DateHelper.getQuarter(asOfDate);
			asOfDate=DateHelper.formatDates(asOfDate,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);

			for(int i=0;i<performanceDataArr.length();i++){
				JSONObject jsonIteration=performanceDataArr.getJSONObject(i);
				String fundCode=jsonIteration.getString("fundCode");
				Boolean isFundExist = fundCheck(fundCode , pagePath,resourceResolver);
				if(isFundExist){
					String date=jsonIteration.getString("incepDate");
					//if(null != jsonIteration.getString("yieldvalue")){
						yieldValue = jsonIteration.getString("yieldvalue");
				//	}
					String incepDate=DateHelper.formatDates(date,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);
					FundDetailsBean fundDetail=fundetails.getFundDetails(pagePath,fundCode,resourceResolver);
					if(null!=fundDetail.getNumberedFootNotes() && !fundDetail.getNumberedFootNotes().isEmpty())
					{
						String[] numFootNotes=fundDetail.getNumberedFootNotes().toString().split(",");
						for (String items : numFootNotes) {
							int footNoteNumber = Integer.parseInt(items);			
							listedFootNotes.add(footNoteNumber);						
						}
					}	
					String riskColorCode=riskDetails.get(fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK, fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK_ORDER, fundDetail.getRiskOrder());				
					jsonIteration.put(GOOMConstants.MORNING_STAR_PATH,fundDetail.getMorningStarPath());
					jsonIteration.put(GOOMConstants.MANAGEMENT_FEE,fundDetail.getManagementFee());
					jsonIteration.put(GOOMConstants.INCEPTION_DATE,incepDate);
					jsonIteration.put(GOOMConstants.FUND_TITLE, fundDetail.getFundTitle());
					jsonIteration.put(GOOMConstants.FUND_MANAGER, fundDetail.getFundManager());
					jsonIteration.put(GOOMConstants.RISK_COLOR_CODE, riskColorCode);
					jsonIteration.put(GOOMConstants.NUMBERED_FOOT_NOTE, fundDetail.getNumberedFootNotes());
					if(("MMKTD".equalsIgnoreCase(fundCode) || "NMMK".equalsIgnoreCase(fundCode)) && (result.equalsIgnoreCase(GOOMConstants.BY_SERIES_MONTHLY_PERFORMANCE) || result.equalsIgnoreCase(GOOMConstants.BY_SERIES_QUATERLY_PERFORMANCE))){
						String inTableFootNote = fundDetail.getFootNote();
						Map<String, String> valuesMap = new HashMap<String, String>();
						valuesMap.put("yieldValue", yieldValue);
						valuesMap.put("todayDate", yieldAsOfDate);
						StrSubstitutor sub = new StrSubstitutor(valuesMap);
						inTableFootNote = sub.replace(inTableFootNote);
						jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, inTableFootNote);
					}else if(("MMKTD".equalsIgnoreCase(fundCode) || "NMMK".equalsIgnoreCase(fundCode)) && (result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_MONTHLY_PERFORMANCE)|| result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_QUATERLY_PERFORMANCE))){
						jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, "");
					}
					else{
						jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, fundDetail.getFootNote());
					}
					fundArray.put(jsonIteration);				
				}
	
				fundArray = fundetails.sortJson(fundArray);
				jObject.put("FundArray",fundArray);	
				if(!listedFootNotes.isEmpty()){
					footNoteArray=fundetails.getFootNoteDetails(listedFootNotes,resourceResolver);
					jObject.put("FootNotesArray", footNoteArray);
				}			
				jObject.put("date",asOfDate);
				jObject.put("quarter",quarter);
			}
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}
		return jObject;
	}

	private Boolean fundCheck(String fundCode, String pagePath, ResourceResolver resourceResolver) {
		Boolean flagVal = false;
		Resource resource =resourceResolver.getResource(pagePath+"/"+fundCode);
		if(null != resource){
			String resourceName = resource.getName();
			if(fundCode.equalsIgnoreCase(resourceName)){
				flagVal = true;
			}
		}else{
			flagVal = false;
		}
		return flagVal;
	}
	public String getDailyUnitJsonData(String procode, String comcode,ResourceResolver resourceResolver, String result, String date,String footNote, String firmId) {		
		String respContent = null;
		String productcode =procode;
		String companycode = comcode;
		String endPointUrl=null;
		String formatedDate = date;
		if(!formatedDate.isEmpty()){
			try {
				formatedDate=DateHelper.formatDates(date,GOOMConstants.INPUT_DATE_FORMAT_DAILY_UNIT,GOOMConstants.OUTPUT_DATE_FORMAT_DAILY_UNIT);
			} catch (java.text.ParseException e) {
				LOG.error("java.text.ParseException"+e);
			}
		}
		
		if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_DAILYUNIT_VALUE)){
			endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_DAILYUNIT_VALUE_URL);
		}
		else if(result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE)){
			endPointUrl = configService.getProperty(GOOMConstants.BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE_URL);
		}		
		JSONObject jsonObj = new JSONObject();
		try {
			jsonObj.put(GOOMConstants.PRODUCTCODE, productcode);
			jsonObj.put(GOOMConstants.COMPANYCODE, companycode);
			jsonObj.put(GOOMConstants.AS_OF_DATE,formatedDate);			
			LOG.debug("input Json:::::::::::::::::" + jsonObj.toString());
			StringEntity input = new StringEntity(jsonObj.toString());
			respContent = getDailyUnitJsonResponse(input,endPointUrl,resourceResolver,footNote, firmId, result);
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		} catch (ParseException e) {
			LOG.error("ParseException", e);
		} catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException", e);
		}
		LOG.debug("BY Product Daily Unit Values final json data for "+result+" ==" + respContent);
		return respContent;
	}
	private String getDailyUnitJsonResponse(StringEntity input, String url, ResourceResolver resourceResolver,String footNote, String firmId, String result) {
		String responseData = null;
		String code = null;
		JSONObject jObject = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {		
			String token = getOauthToken();
			HttpPost postRequest = new HttpPost(url);
			postRequest.setEntity(input);
			postRequest.addHeader("Authorization", "Bearer " + token);
			postRequest.addHeader(GOOMConstants.CONTENT_TYPE, GOOMConstants.APPLICATION_JSON);
			CloseableHttpResponse response = httpClient.execute(postRequest);
			int statusCode = response.getStatusLine().getStatusCode();
			responseData = EntityUtils.toString(response.getEntity(), GOOMConstants.CHARSET);	
			LOG.debug("daily unit Rest service status code"+statusCode);
			LOG.debug("daily unit Rest service  response"+responseData);
			if( statusCode != 200){				
				if(statusCode==403)
				{				
				jObject = getUnavailableErrorJsonData(statusCode);
				}
				else
				{				
				jObject = new JSONObject(responseData);
				jObject = getErrorJsonData(statusCode,jObject);
				}
			}
			else{
				jObject = new JSONObject(responseData);
				jObject=finalDailyUintJsonData(jObject,resourceResolver,footNote, firmId, result);
			}
			responseData=jObject.toString();
			httpClient.close();
		} catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		} catch (RepositoryException e) {
			LOG.error("IOExRepositoryExceptionception", e);
		} catch (java.text.ParseException e) {
			LOG.error("ParseException", e);
		} catch (OAuthSystemException e) {
			LOG.error("OAuthSystemException", e);
		} catch (OAuthProblemException e) {
			LOG.error("OAuthProblemException", e);
		}finally{
			if(null != httpClient){
				try {
					httpClient.close();
				} catch (IOException e) {
					LOG.error("IOException", e);
				}
			}
		}

		return responseData;
	}
	
	private JSONObject finalDailyUintJsonData(JSONObject jObject,ResourceResolver resourceResolver,String footNote, String firmId, String result) throws RepositoryException, java.text.ParseException {

		JSONArray newjson;
		JSONArray fundArray = new JSONArray();
		String asOfDate=null;
		JSONArray footNoteArray = new JSONArray();
		TreeSet<Integer> listedFootNotes= new TreeSet<Integer>();
		String pagePath= null;
		if(firmId.equalsIgnoreCase(GOOMConstants.PRD)){
			pagePath = configService.getProperty(GOOMConstants.PRD_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.EDJ)){
			pagePath = configService.getProperty(GOOMConstants.EDJ_FUNDPROFILE_PATH);
		}else if(firmId.equalsIgnoreCase(GOOMConstants.MGP)){
			pagePath = configService.getProperty(GOOMConstants.MGP_FUNDPROFILE_PATH);
		}else{
			pagePath = configService.getProperty(GOOMConstants.FUND_PROFILES_URL);
		}		
		HashMap<String,String> riskDetails= fundetails.getRiskDetails(GOOMConstants.RISK_DETAILS_URL,resourceResolver);
		if(!footNote.isEmpty()){
			String[] footNotes = footNote.split(",");
			for (String items : footNotes) {
				int footNoteNum = Integer.parseInt(items);			
				listedFootNotes.add(footNoteNum);
			}
		}
		try {
			newjson=jObject.getJSONObject("details").getJSONArray("dailyUnitValue");
			asOfDate=jObject.getJSONObject("details").getString("asOfDate");
			asOfDate=DateHelper.formatDates(asOfDate,GOOMConstants.INPUT_DATE_FORMAT_INCEPTION_DATE,GOOMConstants.OUTPUT_DATE_FORMAT_INCEPTION_DATE);
			for(int i=0;i<newjson.length();i++){
				JSONObject jsonIteration=newjson.getJSONObject(i);
				String fundCode=jsonIteration.getString("fundCode");
				Boolean isFundExist = fundCheck(fundCode,pagePath,resourceResolver);				
				if(isFundExist){
					String netChangeVal;
					String color;		
					if(jsonIteration.getString("netChange")!="null"){
					double netChangeValue =Double.parseDouble(jsonIteration.getString("netChange"));
					netChangeVal= GOOMConstants.NET_CHARGE_POSITIVE;
					color="green";
					if(netChangeValue<0)
					{
						netChangeVal=GOOMConstants.NET_CHARGE_NEGATIVE;
						color="red";
					}
					else if(netChangeValue==0)
					{
						netChangeVal=GOOMConstants.NET_CHARGE_ZERO;
						color="blue";
					}
					}
					else{
						netChangeVal=GOOMConstants.NET_CHARGE_ZERO;
						color="blue";
					}
					FundDetailsBean fundDetail=fundetails.getFundDetails(pagePath,fundCode,resourceResolver);
					if(null!=fundDetail.getNumberedFootNotes() && !fundDetail.getNumberedFootNotes().isEmpty())
					{
						String[] numFootNotes=fundDetail.getNumberedFootNotes().toString().split(",");
						for (String items : numFootNotes) {
							int footNoteNumber = Integer.parseInt(items);			
							listedFootNotes.add(footNoteNumber);						
						}
					}	
					String riskColorCode=riskDetails.get(fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK, fundDetail.getRisk());
					jsonIteration.put(GOOMConstants.RISK_ORDER, fundDetail.getRiskOrder());				
					jsonIteration.put(GOOMConstants.MORNING_STAR_PATH,fundDetail.getMorningStarPath());
					jsonIteration.put(GOOMConstants.MANAGEMENT_FEE,fundDetail.getManagementFee());
					jsonIteration.put(GOOMConstants.FUND_TITLE, fundDetail.getFundTitle());
					jsonIteration.put(GOOMConstants.FUND_MANAGER, fundDetail.getFundManager());
					jsonIteration.put(GOOMConstants.RISK_COLOR_CODE, riskColorCode);
					jsonIteration.put(GOOMConstants.NET_CHNAGE, netChangeVal);
					jsonIteration.put(GOOMConstants.COLOR,color);
					jsonIteration.put(GOOMConstants.NUMBERED_FOOT_NOTE, fundDetail.getNumberedFootNotes());
					if(("MMKTD".equalsIgnoreCase(fundCode) || "NMMK".equalsIgnoreCase(fundCode)) && (result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_DAILYUNIT_VALUE) || result.equalsIgnoreCase(GOOMConstants.BY_PRODUCT_HISTORICAL_DAILYUNIT_VALUE))){
						jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, "");
					}else{
						jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, fundDetail.getFootNote());
					}
					//jsonIteration.put(GOOMConstants.FUND_IN_TABLE_FOOTNOTE, fundDetail.getFootNote());
					fundArray.put(jsonIteration);
				}
				fundArray = fundetails.sortJson(fundArray);
				jObject.put("FundArray",fundArray);
				if(!listedFootNotes.isEmpty()){
					footNoteArray=fundetails.getFootNoteDetails(listedFootNotes,resourceResolver);				
					jObject.put("FootNotesArray", footNoteArray);
				}
				jObject.put("date",asOfDate);
			}
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}
		return jObject;
	}	
	private JSONObject getErrorJsonData(int statusCode,JSONObject reseponseJson) {
		
		Page pagePath;
		JSONObject jObject=new JSONObject();
		Boolean errorCode = isErrorCode(statusCode);
		
		PageManager pageManager = getServiceResolver().adaptTo(PageManager.class);		
		pagePath = pageManager.getPage(GOOMConstants.FUND_PERFORMANCE_ERRORLIST_PATH);
		String message = null;
		GenericList list = pagePath.adaptTo(GenericList.class);
		String statusCodeVal = Integer.toString(statusCode);
		if (StringUtils.isBlank(statusCodeVal)) {
			statusCodeVal = GOOMConstants.DEFAULT;
		}
		message = list.lookupTitle(statusCodeVal);
		if(StringUtils.isBlank(message)){
			message = list.lookupTitle(GOOMConstants.DEFAULT);
		}
		try {
			if (errorCode) {
				if (null != reseponseJson && reseponseJson.length() != 0) {
					if (reseponseJson.has(GOOMConstants.CODE)) {				
						jObject.put(GOOMConstants.CODE, reseponseJson.getString(GOOMConstants.CODE));
						jObject.put(GOOMConstants.MESSAGE, message);
						jObject.put("StatusCode", statusCodeVal);
					}else{
						if(statusCodeVal.equalsIgnoreCase(GOOMConstants.NOTFOUND)){
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_NOTFOUND);	
						}else if(statusCodeVal.equalsIgnoreCase(GOOMConstants.SERVERERROR)){
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_SERVERERROR);
						}else if(statusCodeVal.equalsIgnoreCase(GOOMConstants.UNAVAILABLE)){
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_UNAVAILABLE);
						}else{
							jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_DEFAULT_ERRORCODE_UNAVAILABLE);
						}	
						jObject.put(GOOMConstants.MESSAGE, message);
						jObject.put("StatusCode", statusCodeVal);
					}
				}				
			}
		} catch (JSONException e) {
			LOG.error("JSONException:", e);
		}
		return jObject;
	}
	private ResourceResolver getServiceResolver(){
		ResourceResolver resourceResolver = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(ResourceResolverFactory.SUBSERVICE, GOOMConstants.JHINS_SERVICE);
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			//resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
		} catch (LoginException e) {
			LOG.error("LoginException:", e);
		}
		return resourceResolver;
	}
	private Boolean isErrorCode(int code) {
		boolean errorFlag = false;
		if (400 <= code && code < 600) {
			errorFlag = true;
		}
		return errorFlag;
	}
	private JSONObject getUnavailableErrorJsonData(int statusCode) {
		Page pagePath;
		JSONObject jObject=new JSONObject();
		Boolean errorCode = isErrorCode(statusCode);

		PageManager pageManager = getServiceResolver().adaptTo(PageManager.class);		
		pagePath = pageManager.getPage(GOOMConstants.FUND_PERFORMANCE_ERRORLIST_PATH);
		String message = null;
		GenericList list = pagePath.adaptTo(GenericList.class);
		String statusCodeVal = Integer.toString(statusCode);
		if (StringUtils.isBlank(statusCodeVal)) {
			statusCodeVal = GOOMConstants.DEFAULT;
		}
		message = list.lookupTitle(statusCodeVal);
		if(StringUtils.isBlank(message)){
			message = list.lookupTitle(GOOMConstants.DEFAULT);
		}
		try {
			jObject.put(GOOMConstants.CODE, GOOMConstants.CUSTOM_ERRORCODE_UNAVAILABLE);
			jObject.put(GOOMConstants.MESSAGE, message);
			jObject.put("StatusCode", GOOMConstants.UNAVAILABLE);
		}catch (JSONException e) {			
			e.printStackTrace();
		}
		return jObject;
	}
	public String getOauthToken() throws OAuthSystemException, OAuthProblemException {
		OAuthClient client = new OAuthClient(new URLConnectionClient());
		CryptoBase64 decryptClientSecret = new CryptoBase64();
		String token="";
		try {
			String clientSecret = String.valueOf(decryptClientSecret.decrypt(configService.getProperty(GOOMConstants.OAUTH_CLIENT_SECRET)))
					.trim();

			OAuthClientRequest request = OAuthClientRequest
					.tokenLocation(configService.getProperty(GOOMConstants.OAUTH_TOKENLOCATION_PATH))
					.setGrantType(GrantType.CLIENT_CREDENTIALS)
					.setClientId(configService.getProperty(GOOMConstants.OAUTH_CLIENT_ID))
					.setClientSecret(clientSecret)				
					.buildBodyMessage();
			request.addHeader("ContentType", ContentType.JSON);
			token = client.accessToken(request, OAuthJSONAccessTokenResponse.class).getAccessToken();
		}
		catch (CryptoException e) {
			LOG.error("CryptoException:", e);
		}
		return token;

	}

}