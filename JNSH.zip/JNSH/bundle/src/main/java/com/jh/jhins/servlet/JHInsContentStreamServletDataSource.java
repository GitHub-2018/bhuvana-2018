package com.jh.jhins.servlet;

import java.io.IOException;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.ui.components.Config;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.jh.jhins.constants.JHINSConstants;
import com.jh.jhins.servlet.KeyValue;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = JHINSConstants.SERVICE_DESCRIPTION, value = "JHInsContentStreamServlet"),
	@Property(name = JHINSConstants.SLING_SERVLET_PATH, value = { "/bin/sling/JHINSContentStreamDatasource" }),
	@Property(name = JHINSConstants.FIRM_ID_TEXT, value = { "FirmA", "FirmB", "FirmC", "FirmD" }),
	@Property(name = JHINSConstants.FIRM_ID_VALUE, value = { "firma", "firmb", "firmc", "firmd" }),
	@Property(name = JHINSConstants.IDENTITYSOURCE_ID_TEXT, value = { "IdA", "IdB", "IdC", "IdD" }),
	@Property(name = JHINSConstants.IDENTITYSOURCE_ID_VALUE, value = { "idsrca", "idsrcb", "idsrcc", "idd" }),
	@Property(name = JHINSConstants.SERVICE_VENDOR, value = "JHINS"),
	@Property(name = JHINSConstants.SLING_SERVLET_SELECTORS, value = { "firm", "idSrc" }),
	@Property(name = JHINSConstants.SLING_SERVLET_METHOD, value = "GET", propertyPrivate = true) })

/**
 * JHInsContentStreamServlet for the getting the firm ids and identity sources
 *
 *
 */
public class JHInsContentStreamServletDataSource extends SlingAllMethodsServlet {
	private static Logger LOG = LoggerFactory.getLogger(JHInsContentStreamServletDataSource.class);

	private static final long serialVersionUID = 1L;
	/**
	 * Method to fetch the sling properties
	 *
	 */

    private static Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		synchronized (context) {
			properties = context.getProperties();
		}
	}

	/**
	 * doGet method
	 */

	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		
		final ResourceResolver resourceResolver = request.getResourceResolver();

		Object[] firmobjArr = { properties.get("firm.id.text") };
		Object[] firmValobjArr = { properties.get("firm.id.value") };
		Object[] idSrcobjArr = { properties.get("identitySource.id.text") };
		Object[] idSrcValobjArr = { properties.get("identitySource.id.value") };
		String[] firmIdValues = null;
		String[] firmIdTexts = null;
		String[] identitySourceIDTexts = null;
		String[] identitySourceIDValues = null;

		for (Object firmtxtobj : firmobjArr) {
			if (firmtxtobj instanceof String[]) {
				firmIdTexts = (String[]) firmtxtobj;
			}

		}
		for (Object firmvalobj : firmValobjArr) {
			if (firmvalobj instanceof String[]) {
				firmIdValues = (String[]) firmvalobj;
			}

		}
		for (Object idsrctxtobj : idSrcobjArr) {
			if (idsrctxtobj instanceof String[]) {
				identitySourceIDTexts = (String[]) idsrctxtobj;
			}

		}
		for (Object idsrcValobj : idSrcValobjArr) {
			if (idsrcValobj instanceof String[]) {
				identitySourceIDValues = (String[]) idsrcValobj;
			}

		}
		
		//String selectorsValue = request.getRequestPathInfo().getSelectorString();
		
		Config dsCfg = new Config(request.getResource().getChild("datasource"));
		String selectorsValue = dsCfg.get("selector");
		LOG.debug("selectorsValue" + selectorsValue);
		
		List<KeyValue> firmList = new ArrayList<KeyValue>();
		List<KeyValue> identityList = new ArrayList<KeyValue>();
		final Collator collator = Collator.getInstance(request.getLocale());
	    
	    if (dsCfg.get("addNone", false)) {
	    	firmList.add(new KeyValue("", ""));
	    	identityList.add(new KeyValue("", ""));
	    }
	    

		if (selectorsValue.equalsIgnoreCase(JHINSConstants.PARAM_FIRM)) {
			if (firmIdValues != null && firmIdTexts != null) {
				for (int i = 0; i < firmIdValues.length; i++) {
					try {
						firmList.add(new KeyValue(firmIdTexts[i], firmIdValues[i]));
						LOG.info("firmIdTexts : "+firmIdTexts+ "firmIdValues : "+firmIdValues);
						
					} catch (Exception e) {
						LOG.error("JSONException");
					}
								}

			}
			
			

		    Collections.sort(firmList, new Comparator<KeyValue>() {
		        public int compare(KeyValue o1, KeyValue o2) {
		            return collator.compare(o1.value, o2.value);
		        }
		    });

		    @SuppressWarnings("unchecked")
		    DataSource ds = new SimpleDataSource(new TransformIterator(firmList.iterator(), new Transformer() {
				
				public Object transform(Object input) {
					try {
		                KeyValue keyValue = (KeyValue) input;

		                ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
		                vm.put("text", keyValue.key);
		                vm.put("value", keyValue.value);

		                return new ValueMapResource(resourceResolver, new ResourceMetadata(), "nt:unstructured", vm);
		            } catch (Exception e) {
		                throw new RuntimeException(e);
		            }
				}
			}));
		    
		    request.setAttribute(DataSource.class.getName(), ds);

		}
		
		else {
			if (identitySourceIDValues != null && identitySourceIDTexts != null) {
				for (int i = 0; i < identitySourceIDTexts.length; i++) {
					try {
						identityList.add(new KeyValue(identitySourceIDTexts[i], identitySourceIDValues[i]));
						LOG.info("identitySourceIDTexts : "+identitySourceIDTexts+ "identitySourceIDValues : "+identitySourceIDValues);
					} catch (Exception e) {
						LOG.error("JSONException");
					}
					
				}

			}
			
			Collections.sort(identityList, new Comparator<KeyValue>() {
		        public int compare(KeyValue o1, KeyValue o2) {
		            return collator.compare(o1.value, o2.value);
		        }
		    });

		    @SuppressWarnings("unchecked")
		    DataSource ds = new SimpleDataSource(new TransformIterator(identityList.iterator(), new Transformer() {
				
				public Object transform(Object input) {
					try {
		                KeyValue keyValue = (KeyValue) input;

		                ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
		                vm.put("text", keyValue.key);
		                vm.put("value", keyValue.value);

		                return new ValueMapResource(resourceResolver, new ResourceMetadata(), "nt:unstructured", vm);
		            } catch (Exception e) {
		                throw new RuntimeException(e);
		            }
				}
			}));
		    
		    request.setAttribute(DataSource.class.getName(), ds);

		}

	}

}
