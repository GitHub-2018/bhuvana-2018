package com.jh.jhins.constants;

public class AssetConstants {
	public static final String DAM_PATH = "/content/dam/jhins";
	public static final String PRODUCT_PROP_NAME="@jcr:content/metadata/jh:product";
	public static final String TOPIC_PROP_NAME="@jcr:content/metadata/jh:topic";
	public static final String TYPE_PROP_NAME="@jcr:content/metadata/jh:type";
	public static final String CONTENT_TYPE="application/json; charset=UTF-8";
	
	public static final String ARTICLE_TEMPLATE = "/apps/JHINS/templates/articletemplate";
	public static final String SLING_RESOURCETYPE="@jcr:content/sling:resourceType";
	public static final String CQ_TEMPLATE="@jcr:content/cq:template";
	public static final String METADATA_FIRM="@jcr:content/metadata/firm";
	public static final String ORDER_BY="@jcr:content/cq:lastReplicated";
	public static final String ORDER_BY_MODIFIED="@jcr:content/jcr:lastModified";
	public static final String ODERBY_SORT="desc";
		
	public static final String METADATA_TOPIC="@jcr:content/metadata/topic";
	public static final String METADATA_CHANNEL="@jcr:content/metadata/channel";
    public static final String CQ_TAGS__PROPERTYNAME = "@jcr:content/metadata/cq:tags";
	

	public static final String PARAM_TYPE = "assetType";
	public static final String PARAM_FUNCTIONALITY = "functionality";
	public static final String PARAM_USERID = "userId";
	public static final String PARAM_FIRMID = "firmId";
	public static final String PARAM_LIMIT = "limit";
	public static final String PARAM_TOPIC = "topic";
	public static final String PARAM_PATH = "path";
	public static final String PARAM_STATE = "state";
	public static final String PARAM_PRODUCT = "product";
	public static final String PROSPECTUSES_TYPE = "prospectusesType";
	public static final String PROSPECTUSES_TITLE = "prospectusesTitle";
	public static final String PARAM_CHANNEL = "channel";
	public static final String PARAM_DATE = "date";
	public static final String PARAM_IMG_PATH="imgPath";
	public static final String PARAM_TITLE="title";
	public static final String PARAM_DESCRIPTION = "description";
	public static final String PARAM_PRODUCT1 = "product1";
	public static final String PARAM_PRODUCT2 = "product2";
	public static final String CONSUMER_MATERIAL="consumermaterials";
	public static final String PRODUCER_MATERIAL="producermaterials";
	public static final String SALES_FLYER="salesflyers";
	public static final String SALES_FLYER_COMP="salesflyerscomponent";
	public static final String INVESTMENT_INFORMATION="investmentinformation";
	public static final String FUNDS_RATE_AND_INFO="fundrate";
	public static final String PROSPECTUSES="prospectuses";
	public static final String CONSUMER_GUIDE="/content/cq:tags/JHINS/type/consumer_guide";
	public static final String TECHNICHAL_GUIDE="/content/cq:tags/JHINS/type/technical_guide";
	public static final String SELLERS_GUIDE="/content/cq:tags/JHINS/type/sellers_guide";
	public static final String SAMPLE_CONTRACT="/content/cq:tags/JHINS/type/sample_contract";
	public static final String PRODUCER_GUIDE="/content/cq:tags/JHINS/type/producerguide";
	public static final String USERTO="UserTO";
	public static final String JH_CONSUMER_APPROVED_YES="yes";
	public static final String SLING_REQUEST="slingRequest";
	public static final String NEWS_TYPE="news";
	public static final String ASSET_TYPE="asset";
	public static final String PARSYS="par_leftcolumn";
	public static final String PARAM_PRIORITY = "priortiyVal";
	
	public static final String IMAGE="image";
	public static final String IMAGE_REFERENCE="fileReference";
	public static final String ASSET_LAST_REPLICATED="cq:lastReplicated";
	public static final String ASSET_LAST_MODIFIED="jcr:lastModified";
	public static final String CUSTOM_DATE_FORMAT="MMMM dd,YYYY";
	public static final String SALES_FLYERS="salesflyers";
	public static final String SALES_FLYERS_COMPONENT="salesflyerscomp";
	public static final String RELATED_TOPIC="relatedtopic";
	public static final String MY_NEWS_AND_UPDATES="MyNewsAndUpdates";
	public static final String RECENT_NEWS="Recentnews";
	public static final String RELATED_ARTICLE="RelatedArticles";
	public static final String RELATED_PAGES = "RelatedPages";
	public static final String RELATED_RESOURCES = "RelatedResources";
	public static final String PARAM_FIRM = "firm";
	public static final String PAGE_TYPE = "cq:Page";
	public static final String RIGHT_RAILS_UPDATES = "rightrailuserupdate";
	public static final String RECENT_PRODUCT_CHANGE = "recentproductchange";
	public static final String ASSET_FEED = "assetfeed";
	public static final String KEY_PRODUCT_MATERIAL = "keyproductmaterial";
	public static final String RELATED_DOCUMENTS = "relateddocuments";
    public static final String DOMAIN="domain";
    public static final String SEEMORELINK="seemorelink";
    public static final String SEEMORELABEL="seemorelabel";
	
}
