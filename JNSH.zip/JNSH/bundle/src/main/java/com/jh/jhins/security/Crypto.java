package com.jh.jhins.security;

public interface Crypto
{
    /**
     * @param a_text
     * @return the encrypted string
     * @throws CryptoException
     */
    public char[] encrypt(String a_text) throws CryptoException;

    /**
     * @param a_decrypt
     * @return the decrypted string
     * @throws CryptoException
     */
    public char[] decrypt(String a_decrypt) throws CryptoException;
}