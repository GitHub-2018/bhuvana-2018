package com.jh.jhins.bean;

import java.util.List;

public class EmailDetails {
	
	private String ccrecipient;
	private String firstName;
	private String insuredName;
	private String firmName;
	private String requestor;
	private String emailAddress;
	private String comments;
	private String date;
	private String telephone;
	private String category;
	private String subject;
	private String fromAddress;
	private List<String> toList;
	private List<String> ccList;
	private String message;
	public List<String> getToList() {
		return toList;
	}
	public void setToList(List<String> toList) {
		this.toList = toList;
	}
	public List<String> getCcList() {
		return ccList;
	}
	public void setCcList(List<String> ccList) {
		this.ccList = ccList;
	}
	public String getCcEmailAddress() {
		return emailAddress;
	}
	public void setCcEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public String getRequestor() {
		return requestor;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public String getToEmailAddress() {
		return emailAddress;
	}
	public void setToEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubject() {
		return subject;
	}
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
	public String getFromAddress() {
		return fromAddress;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "EmailDetails [toList=" + toList + ", ccList=" + ccList +", firstName=" + firstName + ", insuredName=" + insuredName + ", firmName="
				+ firmName + ", requestor=" + requestor + ",date="+date+",comments="+comments+","
						+ "telephone="+telephone+",category="+category+",subject="+ subject + ", message=" + message + "]";
	}
}
