package com.jh.jhins.helper;

import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.jh.jhins.security.Crypto;
import com.jh.jhins.security.CryptoBase64;

public final class SecurityHelper {
	
	private static final Logger LOG = LoggerFactory.getLogger(SecurityHelper.class);	
	
	// encrypt/decrypt util
	private static final Crypto crypto = new CryptoBase64(); 
	
	// Private constructor to avoid object creation
	private SecurityHelper(){
		
	}
	

	
	public static final char[] encryptText(String textToEncrypt) throws Exception
	{
		return crypto.encrypt(textToEncrypt);
	}

	public static final String decryptText(String encryptedId) throws Exception
	{
		return new String(crypto.decrypt(encryptedId));
	}	
	

	

	public static boolean isAuthorEnvironment(SlingSettingsService settingsService){
		 final Set<String> runmodes = settingsService.getRunModes();
		 for(String runMode : runmodes){
			 if(StringUtils.equalsIgnoreCase(runMode, "author")){
				 return true;
			 }
		 }
		 return false;
	}
	
}