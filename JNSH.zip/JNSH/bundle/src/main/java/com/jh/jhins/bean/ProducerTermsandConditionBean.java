package com.jh.jhins.bean;

public class ProducerTermsandConditionBean {
	

	private String profileId;
	private String userRole;
	private String npnNo;
	private String lastName;
	private String ssnNo;
	public String getProfileId() {
		return profileId;
	}
	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getNpnNo() {
		return npnNo;
	}
	public void setNpnNo(String npnNo) {
		this.npnNo = npnNo;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSsnNo() {
		return ssnNo;
	}
	public void setSsnNo(String ssnNo) {
		this.ssnNo = ssnNo;
	}
	
	
}
