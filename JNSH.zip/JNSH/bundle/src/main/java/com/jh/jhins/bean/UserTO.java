package com.jh.jhins.bean;

import com.day.cq.tagging.Tag;

public class UserTO {
	private String userID;
	private String firmID;
	private Tag firmTag;
	private String channelName;
	private String searchCount;
	private String pageCount;
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getFirmID() {
		return firmID;
	}
	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getSearchCount() {
		return searchCount;
	}
	public void setSearchCount(String searchCount) {
		this.searchCount = searchCount;
	}
	public String getPageCount() {
		return pageCount;
	}
	public void setPageCount(String pageCount) {
		this.pageCount = pageCount;
	}
	public Tag getFirmTag() {
		return firmTag;
	}
	public void setFirmTag(Tag firmTag) {
		this.firmTag = firmTag;
	}
	
	

}
