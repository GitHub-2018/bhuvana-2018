package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhins.constants.GOOMConstants;
import com.jh.jhins.interfaces.DailyUnitValuesService;
@SlingServlet(paths="/bin/sling/dailyUnitValues",metatype=true, methods = HttpConstants.METHOD_GET )
public class DialyUnitValuesServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(DialyUnitValuesServlet.class);

	@Reference
	DailyUnitValuesService dailyUnitValuesService;

	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);

	}
	protected final void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		XSSAPI xssAPI = request.getResourceResolver().adaptTo(XSSAPI.class);
		String inputData = xssAPI.getValidJSON(request.getParameter("inputJSON"), null);
		JSONObject inputJSON=null;
		JSONObject dialyUnitResponse=null;
		try {
			inputJSON = new JSONObject(inputData);		
			String productCode = inputJSON.getString("productCode");
			String companyCode = inputJSON.getString("companyCode");
			String mProductFlag =inputJSON.getString("mproduct");
			String shortCode = inputJSON.getString("productShortName");
			JSONArray fundCodeList =inputJSON.getJSONArray("funds");
			if((null!=productCode && !productCode.isEmpty()) || (!shortCode.isEmpty()&& null != shortCode)){
				if("IUL".equalsIgnoreCase(productCode)){
					if("0".equalsIgnoreCase(companyCode)){
						companyCode = "JHUSA";
					}
					dialyUnitResponse = dailyUnitValuesService.getIULProductDetails(productCode, companyCode, request);
				}else{
					dialyUnitResponse = dailyUnitValuesService.dialyUnitValues(productCode,companyCode,mProductFlag, shortCode);
					int statusCode = Integer.parseInt(dialyUnitResponse.getString("statusCode"));
					response.setContentType(GOOMConstants.APPLICATION_JSON);
					response.setCharacterEncoding(GOOMConstants.CHARSET);
					if(statusCode == 200){
						dialyUnitResponse.remove("statusCode");
						dialyUnitResponse.put("code", statusCode);
						response.setStatus(HttpServletResponse.SC_OK);
					}else if(statusCode == 400){
						dialyUnitResponse.remove("statusCode");
						dialyUnitResponse.put("code", statusCode);
						response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
					}else if (statusCode == 403){
						dialyUnitResponse.remove("statusCode");
						dialyUnitResponse.put("code", statusCode);
						response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
					}else if( statusCode == 404){
						dialyUnitResponse.remove("statusCode");
						dialyUnitResponse.put("code", statusCode);
						response.setStatus(HttpServletResponse.SC_NOT_FOUND);
					}else if(statusCode == 500){
						dialyUnitResponse.remove("statusCode");
						dialyUnitResponse.put("code", statusCode);
						response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
					}
				}
				
			}
			else
			{
				dialyUnitResponse = dailyUnitValuesService.getFundDetails(fundCodeList,mProductFlag);
			}
			PrintWriter out = response.getWriter();
			out.write(xssAPI.getValidJSON(dialyUnitResponse.toString(), null));
			out.flush();
			out.close();
		} catch (NumberFormatException e) {
			LOG.error("NumberFormatException::::",e );
		} catch (JSONException e) {
			LOG.error("JSONException::::",e );
		}
	}
}
