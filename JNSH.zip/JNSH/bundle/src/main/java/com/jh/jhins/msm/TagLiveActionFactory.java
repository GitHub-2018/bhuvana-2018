package com.jh.jhins.msm;

import java.util.Arrays;
import java.util.Collections;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.io.JSONWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.WCMException;
import com.day.cq.wcm.msm.api.ActionConfig;
import com.day.cq.wcm.msm.api.LiveAction;
import com.day.cq.wcm.msm.api.LiveActionFactory;
import com.day.cq.wcm.msm.api.LiveRelationship;



@Component(metatype = false)
@Service
public class TagLiveActionFactory implements LiveActionFactory<LiveAction> {
	@Property(value="tagLiveAction")
	static final String actionname = LiveActionFactory.LIVE_ACTION_NAME;
	
	public LiveAction createAction(Resource config) {
		ValueMap configs;
		/* Adapt the config resource to a ValueMap */
        if (config == null || config.adaptTo(ValueMap.class) == null) {
            configs = new ValueMapDecorator(
            		Collections.<String, Object>emptyMap());
        } else {
            configs = config.adaptTo(ValueMap.class);
        }
		
		return new TagLiveAction(actionname, configs);
	}
	public String createsAction() {
		return actionname;
	}
	/*************  LiveAction ****************/
	private static class TagLiveAction implements LiveAction {
		private String name;
		private ValueMap configs;
		private static final Logger log = LoggerFactory.getLogger(TagLiveAction.class);

		public TagLiveAction(String nm, ValueMap config){
			name = nm;
			configs = config;
		}

		public void execute(Resource source, Resource target,
				LiveRelationship liverel, boolean autoSave, boolean isResetRollout)
						throws WCMException {
			
			String[] tags = null;
			
			log.info(" *** Executing TagLiveAction *** ");
			log.info("source path is "+source);
			//log.info("target path is "+target.getPath());

			
			if ((Boolean) configs.get("repcqTags")){
				
				String targetTag = (String)configs.get("tagrgetTag");

				if (source != null && source.adaptTo(Node.class) !=  null){
					ValueMap sourcevm = source.adaptTo(ValueMap.class);
					tags = sourcevm.get(com.day.cq.wcm.api.NameConstants.PN_TAGS, String[].class);	
					if(null==tags){
						log.info("tag == null");
						return;
					}
				}else{
				log.info("source is null or not a node");
				}

				/* set the target node's la-lastModifiedBy property */
				Session session = null;
				if (target != null && target.adaptTo(Node.class) !=  null){
					ResourceResolver resolver = target.getResourceResolver();
					TagManager tagManager = resolver.adaptTo(TagManager.class);
					session = resolver.adaptTo(javax.jcr.Session.class);

					try{

						Tag[] arrTags = tagManager.getTags(source);
						if(arrTags!=null){
							log.info("arrTags length"+arrTags.length);
							
							Tag[] targetArrTags = Arrays.copyOf(arrTags, arrTags.length+1); //new Tag[arrTags.length+1];
							if(targetArrTags!=null){
								log.info("targetArrTags length"+targetArrTags.length);
								
								Tag targetTagVal = tagManager.resolve(targetTag);
								
								if(arrTags.length>0 && null!=targetTagVal){
									
									targetArrTags[arrTags.length] = targetTagVal;
									tagManager.setTags(target, targetArrTags);
									
								}else{
									log.info("target tags are nul");
									return;
								}
												
								log.info(" *** Target node cq:tags property updated: {} ***",targetTag);
							}
						}
					}catch(Exception e){
						
						log.error("exception while setting tag",e);
						log.info("exception while setting tag",e);
					}	
				}else{
					log.info("target == null");
				}
				if(autoSave){
					try {
						if(session!=null){
						session.save();
						}
					} catch (Exception e) {
						try {
							session.refresh(true);
						} catch (RepositoryException e1) {
							
							log.error("RepositoryException while setting tag",e1);
							log.info("RepositoryException while setting tag",e1);
						}
						log.error("exception while setting tag",e);
						log.info("exception while setting tag",e);
					} 
				}			
			}
		}
		public String getName() {
			return name;
		}

		/************* Deprecated *************/
		@Deprecated
		public void execute(ResourceResolver arg0, LiveRelationship arg1,
				ActionConfig arg2, boolean arg3) throws WCMException {		
		}
		@Deprecated
		public void execute(ResourceResolver arg0, LiveRelationship arg1,
				ActionConfig arg2, boolean arg3, boolean arg4)
						throws WCMException {		
		}
		@Deprecated
		public String getParameterName() {
			return null;
		}
		@Deprecated
		public String[] getPropertiesNames() {
			return null;
		}
		@Deprecated
		public int getRank() {
			return 0;
		}
		@Deprecated
		public String getTitle() {
			return null;
		}
		@Deprecated
		public void write(JSONWriter arg0) throws JSONException {
		}
	}
}
