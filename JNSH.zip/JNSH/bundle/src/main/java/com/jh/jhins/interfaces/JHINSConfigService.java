package com.jh.jhins.interfaces;

public interface JHINSConfigService {
	public String getConfigProperty(final String property);


}