package com.jh.jhins.config;

import org.apache.felix.scr.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Component(
		name = "Personalization Configuration Service",
		description = "Service for configuring Personalization settings",
		label = "Personalization Configuration Service",
		immediate = true,
		metatype = true
)
@Service
@Properties({
		@Property(
				name = "iframe.source.name",
				label = "The location of the personalization iFrame"
		)
})
public class PersonalizationConfigServiceImpl implements PersonalizationConfigService {
	private static final Logger LOG = LoggerFactory.getLogger(PersonalizationConfigServiceImpl.class);

	private String iFrameSource;

	public String getIframeSource()
	{
		LOG.info("Returning new iframe: "+iFrameSource);
		return iFrameSource;
	}


	@Activate
	protected void activate(final Map<String, Object> config) throws Exception {
		resetService(config);
	}

	@Modified
	protected void modified(final Map<String, Object> config) {
		resetService(config);
	}

	private synchronized void resetService(final Map<String, Object> config) {
		iFrameSource = config.containsKey(IFRAME_SOURCE_NAME) ? (String) config.get(IFRAME_SOURCE_NAME) : "//test.register.jhancock.com/ProducerSupport-WAR/";
		LOG.info("New location of iframe: "+ iFrameSource);
	}
}

