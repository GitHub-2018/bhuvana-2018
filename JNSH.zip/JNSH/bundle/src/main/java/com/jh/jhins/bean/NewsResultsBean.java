package com.jh.jhins.bean;

public class NewsResultsBean {

}
