package com.jh.jhins.interfaces;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONObject;


public interface JHINSGetAllFundDetailsService {
	
	public abstract JSONObject getAllFundDetails(ResourceResolver resourceResolver);

}
