package com.jh.jhins.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.jh.jhins.helper.SecurityHelper;


@SlingServlet(
paths={"/bin/JHINS/encryptionUtil"},
methods = "GET")
public class JHINSEncryptionServlet extends SlingAllMethodsServlet{

	private static final Logger LOG = LoggerFactory.getLogger(JHINSEncryptionServlet.class);
	
	@Reference
	private SlingSettingsService slingSettingsService;
	

	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws IOException {
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		
		// do not run this code in publish environment
		if(!SecurityHelper.isAuthorEnvironment(slingSettingsService)){
			out.println("Dispatcher cache - cannot run in publish environment");
			return;
		}
		
		String textToEncrypt = request.getParameter("encryptText");
		
		// return NULL if the query string parameter is missing
		if(StringUtils.isEmpty(textToEncrypt)){
			out.println("Query String param cannot be empty");
			return;
		}
		
		try {
			out.println(String.valueOf(SecurityHelper.encryptText(textToEncrypt)));
		} catch (Exception e) {
			LOG.error("Error in "+getClass().getName(),e);
		}
	}
}
