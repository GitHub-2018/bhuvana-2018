package com.jh.jhins.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.jh.jhins.bean.AppointmentStatusArrayBean;
import com.jh.jhins.bean.AppointmentStatusBean;
import com.jh.jhins.bean.HeaderBean;
import com.jh.jhins.bean.SearchRequests;
import com.jh.jhins.interfaces.AppointmentStatusService;
import com.jh.jhins.interfaces.GOOMConfigService;
import com.jh.jhins.interfaces.GoomAuthorableListService;
import com.jh.jhins.security.CryptoBase64;
import com.jh.jhins.security.CryptoException;

@Component
@Service
public class AppointmentStatusServiceImpl implements AppointmentStatusService{

	private static final Logger LOG = LoggerFactory.getLogger(AppointmentStatusServiceImpl.class);
	public static final String PRODUCER = "Producer";
	public static final String PRODUCER_SUPPORT = "ProducerSupport";
	public static final String PRODUCER_HEADER_KEY = "producer.header.key";
	public static final String PRODUCER_HEADER_VALUE = "producer.header.value";
	public static final String APPT_PRODUCER_URL = "appt.producer.url";
	public static final String APPT_PRODUCERSUPPORT_URL = "appt.producersupport.url";
	public static final String FIRM_SUPPORT_URL = "appt.firmsupport.url";
	public static final String APPOINTMENT_STATUS = "appointmentstatus";
	public static final String USER_PROFILE_ID = "UserProfileID";
	public static final String STATES_TERRITORIES ="StatesTerritories";
	public static final String PRODUCT_TYPES ="ProductTypes";
	public static final String APPLICATION_JSON = "application/json";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String CHARSET = "UTF-8";
	public static final String FIRM_SUPPORT = "FirmSupport"; 
	public static final String SUPERUSER = "SuperUser_SN";
	public static final String LASTNAME = "LastName";
	public static final String LAST_FOUR_SSN_NO = "LastFourSsn";
	public static final String NPN_NO = "Npn";
	public static final String TIN_NO = "Tin";
	public static final String PAYROLL_NO = "PayrollNumber";
	public static final String AGENT_CODE = "AgentCode"; 
	public static final String REQUEST_TYPE = "RequestType";
	public static final String COMMENTS = "Comments";
	
	
	@Reference
	private GOOMConfigService configService;	
	
	@Reference
	private GoomAuthorableListService service;
	
	public String getProducerData(AppointmentStatusBean statusBean) {
		String jsonResponse = null;
		String role = statusBean.getUserRole();
		HeaderBean bean = getGoomConfigurations(role);
		jsonResponse = producerJsonData(statusBean, bean);
		
		return jsonResponse;
	}
	
	private HeaderBean getGoomConfigurations(String role) {
		CryptoBase64 decryptPassword = new CryptoBase64();
		HeaderBean headerBean = new HeaderBean();
		try {
			headerBean.setKey(configService.getProperty(PRODUCER_HEADER_KEY));
			headerBean.setValue(String.valueOf(decryptPassword.decrypt(configService.getProperty(PRODUCER_HEADER_VALUE))).trim());
			headerBean.setUrl(getEndPointUrl(role));
			
		} catch (CryptoException e) {
			LOG.error("CryptoException",e);
		}
		return headerBean;
	}

	private String producerJsonData(AppointmentStatusBean statusBean,HeaderBean bean) {
		String singleSearchResponse = null;
			try {
				String role = statusBean.getUserRole();
				JSONObject jsonObj = new JSONObject();
				List<String> states = new ArrayList<String>();
				states.addAll(statusBean.getStates());
				List<String> products = new ArrayList<String>();
				products.addAll(statusBean.getProducts());
				jsonObj.put(USER_PROFILE_ID, statusBean.getProfileId());
				jsonObj.put(STATES_TERRITORIES, states);
				jsonObj.put(PRODUCT_TYPES, products);
				LOG.debug("input Json:::::::::::::::::" + jsonObj.toString());
				StringEntity input = new StringEntity(jsonObj.toString());
				input.setContentType(APPLICATION_JSON);
				singleSearchResponse = getJsonResponse(input, bean, role);
			} catch (JSONException e) {
				LOG.error("JSONException", e);
			} catch (ParseException e) {
				LOG.error("ParseException", e);
			} catch (UnsupportedEncodingException e) {
				LOG.error("UnsupportedEncodingException", e);
			}

		return singleSearchResponse;
	}
	
	private String getEndPointUrl(String userRole){
			String url= "";
			if(PRODUCER.equalsIgnoreCase(userRole)){
				url = configService.getProperty(APPT_PRODUCER_URL);
			}else if(PRODUCER_SUPPORT.equalsIgnoreCase(userRole)){
				url = configService.getProperty(APPT_PRODUCERSUPPORT_URL);
			}else if(FIRM_SUPPORT.equalsIgnoreCase(userRole) || SUPERUSER.equalsIgnoreCase(userRole)){
				url = configService.getProperty(FIRM_SUPPORT_URL);
			}
			LOG.debug("Appointment Status Rest End Point URL :"+url);
			return url;
		}
	private String getJsonResponse(StringEntity input, HeaderBean bean, String role) {
		String responseData = null;
		try {
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(bean.getUrl());
			postRequest.setEntity(input);
			postRequest.addHeader(bean.getKey(),bean.getValue());
			postRequest.addHeader(CONTENT_TYPE, APPLICATION_JSON);
			HttpResponse response = httpClient.execute(postRequest);
			String responseString = EntityUtils.toString(response.getEntity(), CHARSET);
			LOG.debug("Rest Service response::::::"+responseString);
			String resultPage = APPOINTMENT_STATUS;
			if (response.getStatusLine().getStatusCode() != 200) {
				int statusCode = response.getStatusLine().getStatusCode();
				LOG.debug("Response code::::" + statusCode);
				responseData = service.finalJsonData(responseString, resultPage, statusCode, role);
				LOG.debug("final Error json response with Comments::::::::::::::::::::"+responseData);
			}else{
				JSONObject commentsJson = service.commentsJson();
				JSONObject responseObject = new JSONObject(responseString);
				responseObject.put(COMMENTS, commentsJson);
				responseData = responseObject.toString();
				LOG.debug("final json response with Comments :::"+responseData.toString());
			}
			httpClient.getConnectionManager().shutdown();
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		}catch (ClientProtocolException e) {
			LOG.error("ClientProtocolException", e);
		} catch (IOException e) {
			LOG.error("IOException", e);
		}
		return responseData;
	}

	public String getFirmSupporMultiSearchData(AppointmentStatusArrayBean searchBean) {
		String jsonResponse = null;
		String role = searchBean.getUserRole();
		HeaderBean bean = getGoomConfigurations(role);
		jsonResponse = FirmSupportJsonData(searchBean, bean);
		
		return jsonResponse;
	}

	private String FirmSupportJsonData(AppointmentStatusArrayBean searchBean, HeaderBean bean) {
LOG.debug("FirmSupportJsonData method");
		String singleSearchResponse = null;
		try {
			String role = searchBean.getUserRole();
			//Gson gson = new Gson();
			JSONObject jsonObj = new JSONObject();
			JSONArray searchList = new JSONArray();
			List<SearchRequests> searchBeanList = searchBean.getSearchRequests();
			for(SearchRequests requestBean : searchBeanList){
				JSONObject searchBeanObj = new JSONObject();
				if(StringUtils.isNotEmpty(requestBean.getLastName())){
					searchBeanObj.put(LASTNAME, requestBean.getLastName());
					searchBeanObj.put(LAST_FOUR_SSN_NO, requestBean.getLastFourSSN());
				}else if(StringUtils.isNotEmpty(requestBean.getNpn())){
					searchBeanObj.put(NPN_NO, requestBean.getNpn());
				}else if (StringUtils.isNotEmpty(requestBean.getTin())){
					searchBeanObj.put(TIN_NO, requestBean.getTin());
				}else if (StringUtils.isNotEmpty(requestBean.getPayrollNumber())){
					searchBeanObj.put(PAYROLL_NO, requestBean.getPayrollNumber());
				}else if (StringUtils.isNotEmpty(requestBean.getAgentCode())){
					searchBeanObj.put(AGENT_CODE, requestBean.getAgentCode());
				}
				searchBeanObj.put(REQUEST_TYPE, requestBean.getRequestType());
				searchBeanObj.put(STATES_TERRITORIES, requestBean.getStatesTerritories());
				searchBeanObj.put(PRODUCT_TYPES, requestBean.getProductTypes());
				searchList.put(searchBeanObj);
			}
			LOG.debug("searchList "+searchList.toString());
			//String inputJsonValue= gson.toJson(searchBeanList);
			jsonObj.put("SearchRequests", searchList);
			LOG.debug("FirmSupport input Json:::::::::::::::::" + jsonObj.toString());
			StringEntity input = new StringEntity(jsonObj.toString());
			input.setContentType(APPLICATION_JSON);
			singleSearchResponse = getJsonResponse(input, bean, role);
		} catch (JSONException e) {
			LOG.error("JSONException", e);
		} catch (ParseException e) {
			LOG.error("ParseException", e);
		} catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException", e);
		}

	return singleSearchResponse;
	
	}		
}

