package com.jh.jhins.workflow;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.HistoryItem;
import com.adobe.granite.workflow.exec.ParticipantStepChooser;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.Workflow;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.metadata.MetaDataMap;

@Component(immediate = true)
@Service
@Properties({ @Property(name = WorkflowConstants.SERVICE_DESCRIPTION, value = "JHINS Dynamic Participation Chooser"),
	@Property(name = WorkflowConstants.SERVICE_VENDOR, value = "JHINS"),
	@Property(name = WorkflowConstants.CHOOSER_LABEL, value = "JHINS Workflow Dynamic Participation Chooser") })

public class DynamicParticipantStepChooser implements ParticipantStepChooser {
	
	@Reference
	ResourceResolverFactory resolverFactory;
	
	private static final Logger LOG = LoggerFactory.getLogger(DynamicParticipantStepChooser.class);
	/**
	 * getParticipant step for getting the users 
	 * from the previous step 
	 * 
	 */
	public String getParticipant(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap)
			throws WorkflowException {

		WorkflowData workflowData = workItem.getWorkflowData();
		String principalParticipiant = WorkflowConstants.ADMIN;
		String participant = WorkflowConstants.ADMIN;
		Node jcrNode = null;
		ResourceResolver resourceResolver = null;
		LOG.debug("before try");
		try {
			if (workflowData.getPayloadType().equals(WorkflowConstants.TYPE_JCR_PATH)) {
				
				Map<String, Object> param = new HashMap<String, Object>();
				param.put(ResourceResolverFactory.SUBSERVICE, "JHINSWorkflowService");
				resourceResolver = resolverFactory.getServiceResourceResolver(param);
			
				
				LOG.debug("workflowData"+workflowData.getPayloadType());
				Session jcrSession = wfSession.adaptTo(Session.class);
				LOG.debug("workflowData"+jcrSession);
				LOG.debug("workflowData payload"+workflowData.getPayload());
				String payloadPath=workflowData.getPayload().toString();
				//jcrSession.getNode((String)workflowData.getPayload());
			
				if(!("").equals(payloadPath)){
					LOG.debug("getting resource");
					Resource resource = resourceResolver.getResource(payloadPath);
					Node node = (null != resource) ? resource.adaptTo(Node.class) : null;
					
					if (node != null && node.hasNode(WorkflowConstants.JCR_CONTENT)) {
						LOG.debug("node"+node.getPath());
						jcrNode = node.getNode(WorkflowConstants.JCR_CONTENT);
						if (jcrNode != null && jcrNode.hasProperty(WorkflowConstants.PROPERTY_SELECT)) {
							principalParticipiant = jcrNode.getProperty(WorkflowConstants.PROPERTY_SELECT).getValue()
									.toString();
						}
					}
				}
			}
			Workflow wf = workItem.getWorkflow();
			List<HistoryItem> wfHistory = wfSession.getHistory(wf);
			if (!wfHistory.isEmpty()) {
				participant = principalParticipiant;
			} 

		} catch (RepositoryException e) {
			LOG.error("RepositoryException occured in servlet" + e);
		} catch (LoginException e) {
			LOG.error("LoginException occured in servlet" + e);
		}
		return participant;

	}
}
