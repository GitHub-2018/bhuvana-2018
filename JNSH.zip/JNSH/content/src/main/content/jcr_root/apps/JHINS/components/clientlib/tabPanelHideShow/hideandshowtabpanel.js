(function ($, $document) {
    "use strict";
    $document.on("coral-overlay:open", function() {

	if($('input[name="./tabType"]').val() == "normalinnertab")
            {
                //console.log("inside if");
                $('input[name="./innertabtitle"]').parent().find( "label" ).css( "display", "block" );
                $('input[name="./innertabtitle"]').show();

            }
            else
            {
                $('input[name="./innertabtitle"]').parent().find( "label").css( "display", "none");
                $('input[name="./innertabtitle"]').hide();
			}
        $('coral-select[name="./tabType"]').get(0).on('change', function (e){
      		//console.log("inside selected..");
		if($('input[name="./tabType"]').val() == "normalinnertab")
            {
                $('input[name="./innertabtitle"]').parent().find( "label" ).css( "display", "block" );
                $('input[name="./innertabtitle"]').show();

            }
            else
            {
                $('input[name="./innertabtitle"]').parent().find( "label").css( "display", "none");
                $('input[name="./innertabtitle"]').hide();
}});});
})($, $(document));
