/*To Design the agent search Pages*/
$( document ).ready(function() {
    /*json data*/
    var AgentList={"AgentSearch":[
    {
        "AgentListCode"       :"123451"
    }


]}
    var userId="";
    var policynumber="";
    var plcnumber="";
    var userRole="";
    var hostsystem="Salesnet";
    var emailaddress="";
    var userName="";
    if(typeof UserData != undefined && UserData != null){
		userId = UserData.content.uid;
        userRole = UserData.content.role;
        emailaddress = UserData.content.email;
        userName= UserData.content.name;
    }
    //console.log(AgentList.AgentSearch[0].AgentListCode);

    /*json data end*/
    $(".agentsearch").parent().parent().parent().addClass("agentseach-contentblock");
    $(".agentseach-contentblock").parent().addClass("agentseach-container");

    /*Validation function are here*/
    function validateAgentSearch(){
	        var AgentSearchReg = /^[1-9]{1}[0-9]{2,5}$/;
	        var salesIdvalueAgentSearch = $( "#agentcode" ).val();
	        if (AgentSearchReg.test(salesIdvalueAgentSearch)) {
	           $(".validate_input_agent").remove();  
	        }	
	        else{
	        	if($('.validate_input_agent').length < 1){
	        	$("#agantsearchSubmit").after('<div class="validate_input_agent">Please enter a valid Agent Code</div>');
	        	}
				return false;
	        }
	}
    /*Validation function are here*/
   $("#agantsearchSubmit").on("click",function(){
       $(".validate_input__Invalid_agent").remove();
       $(".validate_input__valid_agent").remove();
       $(".validate_input_search").remove();
       $(".validate_input_agent").remove();  

        if($( "#agentcode" ).val() != ""){
       		$(".validate_input_search").remove();
            validateAgentSearch();
            if($('.validate_input_agent').length < 1){
            agentsearchcall(userId,userRole,emailaddress,userName);
            }

        }else{

            if($('.validate_input_search').length < 1){
            $("#agantsearchSubmit").after('<div class="validate_input_search">This field is required</div>');
            }

        }


    });
    /*allow only numeric value in input field*/
    $("#agentcode").on("keypress keyup blur",function (event) {    
           $(this).val($(this).val().replace(/[^\d].+/, ""));
            if ((event.which < 48 || event.which > 57)) {
                event.preventDefault();
            }
        });
});

  function agentsearchcall(userId,userRole,emailaddress,userName){

 		var agentCode = $("#agentcode").val();
        var userId = userId;
    	var policynumber="";
        var plcnumber="";
    	var userRole =userRole;
   	 	var hostsystem="Salesnet";
   	    var emailaddress= emailaddress;
       	var userName=userName;

		$.ajax({

                type: "POST",  
                url: "/bin/sling/agentSearch",
            data: {agentCode: agentCode, userId : userId,policynumber : policynumber,plcnumber :plcnumber,userRole :userRole,hostsystem : hostsystem,emailaddress :emailaddress,userName:userName},
                success : function(data) {
                    //console.log(data);
                    if (data.indexOf('sfjwt') > -1) {
                        var getrequiredurl=data;
                        function post(path, params, method) {
                            method = method || "post"; // Set method to post by default if not specified.
                        
                            // The rest of this code assumes you are not using a library.
                            // It can be made less wordy if you use one.
                            var form = document.createElement("form");
                            form.setAttribute("method", method);
                            form.setAttribute("action", path);
                            form.setAttribute("target", "_blank");
                        
                            for(var key in params) {
                                if(params.hasOwnProperty(key)) {
                                    var hiddenField = document.createElement("input");
                                    hiddenField.setAttribute("type", "hidden");
                                    hiddenField.setAttribute("name", key);
                                    hiddenField.setAttribute("value", params[key]);
                        
                                    form.appendChild(hiddenField);
                                }
                            }
                        
                            document.body.appendChild(form);
                            form.submit();
                        }
                        post(getrequiredurl,post);

                    } else {

                        if($('.validate_input__valid_agent').length < 1){

                        $("#agantsearchSubmit").after('<div class="validate_input__valid_agent">'+data+'</div>');
                        }
                    }

                	//$(".agentSearchWrapper").hide();
            		//$(".agentsearchresult").html(data);

                  },

                error : function() {

                } 
            });

	}