if(window.location.href.indexOf("tab_agent_report_result.html") > -1) {
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
var getrequiredurl = getParameterByName('param');
    console.log(getrequiredurl);
/*post request call we are making here*/
  $.post(getrequiredurl, function (data) {
    window.document.open(getrequiredurl);
    window.document.write(getrequiredurl);
    window.document.close();
});
   /* $.ajax({
    type: "POST",
    url: getrequiredurl,
    crossDomain : true,
    xhrFields: {
        withCredentials: true
    }
});*/
/*post request call we are making end here*/
}