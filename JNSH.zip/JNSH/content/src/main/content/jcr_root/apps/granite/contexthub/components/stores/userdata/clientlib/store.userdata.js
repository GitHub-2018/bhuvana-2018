/*
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */

ContextHub.console.log(ContextHub.Shared.timestamp(), '[loading] contexthub.store.contexthub.userdata - store.userdata.js');
//http://www.mocky.io/v2/5b3f734a3400005600001af2
//   /v2/5b3f1a943000005600abc89f
(function($, window) {
    'use strict';
	var domainval = location.hostname;
	var bermudaFlag = false;
	if(domainval === "sales-tst.johnhancockinsurance.com"){
		domainval = "sales-tst.johnhancockinsurance.com";
        bermudaFlag = true;
    }else if(domainval === "test.manulifebermuda.com"){
		domainval = "pers-tst.manulifebermuda.com";
		bermudaFlag = true;
    }else if(domainval === "stage.manulifebermuda.com"){
		domainval = "pers-stg.manulifebermuda.com";
        bermudaFlag = true;
    }else if(domainval === "www.manulifebermuda.com"){
		domainval = "pers.manulifebermuda.com";
        bermudaFlag = true;
    }else{
		domainval = domainval;
        bermudaFlag = false;
    }
    console.log("contexthub::"+domainval);

    /* default config */
    var defaultConfig = {
        eventDeferring: 16 * 2,
        eventing: ContextHub.eventing,
        service: {
            jsonp: false,
            timeout: 1000,
            host: domainval,     
            path: '/pers/data/account/',
       		secure: 'true',

        },

        initialValues: {
            group: 'Producers',
            role: 'FirmSupport'
        }
    };

	/**
     * UserData store implementation.
     *
     * @constructor
     * @extends ContextHub.Store.PersistedJSONPStore
     * 
     * @param {Object} userdata - store config
     */
    var UserDataStore = function(name, config) {
        /* prepare config */
        this.userdata = $.extend(true, {}, defaultConfig);

        /* initialize store */
        this.init(name,defaultConfig);

        /* query service */
        this.userDataQueryService(false);
    };

	ContextHub.Utils.inheritance.inherit(UserDataStore, ContextHub.Store.PersistedJSONPStore);

/**
     * Performs a query to remote service. Event 'ready' is triggered once query is finished.
     * Callback is executed with result set as a parameter.
     *
     * @this ContextHub.Store.UserDataStore
     * @param {Boolean} reload
     */
    	ContextHub.Store.JSONPStore.prototype.userDataQueryService = function(reload) {
        var url = this.getServiceURL(true);

        /* do nothing if service is not configured properly */
        if (!url) {
            return;
        }

        /* vars */
        var isScript = this.config.service.jsonp || this.config.service.script;
        var wasPaused = this.isEventingPaused();
        var self = this;

        /* force reload */
        if (reload) {
            this.removeItem('_', { silent: true });
        }

        /* check last response time and service url */
        var lastResponseTime = this.getItem(ContextHub.Constants.SERVICE_RESPONSE_TIME_KEY) || 0;
        var lastUrl = this.getItem(ContextHub.Constants.SERVICE_LAST_URL_KEY);

        /* if response lifetime is still valid and url didn't change since last query, return cached response */
        if ((lastResponseTime + this.config.service.ttl > new Date().getTime()) && (lastUrl === url)) {
            this.duration = 'cached';
            this.announceReadiness();
            return;
        }

        this.setItem(ContextHub.Constants.SERVICE_LAST_URL_KEY, url);

        /* set up callback handler */
        window.ContextHub.Callbacks = window.ContextHub.Callbacks || {};
        ContextHub.Callbacks[this.name] = this.callbackFunction.bind(this);

        /* ajax request options */
        var options = {
            url: url,
            timeout: this.config.service.timeout,
            async: this.config.service.synchronous ? false : true,
            method: this.config.service.method || 'GET',

        };
        console.log("before bermuda flag: "+bermudaFlag);
		if(bermudaFlag){
           // alert(bermudaFlag);
        $.extend(options, {
                xhrFields: { 
                withCredentials: true 
                }
         });
    	}
        if (isScript) {
            $.extend(options, {
                dataType: 'script',
                cache: true
            });
        }

        /* pause eventing and reset timer */
        this.pauseEventing();
        this.duration = 0;
        ContextHub.Shared.timers.start(this.name);

        /* perform a query */
        var request = $.ajax(options);

        /* attach success handler if a requested resource is not a script */
        if (!isScript) {
            request.done(function(result, status, xhr) {
                var responseJSON = ContextHub.Utils.JSON.parse(xhr.responseText);
                ContextHub.Callbacks[self.name](responseJSON);
            });
        }

        /* attach failure handler */
        request.fail(function(error) {
            self.failureHandler(error);
        });

        /* complete the request - resume eventing and announce readiness */
        request.always(function() {
            if (!wasPaused) {
                self.resumeEventing();
            }

            self.announceReadiness();
        });
    };

  /**
     * Definition of UserData.
     *
     * @typedef {Object} UserData
     * @property {String} group - group name
       @property {String} role - role name

     */
	/**
     * UserData fetching success handler.
     *
     * @param {Object} response - response
     */

    UserDataStore.prototype.successHandler = function(response) {
        /* pause eventing for this store */
       // console.log("store userdata response::"+response);
        this.pauseEventing();
		var userInfo = response;
        /* user group  */
        var group = userInfo.content['iv-groups'];
        var role = userInfo.content.role;
        /* set displayName */
       // var displayName = group;
        /**
         * @type User Result
         */
        var obj = new Object();
                    obj.group = group;
                    obj.role = role;
                    //obj.displayName = displayName ;

        var result = obj;
        var haveAvatar = !!ContextHub.Utils.JSON.tree.getItem(result, '/photos/primary/image');


        console.log("group:::"+group);
        console.log("role::::"+role);
       // result = ContextHub.Utils.JSON.tree.setItem(result, 'displayName', displayName);
		result = ContextHub.Utils.JSON.tree.setItem(result, 'group', group);
        result = ContextHub.Utils.JSON.tree.setItem(result, 'role', role);
        /* set profile photo */
        if (haveAvatar) {
            result = ContextHub.Utils.JSON.tree.setItem(result, 'avatar', path + '/profile/photos/primary/image');
        }
        console.log("result::"+result);
        /* store result */
        this.setItem('/', result);


        /* resume eventing */
        this.resumeEventing();
    };

 /**
     * Loads a given profile.
     *
     * @param {String} path - profile path
     */
    UserDataStore.prototype.loadProfile = function() {
        var store = ContextHub.getStore('userdata');


        store.queryService(true);
    };

    ContextHub.Utils.storeCandidates.registerStoreCandidate(UserDataStore, 'contexthub.userdata', 0);

}(ContextHubJQ, this));
