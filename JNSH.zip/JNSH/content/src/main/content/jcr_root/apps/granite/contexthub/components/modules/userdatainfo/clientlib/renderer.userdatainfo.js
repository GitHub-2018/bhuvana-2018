/*
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */

ContextHub.console.log(ContextHub.Shared.timestamp(), '[loading] contexthub.module.contexthub.userdatainfo - renderer.userdatainfo.js');

(function() {
    'use strict';


    /**
     * Surfer info module.
     *
     * @constructor
     */
    var UserDatainfoRenderer = function() {

        console.log("pers domain url");
		//$.getJSON(url, function(data) {

    };

    /* inherit from ContextHub.UI.BaseModuleRenderer */
    ContextHub.Utils.inheritance.inherit(UserDatainfoRenderer, ContextHub.UI.BaseModuleRenderer);

    /* default config */
    UserDatainfoRenderer.prototype.defaultConfig = {
        icon: 'coral-Icon--personalizationField',
		 title: 'User Data Profile',
            clickable: true,
            editable: {
            key: '/user_data'
            },

        	storeMapping: {
            userdata : 'user_data'
        },

        template:
        '<p>Group: {{userdata.group}}  <br> Role: {{userdata.role}}</p>'


    };
// Profile render code start

    UserDatainfoRenderer.prototype.render = function(module) {
        var config = $.extend(true, {}, this.defaultConfig, module.config);
     /*   if (config.storeMapping && config.storeMapping.userdata) {
            var store = ContextHub.getStore(config.storeMapping.userdata);
            if (store) {
                config.image = GraniteHelpers.HTTP.externalize(store.getItem('avatar'));


                if ((config.image || '').indexOf('avatar.png') !== -1) {
                    delete config.image;
                }
            } else {
                delete config.image;
            }
        } else {
            delete config.image;
        } */

        module.config = config;
        console.log("module :::"+module);
        return this.uber('render', module);
    };


// Profile popover code start
     UserDatainfoRenderer.prototype.getPopoverContent = function(module, popoverVariant) {
        var config = $.extend(true, {}, this.defaultConfig, module.config);

        /* presentation mode */
        if (!popoverVariant || popoverVariant === 'default') {
            var list = this.users;

            if (list && config.skipUsers) {
                list = $.grep(list, function(user, i) {
                    return config.skipUsers.indexOf(user.data.principal) === -1;
                });
            }

            if (list && config.storeMapping && config.storeMapping.userdata) {
                var store = ContextHub.getStore(config.storeMapping.userdata);

                if (store) {
                    var path = store.getItem('path');

                    if (path) {
                        $.each(list, function(i, user) {
                            user.selected = path.indexOf(user.data.path) === 0;
                        });
                    }
                }
            }

            config.listType = 'checkmark';
            config.list = list;
        }

        /* edition mode */
        if (popoverVariant === 'module-editing') {
            list = this.prepareGenericList(config.editable.key, config);

            config.listType = 'input';
            config.list = list;
        }

        module.config = config;

        return this.uber('getPopoverContent', module);
    };
    // Profile popover code end
    UserDatainfoRenderer.prototype.onListItemClicked = function(module, position, data, event) {
        if (data) {
            var config = $.extend(true, {}, this.defaultConfig, module);
            if (config.storeMapping && config.storeMapping.userdata) {
                var store = ContextHub.getStore(config.storeMapping.userdata);
                if (store) {
                    var isClientContextStore = typeof store.config.mappingConfig !== 'undefined';
            console.log("principal:"+data.principal+"path::"+data.path);
                    var userdata = isClientContextStore ? data.principal : data.path;

                    store.loadProfile(userdata);
                }
            }
        }
    };


    /* register module */
    ContextHub.UI.ModuleRenderer('contexthub.userdata', new UserDatainfoRenderer());

}(ContextHubJQ));
