var AsOFdateTemp;

function dailyunitvalues(productcode,companycode,resultType,date,footnote){ 
    var productCode =productcode;
    var companyCode	=companycode;
    var functionality ="byProduct";
    var resultType= resultType;
    var dateVal = date;
    var formData;
    if(null !== productCode && null !== companyCode){
        formData={productCode:productCode,companyCode:companyCode,functionality:functionality,resultType:resultType,date:dateVal,footNote:footnote};
    }   
    callAjax(formData);
    return AsOFdateTemp;
} 

function callAjax(formData){
        $.ajax({  
            type: "POST",  
            url: "/bin/sling/fundperformance",  
            async : false,
            data: formData,
            dataType: 'json',
            cache: false,
            success: function(resp){

                var i;
                var details = resp.FundArray;
                if(typeof details != "undefined"){
                    var tr;
                    var getdate=resp.Details.AsOfDate;
                    var convertdate=getdate.split("-");
                    var str1=convertdate[2];
                    var str2=convertdate[1];
                    var str3=convertdate[0];
                    AsOFdateTemp = str2 +"/"+ str1 +"/"+ str3;;
                    $(".DailyUnit_date").html("Unit Values (in $) as of "+resp.date);
                    $("#dailyunitvalueresultable").children("tbody").empty();
                    var prevRiskVal = null;
                    var currRiskVal = null;
                    var risk=null;
                    for (i = 0; i < details.length; i++) {
                        tr = $('<tr/>');
                         var footNoteVal="";
                        currRiskVal =  resp.FundArray[i].risk;
                        if(currRiskVal!==prevRiskVal){
                            prevRiskVal = currRiskVal;
                            risk=resp.FundArray[i].risk;
                            var riskvalue=risk.toUpperCase();
                            var colorcode=resp.FundArray[i].riskColorCode;
                            $('#dailyunitvalueresultable').append('<tr class="colorband">'+
                                                                 '<td  class="riskHearder" colspan="5" style="background-color:' +colorcode+'">'+ riskvalue +'</td>'); 


                        }else{
                            console.log();
                        }                 

                        if(typeof resp.FundArray[i].morningStarPath !== "undefined" && resp.FundArray[i].morningStarPath !== ""){
                            if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }

                    tr.append("<td scope='row' width='40%'>"+"<a href='"+resp.FundArray[i].morningStarPath+"'target='_blank'>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup></td>");							
                       }
                       else
                       {
						if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }
                           tr.append("<td scope='row' width='40%'>"+"<a href=''>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup></td>");
                       }
                        tr.append("<td>" +resp.FundArray[i].UnitValue + "</td>");
                        tr.append("<td class='netchangetd'>" + resp.FundArray[i].NetChange + "</td>");
                        tr.append("<td  style='font-size:18px;color:"+resp.FundArray[i].color+"'>"+"<span class='glyphicon'>"+resp.FundArray[i].netChange+"</span></td>");
                        tr.append("<td class='managertd'>" + resp.FundArray[i].fundManager + "</td>");



                        if($("#dailyUnitValues").is(':hidden')){
                            $('#dailyunitvalueresultable').append(tr);
                        } 
						 /**************Footnes to be shown in the table****************************/
                       if(typeof resp.FundArray[i].footnotes !== "undefined" && resp.FundArray[i].footnotes !== ""){
                           $('#dailyunitvalueresultable').append('<tr class="intable-footnotes" >'+
                                                       '<td style="background-color:#fff" colspan="11">'+ resp.FundArray[i].footnotes +'</td>'); 
                        								console.log(resp.FundArray[i].footnotes);

                        }
                       $('#dailyunitvalueresultable').children("tbody").children("tr.intable-footnotes").prev("tr").children("td").css("border-bottom","none");
                       /**************Footnes to be shown in the table****************************/
                    }

                     /**************Footnes to be shown below the table****************************/
                   			 var getFootNotes=resp.FootNotesArray;
                             $(".foot-notes").remove();
                             $(".foot-notes-para").remove();

						 if(typeof(getFootNotes) !== "undefined" && getFootNotes !== null){
                            
                             $.each( getFootNotes, function( key, value ) {                                 
                                   $.each( value, function( key, value ) {

                                      $("#dailyUnitValues").append("<div class='foot-notes'>"+
                                                                            "<b>"+
                                                                            +key+
                                                                            "</b>"+
                                                                            "</div>");
                                      //var footnotespara='footnotes"+key+"';
                                      $("#dailyUnitValues").append("<div class='foot-notes-para'>"+value+"</div>");
        
                                       console.log("inside"+key);
                                       console.log(value);


        
        
                                   });

        
        
                            });
                         }

                    /**************Footnes to be shown below the table****************************/

                    $("#fundByproduct").hide();                   
                    $("#dailyUnitValues").show();
                    $("#epvul").show(); 
                }else{

                }
            },

            error: function(e){
                console.log("error");       
            }
        });
    } 
