(function ($, $document) {
    "use strict";
    $(document).on("coral-overlay:open", function() {
	//console.log("inside dialog ready");
        //console.log("val@@"+$('coral-select[name="./contentstreamtype"]').val());
		if($('input[name="./contentstreamtype"]').val() == "firm")
        {
                //console.log("inside if");
                $('coral-select[name="./firm"]').parent().find( "label" ).css( "display", "block" );
                $('coral-select[name="./firm"]').show();

                $('coral-select[name="./identitySource"]').parent().find( "label").css( "display", "none");
                $('coral-select[name="./identitySource"]').hide();

                $('input[name="./default"]').parent().find( "label").css( "display", "none");
                $('input[name="./default"]').hide();

         }
        else if($('input[name="./contentstreamtype"]').val() == "identitySource")
        {

            	$('coral-select[name="./firm"]').parent().find( "label" ).css( "display", "none" );
                $('coral-select[name="./firm"]').hide();

                $('coral-select[name="./identitySource"]').parent().find( "label").css( "display", "block");
                $('coral-select[name="./identitySource"]').show();

                $('input[name="./default"]').parent().find( "label").css( "display", "none");
                $('input[name="./default"]').hide();
        }
        else
        {
            //console.log("else");
               $('coral-select[name="./firm"]').parent().find( "label" ).css( "display", "none" );
               $('coral-select[name="./firm"]').hide();

               $('coral-select[name="./identitySource"]').parent().find( "label").css( "display", "none");
               $('coral-select[name="./identitySource"]').hide();

               $('input[name="./default"]').parent().find( "label").css( "display", "block");
               $('input[name="./default"]').show();
		}

        $('coral-select[name="./contentstreamtype"]').get(0).on('change', function (e){

      		//console.log("inside selected..");
            if($('input[name="./contentstreamtype"]').val() == "firm")
        {
                //console.log("inside if");
                $('coral-select[name="./firm"]').parent().find( "label" ).css( "display", "block" );
                $('coral-select[name="./firm"]').show();

                $('coral-select[name="./identitySource"]').parent().find( "label").css( "display", "none");
                $('coral-select[name="./identitySource"]').hide();

                $('input[name="./default"]').parent().find( "label").css( "display", "none");
                $('input[name="./default"]').hide();

         }
        else if($('input[name="./contentstreamtype"]').val() == "identitySource")
        {

            	$('coral-select[name="./firm"]').parent().find( "label" ).css( "display", "none" );
                $('coral-select[name="./firm"]').hide();

                $('coral-select[name="./identitySource"]').parent().find( "label").css( "display", "block");
                $('coral-select[name="./identitySource"]').show();

                $('input[name="./default"]').parent().find( "label").css( "display", "none");
                $('input[name="./default"]').hide();
        }
        else
        {
               $('coral-select[name="./firm"]').parent().find( "label" ).css( "display", "none" );
               $('coral-select[name="./firm"]').hide();

               $('coral-select[name="./identitySource"]').parent().find( "label").css( "display", "none");
               $('coral-select[name="./identitySource"]').hide();

               $('input[name="./default"]').parent().find( "label").css( "display", "block");
               $('input[name="./default"]').show();
		}

	});});
})($, $(document));
