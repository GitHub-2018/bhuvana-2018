$(function(){
eserviceproductType=[];
$(".eserviceform ").parent().parent().parent().addClass("e-services-wrapper");
$(".e-services-wrapper").find(".customRichtexteditor ").children("div").addClass("para-wrapper");
$('.eservices-thankyou').hide();

/*E-services validation start here for the e-services form*/
function validateFirstName(){	
			var eserviceLname = $("#eserviceLname").val();
			if(eserviceLname.length > 0){
				 $(".validate_input_lastname").remove();
                $("#eserviceLname").removeClass("Error-border");
			}
			else{
	        	if($('.validate_input_lastname').length < 1){
	        			$("#eserviceLname").after('<div class="validate_input_lastname validate-eservice">This is a required field</div>');
                        $("#eserviceLname").addClass("Error-border");
	        		}
	        		
				return false;
	        }

	       
}
function validateLastName(){
			var eserviceFname = $("#eserviceFname").val();
			if(eserviceFname.length > 0){
				 $(".validate_input_firstname").remove();
                $("#eserviceFname").removeClass("Error-border");
			}
			else{
	        		if($('.validate_input_firstname').length < 1){
	        			$("#eserviceFname").after('<div class="validate_input_firstname validate-eservice">This is a required field</div>');
                         $("#eserviceFname").addClass("Error-border");
	        		}
	        		
				return false;
	        }

	       
}
function validateFirmAgent(){
			if ($('input.checkbox_check').is(':checked')) {
				$(".validate_input_checkbox").remove();
			}
			else{
	        		if($('.validate_input_checkbox').length < 1){
	        			$(".checkbox-contain").children(".product-indiviual").children("p").after('<div class="validate_input_checkbox  validate-eservice">Please select at least one product from the lists below.</div>');
	        		}
	        		
				return false;
	        }

}
function validateEmailaddress(){
			var email = /^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i;
	        var eserviceEmail = $( "#eserviceEmail" ).val();
	        if (email.test(eserviceEmail)) {
	            $(".validate_input_email").remove();
                $("#eserviceEmail").removeClass("Error-border");
	        }	
	        else{
	        	if($('.validate_input_email').length < 1){
	        	$("#eserviceEmail").after('<div class="validate_input_email validate-eservice">This is a required field</div>');
                $("#eserviceEmail").addClass("Error-border");
	        	}
				return false;
	        }
}
$(".checkbox_check").change(function(){ 
		 $(".validate_input_checkbox").remove();
        eserviceproductType=[];
        eserviceproductobj={};
		$(".checkbox_check:checked" ).each(function() {	            
            eserviceproductobj={
                "productCode":$(this).val(),
                "productDisplayName":$(this).parent().text().trim()
            };
			    eserviceproductType.push(eserviceproductobj);

		});

	});
$( "#eserviceEmail" ).focus(function() {
	$(this).removeClass("Error-border");
    $(".validate_input_email").remove();
});
$( "#eserviceFname" ).focus(function() {
	$(this).removeClass("Error-border");
    $(".validate_input_firstname").remove();
});
$( "#eserviceLname" ).focus(function() {
	$(this).removeClass("Error-border");
    $(".validate_input_lastname").remove();
});
$(document).on( "click", "#eservicesSubmit", function() {
	validateFirstName();
	validateEmailaddress();
	validateLastName();
	validateFirmAgent();
	if($('.validate-eservice').length < 1){
        var firstName=$("#eserviceFname").val();
        var lastName=$("#eserviceLname").val();
        var email=$("#eserviceEmail").val();
		var requestedProducts = eserviceproductType;
        var obj = new Object();
			obj.lastName =lastName;
            obj.firstName = firstName;
    		obj.emailID = email;
            obj.requestedProducts=requestedProducts;
           var formData=JSON.stringify(obj);
        //console.log(formData);
        $.ajax({  
            type: "POST",  
            url: "/bin/sling/eservice",
            data:{formData: formData},
            success : function(resp) {
             $(".form-eservices").hide();
             $(".e-services-wrapper").children(".section").hide();
             $('.eservices-thankyou').show();
             $(".welcomeMsg").hide();
             },
             error:function(e){
    
             },
        }); 
		
	}

});
});

