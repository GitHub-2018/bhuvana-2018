package com.jhmn.jhmn.core.search;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.jackrabbit.commons.query.GQL;
import org.apache.sling.api.SlingHttpServletRequest;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.SimpleSearch;
import com.day.cq.search.facets.Bucket;
import com.day.cq.search.facets.Facet;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.ResultPage;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhmn.jhmn.core.bean.AssetMetaDataBean;
import com.jhmn.jhmn.core.bean.SearchParameter;
import com.jhmn.jhmn.core.bean.SearchResultTO;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.helper.JHMNAssetHelper;
import com.jhmn.jhmn.core.helper.JHMNSearchHelper;
import com.jhmn.jhmn.core.interfaces.JHMNFormatType;


public class DocumentSearchService {

	private static final Logger LOG = LoggerFactory.getLogger(DocumentSearchService.class);
	private static final String CHARSET_PARAM_NAME = "_charset_";
	private static final String QUERY_PARAM_NAME = "q";
	private static final String START_PARAM_NAME = "start";
	private static final String ORDER_PARAM_NAME = "sort";
	private static final String LIMIT_PARAM_NAME = "size";
	private String size = "10";
	private String resultsOrder = "desc";
	private int queryCount;
	private int groupValue;
	private long page = 1;
	private long offset;
	private String query;
	private Map<String, Map<String, SearchParameter>> formatAndTypes = new HashMap<String, Map<String, SearchParameter>>();
	private Map<String, String> tagList = new HashMap<String, String>();
	private SimpleSearch search;

	public DocumentSearchService(SlingHttpServletRequest request) {
		LOG.info("iniside DocumentSearchServiceDAO");
		this.search = request.getResource().adaptTo(SimpleSearch.class);
		this.queryCount = 0;
		this.groupValue = 0;
		String charset = "ISO-8859-1";
		if (request.getParameter(CHARSET_PARAM_NAME) != null) {
			charset = request.getParameter(CHARSET_PARAM_NAME);
		}
		if (request.getParameter(JHMNConstants.PAGE_PARAM_NAME) != null) {
			this.page = Long.parseLong(request.getParameter(JHMNConstants.PAGE_PARAM_NAME));
		}
		if (request.getParameter(QUERY_PARAM_NAME) != null) {
			try {
				setQuery((new String(request.getParameter(QUERY_PARAM_NAME).getBytes(charset), "UTF-8")) , request);
			} catch (UnsupportedEncodingException e) {
				LOG.error("UnsupportedEncoding Exception ", e);
			}
		}
		if (request.getParameter(START_PARAM_NAME) != null) {
			try {
				this.search.setStart(Long.parseLong(request.getParameter(START_PARAM_NAME)));
			} catch (NumberFormatException e) {
				// ignore
			}
		}
		
		if (request.getParameter(LIMIT_PARAM_NAME) != null) {
			size = request.getParameter(LIMIT_PARAM_NAME);
		}
		if (request.getParameter(ORDER_PARAM_NAME) != null) {
			resultsOrder = request.getParameter(ORDER_PARAM_NAME);
		}

		this.tagList = JHMNSearchHelper.setTagList(request, tagList);


	}
	/**
	 * @param result
	 * @return the page, which contains the information about the Previous page.
	 *         Returns <code>null</code> if there is no Previous page (i.e. the
	 *         current page is the last page).
	 * @throws RepositoryException
	 *             if an error occurs while reading from the query result.
	 */

	public boolean getPreviousPage(SearchResult result) throws RepositoryException {
		ResultPage previous = result.getPreviousPage();
		if (previous != null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param result
	 * @return the page, which contains the information about the next page.
	 *         Returns <code>null</code> if there is no next page (i.e. the
	 *         current page is the last page).
	 * @throws RepositoryException
	 *             if an error occurs while reading from the query result.
	 */
	public boolean getNextPage(SearchResult result) throws RepositoryException {
		ResultPage next = result.getNextPage();

		if (next != null) {
			next.getStart();
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Sets a new fulltext query that will be executed.
	 *
	 * @param query
	 *            the fulltext query.
	 */
	public void setQuery(String query, SlingHttpServletRequest request) {
		this.query = query;

		// use GQL to filter out wildcards
		try {
			final StringBuilder sb = new StringBuilder();
			GQL.parse(query, request.getResourceResolver().adaptTo(Session.class), new GQL.ParserCallback() {
				public void term(String property, String value, boolean optional) throws RepositoryException {
					sb.append(" ");
					if (optional) {
						sb.append("OR ");
					}
					if (property.length() > 0) {
						sb.append(property).append(":");
					}
					sb.append(value);

				}
			});
			search.setQuery(sb.toString().trim());
		} catch (RepositoryException e) {
			search.setQuery("");
		}
	}

	public String getQuery() {
		return query;
	}

	/**
	 * Get the Asset List for the Document search
	 *
	 * @return assetBeans containing the list of the assets 
	 * 
	 */
	public SearchResultTO getResult(SlingHttpServletRequest request) {
		ArrayList<AssetMetaDataBean> assetBeans = new ArrayList<AssetMetaDataBean>();
		AssetMetaDataBean assetBean = null;
		QueryBuilder queryBuilder = request.getResourceResolver().adaptTo(QueryBuilder.class);
		SearchResultTO searchResultTO = new SearchResultTO();
		long current;
		this.offset = Long.parseLong(size) * (page - 1);

		Map<String, String> map = new HashMap<String, String>();
		map.put("path", "/content");
			map.put("1_group.1_property.value", "MNBD:topic/%");
			map.put("1_group.1_property", "jcr:content/metadata/cq:tags");
			map.put("1_group.1_property.operation", "like");
			if (resultsOrder != null) {
				map.put("orderby", JHMNConstants.ORDER_BY_MODIFIED);
				map.put("orderby.sort", resultsOrder);
			
			}
		
		map.put("1_group.2_property.value", "*");
		map.put("1_group.2_property", "jcr:content/metadata/dc:format");
		map.put("p.offset", Long.toString(offset));
		map.put("1_group.p.or", "true");
		map.put("2_fulltext", search.getQuery());
		map.put("type", "dam:Asset");
		
		if (tagList != null && !tagList.isEmpty()) {
			queryCount = 2;
			getSearchCriteriaMap(map, tagList);
		}
		if (size != null && (!"".equals(size))) {
			map.put("p.limit", size);
		}else{
			size = "10";
		}
		
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), request.getResourceResolver().adaptTo(Session.class));
		LOG.info("query generated is "+map);
		SearchResult searchRes = query.getResult();
		setFormatAndResourceType(searchRes, request);

		double totalResults = searchRes.getTotalMatches();
		long  numberOfPages = (long) (totalResults / Integer.parseInt(size));
		
		if(totalResults % Integer.parseInt(size) > 0){
			numberOfPages += 1 ;
		}
		current = (offset / Long.parseLong(size)) + 1;

		long end = current + 2;
		if (end > numberOfPages) {
			end = (long) numberOfPages;
		}
		long endResult = offset + Integer.parseInt(size);
		if (endResult > totalResults) {
			endResult = (long) totalResults;
		}
		searchResultTO.setEndResult(endResult);
		searchResultTO.setStartResult(offset + 1);
		searchResultTO.setCount(totalResults);
		searchResultTO.setNumberOfPages(numberOfPages);
		searchResultTO.setCurrentIndex(current);

		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				try {
					String queryPath = hit.getPath();
					assetBean = JHMNAssetHelper.retrieveAssetBean(queryPath, request.getResourceResolver());
					assetBeans.add(assetBean);
				} catch (PathNotFoundException e) {
					LOG.error("Path not found for the Hit in Site Search ", e);
				} catch (RepositoryException e) {
					LOG.error("Repository Exception in Site Search ", e);
				}
			}
		}
		searchResultTO = JHMNSearchHelper.getPagination(searchResultTO, numberOfPages, page, request);
		
		searchResultTO.setAssetBeans(assetBeans);
		return searchResultTO;

	}

	private void getSearchCriteriaMap(Map<String, String> map, Map<String, String> tagList) {
		for (Map.Entry<String, String> entry : tagList.entrySet()) {
			String tagName = entry.getKey();
			String tagValue = entry.getValue();
			String[] tagValueArray = tagValue.split(",");
			 
			if ("format".equalsIgnoreCase(tagName)) {
				if(tagValueArray.length>0){
					addFormatsToQuery(map,tagValueArray);
				}
				else{
				queryCount++;
				map.put(queryCount + "_property.value", tagValue);
				map.put(queryCount + "_property", "@jcr:content/metadata/dc:format");
				}
			} 
			else if("topic".equalsIgnoreCase(tagName)){
				if(tagValueArray.length>0){
					addTopicsToQuery(map,tagValueArray);
				}
				else{
				queryCount++;
				map.put(queryCount + "_property.value", tagValue+"%");
				map.put(queryCount + "_property", "jcr:content/metadata/cq:tags");
				map.put(queryCount + "_property.operation", "like");
				}
			}
			else if (tagValueArray.length > 0) {
				addTagsToQuery(map, tagValueArray);
			} else {
				addTagsToQuery(map, tagValue);
			}
		}

	}

	private Map<String, String> addFormatsToQuery(Map<String, String> map, String[] tagValueArray) {
		groupValue = 0;
		queryCount++;
		for (String format : tagValueArray) {
			map.put(queryCount + "_group." + ++groupValue + "_property.value", format);
			map.put(queryCount + "_group." + groupValue + "_property", "jcr:content/metadata/dc:format");
		}
		map.put(queryCount + "_group.p.or", "true");
		return map;
	}
	
	
	private void addTagsToQuery(Map<String, String> map, String tagValue) {
		groupValue = 0;
		queryCount++;
		map.put(queryCount + "_property.value", tagValue);
		map.put(queryCount + "_property", "jcr:content/metadata/cq:tags");
	}

	private void addTagsToQuery(Map<String, String> map, String[] tagValueArray) {
		groupValue = 0;
		queryCount++;
		for (String tag : tagValueArray) {
			map.put(queryCount + "_group." + ++groupValue + "_property.value", tag);
			map.put(queryCount + "_group." + groupValue + "_property", "jcr:content/metadata/cq:tags");
		}
		map.put(queryCount + "_group.p.or", "true");
	}
	
	private Map<String, String> addTopicsToQuery(Map<String, String> map, String[] tagValueArray) {
		groupValue = 0;
		queryCount++;
		for (String tag : tagValueArray) {
			map.put(queryCount + "_group." + ++groupValue + "_property.value", tag+"%");
			map.put(queryCount + "_group." + groupValue + "_property", "jcr:content/metadata/cq:tags");
			map.put(queryCount + "_group." + groupValue + "_property.operation", "like");
		}
		map.put(queryCount + "_group.p.or", "true");
		return map;
	}

	public void setFormatAndResourceType(SearchResult searchRes, SlingHttpServletRequest request) {
		try {
			BundleContext bundleContext = FrameworkUtil.getBundle(JHMNFormatType.class).getBundleContext();
			ServiceReference serviceReference = (ServiceReference)bundleContext.getServiceReference(JHMNFormatType.class.getName());
			JHMNFormatType formatType = (JHMNFormatType)bundleContext.getService(serviceReference);
			Map<String, String> formatTypeMap = formatType.getConfigProperty(JHMNConstants.FORMAT_TYPE);
			
			Map<String, Facet> facetsmap = searchRes.getFacets();

			Map<String, SearchParameter> mapFormat = new HashMap<String, SearchParameter>();
			Map<String, SearchParameter> mapResourceType = new HashMap<String, SearchParameter>();
			for (Map.Entry<String, Facet> entry : facetsmap.entrySet()) {
					
				String key = entry.getKey();
				Facet facet = facetsmap.get(key);
				LOG.info("doc Search facet Key::::::::::::::::::::::"+key);
				LOG.info("doc Search facet oject::::::::::::::::::::::"+facetsmap.get(key));

				if (facet.getContainsHit()) {
					TagManager tagManager = request.getResourceResolver().adaptTo(TagManager.class);
					for (Bucket bucket : facet.getBuckets()) {
						String value = bucket.getValue();
						double count = bucket.getCount();
						LOG.info("Doc Search Value :::::"+value);
						LOG.info("Doc Search count :::::"+count);
						Tag tag = tagManager.resolve(value);
						if (key.equalsIgnoreCase("1_group.2_property")) {
								SearchParameter searchParameter = new SearchParameter();
								// get the lable name corresponding to the dc:format ie. get PDF from application/PDF
								if(formatTypeMap.containsKey(value)){
									LOG.info("key from formattype"+value);
									String labelName = formatTypeMap.get(value);
									LOG.info("labelName from formattype"+value);
									searchParameter.setCategoryCount(count);
									searchParameter.setCategoryValue(value);
									searchParameter.setCategoryKey(labelName);
									if(mapFormat.containsKey(labelName)){
										LOG.info("map having label entry: "+labelName);
										SearchParameter srchParameter = mapFormat.get(labelName);
										srchParameter.setCategoryCount(srchParameter.getCategoryCount()+count);
										srchParameter.setCategoryValue(srchParameter.getCategoryValue()+","+value);
										mapFormat.put(srchParameter.getCategoryKey(), srchParameter);
									
									}else{
										mapFormat.put(searchParameter.getCategoryKey(), searchParameter);
									}
								}
								
							} else if (value.startsWith("MNBD:type") && (key.equalsIgnoreCase("1_group.1_property")||key.equalsIgnoreCase("1_group.2_property") )) {
							SearchParameter searchParameter = new SearchParameter();
							searchParameter.setCategoryKey(tag.getTitle());
							searchParameter.setCategoryCount(count);
							searchParameter.setCategoryValue(value);
							if(mapResourceType.get(value)!=null){
								SearchParameter srchParameter = mapResourceType.get(value);
								srchParameter.setCategoryCount(srchParameter.getCategoryCount()+count);
								mapResourceType.put(value, srchParameter);
							}else{
								mapResourceType.put(value, searchParameter);
							}
						}
						//}
					}
				}
			}

			/** remaining formats and resourceType count will be set to zero */
			// setFormatMapZero(mapFormat);
			//setResourceTypeMapZero(mapResourceType);
			/****/

			this.formatAndTypes.put("format", mapFormat);
			this.formatAndTypes.put("type", mapResourceType);

		} catch (RepositoryException e) {
			LOG.error("Repository Exception ", e);
		}

	}

	public Map<String, Map<String, SearchParameter>> getFormatAndResourceType() {
		return formatAndTypes;
	}
}
