package com.jhmn.jhmn.core.constants;
public class JHMNConstants {


	public static final String BASE_PAGE_TEMPLATE="/apps/jhmn/components/page/jhmnbasepage";
	public static final String CQ_TEMPLATE_LABEL="cq:template";
	public static final String CQ_TAGS_METADATA_PROPERTYNAME = "@jcr:content/metadata/cq:tags";
	public static final String ASSET_TITLE = "dc:title";
	public static final String EMPTY_STRING = "";
	public static final String CQ_TAGS="cq:tags";
	public static final String PARAM_PRIORITY= "Priority";
	public static final String PRIORITY_LOW = "low";
	public static final String PARAM_TYPE = "type";
	public static final String PARAM_FORMAT = "format";
	public static final String PARAM_TOPIC = "topic";	
	public static final String PARAM_CHANNEL = "channel";
	public static final String IMAGE_RENDITION_30_42 = "cq5dam.thumbnail.30.42.png";
	public static final String ASSET_FORMAT="dc:format";
	public static final String ASSET_LAST_MODIFIED="jcr:lastModified";
	public static final String CUSTOM_DATE_FORMAT="MMMM dd,YYYY";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
	public static final String PAGE_LAST_REPLICATED="cq:lastReplicated";
	public static final String PAGE_LAST_MODIFIED="cq:lastModified";

	public static final String PDF_FORMAT = "application/pdf";
	public static final String PPT_FORMAT = "application/vnd.ms-powerpoint";
	public static final String DOC_FORMAT = "application/msword";
	public static final String EXCEL_FORMAT = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static final String AUDIO_FORMAT = "audio/mpeg";
	public static final String VIDEO_FORMAT = "video/x-ms-wmv";
	public static final String TOOL_FORMAT = "application/x-msdownload";
	public static final String IMAGE_FORMAT = "image/jpeg";
	public static final String PPT1_FORMAT = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
	public static final String TOOL1_FORMAT = "application/zip";
	public static final String EXCEL1_FORMAT = "application/vnd.ms-excel";
	public static final String DOC1_FORMAT = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

	public static final String TAG_FORMAT_DOC = "DOC";
	public static final String TAG_FORMAT_PDF = "PDF";
	public static final String TAG_FORMAT_PPT = "PPT";
	public static final String TAG_FORMAT_TOOL = "Tool";
	public static final String TAG_FORMAT_HTML = "HTML";
	public static final String TAG_FORMAT_AUDIO = "Audio";
	public static final String TAG_FORMAT_VIDEO = "Video";
	public static final String TAG_FORMAT_EXCEL = "XLS";
	public static final String TAG_FORMAT_IMAGE = "Image";
	public static final String TAG_COLOR_RED = "red";
	public static final String TAG_COLOR_GREEN= "green";
	public static final String TAG_COLOR_BLUE = "blue";

	public static final String DAM_ASSET="dam:Asset";
	public static final String TYPE_PROP_NAME="@jcr:content/metadata/cq:tags";
	public static final String ORDER_BY_MODIFIED="@jcr:content/jcr:lastModified";
	public static final String ORDER_SORT="desc";
	public static final String JCR_CONTENT ="jcr:content";
	public static final String ASSET_LAST_REPLICATED="cq:lastReplicated";
	public static final String DATE_FORMAT="MMMM dd, yyyy";
	public static final String CQ_TAGS_PROPERTYNAME = "@jcr:content/cq:tags";
	public static final String JCR_CREATED="jcr:created";
	public static final String ASSET_DESC="dc:description";
	public static final String JCR_TITLE="jcr:title";
	public static final String PAGE_PARAM_NAME = "page";
	public static final String FORMAT_TYPE = "formatType";
	public static final String FORMATCONFIG_PID = "com.jhmn.jhmn.core.impl.JHMNFormatTypeImpl";
	public static final String UNCHECKED="unchecked";

    public static final String SLING_REQUEST="slingRequest";
	public static final String NEWS_TYPE="news";
	public static final String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String BERMUDA_MAINTENANCE = "Bermuda";
	public static final String MAINTENANCE_NODE ="maintenance";
	public static final String PAR_NODE="par";
	public static final String MAINTENANCE_MESSAGE="Site in an Active State";
	public static final String TIMINGS_NODE="timings";
	public static final String START_TIME="starttime";
	public static final String END_TIME="endtime";
	public static final String DOMAIN="domain";
	public static final String MAINTENANCE_STATUS="maintenanceStatus";
	public static final String MESSAGE="message";
	public static final String CONFIG_PID="com.jhmn.jhmn.core.impl.JHMNConfigServiceImpl";
    
}
