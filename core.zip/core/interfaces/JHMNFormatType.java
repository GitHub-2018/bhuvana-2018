package com.jhmn.jhmn.core.interfaces;

import java.util.Map;

public interface JHMNFormatType {
	
	public Map<String, String> getConfigProperty(final String property);

}
