package com.jhmn.jhmn.core.interfaces;

public interface JHMNConfigService {
	public String getConfigProperty(final String property);


}