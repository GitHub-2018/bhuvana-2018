package com.jhmn.jhmn.core.interfaces;
import java.text.ParseException;
import java.util.Map;

import javax.jcr.RepositoryException;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

public interface JHMNBusinessService {
	
		public JSONObject getJSONResponse(Map<String ,Object> mapObj) throws RepositoryException,JSONException,ParseException;
}
