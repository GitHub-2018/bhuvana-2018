package com.jhmn.jhmn.core.bean;

import java.util.List;

public class NavBean {

	private String pageTitle;
	private String pagePath;
	private List<NavBean> childPages; 
	private int level;
	private boolean basePage=false;
		
	/**
	 * @return the pageTitle
	 */
	public String getPageTitle() {
		return pageTitle;
	}
	
	/**
	 * @param path the pageTitle to set
	 */
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}	
	
	/**
	 * @return the pagePath
	 */
	
	public String getPagePath() {
		return pagePath;
	}
	/**
	 * @param path the pagePath to set
	 */
	public void setPagePath(String pagePath) {
		this.pagePath = pagePath;
	}
	
	/**
	 * @return the childPages
	 */
	public List<NavBean> getChildPages() {
		return childPages;
	}
	/**
	 * @param path the childPages to set
	 */
	public void setChildPages(List<NavBean> childPages) {
		this.childPages = childPages;
	}
	
	
	/**
	 * @return the level for the page
	 */
	public int getLevel() {
		return level;
	}
	
	/**
	 * @param level the levels  to set
	 */
	
	public void setLevel(int level) {
		this.level = level;
	}
	public boolean isBasePage() {
		return basePage;
	}

	public void setBasePage(boolean basePage) {
		this.basePage = basePage;
	}

}

