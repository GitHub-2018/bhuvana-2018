package com.jhmn.jhmn.core.servlets;

import java.io.IOException;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;

import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.collections.iterators.TransformIterator;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.granite.ui.components.Config;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import org.apache.commons.collections.Transformer;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "MNBD Users List Servlet"),
		@Property(name = "sling.servlet.paths", value = { "/bin/sling/MNBDUsersListDatasource" }),
		@Property(name = "service.vendor", value = "MNBD"),
		@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)})
public class JHMNUserListDatasource extends SlingAllMethodsServlet{
	
	private static final Logger LOG = LoggerFactory
			.getLogger(JHMNUserListDatasource.class);

	private static final long serialVersionUID = 1L;

	@Reference
    private ConfigurationAdmin configAdmin;
	
	private static Dictionary<String, String> properties;
	
	private static final String GROUP_PID = "com.jhmn.jhmn.core.servlets.JHMNUserListServlet";
	private static final String CONTENTOWNERS = "contentowners";
	
	protected final void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException, IOException {
			
			LOG.info("inside JHMNUserListServlet ");
		    	
                Configuration config = configAdmin.getConfiguration(GROUP_PID);
                synchronized (config) {
                properties = config.getProperties();
            }
            Config dsCfg = new Config(request.getResource().getChild("datasource"));
            List<KeyValue> list = new ArrayList<KeyValue>();
            if (dsCfg.get("addNone", false)) {
        	   list.add(new KeyValue("", ""));
        	}
			
			java.util.Iterator<Authorizable> users = null, groups ;
			Object obj = null; 
			User user = null;
			String id = null;
			String path= null;
            
            String[] groupNames = PropertiesUtil.toStringArray(properties.get(CONTENTOWNERS));
            LOG.debug("groups length "+groupNames.length);
			final ResourceResolver resourceResolver = request.getResourceResolver();
			    UserManager userManager = resourceResolver.adaptTo(UserManager.class);
			    Group groupd = null;
			     
				try {
					for(String groupName: groupNames){
						LOG.debug("group Name ::::"+groupName);
					groupd = (Group) userManager.getAuthorizable(groupName);
					users = groupd.getMembers();
			           while(users.hasNext()){
			              obj = users.next();
			                 if(!(obj instanceof User)){
			                   continue;
			                 }
			                 user = (User)obj;
							 id = user.getID();
							 path= user.getPath();
							 list.add(new KeyValue(id, path));
			             }
					}
			          
				} catch (RepositoryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				final Collator collator = Collator.getInstance(request.getLocale());
				Collections.sort(list, new Comparator<KeyValue>() {
			        public int compare(KeyValue o1, KeyValue o2) {
			            return collator.compare(o1.value, o2.value);
			        }
			    });
				
				@SuppressWarnings("unchecked")
				
			    DataSource ds = new SimpleDataSource(new TransformIterator(list.iterator(), new Transformer() {

					public Object transform(Object input) {
						try {
			                KeyValue keyValue = (KeyValue) input;

			                ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
			                vm.put("text", keyValue.key);
			                vm.put("value", keyValue.value);

			                return new ValueMapResource(resourceResolver, new ResourceMetadata(), "nt:unstructured", vm);
			            } catch (Exception e) {
			                throw new RuntimeException(e);
			            }
					}
				}));
				request.setAttribute(DataSource.class.getName(), ds);
	}
	
}
class KeyValue {
    String key;
    String value;
    
    public KeyValue(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
