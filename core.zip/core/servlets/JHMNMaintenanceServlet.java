package com.jhmn.jhmn.core.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Dictionary;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.impl.MaintenanceServiceImpl;
import com.jhmn.jhmn.core.interfaces.MaintenanceService;


@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "MNBD Maintenance Status check"),
	@Property(name = "sling.servlet.paths", value = { "/bin/sling/mnbdmaintenanceStatus" }),
	@Property(name = "service.vendor", value = "MNBD"),
	@Property(name = "maintenance.message.path", value = "/content/MNBD/en/nli/maintenance"),
	@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)})
public class JHMNMaintenanceServlet extends SlingAllMethodsServlet{

	private static Dictionary<String, String> properties;

	@SuppressWarnings("unchecked")
	@Activate
	public void activate(ComponentContext context) throws Exception {
		properties = context.getProperties();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory
			.getLogger(JHMNMaintenanceServlet.class);

	protected final void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException, IOException {
		MaintenanceService maintenanceService = new MaintenanceServiceImpl();
		JSONObject json = new JSONObject();
		LOG.debug("inside JHINSMaintenanceServlet");
		String domain = request.getParameter("domain");
		LOG.debug("domain::::::::::::::"+domain);
		boolean maintenanceStatus = false;
		String message = StringUtils.EMPTY;
		Node maintenanceNode = null;		

		if(JHMNConstants.BERMUDA_MAINTENANCE.equalsIgnoreCase(domain)){
			Resource resource =request.getResourceResolver().getResource(properties.get("maintenance.message.path"));
			if(null != resource && null!=resource.adaptTo(Page.class)){
				Page page = resource.adaptTo(Page.class);
				Node node = page.adaptTo(Node.class);
				Node jcrNode;
				try {
					if(null!=node && node.hasNode(JHMNConstants.JCR_CONTENT)){
						jcrNode = node.getNode(JHMNConstants.JCR_CONTENT);
						if(null!=jcrNode && jcrNode.hasNode(JHMNConstants.PAR_NODE)){
							Node parNode = jcrNode.getNode(JHMNConstants.PAR_NODE);
							if(null!=parNode && parNode.hasNode(JHMNConstants.MAINTENANCE_NODE)){
								maintenanceNode = parNode.getNode(JHMNConstants.MAINTENANCE_NODE);
							} 
						}
					}
				}catch (PathNotFoundException e) {
					LOG.error("PathNotFoundException",e);
				} catch (RepositoryException e) {
					LOG.error("RepositoryException",e);
				}
				maintenanceStatus =  maintenanceService.getStatus(maintenanceNode);
				LOG.debug("maintenanceStatus is "+maintenanceStatus);
				if(maintenanceStatus){
					message = maintenanceService.getMessage(maintenanceNode);
				}else{
					message = JHMNConstants.MAINTENANCE_MESSAGE;
				}
			} 
		}

		json = maintenanceService.getJsonResponse(domain, maintenanceStatus, message);
		LOG.debug("json data:::::::::::::::::::::"+json.toString());
		PrintWriter out = response.getWriter();
		out.println(json);
		out.flush();
		out.close();
	}

}
