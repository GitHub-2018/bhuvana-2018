package com.jh.igpinfo.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Model(adaptables=Resource.class)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class ListAssetItem {

	private static final Logger LOG = LoggerFactory.getLogger(ListAssetItem.class);

	

	private String assetTitle;
	private String assetPath;
	
	public String getAssetTitle() {
		return assetTitle;
	}
	public void setAssetTitle(String assetTitle) {
		this.assetTitle = assetTitle;
	}
	public String getAssetPath() {
		return assetPath;
	}
	public void setAssetPath(String assetPath) {
		this.assetPath = assetPath;
	}
}