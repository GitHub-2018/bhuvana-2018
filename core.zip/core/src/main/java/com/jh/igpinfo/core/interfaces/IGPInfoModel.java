package com.jh.igpinfo.core.interfaces;

public interface IGPInfoModel {
	public boolean isEmpty();

}