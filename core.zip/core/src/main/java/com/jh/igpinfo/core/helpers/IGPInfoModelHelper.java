package com.jh.igpinfo.core.helpers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.igpinfo.core.models.ListAssetItem;
import com.jh.igpinfo.core.models.ListPageItem;

public class IGPInfoModelHelper {

	public static String output = "";
	public static final String DC_TITLE="dc:title";
	public static final String EMPTY_STRING = "";
	public static final String JCR_CONTENT="jcr:content";


	public static String checkLinkType(String imagelink)
	{
		if(imagelink.startsWith("/content") && !(imagelink.startsWith("/content/dam")))
		{
			output = "internal";
		}
		else if(imagelink.startsWith("/content/dam") || imagelink.startsWith("https") || imagelink.startsWith("http"))
		{
			output = "external";
		}
		else {
			output="invalid";
		}

		return output;		
	}
	public static String generateIdByTitle(String tabTitle){
		String tabTitleId=tabTitle.replaceAll(" ", "_").toLowerCase();
		return tabTitleId;	
	}
	public static String generateRandomId(){
		String uniqueID = UUID.randomUUID().toString();
		return uniqueID;	
	}

	public static ArrayList<ListPageItem> getPageDetail(String parentPath,ResourceResolver resourceResolver){

		ListPageItem pageBean= null;
		ArrayList<ListPageItem> pageItemArrayList=new ArrayList<ListPageItem>();

		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
		Page parentPage =pageManager.getPage(parentPath);

		if(null!=parentPage){
			Iterator<Page> pages=parentPage.listChildren();

			while (pages.hasNext()) {
				Page childPage = pages.next();
				ValueMap properties = childPage.getProperties();
				pageBean= new ListPageItem();
				pageBean.setPageTitle(childPage.getTitle());
				pageBean.setPageDetail(properties.get("pageDetail",String.class)!=null?properties.get("pageDetail",String.class):EMPTY_STRING);
				pageBean.setPagePath(childPage.getPath());
				pageItemArrayList.add(pageBean);

			}
		}
		return pageItemArrayList;
	}


	public static ArrayList<ListAssetItem> getAssetDetail(String parentPath,ResourceResolver resourceResolver){

		ListAssetItem assetBean=null;
		ArrayList<ListAssetItem> assetItemArrayList=new ArrayList<ListAssetItem>();

		Resource resource = resourceResolver.getResource(parentPath);

		if(null!=resource){
			Iterator<Resource> resources=resource.listChildren();
			Resource childResource=null;
			Asset asset=null;
			while (resources.hasNext()) {
				childResource = resources.next();
				asset=childResource.adaptTo(Asset.class);
				//condition to ignore jcr_content node at same level as asset childnodes.
				if(null!=asset && asset.getName()!=JCR_CONTENT){
					Map<String, Object> assetMetaDataMap = asset.getMetadata();
					assetBean=new ListAssetItem();
					if(assetMetaDataMap.containsKey(DC_TITLE) && !asset.getMetadataValue(DC_TITLE).isEmpty()){
						assetBean.setAssetTitle(asset.getMetadataValue(DC_TITLE));
						assetBean.setAssetPath(asset.getPath());
						assetItemArrayList.add(assetBean);
					}
				}
			}
		}
		return assetItemArrayList;
	}


}


