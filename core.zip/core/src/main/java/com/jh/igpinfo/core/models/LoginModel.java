package com.jh.igpinfo.core.models;

import javax.inject.Inject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;
import com.jh.igpinfo.core.interfaces.IGPInfoModel;



@Model(adaptables = Resource.class, resourceType = { "igpinfo/components/content/login" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class LoginModel implements IGPInfoModel{
	private static Logger LOG = LoggerFactory.getLogger(LoginModel.class);


	@Inject
	private String logintext;

	@Inject
	private String logindescription;

	@Inject
	private String loginurl;

	private String linkType;
	public String getLogintext() {
		return logintext;
	}

	public String getLogindescription() {
		return logindescription;
	}

	public String getLoginurl() {
		return loginurl;
	}


	public String getLinkType(){
		linkType = "";
		try{
			if(!loginurl.isEmpty()){
				linkType = IGPInfoModelHelper.checkLinkType(loginurl);	
			}		
		}

		catch(Exception e)
		{
			LOG.error("Exception",e);
		}
		return linkType;
	}	
	
	@Override
	public boolean isEmpty() {
		boolean empty = false;
		try{
		if(logintext == null || logindescription == null || loginurl == null)
			empty = true;		
		}	
		catch(Exception e)
		{
			LOG.error("Exception occured"+e);
		}
		return empty;
	}

}
