package com.jh.igpinfo.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;



@Model(adaptables=Resource.class)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class TabItem {

	private static final Logger LOG = LoggerFactory.getLogger(TabItem.class);

	@Inject
	@Optional
	private String tabTitle;
	private String tabTitleId;

	public String getTabTitle() {
		return tabTitle;
	}

	public String getTabTitleId() {
		tabTitleId = "";
		try{
			if(!tabTitle.isEmpty()){
				tabTitleId = IGPInfoModelHelper.generateIdByTitle(tabTitle);	
			}		
		}

		catch(Exception e)
		{
			LOG.error("Exception",e);
		}
		return tabTitleId;
	}

}