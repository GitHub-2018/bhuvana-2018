package com.jh.igpinfo.core.models;

import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;
import com.jh.igpinfo.core.interfaces.IGPInfoModel;


@Model(adaptables = Resource.class, resourceType = { "igpinfo/components/content/list" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class ListModel implements IGPInfoModel{



	private static Logger LOG = LoggerFactory.getLogger(ListModel.class);

	@Inject
	public String listType;

	@Inject
	public String parentPath;

	@Inject
	private ResourceResolver resourceResolver;

	private String contentType =null;

	private ArrayList<ListPageItem> pageItemArrayList;
	private ArrayList<ListAssetItem> assetItemArrayList;

	@PostConstruct
	protected void init()
	{
		if(null!=parentPath && parentPath.startsWith("/content/igpinfo") && !(parentPath.startsWith("/content/dam/igpinfo"))){
			pageItemArrayList = IGPInfoModelHelper.getPageDetail(parentPath,resourceResolver);
			contentType="page";

		}
		else if(null!=parentPath && parentPath.startsWith("/content/dam/igpinfo"))
		{
			assetItemArrayList=IGPInfoModelHelper.getAssetDetail(parentPath,resourceResolver);
			contentType="asset";
		}
	}

	@Override
	public boolean isEmpty() {
		boolean empty = false;
		try{
			if(listType== null && parentPath== null)
				empty=true;
		}
		catch(Exception e)
		{
			LOG.error("Exception occured"+e);
		}
		return empty;
	}

	public String getListType() {
		return listType;
	}
	public String getContentType() {
		return contentType;
	}
	public ArrayList<ListPageItem> getPageItemArrayList() {
		return pageItemArrayList;
	}

	public ArrayList<ListAssetItem> getAssetItemArrayList() {
		return assetItemArrayList;
	}
}
