package com.jh.igpinfo.core.models;

import javax.inject.Inject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;
import com.jh.igpinfo.core.interfaces.IGPInfoModel;

@Model(adaptables = Resource.class, resourceType = { "igpinfo/components/content/subscribe" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class SubscribeButtonModel implements IGPInfoModel{
	private static Logger LOG = LoggerFactory.getLogger(SubscribeButtonModel.class);


	@Inject
	private String subscriptionText;
	
	
	@Inject
	private String subscriptionPath;


	private String linkType;
	
	public String getSubscriptionText() {
		return subscriptionText;
	}

	public String getSubscriptionPath() {
		return subscriptionPath;
	}
	public String getLinkType(){
		linkType = "";
		try{
			if(!subscriptionPath.isEmpty()){
				linkType = IGPInfoModelHelper.checkLinkType(subscriptionPath);	
			}		
		}

		catch(Exception e)
		{
			LOG.error("Exception",e);
		}
		return linkType;
	}	

	@Override
	public boolean isEmpty() {
		boolean empty = false;
		try{
		if(subscriptionText == null || subscriptionPath == null)
			empty = true;		
		}	
		catch(Exception e)
		{
			LOG.error("Exception occured"+e);
		}
		return empty;
	}
	
}
