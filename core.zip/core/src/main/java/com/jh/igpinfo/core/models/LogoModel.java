package com.jh.igpinfo.core.models;

import java.text.ParseException;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;
import com.jh.igpinfo.core.interfaces.IGPInfoModel;

@Model(adaptables = Resource.class, resourceType = { "igpinfo/components/content/logo" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class LogoModel  implements IGPInfoModel{
	private static Logger LOG = LoggerFactory.getLogger(LogoModel.class);


	@Inject
	private String logoFileReference;

	@Inject
	private String logoLinkURL;

	@Inject
	private String alternativeText;

	private String linkType;

	public String getLogoFileReference() {
		return logoFileReference;
	}

	public String getLogoLinkURL() {
		return logoLinkURL;
	}
	public String getAlternativeText() {
		return alternativeText;
	}

	public String getLinkType(){
		linkType = "";
		try{
			if(!logoLinkURL.isEmpty()){
				linkType = IGPInfoModelHelper.checkLinkType(logoLinkURL);	
			}		
		}

		catch(Exception e)
		{
			LOG.error("Exception",e);
		}
		return linkType;
	}	

	@Override
	public boolean isEmpty() {
		boolean empty = false;
		try{
		if(logoFileReference == null || logoLinkURL == null || alternativeText == null)
			empty = true;		
		}	
		catch(Exception e)
		{
			LOG.error("Exception occured"+e);
		}
		return empty;
	}

}
