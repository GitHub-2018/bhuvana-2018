package com.jh.igpinfo.core.models;

import java.util.List;
import javax.inject.Inject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.interfaces.IGPInfoModel;
import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;

@Model(adaptables = Resource.class, resourceType = { "igpinfo/components/content/accordion" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class AccordionModel implements IGPInfoModel{
	
	private static final Logger LOG = LoggerFactory.getLogger(AccordionModel.class);
	
	@Inject
	private String accordionOverview ;
	
	public String getAccordionOverview()
	{
		return accordionOverview;
	}
	
	private String accodionId;
	
	public String getAccordionId(){
		accodionId = ""; 
		try{
			
			accodionId = IGPInfoModelHelper.generateRandomId();					
		}
		catch(Exception e)
		{
			LOG.error("Exception",e);
		}
		return accodionId;
	}
	
	@Inject
	public List<AccordionItem> accordionconfigs;

	@Override
	public boolean isEmpty() {
		boolean empty = false;
		try{
		if(accordionconfigs == null)
			empty = true;		
		}
	
		catch(Exception e)
		{
			LOG.error("Exception occured"+e);
		}
		return empty;
	}
}
