package com.jh.igpinfo.core.models;

import javax.inject.Inject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;

@Model(adaptables=Resource.class)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class AccordionItem {
	
	@Inject
	private String accordionTitle;
	
	@Inject
	private String accordionText;
	
	public String getAccordionTitle() {
		return accordionTitle;
	}

	public String getAccordionText() {
		return accordionText;
	}
}