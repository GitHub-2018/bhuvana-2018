package com.jh.igpinfo.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;
import com.jh.igpinfo.core.interfaces.IGPInfoModel;


@Model(adaptables = Resource.class, resourceType = { "igpinfo/components/content/brightcove" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class BrightcoveModel  implements IGPInfoModel{
	private static Logger LOG = LoggerFactory.getLogger(BrightcoveModel.class);


	@Inject
	private String brightcoveTitle;

	@Inject
	private String brightcoveLink;

	private String linkType;
	
	public String getBrightcoveTitle() {
		return brightcoveTitle;
	}

	public String getBrightcoveLink() {
		return brightcoveLink;
	}

	public String getLinkType(){
		linkType = "";
		try{
			if(!brightcoveLink.isEmpty()){
				linkType = IGPInfoModelHelper.checkLinkType(brightcoveLink);	
			}		
		}

		catch(Exception e)
		{
			LOG.error("Exception",e);
		}
		return linkType;
	}	
	

	@Override
	public boolean isEmpty() {
		boolean empty = false;
		try{
		if(brightcoveTitle == null || brightcoveLink == null)
			empty = true;		
		}	
		catch(Exception e)
		{
			LOG.error("Exception occured"+e);
		}
		return empty;
	}
}
