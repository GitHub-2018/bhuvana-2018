package com.jh.igpinfo.core.models;

import javax.inject.Inject;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;


@Model(adaptables=Resource.class)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class CarouselItem {
	
	private static final Logger LOG = LoggerFactory.getLogger(CarouselItem.class);
	
	@Inject
	@Optional
	private String imagelink;
	
	@Inject
	private String image;
	
	@Inject
	private String alttext;
	
	@Inject
	@Optional
	private String carouseltext;
		
	private String linkType;
	
	public String getCarouseltext() {
		return carouseltext;
	}

	public String getLinkType(){
	linkType = "";
	try{
		if(imagelink != null){
			linkType = IGPInfoModelHelper.checkLinkType(imagelink);	
		}		
	}
	catch(Exception e){
		LOG.error("Excception",e);
		
	}
		return linkType;
}

	public String getImagelink() {
		return imagelink;
	}

	public String getImage() {
		return image;
	}

	public String getAlttext() {
		return alttext;
	}

}