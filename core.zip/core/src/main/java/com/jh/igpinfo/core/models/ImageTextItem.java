package com.jh.igpinfo.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;

@Model(adaptables = Resource.class)
@Exporter(name = "jackson", extensions = "json", options = {
@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ImageTextItem  {
	
	private static final Logger LOG = LoggerFactory.getLogger(ImageTextItem.class);
	
	@Inject
	private String componentAlignment;
	
	@Inject
	private String image;
	
	@Inject
	private String alttext;

	@Inject
	private String title;
	
	@Inject
	private String description;

	public String getComponentAlignment() {
		return componentAlignment;
	}
	
	public String getDescription() {
		return description;
	}

	public String getTitle() {
		return title;
	}
	
	public String getAlttext() {
		return alttext;
	}

	//private String linkType;

	public String getImage() {
		return image;
	}
	
	/*public String getLinkType(){
		linkType = "";
		try{
			if(!imagelink.isEmpty()){
				linkType = IGPInfoModelHelper.checkLinkType(imagelink);	
			}		
		}
		catch(Exception e){
			LOG.error("Excception",e);
			
		}
			return linkType;
	}*/
	/*@Override
	public boolean isEmpty() {
		if (image.isEmpty() || alttext.isEmpty() || title.isEmpty() || description.isEmpty() ) {
			return true;
		} else
			return false;
	}*/

}
