package com.jh.igpinfo.core.models;

import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import com.jh.igpinfo.core.helpers.IGPInfoModelHelper;


@Model(adaptables=Resource.class)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class ClientDetailItem {

	@Inject
	public String heading;

	@Inject
	public String description;

	@Inject
	@Optional
	public String parentPath;


	@Inject
	private ResourceResolver resourceResolver;

	private String contentType =null;

	private ArrayList<ListPageItem> pageItemArrayList;
	private ArrayList<ListAssetItem> assetItemArrayList;

	@PostConstruct
	protected void init()
	{
		if(null!=parentPath && parentPath.startsWith("/content/igpinfo") && !(parentPath.startsWith("/content/dam/igpinfo"))){
			pageItemArrayList = IGPInfoModelHelper.getPageDetail(parentPath,resourceResolver);
			contentType="page";

		}
		else if(null!=parentPath && parentPath.startsWith("/content/dam/igpinfo"))
		{
			assetItemArrayList=IGPInfoModelHelper.getAssetDetail(parentPath,resourceResolver);
			contentType="asset";
		}
	}

	public String getHeading() {
		return heading;
	}

	public String getDescription() {
		return description;
	}
	public String getContentType() {
		return contentType;
	}
	public ArrayList<ListPageItem> getPageItemArrayList() {
		return pageItemArrayList;
	}

	public ArrayList<ListAssetItem> getAssetItemArrayList() {
		return assetItemArrayList;
	}

}
