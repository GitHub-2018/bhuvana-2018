package com.jh.igpinfo.core.models;

import java.util.List;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.igpinfo.core.interfaces.IGPInfoModel;


@Model(adaptables = Resource.class, resourceType = { "igpinfo/components/content/carouselcomp" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })

public class CarouselModel implements IGPInfoModel{
	private static final Logger LOG = LoggerFactory.getLogger(CarouselModel.class);
	@Inject
	public List<CarouselItem> carouselconfigs;

	@Override
	public boolean isEmpty() {
		boolean empty = false;
		try{
		if(carouselconfigs == null)
			empty = true;		
		}
	
		catch(Exception e)
		{
			LOG.error("Exception occured"+e);
		}
		return empty;
	}
	
}
