package com.jhmn.jhmn.core.model;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhmn.jhmn.core.bean.JHMNArticleBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.constants.JHMNNewsConstants;
import com.jhmn.jhmn.core.helper.JHMNArticleHelper;

@Model(adaptables =SlingHttpServletRequest.class)
public class JHMNNewsandUpdateModel {
	private static Logger LOG = LoggerFactory.getLogger(JHMNNewsandUpdateModel.class);

	@Inject
	private String limit;		
	@Inject
	private String channel;
	@Inject
	private String newsPath;

	@Inject
	private SlingHttpServletRequest request;
	private ArrayList<JHMNArticleBean> articlebeans;


	private static Session session;

	@PostConstruct
	protected void init() throws RepositoryException, ParseException
	{	
		articlebeans = new ArrayList<JHMNArticleBean>();
		JHMNArticleBean articleBean = null;
		TagManager tagmanager = request.getResourceResolver().adaptTo(TagManager.class);
		Tag tag = tagmanager.resolve(channel);
		if(null!=tag && null!=tag.getTagID()){
		QueryBuilder queryBuilder = request.getResourceResolver().adaptTo(QueryBuilder.class);

		session = request.getResourceResolver().adaptTo(Session.class);
		Map<String, String> map = new HashMap<String, String>();
		map.put("type", JHMNNewsConstants.PAGE_TYPE);
		map.put("path", newsPath);
		map.put("1_property", JHMNNewsConstants.CQ_TEMPLATE);
		map.put("1_property.value", JHMNNewsConstants.ARTICLE_TEMPLATE);
		map.put("2_property", JHMNConstants.CQ_TAGS_PROPERTYNAME);
		map.put("2_property.value", tag.getTagID());
		map.put("orderby", JHMNNewsConstants.ORDER_BY);
		map.put("orderby.sort", JHMNNewsConstants.ODERBY_SORT);
		map.put("p.limit", limit);
		Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
		SearchResult searchRes = query.getResult();
		if (!searchRes.getHits().isEmpty()) {
			for (Hit hit : searchRes.getHits()) {
				String queryPath = hit.getPath();
				articleBean = new JHMNArticleBean();
				articleBean = JHMNArticleHelper.retriveArticleBean(queryPath, request.getResourceResolver());
				articlebeans.add(articleBean);

			}
		
		}
		else {
			LOG.debug("No results for the selected channel" + channel);
		}
		LOG.debug("End of retriveRelatedArticlesByChannel method");
		}
	}
	public ArrayList<JHMNArticleBean> getArticlebeans() {
		return articlebeans;
	}

}
