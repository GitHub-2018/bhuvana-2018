package com.jhmn.jhmn.core.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.jhmn.jhmn.core.bean.AssetMetaDataBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.helper.JHMNAssetHelper;

@Model(adaptables = Resource.class)
public class JHMNRelatedResourcesModel {

	private static final Logger LOG = LoggerFactory.getLogger(JHMNRelatedResourcesModel.class);

	@Inject
	private String title;

	@Inject
	private String topic;
	
	@Inject
	private String limit;

	private static Session session = null;

	@Inject
	private ResourceResolver resourceResolver;

	ArrayList<AssetMetaDataBean> assetBeanList;

	public String getTitle() {
		return title;
	}

	public String getLimit() {
		return limit;
	}
	public ArrayList<AssetMetaDataBean> getAssetBeanList() {
		return assetBeanList;
	}

	public void setAssetBeanList(ArrayList<AssetMetaDataBean> assetBeanList) {
		this.assetBeanList = assetBeanList;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	@PostConstruct
	protected void init(){
	
		assetBeanList = new ArrayList<AssetMetaDataBean>();
		try {
			AssetMetaDataBean assetbean = new AssetMetaDataBean();
			TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
			Tag tag = tagManager.resolve(topic);
			QueryBuilder queryBuilder = resourceResolver.adaptTo(QueryBuilder.class);
			session = resourceResolver.adaptTo(Session.class);
			Map<String, String> map = new HashMap<String, String>();
			map.put("type", JHMNConstants.DAM_ASSET);
			map.put("1_group.1_property", JHMNConstants.TYPE_PROP_NAME);
			map.put("1_group.1_property.value", tag.getTagID());
			map.put("orderby", JHMNConstants.ORDER_BY_MODIFIED);
			map.put("orderby.sort", JHMNConstants.ORDER_SORT);
			map.put("p.limit", limit);
			Query query = queryBuilder.createQuery(PredicateGroup.create(map), session);
			SearchResult searchRes = query.getResult();
				if (!searchRes.getHits().isEmpty()) {
					for (Hit hit : searchRes.getHits()) {
						String queryPath = hit.getPath();
						assetbean = JHMNAssetHelper.retrieveAssetBean(queryPath,resourceResolver);
						assetBeanList.add(assetbean);
						LOG.info("Assetbean list size:::::"+assetBeanList.size());
					}
				}	
			} catch (PathNotFoundException e) {
				LOG.error("PathNotFoundException occured" ,e);
			} catch (ValueFormatException e) {
				LOG.error("ValueFormatException occured" ,e);
			} catch (RepositoryException e) {
				LOG.error("RepositoryException occured" ,e);
			}
	}

}
