package com.jhmn.jhmn.core.impl;

import java.io.IOException;
import java.util.Dictionary;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jhmn.jhmn.core.constants.JHMNConstants;
import com.jhmn.jhmn.core.interfaces.JHMNConfigService;

import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;

@Service
@Component(immediate = true, metatype = true, name = "JHMNConfigServiceImpl", description = "Programatically get  properties of OSGi configurations.")
public class JHMNConfigServiceImpl implements JHMNConfigService {

	/** The service to get OSGi configs */
	@Reference
	private ConfigurationAdmin configAdmin;

	private static final Logger LOG = LoggerFactory
			.getLogger(JHMNConfigServiceImpl.class);
	
	/**
     * Get the value of an OSGi configuration string property for a given PID.
     *
     *
     * @param property The property of the config to retrieve    
     * @return The property value
     */

	public String getConfigProperty(final String property) {
		String propertyValue ="" ;
		try {
			Configuration conf = configAdmin.getConfiguration(JHMNConstants.CONFIG_PID);
			@SuppressWarnings(JHMNConstants.UNCHECKED)
			Dictionary<String, Object> properties = conf.getProperties();
			if (properties != null) {
				if (!properties.isEmpty()) {
					if (properties.get(property) != null) {
						propertyValue = properties.get(property).toString();
					}
				}
				
			}
		} catch (IOException e) {
			LOG.error("IOException",e);
		}
		return propertyValue;
		
	}

}
