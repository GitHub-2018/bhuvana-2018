package com.jhmn.jhmn.core.helper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.jhmn.jhmn.core.bean.NavBean;
import com.jhmn.jhmn.core.constants.JHMNConstants;

public class JHMNNavigationHelper {
	private static final Logger LOG = LoggerFactory.getLogger(JHMNNavigationHelper.class);

	/**
	 * Method to fetch the local navigation pages
	 *
	 * @param currentpage
	 * @param parentpage
	 * @return list
	 * @throws RepositoryException
	 */

	public List<NavBean> retrieveLocalNavPages(Page currentPage, Page parentPage) throws PathNotFoundException {

		List<NavBean> localPages = new ArrayList<NavBean>();
		NavBean localNavBean = null;
		String pagePath = null;
		String pageTitle = null;

		/*
		 * Getting the direct parent Pages of the currentPage till the
		 * ParentPage
		 */
		if (null != currentPage && null != parentPage) {
			int depth = parentPage.getDepth();
			LOG.debug("currentpage Depth" + currentPage.getDepth());
			;
			int i;
			for (i = currentPage.getDepth() - depth; i >= 0; i--) {
				localNavBean = new NavBean();
				Page parent = currentPage.getParent(i);
				/*
				 * Getting Navigation title as title if navigation title is
				 * empty, fetching pageTitle if its empty fetching Title as
				 * title.
				 * 
				 */
				if (parent.getNavigationTitle() != null) {
					pageTitle = parent.getNavigationTitle();
				} else if (parent.getPageTitle() != null) {
					pageTitle = parent.getPageTitle();
				} else {
					pageTitle = parent.getTitle();
				}
				localNavBean.setPageTitle(parent.getTitle());
				localNavBean.setPagePath(parent.getPath());
				localPages.add(localNavBean);
			}

			/* Getting the one level child Pages of the currentPage */
			Iterator<Page> iterator = currentPage.listChildren();
			while (iterator.hasNext()) {
				Page child = (Page) iterator.next();
				if (!child.isHideInNav()) {
					localNavBean = new NavBean();
					/*
					 * Getting Navigation title as title if navigation title is
					 * empty, fetching pageTitle if its empty fetching Title as
					 * title.
					 * 
					 */
					if (child.getNavigationTitle() != null) {
						pageTitle = child.getNavigationTitle();
					} else if (child.getPageTitle() != null) {
						pageTitle = child.getPageTitle();
					} else {
						pageTitle = child.getTitle();
					}
					pagePath = child.getPath();
					localNavBean.setPageTitle(pageTitle);
					localNavBean.setPagePath(pagePath);
					localPages.add(localNavBean);
				}
			}

		}

		return localPages;
	}

	/**
	 * Method to fetch the First level child pages .
	 * 
	 * @return list
	 */

	public static List<Page> retrieveChildPages(Page currentPage) {
		List<Page> pages = new ArrayList<Page>();
		if (currentPage != null) {
			Page child = null;

			Iterator<Page> childrenPages = currentPage.listChildren();
			while (childrenPages.hasNext()) {

				child = childrenPages.next();
				pages.add(child);

			}

		}
		return pages;

	}

	/**
	 * Overloaded Method to fetch the navigation pages .
	 *
	 * @param absPage
	 * @return list
	 * @throws PathNotFoundException
	 */

	public List<NavBean> retrieveNavigationPages(Page absParentPage) throws PathNotFoundException {
		List<NavBean> navPages = new ArrayList<NavBean>();
		List<NavBean> subNavPages = new ArrayList<NavBean>();
		NavBean navBean = null;
	
		if (null != absParentPage) {
			Iterator<Page> iterator = absParentPage.listChildren();
			while (iterator.hasNext()) {
				Page child = (Page) iterator.next();
				/* Checking Hide In Navigation property */
				LOG.info("childpath:: for show:: "+child.getPath());
				
				String title = "";
				if (!child.isHideInNav()) {
					navBean = new NavBean();
					if (child.getProperties().get(JHMNConstants.CQ_TEMPLATE_LABEL, "") != null) {
						String template = child.getProperties().get(JHMNConstants.CQ_TEMPLATE_LABEL, "").toString();
						if (template.equals(JHMNConstants.BASE_PAGE_TEMPLATE)) {
							navBean.setBasePage(true);
						}
					}
					/*
					 * Getting Navigation title as title if navigation title is
					 * empty, fetching pageTitle if its empty fetching Title as
					 * title.
					 * 
					 */
					if (child.getNavigationTitle() != null) {
						title = child.getNavigationTitle();
					} else if (child.getPageTitle() != null) {
						title = child.getPageTitle();
					} else
						title = child.getTitle();
					navBean.setPageTitle(title);
					if (child.getPath() != null) {
						navBean.setPagePath(child.getPath());
					}
					/*
					 * If has child getting the child pages and setting the
					 * level
					 */
					if (child.listChildren().hasNext()) {
						/*
						 * Calling Recursively the same method if the page has
						 * children
						 */

						subNavPages = retrieveNavigationPages(child);
						navBean.setChildPages(subNavPages);
						if (subNavPages != null && subNavPages.size() > 0) {
							navBean.setLevel(1);
						} else {
							navBean.setLevel(0);
						}
					} else {
						navBean.setLevel(0);
					}
					navPages.add(navBean);
				}

			}
		}

		return navPages;
	}

}