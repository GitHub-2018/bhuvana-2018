/*
| Copyright 2013 Adobe
|
| Licensed under the Apache License, Version 2.0 (the "License");
| you may not use this file except in compliance with the License.
| You may obtain a copy of the License at
|
| http://www.apache.org/licenses/LICENSE-2.0
|
| Unless required by applicable law or agreed to in writing, software
| distributed under the License is distributed on an "AS IS" BASIS,
| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
| See the License for the specific language governing permissions and
| limitations under the License.
*/
 
if (CQ_Analytics.CustomStoreMgr ) {
 
 
    // HTML template
    CQ_Analytics.CustomStoreMgr.template = 
        "<input class='customstore-input' type='checkbox' id='customstore-input-%key%' name='%key%' value='%key%' %checked%>" +
        "<label for='customstore-input-%key%'" +
        "<div class='toggle'></div>" +
        "%value%</label>";
 
    CQ_Analytics.CustomStoreMgr.templateRenderer = function(key,value) {
/*
         var checkedString = ""; var checkedClass = "";
         if (value==="true") {
             checkedString = "checked='checked'";
             checkedClass  = "checked";
         }*/
       // console.log("KEY***" + key);
       // console.log("VALUE***" + value);
         var template = CQ_Analytics.CustomStoreMgr.template;
         return template.replace(/%value%/g, value)
             .replace(/%key%/g, key);
     }
 
 
    CQ_Analytics.CustomStoreMgr.renderer = function(store, divId) {
 
        // first load data
                                // CQ_Analytics.CustomStoreMgr.loadData();
 
                                $CQ("#" + divId).children().remove();
 
 
                                var templateRenderer = CQ_Analytics.CustomStoreMgr.templateRenderer;
                               //console.log("templateRenderer ++" + templateRenderer);
        // Set title
                                //$CQ("#" + divId).addClass("cq-cc-customstore");
                                //var div = $CQ("<div>").html(name + " services");
       // console.log("div ++" + div);
                                //$CQ("#" + divId).append(div);           
 
 
                                var data = this.getJSON();
 
        if (data) {
            for (var i in data) {
               // console.log("Infoo " + i + data[i]);
               //  console.log("Infoo " + typeof data[i]);
               if (typeof data[i] === 'string') {
                 //  console.log("TESTTTT" + templateRenderer(i,data[i]));
                    $CQ("#" + divId).append(templateRenderer(i,data[i]));
                   if(i === "firstname"){
                          $CQ("#" + divId).addClass("cq-cc-customstore");
                       var div = $CQ("<div>").html(data[i] + "'s User Info");
                    //   console.log("div ++" + div);
                       $CQ("#" + divId).append(div); 
                   }

                }
            }
        }
 
    }
 
 
                CQ_Analytics.ClickstreamcloudMgr.register(CQ_Analytics.CustomStoreMgr);
 
}
