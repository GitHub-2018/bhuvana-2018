  $(document).ready(function(){
          $("#iframeid").each(function() {
        var selector= $(this).closest(".tab-content").attr("class");
          //   console.log("selector",selector);
              if(typeof selector==="undefined")
              {
            	  if($("iframe[src='']")){
            		  $(this).attr('src', $(this).attr('src1'));
            	  }
              }

        //var dyndiv=$("iframe").siblings('.g').attr("class");
        // var dyndiv1=$("iframe").closest("div").siblings().text();
        //var $ul      = $this.closest('ul:not(.dropdown-menu)') 

          });
});
