$(document).on("dialog-ready", function () {
$(".js-coral-Multifield-add").click(function() {
    var field = $(this).parent();
    var size = field.attr("data-maxlinksallowed");

    if (size) {
        var ui = $(window).adaptTo("foundation-ui");
        var totalLinkCount = $(this).prev('ol').children('li').length;
        console.log("totalLinkCount"+totalLinkCount);
        if (totalLinkCount >= size) {
            ui.alert("Warning", "Maximum " + size + " options are allowed!", "notice");
            return false;
        }
    }
});
});
//autoscroll
$(document).ready(function (){
            $(".answer").click(function (){
                $('html, body').animate({
                    scrollTop: $(this).parent().offset().top
                }, 1000);
            });
 }); 