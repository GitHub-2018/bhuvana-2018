
var jsonResponse;
$(document).ready(function () {
    $('.answer').on('click', function () {     

            var elem = $(this);
             var checkedAnswer = elem[0].classList[1];
             var parentDivID = (elem.parent('div').parent('div.question')).prevObject[0].id;
             var options = "options";
             var filterNextQuestion = jsonResponse[parentDivID][options][checkedAnswer];
             console.log(filterNextQuestion);
             $('#' + filterNextQuestion).show();

             // hide previous unselected options                
             $('#' + parentDivID).find('div.answer').each(function () {
                 console.log($(this));
                 if ($(this)[0].classList[1] != checkedAnswer) {
                     $(this).hide();
                 }                 
             });

             var elemStr = parentDivID + ' .' + checkedAnswer;
             $('#' + elemStr).find('p').each(function (i) {
                 //console.log('1');
                 //console.log($(this));  
                 if (i != 0) {
                     if ($(this)[0].className == "shwArrow clicked") {
                         $(this).parent('div').parent('div.question').find('div.answer').each(function () {
                             $(this).show();
                             $('#' + filterNextQuestion).hide();
                             if (jsonResponse[filterNextQuestion]) {                                 
                                 var otherRes = jsonResponse[filterNextQuestion][options];
                                 //for (var or = 0; or < otherRes.length; or++) {
                                 //    console.log(otherRes[or]);
                                 //}
                                 for (x in otherRes) {
                                     $('#' + otherRes[x]).hide();
                                     var inter = otherRes[x];
                                    if (jsonResponse[inter]) {
                                        var otherRes2 = jsonResponse[inter][options];
                                        for (t in otherRes2) {
                                            $('#' + otherRes2[t]).hide();
                                        }
                                    } 

                                 }

                                 $('#' + filterNextQuestion).find('div.answer').each(function () {
                                     $(this).show();
                                     $(this).find('p.clicked').each(function () {
                                         $(this).removeAttr('class');
                                         $(this).attr('class', 'hideArrow');
                                         console.log($(this).parent());
                                         $(this).parent().find('p.hideArrow').each(function (i) {                                             
                                             if (i == 0) {
                                                 $(this).removeAttr('class');
                                                 $(this).attr('class', 'shwArrow');
                                             }                                             
                                         });                                         
                                     });
                                 });
                             }
                             
                         });
                     }
                 }

                 if ($(this)[0].classList[0] == "shwArrow") {
                     $(this).removeAttr('class');
                     $(this).attr('class', 'hideArrow');
                 }                 
                 else {
                     if ($(this).next().hasClass('clicked')) {                         
                         $(this).removeAttr('class');
                         $(this).attr('class', 'shwArrow');
                     }
                     else {
                         $(this).removeAttr('class');
                         $(this).attr('class', 'shwArrow clicked');
                     }
                 }
             });




         });


             firstTimeLoad();
             loadAnswerResponce();
         });



         function firstTimeLoad() {
             var getAllQuestionElement = $('.question');
             getAllQuestionElement.each(function (i) {
                 if (i != 0) {
                     $(this).hide();
                 }
             });
         }


function loadAnswerResponce() {
var pagePath = $("#pagePath").text();
   // console.log("pagePath"+pagePath);
     if($("div").is(".questionaire")){
     $.ajax({  
            type: "POST", 
            url: "/bin/sling/jhins/mappingconfiguration",
         	data:{"pagePath" : pagePath},
            success: function(resp){
            //console.log("response$$$$"+resp);
          jsonResponse = resp;
        },
            error: function(result) {
                console.log('error');
            }
    });
     }
}


