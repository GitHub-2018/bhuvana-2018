$( function() {

	$( "#from" ).datepicker();
	$( "#to" ).datepicker();

    $("#customSearch").hide();
   	$("#lessOptions").hide();

     $(document).on('click','#moreOptions', function(){
		$("#customSearch").show();
       	$("#lessOptions").show();
        $("#moreOptions").hide();
    });
     $(document).on('click','#lessOptions', function(){
		$("#customSearch").hide();
    	$("#lessOptions").hide();
        $("#moreOptions").show();
    });

	var uuid;
    var role;
    var uid;
    var partnerId;
    var fimId;
	var ssoconId;
    var ivGroups;
	var firmIndicator;

    if(typeof UserData != undefined && UserData != null){

    if(UserData.content.hasOwnProperty('uuid')){
		uuid=UserData.content.uuid;
    }
    if(UserData.content.hasOwnProperty('role')){
        role= UserData.content.role;
    }
    if(UserData.content.hasOwnProperty('uid')){
       uid= UserData.content.uid;
    }
    if(UserData.content.hasOwnProperty('partner-uid')){
        partnerId= UserData.content.partner-uid;
    }
    if(UserData.content.hasOwnProperty('fim_partner_id')){
       fimId= UserData.content.fim_partner_id;
    }
    if(UserData.content.hasOwnProperty('sso-connection-id')){
        ssoconId= UserData.content['sso-connection-id'];
    }
    if(UserData.content.hasOwnProperty('iv-groups')){
       ivGroups=UserData.content['iv-groups'];
    }
    if(UserData.content.hasOwnProperty('firmindicator')){
        firmIndicator=UserData.content.firmindicator;
    }
    }


    console.log("ivGroups"+ivGroups);
	console.log("fimId"+fimId);

    if((null!= document.getElementById("policySearchUrl"))){
        var PolicySearchUrl = document.getElementById("policySearchUrl").innerHTML;
    }
    if((null!= document.getElementById("getPolicyUrl"))){
        var GetPolicyUrl = document.getElementById("getPolicyUrl").innerHTML;
    }
    if((null!= document.getElementById("pdfButtontext"))){
		var pdfButtonText= document.getElementById("pdfButtontext").innerHTML;
    }
    if((null!= document.getElementById("excelbuttonText"))){
        var excelButtonText = document.getElementById("excelbuttonText").innerHTML;
    }
    if((null!= document.getElementById("excelbuttonText"))){
        var setTimeout = document.getElementById("setTimeout").innerHTML;      
    }


    console.log("PolicySearchUrl"+PolicySearchUrl);
    console.log("GetPolicyUrl"+GetPolicyUrl);

    console.log("pdfButtonText"+pdfButtonText);
    console.log("excelButtonText"+excelButtonText);
    console.log("role##"+role);

	if(firmIndicator != "MGROUP")
    {
        if(ivGroups != undefined){
	var ivGroupsMultiple = ivGroups.split(",");   

    for(var i=0;i<ivGroupsMultiple.length;i++)
    {

	if((ivGroupsMultiple[i] == "Producers" || ivGroupsMultiple[i] == "EJProducers" || ivGroupsMultiple[i] == "InternationalProducers") && (role == "Producer" || role == "FirmSupport" || role == "RD/RAM" || role == "SuperUser_SN" || role == "ProducerSupport"))
    {
        $("#myBusinessForm").show();
        $("NotRightRole").hide();
        console.log("inside if right user");
        break;
    }
	else
    {
        console.log("inside else not a right user")
        $("#myBusinessForm").hide();
        $("#NotRightRole").show();
   	}
    }
    }
    }
    else
    {
        $("#myBusinessForm").show();
        $("#NotRightRole").hide();
    }



//Predefined Search starts here

	if(role=="SuperUser_SN")
    {
        $("#predefinedUserNameField").show();
        $("#customUserNameField").show();
    }
    else
        {
           $("#predefinedUserNameField").hide();
           $("#customUserNameField").hide();
    	}
	$('#clearValues').on('click', function() {
        $("#myBusinessForm")[0].reset();

    });
 function refineSearch(){

			$("#PredefinedSearchDiv").hide();
     		$("#ExtendedSearchDiv").hide();
            $("#myBusinessForm").show();
            $("#emptyResponse").hide();
            $("#noResponse").hide();
            $("#refineSearch").hide();
            $('html,body').scrollTop(20);
     		$(".predefined-img-loading").hide();
     		$(".custom-img-loading").hide();
      		$("#NewBusinessPredefinedSearch").show();
     		$("#NewBusinessExtendedSearch").show();
     		$("#customSearch").hide();
    		$("#lessOptions").hide();
        	$("#moreOptions").show();
	}
	$('#refineSeachButton').on('click', function() {
         refineSearch();
    });

	$('#PredefinedGetPolicyBack').on('click', function() {
		$("#PredefinedSearchGetPolicyDiv").hide();
        $("#PredefinedSearchDiv").show();
        $("#refineSearch").show();
        $(".predefinedGetPolicy-img-loading").remove();
        $(".predefinedGetPolicyResponse").parent().show();

	});

    $('#ExtendedGetPolicyBack').on('click', function() {
		$("#ExtendedSearchGetPolicyDiv").hide();
        $("#ExtendedSearchDiv").show();
        $("#refineSearch").show();
        $(".customGetPolicy-img-loading").remove();
        $(".extendedGetPolicyResponse").parent().show();

     });


    $(document).on("click","#NewBusinessPredefinedSearch", function(e){

         e.preventDefault();

         var searchBy=$("#searchBy").val();
         var sortBy=$("#predefinedSortBy").val();
         var userName=$("#predefinedUserName").val();
         var displayProducers=($("#predefinedProducers").is(":checked"))?"Yes":"No";
		 var displayGABGAFirm=($("#predefinedGABGAFirm").is(":checked"))?"Yes":"No";

        if(role=="SuperUser_SN")
         {
			if(userName == "")
            {
                alert("User Name is Mandatory for Predefined Search");
                e.preventDefault();
                return false;
			}
             else
             {
                 $("#NewBusinessPredefinedSearch").css("display","none");
        		 $(".predefined-img-loading").css("display","inline-block");
             }
        }
         else
        {
            userName=uid;
            $("#NewBusinessPredefinedSearch").css("display","none");
            $(".predefined-img-loading").css("display","inline-block");
        }

        var predefinedPolicySearchRequest={};

        predefinedPolicySearchRequest['SearchBy']=searchBy;
        predefinedPolicySearchRequest['sortBy']=sortBy;
        predefinedPolicySearchRequest['UUID']=uuid;
        predefinedPolicySearchRequest['userName']=userName;
        var displayOptionsObj={};
        displayOptionsObj['producers']=displayProducers;
		displayOptionsObj['GABGAFirm']=displayGABGAFirm;
		predefinedPolicySearchRequest['displayOptions']=displayOptionsObj;
        predefinedPolicySearchRequest['userRole']=role;
        predefinedPolicySearchRequest['partyRole']='insured';
        predefinedPolicySearchRequest['appId']='JHI Producer Website';

        if(ssoconId) {
            predefinedPolicySearchRequest['ssoconId']=ssoconId;
        }
        if(fimId) {
        	predefinedPolicySearchRequest['fimId']=fimId;
        }
        if(partnerId) {
        	predefinedPolicySearchRequest['partnerId']=partnerId;
        }

         $.ajax({
		 	type: 'POST',
            headers: { 'Application': 'Business Policy' },
         	url:PolicySearchUrl,
            data: JSON.stringify(predefinedPolicySearchRequest),
            dataType: 'json',
         	success: function(response){

                var buttonId="NewBusinessPredefinedSearch";
                var policySearchStatusCode=response.PolicySearch_response.StatusCode;

                $("#myBusinessForm").hide();
				$("#refineSearch").show();
				$("#PredefinedSearchTable").empty();

				if('newBusinessCaseList' in response.PolicySearch_response){
                   $("#PredefinedSearchDiv").show();

                   	if(Array.isArray(response.PolicySearch_response.newBusinessCaseList))
                    {
                        console.log("Predefined Policy Search JSON Array newBusinessCaseList");
                        policySearchResponseMultiple(response.PolicySearch_response.newBusinessCaseList, sortBy, excelButtonText, pdfButtonText, buttonId,displayProducers,displayGABGAFirm);
                    }
                    else{
                        console.log("Predefined Policy Search JSON Object newBusinessCaseList");
                        policySearchResponseSingle(response.PolicySearch_response.newBusinessCaseList, sortBy, excelButtonText, pdfButtonText, buttonId,displayProducers,displayGABGAFirm);
                     }
                }
                else
                {
                    console.log("Predefined Policy Search no newBusinessCaseList");
                    $("#PredefinedSearchDiv").hide();
                    $("#emptyResponse").show();
                }

                    $(document).on("click",".predefinedGetPolicyResponse", function(e){

                        $(this).addClass("visited");
						$(".predefinedGetPolicy-img-loading").remove();
                        $(this).parent().hide();
                        $(this).parent().after('<img src="/apps/settings/wcm/designs/JHINS/images/ajax-loader.gif" alt="Loading-Image" class="predefinedGetPolicy-img-loading" style="margin-top:10px;margin-left:10px">');
       					$(this).next(".predefinedGetPolicy-img-loading").css("display","inline-block");

       					var emailPolicyNumber = $(this).data('policynumber').toString();
       					emailPolicyNumber = emailPolicyNumber.substring(emailPolicyNumber.length - 4);
           				var emailLastName = $(this).data('insuredlastname');

                    	var predefinedGetPolicyRequest={};
                    	predefinedGetPolicyRequest['policyId']=$(this).data('policyid');
                    	predefinedGetPolicyRequest['userRole']=role;
                    	predefinedGetPolicyRequest['UUID']=uuid;
                    	predefinedGetPolicyRequest['PolNumber']=$(this).data('policynumber');
                    	predefinedGetPolicyRequest['ProductLineCode']=$(this).data('productlinecode');
                    	predefinedGetPolicyRequest['partyRole']='insured';
                        predefinedGetPolicyRequest['FirmID']=$(this).data('firmid');
                        predefinedGetPolicyRequest['userName']=userName;
                        if(fimId) {
        					predefinedGetPolicyRequest['fimId']=fimId;
        				}
                        if(ssoconId) {
            				predefinedGetPolicyRequest['ssoconId']=ssoconId;
        				}

					 $.ajax({
                     type: 'POST',
                     headers: { 'Application': 'Business Policy' },
                     url:GetPolicyUrl,
                     data:JSON.stringify(predefinedGetPolicyRequest),
                     dataType: 'json',
                     success: function(response){

                         $("#PredefinedSearchDiv").hide();
						 $("#refineSearch").hide();

                         var getPolicyStatusCode=response.GetPolicyStatus_response.StatusCode;
                         var buttonId = "predefinedGetPolicyResponse";

							if('insuredDetails' in response.GetPolicyStatus_response)
                            {
                                $("#PredefinedSearchGetPolicyDiv").show();
                                if(Array.isArray(response.GetPolicyStatus_response.insuredDetails))
                                {
                                     console.log("Predefined Get Policy JSON Array newBusinessCaseList");
                                     getPolicyStatusMultiple(response,buttonId,emailPolicyNumber,emailLastName);
                                }
                                else{
                                      console.log("Predefined Get Policy JSON Object newBusinessCaseList");
                                      getPolicyStatusSingle(response, buttonId,emailPolicyNumber,emailLastName);
                               }
                          }

                         	else
                            {
                                console.log("Predefined Policy Search no newBusinessCaseList");
                    	 		$("#PredefinedSearchGetPolicyDiv").hide();
                                $("#refineSearch").show();
                    			$("#emptyResponse").show();
                            }

						},
                         error:function(error)
          					{
                              console.log("Inside Error");
                              $("#myBusinessForm").hide();
							  $("#PredefinedSearchDiv").hide();
                              $("#emailConformation").hide();
               				  $("#refineSearch").show();
               				  $("#noResponse").show();
            		 	},
       				 timeout:setTimeout
                 });

             });

         },
         	error:function(error)
          	{
               console.log("Inside Error");
               $("#myBusinessForm").hide();
               $("#emailConformation").hide();
               $("#refineSearch").show();
               $("#noResponse").show();

             },
        timeout:setTimeout

     }); 
});

     //Predefined Search ends here

     //Extended Search Starts here

		 $(document).on("click","#NewBusinessExtendedSearch", function(e){

		 e.preventDefault();

         var sortBy = $("#customSortBy").val();
         var from= $("#from").val();
         var to= $("#to").val();
         console.log("from"+from);
         console.log("to"+to);
         var policyNumber =$("#policyNum").val();
		 var insuredLName =$("#insuredlname").val();
         var insuredFName =$("#insuredFname").val();
         var faceAmountIdr =$("#faceAmtIdentifier").val();
         var faceAmount =$("#faceAmount").val();
         var plannedPremiumIdr =$("#plannedPmrIdentifier").val();
         var plannedPremium =$("#plannedPremium").val();
		 var moneyReceivedYes=($("#moneyReceivedYes").is(":checked"))?"Yes":"";
		 var moneyReceivedNo=($("#moneyReceivedNo").is(":checked"))?"No":"";
         console.log("moneyReceivedYes"+moneyReceivedYes+" moneyReceivedNo"+moneyReceivedNo);
		 var productType =$("#productType").val();
         var intReplacement=($("#internalReplacement").is(":checked"))?"Internal":"";
         var extReplacement=($("#externalReplacement").is(":checked"))?"External":"";
         var status =$("#status").val() != null ? $("#status").val().toString() : "";
             console.log("status"+status);
         var decisionType =$("#decisionType").val() != null ? $("#decisionType").val().toString() : "";
         var firm =$("#firm").val();
         var producerLName =$("#producerLname").val();
         var producerFName =$("#producerFname").val();
         var userName=$("#customUserName").val();
         var displayProducers=($("#customProducers").is(":checked"))?"Yes":"No";
         var displayGABGAFirm=($("#customGABGAFirm").is(":checked"))?"Yes":"No";

		if(role=="SuperUser_SN")
         {
            if(userName =="" && policyNumber == "")
            {
               alert("User Name or Policy Number are Mandatory for Extended Search");
               e.preventDefault();
			   return false;

            }
             else{

                 $("#NewBusinessExtendedSearch").css("display","none");
         		 $(".custom-img-loading").css("display","inline-block");
             }
         }
         else
         {
        	 userName=uid;
			if(from == "" && to == "" && policyNumber == "" && insuredLName == "" && insuredFName == "" && faceAmountIdr== "" && faceAmount == "" && plannedPremiumIdr== "" && plannedPremium == "" && moneyReceivedYes == "" && moneyReceivedNo == "" && productType == "" && intReplacement == "" && extReplacement == "" && status =="" && decisionType =="" && firm == "" && producerLName == "" && producerFName == "" && displayProducers == "No" && displayGABGAFirm == "No")
            {
                alert("Please enter at least one criteria to perform a custom search.");
                e.preventDefault();
                return false;
            }
            else
            {
                $("#NewBusinessExtendedSearch").css("display","none");
         		$(".custom-img-loading").css("display","inline-block");
             }

         }

        var customPolicySearchRequest={};

        customPolicySearchRequest['sortBy']=sortBy;
        customPolicySearchRequest['UUID']=uuid;
        customPolicySearchRequest['homeOfficeStartDate']=from;
        customPolicySearchRequest['homeOfficeEndDate']=to;
        customPolicySearchRequest['policyNumber']=policyNumber;
        customPolicySearchRequest['insuredLastName']=insuredLName;
        customPolicySearchRequest['insuredFirstName']=insuredFName;
        customPolicySearchRequest['faceAmountIdentifier']=faceAmountIdr;
        customPolicySearchRequest['faceAmount']=faceAmount;
        customPolicySearchRequest['plannedPremiumIDentifier']=plannedPremiumIdr;
        customPolicySearchRequest['plannedPremium']=plannedPremium;
        var moneyReceivedArray=[];
        if(moneyReceivedYes != "" && moneyReceivedNo != ""){
            moneyReceivedArray.push(moneyReceivedYes);
            moneyReceivedArray.push(moneyReceivedNo);
        }
        else if(moneyReceivedYes != ""){
		moneyReceivedArray.push(moneyReceivedYes);
        }
        else if(moneyReceivedNo != ""){
        moneyReceivedArray.push(moneyReceivedNo);
        } 
		customPolicySearchRequest['moneyReceived']=moneyReceivedArray;
        customPolicySearchRequest['productType']=productType;
		var replacementArray=[];
        if(intReplacement != "" && extReplacement != ""){
            replacementArray.push(intReplacement);
            replacementArray.push(extReplacement);
        }
        else if(intReplacement != ""){
		replacementArray.push(intReplacement);
        }
        else if(extReplacement != ""){
        replacementArray.push(extReplacement);
        } 
        customPolicySearchRequest['replacement']=replacementArray;
        var statusValues=status.split(",");
        var statusArray=[];
        for(var i in statusValues)
        {
            console.log("statusValues: "+statusValues[i]);
        	if(statusValues[i] == "IssuedAwaitingRequirements") {
        		statusArray.push("Issued, Awaiting Requirements");
                console.log("inside if");
        	} else {
        		statusArray.push(statusValues[i]);
        	}

        }

        customPolicySearchRequest['status']=statusArray;

        var decisionTypeArray=[];
        var decisionTypeValues=decisionType.split(",");
        for(var i in decisionTypeValues)
        {
        	decisionTypeArray.push(decisionTypeValues[i]);
        	console.log("values: "+decisionTypeValues[i]);
        }
        customPolicySearchRequest['decisionType']=decisionTypeArray;
        customPolicySearchRequest['gaBgaFirm']=firm;
        customPolicySearchRequest['producerFirstName']=producerFName;
        customPolicySearchRequest['producerLastName']=producerLName;
        customPolicySearchRequest['userName']=userName;
        var displayOptionsObj={};
        displayOptionsObj['producers']=displayProducers;
        displayOptionsObj['GABGAFirm']=displayGABGAFirm;
        customPolicySearchRequest['displayOptions']=displayOptionsObj;
        customPolicySearchRequest['userRole']=role;
        customPolicySearchRequest['partyRole']='insured';
        customPolicySearchRequest['appId']='JHI Producer Website';

        if(ssoconId) {
            customPolicySearchRequest['ssoconId']=ssoconId;
        } 
        if(fimId) {
        	customPolicySearchRequest['fimId']=fimId;
        }
        if(partnerId) {
        	customPolicySearchRequest['partnerId']=partnerId;
        }

        console.log("customPolicySearchRequest"+JSON.stringify(customPolicySearchRequest));

        $.ajax({

         type: 'POST',    
         url:PolicySearchUrl,
         headers: { 'Application': 'Business Policy' },
         data: JSON.stringify(customPolicySearchRequest),
         dataType: 'json',
         success: function(response){

				var buttonId="NewBusinessExtendedSearch";
             	var policySearchStatusCode=response.PolicySearch_response.StatusCode;

				$("#myBusinessForm").hide();
				$("#refineSearch").show();
				$("#ExtendedSearchTable").empty();
                window.scrollTo(0,$("#refineSeachButton").offset().top);

             	if('newBusinessCaseList' in response.PolicySearch_response){
                    $("#ExtendedSearchDiv").show();

					if(Array.isArray(response.PolicySearch_response.newBusinessCaseList))
                    {
                        console.log("Extended Policy Search JSON Array newBusinessCaseList");
                        policySearchResponseMultiple(response.PolicySearch_response.newBusinessCaseList, sortBy, excelButtonText, pdfButtonText, buttonId,displayProducers,displayGABGAFirm);
                    }
                    else{
                        console.log("Extended Policy Search JSON Object newBusinessCaseList");
                        policySearchResponseSingle(response.PolicySearch_response.newBusinessCaseList, sortBy, excelButtonText, pdfButtonText, buttonId,displayProducers,displayGABGAFirm);
                     }
                }
             	else
                {
                    console.log("Extended Policy Search no newBusinessCaseList");
                    $("#ExtendedSearchDiv").hide();
                    $("#emptyResponse").show();
                }

            	 $(document).on("click",".extendedGetPolicyResponse", function(e){

                    $(this).addClass("visited");
					$(".customGetPolicy-img-loading").remove();
                    $(this).parent().hide();
                    $(this).parent().after('<img src="/apps/settings/wcm/designs/JHINS/images/ajax-loader.gif" alt="Loading-Image" class="customGetPolicy-img-loading" style="margin-top:10px;margin-left:10px">');
       				$(this).next(".customGetPolicy-img-loading").css("display","inline-block");

       				var emailPolicyNumber = $(this).data('policynumber').toString();
       				emailPolicyNumber = emailPolicyNumber.substring(emailPolicyNumber.length - 4);
       				var emailLastName = $(this).data('insuredlastname');
       				
                    var customGetPolicyRequest={};
                    customGetPolicyRequest['policyId']=$(this).data('policyid');
                    customGetPolicyRequest['userRole']=role;
                    customGetPolicyRequest['UUID']=uuid;
                    customGetPolicyRequest['PolNumber']=$(this).data('policynumber');
                    customGetPolicyRequest['ProductLineCode']=$(this).data('productlinecode');
                    customGetPolicyRequest['partyRole']='insured';
                    customGetPolicyRequest['FirmID']=$(this).data('firmid');
                    customGetPolicyRequest['userName']=userName;
                    if(fimId) {
        				customGetPolicyRequest['fimId']=fimId;
        			}
                    if(ssoconId) {
            			customGetPolicyRequest['ssoconId']=ssoconId;
        			}

                     $.ajax({
                     type: 'POST',
                     headers: { 'Application': 'Business Policy' },
                     url:GetPolicyUrl,
                     data: JSON.stringify(customGetPolicyRequest),
                     dataType: 'json',
                     success: function(response){

				    	$("#ExtendedSearchDiv").hide();
                    	$("#refineSearch").hide();

                         var getPolicyStatusCode=response.GetPolicyStatus_response.StatusCode;
                         var buttonId = "extendedGetPolicyResponse";

                         if('insuredDetails' in response.GetPolicyStatus_response)
                         {
                    	 	$("#ExtendedSearchGetPolicyDiv").show();

                                if(Array.isArray(response.GetPolicyStatus_response.insuredDetails))
                                {
                                     console.log("Extended Get Policy JSON Array newBusinessCaseList");
                                     getPolicyStatusMultiple(response, buttonId,emailPolicyNumber,emailLastName);
                                }
                                else{
                                      console.log("Extended Get Policy JSON Array newBusinessCaseList");
                                      getPolicyStatusSingle(response,buttonId,emailPolicyNumber,emailLastName);
                                }

                          }
                          else
                            {
                                console.log("Extended Policy Search no newBusinessCaseList");
                    	 		$("#ExtendedSearchGetPolicyDiv").hide();
                                $("#refineSearch").show();
                    			$("#emptyResponse").show();
                            }

						},
                         	error:function(error)
                         	{

							  console.log("Inside Error");
                              $("#myBusinessForm").hide();
                              $("#ExtendedSearchDiv").hide();
                              $("#emailConformation").hide();
               				  $("#refineSearch").show();
               				  $("#noResponse").show();
                              window.scrollTo(0,$("#refineSeachButton").offset().top);
                          },
            				timeout:setTimeout
					  });

               });
			},
            error:function(error)
            {
                console.log("Inside Error");
                $("#myBusinessForm").hide();
                $("#emailConformation").hide();
               	$("#refineSearch").show();
               	$("#noResponse").show();
                window.scrollTo(0,$("#refineSeachButton").offset().top);

           },
               timeout:setTimeout
 		});
    });

     //Extended Search ends here


});
