function isNumeric(e){

     // Allow: backspace, delete, tab, escape, enter and .
    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
      // Allow: Ctrl+A,Ctrl+C,Ctrl+V, Command+A
      ((e.keyCode == 65 || e.keyCode == 86 || e.keyCode == 67 || e.keyCode == 88) && (e.ctrlKey === true || e.metaKey === true)) ||
      // Allow: home, end, left, right, down, up
      (e.keyCode >= 35 && e.keyCode <= 40) || 
      (e.keyCode >= 96 && e.keyCode <= 105)) {
      // let it happen, don't do anything
      return; 
    }

    if(e.keyCode)
	var charCode = (e.which) ? e.which : e.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;

}	

function validateEmail()
{
   var emailId=$("#emailYourEmail").val();
     console.log("email"+emailId);
      var email = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      if(emailId.match(email))  
      {  
          console.log("inside true");
          $("#emailYourEmail").css("border-color","currentColor");


      }  
      else  
      {  
		$("#emailYourEmail").css("border-color","red");


      }  
    return true;
}
function validateLength(elem){
	if (elem.value.length<8)
	{
		elem.value="";
		elem.style.borderColor = "red";
		elem.title = "Policy number should be minimum 8 digits";
		elem.setCustomValidity('Policy number should be minimum 8 digits'); 
	}
	else
	{
		elem.style.borderColor = "initial";
		elem.title = "";
		elem.setCustomValidity('');
	}
}
function validateEmpty(elem){
	if (elem.value.length==0)
	{
		elem.style.borderColor = "red";
		elem.title = 'Please fill out this field';
		elem.setCustomValidity('Please fill out this field'); 
	}
	else
	{
		elem.style.borderColor = "initial";
		elem.title = "";
		elem.setCustomValidity('');
	}
}