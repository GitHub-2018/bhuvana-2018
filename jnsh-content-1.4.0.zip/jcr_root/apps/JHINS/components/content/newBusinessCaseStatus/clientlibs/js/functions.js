/*function predefinedChangeId()
{
    console.log("inside change id");

    $("#emailCancel").removeAttr("predefinedEmailCancel");
    $("#emailCancel").removeAttr("extendedEmailCancel");
    $("#emailCancel").attr("data-emailcancel","predefinedEmailCancel");

    $("#BackToCaseDetails").removeAttr("predefinedBackToCaseDetails");
    $("#BackToCaseDetails").removeAttr("extendedBackToCaseDetails");
    $("#BackToCaseDetails").attr("data-backtocasedetails","predefinedBackToCaseDetails");

    $("#BackToSearchResults").removeAttr("predefinedBackToSearchResults");
    $("#BackToSearchResults").removeAttr("extendedBackToSearchResults");
    $("#BackToSearchResults").attr("data-backtosearchresults","predefinedBackToSearchResults");

    $("#emailFunctionality").show();
    $("#emailConformation").hide();
}

function extendedChangeId()
{
	$("#emailCancel").removeAttr("predefinedEmailCancel");
    $("#emailCancel").removeAttr("extendedEmailCancel");
    $("#emailCancel").attr("data-emailcancel","extendedEmailCancel");

    $("#BackToCaseDetails").removeAttr("predefinedBackToCaseDetails");
    $("#BackToCaseDetails").removeAttr("extendedBackToCaseDetails");
    $("#BackToCaseDetails").attr("data-backtocasedetails","extendedBackToCaseDetails");

    $("#BackToSearchResults").removeAttr("predefinedBackToSearchResults");
    $("#BackToSearchResults").removeAttr("extendedBackToSearchResults");
    $("#BackToSearchResults").attr("data-backtosearchresults","extendedBackToSearchResults");

    $("#emailFunctionality").show();
    $("#emailConformation").hide();
}

$(document).on("click","#predefinedCaseManager", function(){

    $("#PredefinedSearchGetPolicyDiv").hide();
	$("#emailPolicyNumber").empty(); $("#emailAddress").empty(); $("#emailInsuredName").empty();

    $("#emailPolicyNumber").text($("#predefinedUnderWriter").data("emailpolicynumber"));
    $("#emailAddress").text($("#predefinedCaseManager").data("emailaddress"));
	$("#emailInsuredName").text($("#predefinedCaseManager").data("emailinsuredname"));

    predefinedChangeId();

    });
$(document).on("click","#predefinedUnderWriter", function(){

    $("#PredefinedSearchGetPolicyDiv").hide();
	$("#emailPolicyNumber").empty(); $("#emailAddress").empty(); $("#emailInsuredName").empty();

    $("#emailPolicyNumber").text($("#predefinedUnderWriter").data("emailpolicynumber"));
    $("#emailAddress").text($("#predefinedUnderWriter").data("emailaddress"));
    $("#emailInsuredName").text($("#predefinedUnderWriter").data("emailinsuredname"));

    predefinedChangeId();
});
$(document).on("click","#customCaseManager", function(){

    $("#ExtendedSearchGetPolicyDiv").hide();
    $("#emailPolicyNumber").empty(); $("#emailAddress").empty(); $("#emailInsuredName").empty();

    $("#emailPolicyNumber").text($("#customCaseManager").data("emailpolicynumber"));
    $("#emailAddress").text($("#customCaseManager").data("emailaddress"));
    $("#emailInsuredName").text($("#customCaseManager").data("emailinsuredname"));

    extendedChangeId();

    });
$(document).on("click","#customUnderWriter", function(){

    $("#ExtendedSearchGetPolicyDiv").hide();
    $("#emailPolicyNumber").empty(); $("#emailAddress").empty(); $("#emailInsuredName").empty();

    $("#emailPolicyNumber").text($("#customUnderWriter").data("emailpolicynumber"));
    $("#emailAddress").text($("#customUnderWriter").data("emailaddress"));
    $("#emailInsuredName").text($("#customUnderWriter").data("emailinsuredname"));

    extendedChangeId();

    });
$(document).on('click','#emailSubmit', function(e){
    e.preventDefault();

    var yourName = $("#emailYourName").val();
    var yourEmail = $("#emailYourEmail").val();
    var firstThreeDigits = $("#firstThreeDigits").val();
    var nextThreeDigits = $("#nextThreeDigits").val();
    var lastFourDigits = $("#lastFourDigits").val();
    var extension = $("#extension").val();
    var comments = $("#emailComments").val();
	if(yourName == "" || yourEmail == "" || firstThreeDigits == "" || nextThreeDigits == "" || lastFourDigits == "" || extension == "" || comments == "")
    {
		alert("Please enter all mandatory fields to send an email");
		return false;
    }

    $("#emailFunctionality").hide();
    $("#emailConformation").show();

    $("#confirmSendTo").text($("#emailAddress").text());
    $("#confirmCc").text($("#emailCc").val());
    $("#confirmYourName").text(yourName);
    $("#confirmYourEmail").text(yourEmail);
    $("#confirmYourPhone").text(extension+" "+firstThreeDigits+"-"+nextThreeDigits+"-"+lastFourDigits);
    $("#confirmInsuredName").text($("#emailInsuredName").text());
    $("#confirmPolicyNumber").text($("#emailPolicyNumber").text());
    $("#confirmComments").text(comments);
    window.scrollTo(0,$("#emailConformation").offset().top);

    });
 $(document).on('click','#emailClear', function(e) {
     e.preventDefault();
     $("#emailFunctionalityForm")[0].reset();
    });

$(document).on('click','#emailCancel', function(e){
	e.preventDefault();
    if(($("#emailCancel").attr("data-emailcancel")) == "predefinedEmailCancel")
    {
        $("#emailFunctionality").hide();
    	$("#PredefinedSearchGetPolicyDiv").show();
    	window.scrollTo(0,$("#PredefinedGetPolicyBack").offset().top);
    }
    else
    {
        $("#emailFunctionality").hide();
    	$("#ExtendedSearchGetPolicyDiv").show();
    	window.scrollTo(0,$("#ExtendedGetPolicyBack").offset().top);
    }

    });

$(document).on('click','#BackToCaseDetails', function(e){
	e.preventDefault();
    if(($("#BackToCaseDetails").attr("data-backtocasedetails")) == "predefinedBackToCaseDetails")
    {
		$("#emailConformation").hide();
    	$("#PredefinedSearchGetPolicyDiv").show();
    	window.scrollTo(0,$("#PredefinedGetPolicyBack").offset().top);
    }
    else
    {
        $("#emailConformation").hide();
    	$("#ExtendedSearchGetPolicyDiv").show();
    	window.scrollTo(0,$("#ExtendedGetPolicyBack").offset().top);
    }

    });

$(document).on('click','#BackToSearchResults', function(e){
	e.preventDefault();

	if(($("#BackToSearchResults").attr("data-backtosearchresults")) == "predefinedBackToSearchResults")
    {
    	$("#emailConformation").hide();
    	$("#PredefinedSearchDiv").show();
    	$("#refineSearch").show();
    	$(".predefinedGetPolicy-img-loading").remove();
    	$(".predefinedGetPolicyResponse").parent().show();
    	window.scrollTo(0,$("#refineSeachButton").offset().top);
    }
    else
    {
    	$("#emailConformation").hide();
    	$("#ExtendedSearchDiv").show();
    	$("#refineSearch").show();
    	$(".customGetPolicy-img-loading").remove();
    	$(".extendedGetPolicyResponse").parent().show();
    	window.scrollTo(0,$("#refineSeachButton").offset().top);
    }

    });
*/
$(document).on('click','#underWriter', function(e){
    var underWriterEmail = $("#underWriter").data("emailaddress");
    var subjectEmail = $("#underWriter").data("subjectline");
    $("#myModal a#mailTo").attr("href","mailto:"+underWriterEmail+"?subject="+subjectEmail);
    var caseManagerEmail = $("#caseManager").data("emailaddress");
    if(null!=caseManagerEmail)
    {
    console.log("emailAddress"+underWriterEmail+" "+caseManagerEmail);
    $("#myModal a#mailTo").attr("href","mailto:"+underWriterEmail+"?subject="+subjectEmail+"&cc="+caseManagerEmail);
    }
});

$(document).on('click','#caseManager', function(e){
    var emailAddress = $("#caseManager").data("emailaddress");
    var subjectEmail = $("#caseManager").data("subjectline");
    console.log("emailAddress"+emailAddress);
    $("#myModal a#mailTo").attr("href","mailto:"+emailAddress+"?subject="+subjectEmail);
});

$(document).on('click','.closePopup', function(e){
    console.log("inside close");
$("#myModal").modal('hide');
});

function clearGetPolicyID(){
    $("div[id^='PredefinedGetPolicyInsuredDetails']").each(function(){
       		var divId = $(this).attr("id");
       		$("#"+divId).empty();
     	})
    	$("div[id^='PredefinedGetPolicyDetails']").each(function(){
       		var divId = $(this).attr("id");
	   		$("#"+divId).empty();
    	})
        $("div[id^='ExtendedGetPolicyInsuredDetails']").each(function(){
       		var divId = $(this).attr("id");
       		$("#"+divId).empty();
     		})
    	$("div[id^='ExtendedGetPolicyDetails']").each(function(){
       		var divId = $(this).attr("id");
	   		$("#"+divId).empty();
    	})
}

function policySearchResponseSingle(policySearch, sortBy, excelButtonText, pdfButtonText, buttonId,displayProducers,displayGABGAFirm)
{

	var policySearchArray = [];
	policySearchArray.push(policySearch);
    console.log("policySearchArray"+policySearchArray);

    console.log("submit button id: "+buttonId);
    if(buttonId=="NewBusinessPredefinedSearch")
    {
        var tableId = "PredefinedSearchTable";
        var getpolicyId = "predefinedGetPolicyResponse";
    }
    else{
        var tableId = "ExtendedSearchTable";
        var getpolicyId = "extendedGetPolicyResponse";
    }
/* To display producers and GABGAFirm based on checkbox selection */

    var visibleProducers= false;
    if(displayProducers != "No")
    {
   		visibleProducers = true;
    }

    var visibleGABGAFirm= false;
    if(displayGABGAFirm != "No")
    {
       visibleGABGAFirm = true;
    }

    $("#"+tableId).DataTable({
        			dom: '<B<"top"<"pull-left"<"refinesearch">>p><"clear">rt<"bottom"<"pull-left"<"refinesearch">>p>>',
                	data: policySearchArray,
                	buttons: [
                    	{
                        	extend:'excel',
                        	title:'New Business Case Status',
                        	text:excelButtonText
                    	},
                    	{
                        	extend:'pdf',
                        	title:'New Business Case Status',
                        	text:pdfButtonText,
                        	orientation:'landscape',
                        	pageSize:'A4'
                    	}

        			], 
					order: [[ sortBy, 'desc' ]],
                	destroy:true,
                	columns: [
                    	{ 	title: "Home Office SetUp Date", data: "homeOfficeSetupDate" },
                    	{ 	title: "Policy Number" , data: "policyNumber"},
                    	{ 	title: "Insured" , 
                        	data: "insured", 
                        	render: function(data,type,row,meta) { 
                                var a = '<a href="javascript:void(0);" data-policynumber="'+row.policyNumber+'" data-policyid="'+row.policyId+'" data-insuredLastName="'+row.insuredLastName+'" data-productlinecode="'+row.ProductLineCode+'" data-firmid="'+row.FirmID+'" class="'+getpolicyId+'">' + row.insuredLastName +'</a>,<br/>'+row.insuredFirstName; 

                                    return a;
                                }

                    	},
                    		{ title: "Face Amount" , data: "faceAmount"},
                    		{ title: "Money Received" , data: "moneyReceived"},
                    		{ title: "Planned Premium" , data: "plannedPremium"},
                    		{ title: "Product" , data: "product"},
                    		{ title: "Replacement" , data: "replacement"},
                    		{ title: "Status" , data: "Status"},
                    		{ title: "Decision Type" , data: "decisionType"},
                    		{ title: "Sales Premium Date" , data: "salesPremiumDate"},
                        	{ title: "Producers", data: "Producer[, ]", visible:visibleProducers,
								render: function(data,type,row,meta) {
									var response=data.toString();
                                    var res =response.replace(/,\s*$/, "");
									return res;
					             }
                            },
                        	{ title: "GABGAFirm", data: "BABGAFIRM[, ]", visible:visibleGABGAFirm,
								render: function(data,type,row,meta) {
									var response=data.toString();
                                    var res =response.replace(/,\s*$/, "");
									return res;
					             }
                            }

                    	],

						searching: false,
                        paging:false,
						pageLength: 10,
						bLengthChange: false


    			});
}


function policySearchResponseMultiple(policySearch, sortBy, excelButtonText, pdfButtonText, buttonId,displayProducers,displayGABGAFirm)
{


    if(buttonId=="NewBusinessPredefinedSearch")
    {
        var tableId = "PredefinedSearchTable";
        var getpolicyId = "predefinedGetPolicyResponse";
    }
    else{
        var tableId = "ExtendedSearchTable";
        var getpolicyId = "extendedGetPolicyResponse";
    }

/* To display pagination if results are more than 20 per page */

	var arraylength = policySearch.length;
    var pagination = false;
    if(arraylength >=20)
    {
		pagination =true ;
    }

    /* To display producers and GABGAFirm based on checkbox selection */

    var visibleProducers= false;
    if(displayProducers != "No")
    {
   		visibleProducers = true;
    }

    var visibleGABGAFirm= false;
    if(displayGABGAFirm != "No")
    {
       visibleGABGAFirm = true;
    }

    var dataTable = $("#"+tableId).DataTable({
        			dom: '<B<"top"<"pull-left"<"refinesearch">>p><"clear">rt<"bottom"<"pull-left"<"refinesearch">>p>>',
                	data: policySearch,
                	buttons: [
                    	{
                        	extend:'excel',
                        	title:'New Business Case Status',
                        	text:excelButtonText
                    	},
                    	{
                        	extend:'pdf',
                        	title:'New Business Case Status',
                        	text:pdfButtonText,
                        	orientation:'landscape',
                        	pageSize:'A4'
                    	}

        			], 
					order: [[ sortBy, 'desc' ]],
                	destroy:true,
                	columns: [
                    	{ 	title: "Home Office SetUp Date", data: "homeOfficeSetupDate" },
                    	{ 	title: "Policy Number" , data: "policyNumber"},
                    	{ 	title: "Insured" , 
                        	data: "insured", 
                        	render: function(data,type,row,meta) { 
                            	var a = '<a href="javascript:void(0);" data-policynumber="'+row.policyNumber+'" data-policyid="'+row.policyId+'" data-insuredLastName="'+row.insuredLastName+'" data-productlinecode="'+row.ProductLineCode+'" data-firmid="'+row.FirmID+'" class="'+getpolicyId+'">' + row.insuredLastName +'</a>,<br/>'+row.insuredFirstName; 

                                    return a;
                                }
                    	},
                    		{ title: "Face Amount" , data: "faceAmount"},
                    		{ title: "Money Received" , data: "moneyReceived"},
                    		{ title: "Planned Premium" , data: "plannedPremium"},
                    		{ title: "Product" , data: "product"},
                    		{ title: "Replacement" , data: "replacement"},
                    		{ title: "Status" , data: "Status"},
                    		{ title: "Decision Type" , data: "decisionType"},
                    		{ title: "Sales Premium Date" , data: "salesPremiumDate"},
                        	{ title: "Producers", data: "Producer[, ]", visible:visibleProducers,
								render: function(data,type,row,meta) {
									var response=data.toString();
                                    var res =response.replace(/,\s*$/, "");
									return res;
					             }
                            },
                        	{ title: "GABGAFirm", data:"BABGAFIRM[, ]", visible:visibleGABGAFirm,
								render: function(data,type,row,meta) {
									var response=data.toString();
                                    var res =response.replace(/,\s*$/, "");
									return res;
					             }
                            }
                    	],

						searching: false,
                        paging:pagination,
						pageLength: 20,
						bLengthChange: false

    			});
}



function getPolicyStatusSingle(response, buttonId,emailPolicyNumber,emailLastName){

   if(buttonId== "predefinedGetPolicyResponse")

     {
         window.scrollTo(0,$("#PredefinedGetPolicyBack").offset().top);
         var userDetailsId = "PredefinedGetPolicyDetails";
         var insuredDetailsId = "PredefinedGetPolicyInsuredDetails";
         var requirementsTableId = "PredefinedGetPolicyTable";
         var outerDivision = "PredefinedSearchGetPolicyDiv";
         var underWriterId="predefinedUnderWriter";
         var caseManagerId="predefinedCaseManager";
     }
     else
     {
         window.scrollTo(0,$("#ExtendedGetPolicyBack").offset().top);
         var userDetailsId = "ExtendedGetPolicyDetails";
         var insuredDetailsId = "ExtendedGetPolicyInsuredDetails";
         var requirementsTableId = "ExtendedGetPolicyTable";
         var outerDivision = "ExtendedSearchGetPolicyDiv";
         var underWriterId="customUnderWriter";
         var caseManagerId="customCaseManager";  

     }

        console.log("inside code 0 and JSON object");
        var i=1;
        $("#"+userDetailsId).empty();
		$("#"+insuredDetailsId).empty();

        clearGetPolicyID();

        var divison=document.createElement('div');
	    divison.id= userDetailsId ;
		$("#"+outerDivision).append(divison);

        var userDetailsArray = [];
		$("p[id^='userDetails']").each(function(index, key){
        userDetailsArray.push($(key).attr("value"));
		});

        $.each(response.GetPolicyStatus_response,function(key,value){

		if(key != "insuredDetails" && key != "StatusCode" && key!= "StatusDesc"){            

            if(-1 != userDetailsArray.indexOf(key)){
                if(value == null){

                    value="";
                }
                if(key=="underWriter" && null!= (response.GetPolicyStatus_response.underWriterEmailAddress)) {
                    $("#"+userDetailsId).append("<div class='row'><div class='col-xs-3'>"+$("p[value='"+key+"']").html()+ ":</div><div class='col-xs-9'>" +("<a data-toggle='modal' data-target='#myModal' id='underWriter' data-emailaddress='"+response.GetPolicyStatus_response.underWriterEmailAddress+"' data-subjectLine='"+emailLastName+" - XXXX"+emailPolicyNumber+"' data-emailpolicynumber='"+response.GetPolicyStatus_response.policyNumber+"' data-emailinsuredname='"+response.GetPolicyStatus_response.insuredDetails.insured+"'>"+value+"</a>")+"</div></div>");
                }
                else if(key == "caseManager" && null!= (response.GetPolicyStatus_response.caseManagerEmailAddress)) {
                    $("#"+userDetailsId).append("<div class='row'><div class='col-xs-3'>"+$("p[value='"+key+"']").html()+ ":</div><div class='col-xs-9'>" +("<a data-toggle='modal' data-target='#myModal' id='caseManager' data-emailaddress='"+response.GetPolicyStatus_response.caseManagerEmailAddress+"' data-subjectLine='"+emailLastName+" - XXXX"+emailPolicyNumber+"' data-emailpolicynumber='"+response.GetPolicyStatus_response.policyNumber+"' data-emailinsuredname='"+response.GetPolicyStatus_response.insuredDetails.insured+"'>"+value+"</a>")+"</div></div>");
                }
                else {
                	$("#"+userDetailsId).append("<div class='row'><div class='col-xs-3'>"+$("p[value='"+key+"']").html()+ ":</div><div class='col-xs-9'>"  +value+"</div></div>");
                }
       		}
         i++;
       }
        else{
        i=1;
        }
	});
		var j=1;
        var divison=document.createElement('div');
		divison.id=insuredDetailsId;
		$("#"+outerDivision).append(divison);

		$("#"+insuredDetailsId).append("<div class='row'><div class='col-xs-12'><h4>Requirements - Insured </h4></div></div>");
		$.each(response.GetPolicyStatus_response.insuredDetails,function(key,value){

        if(key != "requirements" && key != "sequence"){
			$("#"+insuredDetailsId).append("<div class='row'><div class='col-xs-2'>"+document.getElementById("insuredDetails"+(j)).innerHTML+" : </div><div class='col-xs-10'>"+value+"</div></div>");
            j++;
        }
        else
        {
          j=1;
        }
	});
		$.each(response.GetPolicyStatus_response.insuredDetails,function(key,value){
        var data;
        var dataArray = [];

        if(key=="requirements"){

        if(Array.isArray(response.GetPolicyStatus_response.insuredDetails.requirements)){
           console.log("requirements array");
           data= response.GetPolicyStatus_response.insuredDetails.requirements;
        }
        else{
            console.log("requirements object");
           dataArray.push(response.GetPolicyStatus_response.insuredDetails.requirements);
           data = dataArray;
        }

		var predefinedTable=document.createElement('table');
		predefinedTable.id=requirementsTableId;
		predefinedTable.className+=" getPolicyCustomDataTable";

		$("#"+insuredDetailsId).append(predefinedTable);

        var t= $("#"+requirementsTableId).DataTable({
        data: data,
        destroy:true,
        columns: [
            { title: "Status", data: "status", className:"statusField"},
        	{ title: "Received" , data: "received", className:"receivedField"},
        	{ title: "Reviewed" , data: "reviewed", className:"reviewedField"},
            { title: "Requirement" , className:"requirementField", data: null, "render": function ( data, type, row, meta ) {
                return ((null != data.requirementName) ? data.requirementName:"")+ "<br/><b>" + ((null != data.requirementDesc) ? data.requirementDesc:"")+"</b>";
    			}
			}],
        searching: false,
        bLengthChange: false,
        paging:false
   	});
}
});

       // Hide table heading border bottom 
		if(buttonId == "predefinedGetPolicyResponse")
        {
        $("table[id^='PredefinedGetPolicyTable']").each(function(){
        var tableId = $(this).attr("id");
        $("#"+tableId).css({"border-bottom":"none","background":"none"});
        $("#"+tableId+" th").css({"border-bottom":"none","background":"none"});
        var idToPass = "#"+tableId+"+div[id^='PredefinedGetPolicyTable_info']";
        var divId = $(idToPass).attr("id");
        $("#"+divId).css("display","none");
		});
       }
	else{
		$("table[id^='ExtendedGetPolicyTable']").each(function(){
        var tableId = $(this).attr("id");
        $("#"+tableId).css({"border-bottom":"none","background":"none"});
        $("#"+tableId+" th").css({"border-bottom":"none","background":"none"});
        var idToPass = "#"+tableId+"+div[id^='ExtendedGetPolicyTable_info']";
        var divId = $(idToPass).attr("id");
        $("#"+divId).css("display","none");
		})
		}

}

function getPolicyStatusMultiple(response, buttonId,emailPolicyNumber,emailLastName)
{
    if(buttonId== "predefinedGetPolicyResponse")
     {
         window.scrollTo(0,$("#PredefinedGetPolicyBack").offset().top);
         var userDetailsId = "PredefinedGetPolicyDetails";
         var insuredDetailsId = "PredefinedGetPolicyInsuredDetails";
         var requirementsTableId = "PredefinedGetPolicyTable";
         var outerDivision = "PredefinedSearchGetPolicyDiv";
         var underWriterId="predefinedUnderWriter";
         var caseManagerId="predefinedCaseManager";
     }
     else
     {
         window.scrollTo(0,$("#ExtendedGetPolicyBack").offset().top);
         var userDetailsId = "ExtendedGetPolicyDetails";
         var insuredDetailsId = "ExtendedGetPolicyInsuredDetails";
         var requirementsTableId = "ExtendedGetPolicyTable";
         var outerDivision = "ExtendedSearchGetPolicyDiv";
         var underWriterId="customUnderWriter";
         var caseManagerId="customCaseManager"; 

     }

    clearGetPolicyID();

    var i=1;
    var divison=document.createElement('div');
	divison.id=userDetailsId;
	$("#"+outerDivision).append(divison);

	var userDetailsArray = [];
	$("p[id^='userDetails']").each(function(index, key){
    userDetailsArray.push($(key).attr("value"));
	});

    $.each(response.GetPolicyStatus_response,function(key,value){
		if(key != "insuredDetails" && key != "StatusCode" && key!= "StatusDesc"){
            if(-1 != userDetailsArray.indexOf(key)){
                 if(value == null){ value="";}
                 if(key=="underWriter" && null!= (response.GetPolicyStatus_response.underWriterEmailAddress)) {

                     $("#"+userDetailsId).append("<div class='row'><div class='col-xs-3'>"+$("p[value='"+key+"']").html()+ " : </div><div class='col-xs-9'>" +("<a data-toggle='modal' data-target='#myModal' id='underWriter' data-emailaddress='"+response.GetPolicyStatus_response.underWriterEmailAddress+"' data-subjectLine='"+emailLastName+" - XXXX"+emailPolicyNumber+"' data-emailpolicynumber='"+response.GetPolicyStatus_response.policyNumber+"' data-emailinsuredname='"+response.GetPolicyStatus_response.insuredDetails[0].insured+"'>"+value+"</a>")+"</div></div>");
                 }
                 else if(key == "caseManager" && null!= (response.GetPolicyStatus_response.caseManagerEmailAddress)) {

					$("#"+userDetailsId).append("<div class='row'><div class='col-xs-3'>"+$("p[value='"+key+"']").html()+ " : </div><div class='col-xs-9'>" +("<a data-toggle='modal' data-target='#myModal' id='caseManager' data-emailaddress='"+response.GetPolicyStatus_response.caseManagerEmailAddress+"' data-subjectLine='"+emailLastName+" - XXXX"+emailPolicyNumber+"' data-emailpolicynumber='"+response.GetPolicyStatus_response.policyNumber+"' data-emailinsuredname='"+response.GetPolicyStatus_response.insuredDetails[0].insured+"'>"+value+"</a>")+"</div></div>");

                 }
                 else {
                	 $("#"+userDetailsId).append("<div class='row'><div class='col-xs-3'>"+$("p[value='"+key+"']").html()+ " : </div><div class='col-xs-9'>"  +value+"</div></div>");
                 }
       	 }
			i++;
    	}
        else{
        i=1;
        }
	});

      var length= Object.keys(response.GetPolicyStatus_response.insuredDetails).length;
      console.log("length"+length);
      for(var i=0;i<length;i++)
      	{

			var divison=document.createElement('div');
			divison.id=insuredDetailsId+(i+1);
			$("#"+outerDivision).append(divison);
			var j=1;
			$("#"+insuredDetailsId+(i+1)).append("<div class='row'><div class='col-xs-12'><h4>Requirements - Insured "+(i+1)+"</h4></div></div>");
			$.each(response.GetPolicyStatus_response.insuredDetails[i],function(key,value){

            if(key != "requirements" && key != "sequence"){

				$("#"+insuredDetailsId+(i+1)).append("<div class='row'><div class='col-xs-2'>"+document.getElementById("insuredDetails"+(j)).innerHTML+" : </div><div class='col-xs-10'>"+value+"</div></div>");
				j++;
            }
            else
           {
               j=1;
           }
		});
            $.each(response.GetPolicyStatus_response.insuredDetails[i],function(key,value){
 			if(key=="requirements"){
			var predefinedTable=document.createElement('table');
			predefinedTable.id=requirementsTableId+(i+1);
            predefinedTable.className+=" getPolicyCustomDataTable";

			$("#"+insuredDetailsId+(i+1)).append(predefinedTable);

            $("#"+requirementsTableId+(i+1)).DataTable({
            	data: response.GetPolicyStatus_response.insuredDetails[i].requirements,
            	destroy:true,
            	columns: [
                    { title: "Status", data: "status", className: "statusField"},
            		{ title: "Received" , data: "received", className: "receivedField"},
            		{ title: "Reviewed" , data: "reviewed", className: "reviewedField"},
                    { title: "Requirement" , className:"requirementField", data: null, "render": function ( data, type, row, meta ) {
                		return ((null != data.requirementName) ? data.requirementName:"")+ "<br/><b>" + ((null != data.requirementDesc) ? data.requirementDesc:"")+"</b>";
    					}
                    }],
                    searching: false,
                	bLengthChange: false,
                   	paging:false
            	});
				}
    		});
		}				 
     if(buttonId== "predefinedGetPolicyResponse")
     {
        $("table[id^='PredefinedGetPolicyTable']").each(function(){
        var tableId = $(this).attr("id");
       	$("#"+tableId).css({"border-bottom":"none","background":"none"});
        $("#"+tableId+" th").css({"border-bottom":"none","background":"none"});
        var idToPass = "#"+tableId+"+div[id^='PredefinedGetPolicyTable']";
        var divId = $(idToPass).attr("id");
        $("#"+divId).css("display","none");
		})
      }
      else
      {
        $("table[id^='ExtendedGetPolicyTable']").each(function(){
        var tableId = $(this).attr("id");
        $("#"+tableId).css({"border-bottom":"none","background":"none"});
        $("#"+tableId+" th").css({"border-bottom":"none","background":"none"});
        var idToPass = "#"+tableId+"+div[id^='ExtendedGetPolicyTable']";
        var divId = $(idToPass).attr("id");
        $("#"+divId).css("display","none");
		})
     }
}

