$(document).ready(function() {
	
	var dataJson = {
	  "userAuthName": "user",
	  "userAuthType": "super",
	  "newBusinessCaseList": [
		{
		  "homeOfficeSetupDate": "Mon DD,YYYY",
		  "policyNumber": "## ### ###",
		  "insured": "Last Name, First Name",
		  "insuredHyperLinkToken": "000000",
		  "faceAmount": "$X,XXX,XXX",
		  "plannedPremium": "$X,XXX,XXX",
		  "product": "Product",
		  "Status": "status",
		  "decisionType": "Decision",
		  "salesPremiumDate": "MM/DD/YYYY"
		},

		{
		  "homeOfficeSetupDate": "Mon DD,YYYY",
		  "policyNumber": "## ### ###",
		  "insured": "Last Name, First Name",
		  "insuredHyperLinkToken": "000000",
		  "faceAmount": "$X,XXX,XXX",
		  "plannedPremium": "$X,XXX,XXX",
		  "product": "Product",
		  "Status": "status",
		  "decisionType": "Decision",
		  "salesPremiumDate": "MM/DD/YYYY"
		},
		
		{
		  "homeOfficeSetupDate": "Mon DD,YYYY",
		  "policyNumber": "## ### ###",
		  "insured": "Last Name, First Name",
		  "insuredHyperLinkToken": "000000",
		  "faceAmount": "$X,XXX,XXX",
		  "plannedPremium": "$X,XXX,XXX",
		  "product": "Product",
		  "Status": "status",
		  "decisionType": "Decision",
		  "salesPremiumDate": "MM/DD/YYYY"
		}
	  ]
	};
	
	$("table th").addClass(".headerSortUp");

	table  = $('#dataTable').DataTable({
        sDom: '<"top"<"pull-left"<"refinesearch">>p><"clear">rt<"bottom"<"pull-left"<"refinesearch">>p>',
		data: dataJson.newBusinessCaseList,
		//ajax: {  url: "../php/join.php",    type: 'POST' }, //this section will be used for actual data fetching
        columns: [
            { 	title: "Home Office SetUp Date", data: "homeOfficeSetupDate" },
            { 	title: "Policy Number" , data: "policyNumber"},
            { 	title: "Insured" , 
				data: "insured", 
				render: function(data,type,row,meta) { 
                            var a = '<a onclick="gotoPage3('+meta.row+')">' + row.insured +'</a>'; // row object contains the row data
                            return a;
                        }
			},
            { title: "Face Amount" , data: "faceAmount"},
            { title: "Planned Premium" , data: "plannedPremium"},
            { title: "Product" , data: "product"},
			{ title: "Status" , data: "Status"},
			{ title: "Decision Type" , data: "decisionType"},
			{ title: "Sales Premium Date" , data: "salesPremiumDate"}
        ],
		searching: false,
		pageLength: 1,
		bLengthChange: false
    });
	
	$( ".refinesearch" ).html('<input type="button" value="Refine Search" class="btn btn-secondary btn-sm	" style="margin: 10px 10px 10px 10px;">');
	
	$( ".refinesearch" ).click(function(){
		table.page(1).draw(1);
	});
});
