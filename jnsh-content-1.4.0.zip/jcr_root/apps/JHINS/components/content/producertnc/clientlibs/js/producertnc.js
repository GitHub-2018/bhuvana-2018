$(document).ready(function(){

			var userRole; 
            var profileIdVal; 
    		var formData;
    		var npnFocused ="true";
            var nameSSNFocused ="true";
 if(typeof UserData != undefined && UserData != null){
    		if(UserData.content.hasOwnProperty('userProfileId')){
    	    //    uuidVal = "229843668145162884";
    	       	profileIdVal = UserData.content.userProfileId;
    	    }else if(UserData.hasOwnProperty('userProfileId')){
    	    	profileIdVal = UserData.userProfileId;
    	    }
    	    if(UserData.content.hasOwnProperty('role')){
    	    	userRole = UserData.content.role;
            } 
   }
    	    
    	    if("" != userRole && (userRole == "ServiceProvider" || userRole =="HomeOfficeUser" || userRole == "RD/RAM")){
    			// Hide Producer terms and condition page and display text for above user roles
             	 $("#producerTNCinput").hide();
    		     $("#userinfoText").show();
             }else if(userRole == "FirmSupport" || userRole == "SuperUser_SN"){
            	 $("#producerTNCinput").show();
             }
   // if(null != document.getElementById("producertermsandconditon")) { 
    	 // ajax call for Producer and ProducerSupport Role
         if(userRole == "Producer" || userRole == "ProducerSupport"){
             $("#producerTNCinput").hide();
         	 $("#producerTNCreturn").show();
         	 $("#producerTNCNewSearch").hide();
         	var obj = new Object();
			obj.profileId = profileIdVal;
            obj.userRole = userRole;
            formData=JSON.stringify(obj);
            // formData={profileId:profileIdVal,userRole:userRole};
             callAjaxProducerTNC(formData);
         }
    	//}
        //Form POST Ajax call for FirmSupport and Super user Role
     	$("#producerTNCSubmit").on("click", function(event){

            var lastName = $("#inputName").val();
            var ssnNo = $("#inputSSN").val();
            var npnNo = $("#inputNPN").val();
            var obj = new Object();
            obj.userRole = userRole;
            obj.lastName = lastName;
            obj.ssnNo = ssnNo;
            obj.npnNo = npnNo;
			formData=JSON.stringify(obj);
           // var urlVal ="/bin/sling/firmsupporttnc";
            /*if("" !== npnNo && null !== npnNo && undefined !== npnNo){
                 formData={npnNo:npnNo,userRole:userRole};
            }else{
 				formData={lastname:lastName,ssnNo:ssnNo,userRole:userRole};
            }*/
            if(validateSubmit()){
            	
                 callAjax(formData);
                 event.preventDefault();
        	} else {
				event.preventDefault();
       		 }
     });

     	function callAjax(formData){

     	     		$.ajax({  
     	                type: "POST",  
     	                url: "/bin/sling/producertermsandcondition",  
     	                data: {formData: formData},
     	                dataType: 'json',
     	                cache: false,
     	                beforeSend: function(){
	     	               	$("#overlayProducerTNCLoading").show();
                            $("#producerTNCinput").show();
				            $("#producerTNCreturn").hide();
	                        $("#producerTNCSubmit").hide();
     	                  },
     					complete: function(){
     						$("#overlayProducerTNCLoading").hide();
                            $("#producerTNCinput").hide();
				            $("#producerTNCreturn").show();
                            $("#producerTNCSubmit").show();
     	                },
     	                success: function(resp){ 
     	                   // console.log(resp);
     	                    var statusCode;
                            var code;
     	                    var message;
     	                    var name;
     	                    var termsconditions;
     	                    var reqId;
     	                    var statusCodeInArray = ["400","403","500","Default"];
                            var codeInArray = ["6001","6003","7001","8001"];
                            
							 if(null != resp.StatusCode){
     	                	  statusCode = resp.StatusCode;
     	                   }
     	                    if(resp.Code){
     	                        code = resp.Code;
     	                    }
     	                    if(resp.Message){
     	                        message = resp.Message;
     	                    }
                           if($.inArray(statusCode,statusCodeInArray) != -1 || $.inArray(code,codeInArray) != -1){ 
                               $('.hide-row-when-error').css('display','none');
                                if(null != resp.Details && undefined != resp.Details){

                                    if(null != resp.Details.RequestId){
     	                                reqId = resp.Details.RequestId;
     	                                $("#requestID").html("Request Id: "+reqId);
     	                            }
                                }
                                if(null != resp.Message){
								         $('#errorDescription').html(resp.Message+" ("+code+")");
                                 }
								$("#producerTNCNewSearch").css({'display':'none'});
                            }
     	                    if(($.inArray(statusCode,statusCodeInArray) == -1 &&  $.inArray(code,codeInArray) == -1) && null != resp.Details && undefined != resp.Details){
                                 $('#errorDescription').html('');
                                $('.hide-row-when-error').css('display','block');
     	                        if(null != resp.Details.RequestId){
     	                                reqId = resp.Details.RequestId;
     	                               $("#requestID").html("Request Id: "+reqId);
     	                            }
     	                        if(null != resp.Details.Representative && undefined != resp.Details.Representative ){
     	                            if(null != resp.Details.Representative.Name){
     	                                name = resp.Details.Representative.Name;
     	                                $("#producerName").html(name);
     	                            }
     	                            if(null != resp.Details.Representative.TermsAndConditionsStatus){
     	                                termsconditions = resp.Details.Representative.TermsAndConditionsStatus;
     	                                if("Y" == termsconditions){
     	                                    termsconditions = "YES";
     	                                }else if("N" == termsconditions){
     	                                    termsconditions = "NO";
     	                                }else if("NOT_FOUND" == termsconditions){
     	                                    termsconditions = "N/A";
     	                                }
     	                                $("#returned").html(termsconditions);
     	                            }
     	                         }
     	                    }
     	                 }, 
      	                 error: function(e){  
      	                  //  console.log("error"+e);
      	                       event.preventDefault();
      	                 }  
      	         	});
     	}

    function callAjaxProducerTNC(formData){

     	     		$.ajax({  
     	                type: "POST",  
     	                url: "/bin/sling/producertermsandcondition",  
     	                data: {formData: formData},
     	                dataType: 'json',
     	                cache: false,
     	                beforeSend: function(){
							$("#overlayProducerTNCsearch").show();
     	                  },
     					complete: function(){
     						$("#overlayProducerTNCsearch").hide();
     	                },
     	                success: function(resp){ 
     	                  //  console.log(resp);
     	                    var statusCode;
                            var code;
     	                    var message;
     	                    var name;
     	                    var termsconditions;
     	                    var reqId;
     	                    var statusCodeInArray = ["400","403","500","Default"];
                            var codeInArray = ["6001","6003","7001","8001"];
                            
							 if(null != resp.StatusCode){
     	                	  statusCode = resp.StatusCode;
     	                   }
     	                    if(resp.Code){
     	                        code = resp.Code;
     	                    }
     	                    if(resp.Message){
     	                        message = resp.Message;
     	                    }
                           if($.inArray(statusCode,statusCodeInArray) != -1 || $.inArray(code,codeInArray) != -1){ 
                               $('.hide-row-when-error').css('display','none');
                                if(null != resp.Details && undefined != resp.Details){

                                    if(null != resp.Details.RequestId){
     	                                reqId = resp.Details.RequestId;
     	                                $("#requestID").html("Request Id: "+reqId);
     	                            }
                                }
                                if(null != resp.Message){
								         $('#errorDescription').html(resp.Message+" ("+code+")");
                                 }
								$("#producerTNCNewSearch").css({'display':'none'});
                            }
     	                    if(($.inArray(statusCode,statusCodeInArray) == -1 &&  $.inArray(code,codeInArray) == -1) && null != resp.Details && undefined != resp.Details){
                                 $('#errorDescription').html('');
                                $('.hide-row-when-error').css('display','block');
     	                        if(null != resp.Details.RequestId){
     	                                reqId = resp.Details.RequestId;
     	                               $("#requestID").html("Request Id: "+reqId);
     	                            }
     	                        if(null != resp.Details.Representative && undefined != resp.Details.Representative ){
     	                            if(null != resp.Details.Representative.Name){
     	                                name = resp.Details.Representative.Name;
     	                                $("#producerName").html(name);
     	                            }
     	                            if(null != resp.Details.Representative.TermsAndConditionsStatus){
     	                                termsconditions = resp.Details.Representative.TermsAndConditionsStatus;
     	                                if("Y" == termsconditions){
     	                                    termsconditions = "YES";
     	                                }else if("N" == termsconditions){
     	                                    termsconditions = "NO";
     	                                }else if("NOT_FOUND" == termsconditions){
     	                                    termsconditions = "N/A";
     	                                }
     	                                $("#returned").html(termsconditions);
     	                            }
     	                         }
     	                    }
     	                 }, 
      	                 error: function(e){  
      	                 //   console.log("error"+e);
      	                       event.preventDefault();
      	                 }  
      	         	});
     	}
     	
     /* Form Validation */
    var lname = "";
	var ssn = "";
	var npn = "";
	
	var numeric = /^\d+$/;
	var nameReg = /^[A-Za-z]*$/;
	var ssnReg = /^\d{4}$/;
	var npnReg = /^[1-9]{1}[0-9]{4,9}$/;
	
/*	$("#producerTNCSubmit").click(function(event){
		if(validateSubmit()){
			$("#producerTNCinput").hide();
			$("#producerTNCreturn").show();
        } else {
			event.preventDefault();
        }
	});*/
	//New Search Button click functionality
	$("#producerTNCNewSearch").click(function(){
		$(".either").val("");
		$(".or").val("");
		$("#producerName").html("");
        $("#returned").html("");
        $("#requestID").html("");
		$("#producerTNCinput").show();
		$("#producerTNCreturn").hide();
		//document.getElementById("myform").reset();
	});

	$(".either").focus(function(){
		$(".either").css("background-color", "#fff");
		$(".or").css("background-color", "#bbb");
		$(".or").val("");
		$("#npnErrorMessage").html("");
		npnFocused ="false";
        nameSSNFocused ="true";
	});

	$(".or").focus(function(){
		$(".or").css("background-color", "#fff");
		$(".either").css("background-color", "#bbb");
		$(".either").val("");
		$("#lnameErrorMessage").html("");
		$("#ssnErrorMessage").html("");
		npnFocused ="true";
        nameSSNFocused ="false";
       // $("#npnErrorMessage").html("");
	});

	var validateSubmit = function(event){
		lname = $("#inputName").val();
		ssn = $("#inputSSN").val();
		npn = $("#inputNPN").val();	
		
		showError("lnameErrorMessage","");
		showError("ssnErrorMessage","");
		showError("npnErrorMessage","");

        var ret = true;

        if((lname.length==0 && ssn.length==0) && npn.length!=0){
		//	console.log("LastName blank :ssn blank :npn blank");
			ret= validateNPN();
		}else if (lname.length==0 && ssn.length==0 && npn.length==0 && nameSSNFocused=="true" && npnFocused =="true"){
			//console.log("lastName blank :ssn blank :npn blank: All Enabled");
			showError("lnameErrorMessage","This field is required");
			showError("ssnErrorMessage","This field is required");
			showError("npnErrorMessage","This field is required");
			ret= false;
		} 
        else if ((lname.length==0 && ssn.length==0) && nameSSNFocused=="true"){
			//console.log("Lname blank :ssn blank :npn disabled");
			showError("lnameErrorMessage","This field is required");
			showError("ssnErrorMessage","This field is required");
			ret= false;
		}else if ((npn.length==0) && (npnFocused =="true")){
			//console.log("Name SSN disabled : npn blank");
			showError("npnErrorMessage","This field is required");
			ret= false;
		}else if (lname.length!=0 || ssn.length!=0){
			//console.log("atleast one of Lname and SSN not blank:npn blank");
			ret= validateLnameSSN();
		}
       // console.log("Validation result : "+ret);
        return ret;
	};

	var validateLnameSSN = function() {	
		var ret = true;
		
		if(lname.length == 0){
			showError("lnameErrorMessage","This field is required");
			ret = false;
		}
		if(ssn.length == 0){
			showError("ssnErrorMessage","This field is required");
			ret = false;
		} else if(ssn.length != 4){
			showError("ssnErrorMessage","SSN must be 4 digits");
			ret = false;
		}
		
		return ret;
	};

	var validateNPN  = function(){

		if(npnReg.test(npn)){
		//	console.log("npn pass");
		} else {
			showError("npnErrorMessage","NPN must be between 5 and 10 digits with no leading 0");
			return false;
		}		
		return true;
	};
	
	var showError = function(labelId,msg){
		$("#"+labelId).html(msg);
	}


   });

 $(window).load(function() {
	    $("#inputName").val('');
	    $("#inputSSN").val('');
	    $("#inputNPN").val('');
	});