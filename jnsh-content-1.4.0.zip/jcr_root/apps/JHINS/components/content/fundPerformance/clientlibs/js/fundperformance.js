$(document).ready(function(){
	 var contentURL = "/content/JHINS/en_US/config/productsinformation/_jcr_content.data.json";
	   var pathName = window.location.pathname;
	    if(pathName.startsWith("/financial-professionals/PRD")){
			contentURL = "/content/PRDJHINS/en_US/config/productsinformation/_jcr_content.data.json";
	    }else if(pathName.startsWith("/financial-professionals/MGP")){
			contentURL = "/content/MGPJHINS/en_US/config/productsinformation/_jcr_content.data.json";
	    }else if(pathName.startsWith("/financial-professionals/EDJ")){
	             contentURL = "/content/EDJJHINS/en_US/config/productsinformation/_jcr_content.data.json";
	    } 
if($("div").is("#fundByproduct")){
	$.ajax({  
		type: "GET",  
		url: contentURL,
          success : function(data) {
				console.log(data);
			    Products=data;
			  $("#fundByproduct").children().children().children("ul").addClass("product-category");
              $("#fundByproduct").children().children().children("ul").empty();
              $("#fundByproduct").children().children().children("ul").addClass("col-md-4");
              //console.log("product"+Products);
                	$("#version").parent().parent().hide();
                	$("#rider").parent().parent().hide();
                	// checks whether the given element is present in the array
					function contains(arr,element){
						for(var i=0; i<arr.length; i++){
							if(arr[i] === element)
								return true;
						}
						return false;
					}              	
                	/*Build the ProductType List*/
                	function buildProductTypeList(productTypeList){	
						var productTypeOptions = "";		
						for (var j= 0; j < productTypeList.length ; j++){
							   productTypeOptions +="<li><a href=\"#\"  id=\"myLink\"   data-toggle=\"tab\">"+productTypeList[j]+"</a></li>";
                            console.log(productTypeList[j]);
						}
						$("ul.nav-tabs.product-category").append("<li><h4>Choose a Category</h4></li>");
						$("ul.nav-tabs.product-category").append(productTypeOptions);
                        $("ul.nav-tabs.product-category > li:nth-child(2)").addClass("active");
						
					}
					var productType="";		
						    for (var i= 0; i < Products.length ; i++){
							   
								productType=Products[i].productCategory;		
								if(!contains(productTypeList,productType)){
											productTypeList.push(productType);				
								}					
							}
					buildProductTypeList(productTypeList);
					/*Build the ProductType List End*/
					/*on change of product*/
					$('#product').change(function () {
						    $("#version").parent().parent().hide();
							$("#rider").parent().parent().hide();
							if(!$("#rider").is(':visible')){
                                    $(".validate_input_rider").hide();
                            }
                        	if(!$("#version").is(':visible')){
                                    $(".validate_input_version").hide();
                            }
							var selProductType=$('li.active a#myLink').text();
						    var selProduct = this.value; //grab the value selected	
							 
							 setVersionOptions(selProductType,selProduct);
						   
				    });
				    /*on change of product End*/
				    /*on change of version */
					$('#version').change(function () {
						var selProductType=$('li.active a#myLink').text();
						var selProduct=$('#product').val();
					    var selVersion = this.value; //grab the value selected
						if(!$("#rider").is(':visible')){
                                    $(".validate_input_rider").hide();
                            }
						
						 //alert(selProductType,selProduct,selVersion);
						 setRiderOptions(selProductType,selProduct,selVersion);
					   
					});
					/*on change of version END*/
					/*set product version and rider */
              		var setValue=productTypeList[0];					
					setProductOptions(setValue);
                    console.log(setValue);
					$("ul.nav-tabs.product-category > li").on("click",function(){
					setValue=$(this).text();
                    console.log(setValue);
					$("#version").parent().parent().hide();
                	$("#rider").parent().parent().hide();
					setProductOptions(setValue);
					});

					function setProductOptions(selProductType){


							var optionList= new Array();
							
							optionList=getProductList(selProductType);
							optionList.unshift("");
							
							var select = document.getElementById("product");
							select.options.length = 0;
							
							var select = document.getElementById("version");
							select.options.length = 0;
							
							var select = document.getElementById("rider");
							select.options.length = 0;
								
							for (var j= 0; j < optionList.length ; j++){ 
								
								$("#product").append($("<option>")
								.val(optionList[j])
								.html(optionList[j])
								);
							}

						}

						function setVersionOptions(selProductType,selProduct){
							
							var optionList= new Array();	
							optionList=getVersionList(selProductType,selProduct);
							optionList.unshift("");
							
							var select = document.getElementById("version");
							select.options.length = 0
								
							for (var j= 0; j < optionList.length ; j++){ 
								
								$("#version").append($("<option>")
								.val(optionList[j])
								.html(optionList[j])
								);
								
							}

						}

					function setRiderOptions(selProductType,selProduct,selVersion){
						
						var optionList= new Array();	
						optionList=gerRiderList(selProductType,selProduct,selVersion);	
						optionList.unshift("");
						var select = document.getElementById("rider");
						select.options.length = 0
							
						for (var j= 0; j < optionList.length ; j++){ 
							
							$("#rider").append($("<option>")
							.val(optionList[j])
							.html(optionList[j])
							);
							
						}

					}
					/*set product version and rider END*/
					function getProductList(selProductType){

						var productNameList=new Array();
						//alert("selProductType is "+selProductType);
						var j = 0;
						
						for(var i=0; i < Products.length ; i++){
							if(Products[i].productCategory == selProductType){
								if(!contains(productNameList, Products[i].name)){
									productNameList[j] = Products[i].name;
									j++;
								}
							}
						}	
					    //alert (productNameList);
						productNameList.sort();
						
					   return productNameList;
					}

					function getVersionList(selProductType,selProduct){
						
						var versionList=new Array();
						var j = 0;
						
						for(var i=0; i < Products.length ; i++){
							if((Products[i].productCategory == selProductType && Products[i].name == selProduct)){
								if(!contains(versionList, Products[i].version)){
									versionList[j] = Products[i].version;
									j++;
								}
							}
						}	    
						versionList.sort();
						var getproductvalue = $('#product').val();
						if($("#product").children('option:first-child').is(':selected')){
							$("#version").parent().parent().hide();
							$("#rider").parent().parent().hide();
						}else if(versionList == 'Not Applicable'){
							$("#version").parent().parent().hide();
							$("#rider").parent().parent().hide();
                        }else if(versionList == ''){
                            $("#version").parent().parent().hide();
							$("#rider").parent().parent().hide();
                        }else{
							$("#version").parent().parent().show();
						}
						
					   return versionList;
					}

					function gerRiderList(selProductType,selProduct,selVersion){
						
						var riderList=new Array();
						var j = 0;

						for(var i=0; i < Products.length ; i++){
							if((Products[i].productCategory == selProductType && Products[i].name == selProduct && Products[i].version == selVersion)){
								if(!contains(riderList, Products[i].rider)){
									riderList[j] = Products[i].rider;
									j++;
								}
							}
						}	    
						riderList.sort();
						if($("#version").children('option:first-child').is(':selected')){
						
							$("#rider").parent().parent().hide();
						}else if(riderList == 'Not Applicable'){
							
							$("#rider").parent().parent().hide();
                        }else if(riderList == ''){
                            $("#rider").parent().parent().hide();
                        }else{
							$("#rider").parent().parent().show();
						}
						
					    return riderList;
					}





         },
        error : function(XMLHttpRequest, textStatus, errorThrown) {

		} 
    });

}
});