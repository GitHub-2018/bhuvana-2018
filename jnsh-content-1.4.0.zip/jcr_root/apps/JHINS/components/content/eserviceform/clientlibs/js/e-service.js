
/*E-services validation start here for the e-services form*/
function validateFirstName(){	
			var eserviceLname = $("#eserviceLname").val();
			if(eserviceLname.length > 0){
				 $(".validate_input_firstname").remove();
			}
			else{
	        	if($('.validate_input_firstname').length < 1){
	        			$("#eserviceLname").after('<div class="validate_input_firstname validate-eservice">This field is required</div>');
	        		}
	        		
				return false;
	        }

	       
}
function validateLastName(){
			var eserviceFname = $("#eserviceFname").val();
			if(eserviceFname.length > 0){
				 $(".validate_input_lastname").remove();
			}
			else{
	        		if($('.validate_input_lastname').length < 1){
	        			$("#eserviceFname").after('<div class="validate_input_lastname validate-eservice">This field is required</div>');
	        		}
	        		
				return false;
	        }

	       
}
function validateFirmAgent(){
			if ($('input.checkbox_check').is(':checked')) {
				$(".validate_input_checkbox").remove();
			}
			else{
	        		if($('.validate_input_checkbox').length < 1){
	        			$(".checkbox-contain").after('<div class="validate_input_checkbox col-xs-12 validate-eservice">Please select atleast one product.</div>');
	        		}
	        		
				return false;
	        }

}
function validateEmailaddress(){
			var email = /^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i;
	        var eserviceEmail = $( "#eserviceEmail" ).val();
	        if (email.test(eserviceEmail)) {
	            $(".validate_input_email").remove();
	        }	
	        else{
	        	if($('.validate_input_email').length < 1){
	        	$("#eserviceEmail").after('<div class="validate_input_email validate-eservice">E-mail is required</div>');
	        	}
				return false;
	        }
}
$(document).on( "click", "#eservicesSubmit", function() {
	validateFirstName();
	validateEmailaddress();
	validateLastName();
	validateFirmAgent();
	if($('.validate-eservice').length < 1){
        $.ajax({  
		type: "POST",  
		url: "/bin/sling/emailsubscription",
        success : function() {

         },
         error:function(){

         },
        });
		alert("summitted call ajax to post the data");
	        	
	}

});
