    function jhvitQuarterlyFundperformace(formData){       
        callAjax(formData);
         function callAjax(formData){
             var resultType;
             formData.resultType="bySeriesQuaterlyPerformance";
             var series=formData["series"];
             series=series.substr(series.length - 1);
            $.ajax({  
                type: "POST",  
                url: "/bin/sling/fundperformance",  
                data: formData,
                dataType: 'json',
                cache: false,
                success: function(resp){ 
                    console.log("success");
                    var i;
                    var details = resp.FundArray;
                    var tr;
                    $(".jhvitquaterlyperformance_date").html(resp.quarter+" Performance (%) as of "+resp.date);
                     $(".Series").html("(Series "+series+" Funds)");
                    $("#jhvitquarterlyresultable").children("tbody").empty();
                    var prevRiskVal = null;
                	var currRiskVal = null;
                	var risk=null;
                   for (i = 0; i < details.length; i++) {
                        var footNoteVal="";
                    tr = $('<tr/>');
                    currRiskVal =  resp.FundArray[i].risk;
                    if(currRiskVal!==prevRiskVal){
                        prevRiskVal = currRiskVal;
                        risk=resp.FundArray[i].risk;
                        var riskvalue=risk.toUpperCase();
                        var colorcode=resp.FundArray[i].riskColorCode;
                        $('#jhvitquarterlyresultable').append('<tr class="colorband">'+
                                                        '<td  class="riskHearder" colspan="11" style="background-color:' +colorcode+'">'+ riskvalue +'</td>'); 

                        console.log(riskvalue);

                    }else{
                        console.log();
                    }                 

                     if(typeof resp.FundArray[i].morningStarPath !== "undefined" && resp.FundArray[i].morningStarPath !== ""){
                         if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }

                    tr.append("<td scope='row' width='40%'>"+"<a href='"+resp.FundArray[i].morningStarPath+"'target='_blank'>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                       else
                       {
						if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }
                           tr.append("<td scope='row' width='40%'>"+"<a href=''>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                    tr.append("<td>" +resp.FundArray[i].managementFee + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Ytd + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TwelveMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].FiveYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TenYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Incep + "</td>");
                    tr.append("<td>" + resp.FundArray[i].incepDate + "</td>");



                       if($("#jhvitquarterlyperformanceResult").is(':hidden')){
                             $('#jhvitquarterlyresultable').append(tr);                          
                        } 
						 /**************Footnes to be shown in the table****************************/
                       if(typeof resp.FundArray[i].footnotes !== "undefined" && resp.FundArray[i].footnotes !== ""){

                           $('#jhvitquarterlyresultable').append('<tr class="intable-footnotes" >'+
                                                       '<td style="background-color:#fff" class="intable-footnotes-td" colspan="11">'+ resp.FundArray[i].footnotes +'</td>'); 
                        								console.log(resp.FundArray[i].footnotes);

                        }
                       $('#jhvitquarterlyresultable').children("tbody").children("tr.intable-footnotes").prev("tr").children("td").css("border-bottom","none");
                       /**************Footnes to be shown in the table****************************/
                    }
					/**************Footnes to be shown below the table****************************/
                   			 var getFootNotes=resp.FootNotesArray;
                     		$(".foot-notes").remove();
                            $(".foot-notes-para").remove();

						 if(typeof(getFootNotes) !== "undefined" && getFootNotes !== null){

                             $.each( getFootNotes, function( key, value ) {                                 
                                   $.each( value, function( key, value ) {

                                      $("#jhvitquarterlyperformanceResult").append("<div class='foot-notes'>"+

                                                                            "<b>"+
                                                                            +key+
                                                                            "</b>"+

                                                                           "</div>");
                                     // var footnotespara='footnotes"+key+"';
                                      $("#jhvitquarterlyperformanceResult").append("<div class='foot-notes-para'>"+value+"</div>");


        
                                       //console.log(key);
                                       //console.log(value);


        
        
                                   });

        
        
                            });
                         }

                    /**************Footnes to be shown below the table****************************/

					$("#bySeries").hide();
                    $("#jhvitquarterlyperformanceResult").show();
                    $("#jhvit").show();

                },
                 error: function(e){
                    console.log("error");       
                }

            });
         }
    }