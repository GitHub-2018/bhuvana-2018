    function jhvitQuarterlyFundperformace(formData){               
             var resultType;
             formData.resultType="bySeriesQuaterlyPerformance";
             var series=formData["series"];
             series=series.substr(series.length - 1);
            $.ajax({  
                type: "POST",  
                url: "/bin/sling/fundperformance",  
                data: formData,
                dataType: 'json',
                cache: false,
                success: function(resp){ 
                     var statusCode;
                     var code;
                     var statusCodeInArray = ["400","403","404","500","Default"];
                     var codeInArray = ["6001","6003","7001","8001"];
                     if(null != resp.StatusCode){
                         statusCode = resp.StatusCode;
                      }
                     if(resp.Code){
                         code = resp.Code;
                     }
                     // Failure Response display start
                     if($.inArray(statusCode,statusCodeInArray) != -1 || $.inArray(code,codeInArray) != -1){
                    	 $("#bySeries").hide();
                  		 $("#jhvitquarterlyperformanceResult").hide();
                   	     $("#jhvit").show();
                         $("#jhvitFundResultUnavailable").show();
                         if(null != resp.Message){
                             $('#jhvitFundErrorDescription').html(resp.Message+" ("+code+")");
                         } 
 


                     } // Failure Response display End
                   //Success Response Start
                   if(($.inArray(statusCode,statusCodeInArray) == -1 &&  $.inArray(code,codeInArray) == -1)){
                    console.log("success");
                    var i;
                    var details = resp.FundArray;
                    var tr;
                    $(".jhvitquaterlyperformance_date").html(resp.quarter+" Performance (%) as of "+resp.date);
                     $(".Series").html("(Series "+series+" Funds)");
                    $("#jhvitquarterlyresultable").children("tbody").empty();
                    var prevRiskVal = null;
                	var currRiskVal = null;
                	var risk=null;
                   for (i = 0; i < details.length; i++) {
                        var footNoteVal="";
                    tr = $('<tr/>');
                    currRiskVal =  resp.FundArray[i].risk;
                    if(currRiskVal!==prevRiskVal){
                        prevRiskVal = currRiskVal;
                        risk=resp.FundArray[i].risk;
                        var riskvalue=risk.toUpperCase();
                        var colorcode=resp.FundArray[i].riskColorCode;
                        $('#jhvitquarterlyresultable').append('<tr class="colorband">'+
                                                        '<td  class="riskHearder" colspan="11" style="background-color:' +colorcode+'">'+ riskvalue +'</td>'); 

                        console.log(riskvalue);

                    }else{
                        console.log();
                    }                 

                     if(typeof resp.FundArray[i].morningStarPath !== "undefined" && resp.FundArray[i].morningStarPath !== ""){
                         if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }

                    tr.append("<td scope='row' width='40%'>"+"<a href='"+resp.FundArray[i].morningStarPath+"'target='_blank'>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                       else
                       {
						if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }
                           tr.append("<td scope='row' width='40%'>"+"<a href=''>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                    tr.append("<td>" +resp.FundArray[i].managementFee + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Ytd + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TwelveMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].FiveYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TenYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Incep + "</td>");
                    tr.append("<td>" + resp.FundArray[i].incepDate + "</td>");



                       if($("#jhvitquarterlyperformanceResult").is(':hidden')){
                             $('#jhvitquarterlyresultable').append(tr);                          
                        } 
						 /**************Footnes to be shown in the table****************************/
                       if(typeof resp.FundArray[i].footnotes !== "undefined" && resp.FundArray[i].footnotes !== ""){

                           $('#jhvitquarterlyresultable').append('<tr class="intable-footnotes" >'+
                                                       '<td style="background-color:#fff" class="intable-footnotes-td" colspan="11">'+ resp.FundArray[i].footnotes +'</td>'); 
                        								console.log(resp.FundArray[i].footnotes);

                        }
                       $('#jhvitquarterlyresultable').children("tbody").children("tr.intable-footnotes").prev("tr").children("td").css("border-bottom","none");
					    $('#jhvitquarterlyresultable').children("tbody").children("tr.intable-footnotes").children("td").css("border-top","none");
                       /**************Footnes to be shown in the table****************************/
                    }
                    /*This code will replace any undefined and Null or blank in US38352-*/
					$( "#jhvitquarterlyresultable > tbody >tr >td" ).each(function( index ) {
                        console.log("Inside Td");
  						if(($(this).text() == "" )||($(this).text() == "null" )||($(this).text() == "undefined" ))
                            $(this).text("-");

				   });
                    /*This code will replace any undefined and Null or blank in -*/
					/*This code will replace [ and ] after supscript -*/
					$( "#jhvitquarterlyresultable > tbody >tr >td>sup" ).each(function( index ) {


                         var getsuptext=$(this).text();
                        if(getsuptext!=""){
                            var startingbracket="[";
                            var endingbracket="]";
						    var makegetsuptext=startingbracket.concat(getsuptext);
                            var footnotes=makegetsuptext.concat(endingbracket);
                            $(this).text(footnotes);
                        }else{
							$(this).text(getsuptext);
                        }


				   });
                    /*This code will replace  replace [ and ] after supscript-*/
					/**************Footnes to be shown below the table****************************/
                   			var getFootNotes=resp.FootNotesArray;
                     		$(".foot-notes").remove();
                            $(".foot-notes-para").remove();

						 if(typeof(getFootNotes) !== "undefined" && getFootNotes !== null){
							 $("#jhvitquarterlyperformanceResult1").remove();
							$("#jhvitquarterlyperformanceResult").after("<div id='jhvitquarterlyperformanceResult1' style='display:none'></div>");
                             $.each( getFootNotes, function( key, value ) {                                 
                                   $.each( value, function( key, value ) {

                                      $("#jhvitquarterlyperformanceResult").append("<div class='foot-notes small'>"+

                                                                            "<b>"+
                                                                            "["+key+"]"+
                                                                            "</b>"+

                                                                           "</div>");
                                     // var footnotespara='footnotes"+key+"';
                                      $("#jhvitquarterlyperformanceResult").append("<div class='foot-notes-para small'>"+value+"</div>");
									   var footnoteClass = 'footnoteClass' + key;
                                      $("#jhvitquarterlyperformanceResult1").append("<span class='"+footnoteClass+"'>"+value+"</span>");
                                      $("#jhvitquarterlyperformanceResult1").children('.' + footnoteClass).children().prepend("["+key+"]  ");
        
                                   });       
                            });
                         }

                    /**************Footnes to be shown below the table****************************/

					$("#bySeries").hide();
                    $("#jhvitquarterlyperformanceResult").show();
                    $("#jhvit").show();
                    $("#jhvitFundResultUnavailable").hide();
                   }

                },
                 error: function(e){
                    console.log("error");       
                }

            });
         }