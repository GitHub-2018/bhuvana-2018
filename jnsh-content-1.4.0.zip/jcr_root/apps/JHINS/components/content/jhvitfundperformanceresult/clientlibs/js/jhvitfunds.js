var formData;
var getproductCode;
var getcompanyCode;


	
function jhvitFund(value)
{    
    var functionality=value;
    if(value=="Monthly")
    {	 
         jhvitFundperformace(formData);
         $("#jhvitquarterlyperformanceResult").hide();

    }
    else if(value=="Quaterly")
    {   
         jhvitQuarterlyFundperformace(formData);
         $("#jhvitmonthlyperformanceResult").hide();
    }
}
    $(document).ready(function(){ //Form POST Ajax call for Fund Information
    	//Hiding Series1 option to EDJ User
    	var groupName = typeof UserData.content["iv-groups"] !== "undefined" ? UserData.content["iv-groups"] : ""; 
    	groupName = groupName.toUpperCase();
    	if(groupName === 'EJPRODUCERS'){ //hiding jhvit byseries1 search for EDJ user
    	    $(".bySeries1").hide();
    	}
    	
    $("#jhvitfunds").on("click", function(){
        var firmId;
        var pathName = window.location.pathname;
	    if(pathName.startsWith("/financial-professionals/PRD")){
			firmId = "PRD";
	    }else if(pathName.startsWith("/financial-professionals/MGP")){
			firmId = "MGP";
	    }else if(pathName.startsWith("/financial-professionals/EDJ")){
	        firmId = "EDJ";
        }else{
			firmId = "JHINS";
        }
		 event.preventDefault();
           //do something
            if($("#series0").is(':checked') ){
              $(this).prop('disabled', true);
            }else if($("#series1").is(':checked')){
		     $(this).prop('disabled', true);
            }
		 $(".jhvitfundperformanceresult  ").css("display", "block");
		/*Code to hide the call out div when there is nothing authored*/
            if($(".callout.callout-jhvit").children().length > 0 ) {
               	$('.callout.callout-jhvit').css('display','block');
				$('.callout.callout-jhvit').parent().css('display','block');
			}else{
				$('.callout.callout-jhvit').css('display','none');
				$('.callout.callout-jhvit').parent().css('display','none');
			}
        /*Code to hide the call out div when there is nothing authored code end*/
        $(".bySeriesSelction").val("Monthly"); 
        var functionality ="bySeries";
        var series;
        var productCode =null;
        var companyCode = null;
        if(document.getElementById("series0").checked==true)
        {
           var firmindicator = typeof UserData.content["firmindicator"] !== "undefined" ? UserData.content["firmindicator"] : "";
         	firmindicator = firmindicator.toUpperCase();
         	if(firmindicator === "MGROUP"){
         		 productCode="JHM";
         	}else{
         		productCode="JHT";
         	}          
            series="series0";
            companyCode= "JHUSA";
        }
        if(document.getElementById("series1").checked==true)
        {
            productCode= "MIT";
            companyCode= "JHUSA";
             series="series1";
        }
        if(null !== productCode){
            var footnote="";
			getproductCode=productCode;
            getcompanyCode=companyCode;
            formData={productCode:productCode,companyCode:companyCode,functionality:functionality,series:series,footNote:footnote,firmId:firmId};
        }
        jhvitFundperformace(formData);

    });
        $( "ul.nav > li" ).on( "click", function() {
	    $("#jhvitfunds").prop('disabled', false);
        $("#bySeries").show();
        $("#jhvit").hide();
        $("#jhvitmonthlyperformanceResult").hide();
        $("#jhvitquarterlyperformanceResult").hide();
        $("#jhvitFundResultUnavailable").hide();
        $('#jhvitmonthlyresultable').children("tbody").children("tr").remove();
        $('#jhvitquarterlyresultable').children("tbody").children("tr").remove();
    });
	 /*For mobile tab new request*/
			 $( ".panel-heading >h4.panel-title >a" ).on( "click", function() { 
                    $("#jhvitfunds").prop('disabled', false);			 
				    $("#bySeries").css("display", "block");
                    $(".jhvitfundperformanceresult").css("display", "none");
                    $("#bySeries").show();
                    $("#jhvitmonthlyperformanceResult").hide();
                    $("#jhvitquarterlyperformanceResult").hide();
                    $('#jhvitmonthlyresultable').children("tbody").children("tr").remove();
                    $('#jhvitquarterlyresultable').children("tbody").children("tr").remove();

			});
        /*For mobile tab new request*/
	 /*Get csv file for mothly quaterly and daily performance*/

							$('.download-csv-jhvit').click(function() {
                                  var titles = [];
                                  var data = [];
                                  var producttitles = [];
                                  var headerdata = [];
                                  var headerparadata=[];
                                  var footerpara=[];
                                  var footerpara1=[];
                                  var headerparadata2=[];
                                  var getproductSeries;
                                if(getcompanyCode=='JHUSA'){
                                  getproductSeries = 0;
                                }else{
                                 getproductSeries = 94;

                                }
                                 if($("#jhvitmonthlyperformanceResult").is(':visible')){
                                     var monthvalue = "MONTH";
                                  }else if($("#jhvitquarterlyperformanceResult").is(':visible')){
                                       var monthvalue = "QUARTER";
                                  }


                                  var fileName = "FundValues" + "_" + getproductCode + "_" + getproductSeries +"_" + monthvalue +'.csv';

							/*get row one common for all the three fund*/
                                if($(".download-csv-jhvitheader").is(':visible')){
                                   $('.download-csv-jhvitheader').each(function() {
                                        var getheader= $(this).text();
                                        var getheadernext= $(this).next().text();
                                        var headerspace = " ";
                                        getheader=getheader.concat(headerspace)
                                        getheader=getheader.concat(getheadernext); 
                                       	getheader=getheader.replace(",", " ");
                                        getheader=getheader.replace(",", " ");
                                        getheader=getheader.replace(/[^A-Z a-z , [0-9] ]/g, " ");
                                        producttitles.push(getheader);

                                    
                                  });
                                }
                            /*get row one common for all the three fund*/

                            /*get row two and three  for all the three fund*/
                                 if($("#jhvitmonthlyperformanceResult").is(':visible')){


                                  $('#jhvitmonthlyperformanceResult').each(function() {
                                        var getpara= $(this).children().children("h4").next("p").text().trim();
                                        headerparadata.push(getpara);
                                
                                  });

                                        var getpara1= $(".jhvitmonthlyperformance_date").text();
                                       // alert(getpara1);
                                        getpara1=getpara1.replace(",", " ");
                                        headerparadata2.push(getpara1);
                                


                                  }else if($("#jhvitquarterlyperformanceResult").is(':visible')){


                                  $('#jhvitquarterlyperformanceResult').each(function() {
                                        var getpara= $(this).children().children("h4").next("p").text().trim();
                                        headerparadata.push(getpara);
                                
                                  });
                                  $('#jhvitquarterlyperformanceResult').each(function() {
                                        var getpara1= $(".jhvitquaterlyperformance_date").text();
                                        getpara1=getpara1.replace(",", " ");
                                        headerparadata2.push(getpara1);
                                
                                  });
                                  }

                                /*get row two and three  for all the three fund*/

                               /*get row 5 and 6  for all the three fund*/
                                if($("#jhvitmonthlyresultable").is(':visible')){
                                  $('#jhvitmonthlyresultable tr th').each(function() {
                                    titles.push($(this).text().toUpperCase());
                                  });
                                
                                  /*
                                   * Get the actual data, this will contain all the data, in 1 array
                                   */
                                    if($("#jhvitmonthlyresultable tr").hasClass("colorband")){
                                        $("#jhvitmonthlyresultable tr.colorband ").children("td.remove-this").remove();
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                         $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");


                                
                                    }
                                    if($("#jhvitmonthlyresultable tr").hasClass("intable-footnotes")){
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").children("td.remove-footnotes").remove();
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");



                                    }
                                  $('#jhvitmonthlyresultable tr td').each(function() {
                                     if($(this).children("a").length > 0){
                                         var gettd= $(this).children("a").text();
                                         var gettdsub= $(this).children("sup").text();
                                         var gettdsmall= $(this).children("small").text();
                                         var getspace = "  ";
                                         gettd=gettd.concat(getspace);
										 gettd=gettd.concat(gettdsub);
                                         gettd=gettd.concat(getspace);
                                         gettd=gettd.concat(gettdsmall);


                                      }else{
                                         var gettd= $(this).text();
                                      }
                                       gettd=gettd.replace(",", " ");
                                       data.push(gettd);
                                  });
                                
                                  
                                    $('.foot-notes').each(function() { 
                                     var getfootnotenumber = $(this).text();
                                     var getgootnotesdesp = $(this).next(".foot-notes-para").children().text().replace(/,/g ,"");
                                     getgootnotesdesp=getgootnotesdesp.replace(/[^A-Z a-z [0-9]]/g, "");
                                      var getspace=" ";
									 getfootnotenumber=getfootnotenumber.concat(getspace);  
                                     var getcsvfootnotes = getfootnotenumber.concat(getgootnotesdesp);
                                     getcsvfootnotes=getcsvfootnotes.trim();
                                     var separatefpptnotes= '\n';
                                     var getseparatefpptnotes=getcsvfootnotes.concat(separatefpptnotes);
                                     footerpara1.push(getseparatefpptnotes);
                                     });

                                     var footparaheader = footerpara1.toString().replace(/,/g ,"");
                                     footerpara.push(footparaheader);
                                }else if($("#jhvitquarterlyresultable").is(':visible')){
                                  $('#jhvitquarterlyresultable tr th').each(function() {
                                    titles.push($(this).text().toUpperCase());
                                  });
                                
                                  /*
                                   * Get the actual data, this will contain all the data, in 1 array
                                   */
                                    if($("#jhvitquarterlyresultable tr").hasClass("colorband")){
                                        $("#jhvitquarterlyresultable tr.colorband ").children("td.remove-this").remove();
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");



                                
                                    }
                                    if($("#jhvitquarterlyresultable tr").hasClass("intable-footnotes")){
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").children("td.remove-footnotes").remove();
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                         $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");



                                    }
                                  $('#jhvitquarterlyresultable tr td').each(function() {
                                     if($(this).children("a").length > 0){
                                         var gettd= $(this).children("a").text();
                                         var gettdsub= $(this).children("sup").text();
                                         var gettdsmall= $(this).children("small").text();
                                         var getspace = "  ";
                                         gettd=gettd.concat(getspace);
										 gettd=gettd.concat(gettdsub);
                                         gettd=gettd.concat(getspace);
                                         gettd=gettd.concat(gettdsmall);


                                      }else{
                                         var gettd= $(this).text();
                                      }
                                       gettd=gettd.replace(",", " ");
                                       data.push(gettd);
                                  });
                                
                                    
                                    $('.foot-notes').each(function() { 
                                     var getfootnotenumber = $(this).text();
                                     var getgootnotesdesp = $(this).next(".foot-notes-para").children().text().replace(/,/g ,"");
                                     getgootnotesdesp=getgootnotesdesp.replace(/[^A-Z a-z [0-9]]/g, "");
                                      var getspace=" ";
									 getfootnotenumber=getfootnotenumber.concat(getspace);  
                                     var getcsvfootnotes = getfootnotenumber.concat(getgootnotesdesp);
                                     getcsvfootnotes=getcsvfootnotes.trim();
                                     var separatefpptnotes= '\n';
                                     var getseparatefpptnotes=getcsvfootnotes.concat(separatefpptnotes);
                                     footerpara1.push(getseparatefpptnotes);
                                     });

                                     var footparaheader = footerpara1.toString().replace(/,/g ,"");
                                     footerpara.push(footparaheader);
                                }
                                  
                                  /*
                                   * Convert our data to CSV string
                                   */
                                
                                    var CSVString = prepCSVRow(producttitles, producttitles.length, "");
                                    CSVString = prepCSVRow(headerdata, headerdata.length, CSVString);
                                    CSVString = prepCSVRow(headerparadata, headerparadata.length, CSVString);
                                    CSVString = prepCSVRow(headerparadata2, headerparadata2.length, CSVString);

                                
                                    CSVString = prepCSVRow(titles, titles.length, CSVString);
                                    CSVString = prepCSVRow(data, titles.length, CSVString);
                                    CSVString = prepCSVRow(footerpara, footerpara.length, CSVString+'\n');
                                
                                
                                
                                
                                
                                  /*
                                   * Make CSV downloadable
                                   */
                                  if (navigator.msSaveBlob)  // For IE 10+
                                  {
                                  var downloadLink = document.createElement("a");
                                  var blob = new Blob([CSVString], {
                                    "type": "text/csv;charset=utf8;"});
                                    navigator.msSaveOrOpenBlob(blob, fileName); 
                                  }
                                  else{
                                  var downloadLink = document.createElement("a");
                                  var blob = new Blob(["\ufeff", CSVString]);
                                  var url = URL.createObjectURL(blob);
                                  downloadLink.href = url;
                                  downloadLink.download = fileName;
                                  /*
                                   * Actually download CSV
                                   */
                                 document.body.appendChild(downloadLink);
                                 downloadLink.click();
                                 document.body.removeChild(downloadLink);}
                                
                          });
                                
                                   /*
                                * Convert data array to CSV string
                                * @param arr {Array} - the actual data
                                * @param columnCount {Number} - the amount to split the data into columns
                                * @param initial {String} - initial string to append to CSV string
                                * return {String} - ready CSV string
                                */
                                function prepCSVRow(arr, columnCount, initial) {
                                  var row = ''; // this will hold data
                                  var delimeter = ','; // data slice separator, in excel it's `;`, in usual CSv it's `,`
                                  var newLine = '\r\n'; // newline separator for CSV row
                                
                                  /*
                                   * Convert [1,2,3,4] into [[1,2], [3,4]] while count is 2
                                   * @param _arr {Array} - the actual array to split
                                   * @param _count {Number} - the amount to split
                                   * return {Array} - splitted array
                                   */
                                  function splitArray(_arr, _count) {
                                    var splitted = [];
                                    var result = [];
                                    _arr.forEach(function(item, idx) {
                                      if ((idx + 1) % _count === 0) {
                                        splitted.push(item);
                                        result.push(splitted);
                                        splitted = [];
                                      } else {
                                        splitted.push(item);
                                      }
                                    });
                                    return result;
                                  }
                                  var plainArr = splitArray(arr, columnCount);
                                  // don't know how to explain this
                                  // you just have to like follow the code
                                  // and you understand, it's pretty simple
                                  // it converts `['a', 'b', 'c']` to `a,b,c` string
                                  plainArr.forEach(function(arrItem) {
                                    arrItem.forEach(function(item, idx) {
                                      row += item + ((idx + 1) === arrItem.length ? '' : delimeter);
                                    });
                                    row += newLine;
                                  });
                                  return initial + row;
                                }



/***************************to export table contentin csv end here*************************************/
/***************************************************************download pdf ***************************************************************************/
 function generateasPDF() {
     var doc = new jsPDF('l', 'pt', 'a4');
     if ($(".jhvitmonthlyperformance_date").is(':visible')) {
         var gethaeder = $(".jhvitmonthlyperformance_date").text();
     } else if ($(".jhvitquaterlyperformance_date").is(':visible')) {
         var gethaeder = $(".jhvitquaterlyperformance_date").text();
     }
     if ($(".download-csv-jhvitheader").is(':visible')) {
         var gethaederProduct = $(".download-csv-jhvitheader").text();
         var gethaederSeries = $(".Series").text();
         var getthemergedheader = gethaederProduct.concat(" "+gethaederSeries);
     } 
     //var domain = location.protocol + "//" + location.hostname + ":" + location.port;
     //var Imageurl = domain + "/content/dam/geometrixx-gov/logo-jhancock.png";
     var domain = location.protocol+"//"+location.hostname+":"+location.port;
     var Imageurl="/etc/designs/JHINS/images/logo-jhancock.png";
     var header = function(data) {
         doc.setFontSize(16);
         //doc.setTextColor(40);
         doc.setFontStyle('bold');
         doc.text(getthemergedheader, data.settings.margin.left, 40);
         doc.text(gethaeder, data.settings.margin.left, 60);
         doc.addImage(Imageurl, 'JPEG', data.settings.margin.left + 565, 20, 150, 40, {
             margin: 100
         });
     };

     var options = {
         // startY: doc.autoTableEndPosY() + 65,
         theme: 'plain',
         showHeader: 'everyPage',
         margin: {
             top: 92
         },
         addPageContent: header,
         styles: {
             font: "normal",
             fontSize: 8,
             overflow: "linebreak",
             cellPadding: 3,

         },
         drawCell: function(cell, data) {
             var rows = data.table.rows;
             if (data.row.index == 0) {                
             }
         },
         createdCell: function(cell, data) {
             if (data.row.cells[0].raw.innerText === "AGGRESSIVE") {
                 console.log(data.row.cells[0].raw.innerText); {
                     cell.styles.fillColor = [198, 28, 49],
                     cell.styles.textColor = [255, 255,255]
                 }
             } else if (data.row.cells[0].raw.innerText === "GROWTH") {
                 {
                     cell.styles.fillColor = [239, 138, 33],
                     cell.styles.textColor = [255, 255,255]
                 }
             } else if (data.row.cells[0].raw.innerText === "GROWTH AND INCOME") {
                 {
                     cell.styles.fillColor = [231, 199, 8],
                     cell.styles.textColor = [255, 255,255]
                 }
             } else if (data.row.cells[0].raw.innerText === "INCOME") {
                 {
                     cell.styles.fillColor = [140, 150, 33],
                     cell.styles.textColor = [255, 255,255]
                 }
             } else if (data.row.cells[0].raw.innerText === "CONSERVATIVE") {
                 {
                     cell.styles.fillColor = [57, 113, 173],
                     cell.styles.textColor = [255, 255,255]
                 }
             } else if (data.row.cells[0].raw.innerText === "LIFESTYLE") {
                 {
                     cell.styles.fillColor = [0, 0, 0],
                     cell.styles.textColor = [255, 255,255]
                 }
             } else if (data.row.cells[0].raw.innerText === "MANAGED VOLATILITY") {
                 {
                     cell.styles.fillColor = [102, 102, 102],
                     cell.styles.textColor = [255, 255,255]
                 }
             }
         },

         headerStyles: {
             //columnWidth: 'wrap',
             cellPadding: 2,
             lineWidth: 0,
             valign: 'top',
             fontStyle: 'bold',
             halign: 'left', //'center' or 'right'
             fillColor: [255, 255, 255],
             textColor: [78, 53, 73], //Black     
             //textColor: [255, 255, 255], //White     
             fontSize: 8,

             rowHeight: 20
         }
     };

     if ($("#jhvitmonthlyresultable").is(':visible')) {
         var res = doc.autoTableHtmlToJson(document.getElementById("jhvitmonthlyresultable"));
     } else {
         var res = doc.autoTableHtmlToJson(document.getElementById("jhvitquarterlyresultable"));
     }
     // doc.autoTable(res.columns, res.data, {
     doc.autoTable(res.columns, res.data, options);
     var specialElementHandlers = {
         '#editor': function(element, renderer) {
             return true;
         }
     };

     function takeHTML() {
	  if ($("#jhvitmonthlyresultable").is(':visible')) {
       doc.fromHTML($("#jhvitmonthlyperformanceResult1").html(), 40, doc.autoTableEndPosY(), {
                 margin: {
                     left: 100,
                     top: 30
                 },
                 styles: {
                     font: "normal",
                     fontSize: 8,
                     overflow: "",
                     halign: "left"
                 },
                 'width': 750,
                 'elementHandlers': specialElementHandlers
             });
		  }else if($("#jhvitquarterlyresultable").is(':visible')){
			 doc.fromHTML($("#jhvitquarterlyperformanceResult1").html(), 40, doc.autoTableEndPosY(), {
                 margin: {
                     left: 100,
                     top: 30
                 },
                 styles: {
                     font: "normal",
                     fontSize: 8,
                     overflow: "",
                     halign: "left"
                 },
                 'width': 750,
                 'elementHandlers': specialElementHandlers
             }); 
	  
		  }





     }
      if(getcompanyCode=='JHUSA'){
          getproductSeries = 0;
      }else{
          getproductSeries = 94;
          
      }

    if ($("#jhvitmonthlyresultable").is(':visible')) {
         takeHTML();
         var downloadas="FundValues" + "_" + getproductSeries +"_JHVITMonthlyPerformance.pdf";
         doc.save(downloadas);
     } else if ($("#jhvitquarterlyresultable").is(':visible')) {
         takeHTML();
         var downloadas="FundValues" + "_" + getproductSeries +"_JHVITQuaterlyPerformance.pdf";
         doc.save(downloadas);
     }





 }

$(".downloadaspdfJHVIT").on("click",function(){
 	generateasPDF();
 });
/***********************************************************download pdf end here*************************************************************/
});