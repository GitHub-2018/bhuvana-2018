var formData;
var getproductCode;
var getcompanyCode;
function jhvitFund(value)
{    
    var functionality=value;
    if(value=="Monthly")
    {	 
         jhvitFundperformace(formData);
         $("#jhvitquarterlyperformanceResult").hide();

    }
    else if(value=="Quaterly")
    {   
         jhvitQuarterlyFundperformace(formData);
         $("#jhvitmonthlyperformanceResult").hide();
    }
}
    $(document).ready(function(){//Form POST Ajax call for Fund Information
    $("#jhvitfunds").on("click", function(){
        $(".bySeriesSelction").val("Monthly"); 
        var functionality ="bySeries";
        var series;
        var productCode =null;
        var companyCode = null;
        if(document.getElementById("series0").checked==true)
        {
           var firmindicator = typeof UserData.content["firmindicator"] !== "undefined" ? UserData.content["firmindicator"] : "";
         	firmindicator = firmindicator.toUpperCase();
         	if(firmindicator === "MGROUP"){
         		 productCode="JHM";
         	}else{
         		productCode="JHT";
         	}          
            series="series0";
            companyCode= "JHUSA";
        }
        if(document.getElementById("series1").checked==true)
        {
            productCode= "MIT";
            companyCode= "JHUSA";
             series="series1";
        }
        if(null !== productCode){
            var footnote="";
			getproductCode=productCode;
            getcompanyCode=companyCode;
            formData={productCode:productCode,companyCode:companyCode,functionality:functionality,series:series,footNote:footnote};
        }
        jhvitFundperformace(formData);

    });
        $( "ul.nav > li" ).on( "click", function() {
        $("#bySeries").show();
        $("#jhvit").hide();
        $("#jhvitmonthlyperformanceResult").hide();
        $("#jhvitquarterlyperformanceResult").hide();
        $('#jhvitmonthlyresultable').children("tbody").children("tr").remove();
        $('#jhvitquarterlyresultable').children("tbody").children("tr").remove();
    });
	 /*Get csv file for mothly quaterly and daily performance*/

							$('.download-csv-jhvit').click(function() {
                                  var titles = [];
                                  var data = [];
                                  var producttitles = [];
                                  var headerdata = [];
                                  var headerparadata=[];
                                  var footerpara=[];
                                  var footerpara1=[];
                                  var headerparadata2=[];
                                  var getproductSeries;
                                if(getcompanyCode=='JHUSA'){
                                  getproductSeries = 0;
                                }else{
                                 getproductSeries = 94;

                                }
                                 if($("#jhvitmonthlyperformanceResult").is(':visible')){
                                     var monthvalue = "MONTH";
                                  }else if($("#jhvitquarterlyperformanceResult").is(':visible')){
                                       var monthvalue = "QUARTER";
                                  }


                                  var fileName = "FundValues" + "_" + getproductCode + "_" + getproductSeries +"_" + monthvalue +'.csv';

							/*get row one common for all the three fund*/
                                if($(".download-csv-jhvitheader").is(':visible')){
                                   $('.download-csv-jhvitheader').each(function() {
                                        var getheader= $(this).text();  
                                       	getheader=getheader.replace(",", " ");
                                        getheader=getheader.replace(",", " ");
                                        getheader=getheader.replace(/[^A-Z a-z , [0-9] ]/g, " ");
                                       producttitles.push(getheader);

                                    
                                  });
                                }
                            /*get row one common for all the three fund*/

                            /*get row two and three  for all the three fund*/
                                 if($("#jhvitmonthlyperformanceResult").is(':visible')){


                                  $('#jhvitmonthlyperformanceResult').each(function() {
                                        var getpara= $(this).children().children("h4").next("p").text();
                                        getpara=getpara.replace(",", " ");
                                        headerparadata.push(getpara);
                                
                                  });

                                        var getpara1= $(".jhvitmonthlyperformance_date").text();
                                       // alert(getpara1);
                                        getpara1=getpara1.replace(",", " ");
                                        headerparadata2.push(getpara1);
                                


                                  }else if($("#jhvitquarterlyperformanceResult").is(':visible')){


                                  $('#jhvitquarterlyperformanceResult').each(function() {
                                        var getpara= $(this).children().children("h4").next("p").text();
                                        getpara=getpara.replace(",", " ");
                                        headerparadata.push(getpara);
                                
                                  });
                                  $('#jhvitquarterlyperformanceResult').each(function() {
                                        var getpara1= $(".jhvitquaterlyperformance_date").text();
                                        getpara1=getpara1.replace(",", " ");
                                        headerparadata2.push(getpara1);
                                
                                  });
                                  }

                                /*get row two and three  for all the three fund*/

                               /*get row 5 and 6  for all the three fund*/
                                if($("#jhvitmonthlyresultable").is(':visible')){
                                  $('#jhvitmonthlyresultable tr th').each(function() {
                                    titles.push($(this).text().toUpperCase());
                                  });
                                
                                  /*
                                   * Get the actual data, this will contain all the data, in 1 array
                                   */
                                    if($("#jhvitmonthlyresultable tr").hasClass("colorband")){
                                        $("#jhvitmonthlyresultable tr.colorband ").children("td.remove-this").remove();
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                         $("#jhvitmonthlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");


                                
                                    }
                                    if($("#jhvitmonthlyresultable tr").hasClass("intable-footnotes")){
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").children("td.remove-footnotes").remove();
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitmonthlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");



                                    }
                                  $('#jhvitmonthlyresultable tr td').each(function() {
                                     var gettd= $(this).text();
                                     gettd=gettd.replace(",", " ");
                                     data.push(gettd);
                                  });
                                
                                  
                                    $('.foot-notes').each(function() { 
                                     var getfootnotenumber = $(this).text();
                                     var getgootnotesdesp = $(this).next(".foot-notes-para").children().text().replace(/,/g ,"");
                                     getgootnotesdesp=getgootnotesdesp.replace(/[^A-Z a-z [0-9]]/g, "");
                                      var getspace=" ";
									 getfootnotenumber=getfootnotenumber.concat(getspace);  
                                     var getcsvfootnotes = getfootnotenumber.concat(getgootnotesdesp);
                                     getcsvfootnotes=getcsvfootnotes.trim();
                                     var separatefpptnotes= '\n';
                                     var getseparatefpptnotes=getcsvfootnotes.concat(separatefpptnotes);
                                     footerpara1.push(getseparatefpptnotes);
                                     });

                                     var footparaheader = footerpara1.toString().replace(/,/g ,"");
                                     footerpara.push(footparaheader);
                                }else if($("#jhvitquarterlyresultable").is(':visible')){
                                  $('#jhvitquarterlyresultable tr th').each(function() {
                                    titles.push($(this).text().toUpperCase());
                                  });
                                
                                  /*
                                   * Get the actual data, this will contain all the data, in 1 array
                                   */
                                    if($("#jhvitquarterlyresultable tr").hasClass("colorband")){
                                        $("#jhvitquarterlyresultable tr.colorband ").children("td.remove-this").remove();
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");



                                
                                    }
                                    if($("#jhvitquarterlyresultable tr").hasClass("intable-footnotes")){
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").children("td.remove-footnotes").remove();
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                         $("#jhvitquarterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");



                                    }
                                  $('#jhvitquarterlyresultable tr td').each(function() {
                                     var gettd= $(this).text();
                                     gettd=gettd.replace(",", " ");
                                     data.push(gettd);
                                  });
                                
                                    
                                    $('.foot-notes').each(function() { 
                                     var getfootnotenumber = $(this).text();
                                     var getgootnotesdesp = $(this).next(".foot-notes-para").children().text().replace(/,/g ,"");
                                     getgootnotesdesp=getgootnotesdesp.replace(/[^A-Z a-z [0-9]]/g, "");
                                      var getspace=" ";
									 getfootnotenumber=getfootnotenumber.concat(getspace);  
                                     var getcsvfootnotes = getfootnotenumber.concat(getgootnotesdesp);
                                     getcsvfootnotes=getcsvfootnotes.trim();
                                     var separatefpptnotes= '\n';
                                     var getseparatefpptnotes=getcsvfootnotes.concat(separatefpptnotes);
                                     footerpara1.push(getseparatefpptnotes);
                                     });

                                     var footparaheader = footerpara1.toString().replace(/,/g ,"");
                                     footerpara.push(footparaheader);
                                }
                                  
                                  /*
                                   * Convert our data to CSV string
                                   */
                                
                                    var CSVString = prepCSVRow(producttitles, producttitles.length, "");
                                    CSVString = prepCSVRow(headerdata, headerdata.length, CSVString);
                                    CSVString = prepCSVRow(headerparadata, headerparadata.length, CSVString);
                                    CSVString = prepCSVRow(headerparadata2, headerparadata2.length, CSVString);

                                
                                    CSVString = prepCSVRow(titles, titles.length, CSVString);
                                    CSVString = prepCSVRow(data, titles.length, CSVString);
                                    CSVString = prepCSVRow(footerpara, footerpara.length, CSVString);
                                
                                
                                
                                
                                
                                  /*
                                   * Make CSV downloadable
                                   */
                                  if (navigator.msSaveBlob)  // For IE 10+
                                  {
                                  var downloadLink = document.createElement("a");
                                  var blob = new Blob([CSVString], {
                                    "type": "text/csv;charset=utf8;"});
                                    navigator.msSaveOrOpenBlob(blob, fileName); 
                                  }
                                  else{
                                  var downloadLink = document.createElement("a");
                                  var blob = new Blob(["\ufeff", CSVString]);
                                  var url = URL.createObjectURL(blob);
                                  downloadLink.href = url;
                                  downloadLink.download = fileName;
                                  /*
                                   * Actually download CSV
                                   */
                                 document.body.appendChild(downloadLink);
                                 downloadLink.click();
                                 document.body.removeChild(downloadLink);}
                                
                          });
                                
                                   /*
                                * Convert data array to CSV string
                                * @param arr {Array} - the actual data
                                * @param columnCount {Number} - the amount to split the data into columns
                                * @param initial {String} - initial string to append to CSV string
                                * return {String} - ready CSV string
                                */
                                function prepCSVRow(arr, columnCount, initial) {
                                  var row = ''; // this will hold data
                                  var delimeter = ','; // data slice separator, in excel it's `;`, in usual CSv it's `,`
                                  var newLine = '\r\n'; // newline separator for CSV row
                                
                                  /*
                                   * Convert [1,2,3,4] into [[1,2], [3,4]] while count is 2
                                   * @param _arr {Array} - the actual array to split
                                   * @param _count {Number} - the amount to split
                                   * return {Array} - splitted array
                                   */
                                  function splitArray(_arr, _count) {
                                    var splitted = [];
                                    var result = [];
                                    _arr.forEach(function(item, idx) {
                                      if ((idx + 1) % _count === 0) {
                                        splitted.push(item);
                                        result.push(splitted);
                                        splitted = [];
                                      } else {
                                        splitted.push(item);
                                      }
                                    });
                                    return result;
                                  }
                                  var plainArr = splitArray(arr, columnCount);
                                  // don't know how to explain this
                                  // you just have to like follow the code
                                  // and you understand, it's pretty simple
                                  // it converts `['a', 'b', 'c']` to `a,b,c` string
                                  plainArr.forEach(function(arrItem) {
                                    arrItem.forEach(function(item, idx) {
                                      row += item + ((idx + 1) === arrItem.length ? '' : delimeter);
                                    });
                                    row += newLine;
                                  });
                                  return initial + row;
                                }



/***************************to export table contentin csv end here*************************************/
});