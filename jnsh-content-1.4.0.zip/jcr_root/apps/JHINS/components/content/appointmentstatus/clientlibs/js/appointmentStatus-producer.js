var expanded = false;
var states = [];
var statesvalue = [];
var newStates = [];
var newStatesvalue  = [];
var selectcheckboxValue = [];
var getcheckboxId = [];
var product = [];
var productType = [];
var selectAllValue = [];
var userRoleVal ; 
var profileIdVal;
var formData ;
var count=0;
var firmSupportData;
var storeaddeddata = [];
var getvaluefromsubmit=[];
var getvaluefromInputforSubmit=[]; 

if(typeof UserData != undefined && UserData != null){
if(UserData.content.hasOwnProperty('userProfileId')){
    //    uuidVal = "229843668145162884";
       	profileIdVal = UserData.content.userProfileId;
    }else if(UserData.hasOwnProperty('userProfileId')){
    	profileIdVal = UserData.userProfileId;
    }
    if(UserData.content.hasOwnProperty('role')){
    	userRoleVal = UserData.content.role;
    } 
}
$(document).on("click touchstart",".ipad-appoimentstatus-tooltip", function() {
    $(".tooltiptext_appoiment").show();

});
$(document).on( "click", ".close", function() {
    $(".tooltiptext_appoiment").hide();
});
///* 4928 Fix 
function getCheckboxes() {
	var checkboxes = document.getElementById("checkboxes");
    	    if (!expanded) {
    	        checkboxes.style.display = "block";
               $("#SelectAll").parent().focus();
               window.setTimeout(function(){
   				$('#SelectAll').focus();
			   }, 50);
    	        expanded = true;
    	    } else {
    	        checkboxes.style.display = "none";
    	        expanded = false;
    	    }

    	 $(document).on('click touchstart', function (event) {
    	    if(!$(event.target).closest('.selectBox').length) {
    	        if($('#checkboxes').is(":visible")) {
    	            $('#checkboxes').hide();
    	            expanded = false;
    	        }
    	    }
    	    if (event.target.id == "checkboxes" || $(event.target).parents("#checkboxes").length) {
    	           $('#checkboxes').show();
    	           expanded = true;
    	    }
 	});    //*/ 4928 Fix end

}
function showCheckboxes() {
    if(userRoleVal == "Producer" || userRoleVal == "ProducerSupport"){
				getCheckboxes();
    }
    else if(userRoleVal == "FirmSupport" || userRoleVal == "SuperUser_SN"){
    if(($("#salesAgent").is(':checked')) && ((($("#salesSSN").is(':checked')) || ($("#salesNPN").is(':checked')) || ($("#salesAgentcode").is(':checked'))||  ($("#salesAgentPyroll").is(':checked'))))){
			getCheckboxes();
	}
	else if(($("#salesFirm").is(':checked') && ((($("#salesAgentPyroll").is(':checked')) || ($("#salesTIN").is(':checked')))))) {
		    getCheckboxes();
	}
   }
  }



function updateProductType(val) {

	}

function updateSelection(val) {
}

$(document).ready(function () {

	if(userRoleVal == "Producer" || userRoleVal == "ProducerSupport"){
        $(".firmSupport").hide();
   	 	$("#appointmentStatusInput").show();
        $("#roleBasedText").hide();
        $('.disabled_onload').removeAttr("disabled");

        //disabled_onload

    }else if("" != userRoleVal && (userRoleVal == "ServiceProvider" || userRoleVal =="HomeOfficeUser" || userRoleVal == "RD/RAM")){
     	$("#appointmentStatusInput").hide();
	    $("#roleBasedText").show();
    }else if(userRoleVal == "FirmSupport" || userRoleVal == "SuperUser_SN"){
   	 	$("#appointmentStatusInput").show();
        $("#roleBasedText").hide();
        $(".firmSupport").show();
        $(".display_table").hide();

 //FirmSupport Form Disable code Start
        $(".disabled_onload.sales_Idvalue").css("color","#595959");
        $(".disabled_onload.sales_IdvalueLast_name").css("color","#595959");
        $('.disabled_onload').attr('disabled', 'disabled');
        $('.disabled_onload').parent().css("color", "#e1e1e1");
        $('.disabled_onload').css("background-color", "#e1e1e1");
        $("input:radio").removeAttr("checked");
        $("input:checkbox").removeAttr("checked");
    
        var producerType="";
        var idType="";
        var idValue="";
        var ssnValue="";
        $(document).on( "click", "input[type='radio'].radio_button", function() {	
            $(".validate_input").remove();
            $(".sales_Idvalue").val("");
            $(".sales_IdvalueLast_name").val("");
                    if(($("#salesAgent").is(':checked')) && (!(($("#salesSSN").is(':checked')) || ($("#salesNPN").is(':checked')) || ($("#salesAgentcode").is(':checked'))||  ($("#salesAgentPyroll").is(':checked'))))){
                    producerType="Agent";
                    $('.disabled_onload').attr('disabled', 'disabled');
                    $('.disabled_onload').parent().css("color", "#e1e1e1");
                    $('.disabled_onload').css("background-color", "#e1e1e1");
                    $('#salesNPN,#salesAgentcode,#salesAgentPyroll,#salesSSN').removeAttr("disabled");
                    $('#salesNPN,#salesAgentcode,#salesAgentPyroll,#salesSSN').parent().css("color", "#595959");
                    $('#salesTIN').parent().css("color", "#e1e1e1");
                    $(".product_type input[type='checkbox']").parent().css("color", "#e1e1e1");
                    $(".idtype_radio_button").prop('checked', false);
                    $("#salesIdvalue").show();
                    $("#salesIdvalueNPN").hide();
                    $("#salesIdvaluePayrollNo").hide();
                    $("#salesIdvalueAgentCode").hide();
                    $("#salesIdvalueTIN").hide();;
                    $("#salesIdvalueLastName").hide();		
                    $("#salesIdvalue").val("");
                    $(".overSelect").html("");
                    $("#checkboxes input[type='checkbox']").prop('checked', false);
                    $("#salesIdvalueSSN").hide();
                    $("#agentFirm").hide();
                    $(".validate_input,.validate_input_lastname").remove(); 
                    $("#valueError,#stateError,#productError,#agentFirm,#idTypeRadiobutton").hide();
                    $(".validate_input_lastname").remove();				
                    }	
            else if(($("#salesFirm").is(':checked') && (!(($("#salesAgentPyroll").is(':checked')) || ($("#salesTIN").is(':checked')))))){
                    producerType="Firm";
                    idType="TIN";
                    $('.disabled_onload').attr('disabled', 'disabled');
                    $('#salesTIN,#salesAgentPyroll').removeAttr("disabled");
                    $('.disabled_onload').css("background-color", "#e1e1e1");
                    $('#salesTIN,#salesAgentPyroll').parent().css("color", "#595959");
                    $('#salesNPN,#salesAgentcode,#salesSSN').parent().css("color", "#e1e1e1");
                    $(".product_type input[type='checkbox']").parent().css("color", "#e1e1e1");
                    $(".idtype_radio_button").prop('checked', false);
                    $("#salesIdvalue").show();
                    $("#salesIdvalueNPN").hide();
                    $("#salesIdvaluePayrollNo").hide();
                    $("#salesIdvalueAgentCode").hide();
                    $("#salesIdvalueTIN").hide();;
                    $("#salesIdvalueLastName").hide();
                    $("#salesIdvalue").val("");
                    $(".overSelect").html("");
                    $("#checkboxes input[type='checkbox']").prop('checked', false);
                    $("#salesIdvalueSSN").hide();
                    $("#agentFirm").hide();
                    $(".validate_input,.validate_input_lastname").remove(); 
                    $("#valueError,#stateError,#productError,#agentFirm,#idTypeRadiobutton").hide();
                    $(".validate_input_lastname").remove();
    
            }
            else if(($("#salesAgent").is(':checked')) && (($("#salesSSN").is(':checked')) )){
                    producerType="Agent";
                    idType="Last Name/SSN";

                    $('.disabled_onload').removeAttr("disabled");
                    $('#salesTIN').attr('disabled', 'disabled');
                    $(".product_type input[type='checkbox']").parent().css("color", "#595959");
                    $('.disabled_onload').css("background-color", "#fff");
					$('.disabled_onload.idtype_radio_button').css("background-color", "#595959");
                    $(".selectBox").css("color", "#595959");
                    $("#salesIdvalue").hide();
                    $("#salesIdvalueNPN").hide();
                    $("#salesIdvaluePayrollNo").hide();
                    $("#salesIdvalueAgentCode").hide();
                    $("#salesIdvalueTIN").hide();;
                    $("#salesIdvalueLastName").show();
                    $("#salesIdvalueSSN").show();
                    $("#salesIdvalueSSN").keypress(function() {
                        return !isNaN(parseInt(event.key));
                    });	
                    $("#idTypeRadiobutton").hide();
                    $("#valueError").hide();
                    $(".validate_input_lastname").remove();
                
            }
            else if(($("#salesAgent").is(':checked')) && (($("#salesNPN").is(':checked')) )){
                    producerType="Agent";
                    idType="NPN";
                    $('.disabled_onload').removeAttr("disabled");
                    $('#salesTIN').attr('disabled', 'disabled');
                    $(".product_type input[type='checkbox']").parent().css("color", "#595959");
                    $('.disabled_onload').css("background-color", "#fff");
					$('.disabled_onload.idtype_radio_button').css("background-color", "#595959");
                    $(".selectBox").css("color", "#595959");
                    $("#salesIdvalue").hide();
                    $("#salesIdvalueLastName").hide();
                    $("#salesIdvaluePayrollNo").hide();
                    $("#salesIdvalueAgentCode").hide();
                    $("#salesIdvalueTIN").hide();;
                    $("#salesIdvalueNPN").show();
                    $("#salesIdvalueNPN").keypress(function() {
                        return !isNaN(parseInt(event.key));
                    });	
                    $("#salesIdvalueSSN").hide();
                    $("#idTypeRadiobutton").hide();
                    $("#valueError").hide();
                    $(".validate_input_lastname").remove();
                    
                    
            }
            else if(($("#salesAgent").is(':checked')) && (($("#salesAgentcode").is(':checked')) )){
                    producerType="Agent";
                    idType="Agent Code";
                    $('.disabled_onload').removeAttr("disabled");
                    $(".product_type input[type='checkbox']").parent().css("color", "#595959");
                    $('.disabled_onload').css("background-color", "#fff");
					$('.disabled_onload.idtype_radio_button').css("background-color", "#595959");
                    $(".selectBox").css("color", "#595959");
                    $('#salesTIN').attr('disabled', 'disabled');
                    $("#salesIdvalue").hide();
                    $("#salesIdvalueLastName").hide();
                    $("#salesIdvaluePayrollNo").hide();
                    $("#salesIdvalueNPN").hide();
                    $("#salesIdvalueTIN").hide();;
                    $("#salesIdvalueAgentCode").show();
                    $("#salesIdvalueAgentCode").keypress(function() {
                        return !isNaN(parseInt(event.key));
                    });		
                    $("#salesIdvalueSSN").hide();
                    $("#idTypeRadiobutton").hide();
                    $("#valueError").hide();
                    $(".validate_input_lastname").remove();
                
            }
            else if(($("#salesAgent").is(':checked')) && (($("#salesAgentPyroll").is(':checked')))){
                    producerType="Agent";
                    idType="Payroll No";
                    $('.disabled_onload').removeAttr("disabled");
                    $('#salesTIN').attr('disabled', 'disabled');
                    $('#salesTIN').parent().css("color", "#e1e1e1");	
                    $('#salesNPN,#salesAgentcode,#salesSSN').parent().css("color", "#595959");
                    $('.disabled_onload').css("background-color", "#fff");
					$('.disabled_onload.idtype_radio_button').css("background-color", "#595959");
                    $(".product_type input[type='checkbox']").parent().css("color", "#595959");	  
                    $(".selectBox").css("color", "#595959");
                    $("#salesIdvalue").hide();
                    $("#salesIdvalueLastName").hide();
                    $("#salesIdvalueAgentCode").hide();
                    $("#salesIdvalueNPN").hide();
                    $("#salesIdvalueTIN").hide();;
                    $("#salesIdvaluePayrollNo").show();
                    $("#salesIdvaluePayrollNo").keypress(function() {
                        return !isNaN(parseInt(event.key));
                    });	
                    $("#salesIdvalueSSN").hide();
                    $("#idTypeRadiobutton").hide();
                    $("#valueError").hide();
                    $(".validate_input_lastname").remove();

            }
            else if(($("#salesFirm").is(':checked')) &&  (($("#salesAgentPyroll").is(':checked')))){
                    producerType="Firm";
                    idType="Payroll No";
                    $('.disabled_onload').removeAttr("disabled");
                    $('#salesSSN').attr('disabled', 'disabled');
                    $(".product_type input[type='checkbox']").parent().css("color", "#595959");
                    $('#salesTIN').parent().css("color", "#595959");
                    $('.disabled_onload').css("background-color", "#fff");
					$('.disabled_onload.idtype_radio_button').css("background-color", "#595959");
                    $('#salesNPN,#salesAgentcode,#salesSSN').parent().css("color", "#e1e1e1");
                    $(".selectBox").css("color", "#595959");
                    $('#salesNPN').attr('disabled', 'disabled');
                    $('#salesAgentcode').attr('disabled', 'disabled');
                    $("#salesIdvalue").hide();
                    $("#salesIdvalueLastName").hide();
                    $("#salesIdvalueAgentCode").hide();
                    $("#salesIdvalueNPN").hide();
                    $("#salesIdvalueTIN").hide();;
                    $("#salesIdvaluePayrollNo").show();
                    $("#salesIdvaluePayrollNo").keypress(function() {
                        return !isNaN(parseInt(event.key));
                    });
                    $("#salesIdvalueSSN").hide();
                    $("#idTypeRadiobutton").hide();
                    $("#valueError").hide();
                    $(".validate_input_lastname").remove();	
            }
            else if(($("#salesFirm").is(':checked')) && (($("#salesTIN").is(':checked')))){
                    producerType="Firm";
                    idType="TIN";
                    $('.disabled_onload').removeAttr("disabled");
                    $('#salesSSN').attr('disabled', 'disabled');
                    $(".product_type input[type='checkbox']").parent().css("color", "#595959");
                    $(".selectBox").css("color", "#595959");
                    $('.disabled_onload').css("background-color", "#fff");
					$('.disabled_onload.idtype_radio_button').css("background-color", "#595959");
                    $('#salesNPN').attr('disabled', 'disabled');
                    $('#salesAgentcode').attr('disabled', 'disabled');
                    $("#salesIdvalue").hide();
                    $("#salesIdvaluePayrollNo").hide();
                    $("#salesIdvalueLastName").hide();
                    $("#salesIdvalueAgentCode").hide();
                    $("#salesIdvalueNPN").hide();
                    $("#salesIdvalueTIN").show();			
                    $("#salesIdvalueTIN").keypress(function() {
                        return !isNaN(parseInt(event.key));
                    });
                    $("#salesIdvalueSSN").hide();
                    $("#idTypeRadiobutton").hide();
                    $("#valueError").hide();
                    $(".validate_input_lastname").remove();
                    
                
            }
	}); 


        //End code
    }
    //Add Functionality
    $(document).on( "click", "#addRequestAgent", function() {
		addappoimentstatussuperuser();	
	});

    /******************************************click on ADD  button ************************************************/
$(".display_table").hide();
var validateIsSubsetValue = function (originalArray, newArray) {
    var isSubSet = true;
    var originalArrayValue = originalArray.toString();
    var originalArraySplitValue = originalArrayValue.split(",");
    var originalArrayList =[];
    $(originalArraySplitValue).each(function(index,value){         
            originalArrayList.push(value.trim());            
    });
    //var newArraySplitValue = newArray.toString.split(",");
    var newArrayValue = newArray.toString();
    var newArraySplitValue = newArrayValue.split(",");
    var newArrayList =[];
    $(newArraySplitValue).each(function(index,value){        
        newArrayList.push(value.trim());        
	});
	// US30683 .. Converted to ECMA 5
	"use strict";
	isSubSet = originalArrayList.some(function (r) {
	return newArrayList.indexOf(r) >= 0;
	});
    //isSubSet = originalArrayList.some(r=> newArrayList.indexOf(r) >= 0);  // US30683    
    return isSubSet;
}
function checkIfDuplicateValue (tableRecords, newFormInput) {
    var commonValueFlag = false;
$(tableRecords).each(function(index,value){     
                   
        if(tableRecords[index].ProducerType==newFormInput.ProducerType &&
            tableRecords[index].IdType==newFormInput.IdType && 
            tableRecords[index].Idvalue.toString() ==newFormInput.Idvalue.toString() &&
            validateIsSubsetValue(tableRecords[index].States,newFormInput.States) &&
            validateIsSubsetValue(tableRecords[index].ProductTypeValue,newFormInput.ProductTypeValue)  
            ){
                commonValueFlag = true;
            }
    });
    return commonValueFlag;
};
 var checkcommonValueFlagForSubmit = function(tableRecords, newFormInput) {
		var commonValueFlagForSubmit = false;
		$(tableRecords).each(function(index,value){

		
			if(tableRecords[index].lastName==newFormInput.lastName &&
				tableRecords[index].lastFourSSN==newFormInput.lastFourSSN && 
				tableRecords[index].npn==newFormInput.npn  &&
				tableRecords[index].tin ==newFormInput.tin  &&
                tableRecords[index].requestType ==newFormInput.requestType  &&
               	tableRecords[index].payrollNumber==newFormInput.payrollNumber  &&
				tableRecords[index].agentCode ==newFormInput.agentCode  &&
				tableRecords[index].statesTerritories.toString() ==newFormInput.statesTerritories.toString() &&
            	tableRecords[index].productTypes.toString() ==newFormInput.productTypes.toString() 
				){
					commonValueFlagForSubmit = true;
			}
		});
		return commonValueFlagForSubmit;
	};

function getinputvalueforADDandSUbmit(){

		if($("#salesIdvalueSSN").is(':visible')){
			var idvalue= $("#salesIdvalueLastName").val()+"/"+ $("#salesIdvalueSSN").val();
			var lastName = $("#salesIdvalueLastName").val();
            var lastFourSsn =$("#salesIdvalueSSN").val();
            validateLnameSSN();

			}
			else if($("#salesIdvalueTIN").is(':visible')){
			var idvalueTIN= $("#salesIdvalueTIN").val();
            var tin=idvalueTIN;
			var getidvalue = idvalueTIN.slice(5, 9);
			var concateidvalue = "XX-XXX";
			var idvalue = concateidvalue.concat(getidvalue);
			validateTIN();
			}
			else if($("#salesIdvalueNPN").is(':visible')){
			var idvalue= $("#salesIdvalueNPN").val();
            var npn=idvalue;
			validateNPN();
			}
			else if($("#salesIdvalueAgentCode").is(':visible')){
			var idvalue= $("#salesIdvalueAgentCode").val();
            var agentcode=idvalue;
			validateAgentCode();
			}
			else if($("#salesIdvaluePayrollNo").is(':visible')){
			var idvalue= $("#salesIdvaluePayrollNo").val();
            var payrollNo=idvalue;
			validatePayroll();
			}
			else if($("#salesIdvalueLastName").is(':visible')){
				validateLastName();
			}

			 if($('.agent_firm').is(':checked')){ 
                 var RequestType= $('input[type=radio].agent_firm:checked').val();
                 if(RequestType =="agent"){          
			      getrequesttype = "IND";
   			     }
                else if(RequestType =="firm"){
                 getrequesttype = "ORG";
                }

            }



            var valuefromInputforSubmit={};

             //for submit
            var valuefromInputforSubmit={			
                "lastName":lastName,
                "lastFourSSN":lastFourSsn,
                "npn":npn,
                "tin":tin,
                "payrollNumber":payrollNo,
                "agentCode":agentcode,
                "requestType":getrequesttype,
                "statesTerritories":newStatesvalue,
                "productTypes":productType,
			}	
    		var commonValueFlagForSubmit = checkcommonValueFlagForSubmit(getvaluefromInputforSubmit, valuefromInputforSubmit);
			//alert("commonValueFlagForSubmit = " +commonValueFlagForSubmit);
			if(commonValueFlagForSubmit){
				//$("#dublicateError").show();
				return false;
			}
			else{

			     getvaluefromInputforSubmit.push(valuefromInputforSubmit);


			}
               //console.log(getvaluefromsubmit);
          // console.log("submitvalue"+ JSON.stringify(getvaluefromInputforSubmit));
          // console.log("submitvalueobject"+JSON.stringify(valuefromInputforSubmit));




}

function addappoimentstatussuperuser(){

         if($("#salesIdvalueSSN").is(':visible')){
			 validateLnameSSN();
			 validateLastName();
			}
			else if($("#salesIdvalueTIN").is(':visible')){
				validateTIN();
			}
			else if($("#salesIdvalueNPN").is(':visible')){
				validateNPN();
			}
			else if($("#salesIdvalueAgentCode").is(':visible')){
				validateAgentCode();
			}
			else if($("#salesIdvaluePayrollNo").is(':visible')){
				validatePayroll();
			}

		if (validate()) {
		if($("#salesIdvalueSSN").is(':visible')){
			var idvalue= $("#salesIdvalueLastName").val()+"/"+ $("#salesIdvalueSSN").val();
			validateLnameSSN();
			}
			else if($("#salesIdvalueTIN").is(':visible')){
			var idvalueTIN= $("#salesIdvalueTIN").val();
			var getidvalue = idvalueTIN.slice(5, 9);
			var concateidvalue = "XX-XXX";
			var idvalue = concateidvalue.concat(getidvalue);
			validateTIN();
			}
			else if($("#salesIdvalueNPN").is(':visible')){
			var idvalue= $("#salesIdvalueNPN").val();
			validateNPN();
			}
			else if($("#salesIdvalueAgentCode").is(':visible')){
			var idvalue= $("#salesIdvalueAgentCode").val();
			validateAgentCode();
			}
			else if($("#salesIdvaluePayrollNo").is(':visible')){
			var idvalue= $("#salesIdvaluePayrollNo").val();
			validatePayroll();
			}
			else if($("#salesIdvalueLastName").is(':visible')){
				validateLastName();
			}

		if(!$(".validate_input").is(':visible')){
			if(!$(".validate_input_lastname").is(':visible')){

		$(".display_table").show();
		$('.add_table').children("tbody").children("tr").children("th").show();	

        if (newStatesvalue.length > 2) {
			statesval = newStatesvalue.slice(0, 54);
			statesval = statesval.join(", ");
            statesvalue=[];
            statesvalue.push(statesval);

			}
			else{
                 statesvalue=[];
				 statesvalue.push(newStatesvalue);
			}
			var checkProducttype = productType;
			var getProductType = checkProducttype.toString();

		if (productType.length > 1) {
			productTypeValue = productType.slice(0, 3);
			if(getProductType == "LTC Rider,Variable Life"){
			//console.log(getProductType);

			productTypeValue = productTypeValue.join(",</br> ");

			}else{
			productTypeValue = productTypeValue.join(", ");
		    }

			}
			else{
				productTypeValue = productType;
			}
			var checkgetvaluefromInput={};
			var getvaluefromInput={
				"ProducerType": producerType,
				"IdType": idType,
				"Idvalue": idvalue,
				"States": statesvalue,
				"ProductTypeValue": productTypeValue,
			}
             //
			var commonValueFlag = checkIfDuplicateValue(getvaluefromsubmit, getvaluefromInput);
		//	console.log(commonValueFlag);
			if(commonValueFlag){
				$("#dublicateError").show();
				return false;
			}
			else{
                 count++; 
                 getinputvalueforADDandSUbmit();
				 $("#dublicateError").hide();
				 getvaluefromsubmit.push(getvaluefromInput);	
			}


		 $('.add_table tbody').empty();
		 $('.add_table tbody').append('<tr>'+
                               ' <th></th>'+
                                '<th>TYPE</th>'+
                                '<th>ID TYPE</th>'+
                                '<th>ID</th>'+
                               ' <th>STATE</th>'+
                               ' <th>PRODUCT TYPE</th>'+
                                '<td><input type="button" value="DELETE ALL" id="deleteAllAgent" class="btn btn-secondary btn-lg" ></td>'+
                                '</tr>');
		for (i = 0; i < getvaluefromsubmit.length; i++) {   
		/*if(getvaluefromsubmit[i].ProducerType==getvaluefromInput.ProducerType && getvaluefromsubmit[i].ProductTypeValue==getvaluefromInput.ProductTypeValue){
			alert("hii");
		} */	
		var tablecount = "";
		tablecount = i+1;
		$('.add_table tbody').append('<tr>'+
                               ' <td>'+ tablecount +'</td>'+
                                '<td>'+ getvaluefromsubmit[i].ProducerType+'</td>'+
                                '<td>'+ getvaluefromsubmit[i].IdType +'</td>'+
                                '<td>'+ getvaluefromsubmit[i].Idvalue+'</td>'+
                               ' <td>'+ getvaluefromsubmit[i].States +'</td>'+
                               ' <td>'+ getvaluefromsubmit[i].ProductTypeValue +'</td>'+
                                '<td><input type="button" value="DELETE" id="deleteAgent" class="btn btn-secondary btn-lg deleteAgent" ></td>'+
                                '</tr>');
		
		}
		

	    if(count !=20){
	    	
	    	$('#multipleError').hide();
	    	$("#addRequestAgent").removeAttr("disabled");

	    }
	    else
	    {	    	
	    	$('#multipleError').show();
	    	$("#addRequestAgent").attr('disabled', 'disabled');

	    }

	    if(count == 1){
	     		$('.add_table').show();	 	
		 }

	    else if(count == 2){
	    	$('.add_table').children("tbody").children("tr:last").after('<tr class="append_submit">'+
                               ' <td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                               ' <td></td>'+
                               ' <td></td>'+
                                '<td><input type="button" value="SUBMIT" id="submitRequestAgentAppend" class="btn btn-secondary btn-lg" /><img src="/etc/designs/JHINS/images/ajax-loader.gif"  style="display:none;height:50px"   alt="Loading-Image"  class="img-responsive overlayAppoiment"></td>'+
                                '</tr>');

	    }
	    else if(count > 2){
	    	$(".append_submit").remove();
	    	$('.add_table').children("tbody").children("tr:last").after('<tr class="append_submit">'+
                               ' <td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                               ' <td></td>'+
                               ' <td></td>'+
                                '<td><input type="button" value="SUBMIT" id="submitRequestAgentAppend" class="btn btn-secondary btn-lg" /><img src="/etc/designs/JHINS/images/ajax-loader.gif"  style="display:none;height:50px"  alt="Loading-Image"  class="img-responsive overlayAppoiment"></td>'+
                                '</tr>');
		}


			updateToCLearState();

}

}
}

       
}
/********************************************************call Add function*****************************/


    // Validate Function


   function validate() {
       //producer support
       if(userRoleVal == "Producer" || userRoleVal == "ProducerSupport"){
		validateState();
		validateProduct();
           if(($("#stateError").is(':visible'))||($("#productError").is(':visible'))){
			return false;
           }
           return true;
       }
       else if(userRoleVal == "FirmSupport" || userRoleVal == "SuperUser_SN"){
		//FirmSupport Start
		validateState();
		validateProduct();
		validateIDValueRadioButton();
		validateFirmAgent();
		if($("#salesIdvalue").is(':visible')){
				validateIdValue();
			}
	if($("#stateError").is(':visible')||$("#productError").is(':visible')||$("#valueError").is(':visible')||$("#agentFirm").is(':visible')||$("#idTypeRadiobutton").is(':visible')){
		return false;

	    }
		
		return true;
	}
   }
	/*validation on blur*/

	function validateState(){
			if($("#checkboxes input[type='checkbox']").is(':checked')){
				$("#stateError").hide();
			}
			else{
				$("#stateError").show();
				return false;
			} 

	}
	function validateIdValue(){
			var idvalue = $("#salesIdvalue").val();
			if(idvalue.length == 0){
				$("#valueError").show();
				return false;
			}
			else{
				$("#valueError").hide();
				
			}
			
	}
	function validateProduct(){
			/*if($(".product_type input[type='checkbox']").is(':checked')){
				$("#productError").hide();
			}
			else{
				$("#productError").show();
				return false;
			} */
		var productType = "";
        $("input[name=productType]:checked").each(function () {
			if (productType == "") {
				productType = productType + this.value;
			}
			else {
				productType = productType + "," + this.value;
			}
		});
        if (productType == 0) {
			//alert("At least one state must be selected.");
			//$("#stateError").show();
			$("#productError").show();
			return false;
		}
        if (productType == "") {
			//alert("At least one product must be selected.");
			$("#productError").show();
			return false;
		}
			
	} 
	function validateIDValueRadioButton(){
			if($(".idtype_radio_button").is(':checked')){
				$("#idTypeRadiobutton").hide();
			}
			else{
				$("#idTypeRadiobutton").show();
				return false;
			}
			
	}
	function validateFirmAgent(){
			if($(".agent_firm").is(':checked')){
				$("#agentFirm").hide();
			}
			else{
				$("#agentFirm").show();
				return false;
			}

	}
	function validateLnameSSN(){
			var ssnReg = /^\d{4}$/;
	        var salesIdvalueSSN = $( "#salesIdvalueSSN" ).val();
	        if (ssnReg.test(salesIdvalueSSN)) {
	            $(".validate_input").remove();
	        }	
	        else{
	        	if($('.validate_input').length < 1){
	        	$("#salesIdvalueSSN").after('<div class="validate_input">SSN must be 4 digits</div>');
	        	}
				return false;
	        }
	}
	function validateTIN(){
			var tinReg = /^\d{9}$/;
	        var salesIdvalueTIN = $("#salesIdvalueTIN" ).val();
	        if (tinReg.test(salesIdvalueTIN)) {
	            $(".validate_input").remove();
	        }	
	        else{
	        	if($('.validate_input').length < 1){
	        	$("#salesIdvalueTIN").after('<div class="validate_input">TIN must be 9 digits</div>');
	        	}
				return false;
	        }
	}

	function validateNPN(){
	        var npnReg = /^[1-9]{1}[0-9]{4,9}$/;
	        var salesIdvalueNPN = $( "#salesIdvalueNPN" ).val();
	        if (npnReg.test(salesIdvalueNPN)) {
	           $(".validate_input").remove();  
	        }	
	        else{
	        	if($('.validate_input').length < 1){
	        	$("#salesIdvalueNPN").after('<div class="validate_input">NPN must be between 5 and 10 digits with no leading 0</div>');
	        	}
				return false;
	        }
	}
	function validateAgentCode(){
	        var agentReg = /^[1-9]{1}[0-9]{2,6}$/;
	        var salesIdvalueAgentCode = $( "#salesIdvalueAgentCode" ).val();
	        if (agentReg.test(salesIdvalueAgentCode)) {
	           $(".validate_input").remove();  
	        }	
	        else{
	        	if($('.validate_input').length < 1){
	        	$("#salesIdvalueAgentCode").after('<div class="validate_input">Agent Code must be between 3 and 6 digits with no leading 0</div>');
	        	}
				return false;
	        }
	}
	function validatePayroll(){
	        var payrollReg = /^[1-9]{1}[0-9]{0,6}$/;
	        var salesIdvaluePayrollNo = $( "#salesIdvaluePayrollNo" ).val();
	        if (payrollReg.test(salesIdvaluePayrollNo)) {
	           $(".validate_input").remove();  
	        }	
	        else{
	        		if($('.validate_input').length < 1){
	        			$("#salesIdvaluePayrollNo").after('<div class="validate_input">Payroll No must be between 1 and 6 digits with no leading 0</div>');
	        		}
	        		
				return false;
	        }
	}
	function validateLastName(){
			var salesIdvalueLastName = $("#salesIdvalueLastName").val();
			if(salesIdvalueLastName.length > 0){
				 $(".validate_input_lastname").remove();
			}
			else{
	        		if($('.validate_input_lastname').length < 1){
	        			$("#salesIdvaluePayrollNo").after('<div class="validate_input_lastname">This field is required</div>');
	        		}
	        		
				return false;
	        }

	       
	}


	$(document).on( "click", ".sales_Idvalue", function() {	
		 $(".validate_input").remove(); 
		 $("#valueError").hide();
		 });	
	$(document).on( "click", ".sales_IdvalueLast_name", function() {	
		 $(".validate_input_lastname").remove();
		 $("#valueError").hide();	
	});
	/****************************************************validation END***********************************************************************/

/******************************************click on clear button ************************************************/
$("#clearRequestAgent").click(function () {
       if(userRoleVal == "Producer" || userRoleVal == "ProducerSupport"){
		states = [];
        newStates = []; 
        $(".overSelect").html("");
		$('input[name="productType"]').attr('checked', false);
		$('input[name="statesCheck"]').attr('checked', false);
       // $("div.overSelect").text("");
		$("#stateError").hide();
		$("#productError").hide();
        $(".overlay").hide();
        }else if(userRoleVal == "FirmSupport" || userRoleVal == "SuperUser_SN"){
			updateToCLearState();
        }
	});
/******************************************click on delete all button ************************************************/

	$(document).on( "click", "#deleteAllAgent", function() {	
		$('.add_table').children("tbody").children("tr").children("td").remove();
		$('.add_table').children("tbody").children("tr").children("th").hide();
		count=0;
        getvaluefromsubmit=[];
		});
/******************************************click on delete  button ************************************************/
	$(document).on( "click", ".deleteAgent", function() {
		 var putindexvalue=$(this).parent("td").parent("tr").children("td:first").text();
		 var removeindexvalue=putindexvalue-1;
		 getvaluefromsubmit.splice(removeindexvalue,1);
         getvaluefromInputforSubmit.splice(removeindexvalue,1);
 		 $(this).parent("td").parent("tr").remove();
		 count--; 
		 /*remove table and add resuffled table*/
		 $('.add_table tbody').empty();
		 $('.add_table tbody').append('<tr>'+
                               ' <th></th>'+
                                '<th>TYPE</th>'+
                                '<th>ID TYPE</th>'+
                                '<th>ID</th>'+
                               ' <th>STATE</th>'+
                               ' <th>PRODUCT TYPE</th>'+
                                '<td><input type="button" value="DELETE ALL" id="deleteAllAgent" class="btn btn-secondary btn-lg" ></td>'+
                                '</tr>');
		for (i = 0; i < getvaluefromsubmit.length; i++) {    	
		var tablecount = "";
		tablecount = i+1;
		$('.add_table tbody').append('<tr>'+
                               ' <td>'+ tablecount +'</td>'+
                                '<td>'+ getvaluefromsubmit[i].ProducerType+'</td>'+
                                '<td>'+ getvaluefromsubmit[i].IdType +'</td>'+
                                '<td>'+ getvaluefromsubmit[i].Idvalue+'</td>'+
                               ' <td>'+ getvaluefromsubmit[i].States +'</td>'+
                               ' <td>'+ getvaluefromsubmit[i].ProductTypeValue +'</td>'+
                                '<td><input type="button" value="DELETE" id="deleteAgent" class="btn btn-secondary btn-lg deleteAgent" ></td>'+
                                '</tr>');
		
		}
	   
		 if(count < 20){
	     	$('#multipleError').hide();
	    	$("#addRequestAgent").removeAttr("disabled");
	    	$("#clearError").hide();
	     }
		 if(count <2){

		 	if($(".append_submit").is(':visible')){
	     		$(".append_submit").remove();
	     	}
		 	
		 }
         if(count == 1){
	     		$('.add_table').show();	 	
		 }
        else if(count < 1){	
	     		
	     		if($(".add_table").is(':visible')){
	     		$('.add_table').hide();
	     	}
        }

	    else if(count == 2){
	    	$('.add_table').children("tbody").children("tr:last").after('<tr class="append_submit">'+
                               ' <td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                               ' <td></td>'+
                               ' <td></td>'+
                                '<td><input type="button" value="SUBMIT" id="submitRequestAgentAppend" class="btn btn-secondary btn-lg" /><img src="/etc/designs/JHINS/images/ajax-loader.gif"  style="display:none;height:50px"   alt="Loading-Image"  class="img-responsive overlayAppoiment"></td>'+
                                '</tr>');

	    }
	    else if(count > 2){
	    	$(".append_submit").remove();
	    	$('.add_table').children("tbody").children("tr:last").after('<tr class="append_submit">'+
                               ' <td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                                '<td></td>'+
                               ' <td></td>'+
                               ' <td></td>'+
                                '<td><input type="button" value="SUBMIT" id="submitRequestAgentAppend" class="btn btn-secondary btn-lg" /><img src="/etc/designs/JHINS/images/ajax-loader.gif"  style="display:none;height:50px"  alt="Loading-Image"  class="img-responsive overlayAppoiment"></td>'+
                                '</tr>');
		}



	    
	     	
	     		     	
		 	

		});


/******************************************click on delete  button End ************************************************/
/*This two function is getting called you can remove once you will not call in jsp*/
/* This is clear function which will bring back to onload state****************************/
function updateToCLearState() {
	        $('.disabled_onload').attr('disabled', 'disabled');
			$("#salesIdvalue").val("");
			$(".overSelect").html("");
			$("#checkboxes input[type='checkbox']").prop('checked', false);
			$(".product_type  input[type='checkbox']").prop('checked', false);
			$(".radio_button ").prop('checked', false);
			$("#salesIdvalue").attr("placeholder", "");
			$("#salesIdvalueSSN").hide();
			$("#salesIdvalue").show();
			$("#salesIdvalueNPN").hide();
			$("#salesIdvaluePayrollNo").hide();
			$("#salesIdvalueAgentCode").hide();
			$("#salesIdvalueTIN").hide();
			$('.disabled_onload').css("background-color", "#e1e1e1");
			$("#salesIdvalueLastName").hide();
			$(".disabled_onload.sales_Idvalue").css("color","#595959");
			$(".disabled_onload.sales_IdvalueLast_name").css("color","#595959");
			$('.disabled_onload').attr('disabled', 'disabled');
			$('.disabled_onload').parent().css("color", "#e1e1e1");
			$('.disabled_onload').css("background-color", "#e1e1e1");
			$(".validate_input,.validate_input_lastname ").remove();
	        $("#valueError,#stateError,#productError,#agentFirm,#idTypeRadiobutton").hide();
			$("#clearError").hide();
			$("#dublicateError").hide();  //fix for DE5315
            $(".overlayAppoiment").hide();
            $("#submitRequestAgent").show();
		    $("#submitRequestAgentAppend").show();
	        
	        
}
/* This is clear function which will bring back to onload state****************************/
function callsubmitvalue() {
    if(count < 1 ){
	  getinputvalueforADDandSUbmit();
	 // alert("submitvalue"+ JSON.stringify(getvaluefromInputforSubmit));
    }
    else if(count< 20){
         if($('.agent_firm').is(':checked')) { 
            if($("#salesIdvalueSSN").is(':visible')){
			var idvalue= $("#salesIdvalueLastName").val()+"/"+ $("#salesIdvalueSSN").val();
			var lastName = $("#salesIdvalueLastName").val();
            var lastFourSsn =$("#salesIdvalueSSN").val();
            validateLnameSSN();

			}
			else if($("#salesIdvalueTIN").is(':visible')){
			var idvalueTIN= $("#salesIdvalueTIN").val();
            var tin=idvalueTIN;
			var getidvalue = idvalueTIN.slice(5, 9);
			var concateidvalue = "XX-XXX";
			var idvalue = concateidvalue.concat(getidvalue);
			validateTIN();
			}
			else if($("#salesIdvalueNPN").is(':visible')){
			var idvalue= $("#salesIdvalueNPN").val();
            var npn=idvalue;
			validateNPN();
			}
			else if($("#salesIdvalueAgentCode").is(':visible')){
			var idvalue= $("#salesIdvalueAgentCode").val();
            var agentcode=idvalue;
			validateAgentCode();
			}
			else if($("#salesIdvaluePayrollNo").is(':visible')){
			var idvalue= $("#salesIdvaluePayrollNo").val();
            var payrollNo=idvalue;
			validatePayroll();
			}
			else if($("#salesIdvalueLastName").is(':visible')){
				validateLastName();
			}
            var getrequesttype ="";

                 var RequestType= $('input[type=radio].agent_firm:checked').val();
                 if(RequestType =="agent"){          
			      getrequesttype = "IND";
   			     }
                else if(RequestType =="firm"){
                 getrequesttype = "ORG";
                }



            var valuefromInputforSubmit={};

             //for submit
            var valuefromInputforSubmit={			
                "lastName":lastName,
                "lastFourSSN":lastFourSsn,
                "npn":npn,
                "tin":tin,
                "payrollNumber":payrollNo,
                "agentCode":agentcode,
                "requestType":getrequesttype,
                "statesTerritories":newStatesvalue,
                "productTypes":productType,
			}	
    		var commonValueFlagForSubmit = checkcommonValueFlagForSubmit(getvaluefromInputforSubmit, valuefromInputforSubmit);
			//alert("commonValueFlagForSubmit = " +commonValueFlagForSubmit);
			if(commonValueFlagForSubmit){
				//$("#dublicateError").show();
                var obj = new Object();
                obj.userRole = userRoleVal;
                obj.searchRequests = getvaluefromInputforSubmit;
               // alert(getvaluefromInputforSubmit);
                firmSupportData = JSON.stringify(obj);
                //alert(firmSupportData);
                //console.log(firmSupportData);
                callFirmSupportAjax(firmSupportData);
				return false;
			}
			else{
			     getvaluefromInputforSubmit.push(valuefromInputforSubmit);

	 		}
         }else{
              // alert("submitvalue"+ JSON.stringify(getvaluefromInputforSubmit));

         }

    }

	//$(this).next(".overlayAppoiment").show();
	//$(this).hide();
    var obj = new Object();
    obj.userRole = userRoleVal;
    obj.searchRequests = getvaluefromInputforSubmit;
   // alert(getvaluefromInputforSubmit);
    firmSupportData = JSON.stringify(obj);
    //alert(firmSupportData);
   // console.log(firmSupportData);
    callFirmSupportAjax(firmSupportData);



}

    $(document).on( "click", "#submitRequestAgent,#submitRequestAgentAppend", function() {

       if(userRoleVal == "Producer" || userRoleVal == "ProducerSupport"){
		       if (validate()) {
    
                    $("#appointmentStatusInput").hide();
                    $("#appointmentStatusProgress").show();
                    var obj = new Object();
                    obj.profileId = profileIdVal;
                    obj.userRole = userRoleVal;
                    obj.states = newStatesvalue ;
                    obj.products = productType;
                    formData = JSON.stringify(obj);
                    callAjax(formData);

         		}
        	}else if(userRoleVal == "FirmSupport" || userRoleVal == "SuperUser_SN"){
			if(count < 1){
	       		if($("#salesIdvalueSSN").is(':visible')){
			 validateLnameSSN();
			 validateLastName();
			}
			else if($("#salesIdvalueTIN").is(':visible')){
				validateTIN();
			}
			else if($("#salesIdvalueNPN").is(':visible')){
				validateNPN();
			}
			else if($("#salesIdvalueAgentCode").is(':visible')){
				validateAgentCode();
			}
			else if($("#salesIdvaluePayrollNo").is(':visible')){
				validatePayroll();
			}
			
			
			 		   
			if (validate()) {
				if(!$(".validate_input").is(':visible')){
					if(!$(".validate_input_lastname").is(':visible')){
					  $(this).next(".overlayAppoiment").show();
					  $(this).hide();
					callsubmitvalue();
		        }
		      }
		   }


	       }

			else if(count < 20){

			if(($("#salesFirm").is(':checked')) || (($("#salesAgent").is(':checked')))){
				
			if($("#salesIdvalueSSN").is(':visible')){
			 validateLnameSSN();
			 validateLastName();
			}
			else if($("#salesIdvalueTIN").is(':visible')){
				validateTIN();
			}
			else if($("#salesIdvalueNPN").is(':visible')){
				validateNPN();
			}
			else if($("#salesIdvalueAgentCode").is(':visible')){
				validateAgentCode();
			}
			else if($("#salesIdvaluePayrollNo").is(':visible')){
				validatePayroll();
			}
			
			
			 		   
			if (validate()) {
				if(!$(".validate_input").is(':visible')){
					if(!$(".validate_input_lastname").is(':visible')){
                         $(this).next(".overlayAppoiment").show();
					  $(this).hide();
					callsubmitvalue();
			
			
		        }
		      }
		   }
		}else{
             $(this).next(".overlayAppoiment").show();
					  $(this).hide();
              callsubmitvalue();

			}
	    }else{
			  
	    	   if(($("#salesFirm").is(':checked')) || (($("#salesAgent").is(':checked')))){
	    	   		$("#clearError").show();
	    		    $("#multipleError").hide();
	    	   }else{
                    $(this).next(".overlayAppoiment").show();
					  $(this).hide();
					callsubmitvalue();
			
		        }

	    }



            }


	}); 



	/*$( "#submitRequestAgentAppend" ).click(function() {
        $("#appointmentStatusInput").hide();
		$("#appointmentStatusProgress").show();
        $("#appointmentStatusResultsmock").show();
    }); */


	$("#newSearch1, #newSearch2").click(function () {
        if(userRoleVal == "Producer" || userRoleVal == "ProducerSupport"){
            states = [];
            newStates = [];
            $('input[name="productType"]').attr('checked', false);
            $('input[name="statesCheck"]').attr('checked', false);
            document.getElementsByClassName("overSelect")[0].innerHTML = "";
            $("#appointmentStatusResults").hide();
            $("#appointmentStatusUnavailable").hide();
            $("#appointmentStatusInput").show();
            $("#submitRequestAgent").show();
            table.destroy();
            $(".overlayAppoiment").hide();
            $("#dataTable").children(".datatable_tbody").empty();   // DE4923 Defect Fix
        }else if(userRoleVal == "FirmSupport" || userRoleVal == "SuperUser_SN"){
			$("#appointmentStatusResults").hide();
            $("#appointmentStatusResultsmock").hide();
            $("#appointmentStatusUnavailable").hide();
            $("#appointmentStatusUnavailable").hide();
            $("#appointmentStatusInput").show();
            $('.disabled_onload').attr('disabled', 'disabled');
			$("#salesIdvalue").val("");
			$(".overSelect").html("");
            table.destroy();
			$("#checkboxes input[type='checkbox']").prop('checked', false);
			$(".product_type  input[type='checkbox']").prop('checked', false);
			$(".radio_button ").prop('checked', false);
			$("#salesIdvalue").attr("placeholder", "");
			$("#salesIdvalueSSN").hide();
			$("#appointmentStatusInput").show();
			$("#appointmentStatusResults").hide();
			$('.add_table').children("tbody").children("tr").children("td").remove();
		    $('.add_table').children("tbody").children("tr").children("th").hide();
            $("#dataTable").children(".datatable_tbody").empty();
		    $('#multipleError').hide();
	    	$("#addRequestAgent").removeAttr("disabled");
		    $(".validate_input").remove(); 
		    $("#valueError").hide();	
		    $("#stateError").hide();
		    $("#submitRequestAgent").show();
		    $("#submitRequestAgentAppend").show(); 
		     $(".overlayAppoiment").hide();
		    $('.disabled_onload').attr('disabled', 'disabled');
		    $('.disabled_onload').parent().css("color", "#e1e1e1");
            getvaluefromsubmit=[];
            getvaluefromInputforSubmit=[];
		    updateToCLearState();
		    count=0;
        }
	});
 var table;
	$("#refineSearch1, #refineSearch2").click(function () {
        if(userRoleVal == "Producer" || userRoleVal == "ProducerSupport"){
            $("#appointmentStatusResults").hide();
            $("#appointmentStatusUnavailable").hide();
            $("#appointmentStatusInput").show();
            $("#submitRequestAgent").show();
            $(".overlayAppoiment").hide();
             table.destroy();
            $("#dataTable").children(".datatable_tbody").empty();  // DE4923 Defect Fix
        } else if(userRoleVal == "FirmSupport" || userRoleVal == "SuperUser_SN"){
			$("#appointmentStatusResults").hide();
            $("#appointmentStatusResultsmock").hide();
            $("#appointmentStatusUnavailable").hide();
            $("#appointmentStatusUnavailable").hide();
            $("#appointmentStatusInput").show();
            table.destroy();
            if(count < 1){
            /*Integration from mock up*/
            getvaluefromsubmit=[];
            getvaluefromInputforSubmit=[];
            }
            $("#appointmentStatusResults").hide();
            $("#appointmentStatusInput").show();
            $("#submitRequestAgent").show();
            $("#submitRequestAgentAppend").show(); 
            $("#dataTable").children(".datatable_tbody").empty();
             $(".overlayAppoiment").hide();
            if(count !=20){
                
                $('#multipleError').hide();
                $("#addRequestAgent").removeAttr("disabled");
                
            }
            else
            {
                
                $('#multipleError').show();
                $("#addRequestAgent").attr('disabled', 'disabled');
    
            }

        }
	});
	
	$('input[name="productType"]').click(function () {
		$("#checkboxes").hide();
		$("#productError").hide();
	});
	$('input[name="statesCheck"]').click(function () {
		$("#stateError").hide();
	});
	
	/*// commented for DE4928 defect Fix
	 $(document).mousedown(function(e) {
	    var container = $("#checkboxes");
	    // if the target of the click isn't the container nor a descendant of the container
	    if (!container.is(e.target) && container.has(e.target).length === 0) {
	       $("#checkboxes").hide();
	    }
	});*/
/***************************to export table contentin csv *************************************/
$('#exportResult').click(function() {
  var titles = [];
  var data = [];
  var headertitles = [];
  var headerdata = [];
  var headercurrenttime = [];
  var headercurrenttimedata = [];
  var requestVal=$("#apptRequestID").text();
  var reqIDnum = requestVal.match(/[\d\.]+/g);
   // alert(requestVal);
    //alert(reqIDnum);
  var fileName = "AppointmentStatusReport_" + reqIDnum +'.csv';
  var csvtitles = [];
  
  var newDate = new Date();
  newDate.setDate(newDate.getDate());
    function pad(val){
    return (val<10) ? '0' + val : val;
  }

 // document.getElementById('DateReceived').innerHTML="Received:"+today;
   var sysDate = pad((newDate.getMonth() + 1)) + '-' + pad(newDate.getDate()) + '-' + pad(newDate.getFullYear()) ;
   var localTime = pad(newDate.getHours())+':'+ pad(newDate.getMinutes())+':'+pad(newDate.getSeconds());


  document.getElementById('DateReceived').innerHTML = "Received: " + sysDate +" at " + localTime;
  //csvtitles = "Appointment Status Report";
  /*
   * Get the table headers, this will be CSV headers
   * The count of headers will be CSV string separator
   */
  $('#dataTableCSVHeader1 th').each(function() {
    headertitles.push($(this).text());
   // console.log($(this).text());
    
  });
 
  $('#dataTableCSVHeader1 td').each(function() {
    headerdata.push($(this).text());
    //console.log($(this).text());
    
  });

  $('#dataTableCSVHeader2 th').each(function() {
    headercurrenttime.push($(this).text());
   // console.log($(this).text());
    
  });
 
  $('#dataTableCSVHeader2 td').each(function() {
    headercurrenttimedata.push($(this).text());
   // console.log($(this).text());
    
  });

  $('#dataTable th').each(function() {
    titles.push($(this).text());
    
  });

  /*
   * Get the actual data, this will contain all the data, in 1 array
   */
  $('#dataTable td').each(function() {
    data.push($(this).text());

  });
  
  /*
   * Convert our data to CSV string
   * 
   *    */

  var CSVString = prepCSVRow(headertitles, headertitles.length, '');
  CSVString = prepCSVRow(headerdata, headertitles.length, CSVString);
  
 CSVString = prepCSVRow(headercurrenttime, headercurrenttime.length, CSVString);
 CSVString = prepCSVRow(headercurrenttimedata, headercurrenttime.length, CSVString+'\n');
 
  CSVString  = prepCSVRow(titles, titles.length, CSVString);
  CSVString = prepCSVRow(data, titles.length, CSVString);
 
  /*
   * Make CSV downloadable
   */
  if (navigator.msSaveBlob)  // For IE 10+
  {
  var downloadLink = document.createElement("a");
  var blob = new Blob([CSVString], {
    "type": "text/csv;charset=utf8;"});
    navigator.msSaveOrOpenBlob(blob, fileName); 
  }
  else{
  var downloadLink = document.createElement("a");
  var blob = new Blob(["\ufeff", CSVString]);
  var url = URL.createObjectURL(blob);
  downloadLink.href = url;
  downloadLink.download = fileName;
  /*
   * Actually download CSV
   */
 document.body.appendChild(downloadLink);
 downloadLink.click();
 document.body.removeChild(downloadLink);}

});

   /*
* Convert data array to CSV string
* @param arr {Array} - the actual data
* @param columnCount {Number} - the amount to split the data into columns
* @param initial {String} - initial string to append to CSV string
* return {String} - ready CSV string
*/
function prepCSVRow(arr, columnCount, initial) {
  var row = ''; // this will hold data
  var delimeter = ','; // data slice separator, in excel it's `;`, in usual CSv it's `,`
  var newLine = '\r\n'; // newline separator for CSV row

  /*
   * Convert [1,2,3,4] into [[1,2], [3,4]] while count is 2
   * @param _arr {Array} - the actual array to split
   * @param _count {Number} - the amount to split
   * return {Array} - splitted array
   */
  function splitArray(_arr, _count) {
    var splitted = [];
    var result = [];
    _arr.forEach(function(item, idx) {
      if ((idx + 1) % _count === 0) {
        splitted.push(item);
        result.push(splitted);
        splitted = [];
      } else {
        splitted.push(item);
      }
    });
    return result;
  }
  var plainArr = splitArray(arr, columnCount);
  // don't know how to explain this
  // you just have to like follow the code
  // and you understand, it's pretty simple
  // it converts `['a', 'b', 'c']` to `a,b,c` string
  plainArr.forEach(function(arrItem) {
    arrItem.forEach(function(item, idx) {
      row += item + ((idx + 1) === arrItem.length ? '' : delimeter);
    });
    row += newLine;
  });
  return initial + row;
}
/***************************to export table contentin csv end here*************************************/

/********************Upgrade the select box in alphabetical order****************/
$("#SelectAll").change(function(){ //"select all" change 
$(".states_value").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
if($("#checkboxes input[type='checkbox'].selectall").is(':checked')){
	newStatesvalue=[];
$("#checkboxes input[type='checkbox'].states_value" ).each(function() {
			    var getId = [];
                var getvalue  =[];
			    getId.push($(this).attr( "id" ));
                newStatesvalue.push($(this).val());

			    selectAllValue.push(getId);
			});
        //	console.log(newStatesvalue);
			if (selectAllValue.length > 2) {
			newStates = selectAllValue.slice(0, 2);
			newStates = newStates.join(", ");
			newStates = newStates + " ..."
			}
		document.getElementsByClassName("overSelect")[0].innerHTML = newStates;	
		var value = $(".overSelect").text();
        value=value.replace( /,\s*/g, ', ' );
        $(".overSelect").text(value);

	}
	else{
		document.getElementsByClassName("overSelect")[0].innerHTML = "";	
	}
});

//".checkbox" change 
var getcheckboxsId = [];
var getcheckboxsValue = [];
var getcheckboxsIdUnique = [];
$('.states_value').change(function(){ 
	newStates=[];
    newStatesvalue=[];
	getcheckboxsId=[];
    getcheckboxsValue=[];
	//console.log(newStates);
		$("#checkboxes input[type='checkbox'].states_value:checked" ).each(function() {	
					    
			    getcheckboxsId.push($(this).attr( "id" ));
                getcheckboxsValue.push($(this).val());
			    getcheckboxsId.sort();
			   	
		});
		newStatesvalue=getcheckboxsValue;
    //console.log(newStatesvalue);
		if (getcheckboxsId.length > 2) {
			newStates = getcheckboxsId.slice(0, 2);
			newStates = newStates.join(", ");
			newStates = newStates + " ..."
			}
		else{
			newStates=getcheckboxsId;
		}
	document.getElementsByClassName("overSelect")[0].innerHTML = newStates;
	     var value = $(".overSelect").text();
        value=value.replace( /,\s*/g, ', ' );
        $(".overSelect").text(value);

	
	//uncheck "select all", if one of the listed checkbox item is unchecked
if(false == $(this).prop("checked")){ //if this item is unchecked
	  $("#SelectAll").prop('checked', false); //change "select all" checked status to false
	
}
//check "select all" if all checkbox items are checked
if ($('.states_value:checked').length == $('.states_value').length ){
    $("#SelectAll").prop('checked', true);
	newStatesvalue=[];
	if($("#checkboxes input[type='checkbox'].selectall").is(':checked')){
		$("#checkboxes input[type='checkbox'].states_value" ).each(function() {
			    var getId = [];
                var getvalue  =[];
			    getId.push($(this).attr( "id" ));
                newStatesvalue.push($(this).val());

			    selectAllValue.push(getId);
                
			});
			if (selectAllValue.length > 2) {
			newStates = selectAllValue.slice(0, 2);
			newStates = newStates.join(", ");
			newStates = newStates + " ..."
			}
		document.getElementsByClassName("overSelect")[0].innerHTML = newStates;	
		var value = $(".overSelect").text();
        value=value.replace( /,\s*/g, ', ' );
        $(".overSelect").text(value);

		
	}
}
}); 
/*onclick of prioduct type we get the value*/    
$(".product_type input[type='checkbox']").change(function(){ 
		productType=[];
		$(".product_type input[type='checkbox']:checked" ).each(function() {	
					    
			    productType.push($(this).val());;
			 
			   	
		});
		//console.log(productType);
	});

/*************Upgrade the select box in alphabetical order code end here****************/


function callAjax(formData){
				$.ajax({  
			         type: "POST",  
			         url: "/bin/sling/appointmentstatus",  
			         data: {formData: formData},
			         dataType: 'json',
			         cache: false,
			         beforeSend: function(){
			         	$(".overlayAppoiment").show();

			            $("#submitRequestAgent").hide();
			            $("#appointmentStatusInput").show();
			            $("#appointmentStatusResults").hide();
			           },
						complete: function(){
                       $(".overlayAppoiment").hide();

			            $("#submitRequestAgent").show();
			            $("#appointmentStatusInput").hide();
			           // $("#appointmentStatusResults").show();
			         },
			         success: function(resp){  
			        	 var reqId;
			        	 var details;
			        	 var statusCodeInArray = ["400","403","500","Default"];
                         var codeInArray = ["6001","6003","7001","8001"];
                         var termsconditions;
                         var statusCode;
                         var code;
			         	
                         if(null != resp.StatusCode){
                             statusCode = resp.StatusCode;
                          }
                           if(resp.Code){
                               code = resp.Code;
                           }
			             //US10771 Error message display
                           if($.inArray(statusCode,statusCodeInArray) != -1 || $.inArray(code,codeInArray) != -1){
                               $("#appointmentStatusProgress").hide();
                               $("#appointmentStatusResults").hide();
                               $("#appointmentStatusUnavailable").show();
                              if(null != resp.Details && undefined != resp.Details){
                                if(null != resp.Details.RequestId){
 	                                reqId = resp.Details.RequestId;
 	                                $("#apptRequestIDVal").html("Request Id: "+reqId);
 	                            }
                            }
                                if(null != resp.Message){
                                         $('#errorDescription').html(resp.Message+" ("+code+")");
                                 }
                          }
			             // Success Response and Name Not Found Response display.
                        if(($.inArray(statusCode,statusCodeInArray) == -1 &&  $.inArray(code,codeInArray) == -1) && null != resp.Details && undefined != resp.Details){
                        	$("#appointmentStatusResults").show();
                            $("#appointmentStatusUnavailable").hide();
			             var i;
			             details = resp.Details.Representative;
			             var termsconditions = details.TermsAndConditionsStatus;
			             if(null != resp.Details && undefined != resp.Details){
			     			
				                if(null != resp.Details.RequestId){
				                     reqId = resp.Details.RequestId;
				                     $("#apptRequestID").html("Request Id: "+reqId);
				                 }
				            }
			              if("Y" == termsconditions){
			                   termsconditions = "YES";
			                }else if("N" == termsconditions){
			                	 termsconditions = "NO";
			                }else if("NOT_FOUND" == termsconditions){
			                   termsconditions = "N/A";
			               }
			              // DE4923 Defect Fix
			              if ($('.datatable_thead').length < 1) {
				  			     $('#dataTable').append('<thead class="datatable_thead"></thead>')
				                  $('.datatable_thead').append('<tr class="tableHeaderRow">'+
                                                               ' <th>NAME</th>'+
				                                        '<th>T&amp;C</th>'+
				                                        '<th>AML COMP EFF DATE</th>'+
				                                        '<th>STATE</th>'+
				                                       ' <th>COMPANY</th>'+
				                                       ' <th>PRODUCT TYPE</th>'+
				                                        '<th>APPT EFF DATE</th>'+
				                                        '<th>COMMENT</th>'+
				                                        '</tr>');             
				 				$('.datatable_thead').after('<tbody class="datatable_tbody"></tbody>');
				         }    // DE4923 Defect Fix End    
			    var tr;
			
				var appointment = resp.Details.Representative.Appointments;
				var comment = resp.Comments; 
				var commentvalue;
				var stateval = [];
			    var stateval1 = [];
			    for (i = 0; i < appointment.length; i++) {
			        /// var stateval = appointment[i-1].StateTerritory ;
			    	var code = appointment[i].CommentCode;

                    if(comment[code] !== undefined){
						commentvalue = comment[code];
                    }else{
						commentvalue = code;
                    }
			         var stateval1 = appointment[i].StateTerritory ;
			         stateval.push(stateval1);
			         /*remove dublicate value*/
			      
			         		tr = $('<tr/>');
			             	tr.append("<td>" + details.Name + "</td>");
			          		tr.append("<td>" + termsconditions + "</td>");
			          		tr.append("<td>" + details.AmlTrainingCompletionDate + "</td>");
			          		tr.append("<td>" + appointment[i].StateTerritory + "</td>");
			                tr.append("<td>" + appointment[i].Company + "</td>");
			                tr.append("<td>" + appointment[i].ProductType + "</td>");
			                tr.append("<td>" + appointment[i].EffectiveDate + "</td>");
			                tr.append("<td>" + commentvalue + "</td>");
			                $('.datatable_tbody').append(tr);
			            }
					/*$('table tr').each(function(index, item){
						if($(item).find("td:nth-child(4)").text() != $(item).prev().find("td:nth-child(4)").text()){
							$(item).prev().find("td").css("borderBottom", "1px #e1e1e1 solid");
							}
					});*/ // */Result table Comments end

                            table= $('#dataTable').DataTable( {
			                       "pagingType": "simple_numbers",
                                   "lengthMenu": [50,100,150],
                                     "info": false,
                                   "language": {
                                    "paginate": {
                                     next: '&raquo;',
                                     previous: '&laquo;'
                                    }
                                  }
			               });

			        }else{
			            $("#appointmentStatusProgress").hide();
						$("#appointmentStatusResults").hide();
			            $("#appointmentStatusUnavailable").show();
			        }
			
			      }, 
			     error: function(e){  
			      //  console.log("error"+e);
			           event.preventDefault();
			     } 
			
				}); 
							
}


function callFirmSupportAjax(firmSupportData){
				$.ajax({  
			         type: "POST",  
			         url: "/bin/sling/appointmentstatus",  
			        data: {formDataArray: firmSupportData},
			         dataType: 'json',
			         cache: false,
			         beforeSend: function(){
			         	//$(this).next(".overlayAppoiment").show();
                        //$(".overlayAppoiment").show();
					    //$(this).hide();
			            //$("#submitRequestAgent").hide();
			            $("#appointmentStatusInput").show();
			            $("#appointmentStatusResults").hide();
			           },
						complete: function(){
					    $(this).next(".overlayAppoiment").show();
                        $(".overlayAppoiment").hide();
					    $(this).show();
			            $("#submitRequestAgent").show();
			            $("#appointmentStatusInput").hide();
			           // $("#appointmentStatusResults").show();
			         },
			         success: function(resp){  
			        	 var reqId;
			        	 var details;
			        	 var statusCodeInArray = ["400","403","500","Default"];
                         var codeInArray = ["6001","7001","6003","8001"];
                         var termsconditions;
                         var statusCode;
                         var code;
			         	
                         if(null != resp.StatusCode){
                             statusCode = resp.StatusCode;
                          }
                           if(resp.Code){
                               code = resp.Code;
                           }
                         var comment = resp.Comments; 
			             //US10771 Error message display
                           if($.inArray(statusCode,statusCodeInArray) != -1 || $.inArray(code,codeInArray) != -1){
                               $("#appointmentStatusProgress").hide();
                               $("#appointmentStatusResults").hide();
                               $("#appointmentStatusUnavailable").show();
                              if(null != resp.Details && undefined != resp.Details){
                                if(null != resp.Details.RequestId){
 	                                reqId = resp.Details.RequestId;
 	                                $("#apptRequestIDVal").html("Request Id: "+reqId);
 	                            }
                            }
                                if(null != resp.Message){
                                         $('#errorDescription').html(resp.Message+" ("+code+")");
                                 }
                          }
			             // Success Response and Name Not Found Response display.
                        if(($.inArray(statusCode,statusCodeInArray) == -1 &&  $.inArray(code,codeInArray) == -1) && null != resp.Details && undefined != resp.Details){
                        	$("#appointmentStatusResults").show();
                            $("#appointmentStatusUnavailable").hide();
                            // DE4923 Defect Fix
			             if ($('.datatable_thead').length < 1) {
				  			     $('#dataTable').append('<thead class="datatable_thead"></thead>')
				                  $('.datatable_thead').append('<tr class="tableHeaderRow">'+
                                                       ' <th>NAME</th>'+
                                                        ' <th>ID TYPE</th>'+
                                                        ' <th>ID</th>'+
                                                        '<th>T&amp;C</th>'+
                                                        '<th>AML COMP EFF DATE</th>'+
                                                        '<th>STATE</th>'+
                                                       ' <th>COMPANY</th>'+
                                                       ' <th>PRODUCT TYPE</th>'+
                                                        '<th>APPT EFF DATE</th>'+
                                                        '<th>COMMENT</th>'+
                                                        '</tr>');                
				 				$('.datatable_thead').after('<tbody class="datatable_tbody"></tbody>');
				         }    // DE4923 Defect Fix End  

			             var i,j;
			             var details = resp.Details.Representatives;
                            //console.log("Representative Array"+details);
                            if(null != resp.Details && undefined != resp.Details){

				                if(null != resp.Details.RequestId){
				                     reqId = resp.Details.RequestId;
				                     $("#apptRequestID").html("Request Id: "+reqId);
				                 }
				            }
				for (i = 0; i < details.length; i++) {

			            var termsconditions = details[i].TermsAndConditionsStatus;
						var name = details[i].Name;
                        var idType = details[i].IDType;
                        var id;
                        if(idType === "TIN"){
                        	idVal = details[i].ID;
                        	id = "xx-xxx"+idVal.substring(5, 9);
                        }else{
                        	id = details[i].ID ;	
                        }
						var amlTraining = details[i].AmlTrainingCompletionDate ;
                    	//console.log("termsconditions:"+termsconditions+"name: " + name + "idType:"+idType +"id:"+ id +"amlTraining:"+ amlTraining);
			              if("Y" == termsconditions){
			                   termsconditions = "YES";
			                }else if("N" == termsconditions){
			                	 termsconditions = "NO";
			                }else if("NOT_FOUND" == termsconditions){
			                   termsconditions = "N/A";
			               }

			    var tr;
			
				var appointment = details[i].Appointments;
				var commentvalue;
				var stateval = [];
			    var stateval1 = [];

			    for (j = 0; j < details[i].Appointments.length; j++) {
			        /// var stateval = appointment[i-1].StateTerritory ;
			    	var code = appointment[j].CommentCode;
					//console.log("comment code "+ code);
                   if(comment[code] !== undefined){
						commentvalue = comment[code];
                    }else{
						commentvalue = code;
                    } 
			         var stateval1 = appointment.StateTerritory ;
			         stateval.push(stateval1);
			         /*remove dublicate value*/
			      
			       tr = $('<tr/>');
			             	tr.append("<td >" + name + "</td>");
                            tr.append("<td >" + idType + "</td>");
                            tr.append("<td style='word-wrap:break-word;' >" + id + "</td>");
                            tr.append("<td >" + termsconditions + "</td>");
                            tr.append("<td >" + amlTraining + "</td>");
                            tr.append("<td >" + appointment[j].StateTerritory + "</td>");
                            tr.append("<td >" + appointment[j].Company + "</td>");
                            tr.append("<td >" + appointment[j].ProductType + "</td>");
                            tr.append("<td >" + appointment[j].EffectiveDate + "</td>");
                            tr.append("<td >" + commentvalue + "</td>");
                            $('.datatable_tbody').append(tr);
			            }
                }
					/*$('table tr').each(function(index, item){
						if($(item).find("td:nth-child(4)").text() != $(item).prev().find("td:nth-child(4)").text()){
							$(item).prev().find("td").css("borderBottom", "1px #e1e1e1 solid");
							}
					});*/ // */Result table Comments end
							table= $('#dataTable').DataTable( {
			                       "pagingType": "simple_numbers",
                                   "lengthMenu": [50,100,150],
                                   "info": false,
                                   "language": {
                                    "paginate": {
                                     'next': '&raquo;',
                                     'previous': '&laquo;'
                                    }
                                  }
			               });

			        }else{
			              $("#appointmentStatusProgress").hide();
						 $("#appointmentStatusResults").hide();
			            $("#appointmentStatusUnavailable").show();
			        }
			
			      }, 
			     error: function(e){  
			       // console.log("error"+e);
			           event.preventDefault();
			     } 
			
				}); 


}
/*For datatable customization*/

$(document).on("click","a",function() {
    if($(' #dataTable_paginate').find('#dataTable_previous').hasClass("disabled")){
	$(' #dataTable_paginate').find('#dataTable_previous').hide();
}
else{
	$(' #dataTable_paginate').find('#dataTable_previous').show();
}
if($(' #dataTable_paginate').find('#dataTable_next').hasClass("disabled")){
	$(' #dataTable_paginate').find('#dataTable_next').hide();
}
else{
	$(' #dataTable_paginate').find('#dataTable_next').show();
}
    });
 /*For datatable customization*/

});     
$( document ).ready(function() {
   if($(' #dataTable_paginate').find('#dataTable_previous').hasClass("disabled")){
	$(' #dataTable_paginate').find('#dataTable_previous').hide();
}
else{
	$(' #dataTable_paginate').find('#dataTable_previous').show();
}
if($(' #dataTable_paginate').find('#dataTable_next').hasClass("disabled")){
	$(' #dataTable_paginate').find('#dataTable_next').hide();
}
else{
	$(' #dataTable_paginate').find('#dataTable_next').show();
}
});