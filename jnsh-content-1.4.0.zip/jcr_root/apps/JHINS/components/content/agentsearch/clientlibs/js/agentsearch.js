/*To Design the agent search Pages*/
$( document ).ready(function() {
    $(".agentsearch").parent().parent().parent().addClass("agentseach-contentblock");
    $(".agentseach-contentblock").parent().addClass("agentseach-container");
});

