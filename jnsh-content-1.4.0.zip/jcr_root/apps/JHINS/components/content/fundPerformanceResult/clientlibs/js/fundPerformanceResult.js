var productCode;
var companyCode;
var productName;
var rider;
var productSeries;
var footNote;
var productcodeList="";
var Products=[];
var productTypeList=new Array();
var versionList=new Array();
var riderList=new Array();  
var companycodeList="";
var idate;
var firmId;
function jsFunction(value)
{    
    var functionality=value;
    if(value=="Monthly")
    {	
        fundperformace(productCode,companyCode,footNote,firmId);
        $("#quaterlyperformanceResult").hide();
        $("#dailyUnitValues").hide();
    }
    else if(value=="Quaterly")
    {   
        $("#dailyUnitValues").hide();
        quaterlyfundperformace(productCode,companyCode,footNote,firmId);
        $("#monthlyperformanceResult").hide();
        $("#dailyUnitValues").hide();
    }
    else if(value =="DailyUnit")         
    {	
        $("#datepicker").val("");
        $(".validate_input").remove();
        $(".validate_input_gray").remove();
        var resultType="byProductDailyUnitValue";
        var date =null;
        dailyunitvalues(productCode,companyCode,resultType,date,footNote,firmId);
        $("#monthlyperformanceResult").hide();
        $("#quaterlyperformanceResult").hide();
    }
}
$(document).ready(function(){
    
    var validDate = true;
    var validateHistoricalDateValue;
    function validateHistoricalDate(){
        var validateHistoricalDate = /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/
        var getdate = $( "#datepicker" ).val();
        var convertdate=getdate.split("/");
        var str1=convertdate[1]; //month
        var str2=convertdate[0]; //day
        var str3=convertdate[2]; //year
        validateHistoricalDateValue = str1 +"/"+ str2 +"/"+ str3;
        if (validateHistoricalDate.test(validateHistoricalDateValue)) {
            $(".validate_input").remove();
            $(".validate_input_gray").remove();
            return checkifFutureDate();
        }	        	
        else{
            $(".validate_input").remove();
            $(".validate_input_gray").remove();
            if($('.validate_input').length < 1){
                $("#datepicker").parent().parent().append('<div class="validate_input">Incorrect date format. Please re-enter date in mm/dd/yyyy format.</div>');
                validDate=false;
            }
            return validDate;
        }
    }
    //firmId info 

    var pathName = window.location.pathname;
	    if(pathName.startsWith("/financial-professionals/PRD")){
			firmId = "PRD";
	    }else if(pathName.startsWith("/financial-professionals/MGP")){
			firmId = "MGP";
	    }else if(pathName.startsWith("/financial-professionals/EDJ")){
	        firmId = "EDJ";
        }else{
			firmId = "JHINS";
        }
    function checkifFutureDate(){
        var Startdate = $( "#datepicker" ).val();
        if(Startdate.length != 0 && Startdate !='') {
            var start_date = Startdate.split('/');

            start_date=start_date[0]+"/"+start_date[1]+"/"+start_date[2];
            var a = new Date(start_date);
            var today = new Date();
            var day = today.getDate();
            var mon = today.getMonth()+1;
            var year = today.getFullYear();
            today = (mon+"/"+day+"/"+year);
            var today = new Date(today);
            if(today.getTime() < a.getTime() )
            {
                $("#datepicker").parent().parent().append('<div class="validate_input">No data available for future date. Please select any date in the past.</div>');
                return false;
            } else {
                $(".validate_input").remove();
                return true;
            }
        }
        
    }
    /*Validation for Product anmd rider*/
    var RiderValue;
    var VersionValue;
    var ProductValue;
					/*on change of product*/
					$('#product').change(function () {
                        checkifProductValue();

				    });
				    /*on change of product End*/
				    /*on change of version */
					$('#version').change(function () {
                        checkifVersionValue();

					});
					/*on change of version END*/
                      /*on change of version */
                    $('#rider').change(function () {
                        checkifRiderValue();
                    });
     function checkifVersionValue(){
         VersionValue=true;
        if($("#version").val() =="") {
            if ($(".validate_input_version").length < 1){
                  $("#version").parent().append('<div class="validate_input_version"> Please select version.</div>');
             }

                VersionValue=false;
            } else {
                $(".validate_input_version").remove();
                VersionValue=true;
            }
            return VersionValue;
        
    }

    function checkifRiderValue(){
		RiderValue=true;
        if($("#rider").val() =="") {
             if ($(".validate_input_rider").length < 1){
                $("#rider").parent().append('<div class="validate_input_rider"> Please select rider.</div>');
             }
               RiderValue=false;
            } else {
                $(".validate_input_rider").remove();
               RiderValue=true;
            }
		return RiderValue;

    }
     function checkifProductValue(){
         ProductValue=true;
        if($("#product").val() =="") {
             if ($(".validate_input_product").length < 1){
                $("#product").parent().append('<div class="validate_input_product"> Please select product.</div>');
             }
                ProductValue=false;
            } else {
                $(".validate_input_product").remove();
                ProductValue=true;
            }
            return ProductValue;
        
    }

    $("#datepicker").datepicker({
        format: 'mm-dd-yyyy',
        maxDate: new Date() ,
        changeYear:true,
        autoclose: true
    });
   /*get proctuct code and country code*/

    $(".fundinformation").on("click", function(){
		/*Code to hide the call out div when there is nothing authored*/             
		   if($(".callout.callout-fundperformance").children().length > 0 ) {
               	$('.callout.callout-fundperformance').css('display','block');
				$('.callout.callout-fundperformance').parent().css('display','block');
			}else{
				$('.callout.callout-fundperformance').css('display','none');
				$('.callout.callout-fundperformance').parent().css('display','none');
			}
        /*Code to hide the call out div when there is nothing authored code end*/
        checkifProductValue();
        if($("#version").is(':visible')){
            checkifVersionValue(); 
        }
        if($("#rider").is(':visible')){
            checkifRiderValue();
        }


        if((VersionValue == true) || (RiderValue == true) || (ProductValue == true)){
        $(".byProductSelction").val("Monthly"); 
        function contains(arr,element){
						for(var i=0; i<arr.length; i++){
							if(arr[i] === element)
								return true;
						}
						return false;
					}    
                        var selProductType=$('li.active a#myLink').text();
				    	var selProduct=$('#product').val();  
				    	var selVersion = $("#version").is(':visible')? $('#version').val():"Not Applicable";
             			var selVersionEmpty = $("#version").is(':visible')? $('#version').val():"";
				    	var selRider = $("#rider").is(':visible')? $('#rider').val():"Not Applicable";
                        var selRiderEmpty = $("#rider").is(':visible')? $('#rider').val():"";
                        console.log(selProductType);
                        console.log(selProduct);
                        console.log(selVersion);
                        console.log(selRider);

				    	
						var j = 0;
						productcodeList="";
						for(var i=0; i < Products.length ; i++){
							if((Products[i].productCategory == selProductType && Products[i].name == selProduct && ((Products[i].version == selVersion)||(Products[i].version == selVersionEmpty))&& ((Products[i].rider == selRider)||(Products[i].rider == selRiderEmpty)))){

									productcodeList = Products[i].productCode;
                            }



						}
                        companycodeList="";
						for(var i=0; i < Products.length ; i++){
							if((Products[i].productCategory == selProductType && Products[i].name == selProduct &&((Products[i].version == selVersion)||(Products[i].version == selVersionEmpty))&& ((Products[i].rider == selRider)||(Products[i].rider == selRiderEmpty)))){

									companycodeList = Products[i].companyCode;


							}
						}
                         productSeries ="";
                        for(var i=0; i < Products.length ; i++){
                            if((Products[i].productCategory == selProductType && Products[i].name == selProduct && ((Products[i].version == selVersion)||(Products[i].version == selVersionEmpty))&& ((Products[i].rider == selRider)||(Products[i].rider == selRiderEmpty)))){

                                    productSeries  = Products[i].series;
                            }



                        }
                        
                        footNote="";
                        for(var i=0; i < Products.length ; i++){
                            if((Products[i].productCategory == selProductType && Products[i].name == selProduct && ((Products[i].version == selVersion)||(Products[i].version == selVersionEmpty))&& ((Products[i].rider == selRider)||(Products[i].rider == selRiderEmpty)))){

                                    footNote = Products[i].footNotes;


                            }
                        }
                        
                       productName=selProduct;
                       rider=selRider;
                       if(rider == "Not Applicable"){
							rider = "";
                        }
						/*For putting [] outside the footnotes*/
					   var getsupfootnotes;
                       if(footNote!=""){
                            var startingbracket="[";
                            var endingbracket="]";
						    var makegetsuptext=startingbracket.concat(footNote);
                            var footnotes=makegetsuptext.concat(endingbracket);
                           getsupfootnotes=footnotes;

                        }else{
							getsupfootnotes=footNote;
                        }
						/*For putting [] outside the footnotes*/
						if((rider =="")||(rider =="Not Applicable")){

                        var headerVal = productName+rider+getsupfootnotes.sup()+'';
						}else{
						var headerVal = productName+' '+rider+getsupfootnotes.sup()+'';
						}
                       
                       var headersubVal = "("+productSeries.toUpperCase()+")";
            		   $(".resultPage_header").html(headerVal);
                       $(".resultPage_header_sub").html(headersubVal);
            
                       productCode =productcodeList;
                       companyCode=companycodeList;                   
                       fundperformace(productCode,companyCode,footNote,firmId);
           }
    });
    $(".historicalDailyUnit").on("click", function(){
        idate = $( "#datepicker" ).val();
        var invalidDateFormat=validateHistoricalDate();
        if(!invalidDateFormat === false){            
            $(".validate_input").remove();
             $(".validate_input_gray").remove();
            $("#dailyUnitValues").hide();
            var resultType="byProductHistoricalDailyUnitValue";
            var date=$("#datepicker").val();
            var AsOFdateTemp = dailyunitvalues(productCode,companyCode,resultType,date,footNote);
            if(!$(".validate_input").is(':visible')){
                if(typeof AsOFdateTemp != "undefined"){
                    if (AsOFdateTemp != idate){
                        if($('.validate_input').length < 1){
                            $(".validate_input").remove();
                            $("#datepicker").parent().parent().append('<div class="validate_input_gray">There were no values for the date you requested. The values shown are for the last market valuation.</div>');
                        }
                    }        	
                    else{
                        $(".validate_input").remove();

                    }
                }

            }
            
        }
    });
    

    $( "ul.nav > li" ).on( "click", function() {
        $("#datepicker").val("");
        $("#fundByproduct").show();
        $("#epvul").hide();
        $("#monthlyperformanceResult").hide();
        $("#quaterlyperformanceResult").hide();
        $("#dailyUnitValues").hide();
        $("#fundResultUnavailable").hide();
        $("#dailyUnitUnavailable").hide();
        $('#resultable').children("tbody").children("tr").remove();
        $('#quaterlyresultable').children("tbody").children("tr").remove();
        $('#dailyunitvalueresultable').children("tbody").children("tr").remove();
    });
	/*For mobile tab the changes are here*/
    $( ".panel-heading >h4.panel-title >a" ).on( "click", function() {  
        $("#fundByproduct").css("display", "block");
        $("#fundPerformanceResult ").css("display", "none");
        $("#epvul").hide();
        $("#monthlyperformanceResult").hide();
        $("#quaterlyperformanceResult").hide();
        $("#dailyUnitValues").hide();
        $("#fundResultUnavailable").hide();
        $("#dailyUnitUnavailable").hide();
        $('#resultable').children("tbody").children("tr").remove();
        $('#quaterlyresultable').children("tbody").children("tr").remove();
        $('#dailyunitvalueresultable').children("tbody").children("tr").remove();
    });
    /*For mobile tab the changes are here*/
	/*Get csv file for mothly quaterly and daily performance*/

							$('.download-csv').click(function() {
                                  var titles = [];
                                  var data = [];
                                  var producttitles = [];
                                  var headerdata = [];
                                  var headerparadata=[];
                                  var footerpara=[];
                                  var footerpara1=[];
                                  var getproductSeries;
                                if(companycodeList=='JHUSA'){
                                  getproductSeries = 0;
                                }else{
                                 getproductSeries = 94;

                                }
                                 if($("#monthlyperformanceResult").is(':visible')){
                                     var monthvalue = "MONTH";
                                  }else if($("#quaterlyperformanceResult").is(':visible')){
                                       var monthvalue = "QUARTER";
                                  }
                                else if($("#dailyUnitValues").is(':visible')){
                                       var monthvalue = AsOFdateTemp;
                                  }
                                  var fileName = "FundValues_"+ productCode + "_" + getproductSeries + "_" + monthvalue +'.csv';
							/*get row one common for all the three fund*/
                                   $('.resultPage_header').each(function() {
                                       if($(".resultPage_header").is(':visible')){
                                        var getheader= $(this).text();
                                        var getheadernext= $(this).next().text();
                                        var headerspace = " ";
                                        getheader=getheader.concat(headerspace)
                                        getheader=getheader.concat(getheadernext); 
                                       	getheader=getheader.replace(",", " ");
                                        getheader=getheader.replace(",", " ");
                                        getheader=getheader.replace(/[^A-Z a-z , [0-9] ]/g, " ");
                                        producttitles.push(getheader);
                                       }
                                    
                                  });
                            /*get row one common for all the three fund*/
                            /*get row two and three  for all the three fund*/
                                 if($("#monthlyperformanceResult").is(':visible')){


                                  $('#monthlyperformanceResult').each(function() {
                                        var getpara= $(this).children().children("h4").next("p").text();
                                        getpara=getpara.replace(",", " ");
                                        headerparadata.push(getpara);
                                
                                  });

                                  }else if($("#quaterlyperformanceResult").is(':visible')){

                                  $('#quaterlyperformanceResult').each(function() {
                                        var getpara= $(this).children().children("h4").next("p").text();
                                        getpara=getpara.replace(",", " ");
                                        headerparadata.push(getpara);
                                
                                  });
                                  }
                                else if($("#dailyUnitValues").is(':visible')){

                                  $('#dailyUnitValues').each(function() {
                                        var getpara= $(this).children().children("h4").next("p").text();
                                        getpara=getpara.replace(",", " ");
                                        headerparadata.push(getpara);
                                
                                  });
                                  }
                                /*get row two and three  for all the three fund*/

                               /*get row 5 and 6  for all the three fund*/
                                if($("#resultable").is(':visible')){
                                  $('#resultable tr th').each(function() {
                                    titles.push($(this).text().toUpperCase());
                                  });
                                
                                  /*
                                   * Get the actual data, this will contain all the data, in 1 array
                                   */
                                    if($("#resultable tr").hasClass("colorband")){
                                        $("#resultable tr.colorband ").children("td.remove-this").remove();
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#resultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                
                                    }
                                    if($("#resultable tr").hasClass("intable-footnotes")){
                                        $("#resultable tr.intable-footnotes ").children("td.remove-footnotes").remove();
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#resultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                    }
                                  $('#resultable tr td').each(function() {
                                     if($(this).children("a").length > 0){
                                         var gettd= $(this).children("a").text();
                                         var gettdsub= $(this).children("sup").text();
                                         var gettdsmall= $(this).children("small").text();
                                         var getspace = " ";
                                         gettd=gettd.concat(getspace);
										 gettd=gettd.concat(gettdsub);
                                         gettd=gettd.concat(getspace);
                                         gettd=gettd.concat(gettdsmall);


                                      }else{
                                         var gettd= $(this).text();
                                      }
                                       gettd=gettd.replace(",", " ");
                                       data.push(gettd);
                                  });


                                    $('.foot-notes').each(function() { 
                                     var getfootnotenumber = $(this).text();
                                     var getgootnotesdesp = $(this).next(".foot-notes-para").children().text().replace(/,/g ,"");
                                     getgootnotesdesp=getgootnotesdesp.replace(/[^A-Z a-z [0-9]]/g, "");
                                        var getspace=" ";
									 getfootnotenumber=getfootnotenumber.concat(getspace);
                                     var getcsvfootnotes = getfootnotenumber.concat(getgootnotesdesp);
                                     getcsvfootnotes=getcsvfootnotes.trim();
                                     var separatefpptnotes= '\n';
                                     var getseparatefpptnotes=getcsvfootnotes.concat(separatefpptnotes);
                                     footerpara1.push(getseparatefpptnotes);
                                     });

                                     var footparaheader = footerpara1.toString().replace(/,/g ,"");
                                     footerpara.push(footparaheader);
                                        console.log(footparaheader);

                                }else if($("#quaterlyresultable").is(':visible')){
                                  $('#quaterlyresultable tr th').each(function() {
                                    titles.push($(this).text().toUpperCase());
                                  });
                                
                                  /*
                                   * Get the actual data, this will contain all the data, in 1 array
                                   */
                                    if($("#quaterlyresultable tr").hasClass("colorband")){
                                        $("#quaterlyresultable tr.colorband ").children("td.remove-this").remove();
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#quaterlyresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");

                                
                                    }
                                    if($("#quaterlyresultable tr").hasClass("intable-footnotes")){
                                        $("#quaterlyresultable tr.intable-footnotes ").children("td.remove-footnotes").remove();
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#quaterlyresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");

                                    }
                                  $('#quaterlyresultable tr td').each(function() {
                                     if($(this).children("a").length > 0){
                                         var gettd= $(this).children("a").text();
                                         var gettdsub= $(this).children("sup").text();
                                         var gettdsmall= $(this).children("small").text();
                                         var getspace = " ";
                                         gettd=gettd.concat(getspace);
										 gettd=gettd.concat(gettdsub);
                                         gettd=gettd.concat(getspace);
                                         gettd=gettd.concat(gettdsmall);


                                      }else{
                                         var gettd= $(this).text();
                                      }
                                       gettd=gettd.replace(",", " ");
                                       data.push(gettd);
                                  });
                                


                                    $('.foot-notes').each(function() { 
                                     var getfootnotenumber = $(this).text();
                                     var getgootnotesdesp = $(this).next(".foot-notes-para").children().text().replace(/,/g ,"");
                                     getgootnotesdesp=getgootnotesdesp.replace(/[^A-Z a-z [0-9]]/g, "");
                                     var getspace=" ";
									 getfootnotenumber=getfootnotenumber.concat(getspace);
                                     var getcsvfootnotes = getfootnotenumber.concat(getgootnotesdesp);
                                     getcsvfootnotes=getcsvfootnotes.trim();
                                     var separatefpptnotes= '\n';
                                     var getseparatefpptnotes=getcsvfootnotes.concat(separatefpptnotes);
                                     footerpara1.push(getseparatefpptnotes);
                                     });

                                     var footparaheader = footerpara1.toString().replace(/,/g ,"");
                                     footerpara.push(footparaheader);
                                }else if($("#dailyunitvalueresultable").is(':visible')){
									 /*code to remove the hader od manager and net change row*/
									$tableth = $('#dailyunitvalueresultable thead tr').clone();
									$tableth.find("th.table-daily-header").text("Values as of");
                                    $tableth.find("th.table-daily-header-manager").remove();
                                    $tableth.find("th.table-daily-header-netchange").remove();
									$tableth.children("th").each(function() { 
									 titles.push($(this).text());                                    
									});
                                    /*code to remove the hader od manager and net change row*/
                                
                                  /*
                                   * Get the actual data, this will contain all the data, in 1 array
                                   */
                                    if($("#dailyunitvalueresultable tr").hasClass("colorband")){
                                        $("#dailyunitvalueresultable tr.colorband ").children("td.remove-this").remove();
                                        $("#dailyunitvalueresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");
                                        $("#dailyunitvalueresultable tr.colorband ").append("<td class='remove-this' style='display:none'></td>");

                                       


                                    }
                                    if($("#dailyunitvalueresultable tr").hasClass("intable-footnotes")){
                                        $("#dailyunitvalueresultable tr.intable-footnotes ").children("td.remove-footnotes").remove();
                                        $("#dailyunitvalueresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");
                                        $("#dailyunitvalueresultable tr.intable-footnotes ").append("<td class='remove-footnotes' style='display:none'></td>");


                                        

                                    }
									/*this code will remove the td for manager and net change*/
                                    $tabletd = $('#dailyunitvalueresultable tbody tr').clone();
                                    $tabletd.children("td").children("span.glyphicon").text(AsOFdateTemp);
                                    $tabletd.children("td.netchangetd").remove();
                                    $tabletd.children("td.managertd").remove();
                                    $tabletd.children("td").each(function() { 
                                     $tabletd.children("span.glyphicon").remove();
									 if($(this).children("a").length > 0){
                                         var gettd= $(this).children("a").text();
                                         var gettdsub= $(this).children("sup").text();
                                         var gettdsmall= $(this).children("small").text();
                                         var getspace = " ";
                                         gettd=gettd.concat(getspace);
										 gettd=gettd.concat(gettdsub);
                                         gettd=gettd.concat(getspace);
                                         gettd=gettd.concat(gettdsmall);


                                      }else{
                                         var gettd= $(this).text();
                                      }
                                       gettd=gettd.replace(",", " ");
                                       data.push(gettd);
                                    }); 
                                    /*this code will remove the td for manager and net change end*/
                            

                                    $('.foot-notes').each(function() { 
                                     var getfootnotenumber = $(this).text();
                                     var getgootnotesdesp = $(this).next(".foot-notes-para").children().text().replace(/,/g ,"");
                                     getgootnotesdesp=getgootnotesdesp.replace(/[^A-Z a-z [0-9]]/g, "");
                                      var getspace=" ";
									 getfootnotenumber=getfootnotenumber.concat(getspace);  
                                     var getcsvfootnotes = getfootnotenumber.concat(getgootnotesdesp);
                                     getcsvfootnotes=getcsvfootnotes.trim();
                                     var separatefpptnotes= '\n';
                                     var getseparatefpptnotes=getcsvfootnotes.concat(separatefpptnotes);
                                     footerpara1.push(getseparatefpptnotes);
                                     });

                                     var footparaheader = footerpara1.toString().replace(/,/g ,"");
                                     footerpara.push(footparaheader);
                                }
                                  
                                  /*
                                   * Convert our data to CSV string
                                   */
                                
                                    var CSVString = prepCSVRow(producttitles, producttitles.length, "");
                                    CSVString = prepCSVRow(headerdata, headerdata.length, CSVString);
                                    CSVString = prepCSVRow(headerparadata, headerparadata.length, CSVString);
                                
                                    CSVString = prepCSVRow(titles, titles.length,CSVString);
                                    CSVString = prepCSVRow(data, titles.length,CSVString);
                                    CSVString = prepCSVRow(footerpara,footerpara.length,CSVString+'\n');

                                

                                
                                
                                  /*
                                   * Make CSV downloadable
                                   */
                                  if (navigator.msSaveBlob)  // For IE 10+
                                  {
                                  var downloadLink = document.createElement("a");
                                  var blob = new Blob([CSVString], {
                                    "type": "text/csv;charset=utf8;"});
                                    navigator.msSaveOrOpenBlob(blob, fileName); 
                                  }
                                  else{
                                  var downloadLink = document.createElement("a");
                                  var blob = new Blob(["\ufeff", CSVString]);
                                  var url = URL.createObjectURL(blob);
                                  downloadLink.href = url;
                                  downloadLink.download = fileName;
                                  /*
                                   * Actually download CSV
                                   */
                                 document.body.appendChild(downloadLink);
                                 downloadLink.click();
                                 document.body.removeChild(downloadLink);}
                                
                          });
                                
                                   /*
                                * Convert data array to CSV string
                                * @param arr {Array} - the actual data
                                * @param columnCount {Number} - the amount to split the data into columns
                                * @param initial {String} - initial string to append to CSV string
                                * return {String} - ready CSV string
                                */
                                function prepCSVRow(arr, columnCount, initial) {
                                  var row = ''; // this will hold data
                                  var delimeter = ','; // data slice separator, in excel it's `;`, in usual CSv it's `,`
                                  var newLine = '\r\n'; // newline separator for CSV row
                                
                                  /*
                                   * Convert [1,2,3,4] into [[1,2], [3,4]] while count is 2
                                   * @param _arr {Array} - the actual array to split
                                   * @param _count {Number} - the amount to split
                                   * return {Array} - splitted array
                                   */
                                  function splitArray(_arr, _count) {
                                    var splitted = [];
                                    var result = [];
                                    _arr.forEach(function(item, idx) {
                                      if ((idx + 1) % _count === 0) {
                                        splitted.push(item);
                                        result.push(splitted);
                                        splitted = [];
                                      } else {
                                        splitted.push(item);
                                      }
                                    });
                                    return result;
                                  }
                                  var plainArr = splitArray(arr, columnCount);
                                  // don't know how to explain this
                                  // you just have to like follow the code
                                  // and you understand, it's pretty simple
                                  // it converts `['a', 'b', 'c']` to `a,b,c` string
                                  plainArr.forEach(function(arrItem) {
                                    arrItem.forEach(function(item, idx) {
                                      row += item + ((idx + 1) === arrItem.length ? '' : delimeter);
                                    });
                                    row += newLine;
                                  });
                                  return initial + row;
                                }



/***************************to export table contentin csv end here*************************************/
/***************************************************************download pdf ***************************************************************************/
  function generateasPDF() {
    var doc = new jsPDF('l', 'pt', 'a4');
    if ($(".DailyUnit_date").is(':visible')) {
        var gethaeder = $(".DailyUnit_date").text();

    } else if ($(".monthlyperformance_date").is(':visible')) {
        var gethaeder = $(".monthlyperformance_date").text();
    } else if ($(".quaterlyperformance_date").is(':visible')) {
        var gethaeder = $(".quaterlyperformance_date").text();
    }
    var gethaederProduct = $(".resultPage_header").text();
    var gethaederSeries = $(".resultPage_header_sub").text();
    var getthemergedheader = gethaederProduct.concat(" "+gethaederSeries);


    //var gethaeder = $(".jhvitmonthlyperformance_date").text();
     /***************************For Local*********************************************/
         /*var domain = location.protocol + "//" + location.hostname + ":" + location.port;
         var Imageurl = domain + "/content/dam/geometrixx-gov/logo-jhancock.png";
         var upurl = domain + "/content/dam/geometrixx-gov/images.png";
         var downurl = domain + "/content/dam/geometrixx-gov/download.png";
         var minusurl = domain + "/content/dam/geometrixx-gov/downloadminus.png";*/
      /***************************For Local*********************************************/
      /***************************For QA And stage*********************************************/
         var domain = location.protocol+"//"+location.hostname+":"+location.port;
         var Imageurl = "/etc/designs/JHINS/images/logo-jhancock.png";
         var upurl = "/etc/designs/JHINS/images/uparrow.png";
         var downurl = "/etc/designs/JHINS/images/download.png";
         var minusurl = "/etc/designs/JHINS/images/downloadminus.png";
     /***************************For QA And stage*********************************************/
      	 var elem = document.getElementById('dailyunitvalueresultableclone');
      	 var imgElements = document.querySelectorAll('#dailyunitvalueresultableclone tbody img');
      	 var data = doc.autoTableHtmlToJson(elem);


    var header = function(data) {
        doc.setFontSize(16);
        //doc.setTextColor(40);
        doc.setFontStyle('bold');
        doc.text(getthemergedheader, data.settings.margin.left, 40);
        doc.text(gethaeder, data.settings.margin.left, 60);
        doc.addImage(Imageurl, 'JPEG', data.settings.margin.left + 565, 20, 150, 40, {
            margin: 100
        });
    };

    var options = {
        //startY: doc.autoTableEndPosY() + 65,
        theme: 'plain',
        showHeader: 'everyPage',
        margin: {
            top: 92
        },
        addPageContent: header,
        styles: {
            font: "normal",
            fontSize: 8,
            overflow: "linebreak",
            cellPadding: 3,

        },

        createdCell: function(cell, data) {
            if (data.row.cells[0].raw.innerText === "AGGRESSIVE") {
                console.log(data.row.cells[0].raw.innerText); {
                    cell.styles.fillColor = [198, 28, 49],
                        cell.styles.textColor = [255, 255,255]
                }
            } else if (data.row.cells[0].raw.innerText === "GROWTH") {
                {
                    cell.styles.fillColor = [239, 138, 33],
                        cell.styles.textColor = [255, 255,255]
                }
            } else if (data.row.cells[0].raw.innerText === "GROWTH AND INCOME") {
                {
                    cell.styles.fillColor = [140, 150, 33],
                        cell.styles.textColor = [255, 255,255]
                }
            } else if (data.row.cells[0].raw.innerText === "INCOME") {
                {
                    cell.styles.fillColor = [140, 150, 33],
                        cell.styles.textColor = [255, 255,255]
                }
            } else if (data.row.cells[0].raw.innerText === "CONSERVATIVE") {
                {
                    cell.styles.fillColor = [57, 113, 173],
                        cell.styles.textColor = [255, 255,255]
                }
            } else if (data.row.cells[0].raw.innerText === "LIFESTYLE") {
                {
                    cell.styles.fillColor = [0, 0, 0],
                        cell.styles.textColor = [255, 255,255]
                }
            } else if (data.row.cells[0].raw.innerText === "MANAGED VOLATILITY") {
                {
                    cell.styles.fillColor = [102, 102, 102],
                        cell.styles.textColor = [255, 255,255]
                }
            }
        },
         drawCell: function(cell, data) { 
			if ($("#dailyunitvalueresultable").is(':visible')) {
          if ( (data.column.dataKey === 3) &&(data.row.cells[3].raw !='undefined')){
              if((data.row.cells[2].text[0] == 0)&&(data.row.cells[2].text[0] != '')){
               doc.addImage(minusurl, cell.textPos.x-30, cell.textPos.y, 10, 10);
              }else if(data.row.cells[2].text[0] > 0){
               doc.addImage(upurl, cell.textPos.x-30, cell.textPos.y, 10, 10);
              }
              else if(data.row.cells[2].text[0] < 0){
               doc.addImage(downurl, cell.textPos.x-30, cell.textPos.y, 10, 10);
              }
              else if(data.row.cells[2].text[0] == ''){
               //doc.addImage(downurl, cell.textPos.x-40, cell.textPos.y, 10, 10);
              }
          }
            }
        },

        headerStyles: {
            //columnWidth: 'wrap',
            cellPadding: 2,
            lineWidth: 0,
            valign: 'top',
            fontStyle: 'bold',
            halign: 'left', //'center' or 'right'
            fillColor: [255, 255, 255],
            textColor: [78, 53, 73], //Black     
            //textColor: [255, 255, 255], //White     
            fontSize: 8

        }
    };

    if ($("#resultable").is(':visible')) {
        var res = doc.autoTableHtmlToJson(document.getElementById("resultable"));
    } else if ($("#quaterlyresultable").is(':visible')) {
        var res = doc.autoTableHtmlToJson(document.getElementById("quaterlyresultable"));
    } else if ($("#dailyunitvalueresultable").is(':visible')) {
        var div = document.getElementById('dailyunitvalueresultable'),
        clone = div.cloneNode(true); // true means clone all childNodes and all event handlers
	    clone.id = "dailyunitvalueresultableclone";
		document.body.appendChild(clone);
        $("#dailyunitvalueresultableclone").hide();
        $("#dailyunitvalueresultableclone tbody tr td span").html("");
        var res = doc.autoTableHtmlToJson(document.getElementById("dailyunitvalueresultableclone"));
    }

    // doc.autoTable(res.columns, res.data, {
    doc.autoTable(res.columns, res.data, options);
    var specialElementHandlers = {
        '#editor': function(element, renderer) {
            return true;
        }
    };

    function getHTML() {


    if ($("#resultable").is(':visible')) {
       doc.fromHTML($("#jhvitmonthlyperformanceResult1").html(), 40, doc.autoTableEndPosY(), {
                 margin: {
                     left: 100,
                     top: 30
                 },
                 styles: {
                     font: "normal",
                     fontSize: 8,
                     overflow: "",
                     halign: "left"
                 },
                 'width': 750,
                 'elementHandlers': specialElementHandlers
             });

    } else if ($("#quaterlyresultable").is(':visible')) {
       doc.fromHTML($("#quaterlyperformanceResult1").html(), 40, doc.autoTableEndPosY(), {
                 margin: {
                     left: 100,
                     top: 30
                 },
                 styles: {
                     font: "normal",
                     fontSize: 8,
                     overflow: "",
                     halign: "left"
                 },
                 'width': 750,
                 'elementHandlers': specialElementHandlers
             });

    } else if ($("#dailyunitvalueresultable").is(':visible')) {
       doc.fromHTML($("#dailyUnitValues1").html(), 40, doc.autoTableEndPosY(), {
                 margin: {
                     left: 100,
                     top: 30
                 },
                 styles: {
                     font: "normal",
                     fontSize: 8,
                     overflow: "",
                     halign: "left"
                 },
                 'width': 750,
                 'elementHandlers': specialElementHandlers
             });

    }



    }
	if(companycodeList=='JHUSA'){
                                  getproductSeries = 0;
                                }else{
                                 getproductSeries = 94;

       }

    if ($("#resultable").is(':visible')) {
        getHTML();
        var downloadas="FundValues_"+ productCode + "_" + getproductSeries +"_MonthlyPerformance.pdf";
        doc.save(downloadas);       
    } else if ($("#quaterlyresultable").is(':visible')) {
        getHTML();
        var downloadas="FundValues_"+ productCode + "_" + getproductSeries +"_QuaterlyPerformance.pdf";
        doc.save(downloadas);
    } else if ($("#dailyunitvalueresultable").is(':visible')) {
        getHTML();
        var downloadas="FundValues_"+ productCode + "_" + getproductSeries +"_DailyUnitValue.pdf";
        doc.save(downloadas);
    }

}
$(".downloadaspadf").on("click", function() {
    generateasPDF();
});
/***********************************************************download pdf end here*************************************************************/


});