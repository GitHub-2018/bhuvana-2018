var AsOFdateTemp;

function dailyunitvalues(productcode,companycode,resultType,date,footnote,firmId){ 
    var productCode =productcode;
    var companyCode	=companycode;
    var functionality ="byProduct";
    var resultType= resultType;
    var dateVal = date;
  	var firmIdVal = firmId;
    var formData;
    if(null !== productCode && null !== companyCode){
        formData={productCode:productCode,companyCode:companyCode,functionality:functionality,resultType:resultType,date:dateVal,footNote:footnote,firmId:firmIdVal};
    }   
    callAjax(formData);
    return AsOFdateTemp;
} 

function callAjax(formData){
        $.ajax({  
            type: "POST",  
            url: "/bin/sling/fundperformance",  
            async : false,
            data: formData,
            dataType: 'json',
            cache: false,
            success: function(resp){
				var statusCode;
                     var code;
                     var statusCodeInArray = ["400","403","404","500","Default"];
                     var codeInArray = ["6001","6003","7001","8001"];
                     if(null != resp.StatusCode){
                         statusCode = resp.StatusCode;
                      }
                     if(resp.Code){
                         code = resp.Code;
                     }
                     // Failure Response display start
                     if($.inArray(statusCode,statusCodeInArray) != -1 || $.inArray(code,codeInArray) != -1){
                    	$("#fundByproduct").hide();                   
              			 $("#dailyUnitValues").show();
               			 $("#epvul").show();  
                         $("#fundResultUnavailable").hide();
                         $(".foot-notes").hide();
                         $(".foot-notes-para").hide();
                         $("#dailyunitvalueresultable").hide();
                         $("#dailyUnitUnavailable").show();
                         if(null != resp.Message){
                             $('#dailyErrorDescription').html(resp.Message+" ("+code+")");
                         } 

                     } // Failure Response display End
					 //Success Response Start
               if(($.inArray(statusCode,statusCodeInArray) == -1 &&  $.inArray(code,codeInArray) == -1)){
                var i;
                var details = resp.FundArray;
                if(typeof details != "undefined"){
                    var tr;
                    var getdate=resp.Details.AsOfDate;
                    var convertdate=getdate.split("-");
                    var str1=convertdate[2];
                    var str2=convertdate[1];
                    var str3=convertdate[0];
                    AsOFdateTemp = str2 +"/"+ str1 +"/"+ str3;;
                    $(".DailyUnit_date").html("Unit Values (in $) as of "+resp.date);
                    $("#dailyunitvalueresultable").children("tbody").empty();
                    var prevRiskVal = null;
                    var currRiskVal = null;
                    var risk=null;
                    for (i = 0; i < details.length; i++) {
                        tr = $('<tr/>');
                         var footNoteVal="";
                        currRiskVal =  resp.FundArray[i].risk;
                        if(currRiskVal!==prevRiskVal){
                            prevRiskVal = currRiskVal;
                            risk=resp.FundArray[i].risk;
                            var riskvalue=risk.toUpperCase();
                            var colorcode=resp.FundArray[i].riskColorCode;
                            $('#dailyunitvalueresultable').append('<tr class="colorband">'+
                                                                 '<td  class="riskHearder" colspan="5" style="background-color:' +colorcode+'">'+ riskvalue +'</td>'); 


                        }else{
                            console.log();
                        }                 

                        if(typeof resp.FundArray[i].morningStarPath !== "undefined" && resp.FundArray[i].morningStarPath !== ""){
                            if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }

                    tr.append("<td scope='row' width='40%'>"+"<a href='"+resp.FundArray[i].morningStarPath+"'target='_blank'>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup></td>");							
                       }
                       else
                       {
						if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }
                           tr.append("<td scope='row' width='40%'>"+"<a href=''>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup></td>");
                       }
                        tr.append("<td>" +resp.FundArray[i].UnitValue + "</td>");
                        tr.append("<td class='netchangetd'>" + resp.FundArray[i].NetChange + "</td>");
                        tr.append("<td  style='font-size:18px;color:"+resp.FundArray[i].color+"'>"+"<span class='glyphicon'>"+resp.FundArray[i].netChange+"</span></td>");
                        tr.append("<td class='managertd'>" + resp.FundArray[i].fundManager + "</td>");



                        if($("#dailyUnitValues").is(':hidden')){
                            $('#dailyunitvalueresultable').append(tr);
                        } 
						 /**************Footnes to be shown in the table****************************/
                       if(typeof resp.FundArray[i].footnotes !== "undefined" && resp.FundArray[i].footnotes !== ""){
                           $('#dailyunitvalueresultable').append('<tr class="intable-footnotes" >'+
                                                       '<td style="background-color:#fff" colspan="11">'+ resp.FundArray[i].footnotes +'</td>'); 
                        								console.log(resp.FundArray[i].footnotes);

                        }
                       $('#dailyunitvalueresultable').children("tbody").children("tr.intable-footnotes").prev("tr").children("td").css("border-bottom","none");
					   $('#dailyunitvalueresultable').children("tbody").children("tr.intable-footnotes").children("td").css("border-top","none");
					   
                       /**************Footnes to be shown in the table****************************/
                    }
                    /*This code will replace any undefined and Null ot blank in US38352-*/
					$( "#dailyunitvalueresultable > tbody >tr >td" ).each(function( index ) {
                        console.log("Inside Td");
  						if(($(this).text() == "" )||($(this).text() == "null" )||($(this).text() == "undefined" ))
                            $(this).text("-");

				   });
                    /*This code will replace any undefined and Null ot blank in -*/
					/*This code will replace [ and ] after supscript -*/
					$( "#dailyunitvalueresultable > tbody >tr >td>sup" ).each(function( index ) {


                         var getsuptext=$(this).text();
                        if(getsuptext!=""){
                            var startingbracket="[";
                            var endingbracket="]";
						    var makegetsuptext=startingbracket.concat(getsuptext);
                            var footnotes=makegetsuptext.concat(endingbracket);
                            $(this).text(footnotes);
                        }else{
							$(this).text(getsuptext);
                        }


				   });
                    /*This code will replace  replace [ and ] after supscript-*/
					/*to make the 0 to 0.0000*/
					$( ".netchangetd" ).each(function( index ) {
  						if($(this).text() == "0")
                            $(this).text("0.0000")
					});

					/*to make the 0 to 0.0000 end*/
                      /**************Footnes to be shown below the table****************************/
                   			 var getFootNotes=resp.FootNotesArray;
                             $(".foot-notes").remove();
                             $(".foot-notes-para").remove();

						 if(typeof(getFootNotes) !== "undefined" && getFootNotes !== null){
                            $("#dailyUnitValues1").remove();
                             $("#dailyUnitValues").after("<div id='dailyUnitValues1' style='display:none'></div>");
                             $.each( getFootNotes, function( key, value ) {                                 
                                   $.each( value, function( key, value ) {

                                      $("#dailyUnitValues").append("<div class='foot-notes small'>"+
                                                                            "<b>"+
                                                                            "["+key+"]"+
                                                                            "</b>"+
                                                                            "</div>");
                                      //var footnotespara='footnotes"+key+"';
                                      $("#dailyUnitValues").append("<div class='foot-notes-para small'>"+value+"</div>");
										/*For Pdf footnotes*/
                                      var footnoteClass = 'footnoteClass' + key;
                                      $("#dailyUnitValues1").append("<span class='"+footnoteClass+"'>"+value+"</span>");
                                      $("#dailyUnitValues1").children('.' + footnoteClass).children().prepend("["+key+"]  ");
                                      /*For Pdf footnotes*/
                                   });

        
        
                            });
                         }

                    /**************Footnes to be shown below the table****************************/


                    $("#fundByproduct").hide();                   
                    $("#epvul").show(); 
                     $("#dailyUnitValues").show();
                     $("#dailyunitvalueresultable").show();
                     $("#dailyUnitUnavailable").hide();
                     $("#fundResultUnavailable").hide();
                    $(".foot-notes").show();
                    $(".foot-notes-para").show();
                }else{

                }
				   }
            },

            error: function(e){
                console.log("error");       
            }
        });
    } 
