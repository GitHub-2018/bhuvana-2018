function quaterlyfundperformace(productcode,companycode,footnote,firmId){
    var productCode =productcode;
    var companyCode	=companycode;
    var functionality ="byProduct";
    var resultType= "byProductQuaterlyPerformance";
  	var firmIdVal = firmId;
    var formData;
    console.log("selected value is"+productCode);
    if(null !== productCode && null !== companyCode){
        formData={productCode:productCode,companyCode:companyCode,functionality:functionality,resultType:resultType,footNote:footnote,firmId:firmIdVal};
    }
    callAjax(formData);
    function callAjax(formData){
        $.ajax({  
            type: "POST",  
            url: "/bin/sling/fundperformance",  
            data: formData,
            dataType: 'json',
            cache: false,
            success: function(resp){
                	 var statusCode;
                     var code;
                     var statusCodeInArray = ["400","403","404","500","Default"];
                     var codeInArray = ["6001","6003","7001","8001"];
                     if(null != resp.StatusCode){
                         statusCode = resp.StatusCode;
                      }
                     if(resp.Code){
                         code = resp.Code;
                     }
                     // Failure Response display start
                     if($.inArray(statusCode,statusCodeInArray) != -1 || $.inArray(code,codeInArray) != -1){
                    	  $("#fundByproduct").hide();                   
              			  $("#quaterlyperformanceResult").hide();
               			 $("#epvul").show();  
                         $("#fundResultUnavailable").show();
                         if(null != resp.Message){
                             $('#fundErrorDescription').html(resp.Message+" ("+code+")");
                         } 

                    	 
                     } // Failure Response display End
                 //Success Response Start
                  if(($.inArray(statusCode,statusCodeInArray) == -1 &&  $.inArray(code,codeInArray) == -1)){
                console.log("success");
                var i;
                var details = resp.FundArray;              
                var tr;
                $(".quaterlyperformance_date").html(resp.quarter+" Performance (%) as of "+resp.date);
                $("#quaterlyresultable").children("tbody").empty();
                var prevRiskVal = null;
                var currRiskVal = null;
                var risk=null;
                for (i = 0; i < details.length; i++) {
                    tr = $('<tr/>');
                     var footNoteVal="";
                    currRiskVal =  resp.FundArray[i].risk;
                    if(currRiskVal!==prevRiskVal){
                        prevRiskVal = currRiskVal;
                        risk=resp.FundArray[i].risk;
                        var riskvalue=risk.toUpperCase();
                        var colorcode=resp.FundArray[i].riskColorCode;
                        $('#quaterlyresultable').append('<tr class="colorband">'+
                                                        '<td  class="riskHearder" colspan="11" style="background-color:' +colorcode+'">'+ riskvalue +'</td>'); 

                        console.log(riskvalue);

                    }else{
                        console.log();
                    }                 

                  if(typeof resp.FundArray[i].morningStarPath !== "undefined" && resp.FundArray[i].morningStarPath !== ""){
                           if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }                                                    
                           tr.append("<td scope='row' width='40%'>"+"<a href='"+resp.FundArray[i].morningStarPath+"'target='_blank'>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                       else
                       {
                           if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                             footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }
                           tr.append("<td scope='row' width='40%'>"+"<a href=''>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                    tr.append("<td>" +resp.FundArray[i].managementFee + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Ytd + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TwelveMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].FiveYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TenYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Incep + "</td>");
                    tr.append("<td>" + resp.FundArray[i].incepDate + "</td>");

                    
                    if($("#quaterlyperformanceResult").is(':hidden')){
                        $('#quaterlyresultable').append(tr);
                    } 
					/**************Footnes to be shown in the table****************************/
                       if(typeof resp.FundArray[i].footnotes !== "undefined" && resp.FundArray[i].footnotes !== ""){

                           $('#quaterlyresultable').append('<tr class="intable-footnotes" >'+
                                                       '<td style="background-color:#fff" colspan="11">'+ resp.FundArray[i].footnotes +'</td>'); 
                        								console.log(resp.FundArray[i].footnotes);

                        }
                       $('#quaterlyresultable').children("tbody").children("tr.intable-footnotes").prev("tr").children("td").css("border-bottom","none");
					   $('#quaterlyresultable').children("tbody").children("tr.intable-footnotes").children("td").css("border-top","none");
                       /**************Footnes to be shown in the table****************************/
                }

				/*This code will replace any undefined and Null ot blank in US38352 -*/
                $( "#quaterlyresultable > tbody >tr >td" ).each(function( index ) {
                    console.log("Inside Td");
                      if(($(this).text() == "" )||($(this).text() == "null" )||($(this).text() == "undefined" ))
                        $(this).text("-");

               });
                /*This code will replace any undefined and Null ot blank in -*/
				/*This code will replace [ and ] after supscript -*/
					$( "#quaterlyresultable > tbody >tr >td>sup" ).each(function( index ) {


                         var getsuptext=$(this).text();
                        if(getsuptext!=""){
                            var startingbracket="[";
                            var endingbracket="]";
						    var makegetsuptext=startingbracket.concat(getsuptext);
                            var footnotes=makegetsuptext.concat(endingbracket);
                            $(this).text(footnotes);
                        }else{
							$(this).text(getsuptext);
                        }


				   });
                    /*This code will replace  replace [ and ] after supscript-*/
                         /**************Footnes to be shown below the table****************************/
                   			 var getFootNotes=resp.FootNotesArray;
                              $(".foot-notes").remove();
                             $(".foot-notes-para").remove();

						 if(typeof(getFootNotes) !== "undefined" && getFootNotes !== null){
							$("#quaterlyperformanceResult1").remove();
                             $("#quaterlyperformanceResult").after("<div id='quaterlyperformanceResult1' style='display:none'></div>");
                             $.each( getFootNotes, function( key, value ) {                                 
                                   $.each( value, function( key, value ) {

                                      $("#quaterlyperformanceResult").append("<div class='foot-notes small'>"+

                                                                            "<b>"+
                                                                            "["+key+"]"+
                                                                            "</b>"+

                                                                           "</div>");
                                      //var footnotespara='footnotes"+key+"';
                                      $("#quaterlyperformanceResult").append("<div class='foot-notes-para small'>"+value+"</div>");
								     /*For Pdf footnotes*/
                                      var footnoteClass = 'footnoteClass' + key;
                                      $("#quaterlyperformanceResult1").append("<span class='"+footnoteClass+"'>"+value+"</span>");
                                      $("#quaterlyperformanceResult1").children('.' + footnoteClass).children().prepend("["+key+"]  ");
                                      /*For Pdf footnotes*/
                                   });

        
        
                            });
                         }

                    /**************Footnes to be shown below the table****************************/




                $("#fundByproduct").hide();                   
                $("#quaterlyperformanceResult").show();
                $("#epvul").show();  
                $("#fundResultUnavailable").hide();
                 } // Success Response End
            },
            
            error: function(e){
                console.log("error");       
            }
        });
    }   
} 