function quaterlyfundperformace(productcode,companycode,footnote){
    var productCode =productcode;
    var companyCode	=companycode;
    var functionality ="byProduct";
    var resultType= "byProductQuaterlyPerformance";
    var formData;
    console.log("selected value is"+productCode);
    if(null !== productCode && null !== companyCode){
        formData={productCode:productCode,companyCode:companyCode,functionality:functionality,resultType:resultType,footNote:footnote};
    }
    callAjax(formData);
    function callAjax(formData){
        $.ajax({  
            type: "POST",  
            url: "/bin/sling/fundperformance",  
            data: formData,
            dataType: 'json',
            cache: false,
            success: function(resp){
                console.log("success");
                var i;
                var details = resp.FundArray;              
                var tr;
                $(".quaterlyperformance_date").html(resp.quarter+" Performance (%) as of "+resp.date);
                $("#quaterlyresultable").children("tbody").empty();
                var prevRiskVal = null;
                var currRiskVal = null;
                var risk=null;
                for (i = 0; i < details.length; i++) {
                    tr = $('<tr/>');
                     var footNoteVal="";
                    currRiskVal =  resp.FundArray[i].risk;
                    if(currRiskVal!==prevRiskVal){
                        prevRiskVal = currRiskVal;
                        risk=resp.FundArray[i].risk;
                        var riskvalue=risk.toUpperCase();
                        var colorcode=resp.FundArray[i].riskColorCode;
                        $('#quaterlyresultable').append('<tr class="colorband">'+
                                                        '<td  class="riskHearder" colspan="11" style="background-color:' +colorcode+'">'+ riskvalue +'</td>'); 

                        console.log(riskvalue);

                    }else{
                        console.log();
                    }                 

                  if(typeof resp.FundArray[i].morningStarPath !== "undefined" && resp.FundArray[i].morningStarPath !== ""){
                           if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                               footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }                                                    
                           tr.append("<td scope='row' width='40%'>"+"<a href='"+resp.FundArray[i].morningStarPath+"'target='_blank'>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                       else
                       {
                           if(resp.FundArray[i].numberedFootNotes!= null && typeof resp.FundArray[i].numberedFootNotes !== undefined ){
                             footNoteVal = resp.FundArray[i].numberedFootNotes;
                           }
                           tr.append("<td scope='row' width='40%'>"+"<a href=''>"+ resp.FundArray[i].fundTitle +"</a><sup>"+footNoteVal+"</sup><br><small>"+ resp.FundArray[i].fundManager+"</small></td>");
                       }
                    tr.append("<td>" +resp.FundArray[i].managementFee + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Ytd + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TwelveMonth + "</td>");
                    tr.append("<td>" + resp.FundArray[i].ThreeYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].FiveYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].TenYear + "</td>");
                    tr.append("<td>" + resp.FundArray[i].Incep + "</td>");
                    tr.append("<td>" + resp.FundArray[i].incepDate + "</td>");

                    
                    if($("#quaterlyperformanceResult").is(':hidden')){
                        $('#quaterlyresultable').append(tr);
                    } 
					/**************Footnes to be shown in the table****************************/
                       if(typeof resp.FundArray[i].footnotes !== "undefined" && resp.FundArray[i].footnotes !== ""){

                           $('#quaterlyresultable').append('<tr class="intable-footnotes" >'+
                                                       '<td style="background-color:#fff" colspan="11">'+ resp.FundArray[i].footnotes +'</td>'); 
                        								console.log(resp.FundArray[i].footnotes);

                        }
                       $('#quaterlyresultable').children("tbody").children("tr.intable-footnotes").prev("tr").children("td").css("border-bottom","none");
                       /**************Footnes to be shown in the table****************************/
                }


                        /**************Footnes to be shown below the table****************************/
                   			 var getFootNotes=resp.FootNotesArray;
                              $(".foot-notes").remove();
                             $(".foot-notes-para").remove();

						 if(typeof(getFootNotes) !== "undefined" && getFootNotes !== null){

                             $.each( getFootNotes, function( key, value ) {                                 
                                   $.each( value, function( key, value ) {

                                      $("#quaterlyperformanceResult").append("<div class='foot-notes'>"+

                                                                            "<b>"+
                                                                            +key+
                                                                            "</b>"+

                                                                           "</div>");
                                      //var footnotespara='footnotes"+key+"';
                                      $("#quaterlyperformanceResult").append("<div class='foot-notes-para'>"+value+"</div>");
        
                                       console.log(key);
                                       console.log(value);


        
        
                                   });

        
        
                            });
                         }

                    /**************Footnes to be shown below the table****************************/



                $("#fundByproduct").hide();                   
                $("#quaterlyperformanceResult").show();
                $("#epvul").show();                               
            },
            
            error: function(e){
                console.log("error");       
            }
        });
    }   
} 