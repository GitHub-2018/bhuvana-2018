var form = ( function ($) {

    "use strict";

	// cache DOM
	var $submitFormBtn = $(".submitBtn");
	var $stateDropdown = $(".stateDropdown");
    var $formFields = $("input, select, textarea, fieldset");

    var emailURL = '/bin/sling/EmailFormServlet';
    var recaptchaURL = '/bin/sling/RecaptchaValidatorServlet';

    // Events
	$submitFormBtn.on("click", function (e) {
		e.preventDefault();
        var form = $(this).closest("form");
        var isRecaptchaDisabled=form.closest(".formComponent__wrapper").find(".captchaDisabled").val();
        if(_buildValidationRules(form)) {
        	if(!isRecaptchaDisabled){
        		validateRecaptcha(form);
        	}  else {
        		setValues(form);
        	}
        }
	});

	_render();

	function _render () {
		setStateValues();
	}

	function setStateValues () {

		var US_STATES = [
		    { name: 'ALABAMA', abbreviation: 'AL'},
		    { name: 'ALASKA', abbreviation: 'AK'},
		    { name: 'AMERICAN SAMOA', abbreviation: 'AS'},
		    { name: 'ARIZONA', abbreviation: 'AZ'},
		    { name: 'ARKANSAS', abbreviation: 'AR'},
		    { name: 'CALIFORNIA', abbreviation: 'CA'},
		    { name: 'COLORADO', abbreviation: 'CO'},
		    { name: 'CONNECTICUT', abbreviation: 'CT'},
		    { name: 'DELAWARE', abbreviation: 'DE'},
		    { name: 'DISTRICT OF COLUMBIA', abbreviation: 'DC'},
		    { name: 'FEDERATED STATES OF MICRONESIA', abbreviation: 'FM'},
		    { name: 'FLORIDA', abbreviation: 'FL'},
		    { name: 'GEORGIA', abbreviation: 'GA'},
		    { name: 'GUAM', abbreviation: 'GU'},
		    { name: 'HAWAII', abbreviation: 'HI'},
		    { name: 'IDAHO', abbreviation: 'ID'},
		    { name: 'ILLINOIS', abbreviation: 'IL'},
		    { name: 'INDIANA', abbreviation: 'IN'},
		    { name: 'IOWA', abbreviation: 'IA'},
		    { name: 'KANSAS', abbreviation: 'KS'},
		    { name: 'KENTUCKY', abbreviation: 'KY'},
		    { name: 'LOUISIANA', abbreviation: 'LA'},
		    { name: 'MAINE', abbreviation: 'ME'},
		    { name: 'MARSHALL ISLANDS', abbreviation: 'MH'},
		    { name: 'MARYLAND', abbreviation: 'MD'},
		    { name: 'MASSACHUSETTS', abbreviation: 'MA'},
		    { name: 'MICHIGAN', abbreviation: 'MI'},
		    { name: 'MINNESOTA', abbreviation: 'MN'},
		    { name: 'MISSISSIPPI', abbreviation: 'MS'},
		    { name: 'MISSOURI', abbreviation: 'MO'},
		    { name: 'MONTANA', abbreviation: 'MT'},
		    { name: 'NEBRASKA', abbreviation: 'NE'},
		    { name: 'NEVADA', abbreviation: 'NV'},
		    { name: 'NEW HAMPSHIRE', abbreviation: 'NH'},
		    { name: 'NEW JERSEY', abbreviation: 'NJ'},
		    { name: 'NEW MEXICO', abbreviation: 'NM'},
		    { name: 'NEW YORK', abbreviation: 'NY'},
		    { name: 'NORTH CAROLINA', abbreviation: 'NC'},
		    { name: 'NORTH DAKOTA', abbreviation: 'ND'},
		    { name: 'NORTHERN MARIANA ISLANDS', abbreviation: 'MP'},
		    { name: 'OHIO', abbreviation: 'OH'},
		    { name: 'OKLAHOMA', abbreviation: 'OK'},
		    { name: 'OREGON', abbreviation: 'OR'},
		    { name: 'PALAU', abbreviation: 'PW'},
		    { name: 'PENNSYLVANIA', abbreviation: 'PA'},
		    { name: 'PUERTO RICO', abbreviation: 'PR'},
		    { name: 'RHODE ISLAND', abbreviation: 'RI'},
		    { name: 'SOUTH CAROLINA', abbreviation: 'SC'},
		    { name: 'SOUTH DAKOTA', abbreviation: 'SD'},
		    { name: 'TENNESSEE', abbreviation: 'TN'},
		    { name: 'TEXAS', abbreviation: 'TX'},
		    { name: 'UTAH', abbreviation: 'UT'},
		    { name: 'VERMONT', abbreviation: 'VT'},
		    { name: 'VIRGIN ISLANDS', abbreviation: 'VI'},
		    { name: 'VIRGINIA', abbreviation: 'VA'},
		    { name: 'WASHINGTON', abbreviation: 'WA'},
		    { name: 'WEST VIRGINIA', abbreviation: 'WV'},
		    { name: 'WISCONSIN', abbreviation: 'WI'},
		    { name: 'WYOMING', abbreviation: 'WY' }
		];

		$.each(US_STATES, function (i, item) {
			$stateDropdown.append($('<option>', {
				value: item.abbreviation,
				text : item.name
			}));
		});

		return renderSelect($stateDropdown);
	}

	function renderSelect ($this) {
		$this.selectpicker('render');
	}

	function _buildValidationRules (form) {
		var rules = {};

    form.find($formFields).each(function () {
			var validationName = $(this).attr("name");
			rules[validationName] = {};

			if (typeof($(this).attr("data-required")) !== 'undefined') {
				if ($(this).attr("data-required") === 'true') {
					rules[validationName]['required'] = true;
				} else {
					rules[validationName]['required'] = false;
				}
			}

			if ($(this).attr("data-validation")) {
				var dv = $(this).attr("data-validation");
				rules[validationName][dv] = true;
			}
		});

		var groups = {};
		var messages = {};

		return validate(form, rules, groups, messages)
	}

	function validate (form, rules, groups, messages) {
    $.validator.addMethod("nameRegex", function (value, element) {
        return this.optional(element) || /^[a-zA-Z0-9]*$/i.test(value);
    }, "Name must contain only letters");

		form.validate({
      errorElement: 'span',
      errorClass: 'help-block',
      highlight: function (element, errorClass, validClass) {
          $(element).closest($formFields).addClass("input__error");
      },
      unhighlight: function (element, errorClass, validClass) {
          $(element).closest($formFields).removeClass("input__error");
      },
			invalidHandler: function(form, validator) {
				var errors = validator.numberOfInvalids();
				if (errors) {
					validator.errorList[0].element.focus();
				}
			},
      errorPlacement: function(error, element) {
        if ( element.is(":radio") || element.is(":checkbox")  ) {
          error.appendTo( element.parents('.input__wrap') );
        } else { // This is the default behavior
          error.insertAfter( element );
        }
      },
      rules: rules,
      groups: groups,
      messages: messages
    });

    return form.valid();
	}

	function getValues (form) {
		var formObj = {};
        var j = 1;

		form.find($formFields).each(function() {
			var idName = $(this).attr("data-label");
            if($(this).is("fieldset")) {
    			var cboxSelected = [];
    			$(this).find("input").each(function () {
    				if ($(this).prop("checked")) {
    					cboxSelected.push($(this).val());
    				}
    			});
                formObj[idName + '_' + j] = cboxSelected;
                j++;
            } else if (!$(this).parents().is("fieldset")) {
                formObj[idName + '_' + j] = $(this).val();
                j++;
            }
		});

		return formObj;
	}

	function setValues (form) {
		var salesforceURL = form.closest(".formComponent__wrapper").find(".sfURL").val();
        if(salesforceURL) {
            form.attr("action", salesforceURL);
            form.submit();
        } else {
            submit(emailURL, form, getValues(form));
        }
	}

    function validateRecaptcha (form) {
        var captcha = {
    		gresponse : form.find(".g-recaptcha-response").val()
        };
        submit(recaptchaURL, form, captcha);
    }

    function loader (form) {
        form.find(".submitBtn").css("display", "none");
        form.find(".loader").css("display", "inline-block");
    }

    // todo extrapolate the message for individual forms
    function successHandler (url, form, response) {
        if (url === recaptchaURL) {
            if (response.message === "recaptcha_success") {
            	form.closest(".formComponent__wrapper").find(".forminvalidreCaptcha").hide();
                setValues(form);
            } else {
                form.closest(".formComponent__wrapper").find(".forminvalidreCaptcha").show();
                grecaptcha.reset();
                return false;
            }
        } else {
            form.find(".submitBtn").css("display", "inline-block");
            if (response.message === "emailForm_success") {
            	var emailRedirect = form.closest(".formComponent__wrapper").find(".EmailForm_RedirectLink").val();
                if (emailRedirect !== '') {
                    window.location.href = emailRedirect;
                } else {
                    form.hide();
                    form.closest(".formComponent__wrapper").find(".emailthankyoublock").show();
                }
            } else if (response.message === "emailForm_failure") {
                form.closest(".formComponent__wrapper").find(".emailerrorblock").show();
                return false;
            }
        }
    }

	function submit (url, form, data) {
		$.ajax({
		    type: 'POST',
		    url: url,
		    data: data,
		    beforeSend: loader(form),
            success: function (response) {
                successHandler(url, form, response);
            },
            failure: function (err) {
                return false;
            }
		});
	}

	return {
        getValues: getValues,
		validate: validate,
        validateRecaptcha: validateRecaptcha,
		submit: submit
	};

})(jQuery);
