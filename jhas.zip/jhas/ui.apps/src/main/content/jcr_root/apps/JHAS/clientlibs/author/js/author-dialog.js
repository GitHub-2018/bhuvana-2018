$(function() {
  /*------ Author page Load functions -------*/

  // Hide from site console page properties

  if ($('.granite-actionbar').length > 0) {
    $('.header-vanity-url').remove();
  }
});

/*------ Author dialog On Load functions ------- */

$(document).on('foundation-contentloaded', function() {


  $('.hexfield').keyup(function() {
    $('.hexfield').css('background-color', $(this).val());
  });

  $('[data-name="./properties"]').each(function(i) {
    $(this).find('h3').text('Slide ' + ++i);
  });


  $('.cq-overlay-options').each(function() {
    showHideOpacitySection(this, 'none');
  });
});

/*------ Author dialog event functions -------*/




$(document).on('selected', '.cq-overlay-options', function() {
  showHideOpacitySection(this, 'none');
});



/*------ Author dialog functions details -------*/

function showHideExternalCheck(el) {
    if ($(el).is(':checked')) {
        $(el).parent().parent().nextAll().eq(0).show();
    } else {
        $(el).parent().parent().nextAll().eq(0).hide();
    }
}

function showHideProfile(el) {
    if ($(el).is(':checked')) {
        $(el).parent().parent().nextAll().eq(0).hide();
    } else {
        $(el).parent().parent().nextAll().eq(0).show();
    }
}


function showHideArticleOptionsCheckbox(el) {
    if (!$(el).is(':checked') && $(el).parent().parent().parent().children().find('.articleViewType').data("select").getValue() == 'list') {
        $(el).parent().parent().nextAll().eq(0).hide();
        $(el).parent().parent().nextAll().eq(1).hide();
        $(el).parent().parent().nextAll().eq(2).hide();
        $(el).parent().parent().nextAll().eq(3).hide();
    } else {
        $(el).parent().parent().nextAll().eq(0).show();
        $(el).parent().parent().nextAll().eq(1).show();
        $(el).parent().parent().nextAll().eq(2).show();
        $(el).parent().parent().nextAll().eq(3).show();
    }

}

function showHideArticleOptionsSelect(el) {
    if (!$(el).parent().parent().children().find('.hideToggleOptions').is(':checked') && $(el).data("select").getValue() == 'list') {
        $(el).parent().nextAll().eq(1).hide();
        $(el).parent().nextAll().eq(2).hide();
        $(el).parent().nextAll().eq(3).hide();
        $(el).parent().nextAll().eq(4).hide();
    } else {
        $(el).parent().nextAll().eq(1).show();
        $(el).parent().nextAll().eq(2).show();
        $(el).parent().nextAll().eq(3).show();
        $(el).parent().nextAll().eq(4).show();
    }
}

function showHideContainerTab(el) {
    var containerSelected = $(el).data("select").getValue();
    if (containerSelected == 'sectionwithpadding' || containerSelected == 'paddinginsidebackground') {
        $(el).parent().parent().parent().parent().parent().children().eq(0).children().eq(2).show();
    } else {
        $(el).parent().parent().parent().parent().parent().children().eq(0).children().eq(2).hide();
    }
}



function showHideOpacitySection(el, val) {
    if ($(el).data("select").getValue() == val) {
        $(el).parent().nextAll().eq(0).hide();
    } else {
        $(el).parent().nextAll().eq(0).show();
    }
}
