export const getLastName = name => {
  const n = name.split(' ');
  return n[n.length - 1];
};

export const sortProfiles = profiles => {
  profiles.sort((a, b) => {
    if (a.title === 'President & CEO, John Hancock') {
      return -1; // a is greater than b
    }
    if (b.title === 'President & CEO, John Hancock') {
      return 1; // b is greater than a
    }
    return getLastName(a.name).localeCompare(getLastName(b.name));
  });

  return profiles;
};

export default {
  getLastName,
  sortProfiles
};
