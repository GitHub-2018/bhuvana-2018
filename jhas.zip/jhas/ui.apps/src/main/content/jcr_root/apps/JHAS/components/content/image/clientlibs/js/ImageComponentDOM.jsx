import { DOMModel, DOMComponent } from 'react-dom-components';
import ImageComponent from './ImageComponent';

class ImageComponentModel extends DOMModel {
  constructor(element) {
    super(element);
    this.getDataAttribute('filereference');
    this.getDataAttribute('caption');
    this.getDataAttribute('title');
    this.getDataAttribute('alttext');
    this.getDataAttribute('linkurl');
    this.getDataAttribute('horizontalalign');
    this.getDataAttribute('textalign');
    this.getDataAttribute('imagewidth');
    this.getDataAttribute('openlinkoptions');
  }
}

export default class ImageComponentDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'ImageComponent';
    this.model = ImageComponentModel;
    this.component = ImageComponent;
  }
}
