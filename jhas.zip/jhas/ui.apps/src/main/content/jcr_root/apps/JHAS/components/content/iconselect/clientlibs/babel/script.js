const icon = (jQuery) => {

	$('.icon__select').each(function () {

		let colorCode = $(this).children('.icon__select--hexcolorcode').val()

        if (typeof(colorCode) === 'undefined') {
			colorCode = $(this).children('.icon__select--colorpickcode').val()
		}

		if (typeof(colorCode) !== 'undefined' && !$(this).children('span').hasClass('icon__border--link')) {
			$(this).children('span').css({
				'color': colorCode,
				'border-color': colorCode
			})
		}

		let iconSize = $(this).children('.icon__select--iconsize').val()
		let iconNum = parseInt(iconSize.slice(0, -2))
		let circleSize = iconNum + iconNum * 0.5

        $(this).children('span').css({
			'font-size': iconSize,
			'line-height': circleSize + 'px',
			'height': circleSize + 'px',
			'width': circleSize + 'px'
		})
	})
}

icon(jQuery)
