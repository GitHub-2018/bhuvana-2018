import { DOMRegistry } from 'react-dom-components';

import '../sass/styles.scss';
import '../sass/aem-grid.scss';
// No JS component
import '../../../../components/content/prnewscategories/clientlibs/scss/PRNewsCategories.scss';
import '../../../../components/content/prnewsnextarticle/clientlibs/scss/PRNewsNextArticle.scss';
import '../../../../components/structure/article/clientlibs/scss/Article.scss';
import '../../../../components/structure/profile/clientlibs/scss/Profile.scss';
import '../../../../components/structure/breadcrumb/clientlibs/scss/Breadcrumb.scss';
import '../../../../components/structure/footer/clientlibs/scss/Footer.scss';

import LatestNewsDOM from '../../../../components/content/latestnews/clientlibs/js/LatestNewsDOM';
/* import ManualArticlesDOM from '../../../../components/content/manualarticles/clientlibs/js/ManualArticlesDOM'; */
import GalleryDOM from '../../../../components/content/gallery/clientlibs/js/GalleryDOM';
import SearchDOM from '../../../../components/content/search/clientlibs/js/SearchDOM';
import LeadershipListDOM from '../../../../components/content/leadershiplist/clientlibs/js/LeadershipListDOM';
import LeadershipProfilesDOM from '../../../../components/content/leadershipprofiles/clientlibs/js/LeadershipProfilesDOM';
import PRNewswireSearchDOM from '../../../../components/content/prnewswiresearch/clientlibs/js/PRNewswireSearchDOM';
import RotatorDOM from '../../../../components/content/rotator_v_2/clientlibs/js/RotatorDOM';
import IframeComponentDOM from '../../../../components/content/iframe/clientlibs/js/IframeComponentDOM';
import ImageComponentDOM from '../../../../components/content/image/clientlibs/js/ImageComponentDOM';
import CrowdriseDOM from '../../../../components/content/crowdrise/clientlibs/js/CrowdriseDOM';

const LatestNews = new LatestNewsDOM();
/* const ManualArticles = new ManualArticlesDOM(); */
const Gallery = new GalleryDOM();
const Search = new SearchDOM();
const LeadershipList = new LeadershipListDOM();
const LeadershipProfiles = new LeadershipProfilesDOM();
const PRNewswireSearch = new PRNewswireSearchDOM();
const Rotator = new RotatorDOM();
const IframeComponent = new IframeComponentDOM();
const ImageComponent = new ImageComponentDOM();
const Crowdrise = new CrowdriseDOM();

const domRegistry = new DOMRegistry();

domRegistry.register({
  LatestNews,
  /* ManualArticles, */
  Gallery,
  Search,
  LeadershipList,
  LeadershipProfiles,
  PRNewswireSearch,
  Rotator,
  IframeComponent,
  ImageComponent,
  Crowdrise
});
