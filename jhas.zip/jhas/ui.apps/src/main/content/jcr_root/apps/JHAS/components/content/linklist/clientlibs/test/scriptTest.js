var assert = require('../../../../../../../etc/designs/JHAS/node_modules/chai').assert;
var jQuery = require('../../../../../../../etc/designs/JHAS/node_modules/jQuery');

global.window = window
global.$ = require('jquery');

var getCurrentYear = require('../js/script.js');

describe('Link List', function () {
	it('Should return the current year', function () {
		assert.equal(getCurrentYear(), 2017);
	});
});
