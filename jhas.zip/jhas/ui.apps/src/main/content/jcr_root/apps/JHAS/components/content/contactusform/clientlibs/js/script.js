'use strict';

var contactusform = function ($) {

    //cache DOM
    var $contactform = $('#contactusform');
    var $contactformsubmit = $('#cu_jhas_send_message');

    $contactformsubmit.on('click', function (e) {
        e.preventDefault();
        if (form.validate($contactform, _setRules())) {
            _contactUsSendMessage();
        }
    });

    var _setRules = function _setRules() {
        var rules = {
            cu_inquiryType: {
                required: true
            },
            cu_firstname: {
                required: true,
                nameRegex: true
            },
            cu_lastname: {
                required: true
            },
            cu_email: {
                required: true
            },
            cu_your_message: {
                required: true
            }
        };
        return rules;
    };

    var _contactUsSendMessage = function _contactUsSendMessage() {
        var contactusformdata = {
            selectFieldValue: $('#cu_inquiryType').val(),
            _message: $('#cu_your_message').val(),
            firstname: $('#cu_firstname').val(),
            lastname: $('#cu_lastname').val(),
            suffix: $('#cu_suffix').val(),
            email: $('#cu_email').val(),
            accountNumber: $('#cu_accountNumber').val(),
            phoneNumber: $('#cu_phoneNumber').val(),
            address: $('#cu_address').val(),
            custExperienceId: $("#custExperienceId").val(),
            recaptcha: grecaptcha.getResponse()
        };
        var servlet = '/bin/sling/ContactUsServlet';
        _submit(servlet, $contactform, contactusformdata);
    };

    var _loader = function _loader(cuform) {
        cuform.find("#cu_jhas_send_message").css("display", "none");
        cuform.find(".loader").css("display", "inline-block");
    };

    var _successHandler = function _successHandler(url, cuform, response) {
        if (response.message === "contactUs_success") {
            cuform.find('.loader').hide();
            $(".invalidreCaptcha").hide();
            cuform.hide();
            $(".thankyouMessage").show();
        } else if (response.message == "contactUs_faliure") {
            cuform.find('.loader').hide();
            $(".errorMessage").show();
        } else if (response.message == "contactUs_invalid_captcha") {
            grecaptcha.reset();
            cuform.find('.loader').hide();
            cuform.find("#cu_jhas_send_message").css("display", "inline-block");
            $(".invalidreCaptcha").show();
        }
    };

    var _submit = function _submit(url, form, data) {
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            beforeSend: _loader(form),
            success: function success(response) {
                _successHandler(url, form, response);
            },
            failure: function failure(err) {
                console.warn("There was a problem processing your request", err);
                return false;
            }
        });
    };
}(jQuery);