"use strict";

var linklist = function linklist(jQuery) {

	//cache DOM
	var $currentYear = $(".currentYear");

	var getCurrentYear = function getCurrentYear() {
		return new Date().getFullYear();
	};

	var _render = function _render() {
		$currentYear.text(getCurrentYear());
	};

	_render();

	return {
		getCurrentYear: getCurrentYear
	};
};

linklist(jQuery);