import React from 'react';
import { isiOS } from '../../../../../clientlibs/publish/src/utils/device';

import '../scss/Iframe.scss';

export default class Iframe extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      iframeWidth: `100%`,
      iframeHeight: 0,
      iframeMinWidth: `100%`
    };
    this.evaluateScreenSize = this.evaluateScreenSize.bind(this);
  }

  componentWillMount() {
    this.evaluateScreenSize();
  }

  componentDidMount() {
    window.addEventListener('resize', this.evaluateScreenSize);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.evaluateScreenSize);
  }

  evaluateScreenSize() {
    const screenWidth = document.body.clientWidth;
    const { widthdesktop, heightdesktop, unitdesktop, widthipad, heightipad, unitipad, widthmobile, heightmobile, unitmobile } = this.props;
    switch (true) {
      case screenWidth > 1024:
        if (widthdesktop !== undefined) {
          this.setState({
            iframeWidth: `${widthdesktop}${unitdesktop}`
          });
        } else {
          this.setState({
            iframeWidth: `100%`
          });
        }
        this.setState({
          iframeHeight: `${heightdesktop}px`
        });
        break;
      case screenWidth <= 1024 && screenWidth >= 768:
        if (widthipad !== undefined) {
          this.setState({
            iframeWidth: `${widthipad}${unitipad}`
          });
        } else {
          if (isiOS()) {
            this.setState({
              iframeWidth: `1px`,
              iframeMinWidth: `100%`
            });
          } else {
            this.setState({
              iframeWidth: `100%`
            });
          }
        }
        if (heightipad !== undefined) {
          this.setState({
            iframeHeight: `${heightipad}px`
          });
        } else {
          this.setState({
            iframeHeight: `${heightdesktop}px`
          });
        }
        break;
      case screenWidth < 768:
        if (widthmobile !== undefined) {
          this.setState({
            iframeWidth: `${widthmobile}${unitmobile}`
          });
        } else {
          if (isiOS()) {
            this.setState({
              iframeWidth: `1px`,
              iframeMinWidth: `100%`
            });
          } else {
            this.setState({
              iframeWidth: `100%`
            });
          }
        }
        if (heightmobile !== undefined) {
          this.setState({
            iframeHeight: `${heightmobile}px`
          });
        } else {
          this.setState({
            iframeHeight: `${heightdesktop}px`
          });
        }
        break;
      default:
        break;
    }
  }

  render() {
    const { source, hex, scrollbar } = this.props;
    const { iframeWidth, iframeHeight, iframeMinWidth } = this.state;
    let noscroll = 'no';
    if (scrollbar) {
      noscroll = 'yes';
    }

    return (
      <React.Fragment>
        {!isiOS() ? (
          <iframe
            ref={selector => {
              this.iframeSelector = selector;
            }}
            className="iframe__inner"
            src={source}
            title={source}
            scrolling={noscroll}
            style={{ width: iframeWidth, height: iframeHeight, borderColor: hex }}
          />
        ) : (
          <iframe
            ref={selector => {
              this.iframeSelector = selector;
            }}
            className="iframe__inner"
            src={source}
            title={source}
            scrolling={noscroll}
            style={{ width: iframeWidth, height: iframeHeight, borderColor: hex, minWidth: iframeMinWidth }}
          />
        )}
      </React.Fragment>
    );
  }
}
