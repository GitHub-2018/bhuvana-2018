const linklist = (jQuery) => {

	//cache DOM
	let $currentYear = $(".currentYear")

	const getCurrentYear = () => {
		return new Date().getFullYear()
	}

	const _render = () => {
    $currentYear.text(getCurrentYear())
	}

	_render()

	return {
		getCurrentYear: getCurrentYear
	}
}

linklist(jQuery)
