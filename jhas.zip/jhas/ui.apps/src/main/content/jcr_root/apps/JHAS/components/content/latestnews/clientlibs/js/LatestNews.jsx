import React from 'react';
import { removeBasePath } from '../../../../../clientlibs/publish/src/utils/globals';

import '../scss/LatestNews.scss';

export default class LatestNews extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      articleCount: 0
    };
    this.handleResize = this.handleResize.bind(this);
  }

  componentDidMount() {
    window.addEventListener('resize', this.handleResize);
    this.handleResize();
  }

  componentWillUnmount() {
    window.addEventListener('resize', null);
  }

  handleResize() {
    const screenWidth = document.body.clientWidth;
    const { desktopcount, tabletcount, mobilecount } = this.props;

    switch (true) {
      case screenWidth > 1024:
        this.setState({
          articleCount: desktopcount
        });
        break;
      case screenWidth <= 1024 && screenWidth >= 768:
        this.setState({
          articleCount: tabletcount
        });
        break;
      case screenWidth < 768:
        this.setState({
          articleCount: mobilecount
        });
        break;
      default:
        this.setState({
          articleCount: 0
        });
        break;
    }
  }

  render() {
    const { newstitle, newsarticles, buttonpath } = this.props;
    const { articleCount } = this.state;
    const newsArticlesJSON = JSON.parse(newsarticles);
    const limitedArticleSet = newsArticlesJSON.articles.slice(0, parseInt(articleCount, 10));

    return (
      <React.Fragment>
        <section className="latest__news">
          {newstitle && <h2>{newstitle}</h2>}
          {limitedArticleSet.map((value, index) => {
            return (
              <div className="latest__news--container" key={index}>
                <p className="latest__news--date article__date">{value.modifiedDate}</p>
                <a href={removeBasePath(value.path)} className="articleLink__title">
                  {value.title}
                </a>
                <p className="latest__news--summary">{value.summary}</p>
              </div>
            );
          })}
        </section>
        {buttonpath && (
          <a href={removeBasePath(buttonpath)} className="button button__tertiary" role="button">
            <span>View All News</span>
          </a>
        )}
      </React.Fragment>
    );
  }
}
