export const getYoutubeVideoCode = source => {
  let youtubeId;
  if (source.match(/(\?|&)v=([^&#]+)/)) {
    youtubeId = source.match(/(\?|&)v=([^&#]+)/).pop();
  } else if (source.match(/(\.be\/)+([^\/]+)/)) {
    youtubeId = source.match(/(\.be\/)+([^\/]+)/).pop();
  } else if (source.match(/(\embed\/)+([^\/]+)/)) {
    youtubeId = source
      .match(/(\embed\/)+([^\/]+)/)
      .pop()
      .replace('?rel=0', '');
  }
  return youtubeId;
};

export default {
  getYoutubeVideoCode
};
