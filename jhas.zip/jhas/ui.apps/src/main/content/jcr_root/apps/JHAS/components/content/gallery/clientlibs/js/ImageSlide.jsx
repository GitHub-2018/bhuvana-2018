import React from 'react';
import { removeBasePath } from '../../../../../clientlibs/publish/src/utils/globals';

export default class ImageSlide extends React.Component {
  render() {
    const { urlLink, options, image, title, slideHeight, slideWidth, description, showSmallSlideInfo, slideHeightDescription } = this.props;
    return (
      <div className="gallery__item" style={{ width: slideWidth, height: slideHeightDescription }}>
        <a href={removeBasePath(urlLink)} target={options} rel={options === '_blank' ? 'noopener noreferrer' : ''}>
          <img src={image} alt={title} style={{ height: slideHeight }} />
          <div className={`gallery__slideInfo ${showSmallSlideInfo}`}>
            <h3 className="gallery__title articleLink__title">{title}</h3>
            <p className="gallery__description">{description}</p>
          </div>
        </a>
      </div>
    );
  }
}
