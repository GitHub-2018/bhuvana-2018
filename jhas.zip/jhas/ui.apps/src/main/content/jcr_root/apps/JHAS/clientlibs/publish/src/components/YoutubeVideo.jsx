import React from 'react';
import { getYoutubeVideoCode } from '../utils/media';

export default class YoutubeVideo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { source, title } = this.props;
    return (
      <div className="YoutubeVideo">
        <iframe title={title} src={`https://www.youtube.com/embed/${getYoutubeVideoCode(source)}?rel=0&enablejsapi=1`} frameBorder="0" allowFullScreen />
      </div>
    );
  }
}
