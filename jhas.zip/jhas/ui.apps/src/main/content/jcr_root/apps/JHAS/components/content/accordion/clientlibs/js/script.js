var accordion = function accordion(jQuery) {
  'use strict';

  if ($('.accordion').length !== 0) {
    var $accordionItem = $('.accordion__item');
    var $title = $('.accordion__title');
    var content = '.accordion__content';
    var hash = window.location.hash;

    $accordionItem.each(function() {
      $(this)
        .children('.anchor')
        .attr(
          'id',
          $(this)
            .find('.accordion__title h3')
            .text()
            .split(' ')
            .join('-')
            .toLowerCase()
        );
    });

    function accordionToggle() {
      // Add active class to title
      $(this).toggleClass('active');

      // Removed inactive classes
      $('.accordion__title')
        .not(this)
        .removeClass('active');

      // Open current fold
      $(this)
        .next(content)
        .slideToggle();

      // Close other folds
      $(this)
        .parent()
        .siblings()
        .children(content)
        .slideUp();

      return false;
    }

    $title.on('click', accordionToggle);

    if (hash) {
      $(hash)
        .siblings('.accordion__title')
        .click();
    }

    if ($('.accordion__menu #editable').val() === 'true') {
      $('.accordion__content').addClass('accordion__content--open');
      $('.accordion__menu h3').css('pointer-events', 'none');
    }
  }
};

accordion(jQuery);

window.addEventListener('popstate', function() {
  if (window.location.hash) {
    var hash = window.location.hash;
    $(hash)
      .siblings('.accordion__title')
      .click();
  }
});
