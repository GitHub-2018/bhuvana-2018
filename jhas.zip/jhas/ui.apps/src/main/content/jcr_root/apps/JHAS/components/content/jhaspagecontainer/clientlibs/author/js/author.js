
/*------ Author dialog On Load functions ------- */

$(document).on('foundation-contentloaded', function() {


// page container common function
  $('.containerSelection').each(function() {
    showHideContainerTab(this);
  });


});

/*------ Author dialog event functions -------*/

$(document).on('selected', '.containerSelection', function() {
  showHideContainerTab(this);
});


