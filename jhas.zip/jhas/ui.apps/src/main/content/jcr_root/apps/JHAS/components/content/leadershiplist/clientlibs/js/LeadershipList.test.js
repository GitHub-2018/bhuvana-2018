import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';

import LeadershipList from './LeadershipList';

describe('<LeadershipList />', () => {
  it('Render a <LeadershipList /> component', () => {
    const wrapper = shallow(<LeadershipList />);
    expect(wrapper).to.have.lengthOf(1);
  });
});
