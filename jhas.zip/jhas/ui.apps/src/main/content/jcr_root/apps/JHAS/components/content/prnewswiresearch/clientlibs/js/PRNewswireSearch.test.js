import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';

import PRNewswireSearch from './PRNewswireSearch';

describe('<PRNewswireSearch />', () => {
  it('Should render the PRNewswireSearch component', () => {
    const wrapper = shallow(<PRNewswireSearch />);
    expect(wrapper).to.have.lengthOf(1);
  });
});
