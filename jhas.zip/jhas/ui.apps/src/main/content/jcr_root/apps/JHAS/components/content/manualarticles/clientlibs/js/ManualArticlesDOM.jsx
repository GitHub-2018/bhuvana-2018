import { DOMModel, DOMComponent } from 'react-dom-components';
import ManualArticles from './ManualArticles';

class ManualArticlesModel extends DOMModel {
  constructor(element) {
    super(element);
    this.getDataAttribute('layout');
    this.getDataAttribute('toggle');
    this.getDataAttribute('nodepath');
  }
}

export default class ManualArticlesDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'ManualArticles';
    this.model = ManualArticlesModel;
    this.component = ManualArticles;
  }
}
