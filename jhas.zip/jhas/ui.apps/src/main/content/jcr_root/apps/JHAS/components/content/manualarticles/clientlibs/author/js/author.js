

/*------ Author dialog On Load functions ------- */

$(document).on('foundation-contentloaded', function() {


//articles
  $('.hideToggleOptions').each(function() {
    showHideArticleOptionsCheckbox(this);
  });
//articles
  $('.articleViewType').each(function() {
    showHideArticleOptionsSelect(this);
  });


});

/*------ Author dialog event functions -------*/

$(document).on('selected', '.articleViewType', function() {
  showHideArticleOptionsSelect(this);
});

$(document).on('click', '.hideToggleOptions', function() {
  showHideArticleOptionsCheckbox(this);
});



function showHideArticleOptionsCheckbox(el) {
    if (!$(el).is(':checked') && $(el).parent().parent().parent().children().find('.articleViewType').data("select").getValue() == 'list') {
        $(el).parent().parent().nextAll().eq(0).hide();
        $(el).parent().parent().nextAll().eq(1).hide();
        $(el).parent().parent().nextAll().eq(2).hide();
        $(el).parent().parent().nextAll().eq(3).hide();
    } else {
        $(el).parent().parent().nextAll().eq(0).show();
        $(el).parent().parent().nextAll().eq(1).show();
        $(el).parent().parent().nextAll().eq(2).show();
        $(el).parent().parent().nextAll().eq(3).show();
    }

}

function showHideArticleOptionsSelect(el) {
    if (!$(el).parent().parent().children().find('.hideToggleOptions').is(':checked') && $(el).data("select").getValue() == 'list') {
        $(el).parent().nextAll().eq(1).hide();
        $(el).parent().nextAll().eq(2).hide();
        $(el).parent().nextAll().eq(3).hide();
        $(el).parent().nextAll().eq(4).hide();
    } else {
        $(el).parent().nextAll().eq(1).show();
        $(el).parent().nextAll().eq(2).show();
        $(el).parent().nextAll().eq(3).show();
        $(el).parent().nextAll().eq(4).show();
    }
}

