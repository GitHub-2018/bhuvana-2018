import React from 'react';
import { removeBasePath } from '../../../../../clientlibs/publish/src/utils/globals';
import { isIE } from '../../../../../clientlibs/publish/src/utils/device';
import '../scss/Image.scss';

export default class ImageComponent extends React.Component {
  render() {
    const { filereference, alttext, title, caption, linkurl, imagewidth, textalign, horizontalalign, openlinkoptions } = this.props;
    let setImgWidth = '';
    let responsiveIE = '';
    if (imagewidth !== 0 && imagewidth !== undefined) {
      setImgWidth = `${imagewidth}px`;
    }
    if (isIE() && setImgWidth === '') {
      responsiveIE = `100%`;
    }
    return (
      <React.Fragment>
        <div className={`image__component ${horizontalalign}`}>
          <div className={`image__placeholder ${textalign}`}>
            {linkurl !== undefined ? (
              <a href={removeBasePath(linkurl)} target={openlinkoptions === 'samewindow' ? '_self' : '_blank'} rel={openlinkoptions === 'samewindow' ? '' : 'noopener noreferrer'}>
                <img className="img-responsive" src={filereference} alt={alttext} title={title} width={setImgWidth} style={{ width: `${responsiveIE}` }} />
                {caption && <span className={`img__caption ${textalign}`}>{caption}</span>}
              </a>
            ) : (
              <React.Fragment>
                <img className="img-responsive" src={filereference} alt={alttext} title={title} width={setImgWidth} style={{ width: `${responsiveIE}` }} />
                {caption && <span className={`img__caption ${textalign}`}>{caption}</span>}
              </React.Fragment>
            )}
          </div>
        </div>
      </React.Fragment>
    );
  }
}
