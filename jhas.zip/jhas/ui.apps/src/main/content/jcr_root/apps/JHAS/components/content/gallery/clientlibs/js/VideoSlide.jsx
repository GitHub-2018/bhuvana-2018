import React from 'react';
import HTML5Video from '../../../../../clientlibs/publish/src/components/HTML5Video';
import YoutubeVideo from '../../../../../clientlibs/publish/src/components/YoutubeVideo';

export default class VideoSlide extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showDescription: ''
    };

    this.handleContentLoaded = this.handleContentLoaded.bind(this);
    this.handleSlideDescriptionShow = this.handleSlideDescriptionShow.bind(this);
    this.handleSlideDescriptionHide = this.handleSlideDescriptionHide.bind(this);
  }

  handleContentLoaded(data) {
    const { onContentLoaded } = this.props;
    onContentLoaded(data);
  }

  handleSlideDescriptionShow() {
    this.setState({
      showDescription: ''
    });
  }

  handleSlideDescriptionHide() {
    const { showSmallSlideInfo } = this.props;
    if (!showSmallSlideInfo) {
      this.setState({
        showDescription: 'gallery__fade'
      });
    }
  }

  render() {
    const { videoUrl, title, description, subtitles, showSmallSlideInfo, slideWidth, slideHeightDescription } = this.props;
    const { showDescription } = this.state;

    let videoType;
    if (videoUrl !== undefined) {
      if (videoUrl.indexOf('youtu') > -1) {
        videoType = <YoutubeVideo title={title} source={videoUrl} />;
      } else {
        videoType = <HTML5Video source={videoUrl} subtitles={subtitles} onContentLoaded={this.handleContentLoaded} videoTag={this.handleVideoTag} />;
      }
    }

    return (
      <div className="gallery__item" onMouseEnter={this.handleSlideDescriptionHide} onMouseLeave={this.handleSlideDescriptionShow} style={{ width: slideWidth, height: slideHeightDescription }}>
        <div className="embed-responsive embed-responsive-16by9">{videoType}</div>
        <div className={`gallery__slideInfo ${showDescription} ${showSmallSlideInfo}`}>
          <h3 className="gallery__title articleLink__title">{title}</h3>
          <p className="gallery__description">{description}</p>
        </div>
      </div>
    );
  }
}
