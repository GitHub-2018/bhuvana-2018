const jhascontainer = (jQuery) => {

	const MAX_WIDTH = 1366
	const SCREEN_RATIO = 16 / 9

	const setBackgroundHeights = ($container) => {
		console.log($container)
		let containerHeight = $container.children('.containerheight').val()
		$(window).on('resize', function () {
			let backgroundWidth = $container.innerWidth() //$('.background').innerWidth()
			let respHeight = (parseInt(containerHeight) * backgroundWidth) / MAX_WIDTH
			$container.children('.backgroundcolor__container').css('min-height', respHeight)
			if((backgroundWidth / respHeight) > SCREEN_RATIO) {
				$container.children('.backgroundcolor__container').css({'background-size': 'cover', 'background-position': 'center center'})
			} else {
				$container.children('.backgroundcolor__container').css('background-size', 'contain')
			}
		})
	}

	$('.jhaspagecontainer').each(function () {
		setBackgroundHeights($(this))
	})
}

jhascontainer(jQuery)
