import React from 'react';
import { getFileExtension } from '../utils/globals';

export default class HTML5Video extends React.Component {
  constructor(props) {
    super(props);

    this.handleLoadedContent = this.handleLoadedContent.bind(this);
  }

  handleLoadedContent() {
    const { onContentLoaded } = this.props;
    onContentLoaded(this.videoTag);
  }

  render() {
    const { source, subtitles } = this.props;
    return (
      <div className="HTML5Video">
        <video
          preload="true"
          controls
          onLoadedData={this.handleLoadedContent}
          ref={selector => {
            this.videoTag = selector;
          }}
        >
          <source src={source} type={`video/${getFileExtension(source)}`} />
          <track src={subtitles} kind="subtitles" srcLang="en" label="English" />
          <p>Your browser does not support the HTML5 Video Element</p>
        </video>
      </div>
    );
  }
}
