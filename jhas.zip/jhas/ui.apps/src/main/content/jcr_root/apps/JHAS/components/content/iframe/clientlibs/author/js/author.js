
  $(document).on('foundation-contentloaded', function() {

  // Remove default width as 0 from image dialog selection


    $('.widthPaddingType').each(function() {
      $(this).css('width', '60px');
    });

    $('.inline-styler').each(function() {
      $(this).parent().css('display', 'inline-block');
    });


 });

 

