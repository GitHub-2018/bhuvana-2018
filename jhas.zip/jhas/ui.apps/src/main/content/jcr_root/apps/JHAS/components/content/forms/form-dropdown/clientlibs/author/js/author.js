
/*------ Author dialog On Load functions ------- */

$(document).on('foundation-contentloaded', function() {



// form dropdown
  $('.statelist').each(function() {
    showHideCustomDropdown($(this));
  });


});

/*------ Author dialog event functions -------*/


$(document).on('click', '.statelist', function() {
  showHideCustomDropdown(this);
});

/*------ Author dialog functions details -------*/

function showHideCustomDropdown(el) {
    if ($(el).prop("checked")) {
        $(el).parent().parent().siblings(".customlist").hide();
        $(el).parent().parent().siblings(".customlist").find(".js-coral-Multifield-input").each(function() {
            $(this).remove();
        });
    } else {
        $(el).parent().parent().siblings(".customlist").show();
    }
}

