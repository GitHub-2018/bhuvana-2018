import { DOMModel, DOMComponent } from 'react-dom-components';
import LeadershipProfiles from './LeadershipProfiles';

class LeadershipProfilesModel extends DOMModel {
  constructor(element) {
    super(element);
  }
}

export default class LeadershipProfilesDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'LeadershipProfiles';
    this.model = LeadershipProfilesModel;
    this.component = LeadershipProfiles;
  }
}
