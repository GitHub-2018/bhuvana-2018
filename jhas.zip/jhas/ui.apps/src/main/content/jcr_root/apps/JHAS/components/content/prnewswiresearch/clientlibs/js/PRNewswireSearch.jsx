import React from 'react';
import axios from 'axios';
import { getReadableDate, getMonthName, removeBasePath } from '../../../../../clientlibs/publish/src/utils/globals';

import '../scss/PRNewswireSearch.scss';

export default class PRNewswireSearch extends React.Component {
  constructor(props) {
    super(props);

    const { category } = this.props;
    this.state = {
      newsArticles: [],
      categories: [],
      years: [],
      months: [],
      selectedCategory: category ? category : 'All',
      selectedYear: 'All',
      selectedMonth: 'All',
      searchTerm: '',
      hasContentLoaded: false
    };
  }

  componentDidMount() {
    axios
      .get('/bin/sling/getLatestNews')
      .then(response => {
        this.setDropDowns(response.data.articleDetails);
        this.setState({
          hasContentLoaded: true,
          newsArticles: response.data.articleDetails
        });
      })
      .catch(error => {
        console.log(error);
        this.setState({
          hasContentLoaded: true
        });
      });
  }

  setDropDowns(response) {
    const tempCategories = [];
    const tempMonths = [];
    const tempYears = [];

    response.map(value => {
      if (tempCategories.indexOf(value.articleCategory) === -1) {
        tempCategories.push(value.articleCategory);
      }

      const publishdate = new Date(value.articlePublishedDate * 1000);
      const publishYear = publishdate.getYear() + 1900;
      if (tempYears.indexOf(publishYear) === -1) {
        tempYears.push(publishYear);
      }

      const publishMonth = publishdate.getMonth();
      if (tempMonths.indexOf(publishMonth) === -1) {
        tempMonths.push(publishMonth);
      }
    });

    this.setState({
      categories: tempCategories.sort(),
      years: tempYears.sort().reverse(),
      months: tempMonths.sort((a, b) => a - b)
    });
  }

  handleFilterView() {
    if (this.filterOptions.style.display === 'none') {
      this.filterOptions.style.display = 'block';
    } else {
      this.filterOptions.style.display = 'none';
    }
  }

  handleSelectFilter() {
    this.setState({
      selectedCategory: this.selectCategory.value,
      selectedYear: this.selectYear.value,
      selectedMonth: this.selectMonth.value
    });
  }

  handleSearch(e) {
    this.setState({
      searchTerm: e.currentTarget.value
    });
  }

  handleReset(e) {
    e.preventDefault();
    this.selectCategory.value = 'All';
    this.selectYear.value = 'All';
    this.selectMonth.value = 'All';
    this.setState({
      selectedCategory: 'All',
      selectedYear: 'All',
      selectedMonth: 'All',
      searchTerm: ''
    });
  }

  render() {
    const { searchicon } = this.props;
    const { newsArticles, categories, years, months, selectedCategory, selectedYear, selectedMonth, searchTerm, hasContentLoaded } = this.state;
    const mappedArticles = newsArticles
      .filter(value => {
        return value.articleTitle.toLowerCase().search(searchTerm.toLowerCase()) !== -1 || value.articleDescription.toLowerCase().search(searchTerm.toLowerCase()) !== -1;
      })
      .filter(value => {
        const publishdate = new Date(value.articlePublishedDate * 1000);
        const publishYear = publishdate.getYear() + 1900;
        const publishMonth = publishdate.getMonth();
        if (
          (value.articleCategory === selectedCategory || selectedCategory === 'All') &&
          (publishYear.toString() === selectedYear || selectedYear === 'All') &&
          (publishMonth.toString() === selectedMonth || selectedMonth === 'All')
        ) {
          return true;
        }
        return false;
      })
      .map((value, index) => {
        return (
          <div key={index} className="filter__result">
            <span className="filter__category article__category">{value.articleCategory}</span>
            <a className="articleLink__title" href={removeBasePath(value.articlePath)}>
              {value.articleTitle}
            </a>
            <span className="filter__date article__date">{getReadableDate(value.articlePublishedDate)}</span>
            <p>{value.articleDescription}</p>
          </div>
        );
      });

    return (
      <React.Fragment>
        <div className="filter">
          <div className="row">
            <div className="col-md-10 col-xs-9">
              <div className="filter__search">
                <input type="text" className="filter__input" placeholder="Search News" value={searchTerm} onChange={this.handleSearch.bind(this)} />
                <button className="filter__searchIcon" onClick={this.handleSearch.bind(this)}>
                  <img src="/content/dam/johnhancock/common/icons/search.svg" alt="Filter News" />
                </button>
              </div>
            </div>
            <div className="col-md-2 col-xs-3 filter__toggle--row">
              <button type="button" className="filter__toggle" onClick={this.handleFilterView.bind(this)}>
                <span>Filter</span>
                <i className="ion-ios-settings-strong" />
              </button>
            </div>
          </div>
          <div className="filter__wrap">
            <div
              className="filter__options"
              ref={selector => {
                this.filterOptions = selector;
              }}
              style={{ display: 'none' }}
            >
              <div className="row">
                <div className="col-md-4">
                  <label htmlFor="filter__categoryDropdown">Category</label>
                  <select
                    className="filter__categoryDropdown"
                    ref={selector => {
                      this.selectCategory = selector;
                    }}
                    onChange={this.handleSelectFilter.bind(this)}
                  >
                    <option>All</option>
                    {categories.map((value, index) => (
                      <option key={index}>{value}</option>
                    ))}
                  </select>
                </div>
                <div className="col-md-4">
                  <label htmlFor="filter__yearDropdown">Year</label>
                  <select
                    className="filter__yearDropdown"
                    ref={selector => {
                      this.selectYear = selector;
                    }}
                    onChange={this.handleSelectFilter.bind(this)}
                  >
                    <option>All</option>
                    {years.map((value, index) => (
                      <option key={index}>{value}</option>
                    ))}
                  </select>
                </div>
                <div className="col-md-4">
                  <label htmlFor="filter__monthDropdown">Month</label>
                  <select
                    className="filter__monthDropdown"
                    ref={selector => {
                      this.selectMonth = selector;
                    }}
                    onChange={this.handleSelectFilter.bind(this)}
                  >
                    <option>All</option>
                    {months.map((value, index) => (
                      <option key={index} value={index}>
                        {getMonthName(value)}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="filterList">{mappedArticles}</div>
            {hasContentLoaded &&
              mappedArticles.length === 0 && (
                <span className="filter__noresults">
                  <strong>No Results Found.</strong> Try adjusting filters or
                  <a href="#" className="filter__reset" onClick={this.handleReset.bind(this)}>
                    {' '}
                    try again.
                  </a>
                </span>
              )}
          </div>
        </div>
      </React.Fragment>
    );
  }
}
