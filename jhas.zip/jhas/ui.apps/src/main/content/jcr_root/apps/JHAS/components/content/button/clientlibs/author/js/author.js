
  $(document).on('foundation-contentloaded', function() {

  // Remove default width as 0 from image dialog selection

    $('.buttonsection').each(function() {
      showHideButtonOptions(this);
    });


  });


  $(document).on('click', '.buttonsection', function() {
    showHideButtonOptions(this);
  });



  