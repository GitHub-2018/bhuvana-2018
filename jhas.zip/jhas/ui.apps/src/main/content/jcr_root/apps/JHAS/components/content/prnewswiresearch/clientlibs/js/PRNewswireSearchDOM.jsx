import { DOMModel, DOMComponent } from 'react-dom-components';
import PRNewswireSearch from './PRNewswireSearch';

class PRNewswireSearchModel extends DOMModel {
  constructor(element) {
    super(element);
    this.getDataAttribute('category');
    this.getDataAttribute('year');
    this.getDataAttribute('month');
  }
}

export default class PRNewswireSearchDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'PRNewswireSearch';
    this.model = PRNewswireSearchModel;
    this.component = PRNewswireSearch;
  }
}
