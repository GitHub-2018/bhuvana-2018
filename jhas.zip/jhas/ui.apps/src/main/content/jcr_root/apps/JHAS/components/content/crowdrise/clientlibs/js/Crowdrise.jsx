import React from 'react';
import axios from 'axios';

import '../scss/Crowdrise.scss';

export default class Crowdrise extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      campaignLink: '#',
      totalRaised: ''
    };
  }

  componentDidMount() {
    const { eventid } = this.props;
    const BASE_URI = 'https://go.crowdrise.com/v2/event/';
    axios
      .get(`${BASE_URI}${eventid}`)
      .then(response => {
        this.setState({
          campaignLink: response.data.data.campaign_url,
          totalRaised: parseInt(response.data.data.event_total_display, 10).toLocaleString()
        });
      })
      .catch(error => {
        console.log(error);
      });
  }

  render() {
    const { bgcolor, textcolor } = this.props;
    const { campaignLink, totalRaised } = this.state;
    return (
      <React.Fragment>
        <div className="crowdrise">
          <a href={campaignLink} style={{ color: textcolor }}>
            ${totalRaised}
          </a>
          <div className="bar" style={{ backgroundColor: bgcolor }} />
        </div>
      </React.Fragment>
    );
  }
}
