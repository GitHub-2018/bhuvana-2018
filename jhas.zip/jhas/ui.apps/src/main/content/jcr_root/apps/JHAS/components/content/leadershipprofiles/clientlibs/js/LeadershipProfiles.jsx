import React from 'react';
import axios from 'axios';
import { removeBasePath } from '../../../../../clientlibs/publish/src/utils/globals';
import { sortProfiles } from '../../../../../clientlibs/publish/src/utils/leadership';

export default class LeadershipProfiles extends React.Component {
  constructor() {
    super();
    this.state = {
      profile: []
    };
  }

  componentDidMount() {
    axios
      .get('/bin/sling/getLeadershipProfiles')
      .then(response => {
        this.setState({
          profile: response.data.profile
        });
      })
      .catch(error => {
        console.log(error);
      });
  }

  render() {
    const { profile } = this.state;
    const sortedProfiles = sortProfiles(profile);

    return (
      <React.Fragment>
        <div className="leadership__profiles">
          {sortedProfiles.map((value, index) => {
            return (
              <div key={index} className="profile text-center">
                <h3>
                  <a href={removeBasePath(value.url)}>{value.name}</a>
                </h3>
                <p dangerouslySetInnerHTML={{ __html: value.title }} style={{ marginBottom: 0 }} />
                <p>{value.bu}</p>
              </div>
            );
          })}
        </div>
      </React.Fragment>
    );
  }
}
