import React from 'react';
import Masonry from 'react-masonry-component';
import axios from 'axios';
import { removeBasePath } from '../../../../../clientlibs/publish/src/utils/globals';

import '../scss/ManualArticles.scss';

export default class ManualArticles extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      view: 'tile',
      manualArticles: [],
      gridItemWidth: 350,
      masonryOptions: {
        itemSelector: '.grid__item',
        gutter: 20,
        fitWidth: true,
        columnWidth: 350
      }
    };

    this.onResize = this.onResize.bind(this);
  }

  componentDidMount() {
    const { nodepath } = this.props;
    axios
      .get('/bin/sling/getjhasarticles', {
        params: {
          manualnodepath: nodepath
        }
      })
      .then(response => {
        this.setState({
          manualArticles: response.data.articles
        });
      })
      .catch(error => {
        console.log(error);
      });

    const columns = {
      largeDevices: 1280,
      threeCol: 792,
      oneCol: 460,
      magicNum: 13.75
    };

    /*     if (document.querySelector('.grid')) {
      const parentWidth = document.querySelector('.grid').parentElement.parentElement.offsetWidth;

      if (parentWidth > columns.threeCol) {
        this.setState({
          gridItemWidth: parentWidth / 3 - columns.magicNum,
          masonryOptions: {
            itemSelector: '.grid_item',
            gutter: 20,
            fitWidth: true
          }
        });
      }
    }
 */
    this.onResize();
    window.addEventListener('resize', this.onResize);
  }

  onResize() {
    this.setState({
      gridItemWidth: window.outerWidth / 3,
      masonryOptions: {
        itemSelector: '.grid_item',
        columnWidth: window.outerWidth / 3,
        gutter: 20,
        fitWidth: true
      }
    });
  }

  handleTileView(e) {
    e.preventDefault();
    if (this.state.view !== 'tile') {
      this.setState({
        view: 'tile'
      });
    }
  }

  handleListView(e) {
    e.preventDefault();
    if (this.state.view !== 'list') {
      this.setState({
        view: 'list'
      });
    }
  }

  render() {
    const { manualArticles, masonryOptions, gridItemWidth } = this.state;

    const jhasManualArticles = manualArticles.map(manualarticle => {
      return (
        <div className="grid__item grid__article">
          <a href={removeBasePath(manualarticle.url)}>
            <img className="article__img" src={manualarticle.imgurl} alt={manualarticle.title} />
          </a>
          <div className="article__content">
            <a className="articleLink__title" href={removeBasePath(manualarticle.url)}>
              {manualarticle.title}
            </a>
            <span className="article__author">{manualarticle.author}</span>
            <span className="article__date article__date">{manualarticle.modifiedDate}</span>
            <p className="article__text">{manualarticle.desc}</p>
          </div>
        </div>
      );
    });

    return (
      <React.Fragment>
        <div className="tile__to__listview">
          <button className="tile__view togglebtn" onClick={this.handleTileView.bind(this)}>
            <i className="fa fa-th-large" aria-hidden="true">
              Tile
            </i>
          </button>
          <button className="list__view togglebtn pull-right" onClick={this.handleListView.bind(this)}>
            <i className="fa fa-th-list" aria-hidden="true">
              List
            </i>
          </button>
        </div>
        <div className="grid">
          <Masonry options={masonryOptions}>{jhasManualArticles}</Masonry>
        </div>
      </React.Fragment>
    );
  }
}
