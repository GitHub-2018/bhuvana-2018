import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';

import LeadershipProfiles from './LeadershipProfiles';

describe('<LeadershipProfiles />', () => {
  it('Render a <LeadershipProfiles /> component', () => {
    const wrapper = shallow(<LeadershipProfiles />);
    expect(wrapper).to.have.lengthOf(1);
  });
});
