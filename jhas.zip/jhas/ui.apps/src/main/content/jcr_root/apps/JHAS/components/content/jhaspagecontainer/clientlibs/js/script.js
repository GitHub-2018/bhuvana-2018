'use strict';

var jhascontainer = function jhascontainer(jQuery) {
  var MAX_WIDTH = 1366;
  var SCREEN_RATIO = 16 / 9;

  var setBackgroundHeights = function setBackgroundHeights($container) {
    $(document).ready(setContainerHieghts($container));
    $(window).on('resize', setContainerHieghts($container));
  };

  var setContainerHieghts = function setContainerHieghts($container) {
    var containerHeight = $container.find('.containerheight').val();
    var backgroundWidth = $container.innerWidth(); //$('.background').innerWidth()
    var respHeight = (parseInt(containerHeight) * backgroundWidth) / MAX_WIDTH;
    $container.find('.backgroundcolor__container').css('min-height', respHeight);
    $container.find('.pageContainerOpacity').css('min-height', respHeight);
    if (backgroundWidth / respHeight > SCREEN_RATIO) {
      $container.find('.backgroundcolor__container').css({ 'background-size': 'cover', 'background-position': 'center center' });
    } else {
      $container.find('.backgroundcolor__container').css('background-size', 'contain');
    }
  };

  var setContainerLinks = function setContainerLinks($container) {
    var containerHref = $container.find('.pagecontainer').data('href');
    var containerTarget = $container.find('.pagecontainer').data('container-target');
    $container.find('.pagecontainer').on('click', function() {
      window.open(refineJohnhancockURL(containerHref), containerTarget);
      return false;
    });
  };
  $('.jhaspagecontainer').each(function() {
    setBackgroundHeights($(this));
    setContainerLinks($(this));
  });
};

jhascontainer(jQuery);
