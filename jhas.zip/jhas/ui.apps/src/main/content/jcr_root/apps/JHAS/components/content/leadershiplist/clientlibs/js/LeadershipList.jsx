import React from 'react';
import axios from 'axios';
import { removeBasePath } from '../../../../../clientlibs/publish/src/utils/globals';
import { sortProfiles } from '../../../../../clientlibs/publish/src/utils/leadership';

export default class LeadershipList extends React.Component {
  constructor() {
    super();

    this.state = {
      profile: []
    };
  }

  componentDidMount() {
    axios
      .get('/bin/sling/getLeadershipProfiles')
      .then(response => {
        this.setState({
          profile: response.data.profile
        });
      })
      .catch(error => {
        console.log(error);
      });
  }

  render() {
    const { profile } = this.state;
    const sortedProfiles = sortProfiles(profile);
    const leader = sortedProfiles
      .filter(value => removeBasePath(value.url) !== removeBasePath(window.location.pathname))
      .map((value, index) => {
        return (
          <li key={index} className="linkList__link">
            <a href={removeBasePath(value.url)}>{value.name}</a>
          </li>
        );
      });

    return (
      <React.Fragment>
        <div className="linkList">
          <ul className="linkList__list--vertical leadership__list text-xs-left">{leader}</ul>
        </div>
      </React.Fragment>
    );
  }
}
