import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';

import ImageComponent from './ImageComponent';

describe('<ImageComponent />', () => {
  const wrapper = shallow(<ImageComponent filereference="http://placehold.it/300x300" />);

  it('Should render the Image component', () => {
    expect(wrapper).to.have.lengthOf(1);
  });

  it('Should display an image', () => {
    expect(wrapper.find('img')).to.have.lengthOf(1);
    expect(wrapper.find('img').prop('src')).to.not.be.undefined;
  });

  it('Should have an alt description for accessibility', () => {
    expect(wrapper.find('img').prop('alt')).to.not.be.undefined;
  });

  it('Should recieve props', () => {
    console.log(wrapper.prop('filereference'));
    expect(wrapper.prop('filereference')).to.not.be.undefined;
  });
});
