
  $(document).on('foundation-contentloaded', function() {

  // Remove default width as 0 from image dialog selection

    $('.imagevideotoggle').each(function() {
    	showHideGalleyOptions($(this));
    });


  });

  /*------ Author dialog event functions -------*/

  $(document).on('selected', '.imagevideotoggle', function() {
    showHideGalleyOptions(this);
  });

$(document).on('blur', '.cq-gallery-video', function() {
    showHideManualVideoThumbnails(this);
  });

/*------ Author dialog functions details -------*/


function showHideGalleyOptions(el) {
      if ($(el).data("select").getValue() == 'imageSlide') {
          $(el).parent().nextAll().eq(0).show();
          $(el).parent().nextAll().eq(5).show();
          $(el).parent().nextAll().eq(6).show();
          $(el).parent().nextAll().eq(1).hide();
          $(el).parent().nextAll().eq(2).hide();
      } else if ($(el).data("select").getValue() == 'videoSlide') {
          $(el).parent().nextAll().eq(0).hide();
          $(el).parent().nextAll().eq(5).hide();
          $(el).parent().nextAll().eq(6).hide();
          $(el).parent().nextAll().eq(1).show();
          $(el).parent().nextAll().eq(2).show();
      }

  }

 function showHideManualVideoThumbnails(el) {
      var pattern = new RegExp("^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+$");
      if (!$(el).children().find('input').val() || pattern.test($(el).children().find('input').val())) {
          $(el).parent().nextAll().eq(0).children().find('input').val('');
          $(el).parent().nextAll().eq(0).hide();
      } else {
          $(el).parent().nextAll().eq(0).show();
      }
  }



