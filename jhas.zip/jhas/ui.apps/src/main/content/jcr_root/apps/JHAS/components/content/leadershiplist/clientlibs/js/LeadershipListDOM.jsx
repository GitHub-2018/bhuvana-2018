import { DOMModel, DOMComponent } from 'react-dom-components';
import LeadershipList from './LeadershipList';

class LeadershipListModel extends DOMModel {
  constructor(element) {
    super(element);
  }
}

export default class LeadershipListDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'LeadershipList';
    this.model = LeadershipListModel;
    this.component = LeadershipList;
  }
}
