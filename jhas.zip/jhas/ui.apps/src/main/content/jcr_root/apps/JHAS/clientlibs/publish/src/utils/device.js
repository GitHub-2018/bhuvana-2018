export const isiOS = () => /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;

export const isIE = () => !!window.MSInputMethodContext && !!document.documentMode;

export default {
  isiOS,
  isIE
};
