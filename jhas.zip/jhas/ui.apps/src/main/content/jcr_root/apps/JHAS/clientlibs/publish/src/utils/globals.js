export const removeBasePath = url => {
  if (typeof url !== 'undefined') {
    if (url.includes('/content/johnhancock')) {
      let path = url;
      if (!path.includes('.html')) {
        path = `${url}.html`;
      }
      return path.replace('/content/johnhancock', '');
    }
    return url;
  }
  return '';
};

export const appendExtension = path => {
  if (typeof path !== 'undefined') {
    if (!path.includes('.html')) {
      `${path}.html`;
    }
    return path;
  }
  return '';
};

export const getUrlParameter = sParam => {
  const sPageURL = decodeURIComponent(window.location.search.substring(1));
  const sURLVariables = sPageURL.split('&');
  for (let i = 0; i < sURLVariables.length; i += 1) {
    const sParameterName = sURLVariables[i].split('=');
    if (sParameterName[0] === sParam) {
      return sParameterName[1];
    }
  }
  return false;
};

export const getReadableDate = inputDate => new Date(inputDate * 1000).toDateString().substr(4);

export const getMonthName = monthIndex => {
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return monthNames[monthIndex];
};

export const isNumber = n => !isNaN(n) && isFinite(n);

export const getFileExtension = videoUrl => videoUrl.split('.').pop();

export default {
  removeBasePath,
  appendExtension,
  getUrlParameter,
  getReadableDate,
  getMonthName,
  isNumber,
  getFileExtension
};
