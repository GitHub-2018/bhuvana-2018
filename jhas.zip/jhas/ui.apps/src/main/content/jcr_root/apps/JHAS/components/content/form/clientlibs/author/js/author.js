
  $(document).on('foundation-contentloaded', function() {

  // Remove default width as 0 from image dialog selection

	$('.cq-dialog-formtype').each(function() {
      showHideFormType($(this));
    });



  });

  /*------ Author dialog event functions -------*/



  $(document).on('selected', '.cq-dialog-formtype', function() {
    showHideFormType(this);
  });



  /*------ Author dialog functions details -------*/



  function showHideFormType(el) {

      var $formOptions = $(el).parent().parent().parent().parent().children().children().children();

      if ($(el).data("select").getValue() == 'Email') {
          for (i = 1; i <= 11; i++) {
              $formOptions.eq(i).hide();
          }
          for (j = 12; j <= 19; j++) {
              $formOptions.eq(j).show();
          }
      } else if ($(el).data("select").getValue() == 'Salesforce') {
          for (i = 1; i <= 11; i++) {
              $formOptions.eq(i).show();
          }
          for (j = 12; j <= 19; j++) {
              $formOptions.eq(j).hide();
          }
      }
  }

 