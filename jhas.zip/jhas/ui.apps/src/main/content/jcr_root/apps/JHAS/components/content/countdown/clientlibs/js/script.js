var countdown = function countdown(jQuery) {
  if ($('.clock').length !== 0) {
    var clock;

    var $countdownDate = $('#countdownDate').val();

    var nowTime = new Date(Date.now());

    var endTime = new Date($countdownDate);

    var endUTCTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate(), endTime.getHours(), endTime.getMinutes());

    // Countdown is in seconds
    var fullTime = (endUTCTime - nowTime) / 1000;

    clock = $('.clock').FlipClock(fullTime, {
      clockFace: 'DailyCounter',
      countdown: true,
      showSeconds: true
    });
  }
};

countdown(jQuery);
