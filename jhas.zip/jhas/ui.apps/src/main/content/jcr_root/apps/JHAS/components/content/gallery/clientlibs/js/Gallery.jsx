import React from 'react';
import Slider from 'react-slick';
import ImageSlide from './ImageSlide';
import VideoSlide from './VideoSlide';
import { getYoutubeVideoCode } from '../../../../../clientlibs/publish/src/utils/media';

import '../scss/Gallery.scss';
import '../../../../../clientlibs/publish/src/sass/slick.scss';
import '../../../../../clientlibs/publish/src/sass/slick-theme.scss';

const getMaxSlideDescriptionHeight = () => {
  let maxSlideInfoHeight = 0;
  const slides = document.querySelectorAll('.gallery__slideInfo');
  [...slides].map(value => {
    if (value.offsetHeight > maxSlideInfoHeight) {
      maxSlideInfoHeight = value.offsetHeight;
    }
  });
  return maxSlideInfoHeight;
};

export default class Gallery extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      galleryHeight: 0,
      slideWidth: 0,
      aspectRatio: 16 / 9,
      smallSlide: false,
      arrowHeight: 0
    };
    this.handleResize = this.handleResize.bind(this);
    this.handleVideoCapture = this.handleVideoCapture.bind(this);
    this.handleContentLoaded = this.handleContentLoaded.bind(this);
  }

  componentDidMount() {
    const { aspectRatio } = this.state;

    this.setState({
      galleryHeight: this.galleryWrapper.offsetWidth / aspectRatio,
      slideWidth: this.galleryWrapper.getBoundingClientRect
    });
    this.handleResize();
    window.addEventListener('resize', this.handleResize);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.handleResize);
  }

  handleResize() {
    const { aspectRatio } = this.state;
    const MAGIC_GALLERY_NUM = 640;
    const resizedHeight = this.galleryWrapper.offsetWidth / aspectRatio;

    /* Use max as description height to avoid different slide heights */
    /* Set track height to include description */
    if (this.galleryWrapper.offsetWidth < MAGIC_GALLERY_NUM) {
      this.setState({
        smallSlide: true,
        galleryHeight: resizedHeight,
        galleryHeightDescription: resizedHeight + getMaxSlideDescriptionHeight(),
        slideWidth: this.galleryWrapper.offsetWidth,
        arrowHeight: resizedHeight / 2
      });
    } else {
      this.setState({
        smallSlide: false,
        galleryHeight: resizedHeight,
        galleryHeightDescription: resizedHeight,
        slideWidth: this.galleryWrapper.offsetWidth,
        arrowHeight: `50%`
      });
    }
  }

  handleVideoCapture(video) {
    const { multifield } = this.props;
    const slideLength = JSON.parse(multifield);
    let canvas = null;
    let dataURL = null;
    slideLength.map((value, index) => {
      if (value.imagevideotoggle === 'videoSlide' && value.videothumbnail === undefined) {
        if (value.videoUrl.indexOf('youtu') < 0) {
          if (video.childNodes[0].src.includes(value.videoUrl)) {
            canvas = this[`videoThumbnail${index}`];
            canvas.getContext('2d').drawImage(video, 0, 0, 112, 63);
            dataURL = canvas.toDataURL();
            canvas.crossOrigin = 'Anonymous';
            canvas.src = dataURL;
          }
        }
      }
    });
  }

  handleContentLoaded(videoTag) {
    if (videoTag) {
      this.handleVideoCapture(videoTag);
    }
  }

  forceHandleClick(index, e) {
    e.preventDefault();
    this.slider1.slickGoTo(index);
  }

  render() {
    const { speed, disableautoplay, multifield, sequenceindicator } = this.props;
    const { slideWidth, galleryHeight, smallSlide, galleryHeightDescription, arrowHeight } = this.state;
    const multifieldJSON = JSON.parse(multifield);
    if (document.querySelector('.gallery .slick-prev') && arrowHeight !== 0) {
      if (arrowHeight !== `50%`) {
        document.querySelector('.gallery .slick-prev').style.top = `${arrowHeight}px`;
        document.querySelector('.gallery .slick-next').style.top = `${arrowHeight}px`;
      } else {
        document.querySelector('.gallery .slick-prev').style.top = `50%`;
        document.querySelector('.gallery .slick-next').style.top = `50%`;
      }
    }
    const settings = {
      dots: sequenceindicator !== 'thumbnails' ? true : false,
      arrows: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: disableautoplay === 'true' ? false : true,
      autoplaySpeed: speed * 1000,
      cssEase: 'ease-in-out',
      focusOnSelect: true
    };

    const maxPages = 5;
    const thumbnailSettings = {
      slidesToShow: maxPages,
      slidesToScroll: 1,
      centerMode: false,
      arrows: false,
      infinite: multifieldJSON.length > maxPages,
      focusOnSelect: true,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1
          }
        }
      ]
    };

    return (
      <div
        className="gallery__wrapper"
        ref={selector => {
          this.galleryWrapper = selector;
        }}
      >
        <div className="gallery__track" style={{ width: slideWidth - 1 }}>
          <Slider
            {...settings}
            ref={slider => {
              this.slider1 = slider;
            }}
          >
            {multifieldJSON.map((value, index) => {
              return (
                <React.Fragment>
                  {value.imagevideotoggle === 'imageSlide' ? (
                    <ImageSlide
                      key={index}
                      urlLink={value.urlLink}
                      title={value.title}
                      image={value.galleryImageRef}
                      options={value.options}
                      description={value.description}
                      slideHeight={galleryHeight}
                      slideHeightDescription={galleryHeightDescription}
                      slideWidth={slideWidth}
                      showSmallSlideInfo={smallSlide ? 'gallery__slideInfo--small' : ''}
                    />
                  ) : (
                    <VideoSlide
                      key={index}
                      urlLink={value.urlLink}
                      title={value.title}
                      videoUrl={value.videoUrl}
                      options={value.options}
                      description={value.description}
                      subtitles={value.subtitles}
                      slideHeight={galleryHeight}
                      slideHeightDescription={galleryHeightDescription}
                      slideWidth={slideWidth}
                      showSmallSlideInfo={smallSlide ? 'gallery__slideInfo--small' : ''}
                      onContentLoaded={this.handleContentLoaded}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </Slider>
        </div>
        {sequenceindicator === 'thumbnails' ? (
          <div className="gallery__pager">
            <Slider {...thumbnailSettings}>
              {multifieldJSON.map((value, index) => {
                return (
                  <div className="gallery__thumbnail" key={index} onClick={this.forceHandleClick.bind(this, index)}>
                    {value.imagevideotoggle === 'imageSlide' ? (
                      <img src={value.galleryImageRef} alt="thumbnail" />
                    ) : value.videoUrl.indexOf('youtu') > -1 ? (
                      <img src={`https://i.ytimg.com/vi/${getYoutubeVideoCode(value.videoUrl)}/maxresdefault.jpg`} alt="thumbnail" />
                    ) : value.videothumbnail !== undefined ? (
                      <img src={value.videothumbnail} alt="thumbnail" />
                    ) : (
                      <canvas
                        ref={selector => {
                          this[`videoThumbnail${index}`] = selector;
                        }}
                        width="112"
                        height="63"
                      />
                    )}
                  </div>
                );
              })}
            </Slider>
          </div>
        ) : (
          <div />
        )}
      </div>
    );
  }
}
