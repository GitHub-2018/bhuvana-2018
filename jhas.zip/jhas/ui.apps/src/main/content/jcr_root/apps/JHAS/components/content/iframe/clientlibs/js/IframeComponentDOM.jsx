import { DOMModel, DOMComponent } from 'react-dom-components';
import IframeComponent from './IframeComponent';

class IframeComponentModel extends DOMModel {
  constructor(element) {
    super(element);
    this.getDataAttribute('source');
    this.getDataAttribute('widthdesktop');
    this.getDataAttribute('heightdesktop');
    this.getDataAttribute('unitdesktop');
    this.getDataAttribute('widthipad');
    this.getDataAttribute('heightipad');
    this.getDataAttribute('unitipad');
    this.getDataAttribute('widthmobile');
    this.getDataAttribute('heightmobile');
    this.getDataAttribute('unitmobile');
    this.getDataAttribute('hex');
    this.getDataAttribute('scrollbar');
  }
}

export default class IframeComponentDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'IframeComponent';
    this.model = IframeComponentModel;
    this.component = IframeComponent;
  }
}
