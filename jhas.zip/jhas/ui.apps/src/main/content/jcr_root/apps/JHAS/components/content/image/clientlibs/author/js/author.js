
  $(document).on('foundation-contentloaded', function() {

  // Remove default width as 0 from image dialog selection

    if ($('.imageWidth input').val() == 0) {
      $('.imageWidth input').val('');
    }

});

 