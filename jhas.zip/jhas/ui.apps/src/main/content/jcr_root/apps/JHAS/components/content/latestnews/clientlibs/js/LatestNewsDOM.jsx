import { DOMModel, DOMComponent } from 'react-dom-components';
import LatestNews from './LatestNews';

class LatestNewsModel extends DOMModel {
  constructor(element) {
    super(element);
    this.getDataAttribute('newstitle');
    this.getDataAttribute('newsarticles');
    this.getDataAttribute('desktopcount');
    this.getDataAttribute('tabletcount');
    this.getDataAttribute('mobilecount');
    this.getDataAttribute('buttonpath');
  }
}

export default class LatestNewsDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'LatestNews';
    this.model = LatestNewsModel;
    this.component = LatestNews;
  }
}
