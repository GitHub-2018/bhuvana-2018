import { DOMModel, DOMComponent } from 'react-dom-components';
import Gallery from './Gallery';

class GalleryModel extends DOMModel {
  constructor(element) {
    super(element);
    this.getDataAttribute('multifield');
    this.getDataAttribute('sequenceindicator');
    this.getDataAttribute('speed');
    this.getDataAttribute('disableautoplay');
  }
}

export default class GalleryDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'Gallery';
    this.model = GalleryModel;
    this.component = Gallery;
  }
}
