'use strict';

var manualArticles = function manualArticles($) {
  var masonryInit = false;

  var $container = $('.articles');
  var $grid = $('.grid');

  var getArticleData = function getArticleData() {
    var manualNode = true;
    if ($container.length !== 0 && $container.hasClass('dynamic__articles')) {
      manualNode = false;
    }

    var path = $('#nodePath').val();
    var nodeData = void 0;

    if (manualNode == true) {
      nodeData = {
        manualnodepath: path
      };
    } else {
      nodeData = {
        dynamicnodepath: path
      };
    }

    $.ajax({
      type: 'GET',
      url: '/bin/sling/getjhasarticles',
      data: nodeData,
      success: function success(response) {
        setResponse(JSON.parse(response));
      },
      failure: function failure(err) {
        console.warn('There was a problem processing your request', err);
        return false;
      }
    });
  };

  var setResponse = function setResponse(articleList) {
    var tags = [];
    articleList.articles.map(function(article) {
      var author = article.author || '',
        date = article.modifiedDate || '',
        desc = article.desc || '',
        title = article.title || '',
        external = article.external || '',
        fullUrl = article.url || '',
        imgUrl = article.imgurl;

      $.each(article.tags, function(i, el) {
        tags.push(el);
      });

      if (article.url.includes('/content/johnhancock')) {
        fullUrl = article.url.replace('/content/johnhancock', '');
      }

      if (typeof imgUrl !== 'undefined' && imgUrl !== '') {
        $('.grid').append(
          '<div class="grid--item grid--article" data-tags="' +
            article.tags +
            '">' +
            '<a href="' +
            fullUrl +
            '" data-href="' +
            fullUrl +
            '">' +
            '<img class="article--img" src="' +
            imgUrl +
            '" alt="' +
            title +
            '"/>' +
            '</a>' +
            '<div class="article--content">' +
            '<a class="articleLink__title" href="' +
            fullUrl +
            '" target="' +
            external +
            '" data-href="' +
            fullUrl +
            '">' +
            title +
            '</a>' +
            '<span class="article--author">' +
            author +
            '</span>' +
            '<span class="article--date article__date">' +
            date +
            '</span>' +
            '<p class="article--text">' +
            desc +
            '</p>' +
            '</div>' +
            '</div>'
        );
      } else {
        $('.grid').append(
          '<div class="grid--item grid--article" data-tags="' +
            article.tags +
            '">' +
            '<div class="article--content">' +
            '<a class="articleLink__title" href="' +
            fullUrl +
            '" target="' +
            external +
            '" data-href="' +
            fullUrl +
            '">' +
            title +
            '</a>' +
            '<span class="article--author">' +
            author +
            '</span>' +
            '<span class="article--date article__date">' +
            date +
            '</span>' +
            '<p class="article--text">' +
            desc +
            '</p>' +
            '</div>' +
            '</div>'
        );
      }
    });

    var uniqueTags = [];
    $.each(tags, function(i, el) {
      if ($.inArray(el, uniqueTags) === -1) uniqueTags.push(el);
    });

    if (articleList.view === 'tile') {
      tileViewDisplay();
    } else if (articleList.view === 'list') {
      listViewDisplay();
    }

    dynamicArticles(uniqueTags);
  };

  var dynamicArticles = function dynamicArticles(tags) {
    var $articles = $('.grid--article');
    var $article_tabs = $('.article__sorting__tabs');
    var tagged = {};

    // Tags for each article - data-tags=""
    $articles.each(function() {
      var article = this;
      var dataTags = $(this).data('tags');

      if (dataTags) {
        dataTags.split(',').forEach(function(tagName) {
          if (tagged[tagName] === null || typeof tagged[tagName] === 'undefined') {
            tagged[tagName] = [];
          }
          tagged[tagName].push(article);
        });
      }
    });

    // Create View All Tab
    $('<li/>', {
      text: 'All',
      class: 'active',
      click: function click() {
        $(this)
          .addClass('active')
          .siblings()
          .removeClass('active');
        $articles.fadeIn('slow');
        if (!$('.grid').hasClass('list--view--background')) {
          $('.grid').masonry('layout');
        }
      }
    }).appendTo($article_tabs);

    // Create other tabs that coming from each data-tag
    $.each(tags, function(i, tagName) {
      $('<li/>', {
        text: tagName,
        value: tagName,
        click: function click() {
          $(this)
            .addClass('active')
            .siblings()
            .removeClass('active');
          $articles
            .hide()
            .filter(tagged[tagName])
            .fadeIn('slow');
          if (!$('.grid').hasClass('list--view--background')) {
            $('.grid').masonry('layout');
          }
        }
      }).appendTo($article_tabs);
    });

    // Trigger only for disabling the "View All"
    $('.disable-viewall li:first-child').addClass('hide');
    $('.disable-viewall li:nth-child(2)')
      .addClass('active')
      .show();

    // If " View All " disabled, removes the active class
    if ($('.article__sorting__tabs li:first-child').hasClass('hide')) {
      $('.article__sorting__tabs li:first-child').removeClass('active');
      $('.disable-viewall li:nth-child(2)').trigger('click');
      $('.article__sorting--mobile button.dropdown-toggle').html($('.disable-viewall .active').html() + ' <span class="caret"></span>');
    } else {
      var article_selector = {};
      $('.grid--article[data-articleselector]').each(function() {
        var $this = $(this);
        if (article_selector[$this.data('articleselector')]) {
          $this.remove();
        } else {
          article_selector[$this.data('articleselector')] = true;
        }
      });
    }

    // Mobile dropdown - to display the selected item in dropdown
    $('.dropdown-menu li').click(function() {
      $(this)
        .parents('.dropdown')
        .find('.btn')
        .html($(this).text() + ' <span class="caret"></span>');
      $(this)
        .parents('.dropdown')
        .find('.btn')
        .val($(this).data('value'));
    });

    // Sort articles based publish date
    $('.grid .grid--article')
      .sort(sort_article)
      .appendTo('.grid');
  };

  var tileViewDisplay = function tileViewDisplay() {
    // Toggle Buttons
    $('.list__view', $container).removeClass('activeView');
    $('.tile__view', $container).addClass('activeView');

    // Remove white background
    $('.manual__article--topbar, .grid', $container).removeClass('list--view--background');

    // Show Image and Article Info
    $('.article--img, .article--author, .article--text, .article--date', $container).css('display', 'block');

    // Switch Views
    $('.grid--article', $container)
      .removeClass('grid--item--listview')
      .addClass('grid--item')
      .css('width', '');

    $('.manual__article--topbar', $container).addClass('manual__article--topbarpad');

    if (masonryInit === true) {
      $('.grid', $container).masonry('destroy');
      tileResponsiveness();
    } else {
      tileResponsiveness();
    }
  };

  var listViewDisplay = function listViewDisplay() {
    if (masonryInit === true) {
      $($grid, $container).masonry('destroy');
    }

    // Toggle Buttons
    $('.list__view', $container).addClass('activeView');
    $('.tile__view', $container).removeClass('activeView');

    // Remove white bg for title
    $('.manual__article--topbar', $container).addClass('list--view--background');

    // Add white background
    $($grid, $container).addClass('list--view--background');

    // Hide Image and Article Info
    $('.article--img, .article--author, .article--text, .article--date', $container).css('display', 'none');

    //Switch Views
    $('.grid--article', $container)
      .removeClass('grid--item')
      .addClass('grid--item--listview');

    $('.grid--item--listview', $container).css('width', '100%');

    $('.manual__article--topbar', $container).removeClass('manual__article--topbarpad');
  };

  var tileResponsiveness = function tileResponsiveness() {
    var LARGE_DEVICES = 1280;
    var THREE_COL = 792;
    var ONE_COL = 460;
    var MAGIC_NUM = 13.75;

    var parentWidth = $('.grid')
      .parents()
      .width();
    var $gridItem = $('.grid--item');

    // Two column large devices
    if (parentWidth > LARGE_DEVICES) {
      $gridItem.width('500px');
      $grid.masonry({
        itemSelector: '.grid--item',
        columnWidth: 500,
        gutter: 20,
        fitWidth: true
      });
    }
    // Three Column
    else if (parentWidth > THREE_COL) {
      $gridItem.width(parentWidth / 3 - MAGIC_NUM);
      $grid.masonry({
        itemSelector: '.grid--item',
        columnWidth: parentWidth / 3 - MAGIC_NUM,
        gutter: 20,
        fitWidth: true
      });
    }
    // One column
    else if (parentWidth < ONE_COL) {
      $gridItem.width(parentWidth);
      $grid.masonry({
        itemSelector: '.grid--item',
        columnWidth: parentWidth,
        gutter: 20,
        fitWidth: true
      });
    }
    // Default Two Column
    else {
      $gridItem.width(parentWidth / 2 - 10);
      $grid.masonry({
        itemSelector: '.grid--item',
        columnWidth: parentWidth / 2 - 10,
        gutter: 20,
        fitWidth: true
      });
    }

    $('.grid')
      .imagesLoaded()
      .progress(function() {
        $('.grid').masonry('layout');
      });

    // Set State
    masonryInit = true;
  };

  var sort_article = function sort_article(a, b) {
    return $(b).data('publishdate') > $(a).data('publishdate') ? 1 : -1;
  };

  if ($('.grid').length !== 0) {
    getArticleData();
  }

  $(window).on('load resize', function() {
    tileResponsiveness();
  });

  $('.tile__view').on('click', function(e) {
    e.preventDefault();
    tileViewDisplay();
  });

  $('.list__view').on('click', function(e) {
    e.preventDefault();
    listViewDisplay();
  });
};

manualArticles(jQuery);
