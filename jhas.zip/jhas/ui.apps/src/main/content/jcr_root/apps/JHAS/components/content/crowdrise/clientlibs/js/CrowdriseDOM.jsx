import { DOMModel, DOMComponent } from 'react-dom-components';
import Crowdrise from './Crowdrise';

class CrowdriseModel extends DOMModel {
  constructor(element) {
    super(element);
    this.getDataAttribute('eventid');
    this.getDataAttribute('bgcolor');
    this.getDataAttribute('textcolor');
  }
}

export default class CrowdriseDOM extends DOMComponent {
  constructor() {
    super();
    this.nodeName = 'Crowdrise';
    this.model = CrowdriseModel;
    this.component = Crowdrise;
  }
}
