
 $(document).on('keyup', '.accordionItem', function() {
    showHideAccordion(this);
  });


function showHideAccordion(el) {
      if (typeof $(el) != undefined) {
          var uniQueid = $(el).val().split(" ").join("-").replace(/[\*\^\?\!]/g, '').toLowerCase();
          var tabLabel = '<label class="coral-Form-fieldlabel uniqueAccId">' + 'Tab Id:' + uniQueid + '</label>';
          if ($(el).parent().find('.uniqueAccId').length != 0) {
              $(el).parent().find('.uniqueAccId').text('Tab Id: ' + uniQueid);
          } else {
              $(el).parent().append(tabLabel);
          }
      }
  }

