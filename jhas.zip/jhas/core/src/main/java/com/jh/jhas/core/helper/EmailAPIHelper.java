package com.jh.jhas.core.helper;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.constants.EmailConstants;
import com.jh.jhas.core.contactus.dto.EmailAPICredential;
import com.jh.jhas.core.serviceimpl.EmailServiceImpl;
import com.jh.jhas.core.utility.ConfigUtil;

public class EmailAPIHelper {
	
    private static final Logger LOG = LoggerFactory.getLogger(EmailAPIHelper.class);

public static boolean sendEmail(String emailJSON, ResourceResolver resourceResolver) throws Exception{
		
		EmailAPICredential emailAPICredentail = new EmailAPICredential();
		String userName=EmailHelper.stripXSS(EmailConstants.CONFIG_EMAIL_API_USERNAME, ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_EMAIL_API_USERNAME));
		String password=EmailHelper.stripXSS(EmailConstants.CONFIG_EMAIL_API_PWD, ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_EMAIL_API_PWD));
		StringBuilder userNameSb = new StringBuilder();
		userNameSb.append(EmailHelper.decryptText(userName));
		StringBuilder passwordSb = new StringBuilder();
		passwordSb.append(EmailHelper.decryptText(password));
		emailAPICredentail.setUsername(userNameSb);
		emailAPICredentail.setPwd(passwordSb);
		String inputJson =  EmailHelper.createGsonObj().toJson(emailAPICredentail);
		StringBuilder apiTokenURL = new StringBuilder();
		String emailApi=EmailHelper.stripXSS(EmailConstants.CONFIG_EMAIL_API_URL, ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_EMAIL_API_URL));
		apiTokenURL.append(emailApi);
		apiTokenURL.append(EmailConstants.EMAIL_JHAS_TOKEN_URL);
		// get the authentication token
		EmailServiceImpl emailserviceImpl=new EmailServiceImpl();
		String oauthToken =  emailserviceImpl.getOAUTHToken(inputJson, apiTokenURL.toString(),resourceResolver);
		if(StringUtils.isBlank(oauthToken)){
			LOG.error("Error while receiving OAuth Token");
			return false;
		}
		
		StringBuilder apiEmailURL = new StringBuilder();
		apiEmailURL.append(emailApi);
		apiEmailURL.append(EmailConstants.EMAIL_JHAS_SEND_URL);
		
		return emailserviceImpl.sendEmail(emailJSON, apiEmailURL.toString(), oauthToken, resourceResolver);
}
}
