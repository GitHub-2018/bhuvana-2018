package com.jh.jhas.core.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.SearchHelper;
import com.jh.jhas.core.leadership.dto.LeadershipProfile;
import com.jh.jhas.core.service.LeadershipProfileService;

@Component(immediate = true, metatype = false)
@Service(value={LeadershipProfileService.class})
public class LeadershipProfileServiceImpl implements LeadershipProfileService {
	private Logger LOG = LoggerFactory.getLogger(LeadershipProfileServiceImpl.class);
	
	@Override
	public List<LeadershipProfile> getLeadershipProfiles(SlingHttpServletRequest request){
		List<LeadershipProfile> leadershipProfiles=new ArrayList<>();
		ResourceResolver resourceResolver= request.getResourceResolver();
		Map<String,String> leadershipQueryMap=getLeadershipQueryMap(GlobalConstants.LEADERSHIP_PROFILES_PATH);
		SearchResult searchResult=SearchHelper.getSearchResults(resourceResolver, leadershipQueryMap);
		try {
			for(Hit hit:searchResult.getHits()){
				String leadershipPath;
				leadershipPath = hit.getPath();
				LeadershipProfile leadershipProfile = getLeadershipPageDetails(resourceResolver, leadershipPath);
				leadershipProfiles.add(leadershipProfile);
			}
		} catch (RepositoryException e) {
			LOG.error("Exception in Leadership Profiles List"+e);
		}
		return leadershipProfiles;
	}
	
	private LeadershipProfile getLeadershipPageDetails(ResourceResolver resourceResolver, String leadershipPath) {
		Resource leadershipPageResource=resourceResolver.getResource(leadershipPath.concat("/jcr:content"));
		LeadershipProfile leadershipProfile=new LeadershipProfile();
        if(leadershipPageResource!=null){
            Node pageContentNode=leadershipPageResource.adaptTo(Node.class);
            try {

            	if(pageContentNode.hasProperty(GlobalConstants.USER_NAME)){
                    leadershipProfile.setName(pageContentNode.getProperty(GlobalConstants.USER_NAME).getString());
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.JOB_TITLE)){
                    leadershipProfile.setTitle(pageContentNode.getProperty(GlobalConstants.JOB_TITLE).getString());
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.BUSINESS_UNIT)){
                    leadershipProfile.setBusinessUnit(pageContentNode.getProperty(GlobalConstants.BUSINESS_UNIT).getString());
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.TURN_OFF_PICTURE)){
                    leadershipProfile.setTurnoffpicture("false");
                } else {
                	leadershipProfile.setTurnoffpicture("true");
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.PROFILE_PICTURE)){
                    leadershipProfile.setPicture(pageContentNode.getProperty(GlobalConstants.PROFILE_PICTURE).getString());
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.PROFILE_CATEGORY)){
                    leadershipProfile.setProfileCategory(getTags(pageContentNode.getProperty(GlobalConstants.PROFILE_CATEGORY)));
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.USER_PHONE)){
                    leadershipProfile.setPhone(pageContentNode.getProperty(GlobalConstants.USER_PHONE).getString());
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.USER_EMAIL)){
                    leadershipProfile.setEmail(pageContentNode.getProperty(GlobalConstants.USER_EMAIL).getString());
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.LINKEDIN_PROFILE)){
                    leadershipProfile.setLinkedIn(pageContentNode.getProperty(GlobalConstants.LINKEDIN_PROFILE).getString());
                }
            	
            	if(pageContentNode.hasProperty(GlobalConstants.USER_EMAIL)){
                    leadershipProfile.setEmail(pageContentNode.getProperty(GlobalConstants.USER_EMAIL).getString());
                }
            	leadershipProfile.setUrl(leadershipPath+".html");
            } 
            catch (Exception e) {
                LOG.info("Exception in fethcing LeadershipProfile Details"+ e);
            }
        }
        return leadershipProfile;
    }

	private Map<String, String> getLeadershipQueryMap(String path) {
		Map<String,String> map=new HashMap<>();
		map.put("path",path);
		map.put("property", "jcr:content/cq:template");
		map.put("property.value","/apps/JHAS/templates/profilespage");
		map.put("property.operation", "equals");
		map.put("orderby", "@jcr:content/@jcr:created");
		map.put("p.limit","-1");
		return map;
	}
	
	private List<String> getTags(Property tagProperty)
			throws PathNotFoundException, ValueFormatException, RepositoryException {
		List<String> tagLists = new ArrayList<String>();
		if (tagProperty.isMultiple()) {
			Value[] tagValues = tagProperty.getValues();
			for (Value tagValue : tagValues) {
				tagLists.add(tagValue.getString());
			}
		}
		return tagLists;
	}
}
