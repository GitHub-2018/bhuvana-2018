package com.jh.jhas.core.headernavigation.model;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.headernavigation.dto.HeaderNavItem;
import com.jh.jhas.core.headernavigation.dto.HeaderNavigationMain;
import com.jh.jhas.core.utility.HeaderNavGenerator;

@Model(adaptables=SlingHttpServletRequest.class)

public class HeaderNavigationModel {
    private Logger LOG = LoggerFactory.getLogger(HeaderNavigationModel.class);

    public HeaderNavigationMain headerNavigationMain;

    @Inject
    SlingHttpServletRequest request;

    @Inject
    private String path;

    @PostConstruct
    protected void init(){
	final Resource resource = request.getResourceResolver().getResource(path);
	headerNavigationMain=new HeaderNavigationMain();
	headerNavigationMain.setHeaderNavList(getHeaderNavigationList(resource));
    }

    private List<HeaderNavItem> getHeaderNavigationList(Resource resource) {
	LOG.info("-- Entering Header getHeaderNavigationList --");
	List<HeaderNavItem> headerNavLinkItems = new ArrayList<>();

	final Node resourceNode = resource.adaptTo(Node.class);
	try {
	    if (resourceNode.hasNode("headermenuitems")) {
		final NodeIterator nodeIterator = resourceNode.getNode("headermenuitems").getNodes();

		while (nodeIterator.hasNext()) {
		    final Node childNode = (Node) nodeIterator.next();
		    String topNavPath=childNode.getProperty("topnavtab").getString();
		    headerNavLinkItems.addAll(HeaderNavGenerator.getTopNavList(request.getResourceResolver(), topNavPath));
		}
	    }
	} catch (RepositoryException e) {
	    LOG.error("-- Encounter Repository Exception fetching properties --");
	}
	LOG.info("-- Final Header List -- " + headerNavLinkItems);
	return headerNavLinkItems;
    }

}
