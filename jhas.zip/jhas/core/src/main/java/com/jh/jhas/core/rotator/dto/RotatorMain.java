package com.jh.jhas.core.rotator.dto;

import java.util.List;

public class RotatorMain {
	private List<RotatorBanner> bannerList;
	
	public List<RotatorBanner>getBannerList(){
	
		return bannerList;
		
	}
	public void setBannerList(List<RotatorBanner> rotatorBannerList){
		
		this.bannerList=rotatorBannerList;
	}

}
