package com.jh.jhas.core.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.InvalidQueryException;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.jh.jhas.core.repository.JhasRepository;

public class SearchHelper {

    protected static final Logger LOG = LoggerFactory.getLogger(SearchHelper.class);
    private static String stopWords;
    private static Map<String,String> spellMap;

    /**
     * @return the stopWords
     */
    public static String getStopWords() {
                return stopWords;
    }

    /**
     * @param stopWords
     *            the stopWords to set
     */
    public static void setStopWords(String stopWords) {
    	SearchHelper.stopWords = stopWords;
    }

    /**
     * @return the spellMap
     */
    public static Map<String, String> getSpellMap() {
                return spellMap;
    }

    /**
     * @param spellMap
     *            the spellMap to set
     */
    public static void setSpellMap(Map<String, String> spellMap) {
    	SearchHelper.spellMap = spellMap;
    }

    public List<String> getResults(final SlingHttpServletRequest slingRequest, final String queryStmt) {

                QueryResult queryResult = null;
                final List<String> results = new ArrayList<String>();

                final Session session = slingRequest.getResourceResolver().adaptTo(Session.class);
                try {
                    final QueryManager manager = session.getWorkspace().getQueryManager();
                    final JhasRepository jhasRepository = new JhasRepository(manager);
                    queryResult = jhasRepository.getQueryResult(queryStmt);
                    if (queryResult != null) {
                         final NodeIterator nitr = queryResult.getNodes();
                         while (nitr.hasNext()) {
                        	 Node node = nitr.nextNode();
                             results.add(node.getPath());
                        }
                    }
                } catch (InvalidQueryException invalidqueryException) {
                	LOG.info("InvalidQueryException"+invalidqueryException);
                	LOG.error(invalidqueryException.getMessage());

                } catch (RepositoryException repositoryException) {
                	LOG.info("RepositoryException"+repositoryException);
                    LOG.error(repositoryException.getMessage());
                }
                return results;

    }
  
    public static SearchResult getSearchResults(ResourceResolver resourceResolver, Map<String, String> queryMap) {
                QueryBuilder qb = resourceResolver.adaptTo(QueryBuilder.class);
                Query query = qb.createQuery(PredicateGroup.create(queryMap), resourceResolver.adaptTo(Session.class));
                if(LOG.isInfoEnabled()){
                    LOG.info("QUERY STRING"+query);
                }
                return query.getResult();
    }

}

