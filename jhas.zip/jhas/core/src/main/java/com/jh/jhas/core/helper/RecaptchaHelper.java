package com.jh.jhas.core.helper;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.contactus.dto.CaptchaResponse;
import com.jh.jhas.core.contactus.dto.HttpUtilResponse;
import com.jh.jhas.core.utility.ConfigUtil;
import com.jh.jhas.core.utility.HttpURLUtil;
import com.jh.jhas.core.utility.JsonSanitizer;

public class RecaptchaHelper {

	private static final Logger LOG = LoggerFactory.getLogger(RecaptchaHelper.class);	
	public static boolean recaptchaValidate(SlingHttpServletRequest request, String ajaxResponse){
	    String recaptchaData = ajaxResponse;
	    if (StringUtils.isBlank(recaptchaData)) {
		recaptchaData=EmailHelper.stripXSS("recaptchaData",request.getParameter(GlobalConstants.G_RECAPTCHA_RESPONSE));
	    }
		String secretKey=ConfigUtil.INSTANCE.getStringConfiguration(GlobalConstants.CONFIG_GOOGLEAPI_RECAPTCHA_SECRECTKEY);
		// go to error page if google captcha is missing
		if(StringUtils.isBlank(recaptchaData)){
			LOG.info("Redirect for recaptchaData blank check");
			return false;
		}

		// validate the google captcha response
		Map<String, String> inputParams = new HashMap<String,String>();
		inputParams.put(GlobalConstants.G_PARAM_SECRET, secretKey);
		inputParams.put(GlobalConstants.G_PARAM_RESPONSE, recaptchaData);
		inputParams.put(GlobalConstants.G_PARAM_REMOTEIP, request.getRemoteAddr());
		HttpUtilResponse httpUtilResponse = HttpURLUtil.postHttpsResponse(GlobalConstants.GOOGLE_RECAPTCHA_VERIFY_API, inputParams);
		
		// check the google recaptcha response
		if(httpUtilResponse.getResponseContent() == null){
			LOG.info("Redirect for getResponseContent() blank check");
			return false;
		}
		String httpResponse = JsonSanitizer.sanitize(httpUtilResponse.getResponseContent());
		CaptchaResponse captchaResponse = EmailHelper.createGsonObj().fromJson(httpResponse, CaptchaResponse.class);
		if(StringUtils.equalsIgnoreCase(captchaResponse.getSuccess(), "false")){
			LOG.info("Redirect for getSuccess() status check");
			return false;
		}
		return true;
	}
}
