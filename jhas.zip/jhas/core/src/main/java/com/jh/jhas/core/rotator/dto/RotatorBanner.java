package com.jh.jhas.core.rotator.dto;

public class RotatorBanner {
	private String layout;
	private String bannerlayout1;	
	private String imageUrlLayout1;
	private String colorLayout1;
	private String videourlLayout1;
	private String videosourceLayout1;
	private String urllinkLayout1;
	private String openoptionsLayout1;
	private String bannerlayout2;
	private String imageurlLayout2;
	private String urllinkimageLayout2;
	private String openoptionsLayout2;
	private String insetImageLayout2Image;
	private String insetVideoLayout2Image;
	private String colorLayout2;
	private String insetImageLayout2Color;
	private String insetVideoLayout2Color;
	private String color1Layout2;
	private String color2Layout2;
	private String insetImageLayout2Gradient;
	private String insetVideoLayout2Gradient;
	private String videooverlayimageURL;
	private String videooverlayColor;
	private String videooverlayColor1;
	private String videooverlayColor2;
	private String videooverlayvideoURL;
	private String alignHorizontal;
	private String alignVertical;
	private String title;
	private String textColor;
	private String textPlacementHorizontal;
	private String textPlacementVertical;
	private String description;
	private String button;
	private String colorClass;
	private String buttonCaption;
	private String textboxPadding;
	private String fontColorClass;
	private String textAlign;
	private String textboxColor;
	private String buttonLinkUrl;
	private String buttonOpenOptions;
	
	/**
	 * @return the layout
	 */
	public String getLayout() {
		return layout;
	}
	/**
	 * @param layout the layout to set
	 */
	public void setLayout(String layout) {
		this.layout = layout;
	}
		
	public String getImageUrlLayout1() {
		return imageUrlLayout1;
	}
	public void setImageUrlLayout1(String imageUrl) {
		this.imageUrlLayout1 = imageUrl;
	}
	public String getBannerlayout1() {
		return bannerlayout1;
	}
	public void setBannerlayout1(String bannerlayout1) {
		this.bannerlayout1 = bannerlayout1;
	}
	/**
	 * @return the colorLayout1
	 */
	public String getColorLayout1() {
		return colorLayout1;
	}
	/**
	 * @param colorLayout1 the colorLayout1 to set
	 */
	public void setColorLayout1(String colorLayout1) {
		this.colorLayout1 = colorLayout1;
	}
	/**
	 * @return the videourlLayout1
	 */
	public String getVideourlLayout1() {
		return videourlLayout1;
	}
	/**
	 * @param videourlLayout1 the videourlLayout1 to set
	 */
	public void setVideourlLayout1(String videourlLayout1) {
		this.videourlLayout1 = videourlLayout1;
	}
	/**
	 * @return the videosourceLayout1
	 */
	public String getVideosourceLayout1() {
		return videosourceLayout1;
	}
	/**
	 * @param videosourceLayout1 the videosourceLayout1 to set
	 */
	public void setVideosourceLayout1(String videosourceLayout1) {
		this.videosourceLayout1 = videosourceLayout1;
	}
	/**
	 * @return the urllinkLayout1
	 */
	public String getUrllinkLayout1() {
		return urllinkLayout1;
	}
	/**
	 * @param urllinkLayout1 the urllinkLayout1 to set
	 */
	public void setUrllinkLayout1(String urllinkLayout1) {
		this.urllinkLayout1 = urllinkLayout1;
	}
	/**
	 * @return the openoptionsLayout1
	 */
	public String getOpenoptionsLayout1() {
		return openoptionsLayout1;
	}
	/**
	 * @param openoptionsLayout1 the openoptionsLayout1 to set
	 */
	public void setOpenoptionsLayout1(String openoptionsLayout1) {
		this.openoptionsLayout1 = openoptionsLayout1;
	}
	/**
	 * @return the bannerlayout2
	 */
	public String getBannerlayout2() {
		return bannerlayout2;
	}
	/**
	 * @param bannerlayout2 the bannerlayout2 to set
	 */
	public void setBannerlayout2(String bannerlayout2) {
		this.bannerlayout2 = bannerlayout2;
	}
	/**
	 * @return the imageurlLayout2
	 */
	public String getImageurlLayout2() {
		return imageurlLayout2;
	}
	/**
	 * @param imageurlLayout2 the imageurlLayout2 to set
	 */
	public void setImageurlLayout2(String imageurlLayout2) {
		this.imageurlLayout2 = imageurlLayout2;
	}
	/**
	 * @return the openoptionsLayout2
	 */
	public String getOpenoptionsLayout2() {
		return openoptionsLayout2;
	}
	/**
	 * @param openoptionsLayout2 the openoptionsLayout2 to set
	 */
	public void setOpenoptionsLayout2(String openoptionsLayout2) {
		this.openoptionsLayout2 = openoptionsLayout2;
	}
	/**
	 * @return the urllinkimageLayout2
	 */
	public String getUrllinkimageLayout2() {
		return urllinkimageLayout2;
	}
	/**
	 * @param urllinkimageLayout2 the urllinkimageLayout2 to set
	 */
	public void setUrllinkimageLayout2(String urllinkimageLayout2) {
		this.urllinkimageLayout2 = urllinkimageLayout2;
	}
	/**
	 * @return the colorLayout2
	 */
	public String getColorLayout2() {
		return colorLayout2;
	}
	/**
	 * @param colorLayout2 the colorLayout2 to set
	 */
	public void setColorLayout2(String colorLayout2) {
		this.colorLayout2 = colorLayout2;
	}
	/**
	 * @return the color2Layout2
	 */
	public String getColor2Layout2() {
		return color2Layout2;
	}
	/**
	 * @param color2Layout2 the color2Layout2 to set
	 */
	public void setColor2Layout2(String color2Layout2) {
		this.color2Layout2 = color2Layout2;
	}
	/**
	 * @return the color1Layout2
	 */
	public String getColor1Layout2() {
		return color1Layout2;
	}
	/**
	 * @param color1Layout2 the color1Layout2 to set
	 */
	public void setColor1Layout2(String color1Layout2) {
		this.color1Layout2 = color1Layout2;
	}
	/**
	 * @return the videooverlayimageURL
	 */
	public String getVideooverlayimageURL() {
		return videooverlayimageURL;
	}
	/**
	 * @param videooverlayimageURL the videooverlayimageURL to set
	 */
	public void setVideooverlayimageURL(String videooverlayimageURL) {
		this.videooverlayimageURL = videooverlayimageURL;
	}
	/**
	 * @return the videooverlayColor
	 */
	public String getVideooverlayColor() {
		return videooverlayColor;
	}
	/**
	 * @param videooverlayColor the videooverlayColor to set
	 */
	public void setVideooverlayColor(String videooverlayColor) {
		this.videooverlayColor = videooverlayColor;
	}
	/**
	 * @return the videooverlayColor1
	 */
	public String getVideooverlayColor1() {
		return videooverlayColor1;
	}
	/**
	 * @param videooverlayColor1 the videooverlayColor1 to set
	 */
	public void setVideooverlayColor1(String videooverlayColor1) {
		this.videooverlayColor1 = videooverlayColor1;
	}
	/**
	 * @return the videooverlayColor2
	 */
	public String getVideooverlayColor2() {
		return videooverlayColor2;
	}
	/**
	 * @param videooverlayColor2 the videooverlayColor2 to set
	 */
	public void setVideooverlayColor2(String videooverlayColor2) {
		this.videooverlayColor2 = videooverlayColor2;
	}
	/**
	 * @return the videooverlayvideoURL
	 */
	public String getVideooverlayvideoURL() {
		return videooverlayvideoURL;
	}
	/**
	 * @param videooverlayvideoURL the videooverlayvideoURL to set
	 */
	public void setVideooverlayvideoURL(String videooverlayvideoURL) {
		this.videooverlayvideoURL = videooverlayvideoURL;
	}
	/**
	 * @return the alignHorizontal
	 */
	public String getAlignHorizontal() {
		return alignHorizontal;
	}
	/**
	 * @param alignHorizontal the alignHorizontal to set
	 */
	public void setAlignHorizontal(String alignHorizontal) {
		this.alignHorizontal = alignHorizontal;
	}
	/**
	 * @return the alignVertical
	 */
	public String getAlignVertical() {
		return alignVertical;
	}
	/**
	 * @param alignVertical the alignVertical to set
	 */
	public void setAlignVertical(String alignVertical) {
		this.alignVertical = alignVertical;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the textColor
	 */
	public String getTextColor() {
		return textColor;
	}
	/**
	 * @param textColor the textColor to set
	 */
	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}
	/**
	 * @return the textPlacementHorizontal
	 */
	public String getTextPlacementHorizontal() {
		return textPlacementHorizontal;
	}
	/**
	 * @param textPlacementHorizontal the textPlacementHorizontal to set
	 */
	public void setTextPlacementHorizontal(String textPlacementHorizontal) {
		this.textPlacementHorizontal = textPlacementHorizontal;
	}
	/**
	 * @return the textPlacementVertical
	 */
	public String getTextPlacementVertical() {
		return textPlacementVertical;
	}
	/**
	 * @param textPlacementVertical the textPlacementVertical to set
	 */
	public void setTextPlacementVertical(String textPlacementVertical) {
		this.textPlacementVertical = textPlacementVertical;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * @return the button
	 */
	public String getButton() {
		return button;
	}
	/**
	 * @param button the button to set
	 */
	public void setButton(String button) {
		this.button = button;
	}
	/**
	 * @return the colorClass
	 */
	public String getColorClass() {
		return colorClass;
	}
	/**
	 * @param colorClass the colorClass to set
	 */
	public void setColorClass(String colorClass) {
		this.colorClass = colorClass;
	}
	/**
	 * @return the buttonCaption
	 */
	public String getButtonCaption() {
		return buttonCaption;
	}
	/**
	 * @param buttonCaption the buttonCaption to set
	 */
	public void setButtonCaption(String buttonCaption) {
		this.buttonCaption = buttonCaption;
	}
	
	/**
	 * @return the textboxPadding
	 */
	public String getTextboxPadding() {
		return textboxPadding;
	}
	/**
	 * @param textboxPadding the textboxPadding to set
	 */
	public void setTextboxPadding(String textboxPadding) {
		this.textboxPadding = textboxPadding;
	}
	/**
	 * @return the fontColorClass
	 */
	public String getFontColorClass() {
		return fontColorClass;
	}
	/**
	 * @param fontColorClass the fontColorClass to set
	 */
	public void setFontColorClass(String fontColorClass) {
		this.fontColorClass = fontColorClass;
	}
	/**
	 * @return the textAlign
	 */
	public String getTextAlign() {
		return textAlign;
	}
	/**
	 * @param textAlign the textAlign to set
	 */
	public void setTextAlign(String textAlign) {
		this.textAlign = textAlign;
	}
	/**
	 * @return the insetImageLayout2Image
	 */
	public String getInsetImageLayout2Image() {
		return insetImageLayout2Image;
	}
	/**
	 * @param insetImageLayout2Image the insetImageLayout2Image to set
	 */
	public void setInsetImageLayout2Image(String insetImageLayout2Image) {
		this.insetImageLayout2Image = insetImageLayout2Image;
	}
	/**
	 * @return the insetVideoLayout2Image
	 */
	public String getInsetVideoLayout2Image() {
		return insetVideoLayout2Image;
	}
	/**
	 * @param insetVideoLayout2Image the insetVideoLayout2Image to set
	 */
	public void setInsetVideoLayout2Image(String insetVideoLayout2Image) {
		this.insetVideoLayout2Image = insetVideoLayout2Image;
	}
	/**
	 * @return the insetImageLayout2Color
	 */
	public String getInsetImageLayout2Color() {
		return insetImageLayout2Color;
	}
	/**
	 * @param insetImageLayout2Color the insetImageLayout2Color to set
	 */
	public void setInsetImageLayout2Color(String insetImageLayout2Color) {
		this.insetImageLayout2Color = insetImageLayout2Color;
	}
	/**
	 * @return the insetVideoLayout2Color
	 */
	public String getInsetVideoLayout2Color() {
		return insetVideoLayout2Color;
	}
	/**
	 * @param insetVideoLayout2Color the insetVideoLayout2Color to set
	 */
	public void setInsetVideoLayout2Color(String insetVideoLayout2Color) {
		this.insetVideoLayout2Color = insetVideoLayout2Color;
	}
	/**
	 * @return the insetImageLayout2Gradient
	 */
	public String getInsetImageLayout2Gradient() {
		return insetImageLayout2Gradient;
	}
	/**
	 * @param insetImageLayout2Gradient the insetImageLayout2Gradient to set
	 */
	public void setInsetImageLayout2Gradient(String insetImageLayout2Gradient) {
		this.insetImageLayout2Gradient = insetImageLayout2Gradient;
	}
	/**
	 * @return the insetVideoLayout2Gradient
	 */
	public String getInsetVideoLayout2Gradient() {
		return insetVideoLayout2Gradient;
	}
	/**
	 * @param insetVideoLayout2Gradient the insetVideoLayout2Gradient to set
	 */
	public void setInsetVideoLayout2Gradient(String insetVideoLayout2Gradient) {
		this.insetVideoLayout2Gradient = insetVideoLayout2Gradient;
	}
	/**
	 * @return the textboxColor
	 */
	public String getTextboxColor() {
		return textboxColor;
	}
	/**
	 * @param textboxColor the textboxColor to set
	 */
	public void setTextboxColor(String textboxColor) {
		this.textboxColor = textboxColor;
	}
	/**
	 * @return the buttonLinkUrl
	 */
	public String getButtonLinkUrl() {
		return buttonLinkUrl;
	}
	/**
	 * @param buttonLinkUrl the buttonLinkUrl to set
	 */
	public void setButtonLinkUrl(String buttonLinkUrl) {
		this.buttonLinkUrl = buttonLinkUrl;
	}
	/**
	 * @return the buttonOpenOptions
	 */
	public String getButtonOpenOptions() {
		return buttonOpenOptions;
	}
	/**
	 * @param buttonOpenOptions the buttonOpenOptions to set
	 */
	public void setButtonOpenOptions(String buttonOpenOptions) {
		this.buttonOpenOptions = buttonOpenOptions;
	}
}
