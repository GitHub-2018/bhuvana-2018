package com.jh.jhas.core.newsarticles.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.ArticleHelper;
import com.jh.jhas.core.helper.SearchHelper;
import com.jh.jhas.core.newsarticles.dto.Article;
import com.jh.jhas.core.newsarticles.dto.ArticleParams;
import com.jh.jhas.core.newsarticles.dto.NewsArticles;

@Model(adaptables=SlingHttpServletRequest.class)
public class NewsArticlesModel {

	private static Logger LOG = LoggerFactory.getLogger(NewsArticlesModel.class);

	public NewsArticles newsArticles;

	@Inject
	private SlingHttpServletRequest request;

	@Inject
	private String path;

	@PostConstruct
	protected void init(){

		final Resource resource = request.getResourceResolver().getResource(path);
		newsArticles=new NewsArticles();
		try{
			if(path.contains("latestnews")){
				newsArticles.setArticles(getLatestNews(resource));
			}
			else if(path.contains("manualarticles")){
				Node resourceNode=resource.adaptTo(Node.class);
				newsArticles.setArticles(getManualArticles(resourceNode));
			}
		}catch(Exception e){
			LOG.error("Error while creating Latest News",e);
		}
	}

	private List<Article> getLatestNews(Resource resource){		
		final Node resourceNode = resource.adaptTo(Node.class);
		String inputType=null;
		List<Article> articleList= new ArrayList<Article>();
		try {
			if(resourceNode.hasProperty("inputType")){
				inputType=resourceNode.getProperty("inputType").getString();
				if("prnews".equals(inputType)){
					articleList=getPRNNewsArticles(resourceNode, null);
				}
				else if("prnnews_boston_marathon".equals(inputType)){
					articleList=getPRNNewsArticles(resourceNode, GlobalConstants.BOSTON_MARATHON);
				} else{
					articleList=getManualArticles(resourceNode);
				}
			}

			// Defect#2609	
			int desktopCount=Integer.parseInt(resourceNode.getProperty("articleCountDesktop").getString());
			int tabletCount=Integer.parseInt(resourceNode.getProperty("articleCountTablet").getString());
			int mobileCount=Integer.parseInt(resourceNode.getProperty("articleCountMobile").getString());

			int count=Math.max(desktopCount, Math.max(tabletCount, mobileCount));
			if(articleList.size()>=count){
				articleList=articleList.subList(0, count);
			}
		} catch (Exception e) {
			LOG.error("Exception in LatestNews"+e);
		} 
		return articleList;

	}

	public String getNewsArticlesJSON() {
		Gson prettyGson = new GsonBuilder().setPrettyPrinting().create();
		String newsArticlesJSON = prettyGson.toJson(newsArticles);
		LOG.info("||NewsArticlesModel||activate JSON method|| getNewsArticlesJSON"+newsArticlesJSON);
		return newsArticlesJSON;
	}

	private List<Article> getManualArticles(Node resourceNode) throws PathNotFoundException, RepositoryException {
		List<Article> articleList=new ArrayList<Article>();
		ResourceResolver resourceResolver=request.getResourceResolver();
		ArticleHelper articleHelper=new ArticleHelper();
		if(resourceNode.hasNode("articles")){
			final NodeIterator articlesNodeIterator = resourceNode.getNode("articles").getNodes();
			while (articlesNodeIterator.hasNext()) {
				Node propertyNode=articlesNodeIterator.nextNode();
				if(propertyNode.hasProperty("urlLink")){
					String articlePath=propertyNode.getProperty("urlLink").getString();
					articlePath=articlePath.concat("/"+GlobalConstants.JCR_CONTENT);
					Article newsArticle = articleHelper.getArticlePage(resourceResolver, articlePath,null);
					articleList.add(newsArticle);
				}
			}
		}
		return articleList;
	}

	public List<Article> getPRNNewsArticles(Node resourceNode, String category){
		List<Article> articleList=new ArrayList<Article>();
		ResourceResolver resourceResolver= request.getResourceResolver();
		Map<String,String> articleQueryMap;
		ArticleParams articleParams=new ArticleParams();
		articleParams.setSearchPath(GlobalConstants.PRNEWS_ARTICLES_PATH);
		if(StringUtils.isNotBlank(category)) {
			ArrayList<String> categories = new ArrayList<String>();
			categories.add(category);
			articleParams.setCategories(categories);
		}
		articleQueryMap=getArticleQueryMap(articleParams);
		SearchResult searchResult=SearchHelper.getSearchResults(resourceResolver, articleQueryMap);
		ArticleHelper articleHelper=new ArticleHelper();
		try {
			for(Hit hit:searchResult.getHits()){
				String articlePath;
				articlePath = hit.getPath();
				Article newsArticle = articleHelper.getArticlePage(resourceResolver, articlePath,null);
				articleList.add(newsArticle);
			}
		} catch (RepositoryException e) {
			LOG.error("Exception in LatestNews"+e);
		}
		return articleList;
	}

	private Map<String, String> getArticleQueryMap(ArticleParams articleParams) {
		Map<String,String> map=new HashMap<String, String>();
		map.put("path",articleParams.getSearchPath());
		map.put("type", "nt:unstructured");
		map.put("1_property", GlobalConstants.ARTICLE_CATEGORY);
		map.put("1_property", GlobalConstants.PRNEWS_CATEGORY);
		if(null != articleParams.getCategories()) {
			map.put("1_property.value",GlobalConstants.BOSTON_MARATHON);
		} else {
			map.put("1_property.operation", "exists");
		}
		map.put("orderby","@"+GlobalConstants.PRNEWS_ARTICLES_DATETIME);
		map.put("orderby.sort", "desc");
		map.put("p.limit","-1");
		return map;
	}
}
