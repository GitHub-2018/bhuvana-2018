package com.jh.jhas.core.service;

import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;

import com.jh.jhas.core.newsarticles.dto.Article;
import com.jh.jhas.core.newsarticles.dto.ArticleParams;

public interface JHASArticlesService {
	public List<Article> getDynamicArticles(Node resourceNode,SlingHttpServletRequest request) 
			throws PathNotFoundException, ValueFormatException, RepositoryException;
	public Map<String, String> getArticleQueryMap(ArticleParams articleParams,String tagValue,int count) 
			throws PathNotFoundException, ValueFormatException, RepositoryException;
	public  List<String> getTags(Node resourceNode) 
			throws PathNotFoundException, ValueFormatException, RepositoryException;
	public List<Article> getManualArticles(Node resourceNode,SlingHttpServletRequest request) 
			throws PathNotFoundException, ValueFormatException, RepositoryException;
}
