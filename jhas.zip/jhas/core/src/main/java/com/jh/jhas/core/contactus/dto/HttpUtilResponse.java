package com.jh.jhas.core.contactus.dto;

public class HttpUtilResponse {

	/**
	 * The {@link Integer} instance represents HTTP response code.
	 */
	private int responseCode;
	/**
	 * The {@link String} instance represents HTTP response message.
	 */
	private String responseContent;
	/**
	 * The {@link String} instance represents HTTP response error message.
	 */
	private String responseErrorMsg;
	
	/**
	 * Constructor method to create {@link HttpUtilResponse} object. 
	 * No setter methods for fields to avoid state change. 
	 * @param responseCode for http response code
	 * @param responseContent for http reponse content
	 * @param responseErrorMsg for http error message
	 */
	public HttpUtilResponse(final int responseCode, 
								final String responseContent,
								final String responseErrorMsg) {
		this.responseCode = responseCode;
		this.responseContent = responseContent;
		this.responseErrorMsg = responseErrorMsg;
	}

	/**
	 * @return The {@link String} instance representing HTTP response code.
	 */
	public final int getResponseCode() {
		return responseCode;
	}
	
	/**
	 * @return The {@link String} instance representing HTTP response content.
	 */
	public final String getResponseContent() {
		return responseContent;
	}
	
	/**
	 * @return The {@link String} instance representing HTTP error message.
	 */	
	public final String getResponseErrorMsg() {
		return responseErrorMsg;
	}

	/**
	 * Required to remove SiteCatalyst library from footer code. It will be injected via JS
	 * @return void
	 */
	public final void setResponseContent(String content) {
		this.responseContent = content;
	}
	
}
