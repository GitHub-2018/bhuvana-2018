package com.jh.jhas.core.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jh.jhas.core.helper.EmailHelper;


@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({
	@Property(name = "service.description", value = "Servlet"),
	@Property(name = "sling.servlet.paths", value = {"/bin/sling/removedamrenditions"}),
	@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)
})
public class RemoveRenditionsServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(RemoveRenditionsServlet.class);
	@Reference  
	private QueryBuilder builder;

	protected void doGet(SlingHttpServletRequest request,
		 SlingHttpServletResponse response) throws ServletException, IOException {

		try{
			log.info("inside remove renditions");
			ResourceResolver resourceResolver = request.getResourceResolver();  
			String path = EmailHelper.stripXSS("path",request.getParameter("path"));
			Session session = resourceResolver.adaptTo(Session.class);
			boolean isRenditionPresent = false;
			Map<String, String> map = new HashMap<String, String>();  
			map.put("path", path);
			map.put("type", "dam:Asset"); 
			map.put("p.limit", "-1");
			Query query = builder.createQuery(PredicateGroup.create(map), session);  
			SearchResult result = query.getResult();  
			List<Hit> hits = result.getHits();  
			log.info("results is"+hits);
			for(Hit hit: hits){  
				Node assetNode = resourceResolver.resolve(hit.getPath()).adaptTo(Node.class);
				log.info("assetnode is"+assetNode);
				Node assetJcrNode = assetNode.getNode("jcr:content");
				if(assetJcrNode.hasNode("renditions")) {
					log.info("has renditions folder");
					Node renditionResource=assetJcrNode.getNode("renditions");
					if(renditionResource.hasNodes()){
						log.info("inside rendition folder");
						Iterator<Node> reneditionIterator = renditionResource.getNodes();  
						while(reneditionIterator.hasNext()){  
							log.info("iterating rendition folder");
							  
							Node renditionNode = reneditionIterator.next();
							
							if(!renditionNode.getName().equals("original")){
								isRenditionPresent=true;
								renditionNode.remove();
							}  
						} 
					}
				}


			}  
			session.save(); 
			session.logout();
			String deletionStatus;
			JSONObject obj = new JSONObject();
			if(isRenditionPresent) {
				deletionStatus = "Renditions deleted successfully";
			} else {
				deletionStatus = "No renditions deleted";
			}
			try {
				obj.put("location",path);
				obj.put("status",deletionStatus);
			} 
			catch (JSONException e) {
				log.info("ERROR IN JSON OBJECT PARSING!");
				e.printStackTrace();
			}			      
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(obj.toString());
		}catch(Exception e){  
			e.printStackTrace();  
		}  
	}  

}




