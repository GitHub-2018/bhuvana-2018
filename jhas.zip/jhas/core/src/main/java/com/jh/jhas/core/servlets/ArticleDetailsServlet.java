package com.jh.jhas.core.servlets;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.SearchHelper;
import com.jh.jhas.core.newsarticles.dto.Article;
import com.jh.jhas.core.newsarticles.dto.ArticleParams;
import com.jh.jhas.core.utility.DateUtils;

@Component(immediate = true, metatype = true)
@Service(Servlet.class) 
@Properties({
	@Property(name = "service.description", value ="Servlet"),
	@Property(name = "sling.servlet.paths", value ={"/bin/sling/getLatestNews"}),
	@Property(name = "sling.servlet.methods", value ="GET", propertyPrivate = true)
})
public class ArticleDetailsServlet  extends SlingSafeMethodsServlet{
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(ArticleDetailsServlet.class);

	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		List<Article> articleLists=getPRNNewsArticles(request);
		Iterator<Article> listIterator= articleLists.iterator(); 
		JSONArray articleList = new JSONArray();
		while(listIterator.hasNext()){
			Article article = listIterator.next();
			if(null!=article.getTitle() && null!=article.getSummary() && null!=article.getTags()){
				JSONObject articleDetail = new JSONObject();
				try{
					articleDetail.put("articleTitle", article.getTitle());
					articleDetail.put("articleDescription", article.getSummary());
					articleDetail.put("articleCategory", article.getNewsCategory());
					articleDetail.put("articlePublishedDate", article.getPublishedDate());
					articleDetail.put("articleSubtitle", article.getSubtitle());
					if(StringUtils.isNotBlank(article.getAuthor())) {
						articleDetail.put("articleAuthor",article.getAuthor());
					}
					articleDetail.put("articlePath", article.getPath()+".html");
					
					LOG.info("Article Path is  "+article.getPath());
					LOG.info("News category is "+article.getNewsCategory());
					LOG.info("articleAuthor is  "+article.getAuthor());
				}
				catch(Exception e){
					LOG.info("ERROR IN FETCHING VALUES"+e);
				}
				articleList.put(articleDetail);
			}


		}

		JSONObject objMain = new JSONObject();
		try {
			objMain.putOpt("articleDetails", articleList);
		} 
		catch (JSONException e) {
			LOG.info("ERROR IN FETCHING VALUES"+e);
		}
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(objMain.toString());

	}

	private List<Article> getPRNNewsArticles(SlingHttpServletRequest request){
		List<Article> articleList=new ArrayList<Article>();
		ResourceResolver resourceResolver= request.getResourceResolver();
		Map<String,String> articleQueryMap;
		ArticleParams articleParams=new ArticleParams();
		articleParams.setSearchPath(GlobalConstants.PRNEWS_ARTICLES_PATH);
		articleQueryMap=getArticleQueryMap(articleParams);
		SearchResult searchResult=SearchHelper.getSearchResults(resourceResolver, articleQueryMap);
		try {
			for(Hit hit:searchResult.getHits()){
				String articlePath;
				articlePath = hit.getPath();
				Article newsArticle = getArticlePage(resourceResolver, articlePath);
				articleList.add(newsArticle);
			}
		} catch (RepositoryException e) {
			LOG.error("Exception in LatestNews"+e);
		}
		return articleList;
	}

	private Map<String, String> getArticleQueryMap(ArticleParams articleParams) {
		Map<String,String> map=new HashMap<String, String>();
		map.put("path",articleParams.getSearchPath());
		map.put("type", "nt:unstructured");
		map.put("1_property", GlobalConstants.ARTICLE_CATEGORY);
		map.put("1_property.operation", "exists");
		map.put("orderby","@"+GlobalConstants.PRNEWS_ARTICLES_DATETIME);
		map.put("orderby.sort", "desc");
		map.put("p.limit","-1");
		return map;
	}
	
    private Article getArticlePage(ResourceResolver resourceResolver, String articlePath)	{
        Resource articleResource=resourceResolver.getResource(articlePath);
        Article newsArticle=new Article();
        if(articleResource!=null){
            Node pageContentNode=articleResource.adaptTo(Node.class);
            String articlePagePath;
            try {
                articlePagePath = pageContentNode.getParent().getPath();
                
                PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
        	    Page articlePageContent = pageManager.getPage(articlePagePath);
                newsArticle.setPageName(articlePageContent.getName());
                
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_TITLE)){
                    newsArticle.setTitle(pageContentNode.getProperty(GlobalConstants.ARTICLE_TITLE).getString());
                }
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_SUMMARY)){
                    newsArticle.setSummary(pageContentNode.getProperty(GlobalConstants.ARTICLE_SUMMARY).getString());
                }
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_PUBLISHED_DATE)){
                    String modifiedDate=pageContentNode.getProperty(GlobalConstants.ARTICLE_PUBLISHED_DATE).getString();
                    Calendar calendarDate=pageContentNode.getProperty(GlobalConstants.ARTICLE_PUBLISHED_DATE).getDate();
                    String formattedDate=null;
                    String publishedDate=null;
                    if(calendarDate!=null){
                    	formattedDate=DateUtils.format(calendarDate,"MMM d, yyyy");
                    	publishedDate=String.valueOf(calendarDate.getTimeInMillis()/1000);
                    }
                    else{
                    	DateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy hh:mm:ss z");
                        Date date = dateFormat.parse(modifiedDate);
                    	formattedDate=DateUtils.format(modifiedDate,"MMM d, yyyy");
                    	publishedDate=String.valueOf(date.getTime()/1000);
                    }
                    newsArticle.setModifiedDate(formattedDate);
                    newsArticle.setPublishedDate(publishedDate);
                }
                
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_CATEGORY)){
                    newsArticle.setTags(pageContentNode.getProperty(GlobalConstants.ARTICLE_CATEGORY).getString());
                }
                
                if(pageContentNode.hasProperty(GlobalConstants.NEWS_CATEGORY)){
                    newsArticle.setNewsCategory(pageContentNode.getProperty(GlobalConstants.NEWS_CATEGORY).getString());
                }
                
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_AUTHOR)){
                    newsArticle.setAuthor(pageContentNode.getProperty(GlobalConstants.ARTICLE_AUTHOR).getString());
                }
                
                if(StringUtils.isNotBlank(pageContentNode.getPath())) {
                	newsArticle.setPath(pageContentNode.getPath().substring(0, pageContentNode.getPath().lastIndexOf('/')));
                }
                
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_SUBHEAD_LINE)){
                    newsArticle.setSubtitle(pageContentNode.getProperty(GlobalConstants.ARTICLE_SUBHEAD_LINE).getString());
                }
                
            } 
            catch (Exception e) {
                LOG.info("Exception in ARTICLE HELPER"+ e);
            }
        }
        return newsArticle;
    }
}
