package com.jh.jhas.core.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.jcr.Node;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.newsarticles.dto.Article;
import com.jh.jhas.core.utility.DateUtils;
import com.jh.jhas.core.utility.LinkChecker;

public class ArticleHelper {
    private static final Logger LOG = LoggerFactory.getLogger(ArticleHelper.class);
    public Article getArticlePage(ResourceResolver resourceResolver, String articlePath, String searchTag)	{
        Resource articleResource=resourceResolver.getResource(articlePath);
        Article newsArticle=new Article();
        if(articleResource!=null){
            Node pageContentNode=articleResource.adaptTo(Node.class);
            String articlePagePath;
            try {
                articlePagePath = pageContentNode.getParent().getPath();
                
                PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
        	    Page articlePageContent = pageManager.getPage(articlePagePath);
                newsArticle.setPageName(articlePageContent.getName());
                
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_TITLE)){
                    newsArticle.setTitle(pageContentNode.getProperty(GlobalConstants.ARTICLE_TITLE).getString());
                }
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_BODY)){
                    newsArticle.setDescription(pageContentNode.getProperty(GlobalConstants.ARTICLE_BODY).getString());
                }
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_SUMMARY)){
                    newsArticle.setSummary(pageContentNode.getProperty(GlobalConstants.ARTICLE_SUMMARY).getString());
                }
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_PUBLISHED_DATE)){
                    String modifiedDate=pageContentNode.getProperty(GlobalConstants.ARTICLE_PUBLISHED_DATE).getString();
                    Calendar calendarDate=pageContentNode.getProperty(GlobalConstants.ARTICLE_PUBLISHED_DATE).getDate();
                    String formattedDate=null;
                    String publishedDate=null;
                    if(calendarDate!=null){
                    	formattedDate=DateUtils.format(calendarDate,"MMM d, yyyy");
                    	publishedDate=String.valueOf(calendarDate.getTimeInMillis() / 1000);
                    }
                    else{
                    	DateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy hh:mm:ss z");
                        Date date = dateFormat.parse(modifiedDate);
                    	formattedDate=DateUtils.format(modifiedDate,"MMM d, yyyy");
                    	publishedDate=String.valueOf(date.getTime()/1000);
                    }
                    newsArticle.setModifiedDate(formattedDate);
                    newsArticle.setPublishedDate(publishedDate);
                }
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_IMAGE)){
                	String image=pageContentNode.getProperty(GlobalConstants.ARTICLE_IMAGE).getString();
                	newsArticle.setImage(image);
                }
                if(pageContentNode.hasProperty(GlobalConstants.ARTICLE_AUTHOR)){
                	String author=pageContentNode.getProperty(GlobalConstants.ARTICLE_AUTHOR).getString();
                	newsArticle.setAuthor(author);
                }
                if(pageContentNode.hasProperty(GlobalConstants.EXTERNAL_ARTICLE_CHECK)){
                	String externalPath=null;
                	if(null!=pageContentNode.getProperty(GlobalConstants.EXTERNAL_ARTICLE_PATH).getString()){
                		externalPath=pageContentNode.getProperty(GlobalConstants.EXTERNAL_ARTICLE_PATH).getString();
                	}
                	else{
                		externalPath=articlePagePath;
                	}
                	newsArticle.setPath(LinkChecker.getInternalPath(externalPath));
                	newsArticle.setExternal(true);
                }
                else{
                	newsArticle.setPath(LinkChecker.getInternalPath(articlePagePath));
                }
                newsArticle.setTags(TagHelper.getTagTitle(searchTag,resourceResolver));	
                
                
                
            } 
            catch (Exception e) {
                LOG.info("Exception in ARTICLE HELPER"+ e);
            }
        }
        return newsArticle;
    }
    
}

