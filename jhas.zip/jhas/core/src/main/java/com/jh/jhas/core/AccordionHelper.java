package com.jh.jhas.core;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Session;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class AccordionHelper extends WCMUsePojo{
	
	private Logger LOG = LoggerFactory.getLogger(AccordionHelper.class);
	
	@Override
	public void activate() throws Exception {
		String path = get("path", String.class);
		String nodename = get("nodename", String.class);
		final Resource resource = getResourceResolver().getResource(path);
		Session session=getResourceResolver().adaptTo(Session.class);
		final Node resourceNode = resource.adaptTo(Node.class);
		if(resourceNode.hasNode(nodename)){
			Node propertiesNode=resourceNode.getNode(nodename);
			final NodeIterator nodeIterator = propertiesNode.getNodes();
			while (nodeIterator.hasNext()) {
				Node tabNode = (Node) nodeIterator.next();
				 int index=Integer.parseInt(tabNode.getName())-1;
				 if(path.contains("/accordion") && !tabNode.hasProperty("accordionParsys")) {
					 tabNode.setProperty("accordionParsys", "parsys"+index);
				 } else if(path.contains("/tabs") && !tabNode.hasProperty("tabsParsys")) {
						 tabNode.setProperty("tabsParsys", "tabparsys"+index); 
				 }
				session.save();
			}
		}
	}

}
