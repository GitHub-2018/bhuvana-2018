package com.jh.jhas.core.servlets;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.genericlists.GenericList;
import com.adobe.acs.commons.genericlists.GenericList.Item;
import com.day.cq.mailer.MessageGatewayService;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhas.core.constants.EmailConstants;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.EmailHelper;
import com.jh.jhas.core.helper.RecaptchaHelper;
import com.jh.jhas.core.mailservice.JohnHancockSecureMailService;
import com.jh.jhas.core.models.EmailRecipient;
import com.jh.jhas.core.models.EmailSender;
import com.jh.jhas.core.models.Substitution;
import com.jh.jhas.core.utility.ConfigUtil;

@SlingServlet(paths="/bin/sling/ContactUsServlet", methods="POST", metatype=true) 	
public class ContactUsServlet extends SlingAllMethodsServlet{
private static final long serialVersionUID = 1L;
	
    private static final Logger LOG = LoggerFactory.getLogger(ContactUsServlet.class);

	@Reference
	private MessageGatewayService msgGatewayService;
	
	@Reference
	JohnHancockSecureMailService johnHancockSecureMailService;
     
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
	
	String selectFieldValue = EmailHelper.stripXSS("selectFieldValue",request.getParameter("selectFieldValue"));
	String contactMessage = EmailHelper.stripXSS("contactMessage",request.getParameter("_message"));
	String firstName = EmailHelper.stripXSS( "firstName",request.getParameter("firstname"));
	String lastName =  EmailHelper.stripXSS("lastName",request.getParameter("lastname"));
	String suffix =  EmailHelper.stripXSS("suffix",request.getParameter("suffix"));
	String emailAddress =  EmailHelper.stripXSS("emailId",request.getParameter("email"));
	String accountNumber =  EmailHelper.stripXSS("accountNumber",request.getParameter("accountNumber"));
	String phoneNumber =  EmailHelper.stripXSS("phoneNumber",request.getParameter("phoneNumber"));
	String address =  EmailHelper.stripXSS("address",request.getParameter("address"));
	String custExperienceId =  EmailHelper.stripXSS("custExperienceId",request.getParameter("custExperienceId"));
	String reCaptcha = EmailHelper.stripXSS("recaptcha",request.getParameter("recaptcha"));
	Boolean reCaptchaStatus= RecaptchaHelper.recaptchaValidate(request,reCaptcha);
	String templateId = ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.SEND_MESSAGE_TEMPLATE);
	String toErrorAddress= ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_ERROR_TO_EMAIL);
	
	ResourceResolver resourceResolver=request.getResourceResolver();
	
	// Get Sender Address
	PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
	Page listPage = pageManager.getPage(GlobalConstants.CONTACT_US_TOPIC_PATH);
	GenericList emailList = listPage.adaptTo(GenericList.class);
	
	String toEmail = "";
	for(Item emailItem : emailList.getItems()) {
	   if(selectFieldValue.equals(emailItem.getTitle())) {
	       toEmail=emailItem.getValue();
	       break;
	   }
	    
	}
	List<String> emailRecipients=Arrays.asList(toEmail.split(","));
	
	// populate the digital Sender Address
	List<EmailRecipient> contactUsEmailRecipients = new ArrayList<>();
	
	for(String emailRecipient : emailRecipients) {
		EmailRecipient contactUsEmailRecipient = new EmailRecipient();
		contactUsEmailRecipient.setName(selectFieldValue);
		contactUsEmailRecipient.setEmail(emailRecipient);
		contactUsEmailRecipients.add(contactUsEmailRecipient);
		
	}
	// Initialize Session object
	Session session = resourceResolver.adaptTo(Session.class);			
	// get the current date
	String date = getCurrentDate();


	// populate the digital email placeholders	
	
	List<Substitution> substitutions = new ArrayList<>();

	Substitution firstNameSub = new Substitution();
	firstNameSub.setName("firstName");
	firstNameSub.setValue(firstName);
	substitutions.add(firstNameSub);
	
	Substitution lastNameSub = new Substitution();
	lastNameSub.setName("lastName");
	lastNameSub.setValue(lastName);
	substitutions.add(lastNameSub);
	
	Substitution suffixSub = new Substitution();
	suffixSub.setName("suffix");
	suffixSub.setValue(suffix);
	substitutions.add(suffixSub);
	
	Substitution emailAddressSub = new Substitution();
	emailAddressSub.setName("emailAddress");
	emailAddressSub.setValue(emailAddress);
	substitutions.add(emailAddressSub);
	
	Substitution accountNumberSub = new Substitution();
	accountNumberSub.setName("accountNumber");
	accountNumberSub.setValue(accountNumber);
	substitutions.add(accountNumberSub);
	
	Substitution phoneNumberSub = new Substitution();
	phoneNumberSub.setName("phoneNumber");
	phoneNumberSub.setValue(phoneNumber);
	substitutions.add(phoneNumberSub);
	
	Substitution addressSub = new Substitution();
	addressSub.setName("address");
	addressSub.setValue(address);
	substitutions.add(addressSub);
	
	Substitution contactMessageSub = new Substitution();
	contactMessageSub.setName("contactMessage");
	contactMessageSub.setValue(contactMessage);
	substitutions.add(contactMessageSub);
	
	Substitution custExperienceIdSub = new Substitution();
	custExperienceIdSub.setName("custExperienceId");
	custExperienceIdSub.setValue(custExperienceId);
	substitutions.add(custExperienceIdSub);
	
	
	
	Map<String,String> emailProps = new HashMap<String,String>();
	emailProps.put("date", date);
	emailProps.put("firstName", firstName);
	emailProps.put("lastName", lastName);
	emailProps.put("suffix", suffix);
	emailProps.put("emailAddress", emailAddress);
	emailProps.put("contactMessage", contactMessage);
	emailProps.put("accountNumber", accountNumber);
	emailProps.put("phoneNumber", phoneNumber);
	emailProps.put("address", address);
	emailProps.put("custExperienceId", custExperienceId);
	emailProps.put("selectFieldValue", selectFieldValue);
	
	String emailSubject = "An Inquiry regarding the "+selectFieldValue;
	EmailSender senderAddress = new EmailSender();
	senderAddress.setName("Johnhancock Webadmin");
	senderAddress.setEmail("webadmin@jhancock.com");

	// send the email by invoking Digital Email API
	boolean emailStatus = false;
	try {
		if(reCaptchaStatus) {
			emailStatus = johnHancockSecureMailService.sendDigitalAPIEmail(templateId, senderAddress, contactUsEmailRecipients, emailSubject, substitutions);
			// US337 - Fixes
			if(!emailStatus) {
				EmailHelper.sendContactUsErrorEmail(msgGatewayService, session, toErrorAddress, emailProps);
			}
		}
	} catch (Exception ex) {
		LOG.error("Error sending mail");
	}

	finally {
	    // ALWAYS close the sessions you open
	    if (null != session && session.isLive()) {
		session.logout();
	    }
	    resourceResolver.close();
	}


	
	String jsonMessage = "";
	JSONObject obj = new JSONObject();
	if(!reCaptchaStatus) {
	    jsonMessage = "contactUs_invalid_captcha";
	} else if (emailStatus) {
	    jsonMessage = "contactUs_success";
	} else {
	    jsonMessage = "contactUs_faliure";
	}
	 try {
		obj.put("message",jsonMessage);
	} 
	catch (JSONException e) {
		
		LOG.info("ERROR IN JSON OBJECT PARSING");
		e.printStackTrace();
	}			      
	    response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(obj.toString());
        
        }
    
    private String getCurrentDate() {
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date = new Date();
	return dateFormat.format(date);
}
}