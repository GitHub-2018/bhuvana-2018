package com.jh.jhas.core.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.contactus.dto.HttpUtilResponse;

public class HttpURLUtil {

	/** The logger. */
	private static final Logger LOG = LoggerFactory.getLogger(HttpURLUtil.class);
	// GET method type
	public final static String DEFAULT_METHOD_TYPE_GET	= "GET"; 
	// POST method type
	public final static String METHOD_TYPE_POST			= "POST"; 
	// Agent for POST method
	private static final String USER_AGENT 				= "Mozilla/5.0";


	/**
	 * Executes HTTP URL and returns the response object.
	 * @param url - Http URL
	 * @return The {@link HttpUtilResponse} instance representing HTTP response.
	 * @throws IOException 
	 */
	public static final HttpUtilResponse getHttpResponse(final String url,final String userName,final String password) throws IOException {
		GetMethod get	                                    = null;
		int responseCode 									= -1;
		HttpUtilResponse response 							= null;
		BufferedReader br 									= null;
		InputStream respRd									= null;
		InputStreamReader rd								= null;
		try {

			// Initialize HttpClient Object
			HttpClient httpClient = new HttpClient();
			HttpClientParams httpClientParams = new HttpClientParams();
			DefaultHttpMethodRetryHandler defaultRetryHandler = new DefaultHttpMethodRetryHandler(0, false);
			httpClientParams.setParameter(HttpClientParams.RETRY_HANDLER, defaultRetryHandler);
			httpClient.setParams(httpClientParams);
			// Set user name and password for author instance
			if(StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(password)){
				httpClient.getState().setCredentials(
						new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
						new UsernamePasswordCredentials(userName,password));
			}
			// Initialize GetMethod Object
			get = new GetMethod(url);
			// Execute GET Method
			httpClient.executeMethod(get);
			// Get the response back
			
			responseCode = get.getStatusCode();
			
			StringBuilder responseContent  = new StringBuilder();
			respRd = get.getResponseBodyAsStream();
			rd = new InputStreamReader(respRd, "UTF-8");
			respRd.close();
			br = new BufferedReader(rd);
			rd.close();
			String input;
			while ((input = br.readLine()) != null) {
				responseContent.append(input);
			}
			
			LOG.debug("URL response code - "+responseCode);
			LOG.debug("URL response content - "+responseContent);
			
			response = new HttpUtilResponse(responseCode, responseContent.toString(), null);
			
		} catch (IOException e) {
			response = new HttpUtilResponse(responseCode, null, e.getLocalizedMessage());
		} finally {
			
			if(null != respRd) {
				respRd.close();
			}
			
			if (null != rd) {
				rd.close();
			}
			if (br != null) {
				br.close();
		}	
			if (get != null) {
				get.releaseConnection();
				get = null;
			}
		}
		return response;
	}
	
	
	public static final HttpUtilResponse postHttpsResponse(final String url,final Map<String, String> inputParams){
		PostMethod post	                                    = null;
		int responseCode 									= -1;
		HttpUtilResponse response 							= null;
		HttpsURLConnection con								= null;
		BufferedReader in 									= null;
		OutputStream os 									= null;
		try {

/*
 * Commented out X509 certificates due to fortify scan issues
 * 
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
				public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1) { }
				public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1) { }
			} };
			
			// Install the all-trusting trust manager
			SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
			// Create an ssl socket factory with our all-trusting manager
			SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
			// All set up, we can get a resource through https now:

			URL obj = new URL(url);
			con = (HttpsURLConnection) obj.openConnection();
			// Tell the url connection object to use our socket factory which bypasses security checks
			con.setSSLSocketFactory(sslSocketFactory);		

*/			
			// Setup SSL socket connection
			SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
			// All set up, we can get a resource through https now:
			URL obj = new URL(url);
			con = (HttpsURLConnection) obj.openConnection();
			// Tell the url connection object to use our socket factory which bypasses security checks
			con.setSSLSocketFactory(sslsocketfactory);			

			//add reuqest header
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);
			con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			
			StringBuilder inputContent = new StringBuilder();
			String seperator = "";
			for(String key : inputParams.keySet()){
				inputContent.append(seperator);
				inputContent.append(key+"="+inputParams.get(key));
				seperator = "&";
			}

			// Send post request
			con.setDoOutput(true);
			
			try{
				os = con.getOutputStream();
				os.write(inputContent.toString().getBytes());
			}finally{
				if(os != null){
					safeClose(os);
				}
			}

			responseCode = con.getResponseCode();
			LOG.debug("\nSending 'POST' request to URL : " + url);
			LOG.debug("Post parameters : " + inputContent.toString());
			LOG.debug("Response Code : " + responseCode);
			String inputLine;
			StringBuilder responseContent = new StringBuilder();
			in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			while ((inputLine = in.readLine()) != null) {
				responseContent.append(inputLine);
			}
			
			// print result
			response = new HttpUtilResponse(responseCode, responseContent.toString(), null);
		} catch (Exception e) {
			response = new HttpUtilResponse(responseCode, null, e.getLocalizedMessage());
			if (in != null) {
				try{
					in.close();
				}catch(Exception ex){
					LOG.error("Error while closing stream: ", ex);
				}
				in = null;
			}
		} finally {
			if (con != null) {
				con.disconnect();
				con = null;
			}			
			if (post != null) {
				post.releaseConnection();
				post = null;
			}
			if (in != null) {
				try{
					in.close();
				}catch(Exception e){
					LOG.error("Error while closing stream: ", e);
				}
				in = null;
			}
		}
		return response;
	}
	
	public static void safeClose(OutputStream os) {
		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				LOG.error("Error while closing stream: ", e);
			}
		}
	}
	
}
