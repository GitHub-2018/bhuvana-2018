package com.jh.jhas.core.security;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
public class CryptoBase64 implements Crypto
{
    private static Base64 s_encoder = new Base64();
    private static Base64 s_decoder = new Base64();
    
    private static CryptoHex s_hexEncoder = new CryptoHex();

    public char[] encrypt(String a_text)
    {
        byte [] encrypted = s_encoder.encode(a_text.getBytes());
        return s_hexEncoder.encrypt(new String(encrypted));
    }

    public char[] decrypt(String a_encrypted) throws CryptoException
    {
    	char[] decrypted;
        try
        {
            char[] decryptedStr = s_hexEncoder.decrypt(a_encrypted.trim());
            byte[] decryptedBytes = s_decoder.decode(toBytes(decryptedStr));
            decrypted = new String(decryptedBytes).toCharArray();
        }
        catch (Exception e)
        {
            throw new CryptoException("Base64 Decode failed", e);
        }

        return decrypted;
    }
    
    private byte[] toBytes(char[] chars) {
        CharBuffer charBuffer = CharBuffer.wrap(chars);
        ByteBuffer byteBuffer = Charset.forName("UTF-8").encode(charBuffer);
        byte[] bytes = Arrays.copyOfRange(byteBuffer.array(),
                byteBuffer.position(), byteBuffer.limit());
        Arrays.fill(charBuffer.array(), '\u0000'); // clear sensitive data
        Arrays.fill(byteBuffer.array(), (byte) 0); // clear sensitive data
        return bytes;
    }    
    
}