package com.jh.jhas.core.service;

import org.apache.sling.api.resource.ResourceResolver;

public interface EmailService {

	String getOAUTHToken(String jsonInput, String apiURL, ResourceResolver resourceResolver);
	
	boolean sendEmail(String jsonEmailInput, String apiURL, String oauth, ResourceResolver resourceResolver);
}
