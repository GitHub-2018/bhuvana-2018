package com.jh.jhas.core.service;

import java.util.List;
import org.apache.sling.api.SlingHttpServletRequest;
import com.jh.jhas.core.leadership.dto.LeadershipProfile;

public interface LeadershipProfileService {
	
	public List<LeadershipProfile> getLeadershipProfiles(SlingHttpServletRequest request);

}
