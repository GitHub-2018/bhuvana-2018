package com.jh.jhas.core.servlets;

/*
 *  Copyright 2015 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */



import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.xss.XSSAPI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;


@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({
    @Property(name = "service.description", value = "Servlet"),
    @Property(name = "sling.servlet.paths", value = {"/bin/sling/jhassearchservlet"}),
    @Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)
})
public class JHASSearchServlet extends SlingAllMethodsServlet {

    @Reference
    QueryBuilder builder;
    
    @Reference
    private XSSAPI xssAPI;


    private static Logger log = LoggerFactory.getLogger(JHASSearchServlet.class);
    private static final long serialVersionUID = 1L;

    public JHASSearchServlet() {
        super();
    }

    protected void doGet(SlingHttpServletRequest request,
        SlingHttpServletResponse response) throws ServletException, IOException {

        String pageTitle, pagePath, pageDescription;
        String concatHtml = ".html";
        ResourceResolver resolver = request.getResourceResolver();
        Session session = resolver.adaptTo(Session.class);
        PageManager pageManager = resolver.adaptTo(PageManager.class);
        response.setContentType("text/html");
        String fulltextSearchTerm = "";
        JSONArray resultArray = new JSONArray();
      

        String keyval = xssAPI.encodeForHTML(request.getParameter("search"));
        
        log.info("Entered Key Word :: " + keyval);

        if (StringUtils.isNotBlank(keyval)) {
            fulltextSearchTerm = keyval;

            Map < String, String > map = new HashMap < String, String > ();
            map.put("group.1_group.1_property", "jcr:content/cq:template");
            map.put("group.1_group.1_property.value", "/apps/JHAS%");
            map.put("group.1_group.1_property.operation", "like");
            map.put("group.1_group.2_property", "jcr:content/excludeInSearch");
            map.put("group.1_group.2_property.operation", "exists");
            map.put("group.1_group.2_property.value", "false");
            map.put("group.1_group.type", "cq:Page");
            map.put("group.1_group.fulltext", fulltextSearchTerm);
            map.put("group.1_group.path", "/content/johnhancock");
            map.put("group.p.or", "true");
            map.put("group.2_group.1_property", "jcr:content/metadata/dc:format");
            map.put("group.2_group.1_property.value", "application/pdf");
            map.put("group.2_group.2_property", "jcr:content/dam:relativePath");
            map.put("group.2_group.2_property.value", "johnhancock/forms%");
            map.put("group.2_group.2_property.operation", "like");
            // Filters for sub assets search
            map.put("group.2_group.3_property", "jcr:createdBy");
            map.put("group.2_group.3_property.operation", "unequals");
            map.put("group.2_group.3_property.value", "workflow-process-service");
            map.put("group.2_group.type", "dam:Asset");
            map.put("group.2_group.fulltext", fulltextSearchTerm);
            map.put("group.2_group.path", "/content/dam/johnhancock");
            map.put("p.limit", "-1");

            Query query = builder.createQuery(PredicateGroup.create(map),
                session);

            SearchResult result = query.getResult();

        

            JSONObject resultObj = new JSONObject();
            int pdfCount = 0;
            try {
                for (Hit hit: result.getHits()) {
                    String resourcePath = null;

                  

                    resourcePath = hit.getResource().getPath().toString();

                   
                    if (resourcePath.startsWith("/content/johnhancock")) {
                        Page page = null;
                        page = pageManager.getPage(resourcePath);

                        pagePath = page.getPath().toString();
                        JSONObject searchhitspages = new JSONObject();

                        String HtmlpagePath = pagePath.concat(concatHtml);
                        searchhitspages.put("searchurl", HtmlpagePath);

                        if (StringUtils.isNotBlank(page.getPageTitle())) {


                            pageTitle = page.getPageTitle();

                            searchhitspages.put("searchtitle", pageTitle);
                        } else  {

                            pageTitle = page.getTitle().toString();
                            searchhitspages.put("searchtitle", pageTitle);

                        }
                        
                        String jcrPagepath=resourcePath.concat("/jcr:content");
                        Resource resource = resolver.getResource(jcrPagepath);
                        Node JcrNode=resource.adaptTo(Node.class);
                        if(JcrNode.hasProperty("description")){
                        	pageDescription=JcrNode.getProperty("description").getValue().toString();
                        	searchhitspages.put("searchdescription", pageDescription);
                        }

                        else if (StringUtils.isNotBlank(page.getDescription())) {
                            pageDescription = page.getDescription().toString();
                            searchhitspages.put("searchdescription", pageDescription);
                        }
                        resultArray.put(searchhitspages);

                    }
                    if (resourcePath.startsWith("/content/dam/johnhancock")) {
                        pdfCount++;

                        Resource resource = resolver.getResource(resourcePath);
                        JSONObject searchhitspdf = new JSONObject();
                        Asset asset = resource.adaptTo(Asset.class);
                        if (StringUtils.isNotBlank(asset.getMetadataValue("dc:title"))) {
                            String pdfTitle = asset.getMetadataValue("dc:title").toString();
                            searchhitspdf.put("searchtitle", pdfTitle);

                        } else {
                            String pdfTitle = asset.getName().toString();

                            searchhitspdf.put("searchtitle", pdfTitle);
                        }
                        if (StringUtils.isNotBlank(asset.getMetadataValue("dc:description"))) {
                            String pdfDescription = asset.getMetadataValue("dc:description").toString();

                            searchhitspdf.put("searchdescription", pdfDescription);

                        }
                        String pdfPath = asset.getPath().toString();


                        searchhitspdf.put("searchurl", pdfPath);
                        resultArray.put(searchhitspdf);
                    }
                  
                

                }
                resultObj.put("searchcount", resultArray.length());
                resultObj.put("pdfsearchcount", pdfCount);
                resultObj.put("searchresults", resultArray);
                
            } catch (RepositoryException e) {

                log.error("Repository exception occured", e);
            } catch (JSONException e) {

                log.error("Json exception occured", e);

            }


            response.getWriter().write(resultObj.toString());
        } else {

            response.getWriter().write("Failure");
        }

    }

    protected void doPost(SlingHttpServletRequest request,
            SlingHttpServletResponse response) throws ServletException,
        IOException {
            doGet(request, response);
        }

}