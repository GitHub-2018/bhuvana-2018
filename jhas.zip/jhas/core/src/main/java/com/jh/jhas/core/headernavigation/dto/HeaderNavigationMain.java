package com.jh.jhas.core.headernavigation.dto;
import java.util.List;


public class HeaderNavigationMain {
    
    private List<HeaderNavItem> headerNavList;

    public List<HeaderNavItem> getHeaderNavList() {
        return headerNavList;
    }

    public void setHeaderNavList(List<HeaderNavItem> headerNavList) {
        this.headerNavList = headerNavList;
    }
    
    
    
}
