package com.jh.jhas.core.newsarticles.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.ArticleHelper;
import com.jh.jhas.core.helper.SearchHelper;
import com.jh.jhas.core.newsarticles.dto.Article;
import com.jh.jhas.core.newsarticles.dto.ArticleParams;
import com.jh.jhas.core.newsarticles.dto.NewsArticles;

@Model(adaptables = SlingHttpServletRequest.class)
public class DynamicArticlesModel {

	private static Logger LOG = LoggerFactory.getLogger(DynamicArticlesModel.class);
	public NewsArticles dynamicNewsArticles;
	public List<String> filterList;
	@Inject
	private SlingHttpServletRequest request;

	@Inject
	private String path;

	@PostConstruct
	protected void init() throws ValueFormatException, RepositoryException {
		final Resource resource = request.getResourceResolver().getResource(path);
		Node resourceNode = resource.adaptTo(Node.class);
		dynamicNewsArticles = new NewsArticles();
		if (null != resourceNode) {
			dynamicNewsArticles.setArticles(getDynamicArticles(resourceNode));

		}
	}

	private List<Article> getDynamicArticles(Node resourceNode)
			throws PathNotFoundException, ValueFormatException, RepositoryException {
		List<Article> articleList = new ArrayList<Article>();
		filterList = new ArrayList<String>();
		ResourceResolver resourceResolver = request.getResourceResolver();
		Map<String, String> articleQueryMap = new HashMap<String, String>();
		int count = 0;
		ArticleParams articleParams = new ArticleParams();
		articleParams.setSearchPath(GlobalConstants.JHAS_ARTICLES_PATH);
		if (resourceNode.hasProperty("articleCount")) {
			count = Integer.parseInt(resourceNode.getProperty("articleCount").getString());
			articleParams.setLimit(count);
		}
		for (String tagValue : getTags(resourceNode)) {
			articleQueryMap= getArticleQueryMap(articleParams,tagValue,count );
		
		LOG.info("MAP: " + articleQueryMap);
		SearchResult searchResult = SearchHelper.getSearchResults(resourceResolver, articleQueryMap);
		ArticleHelper articleHelper = new ArticleHelper();
		
		try {
			for (Hit hit : searchResult.getHits()) {
				String articlePath;
				articlePath = hit.getPath() + "/" + GlobalConstants.JCR_CONTENT;
				Article newsArticle = articleHelper.getArticlePage(resourceResolver, articlePath, tagValue);
				articleList.add(newsArticle);
			}

		} catch (RepositoryException e) {
			LOG.error("Exception in LatestNews" + e);
		}
		}
		return articleList;
	}

	private Map<String, String> getArticleQueryMap(ArticleParams articleParams,String tagValue,int count)
			throws PathNotFoundException, ValueFormatException, RepositoryException {
		Map<String, String> map = new HashMap<String, String>();
		map.put("path", articleParams.getSearchPath());
		map.put("type", "cq:Page");
		map.put("group.p.and", "true");
		map.put("group.1_property", GlobalConstants.JCR_CONTENT + "/" + GlobalConstants.ARTICLE_CATEGORY);
		map.put("group.1_property.1_value", tagValue);
		map.put("group.2_property", GlobalConstants.JCR_CONTENT + "/" + GlobalConstants.SLING_RESOURCE_TYPE);
		map.put("group.2_property.value", GlobalConstants.NEWSARTICLE_RENDERER);
		map.put("orderby", "@" + GlobalConstants.JCR_CONTENT + "/" + GlobalConstants.ARTICLE_PUBLISHED_DATE);
		map.put("orderby.sort", "desc");
		map.put("p.limit",count+"");
		return map;
	}

	public static List<String> getTags(Node resourceNode)
			throws PathNotFoundException, ValueFormatException, RepositoryException {
		List<String> dynamicTagList = new ArrayList<String>();
		if (resourceNode.hasProperty("cq:tags")) {
			Property tagsProperty = resourceNode.getProperty("cq:tags");
			if (tagsProperty.isMultiple()) {
				Value[] tagValues = tagsProperty.getValues();
				for (Value tagValue : tagValues) {
					dynamicTagList.add(tagValue.getString());
				}
			}
		}
		return dynamicTagList;
	}

}
