package com.jh.jhas.core.headernavigation.dto;

public class HeaderNavItem {

    private String navLevel;
    private String levelId;
    private String parentLevelId;
    private String navTitle;
    private String navURL;
    private String navPageName;
    
    
	public String getNavLevel() {
        return navLevel;
    }
    public void setNavLevel(String navLevel) {
        this.navLevel = navLevel;
    }
    public String getLevelId() {
        return levelId;
    }
    public void setLevelId(String levelId) {
        this.levelId = levelId;
    }
    public String getParentLevelId() {
        return parentLevelId;
    }
    public void setParentLevelId(String parentLevelId) {
        this.parentLevelId = parentLevelId;
    }
    public String getNavTitle() {
        return navTitle;
    }
    public void setNavTitle(String navTitle) {
        this.navTitle = navTitle;
    }
    public String getNavURL() {
        return navURL;
    }
    public void setNavURL(String navURL) {
        this.navURL = navURL;
    }
    public String getNavPageName() {
		return navPageName;
	}
	public void setNavPageName(String navPageName) {
		this.navPageName = navPageName;
	}
}
