package com.jh.jhas.core.contactus.dto;

public class EmailAPICredential {
	public StringBuilder username;
	public StringBuilder pwd;
	
	public StringBuilder getUsername() {
		return username;
	}

	public void setUsername(StringBuilder username) {
		this.username = username;
	}

	public StringBuilder getPwd() {
		return pwd;
	}

	public void setPwd(StringBuilder pwd) {
		this.pwd = pwd;
	}

	@Override
	public String toString() {
		return "EmailAPICredential [username=" + username + ", pwd=" + pwd + "]";
	}
}
