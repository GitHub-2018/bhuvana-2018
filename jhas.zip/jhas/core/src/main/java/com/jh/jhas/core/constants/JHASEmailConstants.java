package com.jh.jhas.core.constants;

public class JHASEmailConstants {

	public static final String TEMPLATE_PATH = "/apps/settings/wcm/designs/JHAS/email-templates/workflowemailtemplate";
	public static final String TO_EMAIL	= "";
	public static final String PARAMS_CC_RECEPIENT	= "ccrecipient";
	public static final String SUBJECT_EMAIL = "subject";
	public static final String CONTENT_TYPE = "application/json; charset=UTF-8";
	public static final String REDIRECT_PATH = "redirectpath";
	public static final String FIRST_NAME="name";
	public static final String EMAIL_ADDRESS="emailAddress";
	public static final String MESSAGE_EMAIL="message";
	public static final String SENDER_EMAIL = "senderName";
	public static final String SENDER_EMAIL_ADDRESS = "senderEmailAddress";
	
}
