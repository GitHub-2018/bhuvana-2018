package com.jh.jhas.core.models;

import java.util.List;

public class DropdownContent {
	
	private String dropdowncontenttitle;
	private String dropdowncontenturl;
	private List<NavItem> navitemlist;
	
	public void setDropdowncontenttitle(String title){
		
	this.dropdowncontenttitle=title;
	}
	public String getDropdowncontenttitle(){
		return dropdowncontenttitle;
		
	}
	public void setDropdownContentUrl(String url){
		
		this.dropdowncontenturl=url;
		}
		public String getDropdowncontenturl(){
			return dropdowncontenturl;
			
		}
	
		public void setNavitemlist(List<NavItem> listNavItem){
			this.navitemlist=listNavItem;
		}
		public List<NavItem> getNavitemlist(){
			return navitemlist;
		}
	

}
