package com.jh.jhas.core.models;

public class NavItem {

	private String linkurl;
	private String linktitle;
	
	public void setLinkurl(String url){
		
		this.linkurl=url;
	}
	public String getLinkurl(){
		return linkurl;
		
	}
	public void setLinktitle(String title){
		
		this.linktitle=title;
	}
	public String getLinktitle(){
		return linktitle;
		
	}
}
