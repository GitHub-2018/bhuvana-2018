package com.jh.jhas.core.utility;

import java.net.URL;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.settings.SlingSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.mailer.MessageGatewayService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jh.jhas.core.security.Crypto;
import com.jh.jhas.core.security.CryptoBase64;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.lang.text.StrLookup;
import com.day.cq.commons.mail.MailTemplate;
import com.day.cq.mailer.MessageGateway;

public class EmailUtil {

private static final Logger LOG = LoggerFactory.getLogger(EmailUtil.class);	
	
	// encrypt/decrypt util
	private static final Crypto crypto = new CryptoBase64(); 
	
	// Private constructor to avoid object creation
	private EmailUtil(){
		
	}
	
	public static final String getSuffixForInternalPages(final String path){
		return StringUtils.startsWith(path,"/content") ? ".html" : "";
	}
	
	private static Pattern[] patterns = new Pattern[] {
			// Script fragments
			Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
			// src='...'
			Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",
					Pattern.CASE_INSENSITIVE | Pattern.MULTILINE
							| Pattern.DOTALL),
			Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"",
					Pattern.CASE_INSENSITIVE | Pattern.MULTILINE
							| Pattern.DOTALL),
			// lonely script tags
			Pattern.compile("</script>", Pattern.CASE_INSENSITIVE),
			Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL),
			// eval(...)
			Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL),
			// expression(...)
			Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL),
			// javascript:...
			Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
			// vbscript:...
			Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
			// onload(...)=...
			Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE
					| Pattern.MULTILINE | Pattern.DOTALL)};
	
	
	public static final String stripXSS(String attributeName, String value) {
		if (value != null) {
			
			// Avoid null characters
			value = value.replaceAll("\0", "");

			// Remove all sections that match a pattern
			for (Pattern scriptPattern : patterns) {
				
				value = scriptPattern.matcher(value).replaceAll("");
			}			
			
			Pattern pattern = Pattern.compile("^[^<>%]*$");
			Matcher matcher = pattern.matcher(value);
			if(!matcher.matches()){
				LOG.info("Attribute " + attributeName + " Contains inadmissible character...: " + value);
				value = "";
			}
		}
		return value;
	}	
	
	
	public static final char[] encryptText(String textToEncrypt) throws Exception
	{
		return crypto.encrypt(textToEncrypt);
	}

	public static final char[] decryptText(String encryptedId) throws Exception
	{
		return crypto.decrypt(encryptedId);
	}	
	

	public static boolean isValidHTMLURL(String pUrl) {

        try 
        {
            URL u = new URL(pUrl);
            // to test whether its a valid URL or not
            u.toURI();
            if(!StringUtils.endsWith(u.getPath(), "html")){
            	return false;
            }
        } 
        catch (Exception e) 
        {
            return false;
        }
        return true;
    }
	
	public static boolean isAuthorEnvironment(SlingSettingsService settingsService){
		 final Set<String> runmodes = settingsService.getRunModes();
		 for(String runMode : runmodes){
			 if(StringUtils.equalsIgnoreCase(runMode, "author")){
				 return true;
			 }
		 }
		 return false;
	}
	
	
	public static String addParameterToSearchString(String parameterName,boolean commaFlag){
		StringBuilder queryBuilder = new StringBuilder();
		if(commaFlag){
			queryBuilder.append(",");
		}
		queryBuilder.append("[");
		queryBuilder.append(parameterName);
		queryBuilder.append("]");
		return queryBuilder.toString();
	}	
	
	/**
	 * Converts the argument to lowercase and 
	 * seperate the words with underscore
	 * @param s
	 * @return
	 */
	public static String convertSpacewithUnderscore(String s) {
		// convert the user entered  value to lowercase and space to
		// underscore.
		return StringUtils.lowerCase(s).replaceAll(" ", "_");
	}
	
	/**
	 * To exclude fields based on modifier in JSON output
	 * @param modifier - Modifier levels  - Modifier.PUBLIC, Modifier.PROTECTED, Modifier.PRIVATE, Modifier.ABSTRACT, Modifier.STATIC, Modifier.FINAL, Modifier.STRICT
	 * @return
	 */
	public static Gson createGsonObj(){	
		return new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
	}
	
	
	public static void sendEmail(MessageGatewayService msgGatewayService, Session session,
			final String emailTemplatePath, final Map<String, String> emailProps, String toAddress) throws Exception {
		HtmlEmail email = new HtmlEmail();
		MailTemplate mailTemplate = MailTemplate.create(emailTemplatePath, session);
		if (mailTemplate != null) {
			email = mailTemplate.getEmail(StrLookup.mapLookup(emailProps), HtmlEmail.class);
			String[] toAddressArray=toAddress.split(",");
			// To add email addresses in TO list
			for (final String recipient : toAddressArray) {
				email.addTo(recipient);
			}
			

			LOG.info("Error mail >> "+ email+ "  "+mailTemplate+" "+session);
			MessageGateway<HtmlEmail> messageGateway = msgGatewayService.getGateway(HtmlEmail.class);
			LOG.info("messageGateway"+messageGateway);
			messageGateway.send(email);
			//LOG.info("Email Sent");
		}
	}
	
}//
