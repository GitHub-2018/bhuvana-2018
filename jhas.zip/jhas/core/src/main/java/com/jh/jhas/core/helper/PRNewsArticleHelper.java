package com.jh.jhas.core.helper;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.prnewsarticle.Release;
import com.jh.jhas.core.utility.DateUtils;
import com.jh.jhas.core.utility.TextUtil;

public class PRNewsArticleHelper {
	
	private static Logger LOG = LoggerFactory.getLogger(PRNewsArticleHelper.class);
	public static void saveArticleContent(ResourceResolver resourceResolver,Release articleRelease, String path){
		Node articleNode;
		Resource articleResource;
		articleResource=resourceResolver.getResource(path+"/"+GlobalConstants.JCR_CONTENT);
		articleNode=articleResource.adaptTo(Node.class);
			try {
			    articleNode.setProperty(GlobalConstants.NODE_PRIMARY_TYPE, GlobalConstants.CQ_PAGE_CONTENT);
				articleNode.setProperty(GlobalConstants.PRNEWS_ARTICLES_DATETIME, DateUtils.getTimeInMilliseconds(articleRelease.getModifiedDate()));
				articleNode.setProperty(GlobalConstants.ARTICLE_PUBLISHED_DATE, DateUtils.getCalendarDate(articleRelease.getModifiedDate()));
				articleNode.setProperty(GlobalConstants.ARTICLE_TITLE, StringUtils.isNotBlank(articleRelease.getHeadline()) ? Jsoup.parse(articleRelease.getHeadline()).text():"");
				articleNode.setProperty(GlobalConstants.ARTICLE_SUBHEAD_LINE, StringUtils.isNotBlank(articleRelease.getSubheadline()) ? Jsoup.parse(articleRelease.getSubheadline()).text():"");
				articleNode.setProperty(GlobalConstants.ARTICLE_BODY, articleRelease.getBody());
				articleNode.setProperty(GlobalConstants.ARTICLE_IMAGE, articleRelease.getImage());
				articleNode.setProperty(GlobalConstants.ARTICLE_SUMMARY, StringUtils.isNotBlank(articleRelease.getSummary().replaceAll("\\<[^>]*>", "")) ? Jsoup.parse(articleRelease.getSummary().replaceAll("\\<[^>]*>", "")).text() : "");
				articleNode.setProperty(GlobalConstants.NEWS_CATEGORY, StringUtils.isNotBlank(articleRelease.getCategory().getName()) ? Jsoup.parse(articleRelease.getCategory().getName().trim()).text() : "");
				String category=TextUtil.getValidContentName(StringUtils.isNotBlank(articleRelease.getCategory().getName()) ? Jsoup.parse(articleRelease.getCategory().getName().trim()).text() : "");
				category="jhas:news/"+category;
				articleNode.setProperty(GlobalConstants.ARTICLE_CATEGORY,category);
				String contact=articleRelease.getContact();
				articleNode.setProperty(GlobalConstants.ARTICLE_AUTHOR,contact.split(",")[0]);
				Session session=resourceResolver.adaptTo(Session.class);
				session.save();
			} catch (RepositoryException e) {
			    	LOG.info("Exception in setting page property"+e);
			}
	}
}
