package com.jh.jhas.core.servlets;

import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.jh.jhas.core.helper.EmailHelper;
import com.jh.jhas.core.helper.RecaptchaHelper;
import com.jh.jhas.core.helper.SoapConnectionHelper;
import com.jh.jhas.core.unclaimedpropertyform.AccountSearchRequest;
import com.jh.jhas.core.unclaimedpropertyform.ObjectFactory;
import com.jh.jhas.core.unclaimedpropertyform.SubmitRequest;
import com.jh.jhas.core.utility.DateUtils;
@SlingServlet(paths="/bin/sling/UnclaimedPropertyFormServlet", methods="POST", metatype=true)
public class UnclaimedPropertyFormServlet extends SlingAllMethodsServlet{
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(UnclaimedPropertyFormServlet.class);
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		
		try {
			String firstName= request.getParameter("firstname");
			String middleName=request.getParameter("middlename");
			String lastName= request.getParameter("lastname");
			String companyName= request.getParameter("companyName");
			String maidenName= request.getParameter("maidenname");
			String socSecNumFirst= request.getParameter("socSecNumFirst");
			String socSecNumSecond= request.getParameter("socSecNumSecond");
			String socSecNumThird= request.getParameter("socSecNumThird");
			String birthDate= request.getParameter("birthDate");
			String deathDate=request.getParameter("deathDate");
			String addressFirst= request.getParameter("addressFirst");
			String addressSecond= request.getParameter("addressSecond");
			String city= request.getParameter("city");
			String state= request.getParameter("state");
			String zipCode= request.getParameter("zipCode");
			String productType= request.getParameter("product");
			String policyNum= request.getParameter("policynum");
			String contactFirstName=request.getParameter("contactfirstname");
			String contactLastName=request.getParameter("contactlastname");
			String contactRelationship=request.getParameter("contactrelationship");
			String contactDescription= request.getParameter("contactdescription");
			String contactAddressFirst= request.getParameter("contactaddressFirst");
			String contactAddressSecond= request.getParameter("contactaddressSecond");
			String contactCity= request.getParameter("contactcity");
			String contactState= request.getParameter("contactstate");
			String contactZipCode= request.getParameter("contactzipCode");
			String contactPhoneNumber= request.getParameter("contactphoneNumber");		
			String contactEmail= request.getParameter("contactemail");
			String hearAboutUs = request.getParameter("hearaboutus");
			String hearAboutUsOther = request.getParameter("hearaboutusother");
			String message=request.getParameter("message");
			String reCaptcha = EmailHelper.stripXSS("reCaptcha",request.getParameter("recaptcha"));
			Boolean reCaptchaStatus= RecaptchaHelper.recaptchaValidate(request,reCaptcha);
			String socSecNum= socSecNumFirst+socSecNumSecond+socSecNumThird;
		    ObjectFactory objectFactory=new ObjectFactory();
			AccountSearchRequest accountSearchRequest=objectFactory.createAccountSearchRequest();
			accountSearchRequest.setAddress1(addressFirst);
			accountSearchRequest.setAddress2(addressSecond);
			accountSearchRequest.setCity(city);
			accountSearchRequest.setContactAddress1(contactAddressFirst);
			accountSearchRequest.setContactAddress2(contactAddressSecond);
			accountSearchRequest.setContactCity(contactCity);
			accountSearchRequest.setContactEmail(contactEmail);
			accountSearchRequest.setContactFirstName(contactFirstName);
			accountSearchRequest.setContactLastName(contactLastName);
			accountSearchRequest.setContactPhone(contactPhoneNumber);
			accountSearchRequest.setContactRelationship(contactRelationship);
			accountSearchRequest.setContactRelationshipDescription(contactDescription);
			accountSearchRequest.setContactState(contactState);
			accountSearchRequest.setContactZipCode(contactZipCode);
			accountSearchRequest.setDateOfBirth(DateUtils.getGregorianCalendarDate(birthDate));
			if(!deathDate.isEmpty()){
				accountSearchRequest.setDateOfDeath(DateUtils.getGregorianCalendarDate(deathDate));
			}
			accountSearchRequest.setEmployerName(companyName);
			accountSearchRequest.setFirstName(firstName);
			accountSearchRequest.setLastName(lastName);
			accountSearchRequest.setMiddleName(middleName);
			accountSearchRequest.setOtherName(maidenName);
			accountSearchRequest.setPolicyNumber(policyNum);
			accountSearchRequest.setProduct(productType);
			accountSearchRequest.setReferralDescription(hearAboutUsOther);
			accountSearchRequest.setReferralSource(hearAboutUs);
			accountSearchRequest.setRequestComments(message);
			accountSearchRequest.setSSN(socSecNum);
			accountSearchRequest.setState(state);
			accountSearchRequest.setZipCode(zipCode);
			
			
			JAXBElement<AccountSearchRequest> accountSearchElement=objectFactory.createSubmitRequestAccountDetails(accountSearchRequest);
			
			SubmitRequest submitRequest=objectFactory.createSubmitRequest();
			submitRequest.setAccountDetails(accountSearchElement);
			
			JAXBContext context= JAXBContext.newInstance(SubmitRequest.class);
			
			Marshaller marshaller=context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			
			String jsonMessage = "";
			JSONObject obj = new JSONObject();
			if(!reCaptchaStatus) {
				jsonMessage = "propertyForm_invalid_captcha";
			} else {
				Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
				marshaller.marshal(submitRequest, document);
				String submitCode=SoapConnectionHelper.getSOAPRequest(document);
				if("SUCCESS".equals(submitCode)) {
					jsonMessage = "propertyForm_success";
				} else {
					jsonMessage="propertyForm_faliure";
				}
			}
			try {
				obj.put("message",jsonMessage);
			} 
			catch (JSONException e) {
				LOG.info("ERROR IN JSON OBJECT PARSING!");
				e.printStackTrace();
			}			      
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(obj.toString());

		} catch (Exception e) {
			LOG.error("Exception in Unclaimed Property Servlet"+e);
		}
	}

	


		
	

}
