package com.jh.jhas.core.utility;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class HttpTwitterImageURL extends WCMUsePojo {
	Logger log = LoggerFactory.getLogger(HttpTwitterImageURL.class);
	private String httpTwitterUrl;
	@Override
	public void activate() throws Exception {
		String pathUrl = get("imgParam", String.class);
		if(StringUtils.isNotBlank(pathUrl)) {
			log.info("Twitter Image Path : "+pathUrl);
			String fetchedUrl = getRequest().getRequestURL().toString();
			httpTwitterUrl = fetchedUrl.substring(0, fetchedUrl.length() - getRequest().getRequestURI().length()) + getRequest().getContextPath() + pathUrl;
		} else {
			httpTwitterUrl = "";
		}
	}
	public String getHttpTwitterUrl() {
		return httpTwitterUrl;
	}

}
