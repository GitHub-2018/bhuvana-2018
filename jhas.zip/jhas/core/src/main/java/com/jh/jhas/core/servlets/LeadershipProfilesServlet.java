package com.jh.jhas.core.servlets;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.leadership.dto.LeadershipProfile;
import com.jh.jhas.core.service.LeadershipProfileService;

@Component(immediate = true, metatype = true)
@Service(Servlet.class) 
@Properties({
	@Property(name = "service.description", value ="Servlet"),
	@Property(name = "sling.servlet.paths", value ={"/bin/sling/getLeadershipProfiles"}),
	@Property(name = "sling.servlet.methods", value ="GET", propertyPrivate = true)
})
public class LeadershipProfilesServlet  extends SlingSafeMethodsServlet{
	@Reference
	LeadershipProfileService leadershipProfileService;

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(LeadershipProfilesServlet.class);

	protected final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		List<LeadershipProfile> leadershipProfiles = leadershipProfileService.getLeadershipProfiles(request);
		Iterator<LeadershipProfile> listIterator= leadershipProfiles.iterator(); 
		JSONArray leadershipProfileList = new JSONArray();

		while(listIterator.hasNext()){
			LeadershipProfile leadershipProfile = listIterator.next();
			if(StringUtils.isNotBlank(leadershipProfile.getName())) {
				JSONObject leadershipProfileDetail = new JSONObject();
				try {
					leadershipProfileDetail.put("name", leadershipProfile.getName());
					leadershipProfileDetail.put("title", leadershipProfile.getTitle());
					leadershipProfileDetail.put("bu", leadershipProfile.getBusinessUnit());
					leadershipProfileDetail.put("showimage", leadershipProfile.getTurnoffpicture());
					leadershipProfileDetail.put("image", leadershipProfile.getPicture());
					leadershipProfileDetail.put("categories", new JSONArray(leadershipProfile.getProfileCategory()));
					leadershipProfileDetail.put("phone", leadershipProfile.getPhone());
					leadershipProfileDetail.put("email", leadershipProfile.getEmail());
					leadershipProfileDetail.put("linkedin", leadershipProfile.getLinkedIn());
					leadershipProfileDetail.put("url", leadershipProfile.getUrl());
				} catch (JSONException e) {
					LOG.error("Exception in leadershipProfileDetail"+ e);
				}
				leadershipProfileList.put(leadershipProfileDetail);
			}
		}

		JSONObject resultObj = new JSONObject();
		try {
			resultObj.putOpt("profile", leadershipProfileList);
			response.getWriter().write(resultObj.toString());
		} catch (JSONException e) {
			LOG.error("Exception in final Profile JSON Array"+ e);
		}
	}
}
