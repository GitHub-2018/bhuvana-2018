package com.jh.jhas.core;

import java.util.GregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.jh.jhas.core.utility.DateUtils;

public class DateFieldReader extends WCMUsePojo {
    Logger log = LoggerFactory.getLogger(DateFieldReader.class);
    private String dateParam;
    @Override
    public void activate() throws Exception {
	GregorianCalendar gregDateParameter = get("dateParam", GregorianCalendar.class);
	if(null != gregDateParameter) {
	    log.info(gregDateParameter.toString());
	    dateParam = DateUtils.getStringFromDate(gregDateParameter);
	} else {
	    dateParam = "";
	}
    }
    public String getDateParam() {
        return dateParam;
    }

}
