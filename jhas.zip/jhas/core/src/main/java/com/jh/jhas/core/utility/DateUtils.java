package com.jh.jhas.core.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.servlets.UnclaimedPropertyFormServlet;

public class DateUtils {
	
	public static Calendar getCalendarDate(String dateString){
	Calendar cal = Calendar.getInstance();
	SimpleDateFormat sdf = new SimpleDateFormat("EE,dd MMM yyyy HH:mm:ss z");
	try {
		cal.setTime(sdf.parse(dateString));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return cal;
	}
	

	public static String format(final Calendar calendar, final String dateFormat) {
        DateFormat formatter = new SimpleDateFormat(dateFormat);
        return formatter.format( calendar.getTime() );
}

	public static String format(String dateString, String dateFormat){
		String formatteddate=null;
		Date date=null;
		SimpleDateFormat sdf1=new SimpleDateFormat("EE,dd MMM yyyy HH:mm:ss z");
		SimpleDateFormat sdf2=new SimpleDateFormat(dateFormat);
		try {
			date=sdf1.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		formatteddate=sdf2.format(date);
		return formatteddate;
	}
	public static Long getTimeInMilliseconds(String dateString){
		SimpleDateFormat sdf=new SimpleDateFormat("EE,dd MMM yyyy HH:mm:ss z");
		Date date = null;
		try {
			date = sdf.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Calendar cal=Calendar.getInstance();	
		cal.setTime(date);
		return cal.getTimeInMillis();
	}
	
	public static String getYearFromdateString(String dateString){
		
		String year=null;
		String dateArray[]=dateString.split(" ");
		year=dateArray[3];
		return year;
		
	}
	
	public static String getMonthFromdateString(String dateString){
		String month="";
		String dateArray[]=dateString.split(" ");
		month=dateArray[2];
		if(month.equals("Jan")){
			month = "01";
		}
		else if(month.equals("Feb")){
			month = "02";
		}
		else if(month.equals("Mar")){
			month= "03";
		}
		else if(month.equals("Apr")){
			month = "04";
		}
		else if(month.equals("May")){
			month = "05";
		}
		else if(month.equals("Jun")){
			month = "06";
		}
		else if(month.equals("Jul")){
			month = "07";
		}
		else if(month.equals("Aug")){
			month = "08";
		}
		else if(month.equals("Sep")){
			month = "09";
		}
		else if(month.equals("Oct")){
			month = "10";
		}
		else if(month.equals("Nov")){
			month = "11";
		}
		else if(month.equals("Dec")){
			month = "12";
		}
		return month;
	}
	
	public static String getStringFromDate(GregorianCalendar gregDateParameter){
	    	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	    	return df.format(gregDateParameter.getTime());
	}
	public static  String getCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	public static XMLGregorianCalendar getGregorianCalendarDate(String dateString) throws ParseException, DatatypeConfigurationException{
		Date date=null;
		DateFormat df=new SimpleDateFormat("MM/dd/yyyy");
		date=df.parse(dateString);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		return xmlDate;
		
	}
}
