package com.jh.jhas.core.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@SlingServlet(paths="/bin/sling/GetFormSubmissionData", methods="POST", metatype=true)
public class GetFormSubmissionData extends SlingAllMethodsServlet {



	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG = LoggerFactory.getLogger(GetFormSubmissionData.class);
	
	
	
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("Inside Salesforce Form Servlet");
		 Enumeration<String> parameterNames = request.getParameterNames();
		 JsonArray formData = new JsonArray();
		 while (parameterNames.hasMoreElements()) {
		  String paramName = parameterNames.nextElement();
		  JsonObject formInfo = new JsonObject();
		  formInfo.addProperty("Key", paramName);
		  String paramValue=Arrays.toString(request.getParameterValues(paramName));
		  paramValue = paramValue.substring(1, paramValue.length()-1);
		  formInfo.addProperty("Value", paramValue);
		  /*LOG.info("Key : "+paramName+"Data : "+paramValue);*/
		  formData.add(formInfo);
		 }
		 response.setContentType("application/json");
		 response.setCharacterEncoding("UTF-8");
		 response.getWriter().write(formData.toString());	
			
	}
}
			
			

