package com.jh.jhas.core;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.adobe.cq.sightly.WCMUsePojo;
import com.jh.jhas.core.constants.GlobalConstants;

public class GalleryVideoIdentifier extends WCMUsePojo{
	private String videoSourceValue;
	private String displayVideoURL;
	
	@Override
	public void activate() throws Exception {
		String videoURL = get("videoURL", String.class);
		if(videoURL.contains("youtu")) {
			videoSourceValue = GlobalConstants.VIDEO_TYPE_YOUTUBE;
			displayVideoURL = getYoutubeURL(videoURL);
		} else {
			videoSourceValue = GlobalConstants.VIDEO_TYPE_HTML5;
		}
	}
	
	private String getYoutubeURL(String videoURL) {
		String youtubePattern = GlobalConstants.YOUTUBE_VIDEO_PATTERN;
		Pattern compiledPattern = Pattern.compile(youtubePattern);
		Matcher matcher = compiledPattern.matcher(videoURL);
		if(matcher.find()){
			return matcher.group();
		}
		return videoURL;
	}

	public String getVideoSourceValue() {
		return videoSourceValue;
	}
	
	public String getDisplayVideoURL() {
		return displayVideoURL;
	}

}
