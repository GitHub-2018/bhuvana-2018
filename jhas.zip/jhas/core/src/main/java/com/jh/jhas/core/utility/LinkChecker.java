package com.jh.jhas.core.utility;

import org.apache.commons.lang.StringUtils;

public class LinkChecker {

    public static String getInternalPath(String url) {
              String modifiedURL;
                if (StringUtils.isNotBlank(url) && url.startsWith("/content/")
                                && !url.endsWith(".html")
                                && !url.startsWith("/content/dam/")
                                && !url.contains(".html")) {
                    modifiedURL = url + ".html";
                } else {
                    modifiedURL = url;
                }
                return modifiedURL;
    }

}
