package com.jh.jhas.core.constants;

public class EmailConstants {

	public static final String CONFIG_EMAIL_TEMPLATE_PATH				= "jhas.email.template.path";
	public static final String CONFIG_EMAIL_TO							= "jhas.email.to";
	public static final String CONFIG_CC_EMAIL							= "jhas.email.cc";
	public static final String CONFIG_SUBJECT_EMAIL						= "jhas.email.subject";
	public static final String CONFIG_CONTACTUSERROR_CLAIM_TO_EMAIL		= "contactuserror.claimpackage.to.email";
	public static final String CONFIG_CONTACTUSERROR_INCOME_TO_EMAIL	= "contactuserror.verificationincome.to.email";
	public static final String CONFIG_CONTACTUSERROR_DUPLICATE_TO_EMAIL	= "contactuserror.duplicatetaxform.to.email";
	public static final String CONFIG_CONTACTUSERROR_CC_EMAIL			= "contactuserror.cc.email";
	public static final String CONFIG_CONTACTUS_FALLBACK				= "contactus.fallback.password";
	public static final String CONFIG_EMAIL_API_URL						= "jhas.email.api";
	public static final String CONFIG_EMAIL_API_USERNAME				= "jhas.email.api.username";
	public static final String CONFIG_EMAIL_API_PWD						= "jhas.email.api.password";
	public static final String CONFIG_DTM_URL							= "dtm.url";
	public static final String CONFIG_SITE_DOMAIN_URL					= "site.domain.url"; 
	public static final String CONFIG_SITEMAP_CACHE_PATH				= "sitemap.cache.path";
	public static final String CONFIG_INVALIDATE_SERVER_URL				= "invalidate.server.url";
	public static final String CONFIG_NOINDEX_TEXT						= "noindex.text";
	public static final String CONFIG_CONTACTUS_PATH					= "contactus.path";
	public static final String CONFIG_GOOGLE_CAPTCHA_SITEKEY			= "google.captcha.sitekey";
	public static final String CONFIG_GOOGLE_CAPTCHA_SERVERKEY			= "google.captcha.secretkey";
	public static final String CONFIG_GOOGLE_CAPTCHA_SERVICEURL			= "google.captcha.serviceurl";
	public static final String CONFIG_ERROR_TEMPLATE_PATH				= "jhas.email.error.path";
	public static final String CONFIG_CONTACTUS_ERROR_TEMPLATE_PATH	= "jhas.contactus.error.template";
	public static final String CONFIG_ERROR_TO_EMAIL					= "jhas.contactus.error.toAddress";
	public static final String CONFIG_ERROR_CC_EMAIL					= "error.cc.email";
	public static final String CONFIG_EMAIL_CONTACTUS_MESSAGE			= "jhas.email.message";
	public static final String CONFIG_EMAIL_REDIRECT_PATH				= "jhas.email.redirectpath";
	public static final String CONFIG_EMAIL_NAME						= "jhas.email.name";
	public static final String CONFIG_EMAIL_ADDRESS						= "jhas.email.emailAddress";
	public static final String CONFIG_ENVIRONMENT						= "jhas.environment";
	public static final String CONFIG_SITE_DOMAIN                       = "site.domain.url";
	public static final String EMAIL_DATE								= "date";
	public static final String EMAIL_TO_ADDRESS                         = "jhas.contactus.toaddress";
	
	
	public static final String EMAIL_CONTACTUS_PHONE					= "phone";
	public static final String EMAIL_CONTACTUS_EXTENSION				= "extension";
	public static final String EMAIL_CONTACTUS_CITY						= "city";
	public static final String EMAIL_CONTACTUS_STATE					= "state";
	public static final String EMAIL_CONTACTUS_CUSTOMER_TYPE			= "customerType";
	public static final String EMAIL_CONTACTUS_ANN_CONTRACT_NUMBER		= "annuityContractNumber";
	public static final String EMAIL_CONTACTUS_CUSTOMER_NUMBER			= "customerNumber";
	public static final String EMAIL_CONTACTUS_INQUIRY_TYPE				= "inquiry";
	public static final String EMAIL_CONTACTUS_RESOURCE_PATH			= "resPath";
	
	public static final String EMAIL_CONTACTUS_FALLBACK					= "fallback";
	public static final String EMAIL_JHAS_TOKEN_URL				        = "token";
	public static final String EMAIL_JHAS_SEND_URL 				        = "send";
	public static final String EMAIL_ENVIRONMENT_INFO					= "environment";

	public static final String G_RECAPTCHA_RESPONSE						= "g-recaptcha-response";
	public static final String SECRET									= "secret";
	public static final String RESONSE									= "response";
	public static final String REMOTE_IP								= "remoteip";
	public static final String GOOGLE_SEARCH_API_URL					= "https://www.google.com/recaptcha/api/siteverify";
	public static final String TRUE										= "true";
	public static final String FALSE									= "false";
	public static final String HYPHEN									= "-";
	public static final String UTF_CHARSET								= "UTF-8";
	public static final String SEND_MESSAGE_TEMPLATE				    ="jhas.digitalEmail.template.sendMessage";
	public static final String APPROVE_WORKFLOW_TEMPLATE				="jhas.digitalEmail.template.approveWorkflow";
	public static final String REJECT_WORKFLOW_TEMPLATE					="jhas.digitalEmail.template.rejectWorkflow";
	public static final String EMAIL_FORM_TEMPLATE						="jhas.digitalEmail.template.dynamicForm";
	public static final String PROPERTY_FORM_TEMPLATE                   ="jhas.digitalEmail.template.propertyForm";
	public static final String PROPERTY_FORM_ERROR_TEMPLATE				="/apps/settings/wcm/designs/JHAS/email-templates/propertyformerroremailtemplate.html";
	public static final String EMAIL_FORM_ERROR_TEMPLATE				="/apps/settings/wcm/designs/JHAS/email-templates/dynamicformerrortemplate.html";
	public static final String CONFIG_DUMMY_HTTPS 						= "jhas.email.api.dummycert.https";
	public static final String CONFIG_DIGITALEMAIL_APIID 				= "jhas.digitalEmail.apiId";
	public static final String CONFIG_DIGITALEMAIL_APIKEY 				= "jhas.digitalEmail.apikey";
	public static final String CONFIG_DIGITALEMAIL_APIVALUE 			= "jhas.digitalEmail.apiValue";
	public static final String CONFIG_DIGITALEMAIL_APIURL 				= "jhas.digitalEmail.apiUrl";
								
}
