package com.jh.jhas.core.utility;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.jh.jhas.core.headernavigation.dto.HeaderNavItem;

public class HeaderNavGenerator {
    private static Logger LOG = LoggerFactory.getLogger(HeaderNavGenerator.class);

    public static List<HeaderNavItem> getTopNavList(ResourceResolver resourceResolver, String topNavPath) {
	LOG.info("-- Entering HeaderNavGenerator getTopNavList --");
	List<HeaderNavItem> topHeaderNavs = new ArrayList<HeaderNavItem>();
	int currentLevel = 1;
	Page topNavItemPage = resourceResolver.getResource(topNavPath).adaptTo(Page.class);
	if (null != topNavItemPage) {
	    // Add Top Navigation Page and Vanity Pages as Next < Sub > Pages
	    HeaderNavItem topItem = new HeaderNavItem();
	    setNavItemProperties(topNavItemPage, "", topItem, currentLevel);
	    topHeaderNavs.add(topItem);
	    // Check for next level pages
	    setSubNavigationPages(resourceResolver, topNavItemPage, currentLevel, topItem, topHeaderNavs);
	    topHeaderNavs.addAll(getVanityPages(resourceResolver, topNavItemPage, topItem.getLevelId(), currentLevel));
	}

	return topHeaderNavs;
    }

    private static void setSubNavigationPages(ResourceResolver resourceResolver, Page prevNavItemPage, int previousLevel, HeaderNavItem parentNavItem, List<HeaderNavItem> topHeaderNavs) {
	LOG.info("-- Entering HeaderNavGenerator setSubNavigationPages --");
	if (null != prevNavItemPage.listChildren()) {
	    int currentLevel = previousLevel+1;
	    Iterator<Page> subNavIterator = prevNavItemPage.listChildren();
	    while (subNavIterator.hasNext()) {
		HeaderNavItem subNavItem = new HeaderNavItem();
		Page subNavItemPage=subNavIterator.next();
		setNavItemProperties(subNavItemPage, parentNavItem.getLevelId(), subNavItem, currentLevel);
		topHeaderNavs.add(subNavItem);
		if(currentLevel<5) {
		    setSubNavigationPages(resourceResolver, subNavItemPage, currentLevel, subNavItem, topHeaderNavs);
		}
		topHeaderNavs.addAll(getVanityPages(resourceResolver, subNavItemPage, subNavItem.getLevelId(), currentLevel));
	    }
	}

    }

    private static List<HeaderNavItem> getVanityPages(ResourceResolver resourceResolver, Page currentPage, String parentLevelId, int currentLevel) {
	List<HeaderNavItem> vanityHeaderNavList = new ArrayList<HeaderNavItem>();
	if (null != currentPage && currentLevel<4) {
	    Node resourceNode = resourceResolver.getResource(currentPage.getPath()).adaptTo(Node.class);
	    try {
		if (resourceNode.hasNode("jcr:content")) {
		    Node jcrNode = resourceNode.getNode("jcr:content");
		    if (jcrNode.hasNode("properties")) {
		    	String subVanityPath=null;
			final NodeIterator nodeIterator = jcrNode.getNode("properties").getNodes();
			while (nodeIterator.hasNext()) {
			    final Node childNode = (Node) nodeIterator.next();
			    HeaderNavItem headerVanityItem = new HeaderNavItem();
			    if (childNode.hasProperty("vanityPageTitle") && null != childNode.getProperty("vanityPageTitle").getString()) {
				String title= childNode.getProperty("vanityPageTitle").getString();
			    headerVanityItem.setNavTitle(title);
			    }
			    if (childNode.hasProperty("vanityPath") && null != childNode.getProperty("vanityPath").getString()) {
				headerVanityItem.setNavURL(LinkChecker.getInternalPath(childNode.getProperty("vanityPath").getString()));
				subVanityPath=childNode.getProperty("vanityPath").getString();
				// Production Fix Phase 2
				if(subVanityPath.lastIndexOf('/') > -1) {
					headerVanityItem.setNavPageName(subVanityPath.substring(subVanityPath.lastIndexOf('/')+1));
				}
				if(subVanityPath.equalsIgnoreCase("#")){
					subVanityPath=currentPage.getPath();
				}
			    }
			    headerVanityItem.setParentLevelId(parentLevelId);
			    headerVanityItem.setNavLevel(Integer.toString(currentLevel + 1));
			    headerVanityItem.setLevelId(UUID.randomUUID() + currentPage.getName() + Integer.toString(currentLevel));
			    vanityHeaderNavList.add(headerVanityItem);
			    if(null!=subVanityPath){
			    Page vanityPage=resourceResolver.getResource(subVanityPath).adaptTo(Page.class); 
			    setVanityPages(resourceResolver, vanityPage, currentLevel, headerVanityItem, vanityHeaderNavList);
			    }
			    }
			
		    }
		    
		}
	    } catch (RepositoryException e) {
		LOG.error("-- Encounter Repository Exception fetching properties --");
	    }
	}
	return vanityHeaderNavList;

    }
    private static void setVanityPages(ResourceResolver resourceResolver, Page prevVanityItemPage, int previousVanityLevel, HeaderNavItem parentVanityItem, List<HeaderNavItem> vanityHeaderNavList) {
    	LOG.info("-- Entering HeaderNavGenerator setVanityPages --");
    	previousVanityLevel=previousVanityLevel+1;
    	if (null != prevVanityItemPage.listChildren()) {
    		int currentLevel = previousVanityLevel+1;
    		Iterator<Page> subVanityIterator = prevVanityItemPage.listChildren();
    		while(subVanityIterator.hasNext()){
    			HeaderNavItem subVanityItem = new HeaderNavItem();
    			Page subVanityItemPage=subVanityIterator.next();
    			setNavItemProperties(subVanityItemPage, parentVanityItem.getLevelId(), subVanityItem, currentLevel);
    			vanityHeaderNavList.add(subVanityItem);
    			if(currentLevel<4) {
    				setVanityPages(resourceResolver, subVanityItemPage, currentLevel, subVanityItem, vanityHeaderNavList);
    			}
    		}
    	}
    	
    	}

    private static void setNavItemProperties(Page currentPage, String parentLevelId, HeaderNavItem navItem, int currentLevel) {
	LOG.info("-- Entering setNavItemProperties --");
	if(null!=currentPage.getTitle()){
		navItem.setNavTitle(currentPage.getTitle());
	} else {
		navItem.setNavTitle(currentPage.getName());
	}
	navItem.setNavPageName(currentPage.getName());
	navItem.setNavURL(LinkChecker.getInternalPath(currentPage.getPath()));
	navItem.setNavLevel(Integer.toString(currentLevel));
	navItem.setLevelId(UUID.randomUUID() + currentPage.getName() + Integer.toString(currentLevel));
	navItem.setParentLevelId(parentLevelId);
	LOG.info("-- Values -- : "+navItem.getLevelId()+"_"+navItem.getNavTitle()+"_"+navItem.getParentLevelId()+"_");
    }
}
