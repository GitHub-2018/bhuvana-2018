package com.jh.jhas.core.workflow;

import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.dam.api.Asset;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.jh.jhas.core.WorkflowServicesHelper;
@Component(immediate = true,metatype = true)
@Service
@Properties({
	@Property(name = "service.description", value ="Process for JHAS Workflow Page Activation"),
	@Property(name = "service.vendor", value = "JHAS"),
	@Property(name = "process.label", value = "JHAS Page Activation Service")    
})

public class JHASPageActivationService implements WorkflowProcess{


	@Reference
	private ResourceResolverFactory resolverFactory;
	private final Logger LOG = LoggerFactory.getLogger(getClass());
	@Reference
	private Replicator replicator;
	@Override
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {
		Map<String,Object> paramMap=new HashMap<>();
		paramMap.put(ResourceResolverFactory.SUBSERVICE, "JHASPageActivationService");
		Session session					  = null; 
		ResourceResolver resourceResolver = null;
		try {
			WorkflowData workflowData = workItem.getWorkflowData();
			String payloadPath = workflowData.getPayload().toString();
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			session = resourceResolver.adaptTo(Session.class);
			Resource resource = resourceResolver.getResource(payloadPath+"/"+JcrConstants.JCR_CONTENT);
			

			//Fetching dialog values to the page properties
		
			MetaDataMap widgetValues = workItem.getMetaDataMap();
			String historyPath=widgetValues.get("historyEntryPath").toString();
			Resource metadataResource = resourceResolver.getResource(historyPath+"/workItem/metaData");
			LOG.info("HistoryPath-->"+historyPath);
			Node metadataNode= metadataResource.adaptTo(Node.class);
			String complianceNumber =metadataNode.hasProperty("wfmliNo")?metadataNode.getProperty("wfmliNo").getValue().toString():"";
			LOG.info("compliance-->>"+complianceNumber);
			//Set dialog values to the page properties
			Node pageNode=resource.adaptTo(Node.class);
			if(StringUtils.isNotBlank(complianceNumber)) {
				pageNode.setProperty("mliNo", complianceNumber);
			}
			// Set approver id on page
			Resource userdataResource = resourceResolver.getResource(historyPath);
			Node userdataNode= userdataResource.adaptTo(Node.class);
			pageNode.setProperty("pageApprover", userdataNode.getProperty("user").getValue());
			session.save();
			
			// Activate DAM assets on Page
			
			Map<String,Asset> assets = WorkflowServicesHelper.getReferencesInPage(resource,resourceResolver);
			for(Map.Entry<String, Asset> asset : assets.entrySet()) { 
				replicator.checkPermission(session, ReplicationActionType.ACTIVATE, asset.getKey());
				replicator.replicate(session, ReplicationActionType.ACTIVATE, asset.getKey());
			}
			
			// Activate the Page
			
			replicator.replicate(session, ReplicationActionType.ACTIVATE, payloadPath);
			session.save();
			session.refresh(true);
			
		}catch(Exception e){
			LOG.error("Error in "+getClass().getName(),e);
		} finally {
			// ALWAYS close the sessions you open
			if (session != null && session.isLive()) {
				session.logout();
			}
			// ALWAYS close resolvers you open
			if (resourceResolver != null) {
				resourceResolver.close();
			}
		}

	}
}