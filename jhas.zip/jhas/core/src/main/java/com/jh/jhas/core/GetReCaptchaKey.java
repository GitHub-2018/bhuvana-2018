package com.jh.jhas.core;

import com.adobe.cq.sightly.WCMUsePojo;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.utility.ConfigUtil;

public class GetReCaptchaKey extends WCMUsePojo{
    private String reCaptchaKey;

    @Override
    public void activate() throws Exception {
	reCaptchaKey = ConfigUtil.INSTANCE.getStringConfiguration(GlobalConstants.CONFIG_GOOGLEAPI_RECAPTCHA_SITEKEY);
    }

    public String getReCaptchaKey() {
        return reCaptchaKey;
    }
    public void setReCaptchaKey(String reCaptchaKey) {
        this.reCaptchaKey = reCaptchaKey;
    }
}
