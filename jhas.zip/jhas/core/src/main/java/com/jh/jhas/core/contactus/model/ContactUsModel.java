package com.jh.jhas.core.contactus.model;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import com.adobe.acs.commons.genericlists.GenericList;
import com.adobe.acs.commons.genericlists.GenericList.Item;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhas.core.constants.GlobalConstants;

@Model(adaptables = SlingHttpServletRequest.class)
public class ContactUsModel {
		
	public List<Item> topicList;
	
	@Inject
	SlingHttpServletRequest request;

	
	
	@PostConstruct
	protected void init() throws Exception {
		getTopicList();
	}
		
	public List<Item> getTopicList() {
		ResourceResolver resourceResolver=request.getResourceResolver();
		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
	    Page listPage = pageManager.getPage(GlobalConstants.CONTACT_US_TOPIC_PATH);
	    GenericList list = listPage.adaptTo(GenericList.class);
	    topicList=list.getItems();
	    return topicList;
	}
	
}
