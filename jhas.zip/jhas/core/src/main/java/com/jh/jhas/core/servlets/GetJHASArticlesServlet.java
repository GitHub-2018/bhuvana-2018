package com.jh.jhas.core.servlets;

import java.io.IOException;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.newsarticles.dto.Article;
import com.jh.jhas.core.newsarticles.dto.NewsArticles;
import com.jh.jhas.core.service.JHASArticlesService;

@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({@Property(name = "service.description", value = "JHAS Article Servlet"),
	@Property(name = "sling.servlet.paths", value = {"/bin/sling/getjhasarticles"}),
	@Property(name = "sling.servlet.methods", value = "GET", propertyPrivate = true)})

public class GetJHASArticlesServlet extends SlingSafeMethodsServlet {

	private static Logger LOG = LoggerFactory.getLogger(GetJHASArticlesServlet.class);
	private static final long serialVersionUID = 1L;

	@Reference
	JHASArticlesService jhasArticles;

	public GetJHASArticlesServlet() {
		super();
	}
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,
	IOException {
		JSONArray articletArray = new JSONArray();
		JSONObject resultObj = new JSONObject();
		JSONObject articleObj = null;
		NewsArticles jhasNewsArticles = new NewsArticles();

		try {
			String dynamicNodePath = request.getParameter("dynamicnodepath");
			String manualNodePath = request.getParameter("manualnodepath");
			if (StringUtils.isNotBlank(dynamicNodePath)) {
				final Resource resource = request.getResourceResolver().getResource(dynamicNodePath);
				Node resourceNode = resource.adaptTo(Node.class);
				if (null != resourceNode) {
					if (resourceNode.hasProperty("selectView")) {
						String view = resourceNode.getProperty("selectView").getValue().toString();
						// view option
						resultObj.put("view", view);
						// toggle option
						String toggle = "FALSE";
						if (resourceNode.hasProperty("toggle")) {
							toggle = resourceNode.getProperty("toggle").getValue().toString();
						}
						resultObj.put("toggle", toggle);
						// view all option
						if (resourceNode.hasProperty("disableViewAll")) {
							String disableViewAll = resourceNode.getProperty("disableViewAll").getValue().toString();
							resultObj.put("disableViewAll", disableViewAll);
						} else {
							resultObj.put("disableViewAll", "FALSE");
						}
						// enable filter option
						if (resourceNode.hasProperty("enableFilter")) {
							String enableFilter = resourceNode.getProperty("enableFilter").getValue().toString();
							resultObj.put("enableFilter", enableFilter);

						} else {
							resultObj.put("enableFilter", "FALSE");
						}
						// Add Article to jSON object
						jhasNewsArticles.setArticles(jhasArticles.getDynamicArticles(resourceNode, request));
						List < Article > articleLists = jhasNewsArticles.getArticles();
						for (Article item:articleLists) {
							if(!isArticlePresent(item,articletArray)) {
								articleObj = new JSONObject();
								JSONArray tags = new JSONArray();
								articleObj.put("title",item.getTitle());
								articleObj.put("pageName", item.getPageName());
								tags.put(item.getTags());
								articleObj.put("tags",tags);
								articleObj.put("external", item.getExternal());
								articleObj.put("url", item.getPath());
								// Tile specific Options
								if (!StringUtils.equals(toggle, "FALSE") || StringUtils.equals(view, "tile")) {
									if (resourceNode.hasProperty("tileAuthor")) {
										articleObj.put("author", item.getAuthor());
									}
									if (resourceNode.hasProperty("tileThumbnail")) {
										articleObj.put("imgurl", item.getImage());
									}
									if (resourceNode.hasProperty("tileDate")) {
										articleObj.put("publishedDate", item.getPublishedDate());
										articleObj.put("modifiedDate", item.getModifiedDate());
									}
									if (resourceNode.hasProperty("tileDescription")) {
										articleObj.put("desc", item.getSummary());
									}
								}
								articletArray.put(articleObj);
							}
						}
						resultObj.put("articles", articletArray);
					}
				}
			} else if(StringUtils.isNotBlank(manualNodePath)) {
				final Resource resource = request.getResourceResolver().getResource(manualNodePath);
				Node resourceNode = resource.adaptTo(Node.class);
				if (null != resourceNode) {
					if (resourceNode.hasProperty("layout")) {
						String view = resourceNode.getProperty("layout").getValue().toString();
						// view option
						resultObj.put("view", view);
						// toggle option
						String toggle = "FALSE";
						if (resourceNode.hasProperty("toggle")) {
							toggle = resourceNode.getProperty("toggle").getValue().toString();
						}
						resultObj.put("toggle", toggle);
						// Add Article to jSON object
						jhasNewsArticles.setArticles(jhasArticles.getManualArticles(resourceNode, request));
						List < Article > articleLists = jhasNewsArticles.getArticles();
						for (Article item:articleLists) {
							if(!isArticlePresent(item,articletArray)) {
								articleObj = new JSONObject();
								JSONArray tags = new JSONArray();
								articleObj.put("title",item.getTitle());
								articleObj.put("pageName", item.getPageName());
								tags.put(item.getTags());
								articleObj.put("tags",tags);
								articleObj.put("external", item.getExternal());
								articleObj.put("url", item.getPath());
								// Tile specific Options
								if (!StringUtils.equals(toggle, "FALSE") || StringUtils.equals(view, "tile")) {

									if (resourceNode.hasProperty("author")) {
										articleObj.put("author", item.getAuthor());
									}
									if (resourceNode.hasProperty("thumbnail")) {
										articleObj.put("imgurl", item.getImage());
									}
									if (resourceNode.hasProperty("date")) {
										articleObj.put("publishedDate", item.getPublishedDate());
										articleObj.put("modifiedDate", item.getModifiedDate());
									}
									if (resourceNode.hasProperty("description")) {
										articleObj.put("desc", item.getSummary());
									}
								}
								articletArray.put(articleObj);
							}
						}
						resultObj.put("articles", articletArray);
					}
				}
			}
		}
		catch(ValueFormatException e) {
			LOG.error("Exception in GetJHASArticlesServlet :"+ e);
		} catch(RepositoryException e) {
			LOG.error("Exception in GetJHASArticlesServlet :"+ e);
		}
		catch(JSONException e) {
			LOG.error("Exception in GetJHASArticlesServlet :"+ e);
		}
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(resultObj.toString());

	}

	/**
	 * Checks if dynamic article is present in JSON Array.
	 *
	 * @param fetchedArticle the fetched article
	 * @param articletArray the articlet array
	 * @return true, if is article present
	 */
	private boolean isArticlePresent(Article fetchedArticle, JSONArray articletArray) {
		for (int i = 0; i < articletArray.length(); ++i) {
			try {
				JSONObject currentArticle = articletArray.getJSONObject(i);
				if(fetchedArticle.getPath().equals(currentArticle.getString("url"))) {
					currentArticle.getJSONArray("tags").put(fetchedArticle.getTags());
					return true;
				}
			} catch (JSONException e) {
				LOG.error("Exception in GetDynamicArticlesServlet :"+ e);
			}
			// ...
		}
		return false;
	}
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,
	IOException {
		doGet(request, response);
	}

}
