package com.jh.jhas.core;

import java.util.ArrayList;
import java.util.Collections;

import javax.jcr.Node;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;

import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.models.BreadCrumbItems;

public class Breadcrumb extends WCMUsePojo {

    private ArrayList<BreadCrumbItems> pages = new ArrayList<BreadCrumbItems>();
    private Logger Log = LoggerFactory.getLogger(Breadcrumb.class);
    private Boolean isEditableTemplate = false;
    private String pagepath;

    public void activate() throws Exception {
        final ArrayList<BreadCrumbItems> childPages = new ArrayList<BreadCrumbItems>();
        String startPageLevel = getProperties().get("startPageLevel", "1");

        int startPageLevelValue = Integer.parseInt(startPageLevel);
        if (startPageLevelValue < 1) {
            startPageLevelValue = 1;
        }
        String endPageLevel = getProperties().get("endPageLevel", Integer.toString(getCurrentPage().getDepth()));
        int endPageLevelValue = Integer.parseInt(endPageLevel);
        final int currentPageDepth = getCurrentPage().getDepth();
        if (endPageLevelValue >= currentPageDepth) {
            endPageLevelValue = currentPageDepth - 1;
        }
        String updateLink;
        pagepath = getCurrentPage().getPath();
        if (pagepath.startsWith("/conf")) {
            isEditableTemplate = true;
            Log.info("The request is from template");
            String resourcePath = ResourceUtil.getParent(getCurrentPage().getPath());
            Resource templateResource = getResourceResolver().getResource(resourcePath);
            Log.info("resource  is" + resourcePath);
            if (null != templateResource) {
                BreadCrumbItems tbreadCrumbItem = new BreadCrumbItems();
                Log.info("resource is not null");

                Node resourceNode = templateResource.adaptTo(Node.class);

                tbreadCrumbItem.setTitle(resourceNode.getName());
                Log.info("templatetitle is" + tbreadCrumbItem.getTitle());
                childPages.add(tbreadCrumbItem);
                this.pages = childPages;
            }
        } else {
            for (int currentLevel = startPageLevelValue; currentLevel <= endPageLevelValue; currentLevel++) {
                BreadCrumbItems breadCrumbItems = new BreadCrumbItems();

                String resourcePath = ResourceUtil.getParent(getCurrentPage().getPath(), currentLevel - 1);
                Resource resource = getResourceResolver().getResource(resourcePath);

                if (resource != null) {
                    Node resourceNode = resource.adaptTo(Node.class);
                    if (resourceNode.getProperty(GlobalConstants.JCR_PRIMARY_TYPE).getValue().toString()
                            .equals(GlobalConstants.FOLDER_TYPE)) {
                        breadCrumbItems.setTitle(resourceNode.getName());
                        breadCrumbItems.setHyperLink("yes");
                    } else {

                        Page absoluteParentPage = resource.adaptTo(Page.class);
                        updateLink = absoluteParentPage.getPath();
                        int currentPageLevel = currentLevel - 1;
                        if (currentPageLevel == 0) {
                            breadCrumbItems.setHyperLink("yes");
                        }
                        Log.info("Absolute Parent Level : " + currentLevel);
                        Log.info("Absolute Parent Level URL : " + updateLink);
                        Log.info("Absolute Parent Level Title : " + updateLink);

                        breadCrumbItems.setPath(updateLink);
                        breadCrumbItems.setTitle(absoluteParentPage.getTitle());
                        String jcrNodepath = updateLink.concat("/jcr:content");
                        Node JcrNode = getResourceResolver().getResource(jcrNodepath).adaptTo(Node.class);

                        if (JcrNode.hasProperty("hyperLink")) {

                            String checkValue = JcrNode.getProperty("hyperLink").getString();
                            Log.info("checkValue Fetch" + checkValue);
                            breadCrumbItems.setHyperLink(checkValue);
                        }

                    }

                    childPages.add(breadCrumbItems);
                    startPageLevelValue++;
                }
                this.pages = childPages;
            }
        }
    }

    public ArrayList<BreadCrumbItems> getPages() {
        if (!isEditableTemplate) {
            for (BreadCrumbItems breadCrumbItem : pages) {
                Log.info("Page Path " + breadCrumbItem.getPath());
                Log.info("Page Title " + breadCrumbItem.getTitle());
                Log.info("Page HyperLink " + breadCrumbItem.getHyperLink());
            }
            Collections.reverse(pages);
            return pages;
        } else {
            Log.info("pages" + pages);
            return pages;
        }
    }

}