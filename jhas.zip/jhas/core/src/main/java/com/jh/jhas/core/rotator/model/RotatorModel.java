package com.jh.jhas.core.rotator.model;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.rotator.dto.RotatorBanner;
import com.jh.jhas.core.rotator.dto.RotatorMain;



@Model(adaptables=SlingHttpServletRequest.class)
public class RotatorModel {

	private Logger LOG = LoggerFactory.getLogger(RotatorModel.class);
	public RotatorMain rotatorMain;
	private static final String LAYOUT_1="Layout1 (with full width image/video and text box)";
	private static final String LAYOUT_2="Layout2 (with inset image/video and textbox)";
	private static final String LAYOUT_1_BACKGROUND_IMAGE="Banner with Background Image";
	private static final String LAYOUT_1_BACKGROUND_COLOR="Banner with Background Color";
	private static final String LAYOUT_1_BACKGROUND_VIDEO="Banner with Background Video";
	private static final String LAYOUT_2_BACKGROUND_IMAGE="Banner with Background Image";
	private static final String LAYOUT_2_BACKGROUND_COLOR="Banner with Background Color";
	private static final String LAYOUT_2_BACKGROUND_GRADIENT="Banner with Background Gradient";
	private static final String LAYOUT_2_BACKGROUND_VIDEOOVERLAY="Banner with background Image/Color/Gradient and video overlay";
	
	
	
	@Inject
	SlingHttpServletRequest request;
		
	@Inject
	private String path;
	
	@PostConstruct
	protected void init(){
		final Resource resource = request.getResourceResolver().getResource(path);
		rotatorMain=new RotatorMain();
		rotatorMain.setBannerList(getBannerList(resource));
	}
	
	private List<RotatorBanner> getBannerList(Resource resource){
		LOG.info("LAYOUT_2"+LAYOUT_2);
		List<RotatorBanner> bannerList= new ArrayList<RotatorBanner>();
		final Node resourceNode = resource.adaptTo(Node.class);
		RotatorBanner rotatorBanner = null;
		Value [] bannerLayout1Array = null;
		Value singleBannerLayout1 = null;		
		Value [] bannerLayout2Array = null;
		Value singleBannerLayout2 = null;
		Value [] imageUrlLayout1Array = null;
		Value singleImageUrlLayout1 = null;		
		Value [] colorLayout1Array = null;
		Value singleColorLayout1 = null;
		Value [] videoSourceLayout1Array = null;
		Value singleVideoSourceLayout1 = null;
		Value [] videoUrlLayout1Array = null;
		Value singleVideoUrlLayout1 = null;
		Value [] urlLinkLayout1Array = null;
		Value singleUrlLinkLayout1 = null;
		Value [] openoptionsLayout1Array = null;
		Value singleopenoptionsLayout1 = null;
		Value [] imageurlLayout2Array = null;
		Value singleImageurlLayout2 = null;
		Value [] urllinkimageLayout2Array = null;
		Value singleUrllinkimageLayout2 = null;
		Value [] openoptionsLayout2Array = null;
		Value singleopenoptionsLayout2 = null;
		Value [] insetImageLayout2ImageArray=null;
		Value singleinsetImageLayout2Image=null;
		Value [] insetVideoLayout2ImageArray=null;
		Value singleInsetVideoLayout2Image=null;
		Value [] colorLayout2Array = null;
		Value singlecolorLayout2 = null;
		Value [] insetImageLayout2ColorArray=null;
		Value singleInsetImageLayout2Color=null;
		Value [] insetVideoLayout2ColorArray=null;
		Value singleInsetVideoLayout2Color=null;
		Value [] color1Layout2Array = null;
		Value singlecolor1Layout2 = null;
		Value [] color2Layout2Array = null;
		Value singlecolor2Layout2 = null;
		Value [] insetImageLayout2GradientArray=null;
		Value singleInsetImageLayout2Gradient=null;
		Value [] insetVideoLayout2GradientArray=null;
		Value singleInsetVideoLayout2Gradient=null;
		Value [] videooverlayimageURLArray = null;
		Value singlevideooverlayimageURL = null;
		Value [] videooverlayColorArray = null;
		Value singlevideooverlayColor = null;
		Value [] videooverlayColor1Array = null;
		Value singlevideooverlayColor1 = null;
		Value [] videooverlayColor2Array = null;
		Value singlevideooverlayColor2 = null;
		Value [] videooverlayvideoURLArray = null;
		Value singlevideooverlayvideoURL = null;
		Value [] alignHorizontalArray = null;
		Value singleAlignhorizontal = null;
		Value [] alignVerticalArray = null;
		Value singleAlignvertical = null;
		
		int counter = 0;
		LOG.info("Counter"+counter);
		try {
			/*if(resourceNode.hasProperty("bannerlayout1")){
				if (resourceNode.getProperty("bannerlayout1").isMultiple()) {
					bannerLayout1Array = resourceNode.getProperty("bannerlayout1").getValues();
				} else {
					singleBannerLayout1 = resourceNode.getProperty("bannerlayout1").getValue();
				}
				LOG.info("bannerlayout1 in rotator node"+bannerLayout1Array+singleBannerLayout1);
			}
			if(resourceNode.hasProperty("bannerlayout2")){
				if (resourceNode.getProperty("bannerlayout2").isMultiple()) {
					bannerLayout2Array = resourceNode.getProperty("bannerlayout2").getValues();
				} else {
					singleBannerLayout2 = resourceNode.getProperty("bannerlayout2").getValue();
				}
				LOG.info("bannerlayout2 in rotator node"+bannerLayout2Array+singleBannerLayout2);
				
			}
			
			if(resourceNode.hasProperty("imageurlLayout1")){
				if (resourceNode.getProperty("imageurlLayout1").isMultiple()) {
					imageUrlLayout1Array = resourceNode.getProperty("imageurlLayout1").getValues();
				} else {
					singleImageUrlLayout1 = resourceNode.getProperty("imageurlLayout1").getValue();
				}
			}
			if(resourceNode.hasProperty("colorLayout1")){
				if (resourceNode.getProperty("colorLayout1").isMultiple()) {
					colorLayout1Array = resourceNode.getProperty("colorLayout1").getValues();
				} else {
					singleColorLayout1 = resourceNode.getProperty("colorLayout1").getValue();
				}
			}
			if(resourceNode.hasProperty("videourlLayout1")){
				if (resourceNode.getProperty("videourlLayout1").isMultiple()) {
					videoUrlLayout1Array = resourceNode.getProperty("videourlLayout1").getValues();
				} else {
					singleVideoUrlLayout1 = resourceNode.getProperty("videourlLayout1").getValue();
				}
			}
			if(resourceNode.hasProperty("videosourceLayout1")){
				if (resourceNode.getProperty("videosourceLayout1").isMultiple()) {
					videoSourceLayout1Array = resourceNode.getProperty("videosourceLayout1").getValues();
				} else {
					singleVideoSourceLayout1 = resourceNode.getProperty("videosourceLayout1").getValue();
				}
			}
			if(resourceNode.hasProperty("urllinkLayout1")){
				if (resourceNode.getProperty("urllinkLayout1").isMultiple()) {
					urlLinkLayout1Array = resourceNode.getProperty("urllinkLayout1").getValues();
				} else {
					singleUrlLinkLayout1 = resourceNode.getProperty("urllinkLayout1").getValue();
				}
			}
			if(resourceNode.hasProperty("openoptionsLayout1")){
				if (resourceNode.getProperty("openoptionsLayout1").isMultiple()) {
					openoptionsLayout1Array = resourceNode.getProperty("openoptionsLayout1").getValues();
				} else {
					singleopenoptionsLayout1 = resourceNode.getProperty("openoptionsLayout1").getValue();
				}
			}
			if(resourceNode.hasProperty("imageurlLayout2")){
				if (resourceNode.getProperty("imageurlLayout2").isMultiple()) {
					imageurlLayout2Array = resourceNode.getProperty("imageurlLayout2").getValues();
				} else {
					singleImageurlLayout2 = resourceNode.getProperty("imageurlLayout2").getValue();
					
				}
			}
			if(resourceNode.hasProperty("urllinkimageLayout2")){
				if (resourceNode.getProperty("urllinkimageLayout2").isMultiple()) {
					urllinkimageLayout2Array = resourceNode.getProperty("urllinkimageLayout2").getValues();
				} else {
					singleUrllinkimageLayout2 = resourceNode.getProperty("urllinkimageLayout2").getValue();
				}
			}
			if(resourceNode.hasProperty("openoptionsLayout2")){
				if (resourceNode.getProperty("openoptionsLayout2").isMultiple()) {
					openoptionsLayout2Array = resourceNode.getProperty("openoptionsLayout2").getValues();
				} else {
					singleopenoptionsLayout2 = resourceNode.getProperty("openoptionsLayout2").getValue();
				}
			}
			if(resourceNode.hasProperty("insetImageLayout2Image")){
				if (resourceNode.getProperty("insetImageLayout2Image").isMultiple()) {
					insetImageLayout2ImageArray = resourceNode.getProperty("insetImageLayout2Image").getValues();
				} else {
					singleinsetImageLayout2Image = resourceNode.getProperty("insetImageLayout2Image").getValue();
				}
			}
			if(resourceNode.hasProperty("insetVideoLayout2Image")){
				if (resourceNode.getProperty("insetVideoLayout2Image").isMultiple()) {
					insetVideoLayout2ImageArray = resourceNode.getProperty("insetVideoLayout2Image").getValues();
				} else {
					singleInsetVideoLayout2Image = resourceNode.getProperty("insetVideoLayout2Image").getValue();
				}
			}
			if(resourceNode.hasProperty("colorLayout2")){
				if (resourceNode.getProperty("colorLayout2").isMultiple()) {
					colorLayout2Array = resourceNode.getProperty("colorLayout2").getValues();
				} else {
					singlecolorLayout2 = resourceNode.getProperty("colorLayout2").getValue();
				}
			}
			if(resourceNode.hasProperty("insetImageLayout2Color")){
				if (resourceNode.getProperty("insetImageLayout2Color").isMultiple()) {
					insetImageLayout2ColorArray = resourceNode.getProperty("insetImageLayout2Color").getValues();
				} else {
					singleInsetImageLayout2Color = resourceNode.getProperty("insetImageLayout2Color").getValue();
				}
			}
			if(resourceNode.hasProperty("insetVideoLayout2Color")){
				if (resourceNode.getProperty("insetVideoLayout2Color").isMultiple()) {
					insetVideoLayout2ColorArray = resourceNode.getProperty("insetVideoLayout2Color").getValues();
				} else {
					singleInsetVideoLayout2Color = resourceNode.getProperty("insetVideoLayout2Color").getValue();
				}
			}
			if(resourceNode.hasProperty("color1Layout2")){
				if (resourceNode.getProperty("color1Layout2").isMultiple()) {
					color1Layout2Array = resourceNode.getProperty("color1Layout2").getValues();
				} else {
					singlecolor1Layout2 = resourceNode.getProperty("color1Layout2").getValue();
				}
			}
			if(resourceNode.hasProperty("color2Layout2")){
				if (resourceNode.getProperty("color2Layout2").isMultiple()) {
					color2Layout2Array = resourceNode.getProperty("color2Layout2").getValues();
				} else {
					singlecolor2Layout2 = resourceNode.getProperty("color2Layout2").getValue();
				}
			}
			if(resourceNode.hasProperty("insetImageLayout2Gradient")){
				if (resourceNode.getProperty("insetImageLayout2Gradient").isMultiple()) {
					insetImageLayout2GradientArray = resourceNode.getProperty("insetImageLayout2Gradient").getValues();
				} else {
					singleInsetImageLayout2Gradient = resourceNode.getProperty("insetImageLayout2Gradient").getValue();
				}
			}
			if(resourceNode.hasProperty("insetVideoLayout2Gradient")){
				if (resourceNode.getProperty("insetVideoLayout2Gradient").isMultiple()) {
					insetVideoLayout2GradientArray = resourceNode.getProperty("insetVideoLayout2Gradient").getValues();
				} else {
					singleInsetVideoLayout2Gradient = resourceNode.getProperty("insetVideoLayout2Gradient").getValue();
				}
			}
			if(resourceNode.hasProperty("videooverlayimageURL")){
				if (resourceNode.getProperty("videooverlayimageURL").isMultiple()) {
					videooverlayimageURLArray = resourceNode.getProperty("videooverlayimageURL").getValues();
				} else {
					singlevideooverlayimageURL = resourceNode.getProperty("videooverlayimageURL").getValue();
				}
			}
			if(resourceNode.hasProperty("videooverlayColor")){
				if (resourceNode.getProperty("videooverlayColor").isMultiple()) {
					videooverlayColorArray = resourceNode.getProperty("videooverlayColor").getValues();
				} else {
					singlevideooverlayColor = resourceNode.getProperty("videooverlayColor").getValue();
				}
			}
			if(resourceNode.hasProperty("videooverlayColor1")){
				if (resourceNode.getProperty("videooverlayColor1").isMultiple()) {
					videooverlayColor1Array = resourceNode.getProperty("videooverlayColor1").getValues();
				} else {
					singlevideooverlayColor1 = resourceNode.getProperty("videooverlayColor1").getValue();
				}
			}
			if(resourceNode.hasProperty("videooverlayColor2")){
				if (resourceNode.getProperty("videooverlayColor2").isMultiple()) {
					videooverlayColor2Array = resourceNode.getProperty("videooverlayColor2").getValues();
				} else {
					singlevideooverlayColor2 = resourceNode.getProperty("videooverlayColor2").getValue();
				}
			}
			if(resourceNode.hasProperty("videooverlayvideoURL")){
				if (resourceNode.getProperty("videooverlayvideoURL").isMultiple()) {
					videooverlayvideoURLArray = resourceNode.getProperty("videooverlayvideoURL").getValues();
				} else {
					singlevideooverlayvideoURL = resourceNode.getProperty("videooverlayvideoURL").getValue();
				}
			}
			if(resourceNode.hasProperty("alignHorizontal")){
				if (resourceNode.getProperty("alignHorizontal").isMultiple()) {
					alignHorizontalArray = resourceNode.getProperty("alignHorizontal").getValues();
				} else {
					singleAlignhorizontal = resourceNode.getProperty("alignHorizontal").getValue();
				}
			}
			if(resourceNode.hasProperty("alignVertical")){
				if (resourceNode.getProperty("alignVertical").isMultiple()) {
					alignVerticalArray = resourceNode.getProperty("alignVertical").getValues();
				} else {
					singleAlignvertical = resourceNode.getProperty("alignVertical").getValue();
				}
			}*/
				
				
			
			if (resourceNode.hasNode("properties")) {

				final NodeIterator nodeIterator = resourceNode.getNode("properties").getNodes();

				while (nodeIterator.hasNext()) {

					rotatorBanner = new RotatorBanner();

					final Node childNode = (Node) nodeIterator.next();

					if(childNode.hasProperty("layout")){
						rotatorBanner.setLayout(childNode.getProperty("layout").getString());
					}
					if(childNode.hasProperty("bannerlayout1")){
						rotatorBanner.setBannerlayout1(childNode.getProperty("bannerlayout1").getString());
					}
					if(childNode.hasProperty("bannerlayout2")){
						rotatorBanner.setBannerlayout2(childNode.getProperty("bannerlayout2").getString());
					}
					if(childNode.hasProperty("imageurlLayout1")){
						rotatorBanner.setImageUrlLayout1(childNode.getProperty("imageurlLayout1").getString());
					}
					if(childNode.hasProperty("colorLayout1")){
						rotatorBanner.setColorLayout1(childNode.getProperty("colorLayout1").getString());
					}
					if(childNode.hasProperty("videourlLayout1")){
						rotatorBanner.setVideourlLayout1(childNode.getProperty("videourlLayout1").getString());
					}
					if(childNode.hasProperty("urllinkLayout1")){
						rotatorBanner.setUrllinkLayout1(childNode.getProperty("urllinkLayout1").getString());
					}
					if(childNode.hasProperty("openoptionsLayout1")){
						rotatorBanner.setOpenoptionsLayout1(childNode.getProperty("openoptionsLayout1").getString());
					}
					if(childNode.hasProperty("imageurlLayout2")){
						rotatorBanner.setImageurlLayout2(childNode.getProperty("imageurlLayout2").getString());
					}
					if(childNode.hasProperty("urllinkimageLayout2")){
						rotatorBanner.setUrllinkimageLayout2(childNode.getProperty("urllinkimageLayout2").getString());
					}
					if(childNode.hasProperty("openoptionsLayout2")){
						rotatorBanner.setOpenoptionsLayout2(childNode.getProperty("openoptionsLayout2").getString());
					}
					if(childNode.hasProperty("insetImageLayout2Image")){
						rotatorBanner.setInsetImageLayout2Image(childNode.getProperty("insetImageLayout2Image").getString());
					}
					if(childNode.hasProperty("insetVideoLayout2Image")){
						rotatorBanner.setInsetVideoLayout2Image(childNode.getProperty("insetVideoLayout2Image").getString());
					}
					if(childNode.hasProperty("colorLayout2")){
						rotatorBanner.setColorLayout2(childNode.getProperty("colorLayout2").getString());
					}
					if(childNode.hasProperty("insetImageLayout2Color")){
						rotatorBanner.setInsetImageLayout2Color(childNode.getProperty("insetImageLayout2Color").getString());
					}
					if(childNode.hasProperty("insetVideoLayout2Color")){
						rotatorBanner.setInsetVideoLayout2Color(childNode.getProperty("insetVideoLayout2Color").getString());
					}
					if(childNode.hasProperty("color1Layout2")){
						rotatorBanner.setColor1Layout2(childNode.getProperty("color1Layout2").getString());
					}
					if(childNode.hasProperty("color2Layout2")){
						rotatorBanner.setColor2Layout2(childNode.getProperty("color2Layout2").getString());
					}
					if(childNode.hasProperty("insetImageLayout2Gradient")){
						rotatorBanner.setInsetImageLayout2Gradient(childNode.getProperty("insetImageLayout2Gradient").getString());
					}
					if(childNode.hasProperty("insetVideoLayout2Gradient")){
						rotatorBanner.setInsetVideoLayout2Gradient(childNode.getProperty("insetVideoLayout2Gradient").getString());
					}
					if(childNode.hasProperty("insetImageLayout2Gradient")){
						rotatorBanner.setInsetImageLayout2Gradient(childNode.getProperty("insetImageLayout2Gradient").getString());
					}
														
					if(childNode.hasProperty("title")){
						rotatorBanner.setTitle(childNode.getProperty("title").getString());
					}
					if(childNode.hasProperty("textColor")){
						rotatorBanner.setTextColor(childNode.getProperty("textColor").getString());
					}
					if(childNode.hasProperty("textPlaceHorizontal")){
						rotatorBanner.setTextPlacementHorizontal(childNode.getProperty("textPlaceHorizontal").getString());
					}
					if(childNode.hasProperty("textPlaceVertical")){
						rotatorBanner.setTextPlacementVertical(childNode.getProperty("textPlaceVertical").getString());
					}
					if(childNode.hasProperty("description")){
						rotatorBanner.setDescription(childNode.getProperty("description").getString());
					}
					if(childNode.hasProperty("button")){
						rotatorBanner.setButton(childNode.getProperty("button").getString());
					}
					if(childNode.hasProperty("colorClass")){
						rotatorBanner.setColorClass(childNode.getProperty("colorClass").getString());
					}
					if(childNode.hasProperty("buttonCaption")){
						rotatorBanner.setButtonCaption(childNode.getProperty("buttonCaption").getString());
					}
					if(childNode.hasProperty("textboxPadding")){
						rotatorBanner.setTextboxPadding(childNode.getProperty("textboxPadding").getString());
					}
					if(childNode.hasProperty("fontColorClass")){
						rotatorBanner.setFontColorClass(childNode.getProperty("fontColorClass").getString());
					}
					if(childNode.hasProperty("textAlign")){
						rotatorBanner.setTextAlign(childNode.getProperty("textAlign").getString());
					}
					if(childNode.hasProperty("textboxColor")){
						rotatorBanner.setTextboxColor(childNode.getProperty("textboxColor").getString());
					}
					if(childNode.hasProperty("buttonLinkUrl")){
						rotatorBanner.setButtonLinkUrl(childNode.getProperty("buttonLinkUrl").getString());
					}
					if(childNode.hasProperty("openOptionsButton")){
						rotatorBanner.setButtonOpenOptions(childNode.getProperty("openOptionsButton").getString());
					}
					
					
					
					
					/*if(null != singleBannerLayout1) {
						rotatorBanner.setBannerlayout1(singleBannerLayout1.getString());
					} else {
						rotatorBanner.setBannerlayout1(getValueFromArray(bannerLayout1Array,counter));
					}
					if(null != singleBannerLayout2) {
						rotatorBanner.setBannerlayout2(singleBannerLayout2.getString());
					} else {
						rotatorBanner.setBannerlayout2(getValueFromArray(bannerLayout2Array,counter));
					}
					
					if(null != singleImageUrlLayout1) {
						rotatorBanner.setImageUrlLayout1(singleImageUrlLayout1.getString());
					} else {
						rotatorBanner.setImageUrlLayout1(getValueFromArray(imageUrlLayout1Array,counter));
					}	
					if(null!= singleColorLayout1){
						rotatorBanner.setColorLayout1(singleColorLayout1.getString());						
					} else {
						rotatorBanner.setColorLayout1(getValueFromArray(colorLayout1Array,counter));
					}
					if(null!= singleVideoUrlLayout1){
						rotatorBanner.setVideourlLayout1(singleVideoUrlLayout1.getString());						
					} else {
						rotatorBanner.setVideourlLayout1(getValueFromArray(videoUrlLayout1Array,counter));
					}
					if(null!= singleVideoSourceLayout1){
						rotatorBanner.setVideosourceLayout1(singleVideoSourceLayout1.getString());						
					} else {
						
						rotatorBanner.setVideosourceLayout1(getValueFromArray(videoSourceLayout1Array,counter));
					}
					if(null!= singleUrlLinkLayout1){
						rotatorBanner.setUrllinkLayout1(singleUrlLinkLayout1.getString());						
					} else {
						rotatorBanner.setUrllinkLayout1(getValueFromArray(urlLinkLayout1Array,counter));
					}
					if(null!= singleopenoptionsLayout1){
						rotatorBanner.setOpenoptionsLayout1(singleopenoptionsLayout1.getString());						
					} else {
						rotatorBanner.setOpenoptionsLayout1(getValueFromArray(openoptionsLayout1Array,counter));
					}
					if(null!= singleImageurlLayout2){
						rotatorBanner.setImageurlLayout2(singleImageurlLayout2.getString());						
					} else {
						rotatorBanner.setImageurlLayout2(getValueFromArray(imageurlLayout2Array,counter));
					}
					if(null!= singleUrllinkimageLayout2){
						rotatorBanner.setUrllinkimageLayout2(singleUrllinkimageLayout2.getString());						
					} else {
						rotatorBanner.setUrllinkimageLayout2(getValueFromArray(urllinkimageLayout2Array,counter));
					}
					if(null!= singleopenoptionsLayout2){
						rotatorBanner.setOpenoptionsLayout2(singleopenoptionsLayout2.getString());						
					} else {
						rotatorBanner.setOpenoptionsLayout2(getValueFromArray(openoptionsLayout2Array,counter));
					}
					if(null!= singleinsetImageLayout2Image){
						rotatorBanner.setInsetImageLayout2Image(singleinsetImageLayout2Image.getString());						
					} else {
						rotatorBanner.setInsetImageLayout2Image(getValueFromArray(insetImageLayout2ImageArray,counter));
					}
					if(null!= singleInsetVideoLayout2Image){
						rotatorBanner.setInsetVideoLayout2Image(singleInsetVideoLayout2Image.getString());						
					} else {
						rotatorBanner.setInsetVideoLayout2Image(getValueFromArray(insetVideoLayout2ImageArray,counter));
					}
					if(null!= singlecolorLayout2){
						rotatorBanner.setColorLayout2(singlecolorLayout2.getString());						
					} else {
						rotatorBanner.setColorLayout2(getValueFromArray(colorLayout2Array,counter));
					}
					if(null!= singleInsetImageLayout2Color){
						rotatorBanner.setInsetImageLayout2Color(singleInsetImageLayout2Color.getString());						
					} else {
						rotatorBanner.setInsetImageLayout2Color(getValueFromArray(insetImageLayout2ColorArray,counter));
					}
					if(null!= singleInsetVideoLayout2Color){
						rotatorBanner.setInsetVideoLayout2Color(singleInsetVideoLayout2Color.getString());						
					} else {
						rotatorBanner.setInsetVideoLayout2Color(getValueFromArray(insetVideoLayout2ColorArray,counter));
					}
					
					if(null!= singlecolor1Layout2){
						rotatorBanner.setColor1Layout2(singlecolor1Layout2.getString());						
					} else {
						rotatorBanner.setColor1Layout2(getValueFromArray(color1Layout2Array,counter));
					}
					if(null!= singlecolor2Layout2){
						rotatorBanner.setColor2Layout2(singlecolor2Layout2.getString());						
					} else {
						rotatorBanner.setColor2Layout2(getValueFromArray(color2Layout2Array,counter));
					}
					if(null!= singleInsetImageLayout2Gradient){
						rotatorBanner.setInsetImageLayout2Gradient(singleInsetImageLayout2Gradient.getString());						
					} else {
						rotatorBanner.setInsetImageLayout2Gradient(getValueFromArray(insetImageLayout2GradientArray,counter));
					}
					if(null!= singleInsetVideoLayout2Gradient){
						rotatorBanner.setInsetVideoLayout2Gradient(singleInsetVideoLayout2Gradient.getString());						
					} else {
						rotatorBanner.setInsetVideoLayout2Gradient(getValueFromArray(insetVideoLayout2GradientArray,counter));
					}
					if(null!= singlevideooverlayimageURL){
						rotatorBanner.setVideooverlayimageURL(singlevideooverlayimageURL.getString());						
					} else {
						rotatorBanner.setVideooverlayimageURL(getValueFromArray(videooverlayimageURLArray,counter));
					}
					if(null!= singlevideooverlayColor){
						rotatorBanner.setVideooverlayColor(singlevideooverlayColor.getString());						
					} else {
						rotatorBanner.setVideooverlayColor(getValueFromArray(videooverlayColorArray,counter));
					}
					if(null!= singlevideooverlayColor1){
						rotatorBanner.setVideooverlayColor1(singlevideooverlayColor1.getString());						
					} else {
						rotatorBanner.setVideooverlayColor1(getValueFromArray(videooverlayColor1Array,counter));
					}
					if(null!= singlevideooverlayColor2){
						rotatorBanner.setVideooverlayColor2(singlevideooverlayColor2.getString());						
					} else {
						rotatorBanner.setVideooverlayColor2(getValueFromArray(videooverlayColor2Array,counter));
					}
					if(null!= singlevideooverlayvideoURL){
						rotatorBanner.setVideooverlayvideoURL(singlevideooverlayvideoURL.getString());						
					} else {
						rotatorBanner.setVideooverlayvideoURL(getValueFromArray(videooverlayvideoURLArray,counter));
					}
					if(null!= singleAlignhorizontal){
						rotatorBanner.setAlignHorizontal(singleAlignhorizontal.getString());						
					} else {
						rotatorBanner.setAlignHorizontal(getValueFromArray(alignHorizontalArray,counter));
					}
					if(null!= singleAlignvertical){
						rotatorBanner.setAlignVertical(singleAlignvertical.getString());						
					} else {
						rotatorBanner.setAlignVertical(getValueFromArray(alignVerticalArray,counter));
					}*/

					/*if(rotatorBanner.getLayout().equals(LAYOUT_1)){
						LOG.info(" IF LAYOUT1 : rotatorBanner.getLayout()"+rotatorBanner.getLayout());
						childNode.setProperty("bannerlayout1", rotatorBanner.getBannerlayout1());
						if(rotatorBanner.getBannerlayout1().equals(LAYOUT_1_BACKGROUND_IMAGE)){
							childNode.setProperty("imageurlLayout1", rotatorBanner.getImageUrlLayout1());
						}
						else if(rotatorBanner.getBannerlayout1().equals(LAYOUT_1_BACKGROUND_COLOR)){
							childNode.setProperty("colorLayout1", rotatorBanner.getColorLayout1());
						}
						else if(rotatorBanner.getBannerlayout1().equals(LAYOUT_1_BACKGROUND_VIDEO)){
							childNode.setProperty("videourlLayout1", rotatorBanner.getVideourlLayout1());
							childNode.setProperty("videosourceLayout1", rotatorBanner.getVideosourceLayout1());
						}
						childNode.setProperty("urllinkLayout1", rotatorBanner.getUrllinkLayout1());
						childNode.setProperty("openoptionsLayout1", rotatorBanner.getOpenoptionsLayout1());	
					}
					else if(rotatorBanner.getLayout().equals(LAYOUT_2)){
						LOG.info("IF LAYOUT 2 : rotatorBanner.getLayout()"+rotatorBanner.getLayout());
						childNode.setProperty("bannerlayout2", rotatorBanner.getBannerlayout2());
						if(rotatorBanner.getBannerlayout2().equals(LAYOUT_2_BACKGROUND_IMAGE)){
							childNode.setProperty("imageurlLayout2", rotatorBanner.getImageurlLayout2());
							childNode.setProperty("urllinkimageLayout2", rotatorBanner.getUrllinkimageLayout2());
							childNode.setProperty("openoptionsLayout2", rotatorBanner.getOpenoptionsLayout2());
							childNode.setProperty("insetImageLayout2Image", rotatorBanner.getInsetImageLayout2Image());
							childNode.setProperty("insetVideoLayout2Image", rotatorBanner.getInsetVideoLayout2Image());
						}
						else if(rotatorBanner.getBannerlayout2().equals(LAYOUT_2_BACKGROUND_COLOR)){
							childNode.setProperty("colorLayout2", rotatorBanner.getColorLayout2());
							childNode.setProperty("insetImageLayout2Color", rotatorBanner.getInsetImageLayout2Color());
							childNode.setProperty("insetVideoLayout2Color", rotatorBanner.getInsetVideoLayout2Color());
						}
						else if(rotatorBanner.getBannerlayout2().equals(LAYOUT_2_BACKGROUND_GRADIENT)){
							childNode.setProperty("color1Layout2", rotatorBanner.getColor1Layout2());
							childNode.setProperty("color2Layout2", rotatorBanner.getColor2Layout2());
							childNode.setProperty("insetImageLayout2Gradient", rotatorBanner.getInsetImageLayout2Gradient());
							childNode.setProperty("insetVideoLayout2Gradient", rotatorBanner.getInsetVideoLayout2Gradient());
						}
						else if(rotatorBanner.getBannerlayout2().equals(LAYOUT_2_BACKGROUND_VIDEOOVERLAY)){
						childNode.setProperty("videooverlayimageURL", rotatorBanner.getVideooverlayimageURL());
						childNode.setProperty("videooverlayColor", rotatorBanner.getVideooverlayColor());
						childNode.setProperty("videooverlayColor1", rotatorBanner.getVideooverlayColor1());
						childNode.setProperty("videooverlayColor2", rotatorBanner.getVideooverlayColor2());
						childNode.setProperty("videooverlayvideoURL", rotatorBanner.getVideooverlayvideoURL());
						childNode.setProperty("alignHorizontal", rotatorBanner.getAlignHorizontal());
						childNode.setProperty("alignVertical", rotatorBanner.getAlignVertical());
						}
					}*/
					LOG.info("Color test"+rotatorBanner.getColorLayout1());
					childNode.getSession().save();
					LOG.info("Color test2"+rotatorBanner.getColorLayout1());
					bannerList.add(rotatorBanner);
					LOG.info("Bannerlist updated"+rotatorBanner.getColorLayout1());
					counter++;
				}
			}

		} catch (PathNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ValueFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bannerList;
	}

	private String getValueFromArray(Value[] imageUrlLayout1Array, int index) {
		if(null != imageUrlLayout1Array && imageUrlLayout1Array.length >= index){
			try {
				return imageUrlLayout1Array[index].getString();
			} catch (ValueFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RepositoryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return "";
	}

}
