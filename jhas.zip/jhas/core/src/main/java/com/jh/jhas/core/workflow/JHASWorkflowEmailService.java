package com.jh.jhas.core.workflow;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.JcrConstants;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.HistoryItem;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.mailer.MessageGatewayService;
import com.jh.jhas.core.WorkflowServicesHelper;
import com.jh.jhas.core.constants.EmailConstants;
import com.jh.jhas.core.helper.EmailHelper;
import com.jh.jhas.core.mailservice.JohnHancockSecureMailService;
import com.jh.jhas.core.models.EmailRecipient;
import com.jh.jhas.core.models.EmailSender;
import com.jh.jhas.core.models.Substitution;
import com.jh.jhas.core.utility.ConfigUtil;

@Component(immediate = true,metatype = true)
@Service
@Properties({
    @Property(name = "service.description", value ="Process for JHAS Workflow EmailService"),
	@Property(name = "service.vendor", value = "JHAS"),
	@Property(name = "process.label", value = "JHAS Workflow Email Service")    
  })

public class JHASWorkflowEmailService implements WorkflowProcess {

	
	@Reference
	private ResourceResolverFactory resolverFactory;
	
	@Reference
	JohnHancockSecureMailService johnHancockSecureMailService;

	@Reference
	private MessageGatewayService msgGatewayService;	
	private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
			throws WorkflowException {
		Map<String,Object> paramMap=new HashMap<>();
		paramMap.put(ResourceResolverFactory.SUBSERVICE, "JHASWorkflowEmailService");
		Session session						= null; 
		InputStream inputStream 			= null;	
		Scanner scanner 					= null; 
		ResourceResolver resourceResolver = null;
		
		try {
			WorkflowData workflowData = workItem.getWorkflowData();
			String payloadPath = workflowData.getPayload().toString();
			resourceResolver = resolverFactory.getServiceResourceResolver(paramMap);
			session = resourceResolver.adaptTo(Session.class);
			if (workflowData.getPayloadType().equals("JCR_PATH")) {
				String previousComment = "";
				List<HistoryItem> history = workflowSession.getHistory(workItem.getWorkflow());
				if (history != null && history.get(history.size()-1).getWorkItem().getMetaDataMap().get("comment") != null) {
					previousComment = history.get(history.size()-1).getWorkItem().getMetaDataMap().get("comment").toString();
				}
				if(StringUtils.isBlank(previousComment)) {
					previousComment = "No reason given";
				}
				
				// Get Template Id from Workflow Argument
				String templateId = getProcessArgValues("emailTemplate", metaDataMap);
				
				// Get From Address from Workflow Argument
				EmailSender senderAddress = new EmailSender();
				senderAddress.setName("Workflow Editor");
				senderAddress.setEmail(getProcessArgValues("from", metaDataMap));
				
				String toEmailAddressString=getProcessArgValues("recepient",metaDataMap);
				List<String> emailRecipients=Arrays.asList(toEmailAddressString.split(","));
				
				// populate the digital Sender Address
				List<EmailRecipient> workflowEmailRecipients = new ArrayList<>();
				
				for(String emailRecipient : emailRecipients) {
					EmailRecipient workflowEmailRecipient = new EmailRecipient();
					workflowEmailRecipient.setName("Workflow Approver");
					workflowEmailRecipient.setEmail(emailRecipient);
					workflowEmailRecipients.add(workflowEmailRecipient);
					
				}
				
				
				String domainUrl=ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_SITE_DOMAIN);
				String pageUrl=domainUrl+payloadPath+".html?wcmmode=disabled";
				String notificationPath=domainUrl+"/aem/inbox";
				String emailSubject=getProcessArgValues("subject",metaDataMap);
				// Get DAM asset paths from page
				List<String> damAssetPaths = WorkflowServicesHelper.getDAMAssetsOnPage(resourceResolver, payloadPath);
				String assetPath="";
				for(int i=0 ; i<damAssetPaths.size();i++){
					assetPath=assetPath.concat(domainUrl+damAssetPaths.get(i)+"<br>");
					LOG.error("asset return -->"+damAssetPaths.get(i));
				}
				LOG.error("assetPath String -->"+assetPath);
				
				// Get user name of current participant
				MetaDataMap widgetValues = workItem.getMetaDataMap();
				String historyPath=widgetValues.get("historyEntryPath").toString();
				Resource userdataResource = resourceResolver.getResource(historyPath);
				Node userdataNode= userdataResource.adaptTo(Node.class);
				UserManager wfUserManager = resourceResolver.adaptTo(UserManager.class);
				Authorizable wfUser = wfUserManager.getAuthorizable(userdataNode.getProperty("user").getValue().getString());
				
				String lastName=wfUser.getProperty("./profile/familyName")!=null?wfUser.getProperty("./profile/familyName")[0].getString():"";
			    String firstName=wfUser.getProperty("./profile/givenName")!=null?wfUser.getProperty("./profile/givenName")[0].getString():"";
				
				
				// populate Substitutors
				List<Substitution> substitutions = new ArrayList<>();

				Substitution wfUserSub = new Substitution();
				wfUserSub.setName("wfuser");
				wfUserSub.setValue(firstName+" "+lastName);
				substitutions.add(wfUserSub);
				
				Substitution pageUrlSub = new Substitution();
				pageUrlSub.setName("pageUrl");
				pageUrlSub.setValue(pageUrl);
				substitutions.add(pageUrlSub);
				
				Substitution notificationPathSub = new Substitution();
				notificationPathSub.setName("notificationPath");
				notificationPathSub.setValue(notificationPath);
				substitutions.add(notificationPathSub);
				
				Substitution assetPathSub = new Substitution();
				assetPathSub.setName("assetPath");
				assetPathSub.setValue(assetPath);
				substitutions.add(assetPathSub);
				
				Substitution commentSub = new Substitution();
				commentSub.setName("comment");
				commentSub.setValue(previousComment);
				substitutions.add(commentSub);
				
				boolean emailStatus = johnHancockSecureMailService.sendDigitalAPIEmail(templateId, senderAddress, workflowEmailRecipients, emailSubject, substitutions);
				if(emailStatus){
					LOG.info("Workflow Email sent successfully");
				}else{
					LOG.error("Error while sending workflow email");
					EmailHelper.sendErrorEmail(msgGatewayService, session, senderAddress.getEmail());
				}
				
				// Set MLI Compliance Number
				
				Resource resource = resourceResolver.getResource(payloadPath+"/"+JcrConstants.JCR_CONTENT);
				Node pageNode=resource.adaptTo(Node.class);
				String wfppmNo = pageNode.hasProperty("mliNo")?pageNode.getProperty("mliNo").getValue().toString():"";
				workflowData.getMetaDataMap().put("wfmliNo",wfppmNo);
}
		
	} catch (Exception e) {
		LOG.error("Error in "+getClass().getName(),e);
    } finally {
        // ALWAYS close the sessions you open
        if (session != null && session.isLive()) {
        	session.logout();
        }
        // ALWAYS close resolvers you open
        if (resourceResolver != null) {
        	resourceResolver.close();
        }
        
        if(inputStream != null) {
        	try {
				inputStream.close();
			} catch (IOException e) {
				LOG.error("Exception in inputstream"+e);
			}
        }
        if(scanner != null) {
        	scanner.close();
        	scanner = null;
        }
    }
		
	}
	/**
	 * Method to get the processargs values 
	 * 
	 * @param key
	 * @param metadatamap
	 * @return String 
	 */
	private String getProcessArgValues(String key, MetaDataMap metaDataMap) {
		String processArguments[];
		String argumentValue = " ";
		String processArgs = metaDataMap.get("PROCESS_ARGS", String.class);
		if (processArgs != null && !processArgs.equals("")) {
			processArguments = processArgs.split(";");

			for (int i = 0; i < processArguments.length; i++) {
				String trimmedStr = processArguments[i].trim();
				if (trimmedStr.startsWith(key + ":")) {
					argumentValue = trimmedStr.substring((key + ":").length());
					break;
				}
			}
		}

		return argumentValue;
	}		
}