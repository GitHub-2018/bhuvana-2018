package com.jh.jhas.core;
import com.adobe.cq.sightly.WCMUsePojo;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UUIDGenerator extends WCMUsePojo{
	private String randomUUID;
	private static final Logger LOG = LoggerFactory.getLogger(UUIDGenerator.class);
	
	@Override
    public void activate() throws Exception {
		LOG.info("inside activate method");
		UUID uuid = UUID.randomUUID();
		randomUUID = uuid.toString();
		
	}
	
	public String getRandomUUID()
	{
		LOG.info("inside return method: "+randomUUID);
		return randomUUID;
		
	}
	

}
