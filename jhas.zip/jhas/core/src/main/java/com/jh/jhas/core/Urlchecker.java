package com.jh.jhas.core;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class Urlchecker extends WCMUsePojo {
	String pathval="";
	public void activate() throws Exception {
		Logger log = LoggerFactory.getLogger(Urlchecker.class);
		String path = get("param1", String.class);
		if(StringUtils.isNotBlank(path) && path.startsWith("/content/")&& !path.endsWith(".html.*")
				&& !path.startsWith("/content/dam/") && !path.contains(".html")){
			pathval=path+".html";
			log.info("path"+ path);
		} else if(StringUtils.isNotBlank(path)){
			pathval=path;
		} 
	}
	public String getURLVal() {

		return pathval;

	}


}
