package com.jh.jhas.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;

import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.dam.commons.util.AssetReferenceSearch;

public class WorkflowServicesHelper {

	public static List<String> getDAMAssetsOnPage(ResourceResolver resourceResolver, String payloadPath) {
		List<String> assetList = new ArrayList<>();
		Resource resource = resourceResolver.getResource(payloadPath+"/"+JcrConstants.JCR_CONTENT);
		Map<String,Asset> assets =getReferencesInPage(resource,resourceResolver);
		if (null != assets) {
			for(Map.Entry<String, Asset> asset : assets.entrySet())
			{ 
				assetList.add(asset.getKey());
			}
		}
		return assetList;
	}

	public  static Map<String,Asset> getReferencesInPage(Resource resource,ResourceResolver resourceResolver) {

		Node pageNode = resource.adaptTo(Node.class);
		AssetReferenceSearch referenceSearch = new AssetReferenceSearch(pageNode,DamConstants.MOUNTPOINT_ASSETS,resourceResolver);
		if(referenceSearch.search().size() > 0) {
			return referenceSearch.search();
		}
		else 
			return null;					
	}
}
