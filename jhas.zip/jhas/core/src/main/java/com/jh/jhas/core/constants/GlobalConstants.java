package com.jh.jhas.core.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GlobalConstants {
	
	//For Articles
	public static final String JHAS_ARTICLES_PATH="/content/johnhancock";
	public static final String PRNEWS_ARTICLES_PATH="/content/johnhancock/news";
	public static final String MANUAL_ARTICLES_PATH="/content/johnhancock/articles";
	public static final String PROFILES_LISTED_PATH="/content";
	public static final String NEWSARTICLE_TEMPLATE="/apps/JHAS/templates/articlepage";
	public static final String NEWSARTICLE_RENDERER="/apps/JHAS/components/page/articlepage";
	
	public static final String NEWSARTICLE_PARENT_TEMPLATE="/apps/JHAS/templates/homepage";
	public static final String NEWSARTICLE_PARENT_RENDERER="/apps/JHAS/components/page/homepage";
	
	public static final String USER_NAME="name";
	public static final String BUSINESS_UNIT="businessUnit";
	public static final String TURN_OFF_PICTURE="turnoffpicture";
	public static final String JOB_TITLE="title";
	public static final String USER_PHONE="phone";
	public static final String USER_EMAIL="email";
	public static final String LINKEDIN_PROFILE="linkedIn";
	public static final String PROFILE_PICTURE="picture";
	public static final String PROFILE_MODIFIED_DATE="cq:lastModified";
	public static final String PROFILE_CATEGORY="profileCategory";
	public static final String JCR_TITLE="jcr:title";
	public static final String NODE_PRIMARY_TYPE="primaryType";
	public static final String CQ_PAGE_CONTENT="cq:PageContent";
	public static final String CQ_PAGE_TEMPLATE="cq:template";
	public static final String SLING_RESOURCE_TYPE="sling:resourceType";
	public static final String ARTICLE_TITLE="articleTitle";
	public static final String ARTICLE_BODY="body";
	public static final String ARTICLE_SUMMARY="description";
	public static final String ARTICLE_PUBLISHED_DATE="articleDate";
	public static final String ARTICLE_IMAGE="imageThumbnail";
	public static final String ARTICLE_AUTHOR="authorName";
	public static final String ARTICLE_CATEGORY="articleCategory";
	public static final String ARTICLE_SUBHEAD_LINE = "articleSubheadline";
	public static final String JCR_CONTENT = "jcr:content";
	public static final String PRNEWS_ARTICLES_DATETIME="dateTime";
	public static final String HIDE_IN_NAV = "hyperLink";
	public static final String EXCLUDE_IN_SEARCH = "excludeInSearch";
	public static final String EXCLUDE_IN_SEARCH_VALUE = "true";
	//External Articles
	public static final String EXTERNAL_ARTICLE_CHECK="externalCheck";
	public static final String EXTERNAL_ARTICLE_PATH="externalURL";
	//For Videos
	public static final String VIDEO_TYPE_YOUTUBE="youtube";
	public static final String VIDEO_TYPE_HTML5="html5video";
	public static final String YOUTUBE_VIDEO_PATTERN="(?<=watch\\?v=|/videos/|embed\\/)[^#\\&\\?]*";
	
	
	public static final String EMPTY_STRING = "";
	public static final String ERROR_PAGE_PATH	= "/content/JHAS/en/error/500";
	
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String AUTHORIZATION = "Authorization";
	public static final String JSON_BODY_TYPE = "application/json";
	public static final String UTF_CHARSET = "UTF-8";
	
	public static final String G_RECAPTCHA_RESPONSE = "g-recaptcha-response";
	public static final String G_PARAM_SECRET = "secret";
	public static final String G_PARAM_REMOTEIP = "remoteip";
	public static final String G_PARAM_RESPONSE = "response";
	public static final String GOOGLE_RECAPTCHA_VERIFY_API="https://www.google.com/recaptcha/api/siteverify";
	public static final String CONFIG_GOOGLEAPI_RECAPTCHA_SITEKEY = "jhas.googleapi.reCaptchaSiteKey";
	public static final String CONFIG_GOOGLEAPI_RECAPTCHA_SECRECTKEY = "jhas.googleapi.reCaptchaSecretKey";
	
	public static final String SEARCH_URL="https://www.googleapis.com/customsearch/v1";
	public static final String CONFIG_GOOGLEAPI_SITEKEY = "jhas.googleapi.sitekey";
	public static final String CONFIG_GOOGLEAPI_PARAM = "jhas.googleapi.param";
	
	public static final String CONTACT_US_TOPIC_PATH="/apps/settings/wcm/designs/lists/contact-us-topics";
	public static final String CONFIG_UNCLAIMEDPROPERTY_SERVICEURL = "jhas.unclaimedproperty.serviceUrl";
	public static final String CONFIG_UNCLAIMEDPROPERTY_USERNAME="jhas.unclaimedproperty.userName";
	public static final String CONFIG_UNCLAIMEDPROPERTY_PWD="jhas.unclaimedproperty.password";
	public static final String UNCLAIMEDPROPERTY_SERVER_URI="https://jhcommitment.jhancock.com/Servicelibrary";
	public static final String UNCLAIMEDPROPERTY_SOAPACTION="https://jhcommitment.jhancock.com/Servicelibrary/IJHAccountSearch/SubmitRequest";
	public static final List<String> REMOVE_FORM_PARAMS = new ArrayList<>(Arrays.asList("EmailForm_"));
	public static final String NEWS_CATEGORY = "newsCategory";
	public static final String PR_NEWS_CATEGORIES = "http://johnhancock.mediaroom.com/api/newsfeed_releases/list_categories.php";
	public static final String JCR_PRIMARY_TYPE = "jcr:primaryType";
	public static final String FOLDER_TYPE = "nt:folder";
	public static final String LEADERSHIP_PROFILES_PATH = "/content/johnhancock/who-we-are/leadership-profiles";
	
	public static final String PRNEWS_CATEGORY="newsCategory";
	public static final String BOSTON_MARATHON="Boston Marathon";
}
