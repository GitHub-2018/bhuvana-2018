package com.jh.jhas.core.contactus.dto;

import java.util.List;

public class EmailDetails {
	private List<String> toList;
	private List<String> ccList;
	private String fromAddress;
	private String subject;
	private String message;
	
	public List<String> getToList() {
		return toList;
	}
	public void setToList(List<String> toList) {
		this.toList = toList;
	}
	public List<String> getCcList() {
		return ccList;
	}
	public void setCcList(List<String> ccList) {
		this.ccList = ccList;
	}
	public String getFromAddress() {
		return fromAddress;
	}
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "EmailDetails [toList=" + toList + ", ccList=" + ccList + ", fromAddress=" + fromAddress + ", subject="
				+ subject + ", message=" + message + "]";
	}
}
