package com.jh.jhas.core.servlets;

import java.io.IOException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.helper.EmailHelper;
import com.jh.jhas.core.helper.RecaptchaHelper;

@SlingServlet(paths="/bin/sling/RecaptchaValidatorServlet", methods="POST", metatype=true) 
public class RecaptchaValidatorServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(RecaptchaValidatorServlet.class);

	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		String reCaptcha = EmailHelper.stripXSS("reCaptcha",request.getParameter("gresponse"));
		Boolean reCaptchaStatus= RecaptchaHelper.recaptchaValidate(request,reCaptcha);

		JSONObject obj = new JSONObject();
		try{
			if(!reCaptchaStatus) {
				obj.put("message","recaptcha_faliure");
			} else {
				obj.put("message","recaptcha_success");
			} 
		}
		catch (JSONException e) {
			LOG.info("ERROR IN JSON OBJECT PARSING");
		}			      
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(obj.toString());
	}
}
