package com.jh.jhas.core;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.models.NavItem;
import com.jh.jhas.core.prnewsarticlecategories.Categories;
import com.jh.jhas.core.utility.PRNewsWireGenerator;
import com.jh.jhas.core.utility.TextUtil;

public class GetPRNewsCategories extends WCMUsePojo {
	private Logger LOG = LoggerFactory.getLogger(GetPRNewsCategories.class);
	private List<NavItem> prnewsCategories;
	
	
	@Override
	public void activate() throws Exception {
		prnewsCategories = new ArrayList<>();
		Categories mainCategories = PRNewsWireGenerator.getPRNewsArticleCategories(GlobalConstants.PR_NEWS_CATEGORIES);
		for(Categories.Category category:mainCategories.getCategory()) {
			NavItem navItem = new NavItem();
			navItem.setLinkurl(GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+TextUtil.getValidContentName(category.getName().trim())+".html");
			navItem.setLinktitle(category.getName().trim());
			LOG.info("Title : {} + Path : {} "+navItem.getLinktitle(),navItem.getLinkurl());
			prnewsCategories.add(navItem);
		}
		
	}
	public List<NavItem> getPrnewsCategories() {
		return prnewsCategories;
	}

}
