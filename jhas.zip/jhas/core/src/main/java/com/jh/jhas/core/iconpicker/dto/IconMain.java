package com.jh.jhas.core.iconpicker.dto;

import java.util.List;

public class IconMain {
	
	private String background;
	private List<Icon> icons;

	public String getBackground() {
		return background;
	}

	public void setBackground(String background) {
		this.background = background;
	}

	public List<Icon> getIcons() {
		return icons;
	}

	public void setIcons(List<Icon> icons) {
		this.icons = icons;
	}

}
