package com.jh.jhas.core.newsarticles.dto;

import java.util.List;

public class ArticleParams {

	private String searchPath;
	private List<String> categories;
	private int limit;
	/**
	 * @return the searchPath
	 */
	public String getSearchPath() {
		return searchPath;
	}
	/**
	 * @param searchPath the searchPath to set
	 */
	public void setSearchPath(String searchPath) {
		this.searchPath = searchPath;
	}
	/**
	 * @return the categories
	 */
	public List<String> getCategories() {
		return categories;
	}
	/**
	 * @param categories the categories to set
	 */
	public void setCategories(List<String> categories) {
		this.categories = categories;
	}
	/**
	 * @return the limit
	 */
	public int getLimit() {
		return limit;
	}
	/**
	 * @param limit the limit to set
	 */
	public void setLimit(int limit) {
		this.limit = limit;
	}
	
}
