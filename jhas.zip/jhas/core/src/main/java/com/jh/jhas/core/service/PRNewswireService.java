package com.jh.jhas.core.service;

public interface PRNewswireService {
	public void getNewsfeedReleases();
}
