package com.jh.jhas.core;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.jh.jhas.core.models.NavItem;
import com.jh.jhas.core.utility.NewsArticlesAscendingDateComparator;

public class GetNextPrnewsArticle extends WCMUsePojo {
	private Logger LOG = LoggerFactory.getLogger(GetNextPrnewsArticle.class);
	private NavItem prnewsNextArticle;

	@Override
	public void activate() throws Exception {
		prnewsNextArticle = new NavItem();
		String title="";
		String url="#";
		if(getCurrentPage().getPath().contains("news")) {

			Resource currentCategoryResource = getResourceResolver().getResource(getCurrentPage().getAbsoluteParent(3).getPath());
			Resource currentprnewsYearResource = getResourceResolver().getResource(getCurrentPage().getPath()).getParent().getParent();
			Resource currentprnewsMonthResource = getResourceResolver().getResource(getCurrentPage().getPath()).getParent();
			
			boolean isNextPage = false;
			boolean isNextParentPage = false;

			if(null != currentprnewsYearResource) {
				for(int year=Integer.parseInt(currentprnewsYearResource.getName());year<=Calendar.getInstance().get(Calendar.YEAR);year++) {
					Resource prnewsYearResource = getResourceResolver().getResource(currentCategoryResource.getPath()+"/"+year);
					if(null != currentprnewsMonthResource && null != prnewsYearResource) {
						int startMonth=Integer.parseInt(currentprnewsMonthResource.getName());
						if(isNextPage) {
							startMonth=1;
						}
						for(int month=startMonth;month<=12;month++){
							Resource prnewsMonthResource = getResourceResolver().getResource(prnewsYearResource.getPath()+"/"+String.format("%02d", month));
							if(null != prnewsMonthResource) {
								List<Page> sortedPrnewsPages = getSortedNewsPages(prnewsMonthResource.listChildren());
								for(Page prnewsPage : sortedPrnewsPages) {
									if(isNextPage){
										title=prnewsPage.getTitle();
										url=prnewsPage.getPath()+".html";
										isNextParentPage = true;
										break;
									}
									if(getCurrentPage().getTitle().equals(prnewsPage.getTitle())) {
										isNextPage = true;
									}
								}
								if(isNextParentPage) {
									break;
								}
							}
						}
						if(isNextParentPage) {
							break;
						}
					}
				}
			}
		}
		prnewsNextArticle.setLinktitle(title);
		prnewsNextArticle.setLinkurl(url);
	}

	private List<Page> getSortedNewsPages(Iterator<Resource> prnewsResourceIterator) {
		List<Page> prnewsSortedPages = new ArrayList<>();
		while (prnewsResourceIterator.hasNext()) {
			Page prnewsPage = prnewsResourceIterator.next().adaptTo(Page.class);
			prnewsSortedPages.add(prnewsPage);
		}
		Collections.sort(prnewsSortedPages, new NewsArticlesAscendingDateComparator());
		return prnewsSortedPages;
	}


	public NavItem getPrnewsNextArticle() {
		return prnewsNextArticle;
	}



}