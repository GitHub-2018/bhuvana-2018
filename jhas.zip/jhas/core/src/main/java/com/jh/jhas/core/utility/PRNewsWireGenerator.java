package com.jh.jhas.core.utility;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.prnewsarticle.Release;
import com.jh.jhas.core.prnewsarticlecategories.Categories;
import com.jh.jhas.core.prnewsarticlelist.Releases;

public class PRNewsWireGenerator {
	
	private static Logger LOG = LoggerFactory.getLogger(PRNewsWireGenerator.class);
    
    public static Categories getPRNewsArticleCategories(String uri) throws IOException, JAXBException {
    InputStream articlexml = null;
    Unmarshaller jaxbUnmarshaller;
    Categories categories =new Categories();
	try{
		articlexml=getInputStream(uri);
		JAXBContext jaxbContext = JAXBContext.newInstance( Categories.class );       	
		jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		XMLInputFactory xif = XMLInputFactory.newFactory();
		xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
		xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
		XMLStreamReader xsr = xif.createXMLStreamReader(articlexml);
		categories= (Categories)jaxbUnmarshaller.unmarshal(xsr);
	}
     catch (XMLStreamException e) {
		LOG.info("Error in PRNewswireGenerator"+e);
	}
	finally {
		if (articlexml != null) articlexml.close();
		}
	return categories;
    }
    
    public static Releases getPRNewsArticleList(String uri) throws IOException, JAXBException {
    InputStream articlexml = null;
    Unmarshaller jaxbUnmarshaller;
    Releases releases=new Releases();
    try{
    	articlexml=getInputStream(uri);
    	JAXBContext jaxbContext = JAXBContext.newInstance( Releases.class );       	
    	jaxbUnmarshaller = jaxbContext.createUnmarshaller();
    	XMLInputFactory xif = XMLInputFactory.newFactory();
		xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
		xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
		XMLStreamReader xsr = xif.createXMLStreamReader(articlexml);
    	releases=(Releases)jaxbUnmarshaller.unmarshal(xsr);
    }
    catch (XMLStreamException e) {
		LOG.info("Error in PRNewswireGenerator"+e);
	}
	finally {
		if (articlexml != null) articlexml.close();
		}
	return releases;
    }
    
    public static Release getPRNewsArticle(String uri) throws IOException, JAXBException {
    InputStream articlexml = null;
    Unmarshaller jaxbUnmarshaller;
    Release release =new Release();
    try{
	articlexml=getInputStream(uri);
	JAXBContext jaxbContext = JAXBContext.newInstance( Release.class );       	
	jaxbUnmarshaller = jaxbContext.createUnmarshaller();
	XMLInputFactory xif = XMLInputFactory.newFactory();
	xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
	xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
	XMLStreamReader xsr = xif.createXMLStreamReader(articlexml);
	release=(Release)jaxbUnmarshaller.unmarshal(xsr);
    }
    catch (XMLStreamException e) {
		LOG.info("Error in PRNewswireGenerator"+e);
	}
   	finally {
   		if (articlexml != null) articlexml.close();
   		}
	return release; 
    }
    
  
    private static InputStream getInputStream(String uri) throws IOException {
	try {
	    URL url = new URL(uri);
	    HttpURLConnection connection =(HttpURLConnection) url.openConnection();
	    connection.setRequestMethod("GET");
	    connection.setRequestProperty("Accept", "application/xml");
	    return connection.getInputStream();
	}
	catch( MalformedURLException e ) {
	    LOG.info("Bad URL Generated : "+uri);
	}
	
	return null;
    }
}
