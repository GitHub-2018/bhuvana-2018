package com.jh.jhas.core.leadership.dto;

import java.util.List;

public class LeadershipProfile {
	
	
	private String name;
	private String title;
	private String businessUnit;
	private String turnoffpicture;
	private String picture;
	private List<String> profileCategory;
	private String phone;
	private String email;
	private String linkedIn;
	private String url;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public String getTurnoffpicture() {
		return turnoffpicture;
	}
	public void setTurnoffpicture(String turnoffpicture) {
		this.turnoffpicture = turnoffpicture;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}

	public List<String> getProfileCategory() {
		return profileCategory;
	}
	public void setProfileCategory(List<String> profileCategory) {
		this.profileCategory = profileCategory;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLinkedIn() {
		return linkedIn;
	}
	public void setLinkedIn(String linkedIn) {
		this.linkedIn = linkedIn;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
}
