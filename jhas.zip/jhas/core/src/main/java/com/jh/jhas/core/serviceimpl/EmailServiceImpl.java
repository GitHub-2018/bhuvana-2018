package com.jh.jhas.core.serviceimpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.constants.EmailConstants;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.contactus.dto.TokenResponse;
import com.jh.jhas.core.helper.EmailHelper;
import com.jh.jhas.core.service.EmailService;
import com.jh.jhas.core.utility.ConfigUtil;
import com.jh.jhas.core.utility.JsonSanitizer;

@Component(immediate = true, metatype = false)
@Service(value = { EmailService.class })
public class EmailServiceImpl implements EmailService{

	private static final Logger LOG = LoggerFactory.getLogger(EmailServiceImpl.class);

	private static final String USER_AGENT 				= "Mozilla/5.0";
	private static final String UTF_TYPE 			= "UTF-8";
	
	@Override
	public String getOAUTHToken(String jsonInput, String apiEndPoint, ResourceResolver resourceResolver){
		
		if(StringUtils.containsIgnoreCase(apiEndPoint, "https://")){
			return getOAUTHTokenUsingHttps(jsonInput, apiEndPoint, resourceResolver);
		}
		HttpClient httpClient 		= null;
		PostMethod httpPostMethod 	= null;
		try
		{
			httpClient = new HttpClient();
			StringRequestEntity requestEntity = new StringRequestEntity(jsonInput,GlobalConstants.JSON_BODY_TYPE,GlobalConstants.UTF_CHARSET);
			httpPostMethod = new PostMethod(apiEndPoint); 
			httpPostMethod.setRequestEntity(requestEntity);
		    // Return the response body if the request is successfully executed.
			if (httpClient.executeMethod(httpPostMethod) == HttpStatus.SC_OK){
				LOG.info("Successfully fetched data from the endpoint.");
				String httpPostResponse = JsonSanitizer.sanitize(httpPostMethod.getResponseBodyAsString());
				TokenResponse tokenResposnse = EmailHelper.createGsonObj().fromJson(httpPostResponse, TokenResponse.class);
				if(tokenResposnse.isSuccess()){
					return tokenResposnse.getToken();
				} else {
					LOG.error(" OAuth Token request failed error message received {} "+tokenResposnse.getMessage()+"<End Message>");
					return null;
				}
			} else {
				LOG.error(" OAuth Token request failed with non 200 status ");
				return null;
			}
		}
		catch(Exception e){
			LOG.error("Error while getting authorization token",e);
		}
		finally{
			if(httpPostMethod != null){
				httpPostMethod.releaseConnection();
				httpPostMethod = null;
			}
			httpClient = null;
		}
		return null;
	}

	private String getOAUTHTokenUsingHttps(String jsonInput, String apiEndPoint, ResourceResolver resourceResolver){
		PostMethod post	                                    = null;
		int responseCode 									= -1;
		HttpsURLConnection con								= null;
		BufferedReader in 									= null;
		OutputStream os 									= null;
		try {
/*
 * Commented out X509 certificates due to fortify scan issues
 * 			
			String isDummyCert = ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_DUMMY_HTTPS, "Y");
			if(StringUtils.equalsIgnoreCase("Y", isDummyCert)) {
				con = EmailHelper.getDummySecureConnection(apiEndPoint);
			} else {
				con = EmailHelper.getSecureConnection(resourceResolver,apiEndPoint);
			}
*/			
			con = EmailHelper.getSecureConnection(resourceResolver,apiEndPoint);
			//add request header
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);
			con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			StringBuilder inputContent = new StringBuilder(jsonInput);
			

			// Send post request
			con.setDoOutput(true);
			
			try{
				os = con.getOutputStream();
				//os.write(inputContent.toString().getBytes());
				os.write(inputContent.toString().getBytes(UTF_TYPE));
			}finally{
				if(os != null){
					safeClose(os);
				}
			}

			responseCode = con.getResponseCode();
			String inputLine;
			StringBuilder responseContent = new StringBuilder();
			in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			while ((inputLine = in.readLine()) != null) {
				responseContent.append(inputLine);
			}
			
			// Return the response body if the request is successfully executed.
			if (responseCode == HttpStatus.SC_OK){
				LOG.info("Successfully fetched data from the endpoint.");
				TokenResponse tokenResposnse = EmailHelper.createGsonObj().fromJson(responseContent.toString(), TokenResponse.class);
				if(tokenResposnse.isSuccess()){
					return tokenResposnse.getToken();
				} else {
					LOG.error(" OAuth Token request failed error message received {} "+tokenResposnse.getMessage()+"<End Message>");
					return null;
				}
			} else {
				LOG.error(" OAuth Token request failed with non 200 status ");
				return null;
			}			
		} catch (Exception e) {
			LOG.error("Error while getting authorization token",e);
		} finally {
			if (con != null) {
				con.disconnect();
				con = null;
			}			
			if (post != null) {
				post.releaseConnection();
				post = null;
			}
			if (in != null) {
				try{
					in.close();
				}catch(Exception e){
					LOG.error("Error while getting authorization token inside finally block",e);
				}
				in = null;
			}
		}
		return null;
	}
	
	@Override
	public boolean sendEmail(String jsonEmailInput, String apiURL, String oauth, ResourceResolver resourceResolver) {
		
		if(StringUtils.containsIgnoreCase(apiURL, "https://")){
			return sendEmailUsingHttps(jsonEmailInput, apiURL, oauth, resourceResolver);
		}
		
		HttpClient httpClient 		= null;
		PostMethod httpPostMethod 	= null;
		try
		{
			httpClient = new HttpClient();
			StringRequestEntity requestEntity = new StringRequestEntity(jsonEmailInput,GlobalConstants.JSON_BODY_TYPE,GlobalConstants.UTF_CHARSET);
			httpPostMethod = new PostMethod(apiURL); 
			String headerValue = "Bearer ";
			httpPostMethod.addRequestHeader(GlobalConstants.AUTHORIZATION, headerValue);
			httpPostMethod.setRequestEntity(requestEntity);
			int HTTP_STATUS = httpClient.executeMethod(httpPostMethod);
			LOG.info(" HTTP_STATUS {}",HTTP_STATUS);
			if (HTTP_STATUS == HttpStatus.SC_OK) {
				String httpPostResponseToken = JsonSanitizer.sanitize(httpPostMethod.getResponseBodyAsString());
				LOG.info("inside SC OK. response is {}",httpPostResponseToken);
				TokenResponse tokenResposnse = EmailHelper.createGsonObj().fromJson(httpPostResponseToken, TokenResponse.class);
				if(tokenResposnse.isSuccess()){
					return true;
				} else {
					LOG.error(" Email failed error message received {} "+tokenResposnse.getMessage()+"<End Message>");
					return false;
				}
			} else {
				LOG.error(" Email request failed with non 200 status ");
				return false;
			}
		}
		catch(Exception e){
			LOG.error("Error while sending email",e);
		}
		finally{
			if(httpPostMethod != null){
				httpPostMethod.releaseConnection();
				httpPostMethod = null;
			}
			httpClient = null;
		}
		return false;
	}
	
	private boolean sendEmailUsingHttps(String jsonEmailInput, String apiURL, String oauth, ResourceResolver resourceResolver) {
		PostMethod post	                                    = null;
		int responseCode 									= -1;
		HttpsURLConnection con								= null;
		BufferedReader in 									= null;
		OutputStream os 									= null;
		try {
			con = EmailHelper.getSecureConnection(resourceResolver,apiURL);
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);
			con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			String headerValue = "Bearer "+oauth;
			headerValue=EmailHelper.stripXSS(headerValue, headerValue);
			con.setRequestProperty("Authorization", headerValue);			
			
			StringBuilder inputContent = new StringBuilder(jsonEmailInput);

			// Send post request
			con.setDoOutput(true);
			
			try{
				os = con.getOutputStream();
				//os.write(inputContent.toString().getBytes());
				os.write(inputContent.toString().getBytes(UTF_TYPE));
			}finally{
				if(os != null){
					safeClose(os);
				}
			}

			responseCode = con.getResponseCode();
			String inputLine;
			StringBuilder responseContent = new StringBuilder();
			in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			while ((inputLine = in.readLine()) != null) {
				responseContent.append(inputLine);
			}
			
			// Return the response body if the request is successfully executed.
			if (responseCode == HttpStatus.SC_OK) {
				String responseContentJson = JsonSanitizer.sanitize(responseContent.toString());
				LOG.info("inside SC OK. response is {}",responseContentJson);
				TokenResponse tokenResposnse = EmailHelper.createGsonObj().fromJson(responseContentJson, TokenResponse.class);
				if(tokenResposnse.isSuccess()){
					return true;
				} else {
					LOG.error(" Email failed error message received {} "+tokenResposnse.getMessage()+"<End Message>");
					return false;
				}
			} else {
				LOG.error(" Email request failed with non 200 status ");
				return false;
			}			
			
		} catch (Exception e) {
			LOG.error("Error while getting authorization token",e);
		} finally {
			if (con != null) {
				con.disconnect();
				con = null;
			}			
			if (post != null) {
				post.releaseConnection();
				post = null;
			}
			if (in != null) {
				try{
					in.close();
				}catch(Exception e){
					LOG.error("Error while getting authorization token inside finally block",e);
				}
				in = null;
			}
		}
		return false;
	}
	public void safeClose(OutputStream os) {
		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}	
	
}
