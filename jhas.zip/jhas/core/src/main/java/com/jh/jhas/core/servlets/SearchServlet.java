package com.jh.jhas.core.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import javax.servlet.Servlet;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.configs.PropertiesConfig;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.EmailHelper;
import com.jh.jhas.core.utility.ConfigUtil;

@Component(immediate = true, metatype = true)
@Service(Servlet.class) 
@Properties({
    @Property(name = "service.description", value ="Servlet"),
    @Property(name = "sling.servlet.paths", value ={"/bin/sling/searchservlet"}),
    @Property(name = "sling.servlet.methods", value ="GET", propertyPrivate = true)
})
public class SearchServlet  extends SlingSafeMethodsServlet{
    private static final long serialVersionUID = 1L;
    

    @Reference
    private PropertiesConfig propertiesConfig;
    private static final Logger LOG = LoggerFactory.getLogger(SearchServlet.class);
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
    String googleParamId;
    String cxParam;
    String searchUrl;
	BufferedReader in = null;
	InputStream caInput = null;
	try {
	    googleParamId= ConfigUtil.INSTANCE.getStringConfiguration(GlobalConstants.CONFIG_GOOGLEAPI_SITEKEY);
	    cxParam= ConfigUtil.INSTANCE.getStringConfiguration(GlobalConstants.CONFIG_GOOGLEAPI_PARAM);
	    searchUrl=GlobalConstants.SEARCH_URL;
	    String query=EmailHelper.stripXSS("query",request.getParameter("search").replaceAll(" ", "%20"));
	    String pageNo=EmailHelper.stripXSS("pageNo",request.getParameter("pageno"));
	    String filterDomain=EmailHelper.stripXSS("filterDomain",request.getParameter("filterby"));
	    URL url;

	    if(StringUtils.isNotBlank(filterDomain)) {

		if(StringUtils.isNotBlank(pageNo)) {
		    url = new URL(searchUrl+"?key="+googleParamId+ "&cx=" +cxParam+ "&q="+query+"&siteSearch="+filterDomain+"&siteSearchFilter=i&start="+pageNo+"&safe=high");
		} else {
		    url = new URL(searchUrl+"?key="+googleParamId+ "&cx=" +cxParam+ "&q="+query+"&siteSearch="+filterDomain+"&siteSearchFilter=i&safe=high");
		}
	    } else {
		if(StringUtils.isNotBlank(pageNo)) {
		    url = new URL(searchUrl+"?key="+googleParamId+ "&cx=" +cxParam+ "&q="+query+"&start="+pageNo+"&safe=high");
		} else {
		    url = new URL(searchUrl+"?key="+googleParamId+ "&cx=" +cxParam+ "&q="+query+"&safe=high");
		}
	    }
	    /*
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
			public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1) { }
			public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1) { }
		} };
		

	    SSLContext context = SSLContext.getInstance("TLS");
	    context.init(null, trustAllCerts, null);
	    */
	    HttpURLConnection conn = null;

	    JSONObject jsonObj = new JSONObject();

	    if ("https".equalsIgnoreCase(url.getProtocol())) {
		HttpsURLConnection https = (HttpsURLConnection) url.openConnection();
		//https.setSSLSocketFactory(context.getSocketFactory());
		SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
		https.setSSLSocketFactory(sslsocketfactory);
		conn=https;
		LOG.info("conn--->"+conn);
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept", "application/json");

		int responseCode = conn.getResponseCode();
		if (responseCode == HttpURLConnection.HTTP_OK) { 
		    //success
		    try {
			String inputLine;
			StringBuilder jsonResponse = new StringBuilder();
			in = new BufferedReader(new InputStreamReader(
				conn.getInputStream()));
			while ((inputLine = in.readLine()) != null) {
			    jsonResponse.append(inputLine);
			    LOG.info("inputLine : "+inputLine);
			}
			in.close();
			try {
			    jsonObj = new JSONObject(jsonResponse.toString());
			} catch (JSONException e) {
			    LOG.error("JSON Parsing Failed ... ");
			    e.printStackTrace();
			}
			LOG.info("Search Response : "+jsonResponse.toString());
		    } catch (Exception e) {
			LOG.error("Search Results Fetch Error ..");
		    } finally {
			if (null != in) {
			    in.close();
			}
		    }

		} else {
		    LOG.info("Search Results Error ..");
		}
		conn.disconnect();
	    }
	    response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(jsonObj.toString());
	} catch (Exception e) {
	    LOG.error("Search Results Fetch Error ..");
	} finally {
	    try {
		if (null != caInput) {
		    caInput.close();
		}
		if (null != in) {
		    in.close();
		}
	    } catch (IOException e) {
		LOG.error("Error Closing connection ..");
	    }
	}
    }

}
