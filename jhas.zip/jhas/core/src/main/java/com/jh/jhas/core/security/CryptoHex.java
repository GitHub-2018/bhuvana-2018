package com.jh.jhas.core.security;

/**
 * Converts a text string into a hex string with each character being
 * represented as a two character hex number. So the character "A", ascii
 * code 65 is represented as the string "41". This technique ensures that
 * we can convert all known characters into string form but it does double
 * the length of the string.
 */
public class CryptoHex implements Crypto
{
    public char[] encrypt(String a_text)
    {
        return encode(a_text.getBytes()).toCharArray();
    }

    /**
     * @param a_text
     * @return the encoded string
     */
    public String encode(byte[] a_text)
    {
        StringBuffer result = new StringBuffer();

        Byte aByte;
        int anInt;

        for (int index = 0; index < a_text.length; index++)
        {
            aByte = new Byte(a_text[index]);
            anInt = aByte.intValue();
            if (anInt < 0)
            {
                anInt += 256;
            }

            if (anInt < 16)
            {
                result.append('0');
            }

            result.append(Integer.toHexString(anInt));
        }

        return result.toString();
    }

    public char[] decrypt(String a_hexidecimal) throws CryptoException
    {
    	
        byte[] byteArray = decode(a_hexidecimal);
        
        char[] decryptPass = new char[byteArray.length];
        for(int i = 0; i < byteArray.length; i++){
        	decryptPass[i] = (char)byteArray[i];
        }
       return decryptPass; 
    }

    /**
     * @param a_hexidecimal
     * @return the decoded string
     * @throws CryptoException
     */
    public byte[] decode(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                                 + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }    

}