package com.jh.jhas.core.mailservice;

import java.util.List;

import com.jh.jhas.core.models.EmailRecipient;
import com.jh.jhas.core.models.EmailSender;
import com.jh.jhas.core.models.Substitution;

public interface JohnHancockSecureMailService {

	public boolean sendDigitalAPIEmail(String templateId, EmailSender senderAddress, List<EmailRecipient> recipientAddresses, String emailSubject, List<Substitution> substitutions);
	
}
