package com.jh.jhas.core.repository;
import javax.jcr.RepositoryException;
import javax.jcr.query.InvalidQueryException;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;


public class JhasRepository {
	
    private QueryManager manager;

    public JhasRepository(final QueryManager manager) {
                this.manager = manager;
    }

    public QueryResult getQueryResult(final String querystmt) throws InvalidQueryException, RepositoryException {

                final Query query = manager.createQuery(querystmt, Query.JCR_SQL2);
                return query.execute();

    }

}
