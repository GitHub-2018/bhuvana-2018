package com.jh.jhas.core.utility;

import java.util.Arrays;
import java.util.Dictionary;
import java.util.List;
import java.util.Map;

import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.constants.GlobalConstants;
/**
 * CofigUtil for retrieving necessary configurations
 * 
 * @author Cognizant
 *
 */
public enum ConfigUtil {
	// singleton variable for this class
		INSTANCE;
		
		private final Logger LOG = LoggerFactory.getLogger(getClass());
		
	/*Map<String, Object> configProperties;*/
		Dictionary<String, Object> configProperties;
		
		String envrionment;
		public void setConfigProperties(Dictionary<String, Object> configProperties) {
			// TODO Auto-generated method stub
			this.configProperties = configProperties;
		}
		

	/*public void setConfigProperties(Map<String, Object> configProperties) {
			this.configProperties = configProperties;
		}*/
		
		public String getEnvrionment() {
			return envrionment;
		}

		public void setEnvrionment(String envrionment) {
			this.envrionment = envrionment;
		}

		public String getStringConfiguration(String propertyName) {
			return getStringConfiguration(propertyName,GlobalConstants.EMPTY_STRING);
		}
		
		public String getStringConfiguration(String propertyName, String defaultPropValue) {
			if (configProperties == null || propertyName == null) {
				return defaultPropValue;
			}
			Object configValue = this.configProperties.get(propertyName);
			String propValue = PropertiesUtil.toString(configValue, defaultPropValue);
			return propValue;
		}

		
		public String [] getStringArrayConfiguration(String propertyName, String [] defaultPropValue) {
			if (configProperties == null || propertyName == null) {
				return defaultPropValue;
			}
			
			Object configValue = this.configProperties.get(propertyName);
			String [] propValue = PropertiesUtil.toStringArray(configValue, defaultPropValue);
			LOG.debug("String value for property: '" + propertyName + "'. Value: '" + propValue + "'.");
			return propValue;
		}
		

		public List<String> getListConfiguration(String propertyName, String defaultPropValue) {
			return Arrays.asList(getStringArrayConfiguration(propertyName,new String[]{defaultPropValue}));
		}
		
		
		public long getLongConfiguration(String propertyName, long defaultPropValue) {
			String propValue = getStringConfiguration(propertyName, "" + defaultPropValue);
			try {
				return Long.parseLong(propValue);
			} catch (NumberFormatException e) {
				LOG.error("Invalid long value for property: '" + propertyName + "'. Value: '" + propValue + "'.");
				return defaultPropValue;
			}
		}


		public boolean getBooleanConfiguration(String propertyName, boolean defaultPropValue) {
			String propValue = getStringConfiguration(propertyName, "" + defaultPropValue);
			try {
				return Boolean.parseBoolean(propValue);
			} catch (NumberFormatException e) {
				LOG.error("Invalid boolean value for property: '" + propertyName + "'. Value: '" + propValue + "'.");
				return defaultPropValue;
			}
		}

	
	
}
