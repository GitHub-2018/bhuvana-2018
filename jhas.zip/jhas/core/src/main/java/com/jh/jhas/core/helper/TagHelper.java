package com.jh.jhas.core.helper;

import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;


public class TagHelper {

	public static String getTagTitle(String tagName, ResourceResolver resourceResolver ){
		String tagTitle="";
		TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
        Tag tag = tagManager.resolve(tagName);
		tagTitle=tag.getTitle();
		return tagTitle;
	} 
}
