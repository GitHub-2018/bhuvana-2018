package com.jh.jhas.core.configs;

import java.util.Dictionary;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, label = "JHAS Properties Configuration", description = "Configuration properites for JHAS", metatype = true)
@Properties({
    @Property(name = Constants.SERVICE_DESCRIPTION, value = "This is JHAS Configuration Service"),
    @Property(name = Constants.SERVICE_VENDOR, value = "jhas") })
@Service(PropertiesConfig.class)
public class PropertiesConfig {
    private static final Logger LOG = LoggerFactory .getLogger(PropertiesConfig.class);

    /** The Constant PRNEWS CONTENT_PATH. */
    @Property(label="PR Newswire XML API service endpoint", value="http://johnhancock.mediaroom.com/api/newsfeed_releases", description="Configure PR Newswire XML API service endpoint")
	public static final String PRNEWSWIRE_ENDPOINT_URL="prnewswire.endpoint.url";
    
    /** The Constant Google Search URL. */
    /*
    @Property(label="Google Search URL", value="https://www.googleapis.com/customsearch/v1", description="Configure Google Custom Search URL")
	public static final String SEARCH_URL="search.url";
     */
    
    /** The properties. */
    @SuppressWarnings("rawtypes")
    private static Dictionary props = null;

    /**
     * Activate.
     * 
     * @param componentContext
     *            the component context
     */
    @Activate
    protected final void activate(final ComponentContext componentContext) {

                LOG.info("JHAS Configuration Service:: Activated method called");
                props = componentContext.getProperties();

    }


    /**
     * Deactivate.
     * 
     * @param context
     *            the context
     */
    @Deactivate
    protected final void deactivate(final ComponentContext context) {
                LOG.info("JHAS Configuration  : deactivating service");
    }

    public String getProperty(final String key) {
                return (String) props.get(key);     
    } 

}
