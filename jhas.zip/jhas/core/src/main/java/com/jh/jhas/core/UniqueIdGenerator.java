package com.jh.jhas.core;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model(adaptables=SlingHttpServletRequest.class)
public class UniqueIdGenerator {
	private String Id;
	private static Logger LOG = LoggerFactory.getLogger(UniqueIdGenerator.class);
	@Inject
	private String path;
	
	@PostConstruct
	protected void init() {	
		
		path=path.replaceAll("_", "");
		String parentPath= path.substring(0,path.lastIndexOf('/')-1);
		parentPath= parentPath.substring(parentPath.lastIndexOf('/')+1);
		Id= parentPath+"_"+path.substring(path.lastIndexOf('/')+1);	
		LOG.info("generated Id"+ Id);
		
		}
	
	public String getId(){
		LOG.info("return Id"+ Id);
		return Id;
		
	}
	
}
