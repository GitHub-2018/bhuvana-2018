package com.jh.jhas.core.serviceimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.PRNewsArticleHelper;
import com.jh.jhas.core.prnewsarticle.Release;
import com.jh.jhas.core.prnewsarticlecategories.Categories;
import com.jh.jhas.core.prnewsarticlelist.Releases;
import com.jh.jhas.core.service.PRNewswireService;
import com.jh.jhas.core.utility.DateUtils;
import com.jh.jhas.core.utility.PRNewsWireGenerator;
import com.jh.jhas.core.utility.TextUtil;

@Component(metatype=true,immediate=true)
@Service(value=PRNewswireService.class)
public class PRNewswireServiceImpl implements PRNewswireService {

	@Reference
	ResourceResolverFactory resourceResolverFactory;
	
	@Reference
    private Replicator replicator;

	@Property(label="PR Newswire XML API service endpoint", value="http://johnhancock.mediaroom.com/api/newsfeed_releases", description="Configure PR Newswire XML API service endpoint")
	public static final String PRNEWSWIRE_ENDPOINT_URL="prnewswire.endpoint.url";
	
	private String prnewswireEndpointUrl;
	private static Logger LOG = LoggerFactory.getLogger(PRNewsWireGenerator.class);
	
	@Override
	public void getNewsfeedReleases(){
		generatePrnewswireArticles();
	}		

	/**
	 * Generate prnewswire articles for the first time
	 * Generate prnewswire articles incrementally if latest modified date is already present.
	 */
	private void generatePrnewswireArticles(){
		Map<String,Object> paramMap=new HashMap<String,Object>();
		paramMap.put(ResourceResolverFactory.SUBSERVICE, "PRNewswireService");
		try {
			ResourceResolver resourceResolver=resourceResolverFactory.getServiceResourceResolver(paramMap);
			Resource prnewsArticlesContentResource= resourceResolver.getResource(GlobalConstants.PRNEWS_ARTICLES_PATH+"/jcr:content");
			if(null!=prnewsArticlesContentResource){
				Node prnewsArticlesNode=prnewsArticlesContentResource.adaptTo(Node.class);
				getLatestPRNews(resourceResolver, prnewsArticlesNode);
			}
			else{
				LOG.error("PRNewsarticles node is missing");
			}

		} catch (Exception e) {
			LOG.error("Exception in PRNewswiredervice "+e.getMessage());
		}

	}


	/**
	 * Gets the latest news list from PRNews XML
	 *
	 * @param resourceResolver the resource resolver
	 * @param prnewsArticlesNode the prnews articles node
	 * @return the initial news load
	 */
	private void getLatestPRNews(ResourceResolver resourceResolver, Node prnewsArticlesNode) {
		LOG.info("Entering getLatestPRNews");
		try {
			Categories mainCategories=PRNewsWireGenerator.getPRNewsArticleCategories(prnewswireEndpointUrl+"/list_categories.php");
		// Get News Categories
		for(Categories.Category category:mainCategories.getCategory()){
			String categoryName=TextUtil.getValidContentName(category.getName().trim());
			if(null==resourceResolver.getResource(GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName)) {
				createArticlePage(resourceResolver,GlobalConstants.PRNEWS_ARTICLES_PATH,categoryName,GlobalConstants.NEWSARTICLE_PARENT_TEMPLATE,category.getName().trim(), GlobalConstants.NEWSARTICLE_PARENT_RENDERER, null, category.getName().trim(), null, null);
				replicatePage(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName);
			}
			
		}
		// Create News Year | News Month | News Article Page from Latest News List
		String prevlatestModified = "0";
		if(prnewsArticlesNode.hasProperty("latestModified")){
			prevlatestModified=prnewsArticlesNode.getProperty("latestModified").getString();
		}
		prnewsArticlesNode.setProperty("latestModified", getLatestModifiedAndCreateNewsArticles(prevlatestModified, resourceResolver, prnewsArticlesNode));
		prnewsArticlesNode.getSession().save();
		} catch (Exception e) {
			LOG.error("Exception in getting News Categories"+e);
		}
	}
	
	/**
	 * Gets the latest modified and create news articles.
	 * @param prevlatestModified last modified date on node
	 * @param resourceResolver the resource resolver
	 * @param prnewsArticlesNode the prnews articles node
	 * @return the latest modified and create news articles
	 */
	private String getLatestModifiedAndCreateNewsArticles(String prevlatestModified, ResourceResolver resourceResolver, Node prnewsArticlesNode) {
			try {
				Releases initialReleases=PRNewsWireGenerator.getPRNewsArticleList(prnewswireEndpointUrl+"/list.php?modified_since="+prevlatestModified);
				prnewsArticlesNode.setProperty("latestModified", initialReleases.getLatestModified());
				Long totalArticles = Long.parseLong(initialReleases.getMatchingCount());
				for(long offset=0;offset<totalArticles;offset=offset+50) {
					Releases releases=PRNewsWireGenerator.getPRNewsArticleList(prnewswireEndpointUrl+"/list.php?modified_since="+prevlatestModified+"&limit=50&offset="+offset);
					List<Releases.Release> releaseList=releases.getRelease();
					if(!releaseList.isEmpty()){
						for(Releases.Release articleRelease: releaseList){
							String releaseID=articleRelease.getId();
							String articleName=TextUtil.getValidContentName(articleRelease.getHeadline());
							String year=DateUtils.getYearFromdateString(articleRelease.getModifiedDate());
							String month=DateUtils.getMonthFromdateString(articleRelease.getModifiedDate());
							Release article=PRNewsWireGenerator.getPRNewsArticle(prnewswireEndpointUrl+"/get.php?id="+releaseID+"&safehtml=yes");
							if(null!=article.getCategory()){
								String categoryName=TextUtil.getValidContentName(article.getCategory().getName().trim());
								if(!prnewsArticlesNode.getParent().hasNode(categoryName)){
									createArticlePage(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH, categoryName, GlobalConstants.NEWSARTICLE_PARENT_TEMPLATE, article.getCategory().getName().trim(), GlobalConstants.NEWSARTICLE_PARENT_RENDERER, null, article.getCategory().getName().trim(), null, null);
									replicatePage(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName);
									LOG.info("New category added");
								}
								Node categoryNode=prnewsArticlesNode.getParent().getNode(categoryName);
								if(!categoryNode.hasNode(year)){
									createArticleFolder(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName, year);
									replicatePage(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName+"/"+year);
									LOG.info("New Year added");
								}
								Node yearNode=categoryNode.getNode(year);
								if(!yearNode.hasNode(month)){
									createArticleFolder(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName+"/"+year, month);
									replicatePage(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName+"/"+year+"/"+month);
									LOG.info("New month added");
								}
								Node monthNode=yearNode.getNode(month);
								if(!monthNode.hasNode(articleName)){
									createArticlePage(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName+"/"+year+"/"+month, articleName, GlobalConstants.NEWSARTICLE_TEMPLATE, article.getHeadline(), GlobalConstants.NEWSARTICLE_RENDERER, article.getBody(), null, null, null);
									PRNewsArticleHelper.saveArticleContent(resourceResolver, article, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName+"/"+year+"/"+month+"/"+articleName);
									replicatePage(resourceResolver, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName+"/"+year+"/"+month+"/"+articleName);
									LOG.info("New article added");
								}
								else{
									PRNewsArticleHelper.saveArticleContent(resourceResolver, article, GlobalConstants.PRNEWS_ARTICLES_PATH+"/"+categoryName+"/"+year+"/"+month+"/"+articleName);
								}
							}
						}
					}
				}
				return initialReleases.getLatestModified();
			} catch (Exception e) {
				LOG.error("Exception in getLatestModifiedAndCreateNewsArticles"+e);
			}
			return "0";
	}


	/**
	 * Creates the article page.
	 *
	 * @param resourceResolver the resource resolver
	 * @param path the path
	 * @param pageName the page name
	 * @param template the template
	 * @param pageTitle the page title
	 * @param renderer the renderer
	 * @param body the body
	 * @param articleCategory the article category
	 * @param articleYear the article year
	 * @param articleMonth the article month
	 */
	private void createArticlePage(ResourceResolver resourceResolver,String path,String pageName,String template,String pageTitle, String renderer,  String body, String articleCategory, String articleYear, String articleMonth){
	    Session session = resourceResolver.adaptTo(Session.class);
	    String htmlPageName=StringUtils.isNotBlank(pageName) ? Jsoup.parse(pageName).text() : "";
	    String htmlPageTitle=StringUtils.isNotBlank(pageTitle) ? Jsoup.parse(pageTitle).text() : "";
	    Page page = null;
	    try {        
	    	if (session != null) {       
	    		PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
	    		page=pageManager.create(path, htmlPageName, template, htmlPageTitle);
	    		Node pageNode = page.adaptTo(Node.class);
	    		Node jcrNode;
	    		if(page.hasContent()) {
	    		    jcrNode = page.getContentResource().adaptTo(Node.class);
	    		} else {                  
	    		    jcrNode = pageNode.addNode(GlobalConstants.JCR_CONTENT, GlobalConstants.CQ_PAGE_CONTENT);
	    		}
	    		 jcrNode.setProperty(GlobalConstants.SLING_RESOURCE_TYPE, renderer);
	    		 jcrNode.setProperty(GlobalConstants.CQ_PAGE_TEMPLATE, GlobalConstants.NEWSARTICLE_TEMPLATE);
	    		 if(StringUtils.isNotBlank(articleCategory)) {
	    			 Node parNode = jcrNode.addNode("mainContentParsys");
	    			 parNode.setProperty("sling:resourceType", "wcm/foundation/components/parsys");
	    			 Node jhasContainerNode = parNode.addNode("jhascontainer");
	    			 jhasContainerNode.setProperty("sling:resourceType", "JHAS/components/content/jhaspagecontainer");
	    			 jhasContainerNode.setProperty("bottomPadding", "0");
	    			 jhasContainerNode.setProperty("container", "none");
	    			 jhasContainerNode.setProperty("containerOptions", "section");
	    			 jhasContainerNode.setProperty("containerheight", "none");
	    			 jhasContainerNode.setProperty("leftPadding", "0");
	    			 jhasContainerNode.setProperty("rightPadding", "0");
	    			 jhasContainerNode.setProperty("topPadding", "0");
	    			 Node containerParNode = jhasContainerNode.addNode("containerParsys");
	    			 containerParNode.setProperty("sling:resourceType", "wcm/foundation/components/parsys");
	    			 Node prnewswireNode = containerParNode.addNode("prnewswire");
	    			 prnewswireNode.setProperty("sling:resourceType", "JHAS/components/content/prnewswiresearch");
	    			 prnewswireNode.setProperty("articleCategory", articleCategory);
	    			 if(StringUtils.isNotBlank(articleMonth)) {
	    				 prnewswireNode.setProperty("articleMonth", articleMonth);
	    			 } 
	    			 if(StringUtils.isNotBlank(articleYear)) {
	    				 prnewswireNode.setProperty("articleYear", articleYear);
	    			 }
	    			 jcrNode.setProperty(GlobalConstants.EXCLUDE_IN_SEARCH, GlobalConstants.EXCLUDE_IN_SEARCH_VALUE);
	    		 } else if(StringUtils.isNotBlank(body)){
	    			 // Article Page
	    			 Node parNode = jcrNode.addNode("parlefttop");
	    			 parNode.setProperty("sling:resourceType", "wcm/foundation/components/parsys");
	    			 Node htmlcssNode = parNode.addNode("htmljs");
	    			 htmlcssNode.setProperty("sling:resourceType", "JHAS/components/content/htmlJs");
	    			 htmlcssNode.setProperty("htmlJsInput",body);
	    		 }
	    		  LOG.info("PAGE created  "+path+"/"+htmlPageName);
	    		  session.save();
	    		  session.refresh(true);
	    	}
	    	else{
	    		  LOG.info("Session returning null");
	    	}
	    	} catch (Exception e) {
	  LOG.error("Exception in page creation"+e.getMessage());
	 }   
	}

	/**
	 * Creates the article folder.
	 *
	 * @param resourceResolver the resource resolver
	 * @param path the path
	 * @param folderName the folder name
	 */
	private void createArticleFolder(ResourceResolver resourceResolver, String path, String folderName) {
		Session session = resourceResolver.adaptTo(Session.class);
		Resource resource = resourceResolver.getResource(path);
		try {        
			if (session != null) { 
				Node resourceNode = resource.adaptTo(Node.class);
				resourceNode.addNode(folderName, GlobalConstants.FOLDER_TYPE);
				LOG.info("Folder Created  "+path+"/"+folderName);
				session.save();
				session.refresh(true);
			}
			else{
				LOG.info("Session returning null");
			}
		} catch (Exception e) {
			LOG.error("Exception in folder creation"+e.getMessage());
		} 

	}
	
	/**
	 * Replicate page.
	 *
	 * @param resourceResolver the resource resolver
	 * @param pathToPage the path to page
	 */
	private void replicatePage(ResourceResolver resourceResolver,String pathToPage){
		 Session session = resourceResolver.adaptTo(Session.class);
		 try {
			replicator.replicate(session, ReplicationActionType.ACTIVATE, pathToPage);
			session.save();
  		  	session.refresh(true);
		} catch (Exception e) {
			LOG.error("Error in page activation"+pathToPage);
		}
	}
	
	
	@Activate
	public void activate(final Map<String,Object> props){
		LOG.info("PRNewswireService: Activate Method called");
		this.prnewswireEndpointUrl=(String) props.get(PRNEWSWIRE_ENDPOINT_URL);
		
	}
	
	
	
}
