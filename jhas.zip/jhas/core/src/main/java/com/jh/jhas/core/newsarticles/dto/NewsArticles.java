package com.jh.jhas.core.newsarticles.dto;

import java.util.List;

public class NewsArticles {
	private List<Article> articles;

	/**
	 * @return the latestnews
	 */
	public List<Article> getArticles() {
		return articles;
	}

	/**
	 * @param latestnews the latestnews to set
	 */
	public void setArticles(List<Article> articles) {
		this.articles = articles;
	}
}
