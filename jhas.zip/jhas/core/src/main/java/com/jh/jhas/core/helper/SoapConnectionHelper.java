package com.jh.jhas.core.helper;

import java.io.ByteArrayOutputStream;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.unclaimedpropertyform.SubmitRequestResponse;
import com.jh.jhas.core.unclaimedpropertyform.SubmitStatus;
import com.jh.jhas.core.utility.ConfigUtil;


public class SoapConnectionHelper {
	private static final Logger LOG = LoggerFactory.getLogger(SoapConnectionHelper.class);
    /**
     * Starting point for the SAAJ - SOAP Client Testing
     */
    public static String getSOAPRequest(Document document) {
    	String submitCode="";
	/*
	 * Commented out X509 certificates due to fortify scan issues
	 *    	
    	// Create a trust manager that does not validate certificate chains

    	TrustManager[] trustAllCerts = new TrustManager[]{
    			new X509TrustManager() {
    				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
    					return null;
    				}
    				public void checkClientTrusted(
    						java.security.cert.X509Certificate[] certs, String authType) {
    				}
    				public void checkServerTrusted(
    						java.security.cert.X509Certificate[] certs, String authType) {
    				}
    			}
    	};
    	
    	// Install the all-trusting trust manager
    	try {
    		SSLContext sc = SSLContext.getInstance("SSL");
    		sc.init(null, trustAllCerts, new java.security.SecureRandom());
    		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    	} catch (Exception e) {
    		LOG.info("This block has executed");
    	}
    */
        try {
            // Create SOAP Connection
            SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
            SOAPConnection soapConnection = soapConnectionFactory.createConnection();

            // Send SOAP Message to SOAP Server
            String url = ConfigUtil.INSTANCE.getStringConfiguration(GlobalConstants.CONFIG_UNCLAIMEDPROPERTY_SERVICEURL);
            SOAPMessage soapRequest=createSOAPRequest(document);
            LOG.info("SOAP message created");
            SOAPMessage soapResponse = soapConnection.call(soapRequest, url);
            LOG.info("SOAP service called");

            // Process the SOAP Response
            submitCode=getSOAPResponse(soapResponse);

            soapConnection.close();
            
        } catch (Exception e) {
            LOG.error("Error occurred while sending SOAP Request to Server"+e);
        }
		return submitCode;
        
		
    }

    private static SOAPMessage createSOAPRequest(Document document) throws Exception {
    	
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();
        String serverURI = GlobalConstants.UNCLAIMEDPROPERTY_SERVER_URI;

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("ser", serverURI);
        
        //Mime header: Soap Action
        MimeHeaders mimeHeader = soapMessage.getMimeHeaders();
        
        //change header's attribute
        mimeHeader.setHeader("SOAPAction", GlobalConstants.UNCLAIMEDPROPERTY_SOAPACTION);
        SOAPHeader header = envelope.getHeader();
        SOAPElement security = header.addChildElement("Security", "wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");        
        security.addAttribute(new QName("SOAP-ENV:mustUnderstand"), "1");
        security.addAttribute(new QName("xmlns:wsu"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");
        SOAPElement usernameToken = security.addChildElement("UsernameToken", "wsse");
        security.addChildElement(usernameToken);
        SOAPElement username = usernameToken.addChildElement("Username", "wsse");
        username.addTextNode(ConfigUtil.INSTANCE.getStringConfiguration(GlobalConstants.CONFIG_UNCLAIMEDPROPERTY_USERNAME));
        SOAPElement password = usernameToken.addChildElement("Password", "wsse");
        password.setAttribute("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
    	password.addTextNode(ConfigUtil.INSTANCE.getStringConfiguration(GlobalConstants.CONFIG_UNCLAIMEDPROPERTY_PWD));
    	soapMessage.getSOAPBody().addDocument(document);
        soapMessage.saveChanges();

        /* Print the request message */
        ByteArrayOutputStream bout = new ByteArrayOutputStream();  
        soapMessage.writeTo(bout);  
        String msg = bout.toString("UTF-8");  
        LOG.info(":: Logging SOAP Message :: " + msg);  
        return soapMessage;
    }

    /**
     * Method used to print the SOAP Response
     * @return TODO
     */
    private static String getSOAPResponse(SOAPMessage soapResponse) throws Exception {
    	LOG.info("Response Processing");
        
        SOAPBody sb = soapResponse.getSOAPBody();
        Document d = sb.extractContentAsDocument();
        DOMSource source = new DOMSource(d);
        
        JAXBContext jaxbContext = JAXBContext.newInstance(SubmitRequestResponse.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		JAXBElement<SubmitStatus> submitStatusElement=null;
		SubmitStatus submitStatus=new SubmitStatus();
		
		SubmitRequestResponse submitRequestResponse=(SubmitRequestResponse)jaxbUnmarshaller.unmarshal(source);
		submitStatusElement=submitRequestResponse.getSubmitRequestResult();
		submitStatus=submitStatusElement.getValue();
        LOG.info("\nResponse Message : "+submitStatus.getSubmitMessage().getValue().toString());
        LOG.info("\nResponse Code : "+submitStatus.getSubmitCode().toString());
        
        return submitStatus.getSubmitCode().toString();
        
        
        
    }

   
}
