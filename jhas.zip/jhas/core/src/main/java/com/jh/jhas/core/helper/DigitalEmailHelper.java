package com.jh.jhas.core.helper;

import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class DigitalEmailHelper {

	private static final Logger LOG = LoggerFactory.getLogger(DigitalEmailHelper.class);
	/**
	 * To exclude fields based on modifier in JSON output
	 * @param modifier - Modifier levels  - Modifier.PUBLIC, Modifier.PROTECTED, Modifier.PRIVATE, Modifier.ABSTRACT, Modifier.STATIC, Modifier.FINAL, Modifier.STRICT
	 * @return
	 */
	public static Gson createGsonObj(){	
		return new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
	}
	
	/**
	 * Gets the secure connection with SSL and mitigates Fortify Scan
	 *
	 * @param apiURL the api URL
	 * @return 
	 * @return the secure connection
	 */
	public static HttpsURLConnection getSecureConnection(String apiURL) {
	
		 HttpsURLConnection con = null;	
		 SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
		try {
			URL obj = new URL(apiURL);
			con = (HttpsURLConnection) obj.openConnection();
			con.setSSLSocketFactory(sslsocketfactory);
			LOG.info("Connection was successful!");	
		} catch (Exception e) {
			if(con!=null){
				con.disconnect();
			}
			LOG.error("Error while establishing secure connection", e);	
		}
		return con;
}
}
