package com.jh.jhas.core.utility;

import java.util.Comparator;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import com.day.cq.wcm.api.Page;

public class NewsArticlesAscendingDateComparator implements Comparator<Page> {

	@Override
	public int compare(Page currentPage, Page nextPage) {
		try {
			Long currentPageDate = Long.parseLong(currentPage.getContentResource().adaptTo(Node.class).getProperty("dateTime").getString());
			Long nextPageDate = Long.parseLong(nextPage.getContentResource().adaptTo(Node.class).getProperty("dateTime").getString());
			Long dateDifference = currentPageDate - nextPageDate;
			if(dateDifference < 0) {
				return -1;
			} else if(dateDifference > 0){
				return 1;
			}
		} catch (RepositoryException e) {
			e.printStackTrace();
		}
		return 0;
	}

}
