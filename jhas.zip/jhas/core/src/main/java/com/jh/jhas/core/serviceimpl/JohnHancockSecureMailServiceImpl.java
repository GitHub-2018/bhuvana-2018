package com.jh.jhas.core.serviceimpl;
 
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.constants.EmailConstants;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.DigitalEmailHelper;
import com.jh.jhas.core.mailservice.JohnHancockSecureMailService;
import com.jh.jhas.core.models.EmailRecipient;
import com.jh.jhas.core.models.EmailSender;
import com.jh.jhas.core.models.Substitution;
import com.jh.jhas.core.utility.ConfigUtil;
import com.jh.jhas.core.utility.JsonSanitizer;
 
@Component(immediate = true, metatype = false)
@Service(value = { JohnHancockSecureMailService.class })
 
public class JohnHancockSecureMailServiceImpl implements JohnHancockSecureMailService  {
 
    private static Logger LOG = LoggerFactory.getLogger(JohnHancockSecureMailServiceImpl.class);
 
    @Override
    public boolean sendDigitalAPIEmail(String templateId, EmailSender senderAddress, List<EmailRecipient> recipientAddresses,
            String emailSubject, List<Substitution> substitutions) {
 
        JSONObject emailAPIInput = new JSONObject();
 
        try {
            emailAPIInput.put("AppId", ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_DIGITALEMAIL_APIID));
 
            /* Template ID */
            emailAPIInput.put("TemplateId", templateId);
 
            /* From */
            JSONObject emailSenderObj = new JSONObject();
 
            emailSenderObj.put("name", senderAddress.getName());
            emailSenderObj.put("email", senderAddress.getEmail());
 
            emailAPIInput.put("From", emailSenderObj);
 
            /* To */
            JSONArray emailRecipientArray = new JSONArray();
 
            for (EmailRecipient emailRecipient : recipientAddresses) {
                JSONObject emailRecipientObj = new JSONObject();
                emailRecipientObj.put("name", emailRecipient.getName());
                emailRecipientObj.put("email", emailRecipient.getEmail());
                emailRecipientArray.put(emailRecipientObj); 
            }
 
            emailAPIInput.put("To", emailRecipientArray);
 
            /* Subject */
            emailAPIInput.put("Subject", emailSubject);
 
            /* Substitutions */
            JSONArray substitutionArray = new JSONArray();
 
            for (Substitution substitution : substitutions) {
                JSONObject substitutionObj = new JSONObject();
                substitutionObj.put("Name", substitution.getName());
                substitutionObj.put("Value", substitution.getValue());
                substitutionArray.put(substitutionObj);
            }
 
            emailAPIInput.put("Substitutions", substitutionArray);
 
        } catch (JSONException e) {
            LOG.error("Failure to create Email API JSON", e);
        }
 
        OutputStream os = null;
        HttpsURLConnection conn = null;
        BufferedReader in = null;
        try {
            conn = DigitalEmailHelper.getSecureConnection(ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_DIGITALEMAIL_APIURL));
            //add request header
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty(ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_DIGITALEMAIL_APIKEY), ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.CONFIG_DIGITALEMAIL_APIVALUE));
            StringBuilder inputContent = new StringBuilder(emailAPIInput.toString());
            LOG.info("{}",conn.getRequestProperties());
  
 
            // Send post request
            conn.setDoOutput(true);
 
            try{
                os = conn.getOutputStream();
                os.write(inputContent.toString().getBytes(GlobalConstants.UTF_CHARSET));
            }finally{
                if(os != null){
                    safeClose(os);
                }
            }
 
            int responseCode = conn.getResponseCode();
            String inputLine;
            StringBuilder responseContent = new StringBuilder();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((inputLine = in.readLine()) != null) {
                responseContent.append(inputLine);
            }  
            // Return the response body if the request is successfully executed.
            if (responseCode == HttpStatus.SC_OK) {
                String responseContentJson = JsonSanitizer.sanitize(responseContent.toString());
                LOG.info("Success Digital API Email response <200> : {}",responseContentJson);
                JSONParser emailResponseParser = new JSONParser();
                org.json.simple.JSONObject emailResponseJsonObject = (org.json.simple.JSONObject) emailResponseParser.parse(responseContentJson);
                if("0000".equals((String)emailResponseJsonObject.get("Code"))){
                    return true;
                } else {
                    LOG.error("Digital Email failed error details received {} "+(String)emailResponseJsonObject.get("Message")+" <End Message>");
                    return false;
                }
            } else {
                LOG.error("Digital Email request failed with non 200 status ");
                return false;
            }           
 
        } catch (Exception e) {
            LOG.error("Error while sending Digital API Email : ",e);
        } finally {
            if (conn != null) {
                conn.disconnect();
                conn = null;
            }           
            if (in != null) {
                try{
                    in.close();
                }catch(Exception e){
                    LOG.error("Error while sending Digital API Email < inside finally block > : ",e);
                }
                in = null;
            }
        }
        return false;
    }
    
        /**
         * Safe close Output stream
         *
         * @param os the output stream
         */
        private void safeClose(OutputStream os) {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
}
