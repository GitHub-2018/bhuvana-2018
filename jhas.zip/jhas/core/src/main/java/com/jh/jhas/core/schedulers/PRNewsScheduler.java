package com.jh.jhas.core.schedulers;

import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.ConfigurationPolicy;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.service.PRNewswireService;


@Component(
        immediate = true, label = "JHAS PRNewswire Scheduler", description = "JHAS PRNewswire Scheduler",
        metatype = true, policy=ConfigurationPolicy.REQUIRE)
@Properties({
	@Property(
			label = "Enabled",
			description = "Enable/Disable the Scheduled Service",
			name = "service.enabled",
			boolValue = true 
			),
	@Property(
			name = Constants.SERVICE_DESCRIPTION, value = "JHAS PRNewswire Scheduler"
			),
    @Property(
                name = Constants.SERVICE_VENDOR, value = "JHAS"
             ),
    @Property(
                name = "scheduler.concurrent", boolValue = false
             ),
    @Property(
                name = "scheduler.expression",
                value = "0 0/15 * 1/1 * ? *",
                description = "Scheduler Cron Expression. Follow the link http://www.docjar.com/docs/api/org/quartz/CronExpression.html for more details."
              )
	})
			

public class PRNewsScheduler {
    private static final Logger LOG = LoggerFactory.getLogger(PRNewsScheduler.class);
   
    @Reference
    private SlingSettingsService slingSettings;

    @Reference
    private Scheduler scheduler;
    
    @Reference
    private PRNewswireService prnewswireService;
    
    @Activate
    protected void activate(final ComponentContext componentContext) throws Exception {    
    	final Map<String, String> properties = (Map<String, String>) componentContext.getProperties();
        Boolean enableVal=PropertiesUtil.toBoolean(properties.get("service.enabled"),false);
        final String cronExp=PropertiesUtil.toString(properties.get("scheduler.expression"),"");
        ScheduleOptions options=scheduler.EXPR(cronExp);
        LOG.info("PRNewsScheduler--- enableVal"+enableVal); 
        if(enableVal){
        	scheduler.schedule(new Runnable() {
        		
        		@Override
				public void run() {
		            if(slingSettings.getRunModes().contains("author")){
		                    LOG.error("PRNewsScheduler--- Run Mode is author and scheduler is triggered.");          
		                            try {
		                                    	prnewswireService.getNewsfeedReleases();
		                                LOG.info("PRNewsScheduler--- Completed successfully"); 
		                            }catch (Exception e1) {
		                                LOG.error(":: PRNewsScheduler Exception::" + e1);
		                            }
		            }
				}
			}, options);
        	
        	
        	
        }  
    }
 
    @Deactivate
    protected void deactivate(ComponentContext ctx) {
 
    }
}


