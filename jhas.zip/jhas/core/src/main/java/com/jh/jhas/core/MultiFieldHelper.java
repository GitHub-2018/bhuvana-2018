package com.jh.jhas.core;

import java.util.ArrayList;
import java.util.HashMap;

import javax.jcr.Node;
import javax.jcr.NodeIterator;

import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jh.jhas.core.utility.LinkChecker;

public class MultiFieldHelper extends WCMUsePojo {
	   ArrayList<HashMap<String, String>> fieldList;
	   String fieldListJSON;
		private Logger LOG = LoggerFactory.getLogger(MultiFieldHelper.class);
		HashMap<String, String> multiValHashMap = new HashMap<String, String>();
		public void activate() {
			LOG.info("||MultiFieldHelper||activate method||Start||");
			String path = get("path", String.class);
			String nodename = get("nodename", String.class);
			String properties = get("properties", String.class);
			LOG.info("multifield Properties"+ properties);
			String[] propertyval = properties.split(",");
			try {
			fieldList = new ArrayList<HashMap<String, String>>();
			final Resource resource = getResourceResolver().getResource(path);
			final Node resourceNode = resource.adaptTo(Node.class);
			if (resourceNode.hasNode(nodename)) {
				LOG.info("||MultiFieldHelper||activate method||in sidehas node||"+propertyval);
				final NodeIterator nodeIterator = resourceNode.getNode(
						nodename).getNodes();
				
				while (nodeIterator.hasNext()) {
					final Node childNode = (Node) nodeIterator.next();
					HashMap<String, String> map = new HashMap<String, String>();
					for (final String propertyName : propertyval) {	
						if (childNode.hasProperty(propertyName)&& null != childNode.getProperty(propertyName).getString()) {
							LOG.info("propertyName"+ propertyName);
							String propertyNameValue =childNode.getProperty(propertyName).getString();
							if("urlLink".equals(propertyName)){
								propertyNameValue=LinkChecker.getInternalPath(propertyNameValue);
							}
							map.put(propertyName, propertyNameValue);
							
						} 
					
					}
					fieldList.add(map);
				}
				
		}
			}catch (final Exception e) {
	LOG.error("exception occured while retreiving"
			+ e.getMessage() +e);
	return;
}
		}
		public ArrayList<HashMap<String, String>> getMultiValues() {
			LOG.info("||MultiFieldHelper||activate method|| getMultiValues"+fieldList);
			return fieldList;
		
		}
		
		public String getMultiValuesJSON() {
			Gson prettyGson = new GsonBuilder().setPrettyPrinting().create();
			fieldListJSON = prettyGson.toJson(fieldList);
			LOG.info("||MultiFieldHelper||activate JSON method|| getMultiValuesJSON"+fieldListJSON);
			return fieldListJSON;
		
		}

} 

