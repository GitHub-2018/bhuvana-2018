package com.jh.jhas.core.models;

public class HeaderVanityItems {
	String vanityPath;
	String vanityPageTitle;
	public String getVanityPath() {
		return vanityPath;
	}
	public void setVanityPath(String vanityPath) {
		this.vanityPath = vanityPath;
	}
	public String getVanityPageTitle() {
		return vanityPageTitle;
	}
	public void setVanityPageTitle(String vanityPageTitle) {
		this.vanityPageTitle = vanityPageTitle;
	}
	
}
