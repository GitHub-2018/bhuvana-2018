package com.jh.jhas.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.mailer.MessageGatewayService;
import com.jh.jhas.core.constants.EmailConstants;
import com.jh.jhas.core.constants.GlobalConstants;
import com.jh.jhas.core.helper.EmailHelper;
import com.jh.jhas.core.mailservice.JohnHancockSecureMailService;
import com.jh.jhas.core.models.EmailRecipient;
import com.jh.jhas.core.models.EmailSender;
import com.jh.jhas.core.models.Substitution;
import com.jh.jhas.core.utility.ConfigUtil;
import com.jh.jhas.core.utility.EmailUtil;

@SlingServlet(paths="/bin/sling/EmailFormServlet", methods="POST", metatype=true) 	
public class EmailFormServlet extends SlingAllMethodsServlet{
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG = LoggerFactory.getLogger(EmailFormServlet.class);
	
	@Reference
	private MessageGatewayService msgGatewayService;
	
	@Reference
	JohnHancockSecureMailService johnHancockSecureMailService;
	
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("Inside Dynamic Form Servlet");
		 Enumeration<String> parameterNames =request.getParameterNames();
		 Map<String,String> emailProps = new HashMap<String,String>();
		 String emailBody="";
		 List<String> emailRecipients= new ArrayList<>();
		 String toErrorAddress="PSamanta@jhancock.com";
		 String emailSubject="Email from Johnhancock.com Form";
		 
		 while (parameterNames.hasMoreElements()) {
		  String paramName = parameterNames.nextElement();
		  String paramValue=EmailHelper.stripXSS("paramName",Arrays.toString(request.getParameterValues(paramName)));
		  paramValue = paramValue.substring(1, paramValue.length()-1);
		  if(paramName.contains("EmailForm_MailTo")) {
			  emailRecipients = Arrays.asList(paramValue.split(","));
			  toErrorAddress = paramValue;
		  } else if (paramName.contains("EmailForm_Subject")) {
			  emailSubject = paramValue;
		  }
		  if (paramName.endsWith("[]")) {
			  paramName = paramName.substring(0, paramName.length() - 2);
		  }
		  Boolean isParameterRequired = true;
		  for(String removeParam : GlobalConstants.REMOVE_FORM_PARAMS){
			  if(paramName.contains(removeParam)){
				  isParameterRequired = false;
				  break;
			  }
		  }
		  if(isParameterRequired) {
			  emailBody+=paramName+"  :  "+paramValue+"<br>";
		  }
		 }
		 
		 
		 // populate the digital Sender Address
		 List<EmailRecipient> contactUsEmailRecipients = new ArrayList<>();
	
		 for(String emailRecipient : emailRecipients) {
			 EmailRecipient contactUsEmailRecipient = new EmailRecipient();
			 contactUsEmailRecipient.setName("Recipient Address");
			 contactUsEmailRecipient.setEmail(emailRecipient);
			 contactUsEmailRecipients.add(contactUsEmailRecipient);
		 }
		 
		// populate the digital email placeholders	
		List<Substitution> substitutions = new ArrayList<>();

		Substitution emailBodySub = new Substitution();
		emailBodySub.setName("body");
		emailBodySub.setValue(emailBody);
		substitutions.add(emailBodySub);		 
	 
		EmailSender senderAddress = new EmailSender();
		senderAddress.setName("Johnhancock Webadmin");
		senderAddress.setEmail("webadmin@jhancock.com");
		String templateId = ConfigUtil.INSTANCE.getStringConfiguration(EmailConstants.EMAIL_FORM_TEMPLATE);
		 
		 
		 	emailProps.put("body", emailBody);
			ResourceResolver resourceResolver = request.getResourceResolver();
			// Initialize Session object
			Session session = resourceResolver.adaptTo(Session.class);	
			

			// send the email by invoking JHInvestments API
			boolean emailStatus = false;
			try {
				emailStatus = johnHancockSecureMailService.sendDigitalAPIEmail(templateId, senderAddress, contactUsEmailRecipients, emailSubject, substitutions);
			    if(!emailStatus) {
			    	EmailUtil.sendEmail(msgGatewayService, session, EmailConstants.EMAIL_FORM_ERROR_TEMPLATE , emailProps, toErrorAddress);
			    }

			} catch (Exception ex) {
			    LOG.error("Error sending mail");
			}
			    
			finally {
			    // ALWAYS close the sessions you open
			    if (null != session && session.isLive()) {
				session.logout();
			    }
			    resourceResolver.close();
			}
			
			JSONObject obj = new JSONObject();
			try{
				if(emailStatus) {
					obj.put("message","emailForm_success");
				} else {
					obj.put("message","emailForm_faliure");
				} 
			}
			catch (JSONException e) {
				LOG.info("ERROR IN JSON OBJECT PARSING");
			}			      
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(obj.toString());
	}
}
