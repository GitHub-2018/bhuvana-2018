package com.jh.jhas.core.utility;

public class TextUtil {

	public static String getValidContentName(String name){
		String formattedName=name.replaceAll("[^A-Za-z0-9]","-").toLowerCase();
		return formattedName;
	}
}
