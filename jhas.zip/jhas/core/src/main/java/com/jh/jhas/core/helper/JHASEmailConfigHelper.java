package com.jh.jhas.core.helper;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Modified;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.osgi.service.cm.Configuration;

import com.jh.jhas.core.utility.ConfigUtil;

/**
 * JHAS Email Configuration - sets all Email configurations
 * 
 * @author Cognizant
 *
 */
@Component(immediate = true, metatype = false)
public class JHASEmailConfigHelper {
private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	/*@Reference
	private SlingSettingsService slingSettingsService;*/	
@Reference
private ConfigurationAdmin configAdmin;
private static final String EMAIL_CONFIG_PID = "com.jh.jhas.core.helper.JHASEmailConfigHelper";
	@Activate
	public void activate() throws IOException {
		Configuration emailhelperconfig = configAdmin.getConfiguration(EMAIL_CONFIG_PID);

		 Dictionary<String, Object> properties = emailhelperconfig.getProperties();
		 LOG.info("Properties of email config helper"+properties);
		 ConfigUtil.INSTANCE.setConfigProperties(properties);

	}

	/*@Activate
	public void activate(Map<String, Object> mapCreated) {
		
		LOG.info("Activating JHAS bundle...");
		// get configuration values
		ConfigUtil.INSTANCE.setConfigProperties(mapCreated);
		
		StringBuilder content = new StringBuilder(); 
		
		for(String runMode : slingSettingsService.getRunModes()){
			content.append("RUN Mode -" + runMode);
			content.append(System.getProperty("line.separator"));
		}
		// get configuration values
		ConfigUtil.INSTANCE.setEnvrionment(content.toString());
		
		LOG.info("JHAS bundle activation complete. ");
	}
*/
/*	@Modified
	public void modified(Map<String, Object> mapModified) {
		LOG.info("Modifying JHAS bundle...");
		// get configuration values
		ConfigUtil.INSTANCE.setConfigProperties(mapModified);
		LOG.info("JHAS bundle modification complete. ");
	}*/
}
