package com.jh.jhas.core.iconpicker.model;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.jhas.core.iconpicker.dto.Icon;
import com.jh.jhas.core.iconpicker.dto.IconMain;
import com.jh.jhas.core.utility.LinkChecker;

@Model(adaptables=SlingHttpServletRequest.class)
public class IconPickerModel {

	private Logger LOG = LoggerFactory.getLogger(IconPickerModel.class);

	public IconMain iconMain;

	@Inject
	SlingHttpServletRequest request;

	@Inject
	private String path;

	@PostConstruct
	protected void init(){

		final Resource resource = request.getResourceResolver().getResource(path);
		iconMain = new IconMain();
		try{
			iconMain.setBackground("dark");
			iconMain.setIcons(getIcons(resource));
		}catch(Exception e){
			LOG.error("Error while creating Icon Picker model",e);
		}
	}

	private List<Icon> getIcons(Resource resource) throws ValueFormatException, PathNotFoundException, RepositoryException {

		final Node resourceNode = resource.adaptTo(Node.class);
		List<Icon> iconList = new ArrayList<Icon>();
		Icon icon = null;
		Value [] iconClassesArray = null;
		Value singleIconClass = null;
		int counter = 0;

		if(resourceNode.hasProperty("iconPicker")){
			if (resourceNode.getProperty("iconPicker").isMultiple()) {
				iconClassesArray = resourceNode.getProperty("iconPicker").getValues();
			} else {
				singleIconClass = resourceNode.getProperty("iconPicker").getValue();
			}
			LOG.info("iconClassesArray"+iconClassesArray);
		}

		if (resourceNode.hasNode("properties")) {

			final NodeIterator nodeIterator = resourceNode.getNode("properties").getNodes();

			while (nodeIterator.hasNext()) {

				icon = new Icon();

				final Node childNode = (Node) nodeIterator.next();

				if(childNode.hasProperty("options")){
					icon.setOpenType(childNode.getProperty("options").getString());
				}

				if(childNode.hasProperty("title")){
					icon.setTitle(childNode.getProperty("title").getString());
				}

				if(childNode.hasProperty("urlLink")){
					icon.setUrlLink(LinkChecker.getInternalPath(childNode.getProperty("urlLink").getString()));
				}
				if(childNode.hasProperty("iconpath")){
					icon.setIconPath(childNode.getProperty("iconpath").getString());
				}
				if(null != singleIconClass) {
					icon.setIconClass(singleIconClass.getString());
				} else {
					icon.setIconClass(getValueFromArray(iconClassesArray,counter));
				}

				childNode.setProperty("iconPicker", icon.getIconClass());
				childNode.getSession().save();
				iconList.add(icon);
				LOG.info("childNode "+childNode.getName());
				counter++;
			}
		}
		return iconList;
	}


	private String getValueFromArray(Value [] iconClassesArray,int index) throws ValueFormatException, IllegalStateException, RepositoryException{
		if(iconClassesArray.length >= index){
			return iconClassesArray[index].getString();
		}
		return "";
	}
}
